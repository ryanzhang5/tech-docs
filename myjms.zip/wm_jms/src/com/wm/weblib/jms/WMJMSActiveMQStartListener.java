package com.wm.weblib.jms;

import java.util.logging.Logger;
import javax.jms.Session;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;
  
import com.wm.corelib.config.AppConfig;

public class WMJMSActiveMQStartListener extends WMJMSStartListener {
    private static Logger _logger = Logger.getLogger(WMJMSActiveMQStartListener.class.getName());
    private String aq_queue_name;
    private String aq_schema;

    private TopicConnectionFactory _tcf = null;
    private TopicConnection _tc = null;
    private TopicSession _session = null;
    private TopicSubscriber _subscriber = null;
    private Topic _topic = null;
    private String _subscriberName = null;
    private String _name;
    private static final String _durableSubName = AppConfig.getInstance().getProperty("PROP_JMS_IS_DURABLE_SUBSCRIBER");
    private static final String _url    = AppConfig.getInstance().getProperty("PROP_JMS_ACTIVEMQ_URL");
    private static final String _user   = AppConfig.getInstance().getProperty("PROP_JMS_ACTIVEMQ_USER");
    private static final String _password = AppConfig.getInstance().getProperty("PROP_JMS_ACTIVEMQ_PASSWORD");
    
    public WMJMSActiveMQStartListener(String name, String aq_schema, String aq_queue_name) {
        this._name = name;
        this.aq_queue_name = aq_queue_name;
        this.aq_schema = aq_schema;
    }

    public String getAQQName() {
        return aq_queue_name;
    }

    public String getAQSchema() {
        return aq_schema;
    }

    public String getListenerName() {
        return _name;
    }

    public TopicSession getSession() {
        return _session;
    }

    public TopicSubscriber getSubscriber() {
        return _subscriber;
    }

    public TopicConnection getConnection() {
        return _tc;
    }

    public void JMSStart() {
        try {
            /* create connection and session */
            _logger.warning("Starting JMS connection for " + _name);

            _tcf = ActiveMQSingleTonFactory.getInstance().getTopicConnectionFactory(_user, _password, _url);
              
            /* create a subscriber */
            _subscriberName = JMSAdminUtil.getSubscriberName();
            _logger.warning("TopicConnectionFactory created for " + _name);

            _tc = _tcf.createTopicConnection();
            
            if (_durableSubName != null && _durableSubName.contains(_name)) {
                if (_durableSubName.startsWith(_name))
                    _tc.setClientID(_subscriberName);
                else
                    _tc .setClientID(_subscriberName + "_" + _name);
            }            
            
            _logger.warning("TopicConnection created for " + _name);

            _session = _tc.createTopicSession(true, Session.CLIENT_ACKNOWLEDGE);
            _logger.warning("TopicSession created for " + _name);

             _topic = _session.createTopic(_name);
            _logger.warning("Topic created for " + _name);

            if (_durableSubName != null && _durableSubName.contains(_name)) {
                if (_durableSubName.startsWith(_name))
                    _subscriber = _session.createDurableSubscriber(_topic, _subscriberName, null, false);
                else
                    _subscriber = _session.createDurableSubscriber(_topic, _subscriberName + "_" +  _name, null, false);
            } else {
                _subscriber = _session.createSubscriber(_topic);
            }
            _logger.warning("Subscriber '" + _subscriberName + "' created for " + _name);

            _tc.start();
            _logger.warning("Started connection for " + _name);
            _logger.warning("Waiting for the messages for " + _name + " , " +  _tc);
        } catch (Exception e) {
            _logger.warning("Error starting JMS" + e);
            e.printStackTrace();
        }
    }

    public void JMSStop() {
        _logger.warning("Stopping JMS for " + _name);

        try {
            if (_subscriber != null) {
                _subscriber.close();
            }
        } catch (Exception ignore) {
            ignore.printStackTrace();
        }

        _logger.warning("Subscriber closed for " + _name);

        try {
            if (_tc != null) {
                _tc.stop();
            }
        } catch (Exception ignore) {
            ignore.printStackTrace();
        }

        _logger.warning("Connection stopped " + _name);

        try {
            if (_session != null) {
                _session.unsubscribe(JMSAdminUtil.getSubscriberName());
                _logger.warning("unsubscribe for " + JMSAdminUtil.getSubscriberName());

                _session.close();
            }
        } catch (Exception ignore) {
            ignore.printStackTrace();
        }

        _logger.warning("session closed for " + _name);

        try {
            if (_tc != null) {
                _tc.close();
            }
        } catch (Exception ignore) {
            ignore.printStackTrace();
        }

        _logger.warning("TopicConnection closed for " + _name + " , " + _tc);
        _logger.warning("Done " + _name);
        _tc = null;
        _subscriber = null;
        _session = null;
    }

    /**
     * Checks if listener connected.
     */
    public boolean isConnected() {
        boolean isConn = true;
        try {
            _tc.getMetaData().getJMSMinorVersion();
        } catch (Exception e){
            isConn = false;
        }
        return isConn;
    }

    /**
     * Return status information for the object.
     */
    public synchronized String toString() {
        String ls = AppConfig.getInstance().getProperty("line.separator");
        StringBuffer s = new StringBuffer(getClass().getName() + " { ");
        s.append(ls);

        if (!isConnected()) {
            s.append("  Listener is not connected.");
            s.append(ls);
        } else {
            s.append("  subscriber name: ");
            s.append(_subscriberName);
            s.append(ls);
            s.append("  queue name: ");
            s.append(aq_schema + "." + aq_queue_name);
            s.append(ls);
        }
        return s.toString();
    }
}
