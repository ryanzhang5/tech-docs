package com.wm.weblib.jms;


/**
 * An object of this type is returned by a WMMessageHandler from the
 * handleMessage method.
 * <p>
 * In a concrete implementation of this class, the toString() method should be
 * overridden to provide a String representation of the status of the message
 * handling event that this status object is associated with.  This will allow
 * the JMS listener to easily log message handling events.
 * <p>
 * You might also want to add handler-specific fields.
 */
public class WMMessageHandlerStatus {
    /**
     * This is the default status code, which means that the handler didn't do
     * anything with the message.
     */
    public final static int CODE_NOOP = 0;

    /**
     * This code means, that message was processed successfuly
     */
    public final static int CODE_SUCCESS = 1;

    /**
     * This code means that there's something non-fatally wrong.
     */
    public final static int CODE_WARNING = -1;

    /**
     * This code means, that handler made an attempt to process this message, but failed
     */
    public final static int CODE_FAILURE = -2;
    private int _code;
    private String _message;

    /**
     * No argument constructor: create object for NOOP status
     */
    public WMMessageHandlerStatus() {
        _code = CODE_NOOP;
    }

    /**
     * Create object with specified code
     */
    public WMMessageHandlerStatus(int code) {
        _code = code;
    }

    /**
     * Create object with specified code and message
     */
    public WMMessageHandlerStatus(int code, String message) {
        _code = code;
        _message = message;
    }

    /**
     * Returns the status code of the message handling event.
     */
    public int getCode() {
        return _code;
    }

    public String getMessage() {
        return _message;
    }

    public String toString() {
        StringBuffer s = new StringBuffer("WMMessageHandlerStatus{ code=");
        s.append(this.getCode());
        s.append(", message=");
        s.append(this.getMessage());
        s.append(" }");

        return s.toString();
    }

    /**
     * This method allows handlers to set the response code
     * of this status object.
     */
    protected void setCode(int code) {
        _code = code;
    }

    /**
     * This method allows handlers to set message
     * of this status object.
     */
    public void setMessage(String message) {
        _message = message;
    }
}
