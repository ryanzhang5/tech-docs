package com.wm.weblib.jms;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.jms.Connection;
import javax.jms.TopicConnectionFactory;

public class TibcoPersistentConnection {
    private TopicConnectionFactory _connectionFactory = null;
    private String _user, _password, _url;
    private Connection _tibcoConnection;
    private static final Logger logger = Logger.getLogger(TibcoPersistentConnection.class.getName());

    /**
     * Constructor 
     * @param user -- User name
     * @param password -- password
     * @param url -- URL
     */
    public TibcoPersistentConnection(String user, String password, String url) {
        _user = user;
        _password = password;
        _url = url;
        createTopicConnectionFactory();
    }
    
    /**
     * Method created topic connection factory
     */
    private synchronized void createTopicConnectionFactory() {
        try {
          _connectionFactory = TibcoSingletonFactory.getInstance().getTopicConnectionFactory(_user, _password, _url);
          _tibcoConnection = _connectionFactory.createConnection(_user,_password);
          _tibcoConnection.start();
          
          logger.warning("TIBCO Connection created for " + _url);
          
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }
    

    /**
     * Get connection
     * @return -- Connection
     */
    public Connection getConnection() {
      try {
          _tibcoConnection.getMetaData();
        } catch (Exception exp) {
          logger.log(Level.WARNING, "Exception occurred while getting meta data, connect might have been lost for URL ..." + _url, exp);
          logger.warning("Trying to recover the connection");
          createTopicConnectionFactory();
        }
        return _tibcoConnection;
    }

}
