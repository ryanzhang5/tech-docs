package com.wm.weblib.jms;

import java.util.Date;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Map;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import java.util.concurrent.atomic.AtomicBoolean;

import javax.jms.*;
  
import com.wm.corelib.config.AppConfig;



/**
 * This class knows how to operate the Java Messaging System from the client
 * point of view. It knows how to connect to the message stream
 * (whatever that is) and pass them off to interested parties.  There's a
 * facility for adding message "handlers" to this thing which it, in turn,
 * relays incoming messages to.
 * <p>
 * Note: We have to be VERY careful about exceptions in here.  There should be
 * a master try/catch block which handles all exceptions in a graceful way;
 * otherwise, this jms thing could crash Tomcat, which would be very bad.
 */
public class WMJMSListenerManager implements WMJMSConstants {

    /** Static class logger */
    private static Logger _logger = Logger.getLogger(WMJMSListenerManager.class.getName());
    private static String _initListenerNames[] = AppConfig.getInstance().getProperty("PROP_JMS_LISTENERS").split(",");
    private static String _handlerNames[];
    private Map<String,WMJMSStartListener> _jmsListeners = new LinkedHashMap<String,WMJMSStartListener>();
    private static Map<String, WMJMSReceiveMessages> _recvMessageMap = new LinkedHashMap<String, WMJMSReceiveMessages>();
    private static Map<WMJMSReceiveMessages, String[]> _recvMessageHandlerMap = new LinkedHashMap<WMJMSReceiveMessages, String[]>();
    private static Map<String, WMJMSListenerStatus> _listenerStatusMap = new LinkedHashMap<String, WMJMSListenerStatus>();

    private static final int CONNECTION_CHECK_INTERVAL = 5 * 60 * 1000; // 5 minutes
    private static final AtomicBoolean _isThreadInitialize = new AtomicBoolean(false);
    //
    // Member variables
    //
    private static WMJMSListenerManager _instance = new WMJMSListenerManager(); //holds reference to the only instance of this class
    /** AQ message queue name */
    private String aq_queue_name;

    /** AQ schema */
    private String aq_schema;
    private Timer managerTimer;
    private Timer connTimer;

    /**
     * hide noargument constructor
     */
    private WMJMSListenerManager() {
    }

    /**
     * Returns the only instance of WMJMSListenerManager.
     * We don't want multiple instances of this class hanging around.
     */
    public static WMJMSListenerManager getInstance() {
        return _instance;
    }

    public synchronized void start(int timeout, String listenerName) {
        start(timeout);
    }

   public synchronized void start(int timeout) {
	   	boolean isListenersEnabled = true;
	
		String listenersEnabled = AppConfig.getInstance().getProperty("PROP_JMS_LISTENERS_ENABLED");
		String interval    = AppConfig.getInstance().getProperty("PROP_JMS_LISTENERS_RECONNECT_INTERVAL_IN_MINUTE");
	
		if(listenersEnabled !=null && listenersEnabled.trim().equalsIgnoreCase("false") ){
			isListenersEnabled = false;
		}
		if(interval ==null || interval.trim().equals("") ){
			interval = "1";
		}

		if(isListenersEnabled ){
			_logger.warning("JMSListener is switched on");

                for(int a=0;a<_initListenerNames.length;a++){
                    _initListenerNames[a]=_initListenerNames[a].trim();
                    _listenerStatusMap.put(_initListenerNames[a], new WMJMSListenerStatus(_initListenerNames[a]));
                }

                //dont need to keep it initialized
                    if (!_isThreadInitialize.get()) {
                            _isThreadInitialize.set(true);
                            int randomInterval = 1000 *( 30 + new java.util.Random().nextInt(Integer.parseInt(interval) * 60 - 30 ) );
                            WMJMSListenerManagerThread managerThread = new WMJMSListenerManagerThread(this, timeout);
                            managerTimer = new Timer("listener-manager-thread", true);
                            //managerTimer.schedule(managerThread,randomInterval,CONNECTION_CHECK_INTERVAL);
                            managerTimer.schedule(managerThread,0,CONNECTION_CHECK_INTERVAL);
                            //managerThread.setDaemon(true);
                            //managerThread.start();
    
                            WMJMSListenerCheckingThread statusThread = new WMJMSListenerCheckingThread(this);
                            connTimer = new Timer("check-jms-connection", true);
                            connTimer.schedule(statusThread,randomInterval,CONNECTION_CHECK_INTERVAL);
                            //statusThread.setDaemon(true);
                            //statusThread.start();
                    }
		} else {
			_logger.warning("JMSListener is switched off");
		}

    }


/*
    public synchronized void start(int timeout, String listener) {
    	start(timeout, listener, true);
    }
*/
    /**
     * Tries to start JMS connection with timeout.
     * If it can not connect for <code>timeout</code> millis
     * it gives up and returns.
     *
     * If <code>autoCreateListener</code> is false, Map _jmsListeners will notbe changed. we only let original listeners to try
     * to reconnect to AQ if they are not connected.
     */
    public synchronized void start(int timeout, String listener, boolean autoCreateListener) {


	    if(autoCreateListener){

	    	ArrayList<String> notConnectedListeners = getDisconnectedListeners(listener);

	    	//iterate over the list of listeners to be started
	        for(String listenerName : notConnectedListeners){

                stop(listenerName);
            	_jmsListeners.remove(listenerName);
	            aq_queue_name = AppConfig.getInstance().getProperty("PROP_JMS_" + listenerName + "_AQ_QUEUE_NAME");
	            aq_schema     = AppConfig.getInstance().getProperty("PROP_JMS_" + listenerName + "_AQ_SCHEMA");
                    
	            WMJMSStartListener jmsStart = null;
	            if (JMSAdminUtil.isOracleAQEnabled()) {
	            	jmsStart = new WMJMSOracleStartListener(listenerName, aq_schema, aq_queue_name);
	            } else if (JMSAdminUtil.isActiveMQEnabled()) { 
	                jmsStart = new WMJMSActiveMQStartListener(listenerName, aq_schema, aq_queue_name);
              	    } else {
                        jmsStart = new WMJMSTibcoStartListener(listenerName, aq_schema, aq_queue_name);
	            }
	            _jmsListeners.put(listenerName,jmsStart);
	            
        	    //open connection to AQ in separate thread (in case something is wrong and it blocks, we can kill it)
            	jmsStart.setName("Starting JMS " + jmsStart.getListenerName());
            	jmsStart.setDaemon(true);
            	jmsStart.start();
        	    try {
        	    	jmsStart.join(timeout);
        	    } catch (InterruptedException ignore) {;}

        	    if (jmsStart.isAlive()) {
        	    	jmsStart.JMSStop();
        	    	_logger.warning("Can not connect to AQ! " + jmsStart.getListenerName());
        	    } else {
	        		//start Thread which will receive messages
	        		WMJMSReceiveMessages rcvmsgs = new WMJMSReceiveMessages(listenerName, jmsStart);
	        		//get the handlers for this listener for ex: PROP_JMS_WMJMSAdminListener_HANDLERS
	        		_handlerNames =  AppConfig.getInstance().getProperty("PROP_JMS_" + jmsStart.getListenerName() + "_HANDLERS").split(",");

	        		//it may be a array in the future
	        		String factoryName = AppConfig.getInstance().getProperty("PROP_JMS_" + jmsStart.getListenerName() + "_FACTORY").trim();
	        		rcvmsgs.setMessageFactory(factoryName, jmsStart.getAQQName(), jmsStart.getAQSchema());

	        		for(int a=0;a<_handlerNames.length;a++){
	        		    //trim the handler names
	        		    _handlerNames[a]=_handlerNames[a].trim();

	        		    //initialise the handlers and register them with the listener
	        		    try{
	        			WMMessageHandler msghndlr = (WMMessageHandler)Class.forName(_handlerNames[a]).newInstance();
	        			rcvmsgs.addHandler(msghndlr);
                      			_logger.warning("Registering handlers: " + _handlerNames[a]);
	        		    } catch(Exception ex) {
	        			ex.printStackTrace();
	        		    }
	        		}
	        		rcvmsgs.setName(rcvmsgs.getReceiveMessageName() + " listening for JMS messages.");
	        		rcvmsgs.setDaemon(true);
	        		rcvmsgs.start();
	        		//Add receivemessage thread and handlers to a collection
	        		_recvMessageHandlerMap.put(rcvmsgs,_handlerNames);
	        		_recvMessageMap.put(rcvmsgs.getReceiveMessageName(),rcvmsgs);
        	    }
            }
	    }
    }

    public void checkListenerStatus(){

    	long now = System.currentTimeMillis();

        for (Map.Entry<String,WMJMSListenerStatus> e : _listenerStatusMap.entrySet()){
        	WMJMSListenerStatus status = e.getValue();
        	String listenerName = e.getKey();

        	boolean isconnectedNow = isConnected(listenerName);
        	// first initialize the WMJMSListenerStatus when first connected
        	if( isconnectedNow ){
        		if(status.getInitializePoint()==0){
        			status.setInitializePoint(now);
        		}
        	}
        	// make status change if the now status is diff from last check
        	if( status.getLastConnectionStatus() !=  isconnectedNow ){
        		status.setLastStatusChangedPoint(now);
        		status.setLastConnectionStatus(isconnectedNow);
        		if( isconnectedNow ){
        			status.setOnlineBeginPoint(now);
        			status.setOnlineEndPoint(now);
        		}else{
        			status.setOfflineBeginPoint(now);
        			status.setOfflineEndPoint(now);
        		}
        	} else { //make change for status lasting time if the now status is seam to last check
        		if( isconnectedNow ){
        			status.setOnlineEndPoint(now);
        		}else {
        			if(status.getInitializePoint() !=0)
        				status.setOfflineEndPoint(now);
        		}
        	}

        	//_logger.warning( status.toString() );

        	if( !isconnectedNow ){
        		if(    (status.getInitializePoint()!=0 && status.getOfflineEndPoint() - status.getOfflineBeginPoint() > 10*60*1000 )
        			|| (status.getInitializePoint()==0 && now                         - status.getCreatePoint()       > 10*60*1000 )
        			){
        			_logger.warning( "Can not connect to AQ withing 10 minutes! "+ status.toString() );
        		}
        	}
        }
    }

    public ArrayList<String> getDisconnectedListeners(String listener){

    	ArrayList<String> notConnectedListeners = new ArrayList<String>();
    	if (listener!=null){
            if( !isConnected(listener) ){
            	notConnectedListeners.add(listener);
            }
    	}else{
	        for(int a=0;a<_initListenerNames.length;a++){
	            _initListenerNames[a]=_initListenerNames[a].trim();
	            if( !isConnected(_initListenerNames[a]) ){
	            	notConnectedListeners.add(_initListenerNames[a]);
	            }
	        }
    	}

        return notConnectedListeners;
    }


    public WMJMSReceiveMessages getReceiver(String name){
		return _recvMessageMap.get(name);
	}

    public LinkedHashMap getListeners(){
        return (LinkedHashMap)_jmsListeners;
    }

    public String[] getHandlers(String listenerName){
        return _recvMessageHandlerMap.get(_recvMessageMap.get(listenerName));
    }

    /**
     * Stop JMS connection.
     */
    public synchronized void stop(String listenerName) {

        _logger.warning("Stopping JMS... " + listenerName);

        WMJMSReceiveMessages receiver = _recvMessageMap.get(listenerName);

        if ( receiver!=null && receiver.isConnected() ){
        	receiver.disconnect();
    	    try{
    	    	receiver.interrupt();
    		} catch(Exception ex) {
    			ex.printStackTrace();
    		}
        }
        _recvMessageHandlerMap.remove(receiver);
        _recvMessageMap.remove(listenerName);
        receiver = null;

        WMJMSStartListener listener = _jmsListeners.get(listenerName);
        if(listener != null){
        	listener.JMSStop();
        }
        _jmsListeners.remove(listenerName);

    }

    public void JMSStopAll() {
        if (managerTimer != null) managerTimer.cancel();
        if (connTimer != null) connTimer.cancel();
        //iterate over the collection of listeners and call stop on them.
        for (Map.Entry<String,WMJMSStartListener> e : _jmsListeners.entrySet()){
             stop(e.getKey());
        }
    }
    public boolean isConnected(String listenerName){
        boolean isconnected = (   _jmsListeners.get(listenerName) !=null
        		               && _jmsListeners.get(listenerName).isConnected()
        		               && _recvMessageMap.get(listenerName) !=null
        		               && _recvMessageMap.get(listenerName).isConnected() );

        //_logger.warning("Checking JMS connection... Listener: " + listenerName + " Connected: " + isconnected);
        return isconnected;
    }

    private class WMJMSListenerCheckingThread extends TimerTask {
    	private WMJMSListenerManager manager = null;

    	public WMJMSListenerCheckingThread(WMJMSListenerManager manager ){
            this.manager = manager;
        }

	public void run(){
            manager.checkListenerStatus();
        }
    }

    private class WMJMSListenerManagerThread extends TimerTask {

    	private WMJMSListenerManager manager = null;
    	private int timeout;

    	public WMJMSListenerManagerThread(WMJMSListenerManager manager, int timeout){
            this.manager = manager;
            this.timeout = timeout;
        }

	public void run(){
            manager.start(timeout,null,true);
	}
    }



     /**
     * For testing only.
     */
    public static void main(String[] args) throws java.io.IOException {

        WMJMSListenerManager listener = WMJMSListenerManager.getInstance();
        listener.start(Integer.parseInt(AppConfig.getInstance().getProperty("PROP_JMS_TIMEOUT")));


	Map<String,WMJMSStartListener> jmsListeners = WMJMSListenerManager.getInstance().getListeners();

	for (Map.Entry<String,WMJMSStartListener> e : jmsListeners.entrySet()) {
	    WMJMSListenerManager.getInstance().getReceiver(e.getKey()).getLastMessageReceived();
	}

	/*
        WMJMSListenerManager listener = WMJMSListenerManager.getInstance();

        System.out.println(listener);
        listener.start(Integer.parseInt(AppConfig.getInstance().getProperty("PROP_JMS_TIMEOUT")));

        System.out.println("Press Enter to exit.");
        System.in.read();

	HashMap ls = listener.getListeners();


        System.out.println(listener);
        listener.stop();
	*/

    }

}
