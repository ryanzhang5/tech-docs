package com.wm.weblib.jms;

import java.util.HashMap;
  
import com.wm.corelib.config.AppConfig;


/**
 * Base class for admin messaging interface 
 *
 * All Admin messages should extend this class
 * Ensures proper origin information is passed
 */
public abstract class WMMessageAdmin extends WMMessage implements WMJMSConstants {
	
	public static final String ORIGIN = "origin";	


	
	/** origin of the message is stored here */
	private String _origin;
	
	/**
	 * Direct interface to create new messages
	 * @param msgType Message type from WMMessagType
	 * @param target target server regex
	 */
	protected WMMessageAdmin(WMMessageType msgType, String target)
	{
		super(msgType);					
		_target = target;	
		_origin = AppConfig.getInstance().getProperty(PROP_REAL_HOSTNAME);
	}

	/**
	 * Parse message interface uses to build the message
	 *  
	 * @param msgType messageype
	 * @param valueMap values map of parsed name values
	 * @throws WMMessageException
	 */
	protected WMMessageAdmin(WMMessageType msgType, HashMap valueMap)
		throws WMMessageException
	{
        super(msgType);
		
		_target = (String)valueMap.get(TARGET);        
                if (_target == null)
			throw new WMMessageException(TARGET +" not defined.");
		
		_origin = (String)valueMap.get(ORIGIN);	
		if (_origin == null)
			throw new WMMessageException(ORIGIN +" not defined.");		 			
	}    
	
	/**
	 * @return origin - message origin server
	 */
	public String getOrigin() {
		return _origin;
	}
		
	/**
	 * Carefully override this method, if additional params have to be
	 * stored locally - should include this method output in result
	 * All stored params WMMessages are included
	 * @return String any additional params that are stored
	 * @see WMMessage#getMessageAsString() 
	 */
	public String getAdditionalParamsString() {
		return getParamString(ORIGIN, getOrigin());
	} // getMessageAsString

}
