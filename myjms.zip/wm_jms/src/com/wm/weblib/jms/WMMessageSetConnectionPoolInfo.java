package com.wm.weblib.jms;

import java.util.HashMap;

import com.wm.weblib.jms.WMMessageAdmin;
import com.wm.weblib.jms.WMMessageException;
import com.wm.weblib.jms.WMMessageType;

/**
 * @deprecated - use the one in "common" package
 */
public class WMMessageSetConnectionPoolInfo extends WMMessageAdmin {

	private static final String PROP_SERVERTYPE = "servertype";
	private static final String PROP_POOLNAME = "poolname";
	private static final String PROP_MAXSIZE = "maxsize";

	public WMMessageSetConnectionPoolInfo(String target, String serverType,
			String poolName, String maxSize) {

		super(WMMessageType.MSG_TYPE_SET_CONNECTION_POOL_INFO, target);
		setValue(PROP_SERVERTYPE, serverType);
		setValue(PROP_POOLNAME, poolName);
		setValue(PROP_MAXSIZE, maxSize);

	}

	public WMMessageSetConnectionPoolInfo(HashMap valueMap) throws WMMessageException {
		super(WMMessageType.MSG_TYPE_SET_CONNECTION_POOL_INFO, valueMap);

		setValue(PROP_SERVERTYPE, valueMap.get(PROP_SERVERTYPE));
		setValue(PROP_POOLNAME, valueMap.get(PROP_POOLNAME));
		setValue(PROP_MAXSIZE, valueMap.get(PROP_MAXSIZE));

	}
	
	public String getServerType() {
		return getValue(PROP_SERVERTYPE);
	}
	
	public String getMaxSize() {
		return getValue(PROP_MAXSIZE);
	}

	public String getPoolName() {
		return getValue(PROP_POOLNAME);
	}
}
