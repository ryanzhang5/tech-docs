package com.wm.weblib.jms.common;

import com.bitmechanic.sql.url.UrlKeyManager;
import com.wm.sql.DataAccess;
import com.wm.weblib.jms.WMMessage;
import com.wm.weblib.jms.WMMessageHandlerStatus;
import com.wm.weblib.jms.WMMessageType;

import java.util.logging.Level;
import java.util.logging.Logger;

public class WMMessageHandlerDBPoolUrlKeys extends WMAdminMessageHandler {
    private static final Logger logger = Logger.getLogger(WMMessageHandlerDBPoolUrlKeys.class.getName());

    protected boolean canHandle(WMMessage message) {
        return WMMessageType.MSG_TYPE_DBPOOL_URL_KEYS.equals(message.getMessageType());
    }

    public WMMessageHandlerStatus handleMessage(WMMessage m) {
        try {
            if (!canHandle(m)) return _defaultStatus;

            WMMessageDBPoolUrlKeys message = (WMMessageDBPoolUrlKeys) m;
            UrlKeyManager urlKeyManager = DataAccess.getInstance().getUrlKeyManager();
            if (urlKeyManager == null) throw new Exception("UrlKeyManager is null");
            urlKeyManager.setUrlKeys(message.getUrlKeys());
            _successStatus.setMessage(this.getClass().getName() + ": successfully processed message " + m);
        } catch (Exception e) {
            logger.log(Level.WARNING, "Unexpected error while handling message: " + m, e);
            return new WMMessageHandlerStatus(WMMessageHandlerStatus.CODE_FAILURE, e.toString());
        }
        return _successStatus;
    }

}
