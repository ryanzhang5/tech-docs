package com.wm.weblib.jms.common;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.bitmechanic.sql.GenericPool;
import com.wm.sql.DataAccess;
import com.wm.weblib.jms.*;
  
import com.wm.corelib.config.AppConfig;

public class WMMessageHandlerSetConnectionPoolInfo extends
		WMAdminMessageHandler {

	private static final Logger logger = Logger
			.getLogger(WMMessageHandlerSetConnectionPoolInfo.class.getName());

	public static String APP_DOMAIN_CODE_KEY = "com.wm.ApplicationDomainCode";

	protected boolean canHandle(WMMessage message) {
		WMMessageType msgType = message.getMessageType();
		return msgType.equals(WMMessageType.MSG_TYPE_SET_CONNECTION_POOL_INFO);
	}

	public WMMessageHandlerStatus handleMessage(WMMessage m) {
        try {

        	if (!canHandle(m))
        		return _defaultStatus;

        	WMMessageSetConnectionPoolInfo message = (WMMessageSetConnectionPoolInfo)m;
        	String serverType = message.getServerType();
        	String localServerType = AppConfig.getInstance().getProperty(APP_DOMAIN_CODE_KEY);

        	if (serverType != null && !"".equals(serverType.trim()) && localServerType != null && !"".equals(localServerType.trim())) {
	    	   	if ("ALL".equals(serverType)) {
	        		setConnectionMaxSize(message.getPoolName(), message.getMaxSize());
	        		logger.finest(getClass().getName() +  " Setting " + message.getPoolName()
	        				+ " max size to " + message.getMaxSize() + " on this server is done successfully.");
	        	}else {
	        		if ((serverType.equals(localServerType) )) {
	        			setConnectionMaxSize(message.getPoolName(), message.getMaxSize());
	        			logger.finest(getClass().getName() +  " Setting " + message.getPoolName()
	            				+ " max size to " + message.getMaxSize() + " on this server is done successfully.");
	        		}else {
	        			logger.finest(getClass().getName() +  " Setting " + message.getPoolName()
	            				+ " max size to " + message.getMaxSize() + " on this server is omitted because this server is not "
	            				+ serverType);
	        		}

	        	}

	        	_successStatus.setMessage(this.getClass().getName() +
	                    ": successfully processed message " +
	                    m);
        	}else {
        		return _defaultStatus;
        	}
        } catch (Exception ex) {
        	logger.log(Level.WARNING, "SET CONNECTION POOL INFO ERROR MSG ", ex);
        }
        return _successStatus;
	}

	private void setConnectionMaxSize(String poolName, String maxSize) {

		try {
			GenericPool[] pool = DataAccess.getInstance().getConnectionPool(
					poolName);
			if (pool == null || pool.length == 0)
				return;
			for (int i = 0; i < pool.length; i++) {
				int maxsizeVal = Integer.parseInt(maxSize);
				pool[i].setMaxSize(maxsizeVal);
				AppConfig.getInstance().setProperty("com.wm.sql.dataaccess."+poolName+".maxconn", maxSize);
			}
		} catch (NumberFormatException ex) {
			logger.log(Level.WARNING, "SET CONNECTION POOL INFO ERROR MSG ", ex);
		} catch (Exception ex) {
			logger.log(Level.WARNING, "SET CONNECTION POOL INFO ERROR MSG ", ex);
		}

	}
}
