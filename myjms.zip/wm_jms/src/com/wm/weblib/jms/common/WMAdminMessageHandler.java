package com.wm.weblib.jms.common;

import java.util.logging.Logger;

import com.wm.weblib.jms.WMMessageHandler;
import com.wm.weblib.jms.WMMessage;
import com.wm.weblib.jms.WMMessageAdmin;
  
import com.wm.corelib.config.AppConfig;

/**
 * All admin handlers should implement this class
 * Ensures all validation checks are made 
 */
abstract public class WMAdminMessageHandler extends WMMessageHandler {	

	/** Static class logger */
	private static Logger _logger = Logger.getLogger(WMAdminMessageHandler.class.getName());

    /**
     * Check to see if the message source is trusted or not.
     * Regex check is done against Trusted publishers from System configuration.
     *
     * @param message WMMEssage to be handled
     * @return true if message is from trusted souce else false
     */
    protected final boolean isTrusted(final WMMessage message) {
		
		if (!( message instanceof WMMessageAdmin))
			return false;

		WMMessageAdmin wmAdminMsg = (WMMessageAdmin)message; 
       
        String origin = wmAdminMsg.getOrigin();
		boolean trusted = false;
        if (origin != null) {
			trusted = origin.matches(AppConfig.getInstance().getProperty(PROP_AUTHORIZED_PUBLISHERS));
        }
		_logger.fine("Message origin : " + origin + " trusted : " + trusted);
        return trusted;
    }

    /**
     * Check to see if the message is targetted to this server. target param
     * must be specified for all admin messages.
     * 
     * Overrides default implementation in WMMessageHandler, for admin handlers
     * Regex is used to check.
     *
     * @param message WMMEssage to be handled
     * @return true if message is targetted to this host else false
     * @see WMMessageHandler#isTargetted(WMMessage)
     */
    protected final boolean isTargetted(final WMMessage message) {

        String target = message.getTarget();		
		boolean targetted = false;
        if (target != null) {
        	targetted = AppConfig.getInstance().getProperty(PROP_REAL_HOSTNAME).matches(target);
        }
		_logger.fine("Target Server Regex : " + target + " targetted: "+ targetted);
        return targetted;
    }
}
