package com.wm.weblib.jms.common;

import java.util.HashMap;

import com.wm.weblib.jms.WMMessageType;
import com.wm.weblib.jms.WMMessageAdmin;
import com.wm.weblib.jms.WMMessageException;


/**
 * Base class for messages that use type pool
 * TODO: refactor out a super class that supports an array of String IDs 
 */
abstract class WMMessageDBPool extends WMMessageAdmin {
    public static final String PARAM_TYPE = "type";
    public static final String PROP_PARAM_POOL_TYPE_SEARCH = "search";

    public WMMessageDBPool(WMMessageType msgType, String target, String poolType) {
        super(msgType, target);
        setValue(PARAM_TYPE, poolType);
    }

    public WMMessageDBPool(WMMessageType msgType, HashMap valueMap)
                    throws WMMessageException
    {
        super(msgType, valueMap);
        setValue(PARAM_TYPE, valueMap.get(PARAM_TYPE));
    }

    public String getPoolType() {
        return getValue(PARAM_TYPE);
    }

    public boolean isSearchPoolsOnly() {
        String type = getPoolType();

        return (type != null) && type.equals(PROP_PARAM_POOL_TYPE_SEARCH);
    }
}
