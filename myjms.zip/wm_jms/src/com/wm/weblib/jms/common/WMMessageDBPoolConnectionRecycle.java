package com.wm.weblib.jms.common;

import java.util.HashMap;
import com.wm.weblib.jms.WMMessageException;
import com.wm.weblib.jms.WMMessageType;


public class WMMessageDBPoolConnectionRecycle extends WMMessageDBPool {

	public WMMessageDBPoolConnectionRecycle(String target, String poolType)
	{
		super(WMMessageType.MSG_TYPE_DBPOOL_CONNECTION_RECYCLE, target, poolType);
	}

	public WMMessageDBPoolConnectionRecycle(HashMap valueMap)
		throws WMMessageException
	{
		super(WMMessageType.MSG_TYPE_DBPOOL_CONNECTION_RECYCLE, valueMap);
	}
}

