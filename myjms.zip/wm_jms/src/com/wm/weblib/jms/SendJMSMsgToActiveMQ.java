package com.wm.weblib.jms;

import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.jms.DeliveryMode;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;

import com.wm.corelib.config.AppConfig;

public class SendJMSMsgToActiveMQ {
    private static final boolean _isTransacted = true;
    private static long _TTL = 3600000;
    private static final Logger logger = Logger.getLogger(SendJMSMsgToActiveMQ.class.getName());
    private static TopicConnection _connection = null;
    private static TopicSession _session = null;
    private static final String activeMQURL    = AppConfig.getInstance().getProperty("PROP_JMS_ACTIVEMQ_SEND_URL");
    private static final String activeMQUser   = AppConfig.getInstance().getProperty("PROP_JMS_ACTIVEMQ_USER");
    private static final String activeMQPassword = AppConfig.getInstance().getProperty("PROP_JMS_ACTIVEMQ_PASSWORD");
    private static int CONNECTION_CHECK_INTERVAL = 30 * 60 * 1000; 
    private static int START_INTERVAL = 60 * 1000; 
    private static final Object gate = new Object();

    static {
        TimerTask task = new TimerTask() {
            public void run(){
                try {
                    checkNcreateConnection(true);
                } catch (Exception exp) { exp.printStackTrace(); }
            }
        };
        
        try {
            CONNECTION_CHECK_INTERVAL = Integer.parseInt(AppConfig.getInstance().getProperty("PROP_JMS_CONNECTION_CHECK_INTERVAL"));
            //must be greater than 1 minute
            if ( CONNECTION_CHECK_INTERVAL  <= 60 * 1000)
                CONNECTION_CHECK_INTERVAL = 30 * 60 * 1000; 
        } catch (Exception ignore){;}
        
        Timer conntimer = new Timer("jms-check-connection", true);
        conntimer.schedule(task,START_INTERVAL,CONNECTION_CHECK_INTERVAL);

    }    
    
    /**
     * Method to send Object Message
     * @param topicName - Topic Name
     * @param object - Object Message
     */
    public static void sendAQObjectMessage(String topicName, WMJMSObjectMessage object) {
        sendAQObjectMessage(topicName, object, false);
    }
    
    /**
     * Method to send Object Message
     * @param topicName - Topic Name
     * @param object - Object Message
     * @param isPersistentConnection - true if connection should be open all the time other wise false
     */
    public static void sendAQObjectMessage(String topicName, WMJMSObjectMessage object, boolean isPersistentConnection) {
        sendAQObjectMessage(topicName, _TTL, object, isPersistentConnection);
    }

    /**
     * Method to send Object Message
     * @param topicName - Topic/Queue Name
     * @param ttl -- TTL
     * @param object - Object Message
     */
    public static void sendAQObjectMessage(String topicName, long ttl, WMJMSObjectMessage object) {
        sendAQObjectMessage(topicName, ttl, object, false);
    }

    /**
     * Method to send Object Message
     * @param topicName - Topic Name
     * @param ttl -- TTL
     * @param object - Object Message
     * @param isPersistentConnection - true if connection should be open all the time other wise false
     */
    public static void sendAQObjectMessage(String topicName, long ttl, WMJMSObjectMessage object, boolean isPersistentConnection) {

      if (!JMSAdminUtil.isActiveMQEnabled()) { 
          SendJMSMsgToTibco.sendAQObjectMessage(topicName, ttl, object, isPersistentConnection);
          return;
      }
      
      if (isPersistentConnection) {
            sendMessageonPersistentConn(topicName, ttl, null, object);
      } else { 
            sendMessage(topicName, ttl, null, object);
      }
    }

/*************************************************************************/

    /**
     * Method to send Text Message
     * @param topicName - Topic Name
     * @param text - Text message
     */
    public static void sendAQTextMessage(String topicName, String text) {
        sendAQTextMessage(topicName, text, false);
    }

    /**
     * Method to send Text Message
     * @param topicName - Topic Name
     * @param text - Text message
     * @param isPersistentConnection - true if connection should be open all the time other wise false
     */
    public static void sendAQTextMessage(String topicName, String text, boolean isPersistentConnection) {
        sendAQTextMessage(topicName, _TTL, text, isPersistentConnection);
    }

    /**
     * Method to send Text Message
     * @param topicName - Topic Name
     * @param ttl - TTL
     * @param text - Text message
     */
    public static void sendAQTextMessage(String topicName, long ttl, String text) {
        sendAQTextMessage(topicName, ttl, text, false );
    }
   
    /**
     * Method to send Text Message
     * @param topicName - Topic Name
     * @param ttl - TTL
     * @param text - Text message
     * @param isPersistentConnection - true if connection should be open all the time other wise false 
     */
    public static void sendAQTextMessage(String topicName, long ttl, String text, boolean isPersistentConnection) {
      if (!JMSAdminUtil.isActiveMQEnabled()) { 
          SendJMSMsgToTibco.sendAQTextMessage(topicName, ttl, text, isPersistentConnection);
          return;
      }

      if (isPersistentConnection) {
            sendMessageonPersistentConn(topicName, ttl, text, null);
      } else {
            sendMessage(topicName, ttl, text, null);
      }
    }

    /**
     * Private send message to send Active MQ message
     * @param topicName - Topic Name
     * @param ttl - TTL
     * @param text - Text Message
     * @param object - Object Message
     */
    private static void sendMessage(String topicName, long ttl,  String text,WMJMSObjectMessage object) {
        TopicConnection connection = null;
        TopicSession session = null;
        long startTime = System.currentTimeMillis();
        try {
            TopicConnectionFactory tcf = ActiveMQSingleTonFactory.getInstance().getTopicConnectionFactory(activeMQUser, activeMQPassword, activeMQURL);
            _connection = tcf.createTopicConnection();
            connection.start();
            session = connection.createTopicSession(_isTransacted, Session.AUTO_ACKNOWLEDGE);

            Topic destination = session.createTopic(topicName);        
            TopicPublisher publisher = session.createPublisher(destination);
            
            Message message =  null;
            if (text != null) {
                message =  session.createTextMessage(text);
                logger.log(Level.WARNING, "Sending Text Message : " + text + " Listener[" + topicName + "]");
            } else if (object != null) {
                message = session.createObjectMessage(object);
                logger.log(Level.WARNING, "Sending Object Message : " + object.toString() + ":" + object.getMsgType() + ":" + object.getOrigin() + ":" + object.getTarget() + " Listener[" + topicName + "]");
            }

            publisher.setDeliveryMode(DeliveryMode.PERSISTENT);
            publisher.setTimeToLive(ttl);

            publisher.send(message);
            session.commit();
            publisher.close();
        } catch (Exception exp) {
            try { session.rollback(); } catch (Exception e) {;}
            exp.printStackTrace();
        } finally {
            try {
                session.close();
                connection.stop();
                connection.close();
            } catch (Exception ignore) {;}
        }
        logger.log(Level.WARNING, "Sending Message took : " + ( System.currentTimeMillis() - startTime) + " elapsed" );
    }

    /**
     * Private send message to send Active MQ message
     * @param topicName - Topic Name
     * @param ttl - TTL
     * @param text - Text Message
     * @param object - Object Message
     */
    private static void sendMessageonPersistentConn(String topicName, long ttl,  String text,WMJMSObjectMessage object) {
        long startTime = System.currentTimeMillis();
        try {
            checkNcreateConnection(false);
            Topic destination = _session.createTopic(topicName);        
            TopicPublisher publisher = _session.createPublisher(destination);
            
            Message message =  null;
            if (text != null) {
                message =  _session.createTextMessage(text);
                logger.log(Level.WARNING, "Sending Text Message : " + text + " Listener[" + topicName + "]");
            } else if (object != null) {
                message = _session.createObjectMessage(object);
                logger.log(Level.WARNING, "Sending Object Message : " + object.toString() + ":" + object.getMsgType() + ":" + object.getOrigin() + ":" + object.getTarget() + " Listener[" + topicName + "]");
            }

            publisher.setDeliveryMode(DeliveryMode.PERSISTENT);
            publisher.setTimeToLive(ttl);

            publisher.send(message);
            _session.commit();
            publisher.close();
        } catch (Exception exp) {
            try { _session.rollback(); } catch (Exception e) {;}
            exp.printStackTrace();
        } 
        logger.log(Level.WARNING, "Sending Message took : " + ( System.currentTimeMillis() - startTime) + " elapsed" );
    }

    /**
     * Method to create persistent connection
     * @throws Exception  - Exception
     */
    private static void checkNcreateConnection(boolean shouldReconnect) throws Exception {
        if (!JMSAdminUtil.isActiveMQEnabled()) { 
            return;
        }
        synchronized (gate) {
        //if recreate connection -- true then close prev and create new one
        if (shouldReconnect) {
            logger.log(Level.WARNING, "Creating new persistent connections to the Active MQ " +  _connection );
            try {
            if (_session != null) {
                _session.close(); 
            }
            if (_connection != null) {
                _connection.stop();
                _connection.close();
            }
            } catch (Exception exp) {
                exp.printStackTrace();
                _connection.close();
            }
            _session = null;
            _connection = null;
        }//should reconnect

        try {
        if (_connection == null) {
          TopicConnectionFactory tcf = ActiveMQSingleTonFactory.getInstance().getTopicConnectionFactory(activeMQUser, activeMQPassword, activeMQURL);
          _connection = tcf.createTopicConnection();
          _connection.start();
          _session = _connection.createTopicSession(_isTransacted, Session.AUTO_ACKNOWLEDGE);
        } else {
            try {
            _connection.getMetaData().getJMSMajorVersion();
            } catch (Exception exp) {
                //looks like connection is broken, so create new one
                 logger.log(Level.WARNING, "Topic connection not valid...creating new connection" );
                exp.printStackTrace();
                try {
                    _session.close();
                    _connection.stop();
                    _connection.close();
                } catch (Exception ignore) {;}

                  TopicConnectionFactory tcf = ActiveMQSingleTonFactory.getInstance().getTopicConnectionFactory(activeMQUser, activeMQPassword, activeMQURL);
                  _connection = tcf.createTopicConnection();
                  _connection.start();
                  _session = _connection.createTopicSession(_isTransacted, Session.AUTO_ACKNOWLEDGE);
            }
        }//else
        } catch (Exception exp) {
        exp.printStackTrace();}
        }//sync
    }
}
