package com.wm.weblib.jms;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import javax.jms.TopicConnectionFactory;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;
  
import com.wm.corelib.config.AppConfig;

public class ActiveMQSingleTonFactory {
    //private TopicConnectionFactory _tcf;
    private static ActiveMQSingleTonFactory _instance;
    //private static String _url    = AppConfig.getInstance().getProperty("PROP_JMS_ACTIVEMQ_URL");
    //private static String _user   = AppConfig.getInstance().getProperty("PROP_JMS_ACTIVEMQ_USER");
    //private static String _password = AppConfig.getInstance().getProperty("PROP_JMS_ACTIVEMQ_PASSWORD");
    private static final ConcurrentMap<String, TopicConnectionFactory> _map = new ConcurrentHashMap<String,TopicConnectionFactory>();
    /**
     * Private Constructor
     * @throws Exception -- Exception
     */
    private ActiveMQSingleTonFactory() throws Exception {
    }

    /**
     * Singleton class
     * @return -- Instance ActiveMQSingleTonFactory
     */
    public static synchronized ActiveMQSingleTonFactory getInstance() throws Exception {
        if (_instance == null) {
            _instance = new ActiveMQSingleTonFactory();
        }

        return _instance;
    }    

     /**
     * Return TopicConnectionFactory for Active MQ
     * @param user - User
     * @param password - Password
     * @param url - URL
     * @return - TopicConnectionFactory
     * @throws Exception - Exception
     */
    public synchronized TopicConnectionFactory getTopicConnectionFactory(String user, String password, String url) throws Exception {
        if (!_map.containsKey(url)) {
            if (url == null || url.trim().length() == 0) 
                throw new Exception("Active MQ URL can not be null");
    
            if (user == null || user.trim().length() == 0)
                user = ActiveMQConnection.DEFAULT_USER;
                
            if (password == null || password.trim().length() == 0)
                password = ActiveMQConnection.DEFAULT_PASSWORD;
            
            TopicConnectionFactory _tcf = new ActiveMQConnectionFactory(user,password, url);
            _map.put(url, _tcf); 
        }
        return _map.get(url);
    }    
}
