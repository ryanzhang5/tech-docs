package com.wm.weblib.jms;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;

import com.wm.corelib.config.AppConfig;

public class SendJMSMsgToTibco {
    private static final boolean _isTransacted = true;
    private static long _TTL = 3600000;
    private static final Logger logger = Logger.getLogger(SendJMSMsgToTibco.class.getName());
    private static final String tibcoURL    = AppConfig.getInstance().getProperty("PROP_JMS_TIBCO_SEND_URL");
    private static final String tibcoUser   = AppConfig.getInstance().getProperty("PROP_JMS_TIBCO_USER");
    private static final String tibcoPassword = AppConfig.getInstance().getProperty("PROP_JMS_TIBCO_PASSWORD");
    private static final String DELIM = "+";
    private static final Map<String,TibcoPersistentConnection> connectionMap = new HashMap<String,TibcoPersistentConnection>();
    private static final List<String> urlList= new ArrayList<String>();
    private static boolean isConnectionCreated = false;
    
    /**
     * Method to send Object Message
     * @param topicName - Topic Name
     * @param object - Object Message
     */
    public static void sendAQObjectMessage(String topicName, WMJMSObjectMessage object) {
        sendAQObjectMessage(topicName, object, false);
    }
    
    /**
     * Method to send Object Message
     * @param topicName - Topic Name
     * @param object - Object Message
     * @param isPersistentConnection - true if connection should be open all the time other wise false
     */
    public static void sendAQObjectMessage(String topicName, WMJMSObjectMessage object, boolean isPersistentConnection) {
        sendAQObjectMessage(topicName, _TTL, object, isPersistentConnection);
    }

    /**
     * Method to send Object Message
     * @param topicName - Topic/Queue Name
     * @param ttl -- TTL
     * @param object - Object Message
     */
    public static void sendAQObjectMessage(String topicName, long ttl, WMJMSObjectMessage object) {
        sendAQObjectMessage(topicName, ttl, object, false);
    }

    /**
     * Method to send Object Message
     * @param topicName - Topic Name
     * @param ttl -- TTL
     * @param object - Object Message
     * @param isPersistentConnection - true if connection should be open all the time other wise false
     */
    public static void sendAQObjectMessage(String topicName, long ttl, WMJMSObjectMessage object, boolean isPersistentConnection) {
      if (isPersistentConnection) {
            sendMessageonPersistentConn(topicName, ttl, null, object);
      } else { 
            sendMessage(topicName, ttl, null, object);
      }
    }

/*************************************************************************/

    /**
     * Method to send Text Message
     * @param topicName - Topic Name
     * @param text - Text message
     */
    public static void sendAQTextMessage(String topicName, String text) {
        sendAQTextMessage(topicName, text, false);
    }

    /**
     * Method to send Text Message
     * @param topicName - Topic Name
     * @param text - Text message
     * @param isPersistentConnection - true if connection should be open all the time other wise false
     */
    public static void sendAQTextMessage(String topicName, String text, boolean isPersistentConnection) {
        sendAQTextMessage(topicName, _TTL, text, isPersistentConnection);
    }

    /**
     * Method to send Text Message
     * @param topicName - Topic Name
     * @param ttl - TTL
     * @param text - Text message
     */
    public static void sendAQTextMessage(String topicName, long ttl, String text) {
        sendAQTextMessage(topicName, ttl, text, false );
    }
   
    /**
     * Method to send Text Message
     * @param topicName - Topic Name
     * @param ttl - TTL
     * @param text - Text message
     * @param isPersistentConnection - true if connection should be open all the time other wise false 
     */
    public static void sendAQTextMessage(String topicName, long ttl, String text, boolean isPersistentConnection) {
      if (isPersistentConnection) {
            sendMessageonPersistentConn(topicName, ttl, text, null);
      } else {
            sendMessage(topicName, ttl, text, null);
      }
    }

    /**
     * Private send message to TIBCO 
     * @param topicName - Topic Name
     * @param ttl - TTL
     * @param text - Text Message
     * @param object - Object Message
     */
    private static void sendMessage(String topicName, long ttl,  String text,WMJMSObjectMessage object) {
        TopicConnection connection = null;
        TopicSession session = null;
        long startTime = System.currentTimeMillis();
        for (String tURL : urlList) {
          try {
              TopicConnectionFactory tcf = TibcoSingletonFactory.getInstance().getTopicConnectionFactory(tibcoUser, tibcoPassword, tURL);
              connection = tcf.createTopicConnection(tibcoUser, tibcoPassword);
              connection.start();
              session = connection.createTopicSession(_isTransacted, Session.AUTO_ACKNOWLEDGE);
  
              Topic destination = session.createTopic(topicName);        
              TopicPublisher publisher = session.createPublisher(destination);
              
              Message message =  null;
              if (text != null) {
                  message =  session.createTextMessage(text);
                  logger.log(Level.WARNING, "Sending Text Message : " + text + " Listener[" + topicName + "]");
              } else if (object != null) {
                  message = session.createObjectMessage(object);
                  logger.log(Level.WARNING, "Sending Object Message : " + object.toString() + ":" + object.getMsgType() + ":" + object.getOrigin() + ":" + object.getTarget() + " Listener[" + topicName + "]");
              }
  
              publisher.setDeliveryMode(DeliveryMode.PERSISTENT);
              publisher.setTimeToLive(ttl);
  
              publisher.send(message);
              session.commit();
              publisher.close();
            
          } catch (Exception exp) {
              try { session.rollback(); } catch (Exception e) {;}
              exp.printStackTrace();
          } finally {
              try {
                if (session != null) {
                  session.close();
                }
                if (connection != null) {
                  connection.stop();
                  connection.close();
                }
              } catch (Exception e) {
                  logger.warning("Exception while closing session/connection " + e.getMessage() );
                  e.printStackTrace();
                }
          }
        }//for
        logger.log(Level.WARNING, "Sending Message took : " + ( System.currentTimeMillis() - startTime) + " elapsed" );
    }

    /**
     * Private send message to send Active MQ message
     * @param topicName - Topic Name
     * @param ttl - TTL
     * @param text - Text Message
     * @param object - Object Message
     */
    private static void sendMessageonPersistentConn(String topicName, long ttl,  String text,WMJMSObjectMessage object) {
        long startTime = System.currentTimeMillis();
        TopicSession session = null;
        createConnection();
        for (String tURL : urlList) {
          try {
              TibcoPersistentConnection persistentConn = connectionMap.get(tURL);
              Connection conn = persistentConn.getConnection();
              
              session = ((TopicConnection)conn).createTopicSession(_isTransacted, Session.AUTO_ACKNOWLEDGE);
              
              Topic destination = session.createTopic(topicName);        
              TopicPublisher publisher = session.createPublisher(destination);
              
              Message message =  null;
              if (text != null) {
                  message =  session.createTextMessage(text);
                  logger.log(Level.WARNING, "Sending Text Message : " + text + " Listener[" + topicName + "]");
              } else if (object != null) {
                  message = session.createObjectMessage(object);
                  logger.log(Level.WARNING, "Sending Object Message : " + object.toString() + ":" + object.getMsgType() + ":" + object.getOrigin() + ":" + object.getTarget() + " Listener[" + topicName + "]");
              }
  
              publisher.setDeliveryMode(DeliveryMode.PERSISTENT);
              publisher.setTimeToLive(ttl);
  
              publisher.send(message);
              session.commit();
              publisher.close();
            } catch (javax.jms.IllegalStateException ise) {
                ise.printStackTrace();
                try {
                  if (session != null) {
                      session.recover();
                  }
                } catch (Exception e) {
                    e.printStackTrace();
                  }
            } catch (Exception exp) {
              try { 
                if (session != null) {
                  session.rollback(); 
                }
              } catch (Exception e) {;}
                exp.printStackTrace();
            } finally {
              try {
                if (session != null) {
                  session.close();
                }
              } catch (Exception ignore) {;}
            
            }
        }//for
        logger.log(Level.WARNING, "TIBCO send message took : " + ( System.currentTimeMillis() - startTime) + " elapsed" );
    }


    /**
     * 
     */
    private static synchronized void createConnection() {
      if (isConnectionCreated || tibcoURL == null || tibcoURL.isEmpty()) {
          return;
        }
        StringTokenizer st = new StringTokenizer(tibcoURL, DELIM);
        while (st.hasMoreTokens()) {
          try {
            String tURL = st.nextToken();
            
            if (tURL != null && !tURL.isEmpty()  && !connectionMap.containsKey(tURL)) {
              TibcoPersistentConnection tpc = new TibcoPersistentConnection(tibcoUser,tibcoPassword, tURL);
              
              connectionMap.put(tURL, tpc);
              urlList.add(tURL);

            }//if
          } catch (Exception exp) {
              logger.warning("Exception occured while creating TIBCO connection");
              exp.printStackTrace();
          }
        }//while
        
        isConnectionCreated = true;
      }
}
