/*
 * Created on Aug 7, 2005
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package com.wm.weblib.jms;

import java.util.Date;
  
import com.wm.corelib.config.AppConfig;

public class WMJMSListenerStatus  {

    private String listenerName;
    private boolean lastConnectionStatus = false;
    private long lastStatusChangedPoint = 0;
    private long initializePoint = 0;
    private long offlineBeginPoint = 0;
    private long offlineEndPoint = 0;
    private long onlineBeginPoint = 0;
    private long onlineEndPoint = 0;
    private long createPoint = 0;

	public WMJMSListenerStatus(String name){
    	this.listenerName = name;
    	this.createPoint = System.currentTimeMillis();
    }

    public String getListenerName() {
		return listenerName;
	}

	public boolean getLastConnectionStatus() {
		return lastConnectionStatus;
	}

	public void setLastConnectionStatus(boolean lastConnectionStatus) {
		this.lastConnectionStatus = lastConnectionStatus;
	}

	public long getLastStatusChangedPoint() {
		return lastStatusChangedPoint;
	}

	public void setLastStatusChangedPoint(long lastStatusChangedPoint) {
		this.lastStatusChangedPoint = lastStatusChangedPoint;
	}

	public long getInitializePoint() {
		return initializePoint;
	}

	public void setInitializePoint(long initializePoint) {
		this.initializePoint = initializePoint;
	}

	public long getOfflineBeginPoint() {
		return offlineBeginPoint;
	}

	public void setOfflineBeginPoint(long offlineBeginPoint) {
		this.offlineBeginPoint = offlineBeginPoint;
	}

	public long getOfflineEndPoint() {
		return offlineEndPoint;
	}

	public void setOfflineEndPoint(long offlineEndPoint) {
		this.offlineEndPoint = offlineEndPoint;
	}

	public long getOnlineBeginPoint() {
		return onlineBeginPoint;
	}

	public void setOnlineBeginPoint(long onlineBeginPoint) {
		this.onlineBeginPoint = onlineBeginPoint;
	}

	public long getOnlineEndPoint() {
		return onlineEndPoint;
	}

	public void setOnlineEndPoint(long onlineEndPoint) {
		this.onlineEndPoint = onlineEndPoint;
	}

	public long getCreatePoint() {
		return createPoint;
	}



    public String toString() {
        String ls = AppConfig.getInstance().getProperty("line.separator");
        StringBuffer s = new StringBuffer(" JMS Listener STATUS "+ listenerName + " : { isConnected: "+ lastConnectionStatus);
        s.append(ls);
        s.append("    created       : "+ new Date(createPoint)
        		+ "   isInitialized : "+ ( (initializePoint==0) ? "Non":""+new Date(initializePoint) )
        		+ "   lastStatusChanged: "+ ( (lastStatusChangedPoint==0) ? "Non":""+new Date(lastStatusChangedPoint) ) );
        s.append(ls);
        s.append("    online period : "
        		+ ( (onlineBeginPoint==0) ? "Non":""+new Date(onlineBeginPoint) )+" -- "
        		+ ( (onlineEndPoint==0) ? "Non":""+new Date(onlineEndPoint) )
        		);
        s.append(ls);
        s.append("    offline period: "
        		+ ( (offlineBeginPoint==0) ? "Non":""+new Date(offlineBeginPoint) )+" -- "
        		+ ( (offlineEndPoint==0) ? "Non":""+new Date(offlineEndPoint) )
        		);
        s.append(ls);
        s.append("}");

        return s.toString();
    }



}
