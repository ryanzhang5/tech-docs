package com.wm.weblib.jms;

/**
 * MessageType Sigleton - allows definition of message types
 * used for server communication
 */
public class WMMessageType {

	/**
     * The type of message this thing is.
     */
    private String _messageType;
    
    /**
     * private constructor - enforces Singleton
     * @param msgType type of the message
     */
    private WMMessageType(String msgType) {
		_messageType = msgType;
    }

    public boolean equals(WMMessageType aType) {
	if (aType != null && _messageType != null) {

	    String typeString = aType.toString();
	    if (_messageType.equals(typeString)) {
		return true;
	    }
	}

	return false;
    }

    public String toString() {
    	return _messageType;
    }    
	
    /** Ping Message */
    public static final WMMessageType MSG_TYPE_PING = new WMMessageType("ping");
	
    /** Item update / Availability Message */							
    public static final WMMessageType MSG_TYPE_ITEM_UPDATE = new WMMessageType("item_upd");
    
    public static final WMMessageType MSG_TYPE_STORE_UPDATE = new WMMessageType("store_upd");
	
    /** Clear cache status Messages */						
    public static final WMMessageType MSG_TYPE_CLEAR_CACHE_DYNAMIC = 
	new WMMessageType("clear_cache_dynamic");


    public static final WMMessageType MSG_TYPE_CLEAR_CACHE_CONTENT = 
	new WMMessageType("clear_cache_content");
    
    public static final WMMessageType MSG_TYPE_CLEAR_CACHE_CONTENT_L2 = 
    	new WMMessageType("clear_cache_content_l2");

    public static final WMMessageType MSG_TYPE_CLEAR_CACHE_ITEM = 
	new WMMessageType("clear_cache_item");

    public static final WMMessageType MSG_TYPE_CLEAR_CACHE_ITEM_L2 =
    	new WMMessageType("clear_cache_item_l2");

    public static final WMMessageType MSG_TYPE_CLEAR_CACHE_CAT = 
	new WMMessageType("clear_cache_cat");

    public static final WMMessageType MSG_TYPE_CLEAR_CACHE_CAT_L2 = 
    	new WMMessageType("clear_cache_cat_l2");

    public static final WMMessageType MSG_TYPE_CLEAR_CACHE_SPECIFIC = 
	new WMMessageType("clear_cache_specific");

    public static final WMMessageType MSG_TYPE_CLEAR_CACHE_SPECIFIC_L2 = 
    	new WMMessageType("clear_cache_specific_l2");

  public static final WMMessageType MSG_TYPE_REFRESH_CACHE_VERSION = 
    new WMMessageType("refresh_cache_version");
    
    /** Change cache status Message */							
    public static final WMMessageType MSG_TYPE_CHANGE_CACHE_STATUS = 
	new WMMessageType("change_cache_status");
    

    /** Change config Message */
    public static final WMMessageType MSG_TYPE_CHANGE_CONFIG = 
	new WMMessageType("change_config");


    /** Start graceful shutdown message */							
    public static final WMMessageType MSG_TYPE_SET_GRACEFUL_SHUTDOWN = 
	new WMMessageType("start_graceful_shutdown");


    /** Cancel graceful shutdown message */
    public static final WMMessageType MSG_TYPE_CLEAR_GRACEFUL_SHUTDOWN = 
	new WMMessageType("cancel_graceful_shutdown");

    
    public static final WMMessageType MSG_TYPE_WIRELESS_CARRIER_XML_MSG =
	new WMMessageType("WirelessCarrierXmlMessage");
    
    
    public static final WMMessageType MSG_TYPE_THIRD_PARTY_SERVICE_UPDATE = 
	new WMMessageType("ThirdPartyStatusMessage");
    
    
    public static final WMMessageType MSG_TYPE_URI_REDIRECT_MAP = 
	new WMMessageType("SetURIRedirectionMapMessage");

    
    public static final WMMessageType MSG_TYPE_STORE_INV = 
	new WMMessageType("item_store_upd");

    public static final WMMessageType MSG_TYPE_CLEAR_PA_CACHE_URL = 
    	new WMMessageType("clear_pa_cache_url");

    public static final WMMessageType MSG_TYPE_PING_OBJMSG = new WMMessageType("pingobjmsg");
    
    public static final WMMessageType MSG_TYPE_FARM_ITEM_UPD_OBJ = new WMMessageType("farm_item_upd_obj");
    
    public static final WMMessageType MSG_TYPE_SET_GRACEFUL_MP_SHUTDOWN = 
        new WMMessageType("start_graceful_mp_shutdown");

    public static final WMMessageType MSG_TYPE_CLEAR_GRACEFUL_MP_SHUTDOWN = 
        new WMMessageType("cancel_graceful_mp_shutdown");


    public static final WMMessageType MSG_TYPE_CLEAR_CACHE_BY_KEY = 
        new WMMessageType("clear_cache_by_key");
    
    public static final WMMessageType MSG_TYPE_CLEAR_CACHE_BY_KEY_L1 = 
        new WMMessageType("clear_cache_by_key_l1");

   public static final WMMessageType MSG_TYPE_L1_CLEAR_FUSION_CAT_BY_ID =
        new WMMessageType("l1_clear_fusion_cat_by_id");

    public static final WMMessageType MSG_TYPE_L2_CLEAR_FUSION_CAT_BY_ID =
        new WMMessageType("l2_clear_fusion_cat_by_id");
    

    // MESSAGES BUNDLED WITH WM_JMS MODULE

    /** DB Pool message to lock pools */
    public static final WMMessageType MSG_TYPE_CLEAR_DB_POOL =
	    new WMMessageType("clear_db_pool");

    /** DB Pool message to unlock pools */
    public static final WMMessageType MSG_TYPE_UNLOCK_DB_POOL =
	    new WMMessageType("unlock_db_pool");

    /** dbpool connection recycle message */
    public static final WMMessageType MSG_TYPE_DBPOOL_CONNECTION_RECYCLE =
        new WMMessageType("dbpool_connection_recycle");

    /** dbpool change max connections */
    public static final WMMessageType MSG_TYPE_SET_CONNECTION_POOL_INFO =
    	new WMMessageType("set_connection_pool_info");

    /** dbpool pool -> url_key mappings */
    public static final WMMessageType MSG_TYPE_DBPOOL_URL_KEYS =
    	new WMMessageType("dbpool_url_keys");

    /** Simple Access*/
    public static final WMMessageType MSG_TYPE_REVOKE_SIMPLE_ACCESS =
    	new WMMessageType("revoke_simple_access");
    	
    /** Messages for config management **/
    public static final WMMessageType MSG_TYPE_CONFIG_MGMT_NOTIFICATION=
        new WMMessageType("config_mgmt_notification");

    public static final WMMessageType MSG_TYPE_CONFIG_MGMT_ACK=
        new WMMessageType("config_mgmt_ack");
    
    public static final WMMessageType MSG_TYPE_BMM_CONFIGURATION = 
    	new WMMessageType("bmm_configuration");
}
