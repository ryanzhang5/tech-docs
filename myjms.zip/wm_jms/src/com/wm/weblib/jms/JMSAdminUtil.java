package com.wm.weblib.jms;

import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.sql.SQLException;

import java.util.logging.Logger;
import java.util.logging.Level;
import java.util.HashMap;

import com.wm.sql.DataAccess;
  
import com.wm.corelib.config.AppConfig;

public class JMSAdminUtil {
    private static Logger _logger = Logger.getLogger(JMSAdminUtil.class.getName());
    private static String _subscriberName = null;
    private static final String _getMsgType = "{call wiq_aq_pkg.get_q_msg_types(?)}";
    private static final String _getMsgTypeParameter = "{call wiq_aq_pkg.get_q_msg_type_params(?,?,?)}";
    private static final String _setMsgParameter = "{call wiq_aq_pkg.update_q_msg_parameter(?,?,?,?)}";
    private static final String _AQEnabled = AppConfig.getInstance().getProperty("PROP_JMS_IS_AQ_ENABLED");
    private static final String _isACTMQEnabled = AppConfig.getInstance().getProperty("PROP_JMS_IS_ACTMQ_ENABLED", "true");
    public static void getMsgType() {
        Connection con = null;
        CallableStatement stmt = null;
        ResultSet rs = null;

        try {
			
	    _logger.fine("get message queue info.");
        	
            con = DataAccess.getInstance().getConnection(SendJMSMessage.DBPOOL_ALIAS);            
            stmt = con.prepareCall(_getMsgType);			
	    stmt.registerOutParameter(1, oracle.jdbc.OracleTypes.CURSOR);

	    stmt.execute();
	    rs = (ResultSet)stmt.getObject(1);
	    while (rs.next()) {
		String s1 = rs.getString(1);
		String s2 = rs.getString(2);
		String s3 = rs.getString(3);
		String s4 = rs.getString(4);

		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);
		System.out.println(s4);
	    }

	    rs.close();
	    stmt.close();
        } catch (SQLException e) {            
	    e.printStackTrace();
        } finally {
	    try {
		con.close();
	    } catch (Exception e1) {
		e1.printStackTrace();
	    }
        }
    }



    public static HashMap<String, String> getMsgTypeParameter(String qName, String msgType) {
        Connection con = null;
        CallableStatement stmt = null;
        ResultSet rs = null;

	HashMap<String, String> aMap = new HashMap<String, String>();

        try {
			
	    _logger.fine("get message type parameter info.");
        	
            con = DataAccess.getInstance().getConnection(SendJMSMessage.DBPOOL_ALIAS);
            stmt = con.prepareCall(_getMsgTypeParameter);			
	    stmt.setString(1, qName);
	    stmt.setString(2, msgType);
	    stmt.registerOutParameter(3, oracle.jdbc.OracleTypes.CURSOR);

	    stmt.execute();

	    rs = (ResultSet)stmt.getObject(3);
	    
	    while (rs.next()) {
		String s1 = rs.getString(1);
		String s2 = rs.getString(2);
		String s3 = rs.getString(3);
		String s4 = rs.getString(4);

		aMap.put(s3, s4);
	    }

	    rs.close();
	    stmt.close();
        } catch (SQLException e) {            
	    e.printStackTrace();
        } finally {
	    try {
		con.close();
            } catch (Exception e1) {
                e1.printStackTrace();
	    }
        }

	return aMap;
    }


    public static void setQueueParameter(String qName,
					 String msgType,
					 String pName,
					 String pValue) {
        Connection con = null;
        CallableStatement stmt = null;
        ResultSet rs = null;

	try {
			
	    _logger.fine("set message type parameter info.");
        	
            con = DataAccess.getInstance().getConnection(SendJMSMessage.DBPOOL_ALIAS);
            stmt = con.prepareCall(_setMsgParameter);			
	    stmt.setString(1, qName);
	    stmt.setString(2, msgType);
	    stmt.setString(3, pName);
	    stmt.setString(4, pValue);

	    stmt.execute();
	    stmt.close();
        } catch (SQLException e) {            
	    e.printStackTrace();
        } finally {
	    try {
		con.close();
            } catch (Exception e1) {
                e1.printStackTrace();
	    }
        }
    }

    public static void setSubscriberName(String subName) {
        if (subName != null && subName.trim().length() > 0)
            _subscriberName = subName;
    }
    
    public static String getSubscriberName() {
        if (_subscriberName == null) {
            // first, grab the container level prefix
            String subscriberName = AppConfig.getNamingPrefix();
            // then, add on webapp level suffix (if available)
            String childAppName = AppConfig.getInstance().getDerivedPath();
            if (childAppName != null && !"".equals(childAppName)) {
                subscriberName += "_" + childAppName;
            }
            _subscriberName = subscriberName;
        }

        return _subscriberName;

    }

    public static final boolean isOracleAQEnabled() {
        boolean isAQEnabled = true;
        if(_AQEnabled != null && _AQEnabled.trim().equalsIgnoreCase("false") ){
            isAQEnabled = false;
        }
        return  isAQEnabled;
    }

  public static final boolean isActiveMQEnabled() {
      boolean isACTMQEnabled = false;
      if(_isACTMQEnabled != null && _isACTMQEnabled.trim().equalsIgnoreCase("true") ){
          isACTMQEnabled = true;
      }
      return  isACTMQEnabled;
  }

    public static void main(String[] argvs) {

	//getMsgType();
	HashMap map = getMsgTypeParameter("AQ.WEBAPP_NONADMIN_Q", "ITEM_AVAILABILITY");
	System.out.println(map.toString());

	//setQueueParameter("AQ.WEBAPP_NONADMIN_Q", "ITEM_AVAILABILITY", "MESSAGE_BATCH_SIZE", "20");
    }
}
