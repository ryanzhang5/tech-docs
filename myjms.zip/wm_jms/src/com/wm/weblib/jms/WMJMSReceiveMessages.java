/*
 * Created on Aug 7, 2005
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package com.wm.weblib.jms;

import java.util.Date;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.lang.reflect.Method;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;
import javax.jms.TopicConnection;

import com.wm.corelib.jmxadmin.JmxUtil;

import java.util.ArrayList;

import javax.jms.ObjectMessage;
  
import com.wm.corelib.config.AppConfig;


public class WMJMSReceiveMessages extends Thread {
    private Date _lastMessageReceived = null;
    private int _messageCount = 0;
    private int _batchCount = 0;
    private int _numberOfConnectAttempts = 0;
    /** Static class logger */
    private static Logger _logger = Logger.getLogger(WMJMSReceiveMessages.class.getName());
    private TopicSubscriber _subscriber;
    private TopicSession _session = null;
    private Vector _handlers = new Vector();
    private String _name = null;
    private TopicConnection _tc;
    private String _aq_queue_name;
    private String _aq_schema;

    private MessageFactory _aFactory;
    private String _listenerName; //name is passed for reconnection purpose
    private boolean _msgThrottle = true;
    private String _msgThrottleConfig;
    private long _throttled_millis = 0;
    
    private JMSAdmin _JMSAdminMBean;

    WMJMSReceiveMessages(String listenerName,
			 WMJMSStartListener listener){

        super.setDaemon(true);
        
        this._subscriber = listener.getSubscriber();
        this._session = listener.getSession();
        this._name = listener.getListenerName();
        this._tc = listener.getConnection();
        this._aq_queue_name = listener.getAQQName();
        this._aq_schema = listener.getAQSchema();

        this._listenerName = listenerName;

        //the following is for message throttle config
        this._msgThrottleConfig = AppConfig.getInstance().getProperty("PROP_JMS_" + listenerName + "_Throttle");
        if (_msgThrottleConfig != null && "false".equals(_msgThrottleConfig.trim())) {
            _msgThrottle = false;
        }
        
        try {
            _throttled_millis =  Long.parseLong(AppConfig.getInstance().getProperty("PROP_JMS_THROTTLED_TIMEOUT"));
        } catch (Exception exp) {
            _throttled_millis = 2000;
        }
    }


    public String getReceiveMessageName(){
        return _name;
    }

    public String getAQQName(){
	return _aq_queue_name;
    }

    public String getAQSchema(){
	return _aq_schema;
    }

    public MessageFactory getMessageFactory() {
	return _aFactory;
    }

    /**
     * This method will be ran in separate thread.
     * It loops forever and retrieves messages from the queue.
     */
    public void run() {
        registerMBean();

        _numberOfConnectAttempts = 0; //reset number of consecutive connect attempts

        int numberOfErrors = 0;

        //loop unless number of consecutive errors = 3 and connection is not stopped
        while ((numberOfErrors <= 3) && isConnected()) {
            try {
                Message m = _subscriber.receive(); //blocks thread until message arrives
                numberOfErrors = 0; //reset number of consecutive errors

                if (m != null) {
                //moved here to reduce row locking
                _session.commit(); //confirm message reception

                List <WMMessage> listofMessage = new ArrayList<WMMessage>();
                
                if (m instanceof TextMessage) {
                    _logger.warning("Received message: " + ((TextMessage) m).getText()+ " Listener: " + _name);

		    //if theMT is null, the null exception will be caught and session will rollback
		    //what happen if it fails in the middle of processing batch message ???
		    //List <WMMessage> msgs = (List <WMMessage>) theMT.invoke((TextMessage)m);

		    listofMessage = _aFactory.parseJMSTextMessage((TextMessage)m);
                    
		} else if (m instanceof ObjectMessage && ((ObjectMessage)m).getObject() != null && ((ObjectMessage)m).getObject() instanceof WMJMSObjectMessage)  {
			
                     WMJMSObjectMessage objMessage = (WMJMSObjectMessage)((ObjectMessage)m).getObject();
                     try {
                     _logger.warning("Received object message: " + objMessage.getObjectMessage().toString() + "," +
                              objMessage.getMsgType() + ", origin=" + objMessage.getOrigin() + 
                              ",target=" + objMessage.getTarget() + " Listener: " + _name);
			} catch (Exception exp) {
				_logger.warning("Exception occured while printing the log statement, " + exp);
				exp.printStackTrace();
				}
                        listofMessage = _aFactory.parseJMSObjectMessage(objMessage);
                        
                } //else if

                 _batchCount++;
                 
                 for (WMMessage msg : listofMessage) {
                     _messageCount++;
                     _processMessage(msg);
                 }

		_lastMessageReceived = new Date();

                //after every 10 messages sleep for n milli seconds
                if ((_batchCount % 10) == 0) {
                    try {
                        //if it is not Throttled, don't sleep
                      if (_msgThrottle && _throttled_millis > 0)  {
                            Thread.sleep(_throttled_millis);
                    }
                    } catch (InterruptedException ignore) {; }
                }
            } //if m != null
            } catch (javax.jms.IllegalStateException ise) {
                ise.printStackTrace();
                try {
                  if (_session != null) {
                      _session.recover();
                  }
                } catch (Exception e) {
                    e.printStackTrace();
                  }
            } catch (Exception e) {
                // error happened, so try to rollback
                try {
                    _session.rollback();
                } catch (Exception e1) {
                    _logger.warning("Can not dequeue message, exception:" + e1);
                    e1.printStackTrace();
                }

                numberOfErrors++; //calculate number of consecutive errors

                e.printStackTrace();
                _logger.warning("Can not dequeue message, exception:" + e);
                if( e instanceof JMSException ) {

                    Exception linkedException = ((JMSException)e).getLinkedException();
                    if (linkedException != null) {
                        _logger.warning("Can not dequeue message. Linked exception:" + linkedException);
                        linkedException.printStackTrace();
                    }
                }
/*
                //wait for 30 seconds
                try {
                	if(isConnected()){
                		Thread.sleep(30 * 1000);
                	}
                } catch (InterruptedException ignore) {
                }
*/                
            }//catch
        } //while

        //if connection was interrupted because of error, try to reconnect
	//reconnection will be in seperate threads (WMJMSStartListener and WMJMSReceiveMessage)
	//the current thread will be terminated.

	//try only one time, otherwise too many threads will be created

	    System.err.println((new java.util.Date()).toString() + ": numberOfErrors: " + numberOfErrors
	 	       + " isConnect: " + isConnected() );

	    disconnect();

    }

    private void registerMBean() {
        unregisterMBean();
        try {
            _JMSAdminMBean = new JMSAdmin(_listenerName);
            JmxUtil.registerMBean("JMSAdmin:name="+_listenerName, _JMSAdminMBean, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void unregisterMBean() {
        try {
            if (_JMSAdminMBean != null) {
                _JMSAdminMBean.stopListener();
                _JMSAdminMBean = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            if (JmxUtil.isRegistered("JMSAdmin:name="+_listenerName)) {
                JmxUtil.unRegisterMBean("JMSAdmin:name="+_listenerName);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * Passes the message through the registered handler chain.
     *
     * Checks are made to see:
     * 1. If the message is targetted to this server
     * 2. If the message is from trusted source
     *
     * If the target is not to this server pool, message is ignored.
     * Alternatively messages can be seperated on topics
     *
     * Un-trusted messages are ignored and an alert is sent
     *
     * @param message WMMessage to be processed
     */
    private void _processMessage(WMMessage message) {

        try {
            Vector h = _handlers;
            WMMessageHandler handler = null;
            WMMessageHandlerStatus status = null;

            //
            // Note: This is not implemented in a threaded way, so one
            // of the handlers could block the processing of the next
            // handlers in the chain.  We decided to implement it in
            // the simplest possible way first, since we only envision
            // one handler being implemted immediately.
            //
            // If people think it's necessary to make the handling
            // multithreaded, then we can go ahead and do that.
            //

            String msgString = message.toString();
            if (_logger.isLoggable(Level.FINE))
                _logger.fine("Received Message [" + msgString + "] Message Type :" + message.getClass()+ " Listener: " + _name);
            for (int i = 0; i < h.size(); i++) {

                handler = (WMMessageHandler) h.elementAt(i);


                if ( !handler.canHandle(message)) {
                    continue;
                }

                if (!handler.isTargetted(message)) {
                    if (_logger.isLoggable(Level.FINE))
                        _logger.fine("Message [" + msgString + "] is not targetted for this server. Skipping!" + " Listener: " + _name);
                    continue;
                }

                if (!handler.isTrusted(message)) {
                    if (_logger.isLoggable(Level.WARNING))
                        _logger.warning("Message [" + msgString + "] is not trusted. Skipping!" + " Listener: " + _name);
                    continue;
                }

                // handle message
                status = handler.handleMessage(message);

                if ( (status != null) &&
                     (status.getCode() != WMMessageHandlerStatus.CODE_NOOP)) {
                    _logger.warning("_processMessage: status="+status.toString() + " Listener: " + _name);
                }
            }
        } catch (Exception exception) {
            _logger.log(Level.SEVERE, "Error processing message", exception);
        }
    }
    /**
     * Checks if listener connected.
     */
    public boolean isConnected() {
        boolean isConn = true;
        if (_tc == null) {
            return false;
        }
        
        try {
            _tc.getMetaData().getJMSMajorVersion();
        } catch (Exception exp) { 
              _logger.warning("Unable to verify the connection " + exp.getMessage());
              exp.printStackTrace();
              isConn = false; 
        }
        return isConn;
    }

    @Override
    protected void finalize() throws Throwable {
        disconnect();
        super.finalize();
    }

    public void disconnect(){
        _tc = null;
        unregisterMBean();
    }

    public void addHandler(WMMessageHandler handler) {
        //
        // ???: Do we need to worry about adding the same handler more than once?
        // If we don't, we'll blindly call handlerMessage() on the same handler
        // with the same message.
        //
        _handlers.add(handler);
    }
    public void removeHandler(WMMessageHandler handler) {
        _handlers.remove(handler);
    }

    public Date getLastMessageReceived(){
	return _lastMessageReceived;
    }

    public int getMessageCount(){
	return _messageCount;
    }


    public int getBatchCount() {
	return _batchCount;
    }

    public synchronized String toString() {
        String ls = AppConfig.getInstance().getProperty("line.separator");
        StringBuffer s = new StringBuffer(getClass().getName() + " { ");
        s.append(ls);

        if (!isConnected()) {
            s.append("  Listener is not connected.");
            s.append(ls);
        } else {
            s.append(ls);
            s.append("  lastMessageReceived: ");
            s.append(_lastMessageReceived);
            s.append(ls);
            s.append("  messages received: ");
            s.append(_messageCount);
            s.append(ls);
        }

        s.append("  registered handlers: { ");

        for (int i = 0; i < _handlers.size(); i++) {
            if (i != 0) {
                s.append(",");
            }

            s.append(_handlers.elementAt(i).getClass().getName());
        }

        s.append(" }");
        s.append(ls);
        s.append("}");

        return s.toString();
    }

    public List getHandler() {
	return _handlers;
    }

    public void setMessageFactory(String factoryClassName,
				  String qName,
				  String qSchema) {

	if (factoryClassName == null) {
	    _logger.log(Level.SEVERE,"Unable to parse message, there is no factory class definition" + " Listener: " + _name);

	} else {

	    try {
		_aFactory = (MessageFactory)Class.forName(factoryClassName).newInstance();
		_aFactory.setQueueInfo(qName, qSchema);

	    } catch (ClassNotFoundException e) {
		e.printStackTrace();
		_logger.log(Level.SEVERE, "Unable to parse message, no parseJMSTextMessage method" + " Listener: " + _name);
	    } catch (InstantiationException e) {
		e.printStackTrace();
		_logger.log(Level.SEVERE, "Unable to instanticate the class " + " Listener:" + _name);
	    } catch (IllegalAccessException e) {
		e.printStackTrace();
		_logger.log(Level.SEVERE, "illegal access to the class " + " Listener:" + _name);
	    } catch (WMMessageException e) {
		e.printStackTrace();
		_logger.log(Level.SEVERE, "queue name is null for Listener: " + _name);
	    }
	}

    }


}
