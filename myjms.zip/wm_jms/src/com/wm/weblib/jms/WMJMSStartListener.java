/*
 * Created on Aug 7, 2005
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package com.wm.weblib.jms;

import java.util.Date;
import java.util.Vector;
import java.util.logging.Logger;

import javax.jms.Session;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;


public abstract class WMJMSStartListener extends Thread implements WMJMSConstants {
    /** Static class logger */
    private static Logger _logger = Logger.getLogger(WMJMSStartListener.class.getName());

    public abstract String getAQQName();

    public abstract String getAQSchema();

    public abstract String getListenerName();

    public abstract TopicSession getSession();

    public abstract TopicSubscriber getSubscriber();

    public abstract TopicConnection getConnection();

    public abstract  void JMSStop();

    public abstract  boolean isConnected();

    public final void run() {
    	JMSStart();
    }

    protected abstract void JMSStart();

}
