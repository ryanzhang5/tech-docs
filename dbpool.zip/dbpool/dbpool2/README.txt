After checking out the module, please run the following commands inside module home:

$ bin/subscribe

This will fetch the necessary dependencies, including the JDK, Perl and java libraries.

$ bin/ant

This will compile the java classes, run tests and create the jar file.
The general build output goes into subfolders under the "target" folder.
The final distribution output (JAR file) goes into the "dist" folder.

