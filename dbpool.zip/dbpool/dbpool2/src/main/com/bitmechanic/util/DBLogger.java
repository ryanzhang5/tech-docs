package com.bitmechanic.util;

import java.lang.System;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.ConsoleHandler;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

public class DBLogger {

    public static final Level OFF = Level.OFF;
    public static final Level SEVERE = Level.SEVERE;
    public static final Level WARNING = Level.WARNING;
    public static final Level INFO = Level.INFO;
    public static final Level ALL = Level.ALL;
    public static final Level CONFIG = Level.CONFIG;
    
    // Default timestamp format in 24 hr clock.
    private static final String defaultTimestampFormat = "yyyy-MM-dd HH:mm:ss:S - ";

    // Simple date format
    private static final SimpleDateFormat timestampFormatter = new SimpleDateFormat( defaultTimestampFormat );

    // Prefix to prepend to all log messages
    private String _prefix;

    // Postfix to append to all log messages
    private String _postfix = "\n";

    private final Logger _dbLogger = Logger.getAnonymousLogger();// Logger.getLogger(getClass().getName());
    
    private final Handler handler = new ConsoleHandler();

    //private final MemoryHandler mhandler = new MemoryHandler(handler, 20, Level.WARNING);
    private static DBLogger _instance = null;

  static {
      _instance = new DBLogger();  
  }
  
  private DBLogger() {
      handler.setFormatter(new LogFormatter());
      _dbLogger.addHandler(handler);
      _dbLogger.setLevel(Level.WARNING);
      _dbLogger.setUseParentHandlers(false);
  }
  
  public static DBLogger getInstance() {
    return _instance;
  }

  public final void setPrefix( String logPrefix )  {
    _prefix = logPrefix;
  }

  public final String getPrefix() {
    return _prefix;
  }

  public final void setPostfix( String logPostfix ) {
    _postfix = logPostfix;
  }

  public final String getPostfix() {
    return _postfix;
  }

  public final void log( Level level, String message ) {
    _dbLogger.log(level , message);
  }

  public final void log( Level level, String message, Throwable thrown) {
    _dbLogger.log(level, message, thrown);
  }

  public static String formatTimestamp( long msec ) {
    Date d = new Date( msec );
    return timestampFormatter.format( d ); 
  }

  public void setLevel(Level level)   {
    _dbLogger.setLevel(level);
  }

  public Level getLevel()   {
    return _dbLogger.getLevel();
  }
  
/*************************************************************************/
    class LogFormatter extends Formatter {
    
        //This method is called for every log records
        public String format(LogRecord rec) {

            StringBuffer sb = new StringBuffer();
            long date = System.currentTimeMillis();
            sb.append(formatTimestamp( date ) + 
              Thread.currentThread().getName() + ", " + Thread.currentThread().hashCode() + " -> " );
            if ( _prefix != null )
              sb.append( _prefix );

            sb.append( formatMessage(rec) ).append(_postfix);

            return sb.toString();
        }
        
        public String getHead(Handler h) {
            return "";
        }
            
        public String getTail(Handler h) {
            return "";
        }
    }
/*************************************************************************/
}