/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql;

import java.sql.SQLException;
import java.util.Properties;

/**
 * GenericPool - base interface for different kinds of Pools
 *
 * @author mkishore
 * @since 2.0.1
 */
public interface GenericPool<T extends GenericPooledObject> {
    /**
     * Allows the creator to configure the pool from a list of propwerties.
     *
     * @param props - list of properties
     */
    void configure(Properties props);

    /**
     * This method should be called after the configure() method - allows the implementations
     * to do some post configuration tasks. 
     */
    void initialize();

    /**
     * Returns the name of the pool - needs to be unique for a given pool-manager.
     *
     * @return the name of the pool
     */
    String getAlias();

    /**
     * Returns the connection pool manager that created this pool.
     *
     * @return the connection pool manager
     */
    ConnectionPoolManager getConnectionPoolManager();

    /**
     * Sets the connection pool manager that created this pool.
     *
     * @param connectionPoolManager the connection pool manager
     */
    void setConnectionPoolManager(ConnectionPoolManager connectionPoolManager);

    // GETTERS and SETTERS in the order they appear in config file

    /**
     * Returns the url for the pool - used in a pool specific way to create the object.
     *
     * @return the url for the pool
     */
    String getUrl();

    /**
     * Set the url for the pool - used in a pool specific way to create the object.
     *
     * @param url - the url for the pool
     */
    void setUrl(String url);

    /**
     * Returns the minimum number of objects that will be kept in the pool.
     *
     * @return the minimum number of objects that will be kept in the pool
     */
    int getMinSize();

    /**
     * Returns the minimum number of objects that will be kept in the pool.
     *
     * @param minSize - the minimum number of objects that will be kept in the pool
     */
    void setMinSize(int minSize);

    /**
     * Returns the maximum number of objects that will be kept in the pool. Any subsequent
     * requests to the checkout() method will need to wait (and possibly time out).
     *
     * @return the maximum number of objects that will be kept in the pool
     */
    int getMaxSize();

    /**
     * Returns the maximum number of objects that will be kept in the pool. Any subsequent
     * requests to the checkout() method will need to wait (and possibly time out).
     *
     * @param maxSize - the maximum number of objects that will be kept in the pool
     */
    void setMaxSize(int maxSize);

    /**
     * Returns the maximum number of times a given object can be checked out. Once past
     * this number, the object will be force-cleaned up.
     * WWW configurations currently allow a maximum of 1000 checkouts.
     *
     * @return the maximum number of times a given object can be checked out
     */
    int getMaxCheckout();

    /**
     * Returns the maximum number of times a given object can be checked out. Once past
     * this number, the object will be force-cleaned up.
     * WWW configurations currently allow a maximum of 1000 checkouts.
     *
     * @param maxCheckout - the maximum number of times a given object can be checked out
=     */
    void setMaxCheckout(int maxCheckout);

    /**
     * Returns the maximum duration (in seconds) that a client is allowed to keep an
     * object checked out. After the above duration has passed, the object will be automatically
     * cleaned up and removed from the pool.
     *
     * @return the maximum duration (in seconds) that a client is allowed to keep an object checked out
     */
    int getCheckoutTimeoutSeconds();

    /**
     * Set the maximum duration (in seconds) that a client is allowed to keep an
     * object checked out. After the above duration has passed, the object will be automatically
     * cleaned up and removed from the pool.
     *
     * @param checkoutTimeoutSeconds - the maximum duration (in seconds) that a client is allowed
     *                               to keep an object checked out
     */
    void setCheckoutTimeoutSeconds(int checkoutTimeoutSeconds);

    /**
     * Returns the maximum duration (in seconds) that a client is allowed to keep an
     * object "idle". After the above duration has passed, the object will be automatically
     * cleaned up and removed from the pool.
     *
     * @return the maximum duration (in seconds) that a client is allowed to keep an object "idle"
     */
    int getIdleTimeoutSeconds();

    /**
     * Set the maximum duration (in seconds) that a client is allowed to keep an
     * object "idle". After the above duration has passed, the object will be automatically
     * cleaned up and removed from the pool.
     *
     * @param idleTimeoutSeconds - the maximum duration (in seconds) that a client is allowed
     *                           to keep an object "idle"
     */
    void setIdleTimeoutSeconds(int idleTimeoutSeconds);

    /**
     * Returns the duration (in milliseconds) for which the pool remains marked unhealthy.
     * When the pool is marked unhealthy, it will automatically schedule a timer that will
     * mark the pool healthy after the above duration.
     *
     * @return the duration (in milliseconds) for which the pool remains marked unhealthy
     */
    long getRetryInterval();

    /**
     * Returns the duration (in milliseconds) for which the pool remains marked unhealthy.
     * When the pool is marked unhealthy, it will automatically schedule a timer that will
     * mark the pool healthy after the above duration.
     *
     * @param retryInterval - the duration (in milliseconds) for which the pool remains marked unhealthy
     */
    void setRetryInterval(long retryInterval);

    /**
     * Returns the duration (in milliseconds) for which the pool remains locked.
     * When the pool is locked, it will automatically schedule a timer that will
     * unlock the pool after the above duration.
     *
     * @return the duration (in milliseconds) for which the pool remains locked
     */
    long getLockTimeout();

    /**
     * Set the duration (in milliseconds) for which the pool remains locked.
     * When the pool is locked, it will automatically schedule a timer that will
     * unlock the pool after the above duration.
     *
     * @param lockTimeout - the duration (in milliseconds) for which the pool remains locked
     */
    void setLockTimeout(long lockTimeout);

    /**
     * Returns the maximum number of clients who can wait for an object to become
     * available (applicable when all the objects have been checked out). Any subequent
     * client will receive a XRuntimeSQL runtime exception.
     *
     * @return - the maximum number of clients who can wait for an object to become available
     */
    int getMaxWaitClient();

    /**
     * Returns the maximum number of clients who can wait for an object to become
     * available (applicable when all the objects have been checked out). Any subequent
     * client will receive a XRuntimeSQL runtime exception.
     *
     * @param maxWaitClient - the maximum number of clients who can wait for an object to become available
     */
    void setMaxWaitClient(int maxWaitClient);

    /**
     * Returns the duration (in milliseconds) for which the pool will wait when
     * a checkout() calls finds that all the objects are already checked out. If the
     * pool is not able to get an object within this duration, it will throw a
     * XRuntimeSQL runtime exception.
     *
     * @return the duration (in milliseconds)
     */
    int getMaxWaitTimeout();

    /**
     * Set the duration (in milliseconds) for which the pool will wait when
     * a checkout() calls finds that all the objects are already checked out. If the
     * pool is not able to get an object within this duration, it will throw a
     * XRuntimeSQL runtime exception.
     *
     * @param maxWaitTimeout - the duration (in milliseconds)
     */
    void setMaxWaitTimeout(int maxWaitTimeout);

    // RUNTIME GETTERS and SETTERS

    /**
     * Returns true if the pool is currently locked.
     *
     * @return true, if the pool is currently locked
     */
    boolean isLocked();

    /**
     * Set the locked status of the pool. If locked, any calls to the
     * checkout() method will result in a XPoolLocked runtime exception
     *
     * @param locked - the lock status to set
     */
    void setLocked(boolean locked);

    /**
     * Returns true if the pool is healthy.
     *
     * @return true, if the pool is healthy
     */
    boolean getHealth();

    /**
     * Set the health status of the pool.
     *
     * @param health - the health status to set
     */
    void setHealth(boolean health);

    /**
     * Returns true if the pool has been marked as permanently disabled.
     *
     * @return true, if the pool is marked as permanently disabled
     */
    boolean isPoolPermanentlyDisable();

    /**
     * Set the permanently disabled status of the pool.
     *
     * @param poolPermanentlyDisable - the permanently disabled status of the pool
     * @param errorNo                - a reference error number
     * @param errorMsg               - a descriptive error message
     */
    void setPoolPermanentlyDisable(boolean poolPermanentlyDisable, int errorNo, String errorMsg);

    /**
     * Returns true if the tracing is turned on for the pool.
     *
     * @return true, if the tracing is turned on
     */
    boolean getTracing();

    /**
     * Set the tracing status of the pool.
     *
     * @param tracing - the tracing status to set
     */
    void setTracing(boolean tracing);

    /**
     * Returns true if connections from this pool will log parameter values.
     * @return true if connections from this pool will log parameter values.
     */
    boolean getLogParams();

    /**
     * Set true if connections from this pool will log parameter values.
     * @param logParams - true if connections from this pool will log parameter values.
     */
    void setLogParams(boolean logParams);

    // OTHER FUNCTIONAL CALLS

    /**
     * Returns the number of objects in the pool.
     *
     * @return the number of objects in the pool
     */
    int size();

    /**
     * Returns the total number of calls to the checkout() method.
     *
     * @return - the total number of calls to the checkout() method
     */
    int getNumRequests();

    /**
     * Returns the number of clients waiting to get an object.
     *
     * @return the number of clients waiting to get an object
     */
    int getQueueSize();

    /**
     * Returns a string containing information about the pool and the pooled objects
     * inside it - suitable for general purpose debug statements.
     *
     * @return a string containing information about the pool and the pooled objects
     */
    String dumpInfo() ;

    /**
     * Returns a string containing information about the pooled objects - suitable for
     * display in a JMX admin console.
     *
     * @return a string containing information about the pooled objects
     */
    String dumpConnInfo() ;

    // CORE POOL METHODS

    /**
     * Allows a client to "borrow" an object from the pool.
     *
     * @return the borrowed object
     * @throws SQLException - in case of any errors
     */
    T checkout() throws SQLException;

    /**
     * Allows a client to return a previously "borrowed" object.
     *
     * @param pooledObject - the previously borrowed object
     */
    void checkin(T pooledObject);

    /**
     * Removes all the objects and marks the pool as healthy. The objects that are
     * currently checked out are given some time (@see SQLUtil.CLOSE_USED_CONNECTION_TIMEOUT)
   * to complete their processing, before attempting a force cleanup.
     */
    void removeAll();
    
    /**
     * Called whenever the pool needs to get rid of an object forcefully. The subclasses should not
     * normally need to override this. The default implementation removes it from the pool's internal
     * list of objects, and queues a call to the pooled object's forceClose() method
     *
     * @param pobj - the pooled object that needs to be "removed" forcefully
     * @param delay - the duration after which the pooled object's forceRemove() will be called
     */
    void forceRemove(T pobj, long delay);

    int getActiveClients();
    
    public static final String PROP_URL = "url";
    public static final String PROP_MIN_SIZE = "minSize";
    public static final String PROP_MAX_SIZE = "maxSize";
    public static final String PROP_MAX_CHECKOUT = "maxCheckout";
    public static final String PROP_CHECKOUT_TIMEOUT_SECONDS = "checkoutTimeoutSeconds";
    public static final String PROP_IDLE_TIMEOUT_SECONDS = "idleTimeoutSeconds";
    public static final String PROP_RETRY_INTERVAL = "retryInterval";
    public static final String PROP_LOCK_TIMEOUT = "lockTimeout";
    public static final String PROP_MAX_WAIT_CLIENT = "maxWaitClient";
    public static final String PROP_MAX_WAIT_TIMEOUT = "maxWaitTimeout";
    public static final String PROP_MAX_CHECKOUT_IN_MINUTES = "maxCheckoutInMinutes";

    public static final String PROP_USE_XA = "useXA";
    public static final String PROP_LOG_PARAMS = "logParams";

}
