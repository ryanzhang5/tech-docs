/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql;

import javax.transaction.xa.XAResource;
import javax.transaction.xa.Xid;
import javax.transaction.xa.XAException;
import java.util.Set;
import java.util.HashSet;
import java.util.Collections;

/**
 * PooledXAResource - provides a wrapper over XAResource, primarily to handle
 * a force close.
 *
 * @author mkishore
 * @since 2.0.2
 */
public class PooledXAResource implements XAResource {
    private XAResource xares;

    private final Set<Xid> xids = Collections.synchronizedSet(new HashSet<Xid>());

    public PooledXAResource(XAResource xares) {
        this.xares = xares;
    }

    public void commit(Xid xid, boolean b) throws XAException {
        xares.commit(xid, b);
        synchronized (xids) {
            xids.remove(xid);
        }
    }

    public void end(Xid xid, int i) throws XAException {
        xares.end(xid, i);
    }

    public void forget(Xid xid) throws XAException {
        xares.forget(xid);
        synchronized (xids) {
            xids.remove(xid);
        }
    }

    public int getTransactionTimeout() throws XAException {
        return xares.getTransactionTimeout();
    }

    public boolean isSameRM(XAResource xaResource) throws XAException {
        return xares.isSameRM(xaResource);
    }

    public int prepare(Xid xid) throws XAException {
        return xares.prepare(xid);
    }

    public Xid[] recover(int i) throws XAException {
        return xares.recover(i);
    }

    public void rollback(Xid xid) throws XAException {
        xares.rollback(xid);
        synchronized (xids) {
            xids.remove(xid);
        }
    }

    public boolean setTransactionTimeout(int i) throws XAException {
        return xares.setTransactionTimeout(i);
    }

    public void start(Xid xid, int i) throws XAException {
        xares.start(xid, i);
        synchronized (xids) {
            xids.add(xid);
        }
    }
    
    protected void forceClose() {
        Xid[] array = xids.toArray(new Xid[xids.size()]);
        for (Xid xid : array) {
            try {
                rollback(xid);
            } catch (Exception e) {
                // ignore
            }
        }
        synchronized (xids) {
            xids.clear();
        }
    }
}
