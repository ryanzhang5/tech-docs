package com.bitmechanic.sql;


import com.bitmechanic.util.DBLogger;
import com.bitmechanic.sql.url.UrlKeyManager;

import java.sql.Driver;
import java.sql.DriverPropertyInfo;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Properties;
import java.util.logging.Level;
import java.io.File;
  
import com.wm.corelib.config.AppConfig;


/**
 * Implements java.sql.Driver and controls access to connections in the pool.
 * Here's how to use it:
 * <pre>
 * // When your application starts, initialize the manager.  If you want
 * // the pool to reap unused connections for you (recommended), then pass
 * // an int to the constructor.  this tells the pool how many seconds to
 * // wait between reaping connections in the pool.
 * ConnectionPoolManager mgr = new ConnectionPoolManager(300);
 * 
 * // Load the driver into the VM like you would do w/o the pool
 * Class.forName("exgwe.sql.gweMysqlDriver").newInstance();
 * 
 * // Add one alias to the pool for each JDBC datasource you wish to connect
 * // to.  From this point forward any objects that need connection handles
 * // do not need to know the url, username, or password of the databse.
 * // They simply need the "alias" you named the pool with here
 * mgr.addAlias("myalias", "exgwe.sql.gweMysqlDriver",
 * "jdbc:mysql://localhost:3306/mydb",
 * "username", "password",
 * 10,  // max connections to open
 * 300, // seconds a connection can be idle before it is closed
 * 120, // seconds a connection can be checked out by a thread
 * // before it is returned back to the pool
 * 30); // number of times a connection can be re-used before 
 * // connection to database is closed and re-opened
 * // (optional parameter)
 * 
 * // Later in your code, use the JDBC DriverManager to obtain a
 * // connection manually
 * Connection conn = DriverManager(ConnectionPoolManager.URL_PREFIX +
 * "myalias", null, null);
 * 
 * // Calling conn.close() returns the connection back to the pool
 * conn.close();
 * </pre>
 * 
 * You can also call methods on the pool directly if you want to gather
 * statistics on the pool during runtime (to see if you need more connections
 * in the pool for example):
 * <pre>
 * // First get a ref to the pool for the alias
 * ConnectionPool pool = mgr.getPool("myalias");
 * 
 * // Then call methods on it
 * System.out.println("Connections have been checked out from the pool " +
 * pool.getNumRequests() + " times.");
 * </pre>
 * 
 * 
 */
 
public class ConnectionPoolManager implements Driver { 
    private static final DBLogger _logger = DBLogger.getInstance();
    private static final int MAJOR_VERSION = 0;
    private static final int MINOR_VERSION = 92;

    public static final String URL_PREFIX = "jdbc:bitmechanic:pool:";
    
    private final Hashtable<String, GenericPool> _aliasHash = new Hashtable<String, GenericPool>();
    private final UrlKeyManager _urlKeyManager;

    private static File urlKeysFile;
    static {
        String home = AppConfig.getInstance().getProperty("com.wm.app.home", "/tmp");
        File urlKeysDir = new File(home, "dbpool-url-keys");
        if (!urlKeysDir.exists()) {
            if (!urlKeysDir.mkdirs()) {
                _logger.log(Level.WARNING, "Could not create the base directory for storing url-keys.properties");
            }
        }
        urlKeysFile = new File(urlKeysDir, "url-keys.properties");
    }

    /**
     * Creates a pool with a monitoring thread that checks the pool to make
     * sure no connections are stale or idle.
     * @throws SQLException
     */
    public ConnectionPoolManager() throws SQLException {
        DriverManager.registerDriver(this);
        DriverManager.setLoginTimeout(SQLUtil.CONNECTION_LOGIN_TIMEOUT);

        _urlKeyManager = new UrlKeyManager(urlKeysFile);
        _urlKeyManager.setConnectionPoolManager(this);
        _urlKeyManager.setRefreshInterval(SQLUtil.URL_KEYS_CHECK_INTERVAL);
        _urlKeyManager.initialize();
    }

    /**
     * Add Connection Pool
     * @param alias - Pool Name
     * @param props - List of properties to configure the pool
     */
    public void addPool(String alias, Properties props) {
        GenericPool pool;
        if (props.getProperty("useXA", "false").equalsIgnoreCase("true")) {
            pool = new XAConnectionPoolImpl(alias);
        } else {
            pool = new ConnectionPoolImpl(alias);
        }
        pool.setConnectionPoolManager(this);
        pool.configure(props);
        pool.initialize();
        addPool(pool);
    }

    /**
     * Add Alias
     * @param pool -- Connection Pool
     */
    private synchronized void addPool(GenericPool pool) {
        _aliasHash.put(pool.getAlias(), pool);
    }

    /**
     * Closes all Connections in the pool with the supplied alias 
     * @param alias - String
     * @throws SQLException
     */
    public synchronized void removePool(String alias) throws SQLException {
        GenericPool p = getPool(alias);
        _aliasHash.remove(alias);
        p.removeAll();
    }

    /**
     * Returns an Enumeration of the ConnectionPool objects currently created
     * @return - Enumeration
     */
    public Enumeration<GenericPool> getPools() {
        return _aliasHash.elements();
    }

    /**
     * Get Pool Names
     * @return - Array of String
     */
    public String[] getPoolNames() {
        return _aliasHash.keySet().toArray(new String[_aliasHash.size()]);
    }

    /**
     * Returns the pool with the supplied alias
     * @param alias - String
     * @return - Generic Pool
     * @throws SQLException
     */
    public GenericPool getGenericPool(String alias) throws SQLException {
        GenericPool p = _aliasHash.get(alias);
        if (p != null) {
            return p;
        } else {
            _logger.log(_logger.WARNING,"No pool created for alias: " + alias);
            return null;
        }
    }

    /**
     * Returns the connection pool with the supplied alias
     * @param alias - String
     * @return - Connection Pool
     * @throws SQLException
     */
    public ConnectionPool getPool(String alias) throws SQLException {
        GenericPool p = _aliasHash.get(alias);
        if (p != null && p instanceof ConnectionPool) {
            return (ConnectionPool) p;
        } else {
            _logger.log(_logger.INFO,"No connection pool created for alias: " + alias);
            return null;
        }
    }

    /**
     * Returns the xa connectin pool with the supplied alias
     * @param alias - String
     * @return - XA Connection Pool
     * @throws SQLException
     */
    public XAConnectionPool getXAPool(String alias) throws SQLException {
        GenericPool p = _aliasHash.get(alias);
        if (p != null && p instanceof XAConnectionPool) {
            return (XAConnectionPool) p;
        } else {
            _logger.log(_logger.WARNING,"No XA connection pool created for alias: " + alias);
            return null;
        }
    }

    /**
     * This method should only be used within the dbpool module.
     */
    public UrlKeyManager getUrlKeyManager() {
        return this._urlKeyManager;
    }

    /**
     * Turns tracing on or off.  It is off by default.  When you turn 
     * tracing on, the pool will print verbose messages about what it's
     * doing to STDERR.  If your application is hanging when it calls
     * DriverManager.getConnection() this may help diagnose where things go 
     * wrong.
     * @param on - boolean
     */
    public void setTracing(boolean on) {
        _logger.log(_logger.WARNING,"ConnectionPoolManager: Tracing turned " + (on ? "on" : "off"));
        if (on)
            _logger.setLevel(_logger.INFO);
        else
            _logger.setLevel(_logger.WARNING);
    }

    /**
     * Dump some information about all connections and pools into a String
     * @return - String
     */
    public String dumpInfo() {
        Enumeration<GenericPool> allPools = getPools();
        StringBuffer report = new StringBuffer();
        while (allPools.hasMoreElements()) {
          GenericPool currentPool = allPools.nextElement();
          report.append(currentPool.dumpInfo());
        } // while
        return report.toString();
    } // dumpinfo


    // JDBC DriverManager METHODS

    /**
     * connect and get the connection from connection pool
     * @param url - URL
     * @param props - PROP
     * @return Connection from pool, or null if url does not start with URL_PREFIX
     * @throws SQLException if no alias is given in the URL or if no pool exists
     *         with that alias name
     */
    public Connection connect(String url, Properties props) throws SQLException {
        if(!url.startsWith(URL_PREFIX)) return null;

        if(url.length() <= URL_PREFIX.length())
            throw new SQLException("Invalid URL: " + url + " -- No alias given");

        String alias = url.substring(URL_PREFIX.length());

        _logger.log(_logger.INFO, "ConnectionPoolManager: connect() called for "
            			 + alias + ".  calling pool.getConnection()");

        ConnectionPool p = getPool(alias);

        return p.getConnection();
  }

    /**
     * Returns true of url starts with URL_PREFIX
     * @param url - URL
     * @return - boolean
     */
    public boolean acceptsURL(String url) {
        return url.startsWith(URL_PREFIX);
    }

    /**
     * get major version
     * @return - int
     */
    public int getMajorVersion() {
        return MAJOR_VERSION;
    }

    /**
     * get minor version
     * @return - int
     */
    public int getMinorVersion() {
        return MINOR_VERSION;
    }
    
    /**
     * get property info
     * @param str - String
     * @param props - properties
     * @return - Driver Property info
     */
    public DriverPropertyInfo[] getPropertyInfo(String str, Properties props) {
        return new DriverPropertyInfo[0];
    }

    /**
     * Always returns false since I haven't sent this code to Sun for approval 
     * @return - boolean
     */
    public boolean jdbcCompliant() {
        return false;
    }

}
