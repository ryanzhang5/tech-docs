/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql.tasks;

import com.bitmechanic.sql.ConnectionPool;
import com.bitmechanic.util.DBLogger;

import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * AbortCounterTask - a timer task that marks the pool locked if there are too many aborts.
 * GenericPoolImpl uses a default value of 5 mins for the frequency.
 *
 * @author mkishore
 * @since 2.0.1
 */
public class AbortCounterTask extends TimerTask {
    private static final DBLogger _logger = DBLogger.getInstance();

    private ConnectionPool pool;
    private AtomicInteger abortCounter = new AtomicInteger(0);

    public AbortCounterTask(ConnectionPool pool) {
        this.pool = pool;
    }

    public void run() {
        checkCounter();
        abortCounter.set(0);
    }

    public void incrementAndCheck() {
        abortCounter.incrementAndGet();
        checkCounter();
    }

    private void checkCounter() {
        if (abortCounter.get() >= pool.getMaxSize()) {
            if (!pool.isLocked()) {
                _logger.log(_logger.SEVERE, "ConnectionPool:[" + pool.getAlias() + "] is marked un-healthy, due to multiple abort Connections");
                pool.setLocked(true);
            }
        }
    }
}
