/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql.url;

import com.bitmechanic.sql.GenericPool;

/**
 * UrlProvider - an asbtraction for different kind of url providers
 *
 * @author mkishore
 * @since 2.0.3
 */
public abstract class UrlProvider {
    public static final String PREFIX_STATIC = "static(";

    public static UrlProvider getInstance(GenericPool pool, String url) {
        if (url != null && url.startsWith(PREFIX_STATIC)) {
            return new StaticUrlProvider(pool, url);
        }
        return new SimpleUrlProvider(pool, url);
    }

    protected GenericPool pool;
    protected String url;

    protected UrlProvider(GenericPool pool, String url) {
        this.pool = pool;
        this.url = url;
    }

    /**
     * Get the URL that needs to be used to get a connection
     *
     * @return 	URL
     */
    public abstract String getUrl();
}
