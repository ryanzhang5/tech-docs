/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql;

import javax.sql.XAConnection;
import javax.sql.ConnectionEventListener;
import javax.sql.StatementEventListener;
import javax.transaction.xa.XAResource;
import java.sql.SQLException;
import java.sql.Connection;
import java.util.*;

/**
 * PooledXAConnection - a wrapper over an actual XAConnection, which allows the XAConnectionPool
 * to manage a pool of such instances. All the calls (except the close()) are delegated to the
 * underlying XAConnection object. The close() call removes all event listeners and checks the
 * object back into the pool.
 *
 * @author mkishore
 * @since 2.0.1
 */
public class PooledXAConnection extends GenericPooledObject implements XAConnection {
    private XAConnection xaconn;
    private XAConnectionPool pool;
    private PooledXAResource xares;

    private final List<ConnectionEventListener> connEvtListeners = Collections.synchronizedList(new ArrayList<ConnectionEventListener>());
    private final List<StatementEventListener> stmtEvtListeners = Collections.synchronizedList(new ArrayList<StatementEventListener>());

    /**
     * Creates a wrapper XAConnection over the underlying delegate
     *
     * @param xaconn - the actual underlying delegate
     * @param pool - the pool this wrapper will belong to
     */
    public PooledXAConnection(XAConnection xaconn, XAConnectionPool pool) {
        this.xaconn = xaconn;
        this.pool = pool;
    }

    /**
     * Retrieves an <code>XAResource</code> object that
     * the transaction manager will use
     * to manage this <code>XAConnection</code> object's participation in a
     * distributed transaction.
     *
     * @return the <code>XAResource</code> object
     * @throws java.sql.SQLException if a database access error occurs
     * @throws java.sql.SQLFeatureNotSupportedException
     *                               if the JDBC driver does not support
     *                               this method
     * @since 1.4
     */
    public synchronized XAResource getXAResource() throws SQLException {
        if (xares == null) {
            xares = new PooledXAResource(xaconn.getXAResource());
        }
        return xares;
    }

    /**
     * Creates and returns a <code>Connection</code> object that is a handle
     * for the physical connection that
     * this <code>PooledConnection</code> object represents.
     * The connection pool manager calls this method when an application has
     * called the method <code>DataSource.getConnection</code> and there are
     * no <code>PooledConnection</code> objects available. See the
     * {@link javax.sql.PooledConnection interface description} for more information.
     *
     * @return a <code>Connection</code> object that is a handle to
     *         this <code>PooledConnection</code> object
     * @throws java.sql.SQLException if a database access error occurs
     * @throws java.sql.SQLFeatureNotSupportedException
     *                               if the JDBC driver does not support
     *                               this method
     * @since 1.4
     */
    public Connection getConnection() throws SQLException {
        return xaconn.getConnection();
    }

    /**
     * Closes the physical connection that this <code>PooledConnection</code>
     * object represents.  An application never calls this method directly;
     * it is called by the connection pool module, or manager.
     * <p/>
     * See the {@link javax.sql.PooledConnection interface description} for more
     * information.
     *
     * @throws java.sql.SQLException if a database access error occurs
     * @throws java.sql.SQLFeatureNotSupportedException
     *                               if the JDBC driver does not support
     *                               this method
     * @since 1.4
     */
    public void close() throws SQLException {
        removeAllEventListeners();
        xares = null;
        pool.checkin(this);
    }

    /**
     * Registers the given event listener so that it will be notified
     * when an event occurs on this <code>PooledConnection</code> object.
     *
     * @param listener a component, usually the connection pool manager,
     *                 that has implemented the
     *                 <code>ConnectionEventListener</code> interface and wants to be
     *                 notified when the connection is closed or has an error
     * @see #removeConnectionEventListener
     */
    public void addConnectionEventListener(ConnectionEventListener listener) {
        synchronized (connEvtListeners) {
            connEvtListeners.add(listener);
        }
        xaconn.addConnectionEventListener(listener);
    }

    /**
     * Removes the given event listener from the list of components that
     * will be notified when an event occurs on this
     * <code>PooledConnection</code> object.
     *
     * @param listener a component, usually the connection pool manager,
     *                 that has implemented the
     *                 <code>ConnectionEventListener</code> interface and
     *                 been registered with this <code>PooledConnection</code> object as
     *                 a listener
     * @see #addConnectionEventListener
     */
    public void removeConnectionEventListener(ConnectionEventListener listener) {
        synchronized (connEvtListeners) {
            connEvtListeners.remove(listener);
        }
        xaconn.removeConnectionEventListener(listener);
    }

    /**
     * Registers a <code>StatementEventListener</code> with this <code>PooledConnection</code> object.  Components that
     * wish to be notified when  <code>PreparedStatement</code>s created by the
     * connection are closed or are detected to be invalid may use this method
     * to register a <code>StatementEventListener</code> with this <code>PooledConnection</code> object.
     * <p/>
     *
     * @param listener an component which implements the <code>StatementEventListener</code>
     *                 interface that is to be registered with this <code>PooledConnection</code> object
     *                 <p/>
     * @since 1.6
     */
    public void addStatementEventListener(StatementEventListener listener) {
        synchronized (stmtEvtListeners) {
            stmtEvtListeners.add(listener);
        }
        xaconn.addStatementEventListener(listener);
    }

    /**
     * Removes the specified <code>StatementEventListener</code> from the list of
     * components that will be notified when the driver detects that a
     * <code>PreparedStatement</code> has been closed or is invalid.
     * <p/>
     *
     * @param listener the component which implements the
     *                 <code>StatementEventListener</code> interface that was previously
     *                 registered with this <code>PooledConnection</code> object
     *                 <p/>
     * @since 1.6
     */
    public void removeStatementEventListener(StatementEventListener listener) {
        synchronized (stmtEvtListeners) {
            stmtEvtListeners.remove(listener);
        }
        xaconn.removeStatementEventListener(listener);
    }

    /**
     * This method is called from the PooledObjectReaper - the subclass implementations
     * should perform the necessary cleanup.
     *
     * @since 2.0.2
     */
    public void forceClose() {
        // if is locked means somebody is using connection so abort it
        if (isLocked()) {
            aborted = true;
        }
        if (xares != null) {
            xares.forceClose();
        }
        try {
            if (xaconn != null) {
                xaconn.close();
            }
        } catch (Exception e) {
            // ignore
        }
        xaconn = null;
        removeAllEventListeners();
    }

    // PRIVATE METHODS

    private void removeAllEventListeners() {
        synchronized(connEvtListeners) {
            for (ConnectionEventListener cel : connEvtListeners) {
                xaconn.removeConnectionEventListener(cel);
            }
            connEvtListeners.clear();
        }
        synchronized(stmtEvtListeners) {
            for (StatementEventListener sel : stmtEvtListeners) {
                xaconn.removeStatementEventListener(sel);
            }
            stmtEvtListeners.clear();
        }
    }
}
