/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql;

import com.bitmechanic.sql.adapters.DefaultConnectionPoolAdapter;

import javax.sql.XAConnection;
import javax.sql.XADataSource;
import java.sql.SQLException;
import java.util.Properties;

/**
 * XAConnectionPoolImpl
 *
 * @author mkishore
 * @since 2.0.1
 */
public class XAConnectionPoolImpl extends GenericPoolImpl<PooledXAConnection> implements XAConnectionPool {
    private String user;
    private String password;
    private XAConnectionPoolAdapter adapter;

    /**
     * Constructor
     *
     * @param alias - Pool Name
     */
    public XAConnectionPoolImpl(String alias) {
        super(alias);
    }

    /**
     * Allows the creator to configure the pool from a list of propwerties.
     *
     * @param props - list of properties
     */
    public void configure(Properties props) {
        super.configure(props);

        this.user = props.getProperty(PROP_USER);
        this.password = props.getProperty(PROP_PASSWORD);

        try {
            String adapterName = props.getProperty(PROP_ADAPTER);
            if (adapterName == null && url != null) {
                if (url.contains(":oracle:")) {
                    adapterName = "com.bitmechanic.sql.adapters.OracleXAConnectionPoolAdapter";
                } else if (url.contains(":mysql:")) {
                    adapterName = "com.bitmechanic.sql.adapters.MysqlXAConnectionPoolAdapter";
                }
            }
            if (adapterName != null) {
                Class<?> adapterClass = Thread.currentThread().getContextClassLoader().loadClass(adapterName);
                if (XAConnectionPoolAdapter.class.isAssignableFrom(adapterClass)) {
                    adapter = (XAConnectionPoolAdapter) adapterClass.newInstance();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (adapter == null) {
            throw new RuntimeException("XAConnectionPool: alias [" + alias + "] needs a valid adapter");
        }
    }

    /**
     * This method calls the super.initialize() and sets up an AbortCounterTask.
     */
    public synchronized void initialize() {
        try {
            super.initialize();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Needs to be implemented by the subclass to create an instance of the object to be pooled.
     *
     * @return an instance of the object to be pooled
     * @throws java.sql.SQLException in case of any errors
     */
    protected PooledXAConnection doCreate() throws SQLException {
        XADataSource xads = adapter.getXADataSource(urlProvider.getUrl());
        XAConnection xaconn = xads.getXAConnection(user, password);
        return new PooledXAConnection(xaconn, this);
    }

    /**
     * Returns an XAConnection from the pool.
     *
     * @return XAConnection from the pool
     * @throws java.sql.SQLException in case of any errors
     */
    public XAConnection getXAConnection() throws SQLException {
        return checkout();
    }

    /**
     * Returns a "borrowed" XA connection back to the pool.
     *
     * @param pxaconn - the "borrowed" xa connection
     * @throws java.sql.SQLException in case of any errors
     */
    public void returnXAConnection(PooledXAConnection pxaconn) throws SQLException {
        checkin(pxaconn);
    }

}
