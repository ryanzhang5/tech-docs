/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql.url;

import com.bitmechanic.sql.GenericPool;
import com.bitmechanic.sql.ConnectionPoolManager;

import java.util.Map;
import java.util.LinkedHashMap;
import java.util.StringTokenizer;

/**
 * StaticUrlProvider - takes in a url formatted as follows: static(key1=url1,key2=url2,..)
 * and stores these as a linked HashMap. The call to getUrl() will use the UrlKeyManager to
 * determine which key to use. If the UrlKeyManager does not provide any (overriding) key,
 * this class defaults to the first url in the list.
 *
 * @author mkishore
 * @since 2.0.3
 */
public class StaticUrlProvider extends UrlProvider {
    private Map<String,String> urls = new LinkedHashMap<String,String>();
    private String defaultUrl;

    public StaticUrlProvider(GenericPool pool, String url) {
        super(pool, url);
        if (url == null || !url.startsWith(PREFIX_STATIC)) {
            throw new IllegalArgumentException("The url ["+url+"] needs to start with: " + PREFIX_STATIC);
        } else if (!url.endsWith(")")) {
            throw new IllegalArgumentException("The url ["+url+"] needs to end with: )");
        }
        url = url.substring(PREFIX_STATIC.length(), url.length()-1).trim();
        StringTokenizer tokenizer = new StringTokenizer(url, ",");
        while (tokenizer.hasMoreTokens()) {
            String token = tokenizer.nextToken();
            int ndx = token.indexOf('=');
            if (ndx != -1) {
                String key = token.substring(0, ndx).trim();
                String val = token.substring(ndx+1).trim();
                if (defaultUrl == null) defaultUrl = val;
                urls.put(key, val);
            }
        }
    }

    public String getUrl() {
        String url = null;
        ConnectionPoolManager connectionPoolManager = pool.getConnectionPoolManager();
        if (connectionPoolManager != null) {
            UrlKeyManager urlKeyManager = connectionPoolManager.getUrlKeyManager();
            if (urlKeyManager != null) {
                String key = urlKeyManager.getUrlKey(pool.getAlias());
                url = urls.get(key);
            }
        }
        return (url != null) ?url :defaultUrl;
    }
}