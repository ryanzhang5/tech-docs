package com.bitmechanic.sql;


import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Calendar;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;

// This class will print the DB BENCH's to either System.err or to a file or not print at all
// This behavior is configured in the homewarehouse.conf file

public class DBBench {

    private static PrintStream _dbBenchPOS = System.err;

    /**
     * set db bench pos
     * @param pos -- Stream
     */
    public static void setDBBenchPOS(OutputStream pos){
        if ( pos != null )
            _dbBenchPOS = new PrintStream( pos, true );
        else
            _dbBenchPOS = null;
    }
  
    /**
     * Log time
     * @param sql - String
     * @param time - long
     */
    public static void logTime(String sql, long time, String params, boolean isProxy){
        if( _dbBenchPOS != null) {
            String sessionID = getThreadLocalID(SESSION_ID_GETTER);
            String requestID = getThreadLocalID(REQUEST_ID_GETTER);
            StringBuilder sb = new StringBuilder();
            sb.append("DB ")
                    .append(isProxy ?"PROXY: " :"BENCH: ")
                    .append(sql)
                    .append(" -> millis = ").append(time).append(" elapsed ")
                    .append(Calendar.getInstance().getTime())
                    .append(" <Params: ").append(params != null ?params :"").append(">")
                    .append(" <SessionID: ").append(sessionID != null ?sessionID :"NULL").append(">")
                    .append(" <RequestID: ").append(requestID != null ?requestID :"NULL").append(">")
                    ;
            _dbBenchPOS.println(sb.toString());
        }
    }

    private static String getThreadLocalID(Method method) {
        try {
            if (method != null) return (String) method.invoke(null);
        } catch (Exception e) {
            // ignore
        }
        return null;
    }

    private static Method SESSION_ID_GETTER = null;
    private static Method REQUEST_ID_GETTER = null;

    static {
        try {
            Class clazz = Class.forName("com.wm.corelib.logging.ThreadGroupID");
            SESSION_ID_GETTER = clazz.getMethod("get");
            clazz = Class.forName("com.wm.corelib.logging.ThreadRequestID");
            REQUEST_ID_GETTER = clazz.getMethod("get");
        } catch (Exception e) {
            // ignore - we probably do not have the corelib-logging JAR file
            // which is a soft-dependency
        }
    }
}
