/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql;

import java.io.StringWriter;
import java.io.PrintWriter;
  
import com.wm.corelib.config.AppConfig;

/**
 * GenericPooledObject - base class for all objects placed into a GenericPool
 *
 * @author mkishore
 * @since 2.0.1
 */
public class GenericPooledObject {
    protected boolean locked;
    protected long createdTime=0;
    protected long lastAccess=0;
    protected long lastCheckin=0;
    protected int checkoutCount;
    protected boolean aborted;
    protected Exception traceException;

    /**
     * Creates a new instance and initializes the createdTime property
     */
    public GenericPooledObject() {
        this.createdTime = System.currentTimeMillis();
    }

    /**
     * Returns false if the object is already in use, otherwise marks the object
     * as locked and returns true. This method should be called before returning
     * the object to the client.
     *
     * @return true if the object is not in use, false otherwise
     */
    public synchronized boolean getLock() {
        if (locked) {
            return false;
        } else {
            locked = true;
            checkoutCount++;
            // Touch our access time so that we don't get immediately reaped
            // by accident, which could happen if the idle timeout is close to the
            // max duration of the query
            lastAccess = System.currentTimeMillis();
            try {
                throw new RuntimeException();
            } catch (Exception e) {
                traceException = e;
            }
            return true;
        }
    }

    /**
     * Clears the locked flag (which indicated the objects in-use status).
     * This method should be called when the client returns an object to the pool.
     */
    public void releaseLock() {
        lastAccess = lastCheckin = System.currentTimeMillis();
        locked = false;
    }

    // GETTERS and SETTERS

    /**
     * Returns true if the object is in use - i.e. has been checked out of the pool.
     *
     * @return true, if the object is in use.
     */
    public boolean isLocked() {
        return locked;
    }

    /**
     * Returns the timestamp when the object was created.
     *
     * @return the object creation timestamp
     */
    public long getCreatedTime() {
        return createdTime;
    }

    /**
     * Returns the timestamp when the object was last accessed. This class updates
     * the property on getLock() and releaseLock() methods. The subclasses
     * can update the lastAccess property as needed.
     *
     * @return the timestamp when the object was last "accessed"
     */
    public long getLastAccess() {
        return lastAccess;
    }

    /**
     * Returns the timestamp when the object was last checked back into the pool.
     *
     * @return the timestamp when the object was last checked back into the pool
     */
    public long getLastCheckin() {
        return lastCheckin;
    }

    /**
     * Returns the number of times this object was checked out of the pool.
     *
     * @return the number of times this object was checked out of the pool
     */
    public int getCheckoutCount() {
        return checkoutCount;
    }

    /**
     * Returns true if the object was in use too long and had to be force-cleaned up.
     *
     * @return true, if the object was in use too long and had to be force-cleaned up
     */
    public boolean isAborted() {
        return aborted;
    }

    /**
     * Returns true if the object was in use too long and had to be force-cleaned up.
     *
     * @param aborted - the aborted status of the object
     */
    public void setAborted(boolean aborted) {
        this.aborted = aborted;
    }

    /**
     * Returns the exception containing the stack-trace that represents the client call
     * to checkout an object from the pool.
     *
     * @return the exception containing the stack-trace that represents the client call
     */
    public Exception getTraceException() {
        return traceException;
    }

    /**
     * This method is called from the PooledObjectReaper - the subclass implementations
     * should perform the necessary cleanup. 
     */
    public void forceClose() {
        // no-op
    }

    /**
    * Dump some information about this pooled object
    */
    public String dumpInfo() {
        StringBuffer sb = new StringBuffer();
        String LS = AppConfig.getInstance().getProperty("line.separator");
        sb.append("\t\t" + getClass().getSimpleName() + ": " + this.toString() + LS)
                .append("\t\t\tCheckout count: " + this.getCheckoutCount() + LS)
                .append("\t\t\tLast Checkout: " + getLastAccess() + ": " + new java.util.Date(this.getLastAccess()) + LS)
                .append("\t\t\tLast Checkin : " + getLastCheckin() + ": " + new java.util.Date(getLastCheckin()) + LS)
                .append("\t\t\t" + (isLocked() ? "Connection IS checked out." : "Connection is NOT checked out.") + LS)
                .append("\t\t\tCheckout Stack Trace: ");

        if (traceException != null) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            traceException.printStackTrace(pw);
            sb.append(sw.toString());
        } else {
            sb.append("null");
        }

        sb.append(LS);

        return sb.toString();
    }



}
