package com.bitmechanic.sql;

import java.sql.SQLException;
import java.sql.Connection;

public interface ConnectionPool extends GenericPool<PooledConnection> {
    public Connection getConnection() throws SQLException;
    public void returnConnection(PooledConnection conn) throws SQLException;
    public void removeAllConnections() throws SQLException;

    public String getDriverName() ;

    public void setPrefetchSize(int newPrefetchSize) ;
    public int getPrefetchSize() ;
    public void lockPool(boolean lock) ;
    public boolean poolIsLocked() ;
    boolean isProxy();
    void setProxy(boolean proxy);

    public void registerException(SQLException e, PooledConnection conn) ;
    
    public void cancelConnection(Connection conn);
    public void abortConnection(Connection conn);

    public static final String PROP_DRIVER_NAME = "driverName";
    public static final String PROP_USER = "user";
    public static final String PROP_PASSWORD = "password";
    public static final String PROP_ADAPTER = "adapter";
    public static final String PROP_IS_PROXY = "isProxy";

}
