package com.bitmechanic.sql;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.*;
import java.util.Calendar;
import java.util.Map;
import java.util.HashMap;

public class PooledCallableStatement extends PooledPreparedStatement implements CallableStatement {
    private CallableStatement cstmt;

    public PooledCallableStatement(CallableStatement stmt, String sql, PooledConnection conn) {
        super(stmt, sql, conn);
        this.cstmt = stmt;
    }

    /**
     * ***********************************************************************
     * <p/>
     * CallableStatment methods
     * <p/>
     * ************************************************************************
     */

    public Array getArray(int i) throws SQLException {
        return cstmt.getArray(i);
    }


    public Array getArray(String parameterName) throws SQLException {
        return cstmt.getArray(parameterName);
    }


    public BigDecimal getBigDecimal(int parameterIndex) throws SQLException {
        return cstmt.getBigDecimal(parameterIndex);
    }


    public BigDecimal getBigDecimal(int parameterIndex, int scale) throws SQLException {
        return cstmt.getBigDecimal(parameterIndex, scale);
    }


    public BigDecimal getBigDecimal(String parameterName) throws SQLException {
        return cstmt.getBigDecimal(parameterName);
    }


    public Blob getBlob(int i) throws SQLException {
        return cstmt.getBlob(i);
    }


    public Blob getBlob(String parameterName) throws SQLException {
        return cstmt.getBlob(parameterName);
    }


    public boolean getBoolean(int parameterIndex) throws SQLException {
        return cstmt.getBoolean(parameterIndex);
    }


    public boolean getBoolean(String parameterName) throws SQLException {
        return cstmt.getBoolean(parameterName);
    }


    public byte getByte(int parameterIndex) throws SQLException {
        return cstmt.getByte(parameterIndex);
    }


    public byte getByte(String parameterName) throws SQLException {
        return cstmt.getByte(parameterName);
    }


    public byte[] getBytes(int parameterIndex) throws SQLException {
        return cstmt.getBytes(parameterIndex);
    }


    public byte[] getBytes(String parameterName) throws SQLException {
        return cstmt.getBytes(parameterName);
    }


    public Clob getClob(int i) throws SQLException {
        return cstmt.getClob(i);
    }


    public Clob getClob(String parameterName) throws SQLException {
        return cstmt.getClob(parameterName);
    }


    public Date getDate(int parameterIndex) throws SQLException {
        return cstmt.getDate(parameterIndex);
    }


    public Date getDate(int parameterIndex, Calendar cal) throws SQLException {
        return cstmt.getDate(parameterIndex, cal);
    }


    public Date getDate(String parameterName) throws SQLException {
        return cstmt.getDate(parameterName);
    }


    public Date getDate(String parameterName, Calendar cal) throws SQLException {
        return cstmt.getDate(parameterName, cal);
    }


    public double getDouble(int parameterIndex) throws SQLException {
        return cstmt.getDouble(parameterIndex);
    }


    public double getDouble(String parameterName) throws SQLException {
        return cstmt.getDouble(parameterName);
    }


    public float getFloat(int parameterIndex) throws SQLException {
        return cstmt.getFloat(parameterIndex);
    }


    public float getFloat(String parameterName) throws SQLException {
        return cstmt.getFloat(parameterName);
    }


    public int getInt(int parameterIndex) throws SQLException {
        return cstmt.getInt(parameterIndex);
    }


    public int getInt(String parameterName) throws SQLException {
        return cstmt.getInt(parameterName);
    }


    public long getLong(int parameterIndex) throws SQLException {
        return cstmt.getLong(parameterIndex);
    }


    public long getLong(String parameterName) throws SQLException {
        return cstmt.getLong(parameterName);
    }


    public Object getObject(int parameterIndex) throws SQLException {
        return cstmt.getObject(parameterIndex);
    }


    public Object getObject(int i, Map<String, Class<?>> map) throws SQLException {
        return cstmt.getObject(i, map);
    }


    public Object getObject(String parameterName) throws SQLException {
        return cstmt.getObject(parameterName);
    }


    public Object getObject(String parameterName, Map<String, Class<?>> map) throws SQLException {
        return cstmt.getObject(parameterName, map);
    }


    public Ref getRef(int i) throws SQLException {
        return cstmt.getRef(i);
    }


    public Ref getRef(String parameterName) throws SQLException {
        return cstmt.getRef(parameterName);
    }


    public short getShort(int parameterIndex) throws SQLException {
        return cstmt.getShort(parameterIndex);
    }


    public short getShort(String parameterName) throws SQLException {
        return cstmt.getShort(parameterName);
    }


    public String getString(int parameterIndex) throws SQLException {
        return cstmt.getString(parameterIndex);
    }


    public String getString(String parameterName) throws SQLException {
        return cstmt.getString(parameterName);
    }


    public Time getTime(int parameterIndex) throws SQLException {
        return cstmt.getTime(parameterIndex);
    }


    public Time getTime(int parameterIndex, Calendar cal) throws SQLException {
        return cstmt.getTime(parameterIndex, cal);
    }


    public Time getTime(String parameterName) throws SQLException {
        return cstmt.getTime(parameterName);
    }


    public Time getTime(String parameterName, Calendar cal) throws SQLException {
        return cstmt.getTime(parameterName, cal);
    }


    public Timestamp getTimestamp(int parameterIndex) throws SQLException {
        return cstmt.getTimestamp(parameterIndex);
    }


    public Timestamp getTimestamp(int parameterIndex, Calendar cal) throws SQLException {
        return cstmt.getTimestamp(parameterIndex, cal);
    }


    public Timestamp getTimestamp(String parameterName) throws SQLException {
        return cstmt.getTimestamp(parameterName);
    }


    public Timestamp getTimestamp(String parameterName, Calendar cal) throws SQLException {
        return cstmt.getTimestamp(parameterName, cal);
    }


    public URL getURL(int parameterIndex) throws SQLException {
        return cstmt.getURL(parameterIndex);
    }


    public URL getURL(String parameterName) throws SQLException {
        return cstmt.getURL(parameterName);
    }


    public void registerOutParameter(int parameterIndex, int sqlType) throws SQLException {
        setOutParam(parameterIndex, sqlType);
        cstmt.registerOutParameter(parameterIndex, sqlType);
    }


    public void registerOutParameter(int parameterIndex, int sqlType, int scale) throws SQLException {
        setOutParam(parameterIndex, sqlType);
        cstmt.registerOutParameter(parameterIndex, sqlType, scale);
    }


    public void registerOutParameter(int parameterIndex, int sqlType, String typeName) throws SQLException {
        setOutParam(parameterIndex, sqlType);
        cstmt.registerOutParameter(parameterIndex, sqlType, typeName);
    }


    public void registerOutParameter(String parameterName, int sqlType) throws SQLException {
        setOutParam(parameterName, sqlType);
        cstmt.registerOutParameter(parameterName, sqlType);
    }


    public void registerOutParameter(String parameterName, int sqlType, int scale) throws SQLException {
        setOutParam(parameterName, sqlType);
        cstmt.registerOutParameter(parameterName, sqlType, scale);
    }


    public void registerOutParameter(String parameterName, int sqlType, String typeName) throws SQLException {
        setOutParam(parameterName, sqlType);
        cstmt.registerOutParameter(parameterName, sqlType, typeName);
    }


    public void setAsciiStream(String parameterName, InputStream x, int length) throws SQLException {
        setParam(parameterName, x);
        cstmt.setAsciiStream(parameterName, x, length);
    }


    public void setBigDecimal(String parameterName, BigDecimal x) throws SQLException {
        setParam(parameterName, x);
        cstmt.setBigDecimal(parameterName, x);
    }


    public void setBinaryStream(String parameterName, InputStream x, int length) throws SQLException {
        setParam(parameterName, x);
        cstmt.setBinaryStream(parameterName, x, length);
    }


    public void setBoolean(String parameterName, boolean x) throws SQLException {
        setParam(parameterName, x);
        cstmt.setBoolean(parameterName, x);
    }


    public void setByte(String parameterName, byte x) throws SQLException {
        setParam(parameterName, x);
        cstmt.setByte(parameterName, x);
    }


    public void setBytes(String parameterName, byte[] x) throws SQLException {
        setParam(parameterName, x);
        cstmt.setBytes(parameterName, x);
    }


    public void setCharacterStream(String parameterName, Reader reader, int length) throws SQLException {
        setParam(parameterName, reader);
        cstmt.setCharacterStream(parameterName, reader, length);
    }


    public void setDate(String parameterName, Date x) throws SQLException {
        setParam(parameterName, x);
        cstmt.setDate(parameterName, x);
    }


    public void setDate(String parameterName, Date x, Calendar cal) throws SQLException {
        setParam(parameterName, x);
        cstmt.setDate(parameterName, x, cal);
    }


    public void setDouble(String parameterName, double x) throws SQLException {
        setParam(parameterName, x);
        cstmt.setDouble(parameterName, x);
    }


    public void setFloat(String parameterName, float x) throws SQLException {
        setParam(parameterName, x);
        cstmt.setFloat(parameterName, x);
    }


    public void setInt(String parameterName, int x) throws SQLException {
        setParam(parameterName, x);
        cstmt.setInt(parameterName, x);
    }


    public void setLong(String parameterName, long x) throws SQLException {
        setParam(parameterName, x);
        cstmt.setLong(parameterName, x);
    }


    public void setNull(String parameterName, int sqlType) throws SQLException {
        setParam(parameterName, null);
        cstmt.setNull(parameterName, sqlType);
    }


    public void setNull(String parameterName, int sqlType, String typeName) throws SQLException {
        setParam(parameterName, null);
        cstmt.setNull(parameterName, sqlType, typeName);
    }


    public void setObject(String parameterName, Object x) throws SQLException {
        setParam(parameterName, x);
        cstmt.setObject(parameterName, x);
    }


    public void setObject(String parameterName, Object x, int targetSqlType) throws SQLException {
        setParam(parameterName, x);
        cstmt.setObject(parameterName, x, targetSqlType);
    }


    public void setObject(String parameterName, Object x, int targetSqlType, int scale) throws SQLException {
        setParam(parameterName, x);
        cstmt.setObject(parameterName, x, targetSqlType, scale);
    }


    public void setShort(String parameterName, short x) throws SQLException {
        setParam(parameterName, x);
        cstmt.setShort(parameterName, x);
    }


    public void setString(String parameterName, String x) throws SQLException {
        setParam(parameterName, x);
        cstmt.setString(parameterName, x);
    }


    public void setTime(String parameterName, Time x) throws SQLException {
        setParam(parameterName, x);
        cstmt.setTime(parameterName, x);
    }


    public void setTime(String parameterName, Time x, Calendar cal) throws SQLException {
        setParam(parameterName, x);
        cstmt.setTime(parameterName, x, cal);
    }


    public void setTimestamp(String parameterName, Timestamp x) throws SQLException {
        setParam(parameterName, x);
        cstmt.setTimestamp(parameterName, x);
    }


    public void setTimestamp(String parameterName, Timestamp x, Calendar cal) throws SQLException {
        setParam(parameterName, x);
        cstmt.setTimestamp(parameterName, x, cal);
    }


    public void setURL(String parameterName, URL val) throws SQLException {
        setParam(parameterName, val);
        cstmt.setURL(parameterName, val);
    }


    public boolean wasNull() throws SQLException {
        return cstmt.wasNull();
    }

    public RowId getRowId(int parameterIndex) throws SQLException {
        return cstmt.getRowId(parameterIndex);
    }

    public RowId getRowId(String parameterName) throws SQLException {
        return cstmt.getRowId(parameterName);
    }

    public void setRowId(String parameterName, RowId x) throws SQLException {
        setParam(parameterName, x);
        cstmt.setRowId(parameterName, x);
    }

    public void setNString(String parameterName, String value) throws SQLException {
        setParam(parameterName, value);
        cstmt.setNString(parameterName, value);
    }

    public void setNCharacterStream(String parameterName, Reader value, long length) throws SQLException {
        setParam(parameterName, value);
        cstmt.setNCharacterStream(parameterName, value, length);
    }

    public void setNClob(String parameterName, NClob value) throws SQLException {
        setParam(parameterName, value);
        cstmt.setNClob(parameterName, value);
    }

    public void setClob(String parameterName, Reader reader, long length) throws SQLException {
        setParam(parameterName, reader);
        cstmt.setClob(parameterName, reader, length);
    }

    public void setBlob(String parameterName, InputStream inputStream, long length) throws SQLException {
        setParam(parameterName, inputStream);
        cstmt.setBlob(parameterName, inputStream, length);
    }

    public void setNClob(String parameterName, Reader reader, long length) throws SQLException {
        setParam(parameterName, reader);
        cstmt.setNClob(parameterName, reader, length);
    }

    public NClob getNClob(int parameterIndex) throws SQLException {
        return cstmt.getNClob(parameterIndex);
    }

    public NClob getNClob(String parameterName) throws SQLException {
        return cstmt.getNClob(parameterName);
    }

    public void setSQLXML(String parameterName, SQLXML xmlObject) throws SQLException {
        setParam(parameterName, xmlObject);
        cstmt.setSQLXML(parameterName, xmlObject);
    }

    public SQLXML getSQLXML(int parameterIndex) throws SQLException {
        return cstmt.getSQLXML(parameterIndex);
    }

    public SQLXML getSQLXML(String parameterName) throws SQLException {
        return cstmt.getSQLXML(parameterName);
    }

    public String getNString(int parameterIndex) throws SQLException {
        return cstmt.getNString(parameterIndex);
    }

    public String getNString(String parameterName) throws SQLException {
        return cstmt.getNString(parameterName);
    }

    public Reader getNCharacterStream(int parameterIndex) throws SQLException {
        return cstmt.getNCharacterStream(parameterIndex);
    }

    public Reader getNCharacterStream(String parameterName) throws SQLException {
        return cstmt.getNCharacterStream(parameterName);
    }

    public Reader getCharacterStream(int parameterIndex) throws SQLException {
        return cstmt.getCharacterStream(parameterIndex);
    }

    public Reader getCharacterStream(String parameterName) throws SQLException {
        return cstmt.getCharacterStream(parameterName);
    }

    public void setBlob(String parameterName, Blob x) throws SQLException {
        setParam(parameterName, x);
        cstmt.setBlob(parameterName, x);
    }

    public void setClob(String parameterName, Clob x) throws SQLException {
        setParam(parameterName, x);
        cstmt.setClob(parameterName, x);
    }

    public void setAsciiStream(String parameterName, InputStream x, long length) throws SQLException {
        setParam(parameterName, x);
        cstmt.setAsciiStream(parameterName, x, length);
    }

    public void setBinaryStream(String parameterName, InputStream x, long length) throws SQLException {
        setParam(parameterName, x);
        cstmt.setBinaryStream(parameterName, x, length);
    }

    public void setCharacterStream(String parameterName, Reader reader, long length) throws SQLException {
        setParam(parameterName, reader);
        cstmt.setCharacterStream(parameterName, reader, length);
    }

    public void setAsciiStream(String parameterName, InputStream x) throws SQLException {
        setParam(parameterName, x);
        cstmt.setAsciiStream(parameterName, x);
    }

    public void setBinaryStream(String parameterName, InputStream x) throws SQLException {
        setParam(parameterName, x);
        cstmt.setBinaryStream(parameterName, x);
    }

    public void setCharacterStream(String parameterName, Reader reader) throws SQLException {
        setParam(parameterName, reader);
        cstmt.setCharacterStream(parameterName, reader);
    }

    public void setNCharacterStream(String parameterName, Reader value) throws SQLException {
        setParam(parameterName, value);
        cstmt.setNCharacterStream(parameterName, value);
    }

    public void setClob(String parameterName, Reader reader) throws SQLException {
        setParam(parameterName, reader);
        cstmt.setClob(parameterName, reader);
    }

    public void setBlob(String parameterName, InputStream inputStream) throws SQLException {
        setParam(parameterName, inputStream);
        cstmt.setBlob(parameterName, inputStream);
    }

    public void setNClob(String parameterName, Reader reader) throws SQLException {
        setParam(parameterName, reader);
        cstmt.setNClob(parameterName, reader);
    }

    protected static final Map<Integer, String> SQL_TYPE_NAMES = new HashMap<Integer, String>();
    static {
        SQL_TYPE_NAMES.put(2003, "<OUT: ARRAY>");
        SQL_TYPE_NAMES.put(-5, "<OUT: BIGINT>");
        SQL_TYPE_NAMES.put(-2, "<OUT: BINARY>");
        SQL_TYPE_NAMES.put(-7, "<OUT: BIT>");
        SQL_TYPE_NAMES.put(2004, "<OUT: BLOB>");
        SQL_TYPE_NAMES.put(16, "<OUT: BOOLEAN>");
        SQL_TYPE_NAMES.put(1, "<OUT: CHAR>");
        SQL_TYPE_NAMES.put(2005, "<OUT: CLOB>");
        SQL_TYPE_NAMES.put(70, "<OUT: DATALINK>");
        SQL_TYPE_NAMES.put(91, "<OUT: DATE>");
        SQL_TYPE_NAMES.put(3, "<OUT: DECIMAL>");
        SQL_TYPE_NAMES.put(2001, "<OUT: DISTINCT>");
        SQL_TYPE_NAMES.put(8, "<OUT: DOUBLE>");
        SQL_TYPE_NAMES.put(6, "<OUT: FLOAT>");
        SQL_TYPE_NAMES.put(4, "<OUT: INTEGER>");
        SQL_TYPE_NAMES.put(2000, "<OUT: JAVA_OBJECT>");
        SQL_TYPE_NAMES.put(-16, "<OUT: LONGNVARCHAR>");
        SQL_TYPE_NAMES.put(-4, "<OUT: LONGVARBINARY>");
        SQL_TYPE_NAMES.put(-1, "<OUT: LONGVARCHAR>");
        SQL_TYPE_NAMES.put(-15, "<OUT: NCHAR>");
        SQL_TYPE_NAMES.put(2011, "<OUT: NCLOB>");
        SQL_TYPE_NAMES.put(0, "<OUT: NULL>");
        SQL_TYPE_NAMES.put(2, "<OUT: NUMERIC>");
        SQL_TYPE_NAMES.put(-9, "<OUT: NVARCHAR>");
        SQL_TYPE_NAMES.put(1111, "<OUT: OTHER>");
        SQL_TYPE_NAMES.put(7, "<OUT: REAL>");
        SQL_TYPE_NAMES.put(2006, "<OUT: REF>");
        SQL_TYPE_NAMES.put(-8, "<OUT: ROWID>");
        SQL_TYPE_NAMES.put(5, "<OUT: SMALLINT>");
        SQL_TYPE_NAMES.put(2009, "<OUT: SQLXML>");
        SQL_TYPE_NAMES.put(2002, "<OUT: STRUCT>");
        SQL_TYPE_NAMES.put(92, "<OUT: TIME>");
        SQL_TYPE_NAMES.put(93, "<OUT: TIMESTAMP>");
        SQL_TYPE_NAMES.put(-6, "<OUT: TINYINT>");
        SQL_TYPE_NAMES.put(-3, "<OUT: VARBINARY>");
        SQL_TYPE_NAMES.put(12, "<OUT: VARCHAR>");

        SQL_TYPE_NAMES.put(-10, "<OUT: CURSOR>");
    }
    protected void setOutParam(Object key, int sqlType) {
        if (conn.getLogParams()) {
            String value = SQL_TYPE_NAMES.get(sqlType);
            if (value == null) value = "<OUT: UNKNOWN("+sqlType+")>";
            params.put(key, toRef(value));
        }
    }

}
