/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql.adapters;

import com.bitmechanic.sql.PooledConnection;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * DAL specific implementation
 *
 * @author mkishore
 * @since 2.0.1
 */
public class DALConnectionPoolAdapter extends DefaultConnectionPoolAdapter {
    private static final String CONN_CLASSNAME = "com.wm.dal.jdbc.DALConnection";
    private static Class connClass;
    private static Method validateMethod, cancelMethod, abortMethod, closeMethod;

    static {
        try {
            connClass = Thread.currentThread().getContextClassLoader().loadClass(CONN_CLASSNAME);
            validateMethod = connClass.getMethod("ping");
            cancelMethod = connClass.getMethod("cancel");
            abortMethod = connClass.getMethod("abort");
            closeMethod = connClass.getMethod("reset");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Given a native Connection, the adapter determines if it is valid.
     *
     * @param conn - the native Connection
     * @return True if the native connection is valid.
     * @throws java.sql.SQLException - in case of any errors
     */
    /*
    public boolean isValid(Connection conn) throws SQLException {
        try {
            if (validateMethod != null) {
                return (Integer) validateMethod.invoke(conn) != -1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    */

    /**
     * This method is called when the pool needs to forcibly close a native
     * Connection - e.g. in order to stop a long-running JDBC call being processed
     * on the server. The implementation can assume that the server is reachable and
     * should perform a graceful cleanup. It is expected to perform an immediate
     * (asynchronous) termination of any currently executing operation on this connection.
     *
     * @param conn - the native Connection
     * @throws java.sql.SQLException - in case of any errors
     */
    public void cancelConnection(Connection conn) throws SQLException {
        try {
            if (cancelMethod != null) {
                cancelMethod.invoke(conn);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is called when the pool needs to forcibly close a native
     * Connection - e.g. in order to stop a long-running JDBC call being processed
     * on the server. This method is called after the cancelConnection() method -
     * with a suitable interval between the two method calls. The implementation
     * cannot assume that the server is reachable, and should attempt to do a
     * local client-side cleanup.
     *
     * @param conn - the native Connection
     * @throws java.sql.SQLException - in case of any errors
     */
    public void abortConnection(Connection conn) throws SQLException {
        try {
            if (abortMethod != null) {
                abortMethod.invoke(conn);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is called when the consumer calls close() method on the
     * PooledConnection.
     *
     * @param pconn - the PooledConnection about to be returned to the pool
     * @throws java.sql.SQLException - in case of any errors
     */
    public void onClose(PooledConnection pconn) throws SQLException {
        try {
            if (closeMethod != null) {
                closeMethod.invoke(pconn.getNativeConnection());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
