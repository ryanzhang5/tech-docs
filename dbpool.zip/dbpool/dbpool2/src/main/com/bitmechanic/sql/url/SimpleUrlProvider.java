/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql.url;

import com.bitmechanic.sql.GenericPool;

/**
 * SimpleUrlProvider - takes in a url as the constructor arg, and returns the same every time
 *
 * @author mkishore
 * @since 2.0.3
 */
public class SimpleUrlProvider extends UrlProvider {
    public SimpleUrlProvider(GenericPool pool, String url) {
        super(pool, url);
    }

    public String getUrl() {
        return url;
    }
}
