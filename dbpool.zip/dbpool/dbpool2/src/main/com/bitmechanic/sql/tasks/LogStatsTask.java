/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql.tasks;

import com.bitmechanic.sql.GenericPoolImpl;
import com.bitmechanic.util.DBLogger;

import java.util.TimerTask;

/**
 * LogStatsTask - a timer task that keeps logging the pool stats every so often.
 *
 * @author mkishore
 * @since 2.0.3
 */
public class LogStatsTask extends TimerTask {
    private static final DBLogger _logger = DBLogger.getInstance();

    private GenericPoolImpl pool;

    public LogStatsTask(GenericPoolImpl pool) {
        this.pool = pool;
    }

    public void run() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("ConnectionPool[").append(pool.getAlias())
                .append("] Stats ==> Min Connections[").append(pool.getMinSize())
                //.append("], Opened Connections[").append(pool.size())
                .append("], Active Connections[").append(pool.getActiveClients())
                .append("], Max Connections[").append(pool.getMaxSize())
                .append("], Locked[").append(pool.isLocked())
                .append("], Permanently Disabled[").append(pool.isPoolPermanentlyDisable())
                .append("]");
        _logger.log(_logger.WARNING, buffer.toString());
    }

}