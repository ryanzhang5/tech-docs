package com.bitmechanic.sql;

import com.bitmechanic.sql.adapters.DefaultConnectionPoolAdapter;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectionPoolImpl extends GenericPoolImpl<PooledConnection> implements ConnectionPool {
    
    private String driverName;
    private int prefetchSize = -1;
    private boolean proxy;

    private Driver driver;
    private Properties driverProperties = new Properties();

    private ConnectionPoolAdapter adapter;

    public ConnectionPoolImpl(String alias) {
        super(alias);
    }

    /**
     * Allows the creator to configure the pool from a list of propwerties.
     *
     * @param props - list of properties
     */
    public void configure(Properties props) {
        super.configure(props);

        this.driverName = props.getProperty(PROP_DRIVER_NAME);
        driverProperties.put("user", props.getProperty(PROP_USER));
        driverProperties.put("password", props.getProperty(PROP_PASSWORD));
        this.proxy = "true".equalsIgnoreCase(props.getProperty(PROP_IS_PROXY));

        try {
            //each pool has its own driver instance to avoid synchronization costs
            driver = (Driver) Class.forName(driverName).newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            adapter = new DefaultConnectionPoolAdapter();
            String adapterName = props.getProperty(PROP_ADAPTER);
            if (adapterName == null && url != null) {
                if (url.contains(":oracle:")) {
                    adapterName = "com.bitmechanic.sql.adapters.OracleConnectionPoolAdapter";
                } else if (url.contains(":mysql:")) {
                    adapterName = "com.bitmechanic.sql.adapters.MysqlConnectionPoolAdapter";
                } else if (url.contains(":walmart:")) {
                    adapterName = "com.bitmechanic.sql.adapters.DALConnectionPoolAdapter";
                }
            }
            if (adapterName != null) {
                Class<?> adapterClass = Thread.currentThread().getContextClassLoader().loadClass(adapterName);
                if (ConnectionPoolAdapter.class.isAssignableFrom(adapterClass)) {
                    adapter = (ConnectionPoolAdapter) adapterClass.newInstance();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // TODO: check configuration and throw a RuntimeException
    }

    /**
     * This method calls the super.initialize() and sets up an AbortCounterTask.
     */
    public synchronized void initialize() {
        try {
            super.initialize();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getDriverName() {
        return driverName;
    }

    public int getPrefetchSize() {
        return prefetchSize;
    }

    public void setPrefetchSize(int newPrefetchSize) {
        if (newPrefetchSize > 0) prefetchSize = newPrefetchSize;
        else _logger.log(_logger.WARNING, "Prefetch Size must be greater than Zero...");
    }

    public void lockPool(boolean locked) {
        this.setLocked(locked);
    }

    public boolean poolIsLocked() {
        return this.isLocked();
    }

    public boolean isProxy() {
        return proxy;
    }

    public void setProxy(boolean proxy) {
        this.proxy = proxy;
    }

    public Connection getConnection() throws SQLException {
        return checkout();
    }

    public void returnConnection(PooledConnection conn) throws SQLException {
        checkin(conn);
    }

    public void removeAllConnections() throws SQLException {
        removeAll();
    }

    public void cancelConnection(Connection conn) {
        try {
            adapter.cancelConnection(conn);
        } catch (SQLException e) {
            // ignore
        }
    }

    public void abortConnection(Connection conn) {
        try {
            adapter.abortConnection(conn);
        } catch (SQLException e) {
            // ignore
        }
    }

    public void handleCheckoutTimeout(PooledConnection pconn) {
        super.handleCheckoutTimeout(pconn);
        adapter.onCheckoutTimeout(pconn);
    }

    public void handleIdleTimeout(PooledConnection pconn) {
        super.handleIdleTimeout(pconn);
        adapter.onIdleTimeout(pconn);
    }

    protected PooledConnection onOpen(PooledConnection pconn) throws SQLException {
        adapter.onOpen(pconn);
        // re-initialize the connection to the pool's current config
        pconn.setLogParams(this.getLogParams());
        return pconn;
    }

    protected void onClose(PooledConnection pconn) {
        try {
            adapter.onClose(pconn);
        } catch (SQLException sqle) {
            _logger.log(_logger.WARNING, "ConnectionPool: " + alias + " encountered unexpected exception when executing the onClose event");
            registerException(sqle, pconn);
            sqle.printStackTrace();
        } catch (Exception e) {
            _logger.log(_logger.WARNING, "ConnectionPool: " + alias + " encountered unexpected exception when executing the onClose event");
            e.printStackTrace();
        }
    }

    public void registerException(SQLException e, PooledConnection pconn) {
        adapter.onException(this, pconn, e);
    }

    protected boolean isValid(PooledConnection conn) {
        boolean isvalid = false;
        try {
            isvalid = adapter.isValid(conn.getConnection());
        } catch (SQLException exp) {
            registerException(exp, conn);
            exp.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return isvalid;
    }

    protected PooledConnection doCreate() throws SQLException {
        try {
            return new PooledConnection(driver.connect(urlProvider.getUrl(), driverProperties), this);
        } catch (SQLException e) {
            registerException(e, null);
            throw e;
        }
    }

}
