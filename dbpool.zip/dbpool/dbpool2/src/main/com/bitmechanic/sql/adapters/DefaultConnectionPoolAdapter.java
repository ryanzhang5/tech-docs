/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql.adapters;

import com.bitmechanic.util.DBLogger;
import com.bitmechanic.sql.ConnectionPoolAdapter;
import com.bitmechanic.sql.PooledConnection;
import com.bitmechanic.sql.ConnectionPool;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * DefaultPoolAdapter provides the default implementation for ConnectionPoolAdapter.
 *
 * @author mkishore
 * @since 1.6.1
 */
public class DefaultConnectionPoolAdapter implements ConnectionPoolAdapter {
    protected static final DBLogger _logger = DBLogger.getInstance();
    protected static final int VALIDATION_TIMEOUT = 3; // in seconds

    /**
     * Given a native Connection, the adapter determines if it is valid.
     *
     * @param conn - the native Connection
     * @return True if the native connection is valid.
     * @throws java.sql.SQLException - in case of any errors
     */
    public boolean isValid(Connection conn) throws SQLException {
        try {
            return conn.isValid(VALIDATION_TIMEOUT);
        } catch (SQLException e) {
            return false;
        }
    }

    /**
     * This method is called when the pool needs to forcibly close a native
     * Connection - e.g. in order to stop a long-running JDBC call being processed
     * on the server. The implementation can assume that the server is reachable and
     * should perform a graceful cleanup. It is expected to perform an immediate
     * (asynchronous) termination of any currently executing operation on this connection.
     *
     * @param conn - the native Connection
     * @throws java.sql.SQLException - in case of any errors
     */
    public void cancelConnection(Connection conn) throws SQLException {
        try {
            conn.close();
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }

    /**
     * This method is called when the pool needs to forcibly close a native
     * Connection - e.g. in order to stop a long-running JDBC call being processed
     * on the server. This method is called after the cancelConnection() method -
     * with a suitable interval between the two method calls. The implementation
     * cannot assume that the server is reachable, and should attempt to do a
     * local client-side cleanup.
     *
     * @param conn - the native Connection
     * @throws java.sql.SQLException - in case of any errors
     */
    public void abortConnection(Connection conn) throws SQLException {
        try {
            conn.close();
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }

    /**
     * This method is called before the pool hands off a pooled-connection to
     * a consumer.
     *
     * @param pconn - the PooledConnection about to be handed to a consumer
     * @throws java.sql.SQLException - in case of any errors
     */
    public void onOpen(PooledConnection pconn) throws SQLException {
        try {
            pconn.setAutoCommit(false);
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }

    /**
     * This method is called when the consumer calls close() method on the
     * PooledConnection.
     *
     * @param pconn - the PooledConnection about to be returned to the pool
     * @throws java.sql.SQLException - in case of any errors
     */
    public void onClose(PooledConnection pconn) throws SQLException {
        // no-op
    }

    /**
     * This method is called when the pool encounters a SQLException when
     * trying to perform regular operations like creating a connection,
     * validating it, creating derived objects like Statements etc.
     *
     * @param cpool - the ConnectionPool that encountered the exception
     * @param pconn - the PooledConnection that encountered the exception
     * @param sqle  - the SQLException that was encountered
     */
    public void onException(ConnectionPool cpool, PooledConnection pconn, SQLException sqle) {
        String message = new StringBuffer()
                .append(getClass().getName())
                .append(" : ").append(cpool.getAlias())
                .append(" : code=[").append(sqle.getErrorCode()).append("]")
                .append(", msg=[").append(sqle.getMessage()).append("]")
                .toString();
        _logger.log(_logger.SEVERE, message);
        sqle.printStackTrace();
    }

    /**
     * This method is called before forcibly closing a connection that has been
     * checked out for too long. This method is only meant to perform logging or
     * audit tasks - the connection cleanup is handled separately.
     *
     * @param pconn the PooledConnection about to be closed.
     */
    public void onCheckoutTimeout(PooledConnection pconn) {
        long obtainedTime = System.currentTimeMillis() - pconn.getLastAccess();
        String message = new StringBuffer("ConnectionPool: Warning: found timed-out ")
                .append("\tPoolName: ").append(pconn.getConnectionPool().getAlias())
                .append("\tConnection: ").append(pconn.dumpInfo())
                .append("\n\tlastAccessedTime: ").append(pconn.getLastAccess())
                .append("\n\tconnectionObtainedTime: ").append(obtainedTime)
                .toString();
        _logger.log(_logger.SEVERE, message);
    }

    /**
     * This method is called before forcibly closing a connection that has been
     * idling for too long. This method is only meant to perform logging or
     * audit tasks - the connection cleanup is handled separately.
     *
     * @param pconn the PooledConnection about to be closed.
     */
    public void onIdleTimeout(PooledConnection pconn) {
        String message = new StringBuffer("ConnectionPool: Info: found idle ")
                .append("\tPoolName: ").append(pconn.getConnectionPool().getAlias())
                .append("\n\tlastAccessedTime: ").append(pconn.getLastAccess())
                .toString();
        _logger.log(_logger.WARNING, message);
    }
}
