/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql;

import javax.sql.XAConnection;
import java.sql.SQLException;

/**
 * XAConnectionPool
 *
 * @author mkishore
 * @since 2.0.1
 */
public interface XAConnectionPool extends GenericPool<PooledXAConnection> {
    /**
     * Returns an XAConnection from the pool.
     *
     * @return XAConnection from the pool
     * @throws SQLException in case of any errors
     */
    XAConnection getXAConnection() throws SQLException;

    /**
     * Returns a "borrowed" XA connection back to the pool.
     *
     * @param pxaconn - the "borrowed" xa connection
     * @throws SQLException in case of any errors
     */
    void returnXAConnection(PooledXAConnection pxaconn) throws SQLException;


    public static final String PROP_USER = "user";
    public static final String PROP_PASSWORD = "password";
    public static final String PROP_ADAPTER = "adapter";

}
