/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql.adapters;

import com.bitmechanic.sql.PooledConnection;
import com.bitmechanic.sql.ConnectionPool;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * Oracle specific implementation
 *
 * @author mkishore
 * @since 1.6.1
 */
public class OracleConnectionPoolAdapter extends DefaultConnectionPoolAdapter {
    private static final String CONN_CLASSNAME = "oracle.jdbc.OracleConnection";

    private static Class connClass;
    private static Method cancelMethod, abortMethod, prefetchMethod;

    static {
        try {
            connClass = Thread.currentThread().getContextClassLoader().loadClass(CONN_CLASSNAME);
            cancelMethod = connClass.getMethod("cancel");
            abortMethod = connClass.getMethod("abort");
            prefetchMethod = connClass.getMethod("setDefaultRowPrefetch", Integer.TYPE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Uses Oracle specific Connection.cancel() method.
     *
     * @param conn - the native Connection
     * @throws java.sql.SQLException - in case of any errors
     */
    public void cancelConnection(Connection conn) throws SQLException {
        try {
            if (cancelMethod != null && conn != null) {
                cancelMethod.invoke(conn);
            }
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }

    /**
     * Uses Oracle specific Connection.abort() method.
     *
     * @param conn - the native Connection
     * @throws java.sql.SQLException - in case of any errors
     */
    public void abortConnection(Connection conn) throws SQLException {
        try {
            if (abortMethod != null && conn != null) {
                abortMethod.invoke(conn);
            }
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }

    /**
     * This method is called before the pool hands off a pooled-connection to
     * a consumer.
     *
     * @param pconn - the PooledConnection about to be handed to a consumer
     * @throws java.sql.SQLException - in case of any errors
     */
    public void onOpen(PooledConnection pconn) throws SQLException {
        try {
            int prefetchSize = pconn.getConnectionPool().getPrefetchSize();
            if (prefetchMethod != null && prefetchSize > 0) {
                prefetchMethod.invoke(pconn.getNativeConnection(), prefetchSize);
            }
            pconn.setAutoCommit(false);
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }

    /**
     * This method is called when the pool encounters a SQLException when
     * trying to perform regular operations like creating a connection,
     * validating it, creating derived objects like Statements etc.
     *
     * @param cpool - the ConnectionPool that encountered the exception
     * @param pconn - the PooledConnection that encountered the exception
     * @param sqle  - the SQLException that was encountered
     */
    public void onException(ConnectionPool cpool, PooledConnection pconn, SQLException sqle) {
        super.onException(cpool, pconn, sqle);

        int errorCode = sqle.getErrorCode();
        // check the error against known hard oracle error codes
        if ((errorCode == 17001)        // Oracle JDBC Internal Error
                // || (errorCode == 17002) // Io Exception // commented out as this was causing repeated 30 second outages in PROD
                || (errorCode == 17090) // Operation not allowed - As per Jack Hsu, DBA this implies some DB resource (sqle.g archive space)exhausted
                || (errorCode == 1034)  // Oracle Unavailable
                || (errorCode == 1012)  // Not logged on
                || (errorCode == 28)    // session killed
                || (sqle.getMessage().startsWith("Protocol violation"))) {
            cpool.setHealth(false);
        } else if ((errorCode == 1005)  // null password given; logon denied
                || (errorCode == 1017)  // invalid username/password; logon denied
                || (errorCode == 28000) // account is locked
                ) {
            cpool.setHealth(false);
            cpool.setPoolPermanentlyDisable(true, errorCode, sqle.getMessage());
        } else if (errorCode == 1460) { // "unreasonable conversion" - causes "invalid cursor" for subsequent requests 
            // cpool.forceRemove(pconn, 0); // commented out after we applied an Oracle patch to fix this in the database
        }

    }
}
