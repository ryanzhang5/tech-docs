package com.bitmechanic.sql;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.*;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.Map;
import java.lang.ref.SoftReference;

public class PooledPreparedStatement extends PooledStatement implements PreparedStatement {
    private PreparedStatement pstmt;
    protected String baseSQL;
    protected Map<Object, SoftReference> params = new LinkedHashMap<Object, SoftReference>();

    public PooledPreparedStatement(PreparedStatement stmt, String sql, PooledConnection conn) {
        super(stmt, conn);
        this.pstmt = stmt;
        this.baseSQL = sql;
    }

    /**
     * ***********************************************************************
     * <p/>
     * PreparedStatment methods
     * <p/>
     * ************************************************************************
     */
    public void addBatch() throws SQLException {
        lastSQL = baseSQL;
        pstmt.addBatch();
    }

    @Override
    public void clearBatch() throws SQLException {
        params.clear();
        super.clearBatch();
    }

    public void clearParameters() throws SQLException {
        params.clear();
        pstmt.clearParameters();
    }

    public boolean execute() throws SQLException {
    	    long start = System.currentTimeMillis();
        try {
            lastSQL = baseSQL;
            boolean rv = pstmt.execute();
            DBBench.logTime(baseSQL, (System.currentTimeMillis() - start), getParams(), conn.getConnectionPool().isProxy());
            return rv;
        } catch (SQLException e) {
            DBBench.logTime("Errored SQL: " + baseSQL, (System.currentTimeMillis() - start), getParams(), conn.getConnectionPool().isProxy());
            conn.registerException(e);
            throw e;
        }
    }

    public ResultSet executeQuery() throws SQLException {
            long start = System.currentTimeMillis();
        try {
            lastSQL = baseSQL;
            ResultSet rv = pstmt.executeQuery();
            DBBench.logTime(baseSQL, (System.currentTimeMillis() - start), getParams(), conn.getConnectionPool().isProxy());
            return rv;
        } catch (SQLException e) {
       	    DBBench.logTime("Errored SQL: " + baseSQL, (System.currentTimeMillis() - start), getParams(), conn.getConnectionPool().isProxy());
            conn.registerException(e);
            throw e;
        }

    }

    public int executeUpdate() throws SQLException {
    	    long start = System.currentTimeMillis();
        try {
            lastSQL = baseSQL;
            int rv = pstmt.executeUpdate();
            DBBench.logTime(baseSQL, (System.currentTimeMillis() - start), getParams(), conn.getConnectionPool().isProxy());
            return rv;
        } catch (SQLException e) {
            DBBench.logTime("Errored SQL: " + baseSQL, (System.currentTimeMillis() - start), getParams(), conn.getConnectionPool().isProxy());
            conn.registerException(e);
            throw e;
        }
    }

    public ResultSetMetaData getMetaData() throws SQLException {
        return pstmt.getMetaData();
    }

    public ParameterMetaData getParameterMetaData() throws SQLException {
        return pstmt.getParameterMetaData();
    }

    public void setArray(int i, Array x) throws SQLException {
        setParam(i, x);
        pstmt.setArray(i, x);
    }

    public void setAsciiStream(int parameterIndex, InputStream x, int length) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setAsciiStream(parameterIndex, x, length);
    }

    public void setBigDecimal(int parameterIndex, BigDecimal x) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setBigDecimal(parameterIndex, x);
    }

    public void setBinaryStream(int parameterIndex, InputStream x, int length) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setBinaryStream(parameterIndex, x, length);
    }

    public void setBlob(int i, Blob x) throws SQLException {
        setParam(i, x);
        pstmt.setBlob(i, x);
    }

    public void setBoolean(int parameterIndex, boolean x) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setBoolean(parameterIndex, x);
    }

    public void setByte(int parameterIndex, byte x) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setByte(parameterIndex, x);
    }

    public void setBytes(int parameterIndex, byte[] x) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setBytes(parameterIndex, x);
    }

    public void setCharacterStream(int parameterIndex, Reader reader, int length) throws SQLException {
        setParam(parameterIndex, reader);
        pstmt.setCharacterStream(parameterIndex, reader, length);
    }

    public void setClob(int i, Clob x) throws SQLException {
        setParam(i, x);
        pstmt.setClob(i, x);
    }

    public void setDate(int parameterIndex, Date x) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setDate(parameterIndex, x);
    }

    public void setDate(int parameterIndex, Date x, Calendar cal) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setDate(parameterIndex, x, cal);
    }

    public void setDouble(int parameterIndex, double x) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setDouble(parameterIndex, x);
    }

    public void setFloat(int parameterIndex, float x) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setFloat(parameterIndex, x);
    }

    public void setInt(int parameterIndex, int x) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setInt(parameterIndex, x);
    }

    public void setLong(int parameterIndex, long x) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setLong(parameterIndex, x);
    }

    public void setNull(int parameterIndex, int sqlType) throws SQLException {
        setParam(parameterIndex, null);
        pstmt.setNull(parameterIndex, sqlType);
    }

    public void setNull(int parameterIndex, int sqlType, String typeName) throws SQLException {
        setParam(parameterIndex, null);
        pstmt.setNull(parameterIndex, sqlType, typeName);
    }

    public void setObject(int parameterIndex, Object x) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setObject(parameterIndex, x);
    }

    public void setObject(int parameterIndex, Object x, int targetSqlType) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setObject(parameterIndex, x, targetSqlType);
    }

    public void setObject(int parameterIndex, Object x, int targetSqlType, int scale) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setObject(parameterIndex, x, targetSqlType, scale);
    }

    public void setRef(int i, Ref x) throws SQLException {
        setParam(i, x);
        pstmt.setRef(i, x);
    }

    public void setShort(int parameterIndex, short x) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setShort(parameterIndex, x);
    }

    public void setString(int parameterIndex, String x) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setString(parameterIndex, x);
    }

    public void setTime(int parameterIndex, Time x) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setTime(parameterIndex, x);
    }

    public void setTime(int parameterIndex, Time x, Calendar cal) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setTime(parameterIndex, x, cal);
    }

    public void setTimestamp(int parameterIndex, Timestamp x) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setTimestamp(parameterIndex, x);
    }

    public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setTimestamp(parameterIndex, x, cal);
    }

    public void setUnicodeStream(int parameterIndex, InputStream x, int length) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setUnicodeStream(parameterIndex, x, length);
    }

    public void setURL(int parameterIndex, URL x) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setURL(parameterIndex, x);
    }

    public void setRowId(int parameterIndex, RowId x) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setRowId(parameterIndex, x);
    }

    public void setNString(int parameterIndex, String value) throws SQLException {
        setParam(parameterIndex, value);
        pstmt.setNString(parameterIndex, value);
    }

    public void setNCharacterStream(int parameterIndex, Reader value, long length) throws SQLException {
        setParam(parameterIndex, value);
        pstmt.setNCharacterStream(parameterIndex, value, length);
    }

    public void setNClob(int parameterIndex, NClob value) throws SQLException {
        setParam(parameterIndex, value);
        pstmt.setNClob(parameterIndex, value);
    }

    public void setClob(int parameterIndex, Reader reader, long length) throws SQLException {
        setParam(parameterIndex, reader);
        pstmt.setClob(parameterIndex, reader, length);
    }

    public void setBlob(int parameterIndex, InputStream inputStream, long length) throws SQLException {
        setParam(parameterIndex, inputStream);
        pstmt.setBlob(parameterIndex, inputStream, length);
    }

    public void setNClob(int parameterIndex, Reader reader, long length) throws SQLException {
        setParam(parameterIndex, reader);
        pstmt.setNClob(parameterIndex, reader, length);
    }

    public void setSQLXML(int parameterIndex, SQLXML xmlObject) throws SQLException {
        setParam(parameterIndex, xmlObject);
        pstmt.setSQLXML(parameterIndex, xmlObject);
    }

    public void setAsciiStream(int parameterIndex, InputStream x, long length) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setAsciiStream(parameterIndex, x, length);
    }

    public void setBinaryStream(int parameterIndex, InputStream x, long length) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setBinaryStream(parameterIndex, x, length);
    }

    public void setCharacterStream(int parameterIndex, Reader reader, long length) throws SQLException {
        setParam(parameterIndex, reader);
        pstmt.setCharacterStream(parameterIndex, reader, length);
    }

    public void setAsciiStream(int parameterIndex, InputStream x) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setAsciiStream(parameterIndex, x);
    }

    public void setBinaryStream(int parameterIndex, InputStream x) throws SQLException {
        setParam(parameterIndex, x);
        pstmt.setBinaryStream(parameterIndex, x);
    }

    public void setCharacterStream(int parameterIndex, Reader reader) throws SQLException {
        setParam(parameterIndex, reader);
        pstmt.setCharacterStream(parameterIndex, reader);
    }

    public void setNCharacterStream(int parameterIndex, Reader value) throws SQLException {
        setParam(parameterIndex, value);
       pstmt.setNCharacterStream(parameterIndex, value);
    }

    public void setClob(int parameterIndex, Reader reader) throws SQLException {
        setParam(parameterIndex, reader);
        pstmt.setClob(parameterIndex, reader);
    }

    public void setBlob(int parameterIndex, InputStream inputStream) throws SQLException {
        setParam(parameterIndex, inputStream);
        pstmt.setBlob(parameterIndex, inputStream);
    }

    public void setNClob(int parameterIndex, Reader reader) throws SQLException {
        setParam(parameterIndex, reader);
        pstmt.setNClob(parameterIndex, reader);
    }

    // Logging param values

    protected String getParams() {
        return params.toString();
    }

    protected void setParam(Object key, Object value) {
        if (conn.getLogParams()) {
            params.put(key, toRef(value));
        }
    }

    protected static final int PARAM_VALUE_MAX_LENGTH = 40;
    protected static final Object NULL = new Object() {
        public String toString() {
            return "NULL";
        }
    };
    protected static SoftReference toRef(Object val) {
        return new SoftReference((val != null) ? val : NULL) {
            public String toString() {
                Object ref = this.get();
                if  (ref == null) {
                    return "<GC-ed>"; // garbage-collected before we could log it
                } else if (ref == NULL) {
                    return "<NULL>";
                } else if (ref instanceof String) {
                    return new StringBuilder("'").append(limit((String)ref)).append("'").toString();
                } else if (ref instanceof Number || ref instanceof Boolean || ref instanceof java.util.Date) {
                    return ref.toString();
                } else if (ref instanceof byte[]) {
                    return new StringBuilder("<byte[").append(((byte[])ref).length).append("]>").toString();
                } else if (ref instanceof InputStream) {
                    return "<InputStream>";
                } else if (ref instanceof Reader) {
                    return "<Reader>";
                } else if (ref instanceof Blob) {
                    long length = 0;
                    try {
                        length = ((Blob) ref).length();
                    } catch (SQLException e) {
                        length = -1;
                    }
                    return new StringBuilder("<Blob[").append(length).append("]>").toString();
                } else if (ref instanceof Clob) {
                    long length = 0;
                    try {
                        length = ((Clob) ref).length();
                    } catch (SQLException e) {
                        length = -1;
                    }
                    return new StringBuilder("<Clob[").append(length).append("]>").toString();
                } else if (ref instanceof Array) {
                    String typeName = null;
                    try {
                        typeName = ((Array) ref).getBaseTypeName();
                    } catch (SQLException e) {
                        typeName = "unknown";
                    }
                    return new StringBuilder("<Array[").append(typeName).append("]>").toString();
                } else if (ref instanceof Ref) {
                    String typeName = null;
                    try {
                        typeName = ((Ref) ref).getBaseTypeName();
                    } catch (SQLException e) {
                        typeName = "unknown";
                    }
                    return new StringBuilder("<Ref[").append(typeName).append("]>").toString();
                } else if (ref instanceof RowId) {
                    return "<RowId>";
                } else if (ref instanceof SQLXML) {
                    return "<SQLXML>";
                } else {
                    return limit(ref.toString());
                }
            }
            private String limit(String s) {
                if (s == null) return "";
                if (s.length() <= PARAM_VALUE_MAX_LENGTH) return s;
                return s.substring(0, PARAM_VALUE_MAX_LENGTH) + "..." + (s.length()-PARAM_VALUE_MAX_LENGTH) + " more";
            }
        };
    }

}

