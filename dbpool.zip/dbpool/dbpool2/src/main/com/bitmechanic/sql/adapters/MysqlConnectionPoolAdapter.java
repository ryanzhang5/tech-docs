/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql.adapters;

/**
 * MySQL specific implementation
 *
 * @author mkishore
 * @since 1.6.1
 */
public class MysqlConnectionPoolAdapter extends DefaultConnectionPoolAdapter {
    private static final String CONN_CLASSNAME = "com.mysql.jdbc.Connection";
    private static Class connClass;

    static {
        try {
            connClass = Thread.currentThread().getContextClassLoader().loadClass(CONN_CLASSNAME);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
