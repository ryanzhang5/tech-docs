/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql.adapters;

import com.bitmechanic.sql.XAConnectionPoolAdapter;

import javax.sql.XADataSource;
import java.sql.SQLException;
import java.lang.reflect.Method;

/**
 * MysqlXAConnectionPoolAdapter
 *
 * @author mkishore
 * @since 2.0.1
 */
public class MysqlXAConnectionPoolAdapter implements XAConnectionPoolAdapter {
    private static final String XADS_NAME = "com.mysql.jdbc.jdbc2.optional.MysqlXADataSource";

    private static Class XADS_CLASS = null;
    private static Method SET_URL_METHOD = null;

    static {
        try {
            XADS_CLASS = Thread.currentThread().getContextClassLoader().loadClass(XADS_NAME);
            SET_URL_METHOD = XADS_CLASS.getMethod("setURL", String.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * The adapter is responsible for returning a suitable XADataSource instance.
     *
     * @param url      - the database connection URL
     * @return a suitably configured XADataSource
     * @throws java.sql.SQLException in case of any errors
     */
    public XADataSource getXADataSource(String url) throws SQLException {
        try {
            XADataSource xads = (XADataSource) XADS_CLASS.newInstance();
            SET_URL_METHOD.invoke(xads, url);
            return xads;
        } catch (Exception e) {
            e.printStackTrace();
            throw new SQLException("Could not create vendor specific instance");
        }
    }
}
