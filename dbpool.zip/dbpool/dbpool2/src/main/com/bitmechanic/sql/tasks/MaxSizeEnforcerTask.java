/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql.tasks;

import com.bitmechanic.sql.GenericPoolImpl;
import com.bitmechanic.sql.GenericPooledObject;
import com.bitmechanic.util.DBLogger;

import java.util.TimerTask;
import java.util.List;
  
import com.wm.corelib.config.AppConfig;

/**
 * MaxSizeEnforcerTask - a timer task that automatically shrinks the pool back to max-size.
 *
 * @author mkishore
 * @since 2.0.3
 */
public class MaxSizeEnforcerTask<T extends GenericPooledObject> extends TimerTask {
    private static final DBLogger logger = DBLogger.getInstance();

    private static final int MAX_RETRIES = 3;
    private static final boolean DISABLED = "true".equalsIgnoreCase(AppConfig.getInstance().getProperty("com.wm.sql.dataaccess.maxsizeenforcer.disabled", "false"));

    private GenericPoolImpl<T> pool;

    public MaxSizeEnforcerTask(GenericPoolImpl<T> pool) {
        this.pool = pool;
    }

    public void run() {
        if (DISABLED) return;

        // an addendum: ensure the min size as well
        pool.ensureMinSize();
        
        int cur = pool.size();
        int max = pool.getMaxSize();
        int numToClose = cur - max;
        int retryNum = 1;

        while (numToClose > 0 && retryNum <= MAX_RETRIES) {
            logger.log(DBLogger.INFO, "Enforcing max-size for connection pool [" + pool.getAlias() + "] with max-size [" + max + "] and cur-size [" + (max-numToClose) + "]");
            List<T> list = pool.getElements();
            Object[] array = list.toArray();
            for (int i = 0; numToClose > 0 && i < array.length; i++) {
                Object obj = array[i];
                try {
                    T pobj = (T) obj;
                    if (!pobj.isLocked()) {
                        if (pobj.getLock()) {
                            pool.forceRemove(pobj, 0);
                            numToClose--;
                        }
                    }
                } catch (Exception exp) {
                    // ignore
                }
            }
            retryNum++;
        }
    }
}