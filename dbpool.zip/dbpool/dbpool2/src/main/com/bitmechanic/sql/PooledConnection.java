package com.bitmechanic.sql;

import com.wm.sql.LoggingConnection;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.*;
import java.util.*;
  
import com.wm.corelib.config.AppConfig;

public class PooledConnection extends GenericPooledObject implements Connection, LoggingConnection {
  private Connection _conn;
  private ConnectionPool _pool;
  private boolean cancelled;
  private boolean logParams;

  // [DTC: 9/24/01] We're pooling statements but are not re-using
  // them. Can't think of a reason why this would be beneficial.
  // So, don't pool them. It turns out we are pooling to get DB
  // BENCH numbers, and to automatically close all statements
  // when connection is closed
  

  /** How many statements have been created on this connection */
  int _totalStatements;
  /** How many prepared calls have been created on this connection */
  int _preparedCalls;

  /** How many times to try re-opening a connection before giving up */
  //private static final int closedConnMaxRetry = 3;
  /** How long to wait between re-opening retries, in milliseconds */
  //private static final int closedConnRetryWait = 1000;

  private final Vector<PooledStatement> _openedStmts = new Vector<PooledStatement>();
  
  public PooledConnection(Connection conn, ConnectionPool pool) {
    this._conn = conn;
    this._pool = pool;
    this.logParams = pool.getLogParams();
  }

    public boolean getLogParams() {
        return logParams;
    }

    public void setLogParams(boolean logParams) {
        this.logParams = logParams;
    }

    protected void closeStatement(PooledStatement stmt) {
        _openedStmts.remove(stmt);
    }

    /**
     * Closes all PreparedStatments and CallableStatements
     */
    public void closeStatements() throws SQLException {
        // we are closing statements that might still be opened
        // because of application code errors
        for (int i = _openedStmts.size()-1; i >= 0; i--) {
            try {
                Statement stmt = _openedStmts.elementAt(i);
                if (stmt != null) stmt.close();
            } catch (SQLException e) {
                _pool.registerException(e, this);
                e.printStackTrace();
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }
        _openedStmts.clear();
    }

  public ConnectionPool getConnectionPool() {
    return _pool;
  }

  /**
     * Doesn't actually close the connection, but instead returns itself
     * back to the _pool to be re-used.  However, if you specified maxCheckouts
     * in the constructor, then this *will* close the JDBC Connection and re-open
     * it if the number of checkouts has been exceeded.
     */
  public void close() throws SQLException {
      if (aborted)
        return;
        
    closeStatements();
    _pool.checkin(this);
  }
  
  protected Connection getConnection() throws SQLException {
    return _conn;
  }


  public Connection getNativeConnection() {
    return _conn;
  }

  /**
  * Dump some information about this connection and the statement.
  * This method overrides the one in GenericPooledObject to provide value added
  * information like Suspected SQLs, Statements requested etc.
  */
  public String dumpInfo() {
    StringBuffer sb = new StringBuffer();
    String LS = AppConfig.getInstance().getProperty("line.separator");
    sb.append("\t\tConnection: " + this.toString()+ LS)
        .append("\t\t\tSuspected SQL(s): " + getSuspectedSQLs() + LS)
        .append("\t\t\tStatements Requested: " + this._totalStatements + LS)
        .append("\t\t\tPrepared Calls: " + this._preparedCalls + LS)
        .append("\t\t\tCheckout count: " + this.getCheckoutCount()+ LS)
        .append("\t\t\tLast Checkout: " + getLastAccess() + ": " + new java.util.Date(this.getLastAccess())+ LS)
        .append("\t\t\tLast Checkin : " + getLastCheckin() + ": " + new java.util.Date(getLastCheckin()) + LS)
        .append("\t\t\t" + (isLocked() ? "Connection IS checked out." : "Connection is NOT checked out.") + LS)
        .append("\t\t\tCheckout Stack Trace: ");
   
       if (traceException != null) {
         StringWriter sw = new StringWriter();
         PrintWriter pw = new PrintWriter(sw);
         traceException.printStackTrace(pw);
         sb.append(sw.toString());
       } else {
         sb.append("null");
       }
       
        sb.append(LS);

    return sb.toString();
  }

    private String getSuspectedSQLs() {
        StringBuffer sb = new StringBuffer("[");
        int i = 1;
        for (Iterator iter = this._openedStmts.iterator(); iter.hasNext(); ++i) {
            PooledStatement stmt = (PooledStatement) iter.next();
            if (i == 1) sb.append("\n");
            sb.append("\t\t\t\t" + i + ") " + stmt.getLastSQL() + "\n");
        }
        if (i > 1) sb.append("\t\t\t");
        sb.append("]");
        return sb.toString();
    }


  //////////////////////////////////////////////////////
  // various createStatement signatures
  //////////////////////////////////////////////////////

  // signature 1
  public Statement createStatement() throws SQLException {
    return _createStatement(1, -1, -1, -1);
  }
  
  // signature 2
  public Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException {
    return _createStatement(2, resultSetType, resultSetConcurrency, -1);
  }
  
  // signature 3
  public Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
    return _createStatement(3, resultSetType, resultSetConcurrency, resultSetHoldability);
  }
  
  private Statement _createStatement(int signature, int resultSetType, 
                                     int resultSetConcurrency, int resultSetHoldability) throws SQLException {
    Statement stmt;

    try
    {
      switch(signature)
      {
        case 1:
          stmt = _conn.createStatement();
          break;
        case 2:
          stmt = _conn.createStatement(resultSetType, resultSetConcurrency);
          break;
        case 3:
          stmt = _conn.createStatement(resultSetType, resultSetConcurrency, resultSetHoldability);
          break;
        default:
          throw new RuntimeException("Internal DataAcess error, undefined API called");        
      }
    }
    catch (SQLException e)
    {
      _pool.registerException(e, this);
      throw e;
    }
    
    PooledStatement pstmt = new PooledStatement( stmt, this );
    _openedStmts.addElement( pstmt );
    this._totalStatements++;  
    return pstmt;
  }


  //////////////////////////////////////////////////////
  // various prepareStatement signatures
  //////////////////////////////////////////////////////

  // signature 1
  public PreparedStatement prepareStatement(String sql) throws SQLException {
    return _prepareStatement(1, sql, -1, -1, -1, -1, null, null);
  }

  // signature 2
  public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
    return _prepareStatement(2, sql, resultSetType, resultSetConcurrency, -1, -1, null, null);
  }

  // signature 3
  public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys) throws SQLException {
    return _prepareStatement(3, sql, -1, -1, -1, autoGeneratedKeys, null, null);
  }

  // signature 4
  public PreparedStatement prepareStatement(String sql, int[] columnIndexes) throws SQLException {
    return _prepareStatement(4, sql, -1, -1, -1, -1, columnIndexes, null);
  }

  // signature 5
  public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
    return _prepareStatement(5, sql, resultSetType, resultSetConcurrency, resultSetHoldability, -1, null, null);
  }

  // signature 6
  public PreparedStatement prepareStatement(String sql, String[] columnNames) throws SQLException {
    return _prepareStatement(6, sql, -1, -1, -1, -1, null, columnNames);
  }


  private PreparedStatement _prepareStatement(int signature, 
                                              String sql, 
                                              int resultSetType, 
                                              int resultSetConcurrency,
                                              int resultSetHoldability,
                                              int autoGeneratedKeys,
                                              int[] columnIndexes,
                                              String[] columnNames) throws SQLException {
    PreparedStatement stmt;

    try
    {
      switch(signature)
      {
        case 1:
          stmt = _conn.prepareStatement(sql);
          break;
        case 2:
          stmt = _conn.prepareStatement(sql, resultSetType, resultSetConcurrency);
          break;
        case 3:
          stmt = _conn.prepareStatement(sql, autoGeneratedKeys);
          break;
        case 4:
          stmt = _conn.prepareStatement(sql, columnIndexes);
          break;
        case 5:
          stmt = _conn.prepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
          break;
        case 6:
          stmt = _conn.prepareStatement(sql, columnNames);
          break;
        default:
          throw new RuntimeException("Internal DataAcess error, undefined API called");        
      }
    }
    catch (SQLException e)
    {
      _pool.registerException(e, this);
      throw e;
    }    

    PooledPreparedStatement ppstmt = new PooledPreparedStatement( stmt, sql, this );
    _openedStmts.addElement( ppstmt );
    this._preparedCalls++;   
    return ppstmt;    
  }


  //////////////////////////////////////////////////////
  // various prepareCall signatures
  //////////////////////////////////////////////////////

  // signature 1
  public CallableStatement prepareCall(String sql) throws SQLException {
    return _prepareCall(1, sql, -1, -1, -1);
  }

  // signature 2
  public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
    return _prepareCall(2, sql, resultSetType, resultSetConcurrency, -1);
  }

  // signature 3
  public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
    return _prepareCall(3, sql, resultSetType, resultSetConcurrency, resultSetHoldability);
  }

  private CallableStatement _prepareCall(int signature, 
                                         String sql, 
                                         int resultSetType, 
                                         int resultSetConcurrency,
                                         int resultSetHoldability) throws SQLException {
    CallableStatement stmt;

    try
    {
      switch(signature)
      {
        case 1:
          stmt = _conn.prepareCall(sql);
          break;
        case 2:
          stmt = _conn.prepareCall(sql, resultSetType, resultSetConcurrency);
          break;
        case 3:
          stmt = _conn.prepareCall(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
          break;
        default:
          throw new RuntimeException("Internal DataAcess error, undefined API called");        
      }
    }
    catch (SQLException e)
    {
      _pool.registerException(e, this);
      throw e;
    }    

    PooledCallableStatement pcstmt = new PooledCallableStatement( stmt, sql, this );
    _openedStmts.addElement( pcstmt );
    this._preparedCalls++;   
    return pcstmt;    
  }


  protected void registerException(SQLException e) {
    if (!aborted)
        _pool.registerException(e, this);
  }

    /**
     * This method will call the following methods (in order):
     * - conn.close() - on the caller thread, which generally hangs
     * - conn.cancel() - on one timer
     * - conn.abort() - on another timer
     * - conn = null
     *
     * Please note that the cancel() call returns immediately
     * - causes a SQLException thrown on actual client (the one calling stmt.execute())
     * - causes the conn.close() above to return without any exceptions
     *
     * As per our observations, the executions and resulting socket states are as follows:
     * - cancel (without an abort): TIME_WAIT
     * - cancel and abort: TIME_WAIT - abort is essentially a no-op
     * - abort (without a cancel): [closed]
     */
    public void forceClose() {
        try {
          String cancelTimerName = "ForceClose-Timer-"       + _pool.getAlias() + ":" + (_conn != null ? _conn.hashCode() : "" );
          String abortTimerName  = "ForceClose-Abort-Timer-" + _pool.getAlias() + ":" + (_conn != null ? _conn.hashCode() : "" );
          
            Timer cancelTimer = new Timer(cancelTimerName, true);
            cancelTimer.schedule(new TimerTask() {
                public void run() {
                    if (_conn != null) {
                        try {
                            cancelled = true;
                            _pool.cancelConnection(_conn);
                        } catch (Exception exp) {
                            // ignore 
                        }
                        // do not set conn to null, as we wish to execute abort as well
                    }
                }
            }, SQLUtil.CLOSE_IDLE_CONNECTION_TIMEOUT);

            Timer abortTimer = new Timer(abortTimerName, true);
            abortTimer.schedule(new TimerTask() {
                public void run() {
                    if (_conn != null) {
                        try {
                            aborted = true;
                            _pool.abortConnection(_conn);
                        } catch (Exception exp) {
                            // ignore
                        }
                        _conn = null;
                    }
                }
            }, 2 * SQLUtil.CLOSE_IDLE_CONNECTION_TIMEOUT);

            //if is locked means somebody is using connection so abort it
            if (isLocked()) {
                aborted = true;
            }
            closeStatements();
        } catch (Exception e) {
            // ignore
        }
        try {
            // adding this new for 9.5 - if force closing, try to rollback
            if (_conn != null && !_conn.getAutoCommit()) {
                _conn.rollback();
            }
        } catch (Exception e) {
            // ignore
        }
        try {
            if (_conn != null) {
                _conn.close();
                // if it was cancelled, let it run through abort() as well.
                if (!cancelled) _conn = null;
            }
        } catch (Exception e) {
            // ignore
        }
    }

  /**************************************************************************
   *
   * Proxy all other JDBC calls to actual Connection object
   *
   **************************************************************************/
  public void clearWarnings() throws SQLException {
    _conn.clearWarnings();
  }
 
  public void commit() throws SQLException {
    _conn.commit();
  }
 
  public boolean getAutoCommit() throws SQLException {
    return _conn.getAutoCommit();
  }
 
  public String getCatalog() throws SQLException {
    return _conn.getCatalog();
  }
 
  public int getHoldability() throws SQLException {
    return _conn.getHoldability();
  }
 
  public DatabaseMetaData getMetaData() throws SQLException {
    return _conn.getMetaData();
  }
 
  public int getTransactionIsolation() throws SQLException {
    return _conn.getTransactionIsolation();
  }
 
  public Map<String,Class<?>> getTypeMap() throws SQLException {
    return _conn.getTypeMap();
  }
 
  public SQLWarning getWarnings() throws SQLException {
    return _conn.getWarnings();
  }
 
  public boolean isClosed() throws SQLException {
    return _conn == null || _conn.isClosed();
  }
 
  public boolean isReadOnly() throws SQLException {
    return _conn.isReadOnly();
  }
 
  public String nativeSQL(String sql) throws SQLException {
    return _conn.nativeSQL(sql);
  }
 
  public void releaseSavepoint(Savepoint savepoint) throws SQLException {
    _conn.releaseSavepoint(savepoint);
  }
 
  public void rollback() throws SQLException {
    // assumes that whenever the connection was closed, it was rolled
    // back appropriately, and there is no need to throw an Exception here
    if (_conn != null) {
      _conn.rollback();
    }
  }
 
  public void rollback(Savepoint savepoint) throws SQLException {
    _conn.rollback(savepoint);
  }
 
  public void setAutoCommit(boolean autoCommit) throws SQLException {
    _conn.setAutoCommit(autoCommit);
  }
 
  public void setCatalog(String catalog) throws SQLException {
    _conn.setCatalog(catalog);
  }
 
  public void setHoldability(int holdability) throws SQLException {
    _conn.setHoldability(holdability);
  }
 
  public void setReadOnly(boolean readOnly) throws SQLException {
    _conn.setReadOnly(readOnly);
  }
 
  public Savepoint setSavepoint() throws SQLException {
    return _conn.setSavepoint();
  }
 
  public Savepoint setSavepoint(String name) throws SQLException {
    return _conn.setSavepoint(name);
  }
 
  public void setTransactionIsolation(int level) throws SQLException {
    _conn.setTransactionIsolation(level);
  }
 
  public void setTypeMap(Map<String,Class<?>> map) throws SQLException {
    _conn.setTypeMap(map);
  }

    public Clob createClob() throws SQLException {
        return _conn.createClob();
    }

    public Blob createBlob() throws SQLException {
        return _conn.createBlob();
    }

    public NClob createNClob() throws SQLException {
        return _conn.createNClob();
    }

    public SQLXML createSQLXML() throws SQLException {
        return _conn.createSQLXML();
    }

    public boolean isValid(int timeout) throws SQLException {
        return _conn.isValid(timeout);
    }

    public void setClientInfo(String name, String value) throws SQLClientInfoException {
        _conn.setClientInfo(name, value);
    }

    public void setClientInfo(Properties properties) throws SQLClientInfoException {
        _conn.setClientInfo(properties);
    }

    public String getClientInfo(String name) throws SQLException {
        return _conn.getClientInfo(name);
    }

    public Properties getClientInfo() throws SQLException {
        return _conn.getClientInfo();
    }

    public Array createArrayOf(String typeName, Object[] elements) throws SQLException {
        return _conn.createArrayOf(typeName, elements);
    }

    public Struct createStruct(String typeName, Object[] attributes) throws SQLException {
        return _conn.createStruct(typeName, attributes);
    }

    public <T> T unwrap(Class<T> iface) throws SQLException {
        if (iface != null) {
            return iface.isInstance(this) ?(T)this :_conn.unwrap(iface);
        }
        return null;
    }

    public boolean isWrapperFor(Class<?> iface) throws SQLException {
        if (iface != null) {
            return iface.isInstance(this) ?true :_conn.isWrapperFor(iface);
        }
        return false;
    }
}
