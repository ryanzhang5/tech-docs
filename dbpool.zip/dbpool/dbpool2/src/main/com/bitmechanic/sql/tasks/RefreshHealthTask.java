/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql.tasks;

import com.bitmechanic.sql.GenericPool;
import com.bitmechanic.util.DBLogger;

import java.util.TimerTask;

/**
 * RefreshHealthTask - a timer task that automatically marks a pool healthy after a given duration.
 * DataAccess uses a default value of 2 minutes.
 *
 * @author mkishore
 * @since 2.0.1
 */
public class RefreshHealthTask extends TimerTask {
    private GenericPool pool;

    public RefreshHealthTask(GenericPool pool) {
        this.pool = pool;
    }

    public void run() {
        if (!pool.getHealth()) {
            DBLogger.getInstance().log(DBLogger.SEVERE, " Trying to restore service for connection pool [" + pool.getAlias() + "]");
            pool.setHealth(true);
        }
    }
}
