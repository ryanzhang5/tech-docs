/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql.tasks;

import com.bitmechanic.sql.GenericPoolImpl;
import com.bitmechanic.sql.GenericPooledObject;
import com.bitmechanic.util.DBLogger;

import java.util.TimerTask;
import java.util.List;
import java.util.Iterator;

/**
 * StuckObjectDetector - a timer task that keeps monitoring the pool for objects
 * that have been checked out too long, or have been idle too long.
 * GenericPoolImpl uses a default value of 10 seconds for the frequency.
 *
 * @author mkishore
 * @since 2.0.1
 */
public class StuckObjectDetector<T extends GenericPooledObject> extends TimerTask {
    private static final DBLogger _logger = DBLogger.getInstance();

    private GenericPoolImpl<T> pool;

    public StuckObjectDetector(GenericPoolImpl<T> pool) {
        this.pool = pool;
    }

    public void run() {
        if (pool.isLocked()) return;

        long now = System.currentTimeMillis();
        long checkoutTimeout = now - (pool.getCheckoutTimeoutSeconds() * 1000);
        long idleTimeout = now - (pool.getIdleTimeoutSeconds() * 1000);

        List<T> list = pool.getElements();
        Object[] array = list.toArray();
        for (Object obj : array) {
            try {
                T pobj = (T) obj;
                if (pobj.isLocked()) {
                    if (pobj.getLastAccess() > 0 && pobj.getLastAccess() < checkoutTimeout && pool.getCheckoutTimeoutSeconds() > 0) {
                        pool.handleCheckoutTimeout(pobj);
                    }
                } else if (pobj.getLastAccess() > 0 && pobj.getLastAccess() < idleTimeout && pool.getIdleTimeoutSeconds() > 0 && pool.size() > pool.getMinSize()) {
                    if (pobj.getLock()) {
                        pool.handleIdleTimeout(pobj);
                    }
                }
            } catch (Exception exp) {
                // ignore
            }
        }
    }
}

