/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql;

import javax.sql.XADataSource;
import java.sql.SQLException;

/**
 * XAConnectionPoolAdapter - allows the XA pools to support vendor specific processing.
 *
 * @author mkishore
 * @since 2.0.1
 */
public interface XAConnectionPoolAdapter {
    /**
     * The adapter is responsible for returning a suitable XADataSource instance.
     *
     * @param url - the database connection URL
     * @return a suitably configured XADataSource
     * @throws SQLException in case of any errors
     */
    XADataSource getXADataSource(String url) throws SQLException;
}
