/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql.tasks;

import com.bitmechanic.sql.GenericPooledObject;
import com.bitmechanic.sql.SQLUtil;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * PooledObjectReaper - a shared timer task that queues up the objects to be force-cleaned up.
 * It runs every 10 seconds. All the pools share the same reaper.
 *
 * @author mkishore
 * @since 2.0.1
 */
public class PooledObjectReaper extends TimerTask {
    private static final PooledObjectReaper instance;
    private static final Map<GenericPooledObject, Long> elements = new ConcurrentHashMap<GenericPooledObject, Long>();

    static {
        instance = new PooledObjectReaper();
    }

    /**
     * Construvtor
     */
    private PooledObjectReaper() {
        new Timer("PooledObjectReaper-Timer", true).schedule(this, 5000, SQLUtil.CONNECTION_REAPER_INTERVAL);
    }

    /**
     * Singleton method
     *
     * @return - instance
     */
    public static PooledObjectReaper getInstance() {
        return instance;
    }

    /**
     * Add a pooled object to be reaped (i.e. force cleaned up)
     *
     * @param pobj      - pooled object that needs to be cleaned up
     * @param reapAfter - how long to wait (in milliseconds) before reaping the object
     */
    public void addReapedObject(GenericPooledObject pobj, long reapAfter) {
        elements.put(pobj, System.currentTimeMillis() + reapAfter);
    }

    /**
     * run method
     */
    public synchronized void run() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<GenericPooledObject, Long>> iterator = elements.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<GenericPooledObject, Long> entry = iterator.next();
            if (now >= entry.getValue()) {
                try {
                    iterator.remove();
                    final GenericPooledObject pobj = entry.getKey();
                    Runnable runnable = new Runnable() {
                        public void run() {
                            try {
                                pobj.forceClose();
                            } catch (Exception exp) {
                                exp.printStackTrace();
                            }
                        }
                    };
                    Thread t = new Thread(runnable);
                    t.setDaemon(true);
                    t.start();
                } catch (Exception exp) {
                    exp.printStackTrace();
                }
            }
        }
    }
}
