/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql.tasks;

import com.bitmechanic.sql.GenericPool;
import com.bitmechanic.util.DBLogger;

import java.util.TimerTask;

/**
 * AutoUnlockTask - a timer task that automatically unlocks the pool after a given duration.
 * DataAccess uses a default value of "0", which means we should never auto unlock.
 *
 * @author mkishore
 * @since 2.0.1
 */
public class AutoUnlockTask extends TimerTask {
    private GenericPool pool;

    public AutoUnlockTask(GenericPool pool) {
        this.pool = pool;
    }

    public void run() {
        if (pool.isLocked()) {
            pool.setLocked(false);
            DBLogger.getInstance().log(DBLogger.getInstance().SEVERE, " : AUTO-UNLOCKED POOL " + pool.getAlias() + " after waiting for " + pool.getLockTimeout());
        }
    }
}
