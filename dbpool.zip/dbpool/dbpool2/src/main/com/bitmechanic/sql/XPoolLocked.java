package com.bitmechanic.sql;

/**
 * This exception will be thrown when a connection is requested from a pool
 * that is currently locked
 */
public class XPoolLocked extends RuntimeException {
  public XPoolLocked(String msg) {
    super(msg);
  }
}
