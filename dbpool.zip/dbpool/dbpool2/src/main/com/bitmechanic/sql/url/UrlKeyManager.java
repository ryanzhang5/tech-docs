/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql.url;

import com.bitmechanic.sql.ConnectionPoolManager;
import com.bitmechanic.sql.GenericPool;

import java.util.*;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.util.concurrent.ConcurrentHashMap;
import java.io.*;
import java.sql.SQLException;

/**
 * UrlKeyManager - in-memory source of truth for the pool -> urlKey mapping.
 *
 * @author mkishore
 * @since 2.0.3
 */
public class UrlKeyManager {
    private static final Logger logger = Logger.getLogger(UrlKeyManager.class.toString());

    // injected via constructor
    private File configFile;

    // other properties
    private ConnectionPoolManager connectionPoolManager;
    private long refreshInterval = -1;
    private long lastModified;

    // primary data-structure
    private Map<String,String> urlKeys = new ConcurrentHashMap<String,String>();

    /**
     * Uses the input file to initialize the in-memory mappings, and then saves the
     * in-memory changes to this file (as needed).
     * 
     * @param configFile - the backing config file
     */
    public UrlKeyManager(File configFile) {
        this.configFile = configFile;
    }

    /**
     * Loads up the pool -> urlKey mapping from the given config file, and sets up a timer
     * to reload on change.
     */
    public void initialize() {
        logger.info("Initializing the UrlKeyManager, with configFile = " + configFile);
        refresh();
        TimerTask task = new TimerTask() {
            public void run() {
                refreshIfNeeded();
            }
        };
        Timer refreshTimer = new Timer("UrlKeyManager.refreshTimer", true);
        if (refreshInterval > 0) refreshTimer.schedule(task, refreshInterval);
    }

    /**
     * Returns the url_key corresponding to the input pool_alias. Will return null if
     * the pool does not have a url_key mapping.
     *
     * @param pool - the pool alias
     * @return - the url_key
     */
    public String getUrlKey(String pool) {
        return urlKeys.get(pool);
    }

    /**
     * Returns a copy of the underlying map that stores the pool_alias to url_key mapping.
     *
     * @return a copy of the underlying map
     */
    public Map<String,String> getUrlKeys() {
        return new HashMap<String,String>(urlKeys);
    }

    /**
     * Replaces the contents of the underlying map with the contents of the input map.
     * If the input mappings are not exactly the same as the current mappings, this
     * method will save the new mappings to the configFile.
     *
     * @param urlKeys - the input map of pool -> url_key mapping
     */
    public void setUrlKeys(Map<String,String> urlKeys) {
        if (urlKeys == null) urlKeys = new HashMap<String,String>();
        if (doSetUrlKeys(urlKeys)) {
            save();
        }
    }

    /**
     * Replaces the contents of the underlying map with the contents of the input map.
     * Returns true if any of the pool -> urlKey mappings are changed.
     *
     * @param newUrlKeys - the input map of pool -> url_key mapping
     * @return true if any of the pool -> urlKey mappings are changed
     */
    protected synchronized boolean doSetUrlKeys(Map<String,String> newUrlKeys) {
        List<String> modified = new ArrayList<String>();

        logger.warning("Changing the pool -> url_key mappings. Current mappings: " + urlKeys + ", new mappings: " + newUrlKeys);
        for (Map.Entry<String,String> entry : newUrlKeys.entrySet()) {
            String pool = entry.getKey();
            String newUrlKey = entry.getValue();
            if (this.urlKeys.containsKey(pool)) {
                String oldUrlKey = this.urlKeys.get(pool);
                if (newUrlKey == null && oldUrlKey != null) {
                    // removed
                    this.urlKeys.remove(pool);
                    modified.add(pool);
                } else if (newUrlKey != null && !newUrlKey.equals(oldUrlKey)) {
                    // modified
                    this.urlKeys.put(pool, newUrlKey);
                    modified.add(pool);
                }
            } else if (newUrlKey != null) {
                // new addition
                this.urlKeys.put(pool, newUrlKey);
                modified.add(pool);
            }
        }

        for (Map.Entry<String,String> entry : this.urlKeys.entrySet()) {
            String pool = entry.getKey();
            if (!newUrlKeys.containsKey(pool)) {
                // removal
                this.urlKeys.remove(pool);
                modified.add(pool);
            }
        }

        logger.warning("Recycling the pools that have had their url_key mapping changed: " + modified);
        if (connectionPoolManager != null) {
            for (String pool : modified) {
                try {
                    GenericPool poolObj = connectionPoolManager.getGenericPool(pool);
                    if (poolObj != null) {
                        logger.info("Recycling the pool: " + pool);
                        poolObj.removeAll();
                    }
                } catch (SQLException e) {
                    logger.log(Level.INFO, "Encountered some exceptions while recycling connections", e);
                }
            }
        }

        return !modified.isEmpty();
    }

    /**
     * Checks the file timestamp against the last time we loaded it, and refreshes if needed
     */
    protected void refreshIfNeeded() {
        if (configFile == null || !configFile.isFile() || !configFile.exists() || !configFile.canRead()) return;

        if (configFile.lastModified() != lastModified) {
            refresh();
        }
    }

    /**
     * Reloads the pool -> url_key mapping from the given file.
     */
    protected void refresh() {
        if (configFile == null || !configFile.isFile() || !configFile.exists() || !configFile.canRead()) return;

        logger.warning("Refreshing the pool -> url_key mappings from: " + configFile);
        BufferedReader in = null;
        try {
            Map<String,String> tempMap = new HashMap<String,String>();
            in = new BufferedReader(new FileReader(configFile));
            String line;
            while ((line = in.readLine()) != null) {
                int ndx = line.indexOf('=');
                if (ndx > 0 && ndx < line.length()-1) {
                    // i.e. add it only if it has a valid pool and urlKey
                    tempMap.put(line.substring(0, ndx), line.substring(ndx+1));
                }
            }
            doSetUrlKeys(tempMap);
            lastModified = configFile.lastModified();
        } catch (Exception e) {
            logger.log(Level.WARNING, "Error loading the pool -> url_key mapping from: " + configFile, e);
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    logger.info("Error closing the configFile: " + configFile + " after reading the pool -> url_key mappings - " + e.getMessage());
                }
            }
        }
    }

    /**
     * Saves the pool -> url_key mapping to the given file.
     */
    protected void save() {
        if (configFile == null || (configFile.exists() && (!configFile.isFile() || !configFile.canWrite()))) return;

        logger.warning("Saving the pool -> url_key mappings " + urlKeys + " to: " + configFile);
        PrintWriter out = null;
        try {
            out = new PrintWriter(new FileWriter(configFile));
            Map<String,String> sortedMap = new TreeMap<String,String>(urlKeys);
            for (String pool : sortedMap.keySet()) {
                String urlKey = sortedMap.get(pool);
                out.print(pool);
                out.print('=');
                out.print(urlKey);
                out.println();
            }
            out.flush();
        } catch (Exception e) {
            logger.log(Level.WARNING, "Error saving the pool -> url_key mappings to: " + configFile, e);
        } finally {
            if (out != null) {
                out.close();
            }
        }
        lastModified = configFile.lastModified();
    }

    // GETTERS and SETTERS

    /**
     * Sets the parent connection pool manager - which will be used to lookup the pools
     * to recycle when their urlKeys change.
     *
     * @param connectionPoolManager - connection pool manager
     */
    public void setConnectionPoolManager(ConnectionPoolManager connectionPoolManager) {
        this.connectionPoolManager = connectionPoolManager;
    }

    /**
     * Sets the refresh interval for the timer that keeps checking the config file for
     * any changes. Setting this to -1 will disable the timer.
     * 
     * @param refreshInterval - refresh interval
     */
    public void setRefreshInterval(long refreshInterval) {
        this.refreshInterval = refreshInterval;
    }

    /**
     * Returns the config file
     *
     * @return the config file
     */
    public File getConfigFile() {
        return configFile;
    }

    /**
     * Returns the last modified timestamp
     *
     * @return the last modified timestamp
     */
    public long getLastModified() {
        return lastModified;
    }
}
