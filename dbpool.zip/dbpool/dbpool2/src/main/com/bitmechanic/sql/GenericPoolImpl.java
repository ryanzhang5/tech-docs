/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql;

import com.bitmechanic.util.DBLogger;
import com.bitmechanic.sql.tasks.*;
import com.bitmechanic.sql.url.UrlProvider;
import com.wm.sql.XRuntimeSQL;

import java.util.*;
import java.util.concurrent.Semaphore;
import java.sql.SQLException;
  
import com.wm.corelib.config.AppConfig;

/**
 * GenericPoolImpl - base class for pool implementations.
 *
 * @author mkishore
 * @since 2.0.1
 */
public abstract class GenericPoolImpl<T extends GenericPooledObject> implements GenericPool<T> {
    protected static final DBLogger _logger = DBLogger.getInstance();
    protected ConnectionPoolManager connectionPoolManager;
    protected UrlProvider urlProvider;

    protected String alias;
    protected String url;
    protected int minSize = 1;
    protected int maxSize;
    protected int maxCheckout;
    protected int maxCheckoutTimeOutInMinutes = 0;

    protected volatile int numRequests;

    protected boolean locked;
    protected boolean health = true;
    protected boolean poolPermanentlyDisable;
    // supporting variables for poolPermanentlyDisable
    protected int errorNo;
    protected String errorMsg;

    protected boolean tracing;
    protected boolean logParams;
    protected long lockTimeout;
    protected int maxWaitTimeout;
    protected int maxWaitClient;
    protected long retryInterval = 120 * 1000;
    protected int checkoutTimeoutSeconds;
    protected int idleTimeoutSeconds;

    protected final List<T> elements = Collections.synchronizedList(new ArrayList<T>());
    
    private Semaphore semaphore;
    private Timer lockTimeoutTimer;

    /**
     * The lone constructor requires the immutable alias property.
     *
     * @param alias - the name of the pool
     */
    public GenericPoolImpl(String alias) {
        this.alias = alias;
    }

    /**
     * Allows the creator to configure the pool from a list of propwerties.
     *
     * @param props - list of properties
     */
    public void configure(Properties props) {
        this.setUrl(props.getProperty(PROP_URL));
        this.setMinSize(getInt(props, PROP_MIN_SIZE));
        this.setMaxSize(getInt(props, PROP_MAX_SIZE));
        this.setMaxCheckout(getInt(props, PROP_MAX_CHECKOUT));
        this.setCheckoutTimeoutSeconds(getInt(props, PROP_CHECKOUT_TIMEOUT_SECONDS));
        this.setIdleTimeoutSeconds(getInt(props, PROP_IDLE_TIMEOUT_SECONDS));
        this.setRetryInterval(getLong(props, PROP_RETRY_INTERVAL));
        this.setLockTimeout(getLong(props, PROP_LOCK_TIMEOUT));
        this.setMaxWaitClient(getInt(props, PROP_MAX_WAIT_CLIENT));
        this.setMaxWaitTimeout(getInt(props, PROP_MAX_WAIT_TIMEOUT));
        if ( props.getProperty(PROP_MAX_CHECKOUT_IN_MINUTES) != null )  {
            this.setMaxCheckoutTimeOutInMinutes(getInt(props, PROP_MAX_CHECKOUT_IN_MINUTES));
        }
        this.setLogParams(getBoolean(props, PROP_LOG_PARAMS));
    }

    /**
     * This method sets up StuckObjectDetector and ensures that the pool starts up with the minimum
     * number of objects. The subclass constructor needs to call initialize().
     */
    public synchronized void initialize() {
        try {
            new Timer("StuckObjectDetector-Timer-" + getAlias() ,true).schedule(new StuckObjectDetector<T>(this), 10000, SQLUtil.CONNECTION_DETECTOR_INTERVAL); // 10 secs
            new Timer("MaxSizeEnforcerTask-Timer-" + getAlias(), true).schedule(new MaxSizeEnforcerTask<T>(this), 10000, SQLUtil.MAX_SIZE_ENFORCER_INTERVAL); // 1 min
            new Timer("LogStatsTask-Timer-" + getAlias(), true).schedule(new LogStatsTask(this), 10000, SQLUtil.LOG_STATS_INTERVAL); // 5 mins
            ensureMinSize();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Returns the connection pool manager that created this pool.
     *
     * @return the connection pool manager
     */
    public ConnectionPoolManager getConnectionPoolManager() {
        return connectionPoolManager;
    }

    /**
     * Sets the connection pool manager that created this pool.
     *
     * @param connectionPoolManager the connection pool manager
     */
    public void setConnectionPoolManager(ConnectionPoolManager connectionPoolManager) {
        this.connectionPoolManager = connectionPoolManager;
    }

    // GETTERS and SETTERS - in the order they appear in the config file

    /**
     * Returns the name of the pool - needs to be unique for a given pool-manager.
     *
     * @return the name of the pool
     */
    public String getAlias() {
        return alias;
    }

    /**
     * Returns the url for the pool - used in a pool specific way to create the object.
     *
     * @return the url for the pool
     */
    public String getUrl() {
        String providedUrl = (urlProvider != null) ?urlProvider.getUrl() :null;
        return (providedUrl != null) ?providedUrl :url;
    }

    /**
     * Set the url for the pool - used in a pool specific way to create the object.
     *
     * @param url - the url for the pool
     */
    public void setUrl(String url) {
        this.url = url;
        urlProvider = UrlProvider.getInstance(this, url);
    }

    /**
     * Returns the minimum number of objects that will be kept in the pool.
     *
     * @return the minimum number of objects that will be kept in the pool
     */
    public int getMinSize() {
        return minSize;
    }

    /**
     * Returns the minimum number of objects that will be kept in the pool.
     *
     * @param minSize - the minimum number of objects that will be kept in the pool
     */
    public void setMinSize(int minSize) {
        this.minSize = minSize;
    }

    /**
     * Returns the maximum number of objects that will be kept in the pool. Any subsequent
     * requests to the checkout() method will need to wait (and possibly time out).
     *
     * @return the maximum number of objects that will be kept in the pool
     */
    public int getMaxSize() {
        return maxSize;
    }

    /**
     * Returns the maximum number of objects that will be kept in the pool. Any subsequent
     * requests to the checkout() method will need to wait (and possibly time out).
     *
     * @param maxSize - the maximum number of objects that will be kept in the pool
     */
    public void setMaxSize(int maxSize) {
        this.maxSize = maxSize;
    }

    /**
     * Returns the maximum number of times a given object can be checked out. Once past
     * this number, the object will be force-cleaned up.
     * WWW configurations currently allow a maximum of 1000 checkouts.
     *
     * @return the maximum number of times a given object can be checked out
     */
    public int getMaxCheckout() {
        return maxCheckout;
    }

    /**
     * Returns the maximum number of times a given object can be checked out. Once past
     * this number, the object will be force-cleaned up.
     * WWW configurations currently allow a maximum of 1000 checkouts.
     *
     * @param maxCheckout - the maximum number of times a given object can be checked out
     *                    =
     */
    public void setMaxCheckout(int maxCheckout) {
        this.maxCheckout = maxCheckout;
    }

    /**
     * Returns the maximum duration (in seconds) that a client is allowed to keep an
     * object checked out. After the above duration has passed, the object will be automatically
     * cleaned up and removed from the pool.
     *
     * @return the maximum duration (in seconds) that a client is allowed to keep an object checked out
     */
    public int getCheckoutTimeoutSeconds() {
        return checkoutTimeoutSeconds;
    }

    /**
     * Set the maximum duration (in seconds) that a client is allowed to keep an
     * object checked out. After the above duration has passed, the object will be automatically
     * cleaned up and removed from the pool.
     *
     * @param checkoutTimeoutSeconds - the maximum duration (in seconds) that a client is allowed
     *                               to keep an object checked out
     */
    public void setCheckoutTimeoutSeconds(int checkoutTimeoutSeconds) {
        this.checkoutTimeoutSeconds = checkoutTimeoutSeconds;
    }

    /**
     * Returns the maximum duration (in seconds) that a client is allowed to keep an
     * object "idle". After the above duration has passed, the object will be automatically
     * cleaned up and removed from the pool.
     *
     * @return the maximum duration (in seconds) that a client is allowed to keep an object "idle"
     */
    public int getIdleTimeoutSeconds() {
        return idleTimeoutSeconds;
    }

    /**
     * Set the maximum duration (in seconds) that a client is allowed to keep an
     * object "idle". After the above duration has passed, the object will be automatically
     * cleaned up and removed from the pool.
     *
     * @param idleTimeoutSeconds - the maximum duration (in seconds) that a client is allowed
     *                           to keep an object "idle"
     */
    public void setIdleTimeoutSeconds(int idleTimeoutSeconds) {
        this.idleTimeoutSeconds = idleTimeoutSeconds;
    }

    /**
     * Returns the duration (in milliseconds) for which the pool remains marked unhealthy.
     * When the pool is marked unhealthy, it will automatically schedule a timer that will
     * mark the pool healthy after the above duration.
     *
     * @return the duration (in milliseconds) for which the pool remains marked unhealthy
     */
    public long getRetryInterval() {
        return retryInterval;
    }

    /**
     * Returns the duration (in milliseconds) for which the pool remains marked unhealthy.
     * When the pool is marked unhealthy, it will automatically schedule a timer that will
     * mark the pool healthy after the above duration.
     *
     * @param retryInterval - the duration (in milliseconds) for which the pool remains marked unhealthy
     */
    public void setRetryInterval(long retryInterval) {
        this.retryInterval = retryInterval;
    }

    /**
     * Returns the duration (in milliseconds) for which the pool remains locked.
     * When the pool is locked, it will automatically schedule a timer that will
     * unlock the pool after the above duration.
     *
     * @return the duration (in milliseconds) for which the pool remains locked
     */
    public long getLockTimeout() {
        return lockTimeout;
    }

    /**
     * Set the duration (in milliseconds) for which the pool remains locked.
     * When the pool is locked, it will automatically schedule a timer that will
     * unlock the pool after the above duration.
     *
     * @param lockTimeout - the duration (in milliseconds) for which the pool remains locked
     */
    public void setLockTimeout(long lockTimeout) {
        this.lockTimeout = lockTimeout;
    }

    /**
     * Returns the maximum number of clients who can wait for an object to become
     * available (applicable when all the objects have been checked out). Any subequent
     * client will receive a XRuntimeSQL runtime exception.
     *
     * @return - the maximum number of clients who can wait for an object to become available
     */
    public int getMaxWaitClient() {
        return maxWaitClient;
    }

    /**
     * Returns the maximum number of clients who can wait for an object to become
     * available (applicable when all the objects have been checked out). Any subequent
     * client will receive a XRuntimeSQL runtime exception.
     *
     * @param maxWaitClient - the maximum number of clients who can wait for an object to become available
     */
    public void setMaxWaitClient(int maxWaitClient) {
        this.maxWaitClient = maxWaitClient;
        this.semaphore = new Semaphore(maxWaitClient, true);

    }

    /**
     * Returns the duration (in milliseconds) for which the pool will wait when
     * a checkout() calls finds that all the objects are already checked out. If the
     * pool is not able to get an object within this duration, it will throw a
     * XRuntimeSQL runtime exception.
     *
     * @return the duration (in milliseconds)
     */
    public int getMaxWaitTimeout() {
        return maxWaitTimeout;
    }

    /**
     * Set the duration (in milliseconds) for which the pool will wait when
     * a checkout() calls finds that all the objects are already checked out. If the
     * pool is not able to get an object within this duration, it will throw a
     * XRuntimeSQL runtime exception.
     *
     * @param maxWaitTimeout - the duration (in milliseconds)
     */
    public void setMaxWaitTimeout(int maxWaitTimeout) {
        this.maxWaitTimeout = maxWaitTimeout;
    }

    // RUNTIME GETTERS and SETTERS

    /**
     * Returns true if the pool is currently locked.
     *
     * @return true, if the pool is currently locked
     */
    public boolean isLocked() {
        return locked;
    }

    /**
     * Set the locked status of the pool. If locked, any calls to the
     * checkout() method will result in a XPoolLocked runtime exception.
     *
     * @param locked - the lock status to set
     */
    public void setLocked(boolean locked) {
        this.locked = locked;

        try {
            if (lockTimeoutTimer != null) {
                lockTimeoutTimer.cancel();
            }
            if (locked && lockTimeout > 0) {
                String timerName = "LockTimeout-Timer-" + getAlias();
                lockTimeoutTimer = new Timer(timerName, true);
                lockTimeoutTimer.schedule(new AutoUnlockTask(this), lockTimeout);
            }
            if (!locked) {
                ensureMinSize();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Returns true if the pool is healthy.
     *
     * @return true, if the pool is healthy
     */
    public boolean getHealth() {
        return health;
    }

    /**
     * Set the health status of the pool.
     *
     * @param health - the health status to set
     */
    public synchronized void setHealth(boolean health) {
        _logger.log(_logger.SEVERE, getClass() + ": setting connection pool [" + getAlias() + "] to health := " + health);
        //if the timer has already started and trying to set the pool to false again,
        // then we do not need to start it again - just ignore the message
        if (!health && this.health) {
            String timerName = "HealthCheck-Timer-" + getAlias();
            new Timer(timerName, true).schedule(new RefreshHealthTask(this), retryInterval);
        }

        this.health = health;

        if (health) {
            // ensureMinSize() only adds new connections is the pool is healthy
            ensureMinSize();
        } else {
            // removeAll() calls forceClose(), which calls ensureMinSize()
            removeAll();
        }
    }

    /**
     * Returns true if the pool has been marked as permanently disabled.
     *
     * @return true, if the pool is marked as permanently disabled
     */
    public boolean isPoolPermanentlyDisable() {
        return poolPermanentlyDisable;
    }

    /**
     * Set the permanently disabled status of the pool.
     *
     * @param poolPermanentlyDisable - the permanently disabled status of the pool
     * @param errorNo                - a reference error number
     * @param errorMsg               - a descriptive error message
     */
    public void setPoolPermanentlyDisable(boolean poolPermanentlyDisable, int errorNo, String errorMsg) {
        this.poolPermanentlyDisable = poolPermanentlyDisable;
        this.errorNo = errorNo;
        this.errorMsg = errorMsg;
    }

    /**
     * Returns true if the tracing is turned on for the pool.
     *
     * @return true, if the tracing is turned on
     */
    public boolean getTracing() {
        return tracing;
    }

    /**
     * Set the tracing status of the pool.
     *
     * @param tracing - the tracing status to set
     */
    public void setTracing(boolean tracing) {
        this.tracing = tracing;
        _logger.setLevel(tracing ?_logger.INFO :_logger.WARNING);
    }

    /**
     * Returns true if connections from this pool will log parameter values.
     *
     * @return true if connections from this pool will log parameter values.
     */
    public boolean getLogParams() {
        return logParams;
    }

    /**
     * Set true if connections from this pool will log parameter values.
     *
     * @param logParams - true if connections from this pool will log parameter values.
     */
    public void setLogParams(boolean logParams) {
        this.logParams = logParams;
    }

// OTEHR FUNCTIONAL CALLS

    /**
     * Returns the number of objects in the pool.
     *
     * @return the number of objects in the pool
     */
    public int size() {
        return elements.size();
    }

    /**
     * Returns the total number of calls to the checkout() method.
     *
     * @return - the total number of calls to the checkout() method
     */
    public int getNumRequests() {
        return numRequests;
    }

    /**
     * Returns the number of clients waiting to get an object.
     *
     * @return the number of clients waiting to get an object
     */
    public int getQueueSize() {
        return maxWaitClient - semaphore.availablePermits();
    }

    /**
     * Returns a string containing information about the pool and the pooled objects
     * inside it - suitable for general purpose debug statements.
     *
     * @return a string containing information about the pool and the pooled objects
     */
    public String dumpInfo() {
        String LS = AppConfig.getInstance().getProperty("line.separator");
        StringBuffer sb = new StringBuffer();
        sb.append("Pool: " + this.toString() + LS)
                .append("\tAlias: " + this.getAlias() + LS)
                .append("\tMax connections: " + this.getMaxSize() + LS)
                .append("\tURL: " + urlProvider.getUrl() + LS)
                .append("\tCheckouts: " + this.getNumRequests() + LS)
                .append("\t" + (isLocked() ? "Connection pool IS locked." : "Connection pool is NOT locked.") + LS)
                .append("\tConnections currently in pool: " + this.size() + LS)
                .append("\tPool Health: " + this.getHealth() + LS)
                .append("\tAuto re-connect retry interval: " + retryInterval + LS)
                .append("\tLock Timeout is: " + lockTimeout + LS);

        for (T pc : elementsCopy()) {
            if (pc != null) {
                sb.append(pc.dumpInfo());
            }
        }

        return sb.toString();
    }


    /**
     * Returns a string containing information about the pooled objects - suitable for
     * display in a JMX admin console.
     *
     * @return a string containing information about the pooled objects
     */
    public String dumpConnInfo() {
        StringBuffer sb = new StringBuffer();
        sb.append("<connections>\n");

        for (T pc : elementsCopy()) {
            if (pc != null) {
                sb.append("\t<connection info=\"").append(pc.dumpInfo()).append("\"/>\n");
            }
        }

        sb.append("</connections>\n");
        return sb.toString();
    }

    // CORE POOL METHODS

    /**
     * Allows a client to "borrow" an object from the pool.
     *
     * @return the borrowed object
     * @throws SQLException - in case of any errors
     */
    public T checkout() throws SQLException {
        if (locked) throw new XPoolLocked("The connection pool for alias [" + alias + "] is currently locked");

        if (!semaphore.tryAcquire())
            throw new XRuntimeSQL(new SQLException("Queue is full...Please try again later...Queue Size[" + maxWaitClient + "]"));

        try {
            return doCheckout();
        } catch (SQLException sqe) {
            sqe.printStackTrace();
            throw sqe;
        } finally {
            semaphore.release();
        }
    }

    /**
     * Allows a client to return a previously "borrowed" object.
     *
     * @param pooledObject - the previously borrowed object
     */
    public void checkin(T pooledObject) {
        onClose(pooledObject);
        if (this.getMaxCheckoutTimeOutInMinutes() > 0 && ( System.currentTimeMillis()  >= (pooledObject.getCreatedTime() + (this.getMaxCheckoutTimeOutInMinutes() * 60 * 1000))  ) ) {
            _logger.log(_logger.WARNING, "ConnectionPool: " + alias + " connection checked out for [" + this.getMaxCheckoutTimeOutInMinutes() + "] minutes. closing it.");
            forceRemove(pooledObject, 0);
            return;
        } else if (maxCheckout > 0 && pooledObject.getCheckoutCount() >= maxCheckout) {
            _logger.log(_logger.WARNING, "ConnectionPool: " + alias + " connection checked out max # of times[" + maxCheckout + "]. closing it.");
            forceRemove(pooledObject, 0);
            return;
        }
        _logger.log(_logger.INFO, "ConnectionPool: " + alias + " releasing lock and calling notifyAll()");
        pooledObject.releaseLock();
        synchronized (this) {
            notifyAll();
        }
    }

    /**
     * Removes all the objects and marks the pool as healthy. The objects that are
     * currently checked out are given some time (@see SQLUtil.CLOSE_USED_CONNECTION_TIMEOUT)
     * to complete their processing, before attempting a force cleanup.
     */
    public void removeAll() {
        long now = System.currentTimeMillis();

        _logger.log(_logger.INFO, "ConnectionPool: " + alias + " removeAllConnections() called");

        boolean isPoolLocked = isLocked();
        setLocked(true);

        for (int tries = 1; (tries <= 3 && elements.size() > 0); tries++) {
            for (T pobj : elementsCopy()) {
                if (pobj.getCreatedTime() < now) {
                    if (pobj.getLock()) {
                        //remove immidiately if nobody is using
                        forceRemove(pobj, 0);
                        pobj.releaseLock();
                    } else if (tries == 3) {
                        //force-remove on 3rd attempt (even if somebody is using)
                        forceRemove(pobj, SQLUtil.CLOSE_USED_CONNECTION_TIMEOUT);
                        pobj.releaseLock();
                    }
                }
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                // ignore
            }
        }

      // if pools already lock before than do not unlock and wait for unlock message
        if (!isPoolLocked) {
          setLocked(false);
          ensureMinSize();
        }

        synchronized (this) {
            notifyAll();
        }
    }

    // ABSTRACT METHODS - for subclasses

    /**
     * Needs to be implemented by the subclass to create an instance of the object to be pooled.
     *
     * @return an instance of the object to be pooled
     * @throws SQLException in case of any errors
     */
    protected abstract T doCreate() throws SQLException;

    // PROTECTED METHODS - for subclasses (to call or override)

    /**
     * Called to make sure that the pooled object is still valid. The default implementation
     * just checks that it is not null.
     *
     * @param pobj - the pooled object being checked
     * @return true, if the pooled object is still valid
     */
    protected boolean isValid(T pobj) {
        return pobj != null;
    }

    /**
     * Called just before returning the object to a client. The default implementation returns
     * the input object (unmodified).
     *
     * @param pobj - the pooled object being returned to the client
     * @return the pooled object
     * @throws SQLException in case of any errors
     */
    protected T onOpen(T pobj) throws SQLException {
        return pobj;
    }

    /**
     * Called when the client returns an object back to the pool. The default implementation does
     * nothing.
     *
     * @param pobj - the object being returned to the pool
     */
    protected void onClose(T pobj) {
        // no-op
    }

    /**
     * Called whenever the pool needs to get rid of an object forcefully. The subclasses should not
     * normally need to override this. The default implementation removes it from the pool's internal
     * list of objects, and queues a call to the pooled object's forceClose() method
     *
     * @param pobj - the pooled object that needs to be "removed" forcefully
     * @param delay - the duration after which the pooled object's forceRemove() will be called
     */
    public void forceRemove(T pobj, long delay) {
        if (pobj == null) return;
        _logger.log(_logger.INFO, "<ConnectionPool/removeConnection> Removing statements and connection.");
        synchronized (elements) {
            elements.remove(pobj);
        }
        ensureMinSize();

        PooledObjectReaper.getInstance().addReapedObject(pobj, delay);
    }

    // PUBLIC METHODS (non-interface) - for helper classes

    /**
     * Provides access to the underlying list of Pooled Objects.
     *
     * @return the underlying list of pooled objects
     */
    public List<T> getElements() {
        return elements;
    }

    /**
     * Handles the pooled object that has been checked out for too long. The default
     * implementation force-removes the pooled object from the pool.
     *
     * @param pobj - the pooled object that has been checked out for too long
     */
    public void handleCheckoutTimeout(T pobj) {
        forceRemove(pobj, SQLUtil.CLOSE_USED_CONNECTION_TIMEOUT);
    }

    /**
     * Handles the pooled object that has been "idle" out for too long. The default
     * implementation force-removes the pooled object from the pool.
     *
     * @param pobj - the pooled object that has been "idle" for too long
     */
    public void handleIdleTimeout(T pobj) {
        forceRemove(pobj, SQLUtil.CLOSE_IDLE_CONNECTION_TIMEOUT);
    }

    // PRIVATE METHODS

    private T create() throws SQLException {
        if (isPoolPermanentlyDisable()) {
            throw new SQLException("ConnectionPool [" + alias + "] is permanently disable due to Error Code[" + errorNo + "], Message[" + errorMsg + "]");
        }

        if (!getHealth()) {
            throw new SQLException("ConnectionPool [" + alias + "] is un-healthy, will try upon setHealth event triggered..");
        }

        return doCreate();
    }

    public void ensureMinSize() {
        if (size() >= minSize) return;

        if (locked) {
            _logger.log(_logger.WARNING, "ConnectionPool: " + alias + " is locked, could not create minimum connections...");
            return;
        }
        if (!getHealth()) {
            _logger.log(_logger.WARNING, "ConnectionPool: " + alias + " is un-healthy, could not create minimum connections...");
            return;
        }

        try {
            for (int connSize = size(); connSize < minSize; connSize++) {
                _logger.log(_logger.INFO, "ConnectionPool: " + alias + " adding a connection to ensure minSize.");
                T pobj = create();
                synchronized (elements) {
                    elements.add(pobj);
                }
                // notify waiting threads that there is a new connection available in the pool
                synchronized (this) {
                    notifyAll();
                }
            }
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }

    private synchronized T doCheckout() throws SQLException {
        _logger.log(_logger.INFO, "ConnectionPool: " + alias + " getConnection() called");

        numRequests++;

        long waitTime = System.currentTimeMillis() + maxWaitTimeout;

        while (waitTime >= System.currentTimeMillis()) {
            // first, try to get a free connection from the pool
            for (T pobj : elementsCopy()) {
                if (pobj.getLock()) {
                    if (isValid(pobj)) {
                        return onOpen(pobj);
                    } else {
                        _logger.log(_logger.WARNING, "Connection found bad, removing from ConnectionPool [" + alias + "]. Current Size[" + size() + "], Min Size[" + minSize + "], Max Size[" + maxSize + "]");
                        forceRemove(pobj, 0);
                        pobj.releaseLock();
                    }
                }
            }
            _logger.log(_logger.INFO, "ConnectionPool: " + alias + " all connections locked.");

            // then, see if we can create a new connection
            if (size() < maxSize) {
                _logger.log(_logger.WARNING, "ConnectionPool:[" + alias + "] opening new connection. Current Size[" + size() + "], Min Size[" + minSize + "], Max Size[" + maxSize + "]");
                T pobj = create();
                pobj.getLock();
                synchronized (elements) {
                    elements.add(pobj);
                }
                _logger.log(_logger.INFO, "ConnectionPool: " + alias + " finished opening new connection");
                return onOpen(pobj);
            }

            // finally, just wait to be notified about a connection being returned
            try {
                _logger.log(_logger.INFO, "ConnectionPool: " + alias + " pool is full. Calling wait()");
                wait(waitTime - System.currentTimeMillis());
            } catch (InterruptedException e) {
                // ignore
            }

            _logger.log(_logger.INFO, "ConnectionPool: " + alias + " awoken from wait(). Trying to grab an available connection");
        }

        // if everything fails, just throw a runtime exception
        throw new XRuntimeSQL(new SQLException("No free connection in the pool [" + getAlias() + "], timeout occurred, waited for " + maxWaitTimeout + " millis..."));
    }

    protected int getInt(Properties props, String propName) {
        return Integer.parseInt(props.getProperty(propName));
    }

    protected long getLong(Properties props, String propName) {
        return Long.parseLong(props.getProperty(propName));
    }

    protected boolean getBoolean(Properties props, String propName) {
        return Boolean.valueOf(props.getProperty(propName, "false"));
    }

    /**
     * 
     * @return	maxCheckoutTimeOutInMinutes
     */
    public int getMaxCheckoutTimeOutInMinutes() {
        return maxCheckoutTimeOutInMinutes;
    }

    /**
     * 
     * @param maxCheckoutTimeOutInMinutes
     */
    public void setMaxCheckoutTimeOutInMinutes(int maxCheckoutTimeOutInMinutes) {
        this.maxCheckoutTimeOutInMinutes = maxCheckoutTimeOutInMinutes;
    }

    protected List<T> elementsCopy() {
        synchronized(elements) {
            return new ArrayList<T>(elements);
        }
    }

    public int getActiveClients() {
      int activeClients = 0;
      for (T obj : elements) {
        if (obj.isLocked() ) {
            activeClients++;
          } //if
        }//for
        return activeClients;
      }
}
