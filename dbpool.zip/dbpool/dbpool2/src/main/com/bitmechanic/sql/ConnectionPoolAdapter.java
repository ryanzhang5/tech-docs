/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * This allows the pools to support vendor specific processing.
 *
 * @author mkishore
 * @since 1.6.1
 */
public interface ConnectionPoolAdapter {
    /**
     * Given a native Connection, the adapter determines if it is valid.
     *
     * @param conn - the native Connection
     * @return True if the native connection is valid.
     * @throws SQLException - in case of any errors
     */
    public boolean isValid(Connection conn) throws SQLException;

    /**
     * This method is called when the pool needs to forcibly close a native
     * Connection - e.g. in order to stop a long-running JDBC call being processed
     * on the server. The implementation can assume that the server is reachable and
     * should perform a graceful cleanup. It is expected to perform an immediate
     * (asynchronous) termination of any currently executing operation on this connection.
     *
     * @param conn - the native Connection
     * @throws SQLException - in case of any errors
     */
    public void cancelConnection(Connection conn) throws SQLException;

    /**
     * This method is called when the pool needs to forcibly close a native
     * Connection - e.g. in order to stop a long-running JDBC call being processed
     * on the server. This method is called after the cancelConnection() method -
     * with a suitable interval between the two method calls. The implementation
     * cannot assume that the server is reachable, and should attempt to do a
     * local client-side cleanup.
     *
     * @param conn - the native Connection
     * @throws SQLException - in case of any errors
     */
    public void abortConnection(Connection conn) throws SQLException;

    /**
     * This method is called before the pool hands off a pooled-connection to
     * a consumer.
     *
     * @param pconn - the PooledConnection about to be handed to a consumer
     * @throws SQLException - in case of any errors
     */
    public void onOpen(PooledConnection pconn) throws SQLException;

    /**
     * This method is called when the consumer calls close() method on the
     * PooledConnection.
     *
     * @param pconn - the PooledConnection about to be returned to the pool
     * @throws SQLException - in case of any errors
     */
    public void onClose(PooledConnection pconn) throws SQLException;

    /**
     * This method is called when the pool encounters a SQLException when
     * trying to perform regular operations like creating a connection,
     * validating it, creating derived objects like Statements etc.
     *
     * @param cpool - the ConnectionPool that encountered the exception
     * @param pconn - the PooledConnection that encountered the exception
     * @param sqle - the SQLException that was encountered
     */
    public void onException(ConnectionPool cpool, PooledConnection pconn, SQLException sqle);

    /**
     * This method is called before forcibly closing a connection that has been
     * checked out for too long. This method is only meant to perform logging or
     * audit tasks - the connection cleanup is handled separately.
     *
     * @param pconn the PooledConnection about to be closed.
     */
    public void onCheckoutTimeout(PooledConnection pconn);

    /**
     * This method is called before forcibly closing a connection that has been
     * idling for too long. This method is only meant to perform logging or
     * audit tasks - the connection cleanup is handled separately.
     *
     * @param pconn the PooledConnection about to be closed.
     */
    public void onIdleTimeout(PooledConnection pconn);
}
