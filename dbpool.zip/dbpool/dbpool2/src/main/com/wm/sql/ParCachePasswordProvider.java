package com.wm.sql;

import com.bitmechanic.util.DBLogger;
import com.wm.edmz.ParCacheClient;

import java.util.Properties;

public class ParCachePasswordProvider implements PasswordProvider {

    private static final DBLogger _logger = DBLogger.getInstance();

    public String getPassword(String propertyKey, String alias, Properties aliasProps) {
        try {
            String serviceURL = aliasProps.getProperty(propertyKey + "parcacheURL"); // No "." reqd.
            String systemName = aliasProps.getProperty(propertyKey + alias + ".systemname");
            String userName = aliasProps.getProperty(propertyKey + alias + ".username");

            ParCacheClient parCache = new ParCacheClient();
            parCache.setSystemName(systemName);
            parCache.setAccountName(userName);
            parCache.setServiceURL(serviceURL);
            return parCache.getPassword();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
