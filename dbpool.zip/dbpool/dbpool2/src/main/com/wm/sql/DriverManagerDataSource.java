/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.sql;

import com.wm.sql.internal.AbstractDataSource;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Driver;
import java.sql.DriverManager;
import java.util.Properties;

/**
 * DriverManagerDataSource - inspired by the Spring DataSource classes.
 *
 * @author mkishore
 * @since 2.0.1
 */
public class DriverManagerDataSource extends AbstractDataSource implements DataSource {
    private String driverClassName;
    private String url;
    private String username;
    private String password;
    private Properties connectionProperties;

    private Driver driver;

    /**
     * <p>Attempts to establish a connection with the data source that
     * this <code>DataSource</code> object represents.
     *
     * @return a connection to the data source
     * @throws java.sql.SQLException if a database access error occurs
     */
    public Connection getConnection() throws SQLException {
        return getConnection(username, password);
    }

    /**
     * <p>Attempts to establish a connection with the data source that
     * this <code>DataSource</code> object represents.
     *
     * @param username the database user on whose behalf the connection is
     *                 being made
     * @param password the user's password
     * @return a connection to the data source
     * @throws java.sql.SQLException if a database access error occurs
     * @since 1.4
     */
    public Connection getConnection(String username, String password) throws SQLException {
        Properties props = new Properties(getConnectionProperties());
        if (username != null) {
            props.setProperty("user", username);
        }
        if (password != null) {
            props.setProperty("password", password);
        }
        if (driver != null) {
            return driver.connect(url, props);
        } else {
            return DriverManager.getConnection(url, props);
        }
    }

    // GETTERS and SETTERS

    public String getDriverClassName() {
        return driverClassName;
    }

    public void setDriverClassName(String driverClassName) {
        this.driverClassName = driverClassName;
        try {
            Class<?> clazz = Thread.currentThread().getContextClassLoader().loadClass(driverClassName);
            if (Driver.class.isAssignableFrom(clazz)) {
                driver = (Driver) clazz.newInstance();
            } else {
                throw new Exception("The class [" + driverClassName + "] does not implement the Driver interface");
            }
        } catch (Exception e) {
            throw new IllegalArgumentException("Could not load the driver class: " + driverClassName, e);
        }
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Properties getConnectionProperties() {
        return connectionProperties;
    }

    public void setConnectionProperties(Properties connectionProperties) {
        this.connectionProperties = connectionProperties;
    }
}
