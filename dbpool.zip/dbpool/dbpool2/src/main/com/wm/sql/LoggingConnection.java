/*
 * Copyright 2010 Walmart.com. All rights reserved.
 */
package com.wm.sql;

/**
 * LoggingConnection - allows the clients to turn parameter logging on and off
 *
 * @author mkishore
 * @since 2.0.4
 */
public interface LoggingConnection {
    /**
     * Returns true if this connection is currently logging parameter values.
     * @return true if this connection is currently logging parameter values.
     */
    boolean getLogParams();

    /**
     * Set true if this connection is currently logging parameter values.
     * @param logParams - true if this connection is currently logging parameter values.
     */
    void setLogParams(boolean logParams);
}
