package com.wm.sql;

import java.io.PrintStream;
import java.io.Reader;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class RSUtil
  implements com.wm.sql.Constants
{
  static final String DATE_FORMAT_PATTERN = "dd-MMM-yyyy HH:mm";
  static DateFormat df = DateFormat.getDateTimeInstance();
  static {
    df = new SimpleDateFormat(DATE_FORMAT_PATTERN);
  }

  public static long getNonNullTrimmed( ResultSet rs, int colIndex, long defVal ) throws SQLException
  {
    long rv = rs.getLong( colIndex );
    if ( rs.wasNull() )
      return defVal;
    else
      return rv;
  }

  public static double getNonNullTrimmed( ResultSet rs, int colIndex, double defVal ) throws SQLException
  {
    double rv = rs.getDouble( colIndex );
    if ( rs.wasNull() )
      return defVal;
    else
      return rv;
  }

  public static String getNonNullTrimmed( ResultSet rs, int colIndex, String defVal ) throws SQLException
  {
    String rv = rs.getString( colIndex );
    if ( rs.wasNull() )
      return defVal;
    else
      return rv;
  }

  public static java.sql.Date getSqlDate( java.util.Date d )
  {
    return new java.sql.Date( d.getTime() );
  }

  public static String getSqlBoolean( boolean v )
  {
    return v ? SQL_TRUE : SQL_FALSE;
  }

  public static boolean getBoolean( String v )
  {
    return SQL_TRUE.equals( v );
  }

  public static boolean loadBoolean( ResultSet rs, int colIndex) throws SQLException
  {
    return SQL_TRUE.equals(rs.getString(colIndex));
  }

  public static String loadClob( ResultSet rs, int colIndex)
    throws SQLException
  {
   //Clob clob = rs.getClob(colIndex);
   //return loadClob(clob);
   return rs.getString( colIndex );
  }

  public static String loadClob( Clob clob) throws SQLException
  {
    if (clob == null) return null;
    else {
      StringBuffer out = new StringBuffer();
      Reader stream = clob.getCharacterStream();
      char[] cbuf = new char[(int)clob.length()];
      try {
        stream.read(cbuf);
      } catch (java.io.IOException e) { e.printStackTrace(); return null; }
      out.append(cbuf);
      return out.toString();
    }
  }

  public static void printResultSetMetaData( ResultSet rs, PrintStream out )
  {
    try
    {
      ResultSetMetaData md = rs.getMetaData();
      out.println( "==================================================" );
      out.println( "# of columns returned = " + md.getColumnCount() );
      for ( int c = 1; c <= md.getColumnCount(); c++ )
      {
        out.println( "col[" + c + "] -> name = " + md.getColumnName( c ) + 
                                  ", type = " + md.getColumnTypeName( c ) );
      }
      out.println( "==================================================" );
    }
    catch ( SQLException e )
    {
      throw new XRuntimeSQL( e );
    }
  }

}
