
package com.wm.sql;

import com.wm.corelib.jmxadmin.WmtMBean;
import com.wm.corelib.annotation.Description;
import com.wm.corelib.annotation.PName;

public interface DBPoolAdminMBean extends WmtMBean {

    //number of checkouts
    public int getNumRequests();
    //num of connection in pool
    public int getPoolSize();
    //connection url
    public String getConfUrl();
    public long getConfLockTimeout();
    public long getConfRetryInterval();
    public String getConnDump();
    @Description("Is Pool Permanently Disabled")
    public boolean getisPoolPermanentlyDisable();

    @Description("Get Queue Size")
    public int getQueueSize();

    //max connection
    public int getMaxConnection();
    public void setMaxConnection(int maxConn);


    //get traing status
    public boolean getTrace();
    @Description("Modify the pool tracing")
    public void modifyTracing(boolean enableTrace);

    public boolean getLogParams();
    public void setLogParams(boolean logParams);

    public void setMaxWaitTimeout(int maxWaitTimeout);
    public int getMaxWaitTimeout() ;

    public void setMaxWaitClient(int maxWaitClient) ;
    public int getMaxWaitClient() ;

    @Description("Get the connection pool size")    
    public int getMaxSize();
    @Description("Set the connection pool size")
    public void modifyMaxSize(int maxSize);

    //pool locked or not
    public boolean getPoolLock();
    @Description("Lock/Unlock the connection pool")
    public void modifyPoolLock(boolean lock);
    
    //pool health status
    public boolean getHealth();
    @Description("Set connection pool health")
    public void modifyPoolHealth(boolean health);

    @Description("Get Active Clients")
    public int getActiveClients();

}

