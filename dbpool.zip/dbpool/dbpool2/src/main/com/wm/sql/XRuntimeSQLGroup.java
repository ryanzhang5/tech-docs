package com.wm.sql;
import java.sql.SQLException;

/**
*   Iyer - class which represents a XRuntimeSQL from the whole group of pools
*/


public class XRuntimeSQLGroup extends XRuntimeSQL {

  public XRuntimeSQLGroup( SQLException e ) {
    super(e);
  }

}

