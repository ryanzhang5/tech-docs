/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.sql;

import com.wm.sql.internal.AbstractDataSource;

import javax.sql.XAConnection;
import javax.sql.XADataSource;
import java.sql.SQLException;

/**
 * A simple wrapper to expose the DataAccess class as a javax.sql.XADataSource
 *
 * @author mkishore
 * @since 2.0.1
 */
public class DBPoolXADataSource extends AbstractDataSource implements XADataSource {
    private String poolAlias;

    /**
     * Returns the alias of the pool that will be used to get the XAConnection.
     *
     * @return the alias of the pool that will be used to get the XAConnection
     */
    public String getPoolAlias() {
        return poolAlias;
    }

    /**
     * Set the alias of the pool that will be used to get the XAConnection.
     *
     * @param poolAlias - the alias of the pool that will be used to get the XAConnection
     */
    public void setPoolAlias(String poolAlias) {
        this.poolAlias = poolAlias;
    }

    /**
     * Delegates to DataAccess.getInstance().getXAConnection(poolAlias).
     * <p/>
     * Attempts to establish a physical database connection that can be
     * used in a distributed transaction.
     *
     * @return an <code>XAConnection</code> object, which represents a
     *         physical connection to a data source, that can be used in
     *         a distributed transaction
     * @throws java.sql.SQLException if a database access error occurs
     * @throws java.sql.SQLFeatureNotSupportedException
     *                               if the JDBC driver does not support
     *                               this method
     */
    public XAConnection getXAConnection() throws SQLException {
        return DataAccess.getInstance().getXAConnection(poolAlias);
    }

    /**
     * Delegates to this.getXAConnection()
     * <p/>
     * Attempts to establish a physical database connection, using the given
     * user name and password. The connection that is returned is one that
     * can be used in a distributed transaction.
     *
     * @param user     the database user on whose behalf the connection is being made
     * @param password the user's password
     * @return an <code>XAConnection</code> object, which represents a
     *         physical connection to a data source, that can be used in
     *         a distributed transaction
     * @throws java.sql.SQLException if a database access error occurs
     * @throws java.sql.SQLFeatureNotSupportedException
     *                               if the JDBC driver does not support
     *                               this method
     */
    public XAConnection getXAConnection(String user, String password) throws SQLException {
        return this.getXAConnection();
    }

}
