package com.wm.sql;

import java.sql.SQLException;
import java.io.PrintStream;
import java.io.PrintWriter;

/**
*   Class which wraps a java.sql.SQLException into a RuntimeException
*
*   [mchrisman 2001/10/23:  I added a new constructor that
*    lets one save a message.  The code additions are
*    designed so that if the message is null (or the old
*    constructor is used) the old behavior is unchanged.]
*/


public class XRuntimeSQL extends RuntimeException {

  private SQLException _sqe;
  private String _message=null;
  
  public XRuntimeSQL( SQLException e ) {
    super( e.getMessage() );
    _message=null;
    _sqe = e;
  }
  
  public XRuntimeSQL( SQLException e, String message ) {
    super(message);
    _message=message;
    _sqe = e;
  }
  
  public String getMessage() {
    return (_message!=null ? _message : "") + _sqe.getMessage();
  }

  public void printStackTrace() {
    if (_message!=null) System.err.print(_message+" : ");
    _sqe.printStackTrace();
  }

  public void printStackTrace(PrintStream s) {
    if (_message!=null) s.print(_message+" : ");
    _sqe.printStackTrace( s );
  }

  public void printStackTrace(PrintWriter s) {
    if (_message!=null) s.print(_message+" : ");
    _sqe.printStackTrace( s );
  }

  public String toString() {
    return getClass().getName() + (_message!=null ? " : "+_message : "" ) + " : " + _sqe.toString();
  }

  public SQLException getSQLException() {
    return _sqe;
  }
  
  public int getErrorCode() {
      return _sqe.getErrorCode();
  }
}

