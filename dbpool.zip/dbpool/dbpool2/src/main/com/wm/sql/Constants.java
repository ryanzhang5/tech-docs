package com.wm.sql;

public interface Constants {
  
  //
  // Database constants
  //
  public static final String SQL_TRUE         = "Y";
  public static final String SQL_FALSE        = "N";
}
