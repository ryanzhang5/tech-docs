package com.wm.sql;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.util.*;
  
import com.wm.corelib.config.AppConfig;

/**
 * Checks if we are able to make a connection to all the databases configured in the homewarehouse.conf
 */
public class DBTest {
    public static final String POOL_PREFIX = "com.wm.sql.dataaccess.";
    private static final PrintStream logger = System.out;

    private String confFile;
    private List<String> ignoreList = new ArrayList<String>();

    public static void main(String[] args) {
        DBTest test = new DBTest();
        for (String arg : args) {
            if (arg.startsWith("--ignore=")) {
                String ignore = arg.substring("--ignore=".length());
                test.getIgnoreList().addAll(Arrays.asList(ignore.split(",")));
            } else {
                test.setConfFile(arg);
            }
        }
        test.start();
    }

    protected void start() {
        try {
            // load the conf file into system properties
            AppConfig.getInstance().getProperties().load(new FileInputStream(getConfFile()));
        } catch (IOException e) {
            logger.println("Error loading the properties file: " + getConfFile());
            System.exit(1);
        }
        int status = 0;
        String[] pools = AppConfig.getInstance().getProperty(POOL_PREFIX+"aliases").split(",");
        DBTestResult[] results = checkConnectionPools(pools);
        for (int i = 0; i < pools.length; i++) {
            if (results[i] != null) {
                String user = AppConfig.getInstance().getProperty(POOL_PREFIX+pools[i]+".user");
                String url = AppConfig.getInstance().getProperty(POOL_PREFIX+pools[i]+".url");
                logger.println(String.format("%-20s : Connecting to %15s at %s", pools[i], user, url));
                if (results[i].status != DBTestStatus.PASS) {
                    status = 1;
                    logger.println(String.format("%22s ERROR - %s", "", results[i].message));
                }
            }
        }
        System.exit(status);
    }

    public DBTestResult[] checkConnectionPools(String[] pools) {
        DBTestResult[] results = new DBTestResult[pools.length];
        for (int i = 0; i < pools.length; i++) {
            String pool = pools[i];
            if (!ignoreList.contains(pool)) {
                results[i] = checkConnectionPool(pool);
            }
        }
        return results;
    }

    public DBTestResult checkConnectionPool(String pool) {
        DBTestThread t = new DBTestThread(pool);
        try {
            t.setDaemon(true);
            t.start();
            // wait for a maximum of 10 seconds to establish a connection
            t.join(10*1000);
        } catch (Exception e) {
            t.fail(e.getMessage().trim());
        } finally {
            if (t.isAlive()) {
                t.cancel("Timed out while trying to make a connection");
            }
        }
        return t.getResult();
    }

    private static class DBTestThread extends Thread {
        private String pool;
        private DBTestResult result = new DBTestResult();

        public DBTestThread(String pool) {
            this.pool = pool;
        }

        public void run() {
            Connection conn = null;
            try {
                conn = DataAccess.getInstance().getConnection(pool);
                if (this.result.status != DBTestStatus.PASS) return;
                DatabaseMetaData meta = conn.getMetaData();
            } catch (Exception e) {
                this.fail(e.getMessage().trim());
            } finally {
                if (conn != null) try { conn.close(); } catch (Exception e) {}
            }
        }

        public void fail(String message) {
            this.result.status = DBTestStatus.FAIL;
            this.result.message = message;
        }

        public void cancel(String message) {
            this.result.status = DBTestStatus.CANCEL;
            this.result.message = message;
        }

        public DBTestResult getResult() {
            return this.result;
        }
    }

    public static class DBTestResult {
        public DBTestStatus status = DBTestStatus.PASS;
        public String message = "";
    }

    public static enum DBTestStatus {
        PASS, FAIL, CANCEL
    }

    // GETTERS and SETTERS

    public String getConfFile() {
        return confFile;
    }

    public void setConfFile(String confFile) {
        this.confFile = confFile;
    }

    public List<String> getIgnoreList() {
        return ignoreList;
    }

    public void setIgnoreList(List<String> ignoreList) {
        this.ignoreList = ignoreList;
    }

}
