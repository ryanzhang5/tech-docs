/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.sql;

import com.arjuna.ats.internal.jdbc.DynamicClass;
import com.arjuna.ats.internal.jdbc.drivers.modifiers.ModifierFactory;

import javax.sql.XADataSource;
import java.sql.SQLException;
import java.lang.reflect.Method;

/**
 * DBPoolDynamicClass - provides a jboss-ts specific wrapper over DBPoolXADataSource.
 *
 * If using Spring, the configuration will look something like this:
 *     &lt;bean id="ds1" class="org.springframework.jdbc.datasource.DriverManagerDataSource"&gt;
 *       &lt;property name="driverClassName" value="com.arjuna.ats.jdbc.TransactionalDriver"/&gt;
 *       &lt;property name="connectionProperties"&gt;
 *           &lt;props&gt;
 *               &lt;prop key="DYNAMIC_CLASS"&gt;com.wm.sql.DBPoolDynamicClass&lt;/prop&gt;
 *           &lt;/props&gt;
 *       &lt;/property&gt;
 *       &lt;property name="url" value="jdbc:arjuna:poolAlias"/&gt;
 *   &lt;/bean&gt;
 *
 * When the jboss ts framework calls this class for the DataSource, it passes the last portion
 * of the URL, which would correpond to the poolAlias. This class uses that information to suitably
 * create and initialize a DBPoolXADataSource instance.
 *
 * @author mkishore
 * @since 2.0.1
 */
public class DBPoolDynamicClass implements DynamicClass {
    static {
        ModifierFactory.putModifier("MySQL-AB JDBC driver", -1, -1, "com.arjuna.ats.internal.jdbc.drivers.modifiers.firstsql_jndi");
        ModifierFactory.putModifier("Oracle JDBC driver", -1, -1, "com.arjuna.ats.internal.jdbc.drivers.modifiers.oracle_jndi");
    }

    public XADataSource getDataSource(String url) throws SQLException {
        return getDataSource(url, true);
    }

    public XADataSource getDataSource(String url, boolean create) throws SQLException {
        try {
            DBPoolXADataSource xads = new DBPoolXADataSource();
            xads.setPoolAlias(url);
            return xads;
        } catch (Exception e) {
            e.printStackTrace();
            throw new SQLException("Could not create vendor specific instance");
        }
    }

    public void shutdownDataSource(XADataSource xaDataSource) throws SQLException {
        // no-op
    }
}
