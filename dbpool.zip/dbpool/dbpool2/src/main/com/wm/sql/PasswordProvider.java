/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.sql;

import java.util.Properties;

/*
 * PasswordProvider
 *
 * Allows the DataAccess clients to plug in a password provider. 
 *
 * @author pho
 * @since 1.6.0
 */
public interface PasswordProvider {

    /**
     * Get the database password for the given system and user.
     *
     * @param propertyKey	- property key prefix
     * @param alias      	- alias of properties
     * @param aliasProps 	- alias properties
     * @return the database password
     */
    public String getPassword(String propertyKey, String alias, Properties aliasProps);

}
