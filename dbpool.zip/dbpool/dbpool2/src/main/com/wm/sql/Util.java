package com.wm.sql;

import java.sql.*;

public class Util
{
  public static final int MAX_SQL_SET_SIZE = 1000;

  /**
   * This is the state at the very beginning of the list of values.
   */
  private static final int STATE_SET_START = 1;

  /**
   * This is the state when we've just crossed the MAX_SQL_SET_SIZE
   * boundary.
   */
  private static final int STATE_SET_NEW   = 2;

  /**
   * This is the state when we're in the middle of enumerating a list;
   * (i.e., we're not at a set start position.
   */
  private static final int STATE_SET_ENUM  = 3;


  /**
   * XXX: this needs to be overloaded to allow arrays of all the primitives
   * and an Object array.
   */
  public static String generateSafeSet(String fieldName, long[] values)
  {
    int state = STATE_SET_START;
    int prevState = STATE_SET_START;
    StringBuffer out = new StringBuffer();
    if (values != null && values.length > 0) {

      for (int i=0; i<values.length; i++) {
	
	switch (state) {
	case STATE_SET_START:
	  out.append(fieldName + " in (" + values[i]);
	  // ... do state change
	  //
	  // if this is the last element, then we need to close the set.
	  // Otherwise, change state to STATE_SET_ENUM.
	  // (This test will break if MAX_SQL_SET_SIZE is 1.)
	  if ((i + 1) == values.length) 
	    out.append(")");
	  else 
	    state = STATE_SET_ENUM;
	  break;
	case STATE_SET_NEW:
	  out.append(" OR " + fieldName + " in (" + values[i]);
	  // ... do state change
	  //
	  // if this is the last element, then we need to close the set.
	  // Otherwise, change state to STATE_SET_ENUM.
	  // (This test will break if MAX_SQL_SET_SIZE is 1.)
	  // 
	  if ((i + 1) == values.length)
	    out.append(")");
	  else
	    state = STATE_SET_ENUM;
	  break;
	case STATE_SET_ENUM:
	  out.append(", " + values[i]);
	  // ... do state change
	  //
	  // If the next element is either the last element in values,
	  // or the last element in this set, then we need to close the set.
	  if ((i + 1) == values.length
	      || (i + 1) % MAX_SQL_SET_SIZE == 0) {
	    out.append(")");
	    if (((i + 1) % MAX_SQL_SET_SIZE) == 0
		&& ((i + 1) < values.length))
	      // If we're at the end of the current set and there are
	      // still more elements to enumerate, change state to
	      // STATE_SET_NEW.
	      state = STATE_SET_NEW;
	  }
	  break;
	}
      }
    }
    return out.toString();
  }
  
  public static void main(String[] args)
  {
    long[] ids = new long[Integer.parseInt(args[0])];
    for (int i=0; i<ids.length; i++)
    {
      ids[i] = i;
    }
    String ids_list = generateSafeSet("foo", ids);
    System.out.println("ids_list=" + ids_list);

  }

} 

