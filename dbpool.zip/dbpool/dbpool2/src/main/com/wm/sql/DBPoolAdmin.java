package com.wm.sql;


import com.bitmechanic.sql.GenericPool;
import com.wm.corelib.jmxadmin.WmtMBeanImpl;

import javax.management.NotCompliantMBeanException;


public class DBPoolAdmin extends WmtMBeanImpl implements DBPoolAdminMBean {
    private String poolName;

    public DBPoolAdmin(String name) throws NotCompliantMBeanException {
        super(DBPoolAdminMBean.class);
        poolName = name;
        //aPool = getGenericPool(poolName);
    }


    public boolean getHealth() {
        GenericPool aPool = getGenericPool(poolName);
        if (aPool != null) {
            return aPool.getHealth();
        } else {
            return false;
        }
    }

    public boolean getTrace() {
        GenericPool aPool = getGenericPool(poolName);
        if (aPool != null) {
            return aPool.getTracing();
        } else {
            return false;
        }
    }

    public boolean getLogParams() {
        GenericPool aPool = getGenericPool(poolName);
        if (aPool != null) {
            return aPool.getLogParams();
        } else {
            return false;
        }
    }

    public void setLogParams(boolean logParams) {
        GenericPool aPool = getGenericPool(poolName);
        if (aPool != null) {
            aPool.setLogParams(logParams);
        }
    }

    //pool locked or not
    public boolean getPoolLock() {
        GenericPool aPool = getGenericPool(poolName);
        if (aPool != null) {
            return aPool.isLocked();
        } else {
            return false;
        }
    }


    //number of checkouts
    public int getNumRequests() {
        GenericPool aPool = getGenericPool(poolName);
        if (aPool != null) {
            return aPool.getNumRequests();
        } else {
            return 0;
        }
    }

    //num of connection in pool
    public int getPoolSize() {
        GenericPool aPool = getGenericPool(poolName);
        if (aPool != null) {
            return aPool.size();
        } else {
            return 0;
        }
    }

    //max connection
    public int getMaxConnection() {
        GenericPool aPool = getGenericPool(poolName);
        if (aPool != null) {
            return aPool.getMaxSize();
        } else {
            return 0;
        }
    }

    //connection url
    public String getConfUrl() {
        GenericPool aPool = getGenericPool(poolName);
        if (aPool != null) {
            return aPool.getUrl();
        } else {
            return "";
        }
    }

    public long getConfLockTimeout() {
        GenericPool aPool = getGenericPool(poolName);
        if (aPool != null) {
            return aPool.getLockTimeout();
        } else {
            return 0;
        }
    }

    public long getConfRetryInterval() {
        GenericPool aPool = getGenericPool(poolName);
        if (aPool != null) {
            return aPool.getRetryInterval();
        } else {
            return 0;
        }
    }

    public String getConnDump() {
        GenericPool aPool = getGenericPool(poolName);

        if (aPool != null) {
            return aPool.dumpConnInfo();
        } else {
            return "";
        }
    }

    public void modifyTracing(boolean enableTrace) {
        GenericPool pool = getGenericPool(poolName);
        if (pool != null) {
            pool.setTracing(enableTrace);
        }
    }

    public void setMaxWaitTimeout(int maxWaitTimeout) {
        GenericPool aPool = getGenericPool(poolName);
        if (aPool != null) aPool.setMaxWaitTimeout(maxWaitTimeout);
    }

    public int getMaxWaitTimeout() {
        GenericPool aPool = getGenericPool(poolName);
        if (aPool != null) {
            return aPool.getMaxWaitTimeout();
        } else {
            return 0;
        }
    }

    public void setMaxWaitClient(int maxWaitClient) {
        GenericPool aPool = getGenericPool(poolName);
        if (aPool != null) aPool.setMaxWaitClient(maxWaitClient);
    }

    public int getMaxWaitClient() {
        GenericPool aPool = getGenericPool(poolName);
        if (aPool != null) {
            return aPool.getMaxWaitClient();
        } else {
            return 0;
        }
    }

    //max connection
    public void setMaxConnection(int maxConn) {
        GenericPool aPool = getGenericPool(poolName);
        if (aPool != null) {
            aPool.setMaxSize(maxConn);
        }
    }

    private GenericPool getGenericPool(String poolName) {
        try {
            return DataAccess.getInstance().getPoolManager().getGenericPool(poolName);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public int getMaxSize(){
            GenericPool aPool = getGenericPool(poolName);
            if (aPool != null) {
                return aPool.getMaxSize();
            } else {
                return 0;
            }
        }

    public void modifyMaxSize(int maxSize){
            GenericPool aPool = getGenericPool(poolName);
            if (aPool != null && maxSize > 0) {
                aPool.setMaxSize(maxSize);
            } 
        }
                
    public void modifyPoolLock(boolean lock){
            GenericPool aPool = getGenericPool(poolName);
            if (aPool != null ) {
                aPool.setLocked(lock);
            }
        }        

    public void modifyPoolHealth(boolean health){
            GenericPool aPool = getGenericPool(poolName);
            if (aPool != null ) {
                aPool.setHealth(health);
            }
        }        

    public boolean getisPoolPermanentlyDisable(){
            GenericPool aPool = getGenericPool(poolName);
            if (aPool != null ) {
                return aPool.isPoolPermanentlyDisable();
            }
                return false;
        }      

    public int getQueueSize(){
            GenericPool aPool = getGenericPool(poolName);
            if (aPool != null ) {
                return aPool.getQueueSize();
            }
                return 0;
        }      

    public int getActiveClients() {
        GenericPool aPool = getGenericPool(poolName);
        if (aPool != null ) {
            return aPool.getActiveClients();
        }
            return 0;
        }
}
