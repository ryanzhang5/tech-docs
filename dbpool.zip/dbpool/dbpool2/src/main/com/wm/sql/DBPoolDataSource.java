/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.sql;

import com.wm.sql.internal.AbstractDataSource;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * A simple wrapper to expose the DataAccess class as a javax.sql.DataSource
 *
 * @author mkishore
 * @since 1.6.0
 */
public class DBPoolDataSource extends AbstractDataSource implements DataSource {
    private String poolAlias;

    /**
     * Returns the name of the pool-alias that will be used to create the connection
     *
     * @return the name of the pool-alias that will be used to create the connection
     */
    public String getPoolAlias() {
        return this.poolAlias;
    }

    /**
     * Set the name of the pool-alias that will be used to create the connection
     *
     * @param poolAlias - the name of the pool-alias that will be used to create the connection
     */
    public void setPoolAlias(String poolAlias) {
        this.poolAlias = poolAlias;
    }

    /**
     * <p>Attempts to establish a connection using the provided pool-alias.
     *
     * @return a connection to the data source
     * @throws java.sql.SQLException if a database access error occurs
     */
    public Connection getConnection() throws SQLException {
        return DataAccess.getInstance().getConnection(poolAlias);
    }

    /**
     * Same as calling getConnection()
     *
     * @param username - ignored
     * @param password - ignored
     * @return a connection to the data source
     * @throws java.sql.SQLException if a database access error occurs
     */
    public Connection getConnection(String username, String password) throws SQLException {
        return this.getConnection();
    }

}