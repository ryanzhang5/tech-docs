package com.wm.sql;

import com.bitmechanic.sql.*;
import com.bitmechanic.sql.url.UrlKeyManager;
import com.bitmechanic.util.DBLogger;
import com.wm.corelib.jmxadmin.JmxUtil;

import javax.sql.XAConnection;
import javax.sql.DataSource;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import java.lang.reflect.Method;
  
import com.wm.corelib.config.AppConfig;

public class DataAccess {
    private static final DBLogger _logger = DBLogger.getInstance();

    private final Hashtable<String, StringBuffer> _connectionErrorLogs = new Hashtable<String, StringBuffer>();
    private final Hashtable<String, List<String>> _groupsTable = new Hashtable<String, List<String>>();
    private final Hashtable<String, DataSource> _txDataSources = new Hashtable<String, DataSource>();

    private ConnectionPoolManager _poolManager = null;

    private static DataAccess _theInstance = null;

    private static final String _PROP_KEY = "com.wm.sql.dataaccess.";

    private static final String PROP_USE_XA = "useXA";

    public static final String ALIAS_CATALOG = "jdbcpool_catalog";
    public static final String ALIAS_SEARCH = "jdbcpool_search";
    public static final String ALIAS_SESSION = "jdbcpool_session";
    public static final String ALIAS_BMM = "jdbcpool_bmm";
    public static final String ALIAS_CC = "jdbcpool_cc";

    //private static int GET_CONNECTION_RETRIES = 3;
    private static boolean GET_CONNECTION_LOG_ERRORS = true;
    private static final long DEFAULT_RETRY_INTERVAL_MILLIS = 120 * 1000; // 2 minutes
    //private static final long DEFAULT_EXCEPTION_THRESHOLD = 0; // 0 == no threshold
    private static final int DEFAULT_MAX_IDLE_TIMEOUT_SECONDS = 3600;  //14400 seconds - now 1 hour
    private static final int DEFAULT_MAX_CHECKOUT_TIMEOUT_SECONDS = 120;//seconds
    private static final int DEFAULT_LOCK_TIMEOUT_MILLIS = 0;// 0 == never timeout , in millisec.
    private static final int DEFAULT_MAX_WAIT_TIMEOUT_MILLIS = 3000; // 3 seconds
    private static final int DEFAULT_MAX_CLIENT = 400;
    private static final String DEFAULT_EMPTY_PASSWORD_HANDLER = "com.wm.weblib.pci.pwmgr.client.PasswordEncryptionClient";

    // defaults to false
    private static boolean _connectionPoolTracing = Boolean.getBoolean(_PROP_KEY + "connectionPoolTracing");
    // defaults to false
    private static boolean DisableXA = "true".equalsIgnoreCase(AppConfig.getInstance().getProperty(_PROP_KEY + "disableXA", "true"));
    // defaults to DisableXA
    private static boolean DisableXARecovery = "true".equalsIgnoreCase(AppConfig.getInstance().getProperty(_PROP_KEY + "disableXARecovery", String.valueOf(DisableXA)));
    // defaults to true
    public static boolean PrintDBBench = "true".equalsIgnoreCase(AppConfig.getInstance().getProperty(_PROP_KEY + "DBBench", "true"));
    // no default!
    public static String DBBenchFile = AppConfig.getInstance().getProperty(_PROP_KEY + "DBBenchFile");

    static {
        if (!DisableXARecovery) {
            Thread t = new Thread(new Runnable() {
                public void run() {
                    try {
                        // start up the transaction recovery engine
                        // we are not introducing an abstraction for transaction/recovery managers (right now)
                        Class clazz = Class.forName("com.arjuna.ats.arjuna.recovery.RecoveryManager");
                        Method main = clazz.getMethod("main", String[].class);
                        main.invoke(null, new Object[]{ new String[]{"-test"} });
                    } catch (Exception e) {
                        _logger.log(_logger.SEVERE, "Error starting the transaction recovery engine", e);
                    }
                }
            });
            t.setDaemon(true);
            t.start();
        }
    }


  /**
   *
   * @return
   */
    public synchronized static DataAccess getInstance() {
        if (_theInstance == null) {
                _theInstance = new DataAccess();
                try {
                  _theInstance.initializeDataAccess();
                } catch (RuntimeException exp) {
                    _logger.log(_logger.SEVERE, "Pool(s) were not initialized properly due to configuration/database error", exp);
                  }
        }
        
        return _theInstance;
    }

    public synchronized static void setInstance(DataAccess instance) {
        _theInstance = instance;
    }

    /**
     * Iterates over all the pools and closes all connections.
     */
    public void shutdown() {
        _logger.log(_logger.WARNING, "Shutting down all connection pools");
        for (String alias : _poolManager.getPoolNames()) {
            try {
                _logger.log(_logger.WARNING, "Shutting down connection pool: " + alias);
                _poolManager.removePool(alias);
            } catch (Exception e) {
                _logger.log(_logger.WARNING, "Error closing all connections for the pool: " + alias, e);
            }
            _logger.log(_logger.WARNING, "Unregistering MBean for connection pool: " + alias);
            JmxUtil.unRegisterMBean("DBPoolAdmin:name=" + alias);
        }
    }

    public boolean usesXA(String groupAlias) {
        List<String> aliases = _groupsTable.get(groupAlias);
        List<DataSource> list = new ArrayList<DataSource>();
        if (aliases == null || aliases.isEmpty()) {
            return _txDataSources.containsKey(groupAlias);
        } else {
            return _txDataSources.containsKey(aliases.get(0));
        }
    }

    public GenericPool[] getGenericPool(String groupAlias)  throws XRuntimeSQL {
        List<String> aliases = _groupsTable.get(groupAlias);
        List<GenericPool> pools = new ArrayList<GenericPool>();
        if (aliases == null) {
            GenericPool pool = getMemberGenericPool(groupAlias);
            if (pool != null) pools.add(pool);
        } else {
            for (String alias : aliases) {
                GenericPool pool = getMemberGenericPool(alias);
                if (pool != null) pools.add(pool);
            }
        }
        return pools.toArray(new GenericPool[pools.size()]);
    }

    public ConnectionPool[] getConnectionPool(String groupAlias) throws XRuntimeSQL {
        List<String> aliases = _groupsTable.get(groupAlias);
        List<ConnectionPool> pools = new ArrayList<ConnectionPool>();
        if (aliases == null) {
            ConnectionPool pool = getMemberConnectionPool(groupAlias);
            if (pool != null) pools.add(pool);
        } else {
            for (String alias : aliases) {
                ConnectionPool pool = getMemberConnectionPool(alias);
                if (pool != null) pools.add(pool);
            }
        }
        return pools.toArray(new ConnectionPool[pools.size()]);
    }

    public XAConnectionPool[] getXAConnectionPool(String groupAlias) throws XRuntimeSQL {
        List<String> aliases = _groupsTable.get(groupAlias);
        List<XAConnectionPool> pools = new ArrayList<XAConnectionPool>();
        if (aliases == null) {
            XAConnectionPool pool = getMemberXAConnectionPool(groupAlias);
            if (pool != null) pools.add(pool);
        } else {
            for (String alias : aliases) {
                XAConnectionPool pool = getMemberXAConnectionPool(alias);
                if (pool != null) pools.add(pool);
            }
        }
        return pools.toArray(new XAConnectionPool[pools.size()]);
    }

    private DataSource[] getTxDataSources(String groupAlias) throws XRuntimeSQL {
        List<String> aliases = _groupsTable.get(groupAlias);
        List<DataSource> list = new ArrayList<DataSource>();
        if (aliases == null) {
            DataSource ds = _txDataSources.get(groupAlias);
            if (ds != null) list.add(ds);
        } else {
            for (String alias : aliases) {
                DataSource ds = _txDataSources.get(alias);
                if (ds != null) list.add(ds);
            }
        }
        return list.toArray(new DataSource[list.size()]);
    }

    public Connection getConnection(String groupAlias) throws XRuntimeSQL {
        ConnectionPool[] pools = getConnectionPool(groupAlias);
        if (pools.length != 0) {
            // get the Connection from regular connection pools
            return getConnectionFromPools(pools);
        } else {
            // get it from transaction-aware data-source proxies
            Connection conn = null;
            DataSource[] list = getTxDataSources(groupAlias);
            for (DataSource ds : list) {
                try {
                    conn = ds.getConnection();
                    break;
                } catch (SQLException e) {
                    _logger.log(_logger.WARNING, "Error getting a transaction aware datasource connection", e);
                }
            }
            return conn;
        }
    }

    public XAConnection getXAConnection(String groupAlias) throws XRuntimeSQL {
        XAConnectionPool[] pools = getXAConnectionPool(groupAlias);
        return getConnectionFromPools(pools);
    }


    public boolean getConnectionPoolHealth(String groupAlias) {
        GenericPool[] pools = getConnectionPool(groupAlias);
        if (pools.length == 0) pools = getXAConnectionPool(groupAlias);
        for (GenericPool pool : pools) {
            if (pool.getHealth()) return true;
        }
        return false;
    }

    public void flushGetConnectionErrorLog(String groupAlias) {
        List<String> aliases = _groupsTable.get(groupAlias);
        if (aliases == null) aliases = Arrays.asList(groupAlias);
        for (String alias : aliases) {
            _connectionErrorLogs.put(alias, new StringBuffer());
        }
    }

    public StringBuffer[] getConnectionErrorLogs(String groupAlias) {
        List<String> aliases = _groupsTable.get(groupAlias);
        int size = (aliases == null) ? 1 : aliases.size();
        StringBuffer[] logs = new StringBuffer[size];
        if (aliases == null) {
            logs[0] = _connectionErrorLogs.get(groupAlias);
        } else {
            for (int i = 0; i < aliases.size(); i++) {
                logs[i] = _connectionErrorLogs.get(aliases.get(i));
            }
        }
        return logs;
    }

    public void setTracing(String groupAlias, boolean tracing) throws XRuntimeSQL {
        GenericPool[] pools = getConnectionPool(groupAlias);
        if (pools.length == 0) pools = getXAConnectionPool(groupAlias);
        for (GenericPool pool : pools) {
            pool.setTracing(tracing);
        }
    }

    public static void close(ResultSet rs, Statement stmt, Connection conn) {
        // Close rs
        try {
            if (rs != null) rs.close();
            _logger.log(_logger.INFO, "DataAccess.Close(); Closing Resultset");
        } catch (SQLException sqe1) {
            sqe1.printStackTrace();
        } catch (RuntimeException re1) {
            re1.printStackTrace();
        }

        // Close stmt
        try {
            if (stmt != null) stmt.close();
            _logger.log(_logger.INFO, "DataAccess.Close(); Closing Statement");
        } catch (SQLException sqe1) {
            sqe1.printStackTrace();
        } catch (RuntimeException re1) {
            re1.printStackTrace();
        }

        // Close conn
        try {
            if (conn != null) conn.close();
            _logger.log(_logger.INFO, "DataAccess.Close(); Closing Connection");
        } catch (SQLException sqe1) {
            sqe1.printStackTrace();
        }
    }

    public static void close(Statement stmt, Connection conn) {
        close(null, stmt, conn);
    }

    public static void close(Connection conn) {
        close(null, null, conn);
    }

    public static void close(Statement stmt) {
        close(null, stmt, null);
    }

    public static void close(ResultSet rs) {
        close(rs, null, null);
    }

    private DataAccess() {
    }

    /**
     * Method will initialize all connection pools
     */
    private synchronized void initializeDataAccess() {
        try {
            _poolManager = new ConnectionPoolManager();
            _poolManager.setTracing(_connectionPoolTracing);
        } catch (Exception e) {
            throw new RuntimeException(e.toString());
        }

        if (PrintDBBench && DBBenchFile != null) {
            try {
                DBBench.setDBBenchPOS(new FileOutputStream(DBBenchFile, true));
            } catch (FileNotFoundException e) {
                _logger.log(_logger.SEVERE, "Directory " + DBBenchFile + " does not exist.  Please correct in the homewarehouse.conf ");
                _logger.log(_logger.SEVERE, "file and restart.  DB BENCH's will be written to System.err by default.");
                e.printStackTrace();
            }
        } else if (PrintDBBench && DBBenchFile == null) {
            DBBench.setDBBenchPOS(System.err);
        } else if (!PrintDBBench) {
            DBBench.setDBBenchPOS(null);
        }

        // try to add any pools already defined in System properties
        try {
            String aliasesProperty = AppConfig.getInstance().getProperty(_PROP_KEY + "aliases");
            if (aliasesProperty != null) {
                StringTokenizer aliases = new StringTokenizer(aliasesProperty, ",");
                String alias = null;
                while (aliases.hasMoreTokens()) {
                    alias = aliases.nextToken().trim();
                    if (!configureAliasFromProps(alias, AppConfig.getInstance().getProperties()))
                        throw new RuntimeException("Unable to add DB pool for system defined alias[" + alias + "]");
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e.toString());
        }

        // create datastructure that holds group definitions.
        String groupDef, groupName, groupMembers, member;
        int index;

        try {
            boolean misconfiguration = false;
            String groupsProperty = AppConfig.getInstance().getProperty(_PROP_KEY + "groups");
            if (groupsProperty != null) {
                StringTokenizer groups = new StringTokenizer(groupsProperty, ";");

                while (groups.hasMoreTokens()) {
                    groupDef = groups.nextToken().trim();
                    if (!groupDef.equals("")) {
                        index = groupDef.indexOf(":");
                        if (index > 0) {
                            groupName = groupDef.substring(0, index);
                            _logger.log(_logger.WARNING, getClass().getName() + "-DBPool -> groupName:" + groupName);
                            groupMembers = groupDef.substring(index + 1, groupDef.length());
                            _logger.log(_logger.WARNING, getClass().getName() + "-DBPool -> groupMembers:" + groupMembers);
                            StringTokenizer tMembers = new StringTokenizer(groupMembers, ",");
                            List<String> al = new ArrayList<String>();

                            while (tMembers.hasMoreTokens()) {
                                member = tMembers.nextToken().trim();
                                if (!member.equals("")) {
                                    _logger.log(_logger.WARNING, getClass().getName() + "             ---> member:" + member);
                                    al.add(member);
                                }
                            }

                            if (al.size() > 0) {
                                _groupsTable.put(groupName, al);
                            } else {
                                misconfiguration = true;
                            }
                        } else { // end if index>0
                            misconfiguration = true;
                        }
                    } // endif groupDef is not "'
                } // group has moreTokens
            } // groupsProperty != null

            if (misconfiguration) {
                throw new RuntimeException("misconfiguration with DBPool GroupEntries");
            }
        } catch (Exception e) {
            throw new RuntimeException(e.toString());
        }
        //}//synchro
    }

    private void copyProp(Properties from, Properties to, String alias, String fromName, String toName) {
        copyProp(from, to, alias, fromName, toName, null);
    }

    private void copyProp(Properties from, Properties to, String alias, String fromName, String toName, Object def) {
        String value = from.getProperty(_PROP_KEY + alias + "." + fromName);
        if (value == null) {
            value = (def != null) ?String.valueOf(def) :null;
        }
        if (value != null) {
            to.setProperty(toName, value);
        } else {
            to.remove(toName);
        }
    }

    /**
     * @return true if alias was successfully configured.
     */
    private boolean configureAliasFromProps(String alias, Properties aliasProps) {
        boolean rv = false;
        if (alias != null && !"".equals(alias.trim()) && aliasProps != null) {
            try {
                alias = alias.trim();

                Properties props = new Properties();
                copyProp(aliasProps, props, alias, "url",               GenericPool.PROP_URL);
                copyProp(aliasProps, props, alias, "minconn",           GenericPool.PROP_MIN_SIZE, 0);
                copyProp(aliasProps, props, alias, "maxconn",           GenericPool.PROP_MAX_SIZE);
                copyProp(aliasProps, props, alias, "maxcheckout",       GenericPool.PROP_MAX_CHECKOUT);
                copyProp(aliasProps, props, alias, "maxcheckoutinminutes",GenericPool.PROP_MAX_CHECKOUT_IN_MINUTES);
                copyProp(aliasProps, props, alias, "maxcheckouttimeout",GenericPool.PROP_CHECKOUT_TIMEOUT_SECONDS, DEFAULT_MAX_CHECKOUT_TIMEOUT_SECONDS);
                copyProp(aliasProps, props, alias, "maxidletimeout",    GenericPool.PROP_IDLE_TIMEOUT_SECONDS, DEFAULT_MAX_IDLE_TIMEOUT_SECONDS);
                copyProp(aliasProps, props, alias, "retryinterval",     GenericPool.PROP_RETRY_INTERVAL, DEFAULT_RETRY_INTERVAL_MILLIS);
                copyProp(aliasProps, props, alias, "locktimeout",       GenericPool.PROP_LOCK_TIMEOUT, DEFAULT_LOCK_TIMEOUT_MILLIS);
                copyProp(aliasProps, props, alias, "maxwaitclient",     GenericPool.PROP_MAX_WAIT_CLIENT, DEFAULT_MAX_CLIENT);
                copyProp(aliasProps, props, alias, "maxwaittimeout",    GenericPool.PROP_MAX_WAIT_TIMEOUT, DEFAULT_MAX_WAIT_TIMEOUT_MILLIS);
                copyProp(aliasProps, props, alias, "useXA",             GenericPool.PROP_USE_XA, "false");
                copyProp(aliasProps, props, alias, "logParams",         GenericPool.PROP_LOG_PARAMS, 
                        String.valueOf(!alias.endsWith("pool_cc") && !alias.endsWith("pool_ppc"))
                );

                // check for XA override
                if (DisableXA) props.setProperty(PROP_USE_XA, "false");

                // get inlined or managed password
                String passwd = getPassword(alias, aliasProps);

                // conditional properties
                if ("false".equalsIgnoreCase(props.getProperty(PROP_USE_XA))) {
                    copyProp(aliasProps, props, alias, "class", ConnectionPool.PROP_DRIVER_NAME);
                    copyProp(aliasProps, props, alias, "user", ConnectionPool.PROP_USER);
                    props.setProperty(ConnectionPool.PROP_PASSWORD, passwd);
                    copyProp(aliasProps, props, alias, "adapter", ConnectionPool.PROP_ADAPTER);
                    copyProp(aliasProps, props, alias, "isProxy", ConnectionPool.PROP_IS_PROXY);
                } else {
                    copyProp(aliasProps, props, alias, "user", XAConnectionPool.PROP_USER);
                    props.setProperty(XAConnectionPool.PROP_PASSWORD, passwd);
                    copyProp(aliasProps, props, alias, "adapter", XAConnectionPool.PROP_ADAPTER);
                    _txDataSources.put(alias, createTransactionAwareDataSource(alias));
                }

                addPool(alias, props);

                rv = true;
            } catch (Throwable t) {
                _logger.log(_logger.SEVERE, "Caught exception when processing DB alias '" + alias + "' --> " + t.getMessage());
              try {
                  GenericPool pool = _poolManager.getGenericPool(alias);
                  if (pool != null) {
                    pool.setPoolPermanentlyDisable(true, 1, "Pool marked permanently disabled due to configuration/database error");
                  }
              } catch (Exception exp) {
                  _logger.log(_logger.SEVERE, "Caught exception while marking connection pool permanently disabled for " + alias);  
                }
              //instead of false, setting to true, so that we can still add another connection pool
              //instead of just throwing RTE
              rv = true;                
            }
        }//if
        return rv;
    }

    private void addPool(String alias, Properties props) throws Exception {
        _logger.log(_logger.WARNING, alias + ":" + props.toString());

        _connectionErrorLogs.put(alias, new StringBuffer());

        _poolManager.addPool(alias, props);

        DBPoolAdmin dbPoolMBean = new DBPoolAdmin(alias);
   //     JmxUtil.getInstance().registerMBean("DBPoolAdmin:name=" + alias, dbPoolMBean, null);
    }

    private DataSource createTransactionAwareDataSource(String alias) {
        DriverManagerDataSource dmds = new DriverManagerDataSource();
        dmds.setDriverClassName("com.arjuna.ats.jdbc.TransactionalDriver");
        dmds.setUrl("jdbc:arjuna:"+alias);
        Properties dmdsProps = new Properties();
        dmdsProps.setProperty("user", "keepme"); // to avoid NPE in jboss code
        dmdsProps.setProperty("password", "keepme"); // to avoid NPE in jboss code
        dmdsProps.setProperty("DYNAMIC_CLASS", "com.wm.sql.DBPoolDynamicClass");
        dmds.setConnectionProperties(dmdsProps);
        return dmds;
    }

    private String getPassword(String alias, Properties aliasProps) throws Exception {
        /*
         *  If passwd property is set, use value as password.
	     */
        String passwd = aliasProps.getProperty(_PROP_KEY + alias + ".passwd");
        if (passwd != null && passwd.trim().length() > 0) {
            return passwd;
        }

        /*
         *  passwd property is not set. Get password handler (if any). If no
         *  password handler, use default password handler.
         */
        String passwdHandler = aliasProps.getProperty(_PROP_KEY + alias + ".passwdHandler");
        if (passwdHandler == null || passwdHandler.trim().length() == 0) {
            passwdHandler = DEFAULT_EMPTY_PASSWORD_HANDLER;
        }

        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        Object o = classLoader.loadClass(passwdHandler).newInstance();
        if (o instanceof EmptyPasswordHandler) {
            // Legacy password handler (for ccdb) should be tested first
            String url = aliasProps.getProperty(_PROP_KEY + alias + ".url");
            String user = aliasProps.getProperty(_PROP_KEY + alias + ".user");
            EmptyPasswordHandler impl = (EmptyPasswordHandler) o;
            passwd = impl.getPassword(url, user);
        } else if (o instanceof PasswordProvider) {
            // New password handler should be tested next.
            PasswordProvider impl = (PasswordProvider) o;
            passwd = impl.getPassword(_PROP_KEY, alias, aliasProps);
        } else {
            throw new RuntimeException("Unknown Password Handler: " + passwdHandler + " specified for the pool: " + alias);
        }

        if (passwd != null && passwd.trim().length() > 0) {
            return passwd;
        } else {
            throw new RuntimeException("Password handler/configuration returned NULL password for the pool: " + alias);
        }

    }

    private GenericPool getMemberGenericPool(String alias) throws XRuntimeSQL {
        try {
            return _poolManager.getGenericPool(alias);
        } catch (SQLException e) {
            throw new XRuntimeSQL(e);
        }
    }

    private ConnectionPool getMemberConnectionPool(String alias) throws XRuntimeSQL {
        try {
            return _poolManager.getPool(alias);
        } catch (SQLException e) {
            throw new XRuntimeSQL(e);
        }
    }

    private XAConnectionPool getMemberXAConnectionPool(String alias) throws XRuntimeSQL {
        try {
            return _poolManager.getXAPool(alias);
        } catch (SQLException e) {
            throw new XRuntimeSQL(e);
        }
    }

    private <T extends GenericPooledObject> T getConnectionFromPools(GenericPool<T>[] pools) {
        T conn = null;
        for (int i = 0; (conn == null && (i < pools.length)); i++) {
            try {
                conn = getConnectionFromPool(pools[i]);
            } catch (XRuntimeSQL x) {
                _logger.log(_logger.SEVERE, getClass().getName() + "-Trapped XRuntimeSQLException from " + pools[i].getAlias());
                if (i < (pools.length - 1)) {
                    conn = null;
                    _logger.log(_logger.SEVERE, getClass().getName() + "-Will attempt to get connection from  " + pools[i + 1].getAlias());
                } else {
                    throw new XRuntimeSQLGroup(x.getSQLException());
                }
            }
        }
        return conn;
    }

    private <T extends GenericPooledObject> T getConnectionFromPool(GenericPool<T> pool) throws XRuntimeSQL {

        String alias = pool.getAlias();
        T c = null;

        //mean if pool health is false and no connection in the pool then throw exception
        //otherwise serve the connection back to the client
        if (!pool.getHealth() && pool.size() == 0) {
            throw new XRuntimeSQL(new java.sql.SQLException("DB Pool is marked un-healthly, given up on this pool [" + pool.getAlias() + "]"));
        }

        try {
            //we have the pool, so call getConnection to avoid too much synchronization
            c = pool.checkout();
        } catch (SQLException e) {
            //_logger.log(_logger.SEVERE,getClass().getName() + "-Unable to get a database connection on try [" + tries + "], " + e.toString() );
            _logger.log(_logger.SEVERE, getClass().getName() + "-Unable to get a database connection, " + e.toString());
            if (GET_CONNECTION_LOG_ERRORS) {
                (_connectionErrorLogs.get(alias)).append("\n\n===========================");
                (_connectionErrorLogs.get(alias)).append("\nBad Connection.");
                (_connectionErrorLogs.get(alias)).append("\nDate       : " + new java.util.Date());
                (_connectionErrorLogs.get(alias)).append("\nConnection : " + c);
                (_connectionErrorLogs.get(alias)).append("\nException  : " + e.getMessage());
                if (c != null) {
                    (_connectionErrorLogs.get(alias)).append("\nInfo Dump  : " + c.dumpInfo());          
                }
            }

            if (pool instanceof ConnectionPool) ((ConnectionPool)pool).registerException(e, null);
            throw new XRuntimeSQL(e);
        } // end outer try/catch block
        return c;
    }


    protected ConnectionPoolManager getPoolManager() {
        return _poolManager;
    }

    public UrlKeyManager getUrlKeyManager() {
        return (_poolManager != null) ?_poolManager.getUrlKeyManager() :null;
    }
}
