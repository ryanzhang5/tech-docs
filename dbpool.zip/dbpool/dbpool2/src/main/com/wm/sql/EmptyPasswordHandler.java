/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.sql;

/**
 * Allows the DataAccess clients to plug in a custom password provider. A sample
 * use-case is when you do not wish to put the password in your configuration file
 * and choose to fetch it dynamically at runtime.
 *
 * @deprecated  replaced by PasswordProvider
 *
 * @author mkishore
 * @since 1.6.0
 */
public interface EmptyPasswordHandler {
    /**
     * Get the database password for the given connection url and username.
     *
     * @param url      - JDBC url for the connection
     * @param username - database username for the connection
     * @return the database password for the given connection url and username
     */
    public String getPassword(String url, String username);
}
