package com.wm.sql;

import java.sql.SQLException;
import java.io.PrintStream;
import java.io.PrintWriter;

/**
*   An exception class which wraps SQLException, essentially
*   letting you recast the SQLException as a custom 
*   class while keeping all the functionality.
*
*   This is the non-RuntimeException edition of XRuntimeSQL.
*/

public class XSQL extends Exception {

  private SQLException _sqe;
  
  public XSQL( SQLException e, String message) {
    super( message );
    _sqe = e;
  }
  
  public String getMessage() {
    return super.getMessage() + " : " + _sqe.getMessage();
  }

  public void printStackTrace() {
    System.err.print(this+" : ");
    _sqe.printStackTrace();
  }

  public void printStackTrace(PrintStream s) {
    s.print(this+" : ");
    _sqe.printStackTrace( s );
  }

  public void printStackTrace(PrintWriter s) {
    s.print(this+" : ");
    _sqe.printStackTrace( s );
  }

  public SQLException getSQLException() {
    return _sqe;
  }
  
  public int getErrorCode(){
      return _sqe.getErrorCode();
  }
}

