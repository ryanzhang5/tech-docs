/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql;

import com.wm.sql.DataAccess;

import java.sql.CallableStatement;
import java.sql.Connection;
  
import com.wm.corelib.config.AppConfig;

/**
 * AbortTest
 *
 * @author mkishore
 * @since TODO
 */
public class LogStatsTest {
    static {
        try {
            AppConfig.getInstance().getProperties().load(LogStatsTest.class.getResourceAsStream("system.properties"));
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
    }

    public static void main(String[] args) throws Exception {
        Connection conn = null;
        CallableStatement stmt = null;
        String TIMED_OUT = "{ call dal_test_pkg.sleep_seconds(?) }";
        try {
            conn = DataAccess.getInstance().getConnection("m1");
            stmt = conn.prepareCall(TIMED_OUT);
            stmt.setInt(1, 1);
            System.out.println("======Executing=======");
            stmt.execute();
            System.out.println("======  Done  =======");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) stmt.close();
            } catch (Exception exp) {
                exp.printStackTrace();
            }
            try {
                if (conn != null) conn.close();
            } catch (Exception exp) {
                exp.printStackTrace();
            }
        }
        Thread.sleep(310000);
    }
}