/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql.url;

import com.bitmechanic.sql.GenericPool;
import com.wm.sql.DataAccess;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Collections;
import java.util.Map;
import java.util.Properties;
  
import com.wm.corelib.config.AppConfig;

/**
 * UrlKeyManagerTest
 *
 * @author mkishore
 * @since 2.0.3
 */
public class UrlKeyManagerTest {
    static {
        try {
            AppConfig.getInstance().getProperties().load(UrlKeyManagerTest.class.getResourceAsStream("/com/bitmechanic/sql/system.properties"));
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
    }

    @Test
    public void testUrlKey() throws SQLException, IOException, InterruptedException {
        GenericPool pool = DataAccess.getInstance().getGenericPool("m1")[0];
        UrlKeyManager urlKeyManager = pool.getConnectionPoolManager().getUrlKeyManager();
        File file = urlKeyManager.getConfigFile();

        Assert.assertNull(urlKeyManager.getUrlKey("m1"));

        urlKeyManager.setUrlKeys(Collections.singletonMap("m1", "k2"));
        Assert.assertEquals(urlKeyManager.getUrlKey("m1"), "k2");

        Thread.sleep(1000); // looks like Linux stores second level data only?!?
        Properties props = new Properties();
        props.setProperty("m1", "k1");
        FileOutputStream os = new FileOutputStream(file);
        props.store(os, "");
        os.flush(); os.close();

        Thread.sleep(31000);
        Assert.assertEquals(urlKeyManager.getUrlKey("m1"), "k1");

        urlKeyManager.setUrlKeys(Collections.singletonMap("m1", (String)null));
    }
}