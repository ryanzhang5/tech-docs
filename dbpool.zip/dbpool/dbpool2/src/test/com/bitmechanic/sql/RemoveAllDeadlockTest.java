/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql;

import com.wm.sql.DataAccess;

import java.sql.CallableStatement;
import java.sql.Connection;
  
import com.wm.corelib.config.AppConfig;

/**
 * RemoveAllDeadlockTest
 *
 * @author mkishore
 * @since 2.0.3
 */
public class RemoveAllDeadlockTest {
    static {
        try {
            AppConfig.getInstance().getProperties().load(RemoveAllDeadlockTest.class.getResourceAsStream("system.properties"));
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
    }

    public static void main(String[] args) throws Exception {
        Thread t = new Thread(new Runnable() {
            public void run() {
                while (true) try {
                    System.out.println("About to checkout and checkin connections");
                    Connection[] conns = new Connection[5];
                    for (int i=0; i < 5; i++) {
                        conns[i] = DataAccess.getInstance().getConnection("m1");
                    }
                    for (int i=0; i < 5; i++) {
                        conns[i].close();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        t.setDaemon(true);
        t.start();

        Thread.currentThread().sleep(3000);

        for (int i=0; i < 10; i++) {
            addWaiters();
            System.out.println("About to remove all connections");
            DataAccess.getInstance().getGenericPool("m1")[0].removeAll();
            System.out.println("Done removing all connections");
        }
    }
    private static void addWaiters() {
        Runnable r = new Runnable() {
            public void run() {
                try {
                    GenericPool pool = DataAccess.getInstance().getGenericPool("m1")[0];
                    synchronized(pool) {
                        pool.wait();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        for (int j=0; j < 1000; j++) {
            new Thread(r).start();
        }
    }

}
