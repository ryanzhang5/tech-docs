/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql.url;

import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * SimpleUrlProviderTest
 *
 * @author mkishore
 * @since 2.0.3
 */
public class SimpleUrlProviderTest {
    @Test
    public void testUrl() {
        SimpleUrlProvider sup = new SimpleUrlProvider(null, "test");
        Assert.assertEquals(sup.getUrl(), "test");
    }
}
