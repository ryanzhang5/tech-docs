/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.bitmechanic.sql.url;

import com.bitmechanic.sql.GenericPool;
import com.wm.sql.DataAccess;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Collections;
import java.util.Map;
  
import com.wm.corelib.config.AppConfig;

/**
 * StaticUrlProviderTest
 *
 * @author mkishore
 * @since 2.0.3
 */
public class StaticUrlProviderTest {
    static {
        try {
            AppConfig.getInstance().getProperties().load(StaticUrlProviderTest.class.getResourceAsStream("/com/bitmechanic/sql/system.properties"));
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
    }

    @Test
    public void testUrl() throws SQLException, IOException, InterruptedException {
        GenericPool pool = DataAccess.getInstance().getGenericPool("m1")[0];
        UrlKeyManager urlKeyManager = pool.getConnectionPoolManager().getUrlKeyManager();
        File file = urlKeyManager.getConfigFile();

        StaticUrlProvider sup = new StaticUrlProvider(pool, "static(k1=v1,k2=v2)");
        Assert.assertEquals(sup.getUrl(), "v1");

        urlKeyManager.setUrlKeys(Collections.singletonMap("m1", "k2"));
        Assert.assertEquals(sup.getUrl(), "v2");

        urlKeyManager.setUrlKeys(Collections.singletonMap("m1", (String)null));
    }
}
