/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.sql;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
  
import com.wm.corelib.config.AppConfig;

/**
 * JtaTest - tests the integration of following frameworks:
 * <li> Spring
 * <li> JBoss JTA
 * <li> XAPool
 * <li> MySQL XA DataSource
 * <p/>
 * Assumes that you ran the following DDLs on a mysql database:
 * -- create user 'web_user'@'%' identified by 'web_user';
 * -- grant all privileges on *.* to 'web_user'@'%' with grant option;
 * -- show databases;
 * -- create database clmdb;
 * -- use clmdb;
 * -- create table dal_xa (tx_nbr int(11), tx_value int(11)) engine=InnoDB;
 * <p/>
 * Do the same for on another database or user-schema
 *
 * @author mkishore
 * @since 2.0.1
 */
public class JtaTest {
    private static ApplicationContext applicationContext = null;

    static {
        try {
            // load the system properties before spring-config - needed by dbpool
            AppConfig.getInstance().getProperties().load(JtaTest.class.getResourceAsStream("system.properties"));
            applicationContext = new ClassPathXmlApplicationContext("/com/wm/sql/test-jta-beans.xml");
            System.out.println("ApplicationContext: " + applicationContext);
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
    }

    // after loading the system.properties
    private static boolean DEBUG = "true".equalsIgnoreCase(AppConfig.getInstance().getProperty("DEBUG", "true"));

    public JtaTest() {
        if (applicationContext != null) {
            initialize((JtaTest) applicationContext.getBean("jtaTest"));
        }
    }

    protected void initialize(JtaTest copy) {
        this.setDS1(copy.getDS1());
        this.setDS2(copy.getDS2());
        this.setTxManager(copy.getTxManager());
    }

    private void log(String msg) {
        if (DEBUG) System.out.println(msg);
    }

    protected void safeClose(Connection con) {
        try {
            if (con != null) { // && !con.isClosed()) {
                con.close();
            }
        } catch (SQLException e) {
            // e.printStackTrace();
        }
    }

    protected DefaultTransactionDefinition getTransactionDefinition() {
        return new DefaultTransactionDefinition();
    }

    protected List executeWithTx(String ds, String sql) {
        TransactionStatus status = txManager.getTransaction(getTransactionDefinition());
        List list;
        try {
            list = execute(ds, sql);
            txManager.commit(status);
        } catch (RuntimeException e) {
            txManager.rollback(status);
            throw e;
        }
        return list;
    }

    protected List execute(String ds, String sql) {
        List<Object> list = new ArrayList<Object>();
        Connection con = null;
        try {
            System.out.println("SQL: " + sql);
            log("Getting connection");
            con = DataAccess.getInstance().getConnection(ds);

            // Class iface = Class.forName("oracle.jdbc.OracleConnection");
            // Object obj = con.unwrap(iface);

            log("Preparing statement");
            PreparedStatement pstmt = con.prepareStatement(sql);
            log("Executing statement");
            boolean isRS = pstmt.execute();
            if (isRS) {
                ResultSet rs = pstmt.getResultSet();
                int cols = rs.getMetaData().getColumnCount();
                while (rs.next()) {
                    List<Object> row = new ArrayList<Object>();
                    for (int j = 1; j <= cols; j++) {
                        row.add(rs.getObject(j));
                    }
                    list.add(row);
                }
                log("ResultSet: " + list);
            } else {
                int uc = pstmt.getUpdateCount();
                list.add(uc);
                log("UpdateCount: " + list);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            log("Closing connection");
            safeClose(con);
        }
        return list;
    }

    protected Object single(List list) {
        Object first = list.get(0);
        return (first instanceof List) ? ((ArrayList) first).get(0) : first;
    }

    protected int toInt(List list) {
        return ((Number) single(list)).intValue();
    }

    @Test
    public void testConnectionCommit() {
        Connection con = null;
        TransactionStatus status = txManager.getTransaction(getTransactionDefinition());
        try {
            con = DataAccess.getInstance().getConnection(DS1);
            con.commit();
            Assert.fail("Connection.commit() should throw an Exception");
        } catch (Exception e) {
            log("Commit errored out as expected");
            txManager.rollback(status);
        } finally {
            safeClose(con);
        }
    }

    @Test
    public void testCleanup() {
        executeWithTx(DS1, "delete from dal_xa");
        executeWithTx(DS2, "delete from dal_xa");
    }

    @Test(dependsOnMethods = "testCleanup")
    public void testSuccessfulTx() {
        TransactionStatus status = txManager.getTransaction(getTransactionDefinition());
        try {
            execute(DS1, "insert into dal_xa values(1, 10)");
            execute(DS2, "insert into dal_xa values(1, 10)");
            txManager.commit(status);
        } catch (Exception e) {
            txManager.rollback(status);
            throw new RuntimeException(e);
        }
        Assert.assertEquals(toInt(executeWithTx(DS1, "select count(*) from dal_xa")), 1);
    }

    @Test(dependsOnMethods = "testSuccessfulTx")
    public void testRollbackTx() {
        TransactionStatus status = txManager.getTransaction(getTransactionDefinition());
        try {
            execute(DS1, "insert into dal_xa values(2, 20)");
            execute(DS2, "insert into dal_xa values(2, 'fail')");
            txManager.commit(status);
        } catch (Exception e) {
            log("Insert errored out as expected");
            txManager.rollback(status);
        }
        Assert.assertEquals(toInt(executeWithTx(DS1, "select count(*) from dal_xa")), 1);
    }

    public void runLoadTest(int numThreads, int iterations, int delay) {
        testCleanup();
        Thread[] threads = new Thread[numThreads];
        for (int i = 0; i < numThreads; i++) {
            threads[i] = new LoadTestThread(i, iterations, delay, this);
            threads[i].setDaemon(true);
            threads[i].start();
        }
        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    protected void doLoadTest(int id, int iteration) {
        TransactionStatus status = txManager.getTransaction(getTransactionDefinition());
        try {
            if (iteration % 10 == 0) {
                execute(DS1, "delete from dal_xa where tx_value < " + iteration / 2);
                execute(DS2, "delete from dal_xa where tx_value < " + iteration / 2);
            } else if (iteration % 10 == 5) {
                execute(DS1, "update dal_xa set tx_nbr=" + id + " where tx_value=" + iteration);
                execute(DS2, "update dal_xa set tx_nbr=" + id + " where tx_value=" + iteration);
            } else {
                execute(DS1, "insert into dal_xa values(" + id + ", " + iteration + ")");
                execute(DS2, "insert into dal_xa values(" + id + ", " + iteration + ")");
            }
            txManager.commit(status);
        } catch (Exception e) {
            e.printStackTrace();
            txManager.rollback(status);
        }
    }

    public static void main(String[] args) throws Exception {
        int numThreads = 10, iterations = -1, delay = 10;
        if (args.length > 0) numThreads = Integer.parseInt(args[0]);
        if (args.length > 1) iterations = Integer.parseInt(args[1]);
        if (args.length > 2) delay = Integer.parseInt(args[2]);

        new JtaTest().runLoadTest(numThreads, iterations, delay);

        System.exit(0);
    }

    // INJECTABLE PROPERTIES

    private String DS1;
    private String DS2;
    private PlatformTransactionManager txManager;

    public String getDS1() {
        return DS1;
    }

    public void setDS1(String DS1) {
        this.DS1 = DS1;
    }

    public String getDS2() {
        return DS2;
    }

    public void setDS2(String DS2) {
        this.DS2 = DS2;
    }

    public PlatformTransactionManager getTxManager() {
        return txManager;
    }

    public void setTxManager(PlatformTransactionManager txManager) {
        this.txManager = txManager;
    }

    private static class LoadTestThread extends Thread {
        private int id, iterations, delay;
        private JtaTest test;

        private LoadTestThread(int id, int iterations, int delay, JtaTest test) {
            this.id = id;
            this.iterations = iterations;
            this.delay = delay;
            this.test = test;
        }

        public void run() {
            for (int i = 0; iterations == -1 || i < iterations; i++) {
                try {
                    test.doLoadTest(id, i);
                    Thread.sleep(delay);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
