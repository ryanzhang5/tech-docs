/*     */ package com.bill.make;
/*     */ 
/*     */ import com.bill.bean.Card;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class XMLWrite
/*     */ {
/*  18 */   private static Logger log = Logger.getLogger(XMLWrite.class);
/*     */ 
/*  20 */   private Map<String, XmlFileOutput> map = new HashMap();
/*     */   private XmlFileOutput eOut;
/*     */   private Card card;
/*     */   private IFilePathCreate create;
/*     */ 
/*     */   public XMLWrite(Card card, IFilePathCreate create)
/*     */   {
/*  27 */     this.card = card;
/*  28 */     this.create = create;
/*  29 */     this.eOut = new XmlFileOutput(create.getEmailFileNamePath(card));
/*     */   }
/*     */ 
/*     */   public synchronized void println(String email, String paper, PaperRelatingWrap wrap)
/*     */     throws IOException
/*     */   {
/*  40 */     printlnHtml(email);
/*  41 */     printlnPage(paper, wrap);
/*     */   }
/*     */ 
/*     */   public synchronized void printlnHtml(String email)
/*     */     throws IOException
/*     */   {
/*  50 */     if (email != null)
/*  51 */       this.eOut.write(email);
/*     */   }
/*     */ 
/*     */   public synchronized void printlnPage(String paper, PaperRelatingWrap wrap)
/*     */     throws IOException
/*     */   {
/*  60 */     if (paper != null)
/*     */     {
/*  62 */       XmlFileOutput pOut = (XmlFileOutput)this.map.get(wrap.getBusin() + "_" + wrap.getYyzNo());
/*  63 */       if (pOut == null) {
/*  64 */         pOut = new XmlFileOutput(this.create.getPaperFileNamePath(this.card, wrap.getYyzNo(), wrap.getBusin()));
/*  65 */         pOut.setWbsId(wrap.getBusin());
/*  66 */         pOut.setYyzId(wrap.getYyzId());
/*  67 */         this.map.put(wrap.getBusin() + "_" + wrap.getYyzNo(), pOut);
/*     */       }
/*  69 */       pOut.write(paper);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/*  77 */     this.eOut.close();
/*  78 */     for (XmlFileOutput pOut : this.map.values()) {
/*  79 */       pOut.close();
/*     */     }
/*  81 */     if (log.isDebugEnabled())
/*  82 */       log.debug(this.card.getName() + "(" + this.card.getId() + ")  所有IO关闭");
/*     */   }
/*     */ 
/*     */   public int getWriteNum()
/*     */   {
/*  90 */     int count = this.eOut.getAllNumber();
/*  91 */     for (XmlFileOutput pOut : this.map.values()) {
/*  92 */       count += pOut.getAllNumber();
/*     */     }
/*  94 */     return count;
/*     */   }
/*     */ 
/*     */   public Collection<XmlFileOutput> getPaperOut()
/*     */   {
/* 102 */     return this.map.values();
/*     */   }
/*     */ 
/*     */   public XmlFileOutput getEmailOut()
/*     */   {
/* 110 */     return this.eOut;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.make.XMLWrite
 * JD-Core Version:    0.6.2
 */