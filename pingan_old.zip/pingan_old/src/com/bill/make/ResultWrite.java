/*    */ package com.bill.make;
/*    */ 
/*    */ public class ResultWrite
/*    */ {
/*    */   private String filePath;
/*    */   private String fileName;
/*    */   private int writeNum;
/*    */   private long createTime;
/*    */   private long endTime;
/*    */ 
/*    */   public String getFilePath()
/*    */   {
/* 16 */     return this.filePath;
/*    */   }
/*    */   public void setFilePath(String filePath) {
/* 19 */     this.filePath = filePath;
/*    */   }
/*    */   public String getFileName() {
/* 22 */     return this.fileName;
/*    */   }
/*    */   public void setFileName(String fileName) {
/* 25 */     this.fileName = fileName;
/*    */   }
/*    */   public long getCreateTime() {
/* 28 */     return this.createTime;
/*    */   }
/*    */   public void setCreateTime(long createTime) {
/* 31 */     this.createTime = createTime;
/*    */   }
/*    */   public long getEndTime() {
/* 34 */     return this.endTime;
/*    */   }
/*    */   public void setEndTime(long endTime) {
/* 37 */     this.endTime = endTime;
/*    */   }
/*    */   public int getWriteNum() {
/* 40 */     return this.writeNum;
/*    */   }
/*    */   public void setWriteNum(int writeNum) {
/* 43 */     this.writeNum = writeNum;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.make.ResultWrite
 * JD-Core Version:    0.6.2
 */