/*    */ package com.bill.make;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class Common
/*    */ {
/*    */   public static String timeFormat(long time)
/*    */   {
/*  5 */     int t = (int)(time / 1000L);
/*    */     int h;
/*  7 */     if (t >= 3600) {
/*  8 */       int h = t / 3600;
/*  9 */       t -= h * 3600;
/*    */     } else {
/* 11 */       h = 0;
/*    */     }
/*    */     int m;
/* 12 */     if (t >= 60) {
/* 13 */       int m = t / 60;
/* 14 */       t -= m * 60;
/*    */     } else {
/* 16 */       m = 0;
/* 17 */     }int s = t;
/* 18 */     return String.format("%02d:%02d:%02d.%03d", new Object[] { Integer.valueOf(h), Integer.valueOf(m), Integer.valueOf(s), Long.valueOf(time % 1000L) });
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) {
/* 22 */     System.out.println(timeFormat(System.currentTimeMillis()));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.make.Common
 * JD-Core Version:    0.6.2
 */