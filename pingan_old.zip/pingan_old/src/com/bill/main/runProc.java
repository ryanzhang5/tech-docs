/*    */ package com.bill.main;
/*    */ 
/*    */ import com.bill.db.DbConnectionForOracle;
/*    */ import com.bill.util.DaoBase;
/*    */ import com.bill.util.LogInit;
/*    */ import com.bill.util.config.ConfigReader;
/*    */ import java.io.PrintStream;
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import java.util.Map;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class runProc
/*    */ {
/* 16 */   private static Map<String, String> config = null;
/* 17 */   private static Logger log = null;
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 21 */     System.out.println("##### start run procedures!");
/*    */     try {
/* 23 */       ConfigReader.init();
/*    */     } catch (Exception e) {
/* 25 */       System.out.println("##### read properties file error, file path:" + ConfigReader.class.getClassLoader().getResource(ConfigReader.CONFIG_PATH));
/* 26 */       e.printStackTrace();
/* 27 */       return;
/*    */     }
/*    */ 
/* 30 */     DbConnectionForOracle db = new DbConnectionForOracle(
/* 31 */       ConfigReader.read("db.ip"), 
/* 32 */       ConfigReader.read("db.port"), 
/* 33 */       ConfigReader.read("db.name"), 
/* 34 */       ConfigReader.read("db.user"), 
/* 35 */       ConfigReader.read("db.pwd"));
/*    */ 
/* 37 */     config = DaoBase.getConfig(db);
/* 38 */     LogInit.init((String)config.get("LOG4J_COFIG_PATH"), 
/* 39 */       (String)config.get("LOG4J_FILENAME") + "runProc.log");
/* 40 */     log = Logger.getLogger(runProc.class);
/* 41 */     if ((args == null) || (args.length == 0)) {
/* 42 */       log.error("procedures name is null!");
/* 43 */       System.exit(-1);
/*    */     }
/* 45 */     CallableStatement call = null;
/*    */     try {
/* 47 */       log.debug("procedures name:" + args[0] + ",begin time:" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
/* 48 */       call = db.getConnection().prepareCall("{call " + args[0] + "()}");
/* 49 */       call.execute();
/* 50 */       call.close();
/* 51 */       db.close();
/*    */     } catch (SQLException e) {
/* 53 */       e.printStackTrace();
/* 54 */       log.error("run procedures error!");
/* 55 */       log.error(e.getMessage());
/*    */       try {
/* 57 */         if ((call != null) && (!call.isClosed())) {
/* 58 */           call.close();
/*    */         }
/* 60 */         db.close();
/*    */       } catch (SQLException e1) {
/* 62 */         e1.printStackTrace();
/*    */       }
/* 64 */       System.exit(-1);
/*    */     }
/* 66 */     log.debug("procedures name:" + args[0] + ",end time:" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
/* 67 */     System.exit(0);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.main.runProc
 * JD-Core Version:    0.6.2
 */