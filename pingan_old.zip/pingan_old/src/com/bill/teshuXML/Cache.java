/*     */ package com.bill.teshuXML;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.bean.Busin;
/*     */ import com.bill.bean.Card;
/*     */ import com.bill.bean.Debitinfo;
/*     */ import com.bill.bean.Fodder;
/*     */ import com.bill.bean.Foldout;
/*     */ import com.bill.bean.Plog;
/*     */ import com.bill.bean.PointInfo;
/*     */ import com.bill.bean.Rule;
/*     */ import com.bill.bean.RuleF;
/*     */ import com.bill.bean.RuleM;
/*     */ import com.bill.bean.TempArea;
/*     */ import com.bill.bean.Template;
/*     */ import com.bill.bean.UserAccinfo;
/*     */ import com.bill.bean.UserAccinfoDetail;
/*     */ import com.bill.bean.UserBase;
/*     */ import com.bill.bean.UserBuy;
/*     */ import com.bill.bean.Yyz;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class Cache
/*     */ {
/*     */   private static DBDao dao;
/*  14 */   public static List<Busin> businList = null;
/*     */ 
/*  18 */   public static List<Card> cardList = null;
/*     */ 
/*  23 */   public static Map<String, String> bfpntMap = null;
/*     */ 
/*  27 */   public static Map<String, List<Yyz>> cardBfpntMap = null;
/*     */ 
/*  34 */   public static Map<String, String> templateMap = null;
/*     */ 
/*  41 */   public static Map<String, List<TempArea>> templateInfo = new HashMap();
/*     */ 
/*  48 */   public static Map<String, List<Rule>> ruleMap = null;
/*  49 */   public static Map<String, List<RuleF>> ruleFMap = new HashMap();
/*  50 */   public static Map<String, List<RuleM>> ruleMMap = new HashMap();
/*     */ 
/*  54 */   public static Map<String, Fodder> fodderMap = new HashMap();
/*     */ 
/*  59 */   public static Map<String, String> wdMap = null;
/*     */ 
/*  63 */   public static Map<String, List<Foldout>> foldoutMap = new HashMap();
/*     */ 
/*  68 */   public static Map<String, Map<String, String>> foldoutCityMap = new HashMap();
/*     */ 
/*     */   public static List<String> getCityByCPB(String cardid, String printid, String businId)
/*     */   {
/*  79 */     return dao.getCityByCPB(cardid, printid, businId);
/*     */   }
/*     */ 
/*     */   public static List<UserBase> getUserBase(String cardid, String city)
/*     */   {
/*  88 */     return dao.getUserBase(cardid, city);
/*     */   }
/*     */ 
/*     */   public static List<UserAccinfo> getUserInfo(String acctnbr)
/*     */   {
/*  96 */     return dao.getUserInfo(acctnbr, BaseParam.PERIOD);
/*     */   }
/*     */ 
/*     */   public static List<UserAccinfoDetail> getAccinfoDetail(UserBase ub)
/*     */   {
/* 104 */     return dao.getAccinfoDetail(ub);
/*     */   }
/*     */ 
/*     */   public static UserBuy getUserBuy(UserBase user)
/*     */   {
/* 112 */     return dao.getUserBuy(user);
/*     */   }
/*     */ 
/*     */   public static List<Debitinfo> getDebitinfo(UserBase user) {
/* 116 */     return dao.getDebitinfo(user);
/*     */   }
/*     */   public static List<PointInfo> getPoint(String acctnbr) {
/* 119 */     return dao.getPoint(acctnbr, BaseParam.PERIOD);
/*     */   }
/*     */   public static PointInfo getPoint2(String acctnbr) {
/* 122 */     return dao.getPoint2(acctnbr, BaseParam.PERIOD);
/*     */   }
/*     */ 
/*     */   public static Map<String, String> getTemplateMap()
/*     */   {
/* 130 */     Map map = new HashMap();
/* 131 */     List list = dao.getTemplateList();
/* 132 */     String key = "";
/* 133 */     for (Template t : list) {
/* 134 */       key = t.getCardid() + "_" + t.getType();
/* 135 */       map.put(key, t.getId());
/*     */     }
/* 137 */     return map;
/*     */   }
/*     */ 
/*     */   public static List<Rule> getRuleMap(String tid, String type, String area)
/*     */   {
/* 147 */     if (ruleMap == null) {
/* 148 */       ruleMap = new HashMap();
/*     */     }
/* 150 */     if (ruleMap.containsKey(tid + "_" + type + "_" + area))
/*     */     {
/* 152 */       return (List)ruleMap.get(tid + "_" + type + "_" + area);
/*     */     }
/* 154 */     List list = dao.getRule(tid, type, area, BaseParam.PERIOD);
/* 155 */     ruleMap.put(tid + "_" + type + "_" + area, list);
/* 156 */     return list;
/*     */   }
/*     */ 
/*     */   public static List<RuleF> getRuleFMap(String rid)
/*     */   {
/* 165 */     if (ruleFMap.containsKey(rid)) {
/* 166 */       return (List)ruleFMap.get(rid);
/*     */     }
/*     */ 
/* 169 */     List list = dao.getRuleF(rid);
/* 170 */     ruleFMap.put(rid, list);
/* 171 */     return list;
/*     */   }
/*     */ 
/*     */   public static List<RuleM> getRuleFFList(String rid)
/*     */   {
/* 180 */     if (ruleMMap.containsKey(rid)) {
/* 181 */       return (List)ruleMMap.get(rid);
/*     */     }
/*     */ 
/* 184 */     List list = dao.getRuleFF(rid);
/* 185 */     ruleMMap.put(rid, list);
/* 186 */     return list;
/*     */   }
/*     */ 
/*     */   public static List<TempArea> getTemplateInfo(String tid)
/*     */   {
/* 197 */     if ((templateInfo != null) && (templateInfo.containsKey(tid))) {
/* 198 */       return (List)templateInfo.get(tid);
/*     */     }
/* 200 */     List list = dao.getTemplateInfo(tid);
/* 201 */     templateInfo.put(tid, list);
/* 202 */     return list;
/*     */   }
/*     */ 
/*     */   public static Fodder getFodder(String fid)
/*     */   {
/* 211 */     if (fodderMap.containsKey(fid)) {
/* 212 */       return (Fodder)fodderMap.get(fid);
/*     */     }
/* 214 */     Fodder f = null;
/* 215 */     f = dao.getFodder(fid, BaseParam.PERIOD);
/* 216 */     fodderMap.put(fid, f);
/* 217 */     return f;
/*     */   }
/*     */ 
/*     */   public static List<Foldout> getFoldout(String bid, String cid)
/*     */   {
/* 226 */     if (foldoutMap.containsKey(bid + "_" + cid)) {
/* 227 */       return (List)foldoutMap.get(bid + "_" + cid);
/*     */     }
/*     */ 
/* 230 */     List list = dao.getFoldout(bid, cid, BaseParam.PERIOD);
/* 231 */     foldoutMap.put(bid + "_" + cid, list);
/* 232 */     return list;
/*     */   }
/*     */ 
/*     */   public static int savePLogBegin(Plog log)
/*     */   {
/* 241 */     log.setStmtdate(BaseParam.PERIOD);
/* 242 */     log.setStart_time(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Long.valueOf(System.currentTimeMillis())));
/* 243 */     return dao.savePLogBegin(log);
/*     */   }
/*     */ 
/*     */   public static int savePLogEnd(Plog log)
/*     */   {
/* 251 */     log.setEnd_time(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Long.valueOf(System.currentTimeMillis())));
/* 252 */     return dao.savePLogEnd(log);
/*     */   }
/*     */   public static int savePLogDel(Plog log) {
/* 255 */     return dao.avePLogDel(log);
/*     */   }
/*     */ 
/*     */   public static synchronized Map<String, String> getFoldoutCity(String id, String idx)
/*     */   {
/* 264 */     if (foldoutCityMap.containsKey(id + "_" + idx)) {
/* 265 */       return (Map)foldoutCityMap.get(id + "_" + id);
/*     */     }
/*     */ 
/* 268 */     Map cityMap = dao.getFoldoutCity(id, id);
/* 269 */     foldoutCityMap.put(id + "_" + id, cityMap);
/* 270 */     return cityMap;
/*     */   }
/*     */ 
/*     */   public static int saveProduct(String cardno, String cardname, String filepath, String billtype)
/*     */   {
/* 282 */     return dao.saveProduct(cardno, cardname, filepath, billtype);
/*     */   }
/*     */ 
/*     */   public static void init()
/*     */   {
/* 288 */     if (dao == null) {
/* 289 */       dao = new DBDao();
/*     */     }
/* 291 */     if (businList == null)
/*     */     {
/* 293 */       businList = dao.getBusin();
/*     */     }
/* 295 */     if (cardList == null)
/*     */     {
/* 297 */       cardList = dao.getCard();
/*     */     }
/* 299 */     if (bfpntMap == null)
/*     */     {
/* 301 */       bfpntMap = dao.getBfpntMap();
/*     */     }
/* 303 */     if (cardBfpntMap == null)
/*     */     {
/* 305 */       cardBfpntMap = dao.getCardBfpntMap();
/*     */     }
/* 307 */     if (templateMap == null)
/*     */     {
/* 309 */       templateMap = getTemplateMap();
/*     */     }
/*     */ 
/* 312 */     if (wdMap == null)
/*     */     {
/* 314 */       wdMap = dao.getWDInfo();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void colse()
/*     */   {
/* 323 */     dao.close();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.teshuXML.Cache
 * JD-Core Version:    0.6.2
 */