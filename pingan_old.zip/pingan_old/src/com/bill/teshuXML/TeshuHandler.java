/*     */ package com.bill.teshuXML;
/*     */ 
/*     */ import com.bill.bean.Busin;
/*     */ import com.bill.bean.Plog;
/*     */ import com.bill.bean.UserBase;
/*     */ import com.bill.bean.Yyz;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class TeshuHandler
/*     */ {
/*     */   private EXml ex;
/*     */   private PXml px;
/*     */   private UserXml ux;
/*     */   private String cardid;
/*     */   private String cardtype;
/*     */   private String cardname;
/*     */   private StringBuffer xmlbase;
/*     */   private StringBuffer xmlp;
/*     */   private StringBuffer xmle;
/*     */   private static Logger log;
/*  20 */   private int p_count = 0;
/*  21 */   private int e_count = 0;
/*     */   private Plog plog1;
/*     */   private Plog plog2;
/*     */   private String filename;
/*  34 */   private boolean isPPrint = false;
/*     */ 
/*     */   public TeshuHandler(String cardid, String cardtype, String cardname) {
/*  37 */     log = Logger.getLogger(TeshuHandler.class);
/*  38 */     if ((cardid == null) || ("".equals(cardid))) {
/*  39 */       return;
/*     */     }
/*  41 */     this.cardid = cardid;
/*  42 */     this.cardtype = cardtype;
/*  43 */     this.cardname = cardname;
/*  44 */     this.ex = new EXml();
/*  45 */     this.px = new PXml();
/*  46 */     this.ux = new UserXml();
/*     */   }
/*     */ 
/*     */   public void handler()
/*     */   {
/*  52 */     List yyzlist = (List)Cache.cardBfpntMap.get(this.cardid);
/*  53 */     if (yyzlist == null) {
/*  54 */       log.debug("不存在卡产品对应的预印纸。卡产品ID=" + this.cardid);
/*  55 */       return;
/*     */     }
/*     */ 
/*  58 */     List wbsList = Cache.businList;
/*  59 */     if (wbsList == null) {
/*  60 */       log.debug("不存在外包商");
/*  61 */       return;
/*     */     }
/*     */ 
/*  64 */     List cityList = null;
/*  65 */     List userlist = null;
/*     */ 
/*  68 */     this.filename = this.ex.create(this.cardid, this.cardtype);
/*  69 */     this.plog1 = new Plog();
/*  70 */     this.plog1.setFilename(this.filename);
/*  71 */     this.plog1.setBusinpnt_no("");
/*  72 */     this.plog1.setCard_id(this.cardid);
/*  73 */     this.plog1.setPaper_no("");
/*  74 */     Cache.savePLogBegin(this.plog1);
/*  75 */     this.e_count = 0;
/*     */ 
/*  77 */     for (Yyz yyz : yyzlist)
/*     */     {
/*  79 */       if (Cache.bfpntMap.containsKey(yyz.getId()))
/*     */       {
/*  81 */         for (Busin b : wbsList)
/*     */         {
/*  83 */           cityList = Cache.getCityByCPB(this.cardid, yyz.getId(), b.getId());
/*  84 */           if (cityList.size() == 0) {
/*  85 */             log.error("没有关联的城市。产品ID=" + this.cardid + ",预印纸=" + yyz.getId() + ",外包商=" + b.getId());
/*     */           }
/*     */           else
/*     */           {
/*  89 */             this.filename = this.px.create(this.cardid, b.getId(), yyz.getPaperNo(), this.cardtype);
/*     */ 
/*  91 */             this.p_count = 0;
/*  92 */             this.plog2 = new Plog();
/*  93 */             this.plog2.setFilename(this.filename);
/*  94 */             this.plog2.setBusinpnt_no(b.getId());
/*  95 */             this.plog2.setCard_id(this.cardid);
/*  96 */             this.plog2.setPaper_no(yyz.getId());
/*  97 */             Cache.savePLogBegin(this.plog2);
/*     */             Iterator localIterator4;
/*  99 */             for (Iterator localIterator3 = cityList.iterator(); localIterator3.hasNext(); 
/* 104 */               localIterator4.hasNext())
/*     */             {
/*  99 */               String city = (String)localIterator3.next();
/*     */ 
/* 101 */               userlist = Cache.getUserBase(this.cardid, city);
/* 102 */               log.debug("产品ID=" + this.cardid + ",城市ID=" + city + ",账户数目=" + userlist.size());
/*     */ 
/* 104 */               localIterator4 = userlist.iterator(); continue; UserBase ub = (UserBase)localIterator4.next();
/* 105 */               this.isPPrint = "Y".equals(ub.getPaperflag());
/* 106 */               this.xmlbase = new StringBuffer();
/*     */ 
/* 108 */               this.xmlbase.append("<checksheet>\n");
/*     */ 
/* 110 */               this.ux.writeBaseXml(ub, this.xmlbase);
/*     */ 
/* 112 */               this.ux.writeEnvrule(b.getId(), ub, this.xmlbase);
/*     */ 
/* 114 */               if (this.ux.writeAccinfoXml(ub, this.xmlbase)) {
/* 115 */                 log.error("没有汇总信息!账号=" + ub.getAcctnbr());
/*     */               }
/*     */               else
/*     */               {
/* 119 */                 this.ux.writeAccinfoDetail(ub, this.xmlbase);
/*     */ 
/* 121 */                 this.ux.writeBuy(ub, this.xmlbase);
/*     */ 
/* 123 */                 this.ux.writeDebitinfo(ub, this.xmlbase);
/*     */ 
/* 125 */                 this.ux.writePoint(ub, this.xmlbase);
/*     */ 
/* 128 */                 if (this.isPPrint) {
/* 129 */                   this.xmlp = this.xmlbase;
/* 130 */                   this.xmlp.append(this.ux.writeTemplate(ub, "1").toString());
/* 131 */                   this.xmlp.append("</checksheet>\n");
/* 132 */                   this.px.write(this.xmlp.toString());
/* 133 */                   this.p_count += 1;
/*     */                 }
/*     */ 
/* 136 */                 this.xmle = this.xmlbase;
/* 137 */                 this.xmle.append(this.ux.writeTemplate(ub, "2").toString());
/*     */ 
/* 139 */                 this.xmle.append("</checksheet>\n");
/* 140 */                 this.ex.write(this.xmle.toString());
/* 141 */                 this.ex.over(this.e_count);
/* 142 */                 this.e_count += 1;
/*     */               }
/*     */             }
/* 145 */             this.px.over(this.p_count);
/* 146 */             if (this.p_count == 0) {
/* 147 */               Cache.savePLogDel(this.plog2);
/*     */             } else {
/* 149 */               this.plog2.setShare(this.p_count);
/* 150 */               this.plog2.setState("1");
/* 151 */               Cache.savePLogEnd(this.plog2);
/* 152 */               Cache.saveProduct(this.cardid, this.cardname, this.plog2.getFilename(), "1");
/*     */             }
/* 154 */             this.p_count = 0; } 
/*     */         }
/*     */       }
/* 157 */       else log.error("预印纸无效!账号=" + yyz.getId());
/*     */     }
/*     */ 
/* 160 */     this.ex.close(this.e_count);
/* 161 */     if (this.e_count == 0) {
/* 162 */       Cache.savePLogDel(this.plog1);
/*     */     } else {
/* 164 */       this.plog1.setShare(this.e_count);
/* 165 */       this.plog1.setState("1");
/* 166 */       Cache.savePLogEnd(this.plog1);
/* 167 */       Cache.saveProduct(this.cardid, this.cardname, this.plog2.getFilename(), "1");
/*     */     }
/* 169 */     this.e_count = 0;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.teshuXML.TeshuHandler
 * JD-Core Version:    0.6.2
 */