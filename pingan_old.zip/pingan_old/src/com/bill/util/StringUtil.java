/*    */ package com.bill.util;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class StringUtil
/*    */ {
/*    */   public static List<String> SplieASCII(String input)
/*    */   {
/*  8 */     char[] chars = input.toCharArray();
/*  9 */     int ascii = 0;
/* 10 */     StringBuffer temp = new StringBuffer();
/* 11 */     List templist = new ArrayList();
/* 12 */     for (int i = 0; i < chars.length; i++) {
/* 13 */       ascii = chars[i];
/* 14 */       if (1 == ascii) {
/* 15 */         templist.add(temp.toString());
/* 16 */         temp = new StringBuffer();
/*    */       } else {
/* 18 */         temp.append(String.valueOf(chars[i]));
/*    */       }
/*    */     }
/* 21 */     templist.add(temp.toString());
/* 22 */     return templist;
/*    */   }
/*    */   public static List<String> SplieASCII1E(String input) {
/* 25 */     char[] chars = input.toCharArray();
/* 26 */     int ascii = 0;
/* 27 */     StringBuffer temp = new StringBuffer();
/* 28 */     List templist = new ArrayList();
/* 29 */     for (int i = 0; i < chars.length; i++) {
/* 30 */       ascii = chars[i];
/* 31 */       if (30 == ascii) {
/* 32 */         templist.add(temp.toString());
/* 33 */         temp = new StringBuffer();
/*    */       } else {
/* 35 */         temp.append(String.valueOf(chars[i]));
/*    */       }
/*    */     }
/* 38 */     templist.add(temp.toString());
/* 39 */     return templist;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.util.StringUtil
 * JD-Core Version:    0.6.2
 */