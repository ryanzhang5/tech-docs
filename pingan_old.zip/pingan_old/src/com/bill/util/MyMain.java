/*    */ package com.bill.util;
/*    */ 
/*    */ import com.bill.bean.BaseParam;
/*    */ import com.bill.db.DbConnectionForOracle;
/*    */ import com.bill.util.config.ConfigReader;
/*    */ import java.io.PrintStream;
/*    */ import java.util.Map;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public abstract class MyMain
/*    */ {
/* 15 */   protected static Map<String, String> config = null;
/* 16 */   protected static Logger log = null;
/*    */ 
/*    */   public static void init()
/*    */   {
/*    */     try {
/* 21 */       ConfigReader.init();
/*    */     } catch (Exception e) {
/* 23 */       System.out.println("##### read properties file error, file path:" + ConfigReader.class.getClassLoader().getResource(ConfigReader.CONFIG_PATH));
/* 24 */       e.printStackTrace();
/* 25 */       return;
/*    */     }
/* 27 */     BaseParam.DB_IP = ConfigReader.read("db.ip");
/* 28 */     BaseParam.DB_PORT = ConfigReader.read("db.port");
/* 29 */     BaseParam.DB_NAME = ConfigReader.read("db.name");
/* 30 */     BaseParam.DB_USER = ConfigReader.read("db.user");
/* 31 */     BaseParam.DB_PWD = ConfigReader.read("db.pwd");
/*    */ 
/* 34 */     DbConnectionForOracle db = new DbConnectionForOracle(
/* 35 */       BaseParam.DB_IP, 
/* 36 */       BaseParam.DB_PORT, 
/* 37 */       BaseParam.DB_NAME, 
/* 38 */       BaseParam.DB_USER, 
/* 39 */       BaseParam.DB_PWD);
/*    */ 
/* 42 */     config = DaoBase.getConfig(db);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.util.MyMain
 * JD-Core Version:    0.6.2
 */