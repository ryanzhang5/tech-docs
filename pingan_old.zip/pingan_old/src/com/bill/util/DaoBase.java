/*     */ package com.bill.util;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.bean.Busin;
/*     */ import com.bill.bean.Card;
/*     */ import com.bill.bean.Fodder;
/*     */ import com.bill.bean.Foldout;
/*     */ import com.bill.bean.Rule;
/*     */ import com.bill.bean.RuleF;
/*     */ import com.bill.bean.RuleM;
/*     */ import com.bill.bean.TempArea;
/*     */ import com.bill.bean.Yyz;
/*     */ import com.bill.db.DbConnectionForOracle;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class DaoBase
/*     */ {
/*     */   private PreparedStatement statement;
/*     */   private ResultSet result;
/*  30 */   private static String CARD_SQL = "select t.s_buss_prod_id,t.s_buss_prod_name,t.c_buss_type_id from T_S_BUSI_PROD_INFO t where t.c_buss_prod_flag='0'";
/*     */ 
/*  35 */   private static String BFPNT_SQL = "select t.s_id from t_s_befor_print_basic  t where  to_date(?,'yyyyMM')>= to_date(t.c_period_begen,'yyyy-MM') and to_date(?,'yyyyMM')<= to_date(t.c_period_end,'yyyy-MM') and t.c_period_day=?";
/*     */ 
/*  40 */   private static String TEMPLATE_SQL = "select t.s_stencil_no,t.s_card_prod_id,t.c_type_no from T_S_STENCIL t where t.c_state='1'";
/*     */ 
/*  46 */   private static String CPB_CITY_SQL = "select t.s_city_no from t_s_bfpnt_cty_crdtp t where t.s_city_no is not null and t.s_card_no =? and t.s_id=? and t.s_businpnt_no=?";
/*     */ 
/*  52 */   private static String RULE_SQL = "select * from t_s_rule_m t where t.s_stencil_no=? and t.c_rule_type=? and t.i_area_no=? and t.c_state='1' and to_date(?,'yyyyMM')>=to_date(t.c_period_begen,'yyyy-MM') and to_date(?,'yyyyMM')<=to_date(t.c_period_end,'yyyy-MM') and t.s_period like '%'||?||'%' order by t.i_pri desc";
/*     */ 
/*  58 */   private static String getGLSQL = "select t.s_id, t.s_businpnt_no, t1.c_buss_type_id,t2.s_paper_no   from t_s_bfpnt_cty_crdtp t, t_s_busi_prod_info t1,t_s_befor_print_basic t2  where t.s_city_no=?    and t.s_card_no=?    AND t.s_id <> '0'    and t.s_businpnt_no > '0'    AND t.s_id=t2.s_id    and t.s_card_no = t1.s_buss_prod_id   and ? between t2.c_period_begen and t2.c_period_end   and t2.c_period_day=?";
/*     */ 
/*     */   public List<Busin> getBusin(DbConnectionForOracle dbconn)
/*     */   {
/*  75 */     List list = new ArrayList();
/*     */     try {
/*  77 */       this.statement = dbconn.getConnection().prepareStatement("select t1.s_businpnt_no,t1.s_businpnt_name from T_S_EPLBOLY_PNT t1");
/*  78 */       this.result = this.statement.executeQuery();
/*     */ 
/*  80 */       while (this.result.next()) {
/*  81 */         Busin e = new Busin();
/*  82 */         e.setId(this.result.getString("s_businpnt_no"));
/*  83 */         e.setName(this.result.getString("s_businpnt_name"));
/*  84 */         list.add(e);
/*     */       }
/*  86 */       this.result.close();
/*  87 */       this.statement.close();
/*     */     } catch (SQLException e) {
/*  89 */       e.printStackTrace();
/*     */     }
/*  91 */     return list;
/*     */   }
/*     */ 
/*     */   public List<Card> getCard(DbConnectionForOracle dbconn)
/*     */   {
/*  99 */     List list = new ArrayList();
/*     */     try {
/* 101 */       this.statement = dbconn.getConnection().prepareStatement(CARD_SQL);
/* 102 */       this.result = this.statement.executeQuery();
/*     */ 
/* 104 */       while (this.result.next()) {
/* 105 */         Card e = new Card();
/* 106 */         e.setId(this.result.getString("s_buss_prod_id"));
/* 107 */         e.setName(this.result.getString("s_buss_prod_name"));
/* 108 */         e.setType(this.result.getString("c_buss_type_id"));
/* 109 */         list.add(e);
/*     */       }
/* 111 */       this.result.close();
/* 112 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 114 */       e.printStackTrace();
/*     */     }
/* 116 */     return list;
/*     */   }
/*     */ 
/*     */   public static Map<String, String> getConfig(DbConnectionForOracle dbconn)
/*     */   {
/* 124 */     Map cmap = new HashMap();
/*     */     try {
/* 126 */       PreparedStatement statement = dbconn.getConnection().prepareStatement("select t.s_type,t.s_value from t_s_bill_para t");
/* 127 */       ResultSet result = statement.executeQuery();
/* 128 */       while (result.next()) {
/* 129 */         cmap.put(result.getString("s_type"), result.getString("s_value"));
/*     */       }
/* 131 */       result.close();
/* 132 */       statement.close();
/*     */     } catch (SQLException e) {
/* 134 */       e.printStackTrace();
/* 135 */       return cmap;
/*     */     }
/* 137 */     return cmap;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getBfpntMap(DbConnectionForOracle dbconn)
/*     */   {
/* 144 */     Map map = new HashMap();
/*     */ 
/* 146 */     String ym = BaseParam.PERIOD.substring(0, 6);
/*     */ 
/* 148 */     String d = BaseParam.PERIOD.substring(6);
/*     */     try {
/* 150 */       this.statement = dbconn.getConnection().prepareStatement(BFPNT_SQL);
/* 151 */       this.statement.setString(1, ym);
/* 152 */       this.statement.setString(2, ym);
/* 153 */       this.statement.setString(3, d);
/* 154 */       this.result = this.statement.executeQuery();
/*     */ 
/* 156 */       String id = "";
/* 157 */       while (this.result.next()) {
/* 158 */         id = this.result.getString(1);
/* 159 */         map.put(id, id);
/*     */       }
/* 161 */       this.result.close();
/* 162 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 164 */       e.printStackTrace();
/* 165 */       return null;
/*     */     }
/* 167 */     return map;
/*     */   }
/*     */ 
/*     */   public Map<String, List<Yyz>> getCardBfpntMap(DbConnectionForOracle dbconn)
/*     */   {
/* 175 */     Map map = new HashMap();
/*     */     try {
/* 177 */       this.statement = dbconn.getConnection().prepareStatement("select t.s_card_no,t.s_id,t2.S_PAPER_NO from t_s_bfpnt_cty_crdtp t,T_S_BEFOR_PRINT_BASIC t2 where t.s_id<>'0' and t.s_id=t2.s_id group by t.s_card_no,t.s_id,t2.S_PAPER_NO");
/* 178 */       this.result = this.statement.executeQuery();
/*     */ 
/* 180 */       String id1 = "";
/*     */ 
/* 183 */       while (this.result.next()) {
/* 184 */         Yyz y = new Yyz();
/* 185 */         id1 = this.result.getString("s_card_no");
/* 186 */         y.setId(this.result.getString("s_id"));
/* 187 */         y.setPaperNo(this.result.getString("S_PAPER_NO"));
/* 188 */         if (map.containsKey(id1)) {
/* 189 */           ((List)map.get(id1)).add(y);
/*     */         } else {
/* 191 */           List list = new ArrayList();
/* 192 */           list.add(y);
/* 193 */           map.put(id1, list);
/*     */         }
/*     */       }
/* 196 */       this.result.close();
/* 197 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 199 */       e.printStackTrace();
/* 200 */       return null;
/*     */     }
/* 202 */     return map;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getTemplateList(DbConnectionForOracle dbconn)
/*     */   {
/* 211 */     Map map = new HashMap();
/*     */     try {
/* 213 */       this.statement = dbconn.getConnection().prepareStatement(TEMPLATE_SQL);
/* 214 */       this.result = this.statement.executeQuery();
/* 215 */       while (this.result.next()) {
/* 216 */         map.put(this.result.getString("S_CARD_PROD_ID") + "_" + this.result.getString("C_TYPE_NO"), this.result.getString("S_STENCIL_NO"));
/*     */       }
/* 218 */       this.result.close();
/* 219 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 221 */       e.printStackTrace();
/*     */     }
/* 223 */     return map;
/*     */   }
/*     */ 
/*     */   public List<String> getCityByCPB(DbConnectionForOracle dbconn, String cid, String pid, String bid)
/*     */   {
/* 235 */     List list = new ArrayList();
/*     */     try {
/* 237 */       this.statement = dbconn.getConnection().prepareStatement(CPB_CITY_SQL);
/* 238 */       this.statement.setString(1, cid);
/* 239 */       this.statement.setString(2, pid);
/* 240 */       this.statement.setString(3, bid);
/* 241 */       this.result = this.statement.executeQuery();
/* 242 */       while (this.result.next()) {
/* 243 */         list.add(this.result.getString("S_CITY_NO"));
/*     */       }
/* 245 */       this.result.close();
/* 246 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 248 */       e.printStackTrace();
/*     */     }
/* 250 */     return list;
/*     */   }
/*     */ 
/*     */   public String getPointCardName(DbConnectionForOracle dbconn, String cardportid, String pointtype)
/*     */   {
/* 260 */     String ss = "";
/*     */     try {
/* 262 */       this.statement = dbconn.getConnection().prepareStatement("select t.s_card_name from t_s_busi_card2 t where t.c_card_id=? and t.c_pointtype=?");
/* 263 */       this.statement.setString(1, cardportid);
/* 264 */       this.statement.setString(2, pointtype);
/* 265 */       this.result = this.statement.executeQuery();
/* 266 */       while (this.result.next()) {
/* 267 */         ss = this.result.getString(1);
/*     */       }
/* 269 */       this.result.close();
/* 270 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 272 */       e.printStackTrace();
/* 273 */       return "";
/*     */     }
/* 275 */     return ss;
/*     */   }
/*     */ 
/*     */   public List<Rule> getRule(DbConnectionForOracle dbconn, String tid, String type, String area, String billdayYM, String billdayD)
/*     */   {
/* 288 */     List list = new ArrayList();
/*     */     try {
/* 290 */       this.statement = dbconn.getConnection().prepareStatement(RULE_SQL);
/* 291 */       this.statement.setString(1, tid);
/* 292 */       this.statement.setString(2, type);
/* 293 */       this.statement.setString(3, area);
/* 294 */       this.statement.setString(4, billdayYM);
/* 295 */       this.statement.setString(5, billdayYM);
/* 296 */       this.statement.setString(6, billdayD);
/* 297 */       this.result = this.statement.executeQuery();
/*     */ 
/* 299 */       while (this.result.next()) {
/* 300 */         Rule r = new Rule();
/* 301 */         r.setRuleid(this.result.getString("S_RULE_NO"));
/* 302 */         r.setTid(this.result.getString("S_STENCIL_NO"));
/* 303 */         r.setRuleType(this.result.getString("C_RULE_TYPE"));
/* 304 */         r.setType(this.result.getString("C_TYPENO"));
/* 305 */         r.setPri(this.result.getString("I_PRI"));
/* 306 */         r.setAreaNo(this.result.getString("I_AREA_NO"));
/* 307 */         list.add(r);
/*     */       }
/* 309 */       this.result.close();
/* 310 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 312 */       e.printStackTrace();
/*     */     }
/* 314 */     return list;
/*     */   }
/*     */ 
/*     */   public List<RuleF> getRuleF(DbConnectionForOracle dbconn, String rid)
/*     */   {
/* 322 */     List list = new ArrayList();
/*     */     try {
/* 324 */       this.statement = dbconn.getConnection().prepareStatement("select * from t_s_rule_f t where t.s_rule_no=? order by t.i_pri desc");
/* 325 */       this.statement.setString(1, rid);
/* 326 */       this.result = this.statement.executeQuery();
/*     */ 
/* 328 */       while (this.result.next()) {
/* 329 */         RuleF r = new RuleF();
/* 330 */         r.setId(this.result.getString("S_SEQUENCE"));
/* 331 */         r.setRid(this.result.getString("S_RULE_NO"));
/* 332 */         r.setFodder(this.result.getString("S_FODDER_NO"));
/* 333 */         r.setPri(this.result.getString("I_PRI"));
/* 334 */         list.add(r);
/*     */       }
/* 336 */       this.result.close();
/* 337 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 339 */       e.printStackTrace();
/*     */     }
/* 341 */     return list;
/*     */   }
/*     */ 
/*     */   public List<RuleM> getRuleFF(DbConnectionForOracle dbconn, String rid)
/*     */   {
/* 349 */     List list = new ArrayList();
/*     */     try {
/* 351 */       this.statement = dbconn.getConnection().prepareStatement("select * from t_s_rule_ff t where t.s_sequence=? order by t.s_idx");
/* 352 */       this.statement.setString(1, rid);
/* 353 */       this.result = this.statement.executeQuery();
/*     */ 
/* 355 */       while (this.result.next()) {
/* 356 */         RuleM r = new RuleM();
/* 357 */         r.setFieldid(this.result.getString("S_FIELD"));
/* 358 */         r.setOpr1(this.result.getInt("C_OPR_1"));
/* 359 */         r.setVal1(this.result.getString("S_VALIUE_1"));
/* 360 */         r.setOpr2(this.result.getInt("C_OPR_2"));
/* 361 */         r.setVal2(this.result.getString("S_VALIUE_2"));
/* 362 */         r.setCif(this.result.getInt("C_IF"));
/* 363 */         list.add(r);
/*     */       }
/* 365 */       this.result.close();
/* 366 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 368 */       e.printStackTrace();
/*     */     }
/* 370 */     return list;
/*     */   }
/*     */ 
/*     */   public List<TempArea> getTemplateInfo(DbConnectionForOracle dbconn, String tid)
/*     */   {
/* 377 */     List list = new ArrayList();
/*     */     try {
/* 379 */       this.statement = dbconn.getConnection().prepareStatement("select t.i_area_no,t.c_type_no from t_s_area t where t.s_stencil_no=?");
/* 380 */       this.statement.setString(1, tid);
/* 381 */       this.result = this.statement.executeQuery();
/*     */ 
/* 383 */       while (this.result.next()) {
/* 384 */         TempArea ta = new TempArea();
/* 385 */         ta.setArea(this.result.getString("i_area_no"));
/* 386 */         ta.setType(this.result.getString("c_type_no"));
/* 387 */         list.add(ta);
/*     */       }
/* 389 */       this.result.close();
/* 390 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 392 */       e.printStackTrace();
/*     */     }
/* 394 */     return list;
/*     */   }
/*     */ 
/*     */   public Fodder getFodder(DbConnectionForOracle dbconn, String fid, String d)
/*     */   {
/* 404 */     Fodder fodder = null;
/*     */     try {
/* 406 */       this.statement = dbconn.getConnection().prepareStatement("select t.s_fodder_no,t.s_fodder_doc_name,t.s_url from T_S_FODDER  t where t.s_fodder_no=? and t.c_state='1' and to_date(?, 'yyyyMM') between to_date(t.c_period_begen, 'yyyy-MM') and to_date(t.c_period_end, 'yyyy-MM')");
/* 407 */       this.statement.setString(1, fid);
/* 408 */       this.statement.setString(2, d);
/* 409 */       this.result = this.statement.executeQuery();
/* 410 */       while (this.result.next()) {
/* 411 */         fodder = new Fodder();
/* 412 */         fodder.setFid(this.result.getString("s_fodder_no"));
/* 413 */         fodder.setUrl(this.result.getString("s_fodder_doc_name"));
/* 414 */         fodder.setLinkurl(this.result.getString("s_url"));
/*     */       }
/* 416 */       this.result.close();
/* 417 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 419 */       e.printStackTrace();
/* 420 */       return null;
/*     */     }
/* 422 */     return fodder;
/*     */   }
/*     */ 
/*     */   public List<Foldout> getFoldout(DbConnectionForOracle dbconn, String bid, String cid, String billdate)
/*     */   {
/* 432 */     List list = new ArrayList();
/* 433 */     Foldout foldout = null;
/*     */     try {
/* 435 */       this.statement = dbconn.getConnection().prepareStatement("select * from T_S_FOLDOUT_PROD t2 where t2.i_id= (select t.i_id from T_S_FOLDOUT_PROD_SUB t where t.s_foldout_businpnt_no=? and t.s_foldout_prod_bpid=? and t.c_period=substr(?,7,2) and to_date(?,'yyyyMMdd') >= to_date(t.c_period_begen,'yyyy-MM')and to_date(?,'yyyyMMdd') <= to_date(t.c_period_end,'yyyy-MM')) order by t2.i_foldout_index");
/* 436 */       this.statement.setString(1, bid);
/* 437 */       this.statement.setString(2, cid);
/* 438 */       this.statement.setString(3, billdate);
/* 439 */       this.statement.setString(4, billdate);
/* 440 */       this.statement.setString(5, billdate);
/* 441 */       this.result = this.statement.executeQuery();
/* 442 */       while (this.result.next()) {
/* 443 */         foldout = new Foldout();
/* 444 */         foldout.setId(this.result.getString("I_FOLDOUT_INDEX"));
/* 445 */         foldout.setName(this.result.getString("S_FOLDOUT_PROD_NAME"));
/* 446 */         foldout.setPri(this.result.getInt("I_FOLDOUT_PRI"));
/* 447 */         list.add(foldout);
/*     */       }
/* 449 */       this.result.close();
/* 450 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 452 */       e.printStackTrace();
/* 453 */       return null;
/*     */     }
/* 455 */     return list;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getFoldoutCity(DbConnectionForOracle dbconn, String id, String idx)
/*     */   {
/* 467 */     Map map = new HashMap();
/* 468 */     String city = "";
/*     */     try {
/* 470 */       String sql = "select t.s_foldout_city from t_s_foldout_city t where t.i_id=? and t.i_foldout_index=?";
/* 471 */       this.statement = dbconn.getConnection().prepareStatement(sql);
/* 472 */       this.statement.setString(1, id);
/* 473 */       this.statement.setString(2, idx);
/* 474 */       this.result = this.statement.executeQuery();
/* 475 */       while (this.result.next()) {
/* 476 */         city = this.result.getString("s_foldout_city");
/* 477 */         map.put(city, city);
/*     */       }
/* 479 */       this.result.close();
/* 480 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 482 */       e.printStackTrace();
/* 483 */       return map;
/*     */     }
/* 485 */     return map;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getCity(DbConnectionForOracle dbconn, String addpos)
/*     */   {
/* 494 */     Map citymap = new HashMap();
/*     */     try {
/* 496 */       this.statement = dbconn.getConnection().prepareStatement("select * from t_s_code_tmp t");
/* 497 */       this.result = this.statement.executeQuery();
/* 498 */       while (this.result.next()) {
/* 499 */         citymap.put(this.result.getString("C_ZIPCODE"), this.result.getString("S_CITY_NO"));
/*     */       }
/* 501 */       this.result.close();
/* 502 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 504 */       e.printStackTrace();
/* 505 */       return citymap;
/*     */     }
/* 507 */     return citymap;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getGL(DbConnectionForOracle dbconn, String cardNo, String cityNo)
/*     */   {
/* 516 */     Map map = null;
/*     */     try {
/* 518 */       this.statement = dbconn.getConnection().prepareStatement(getGLSQL);
/* 519 */       this.statement.setString(1, cityNo);
/* 520 */       this.statement.setString(2, cardNo);
/* 521 */       this.statement.setString(3, BaseParam.PERIOD_Y + "-" + BaseParam.PERIOD_M);
/* 522 */       this.statement.setString(4, BaseParam.PERIOD_D);
/* 523 */       this.result = this.statement.executeQuery();
/* 524 */       while (this.result.next()) {
/* 525 */         map = new HashMap();
/* 526 */         map.put("yyz", this.result.getString("s_id"));
/* 527 */         map.put("yyzno", this.result.getString("s_paper_no"));
/* 528 */         map.put("wbs", this.result.getString("s_businpnt_no"));
/* 529 */         map.put("cardtype", this.result.getString("c_buss_type_id"));
/*     */       }
/* 531 */       this.result.close();
/* 532 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 534 */       e.printStackTrace();
/* 535 */       return null;
/*     */     }
/* 537 */     return map;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.util.DaoBase
 * JD-Core Version:    0.6.2
 */