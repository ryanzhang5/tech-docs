/*     */ package com.bill.util;
/*     */ 
/*     */ import com.bill.util.config.ConfigReader;
/*     */ import java.io.InputStream;
/*     */ import java.util.Properties;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.PropertyConfigurator;
/*     */ 
/*     */ public class LogInit
/*     */ {
/*     */   public static void init(String logFileName)
/*     */   {
/*  13 */     Properties properties = null;
/*  14 */     InputStream inputStream = null;
/*     */     try
/*     */     {
/*  17 */       properties = new Properties();
/*  18 */       inputStream = LogInit.class.getClassLoader().getResourceAsStream(
/*  19 */         ConfigReader.LOG_PATH);
/*     */ 
/*  23 */       properties.load(inputStream);
/*  24 */       String fileName = properties
/*  25 */         .getProperty("log4j.appender.DailyFile.File");
/*  26 */       properties.setProperty("log4j.appender.DailyFile.File", fileName
/*  27 */         .replace("<logfilename>", logFileName));
/*     */ 
/*  29 */       PropertyConfigurator.configure(properties);
/*     */     }
/*     */     catch (Exception eLog) {
/*     */       try {
/*  33 */         if (inputStream != null)
/*  34 */           inputStream.close();
/*     */       }
/*     */       catch (Exception eClose) {
/*  37 */         eClose.printStackTrace();
/*     */       }
/*  39 */       eLog.printStackTrace();
/*  40 */       System.exit(-1);
/*     */       try
/*     */       {
/*  44 */         if (inputStream != null)
/*  45 */           inputStream.close();
/*     */       }
/*     */       catch (Exception eClose) {
/*  48 */         eClose.printStackTrace();
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/*  44 */         if (inputStream != null)
/*  45 */           inputStream.close();
/*     */       }
/*     */       catch (Exception eClose) {
/*  48 */         eClose.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void init(String logpath, String logFileName)
/*     */   {
/*  60 */     Properties properties = null;
/*  61 */     InputStream inputStream = null;
/*     */     try
/*     */     {
/*  64 */       properties = new Properties();
/*  65 */       inputStream = LogInit.class.getClassLoader().getResourceAsStream(
/*  66 */         logpath);
/*     */ 
/*  70 */       properties.load(inputStream);
/*  71 */       String fileName = properties
/*  72 */         .getProperty("log4j.appender.DailyFile.File");
/*  73 */       properties.setProperty("log4j.appender.DailyFile.File", fileName
/*  74 */         .replace("<logfilename>", logFileName));
/*     */ 
/*  76 */       PropertyConfigurator.configure(properties);
/*     */     }
/*     */     catch (Exception eLog) {
/*     */       try {
/*  80 */         if (inputStream != null)
/*  81 */           inputStream.close();
/*     */       }
/*     */       catch (Exception eClose) {
/*  84 */         eClose.printStackTrace();
/*     */       }
/*  86 */       eLog.printStackTrace();
/*  87 */       System.exit(-1);
/*     */       try
/*     */       {
/*  91 */         if (inputStream != null)
/*  92 */           inputStream.close();
/*     */       }
/*     */       catch (Exception eClose) {
/*  95 */         eClose.printStackTrace();
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/*  91 */         if (inputStream != null)
/*  92 */           inputStream.close();
/*     */       }
/*     */       catch (Exception eClose) {
/*  95 */         eClose.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 104 */     init("c:\\loginittest.log");
/* 105 */     Logger log = Logger.getLogger(LogInit.class);
/* 106 */     log.info("LonInit info");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.util.LogInit
 * JD-Core Version:    0.6.2
 */