/*     */ package com.bill.util.config;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URL;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class DeployConfigReader
/*     */ {
/*  10 */   public static String LOG_PATH = "java/config/log4j.properties";
/*  11 */   public static String CONFIG_PATH = "java/config/deploy.properties";
/*     */ 
/*  16 */   private static String defaultModuleName = null;
/*     */ 
/*  18 */   private static Properties properties = null;
/*     */ 
/*  20 */   private static String rootPath = null;
/*     */ 
/*  22 */   public static String fileseparator = System.getProperty("file.separator");
/*     */ 
/*     */   public static void init() throws Exception {
/*  25 */     InputStream inputStream = null;
/*     */     try {
/*  27 */       properties = new Properties();
/*  28 */       inputStream = 
/*  30 */         DeployConfigReader.class.getClassLoader().getResourceAsStream(CONFIG_PATH);
/*  31 */       properties.load(inputStream);
/*     */     } finally {
/*     */       try {
/*  34 */         if (inputStream != null)
/*  35 */           inputStream.close();
/*     */       }
/*     */       catch (Exception eClose) {
/*  38 */         eClose.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void initDefaultModuleName(String defaultModuleName)
/*     */     throws Exception
/*     */   {
/*  49 */     if (defaultModuleName == null)
/*  50 */       defaultModuleName = defaultModuleName;
/*     */     else
/*  52 */       throw new Exception("重复的缺省模块名称初始化");
/*     */   }
/*     */ 
/*     */   public static String read(String name)
/*     */   {
/*  63 */     return properties.getProperty(name);
/*     */   }
/*     */ 
/*     */   public static String read(String type, String name)
/*     */     throws Exception
/*     */   {
/*  74 */     return properties.getProperty(type + "." + name);
/*     */   }
/*     */ 
/*     */   public static String read(String module, String type, String name)
/*     */     throws Exception
/*     */   {
/*  86 */     return properties.getProperty(module + "." + 
/*  87 */       type + "." + name);
/*     */   }
/*     */ 
/*     */   public static String readDefaultModule(String type, String name)
/*     */     throws Exception
/*     */   {
/*  98 */     if (defaultModuleName == null) {
/*  99 */       return read(type, name);
/*     */     }
/* 101 */     return read(defaultModuleName, type, name);
/*     */   }
/*     */ 
/*     */   public static String getRootPath()
/*     */   {
/* 107 */     if (rootPath != null) {
/* 108 */       return rootPath;
/*     */     }
/*     */ 
/* 111 */     String classPackageRootPath = null;
/*     */     try {
/* 113 */       classPackageRootPath = DeployConfigReader.class.getClass().getResource("/").getPath();
/* 114 */       if (!fileseparator.equals("/")) {
/* 115 */         classPackageRootPath = StringUtils.replace(classPackageRootPath, "/", fileseparator);
/*     */       }
/* 117 */       classPackageRootPath = StringUtils.replace(classPackageRootPath, "%20", " ");
/*     */ 
/* 119 */       rootPath = classPackageRootPath;
/*     */     } catch (Exception e) {
/* 121 */       classPackageRootPath = System.getProperty("user.dir") + 
/* 122 */         fileseparator;
/* 123 */       rootPath = classPackageRootPath;
/*     */     }
/* 125 */     return rootPath;
/*     */   }
/*     */ 
/*     */   public static String addRootPath(String fileName)
/*     */   {
/* 130 */     if (rootPath == null) {
/* 131 */       getRootPath();
/*     */     }
/* 133 */     if (rootPath == null) {
/* 134 */       return fileName;
/*     */     }
/* 136 */     return rootPath + "java/config/" + fileName;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try {
/* 142 */       init();
/* 143 */       System.out.println(read("make.xml.stmtdate"));
/*     */     } catch (Exception e) {
/* 145 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.util.config.DeployConfigReader
 * JD-Core Version:    0.6.2
 */