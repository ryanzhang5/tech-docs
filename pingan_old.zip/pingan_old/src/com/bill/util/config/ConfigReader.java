/*     */ package com.bill.util.config;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URL;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class ConfigReader
/*     */ {
/*  10 */   public static String LOG_PATH = "java/config/log4j.properties";
/*  11 */   public static String CONFIG_PATH = "java/config/deploy.properties";
/*     */ 
/*  17 */   private static String defaultModuleName = null;
/*     */ 
/*  19 */   private static Properties properties = null;
/*     */ 
/*  21 */   private static String rootPath = null;
/*     */ 
/*  23 */   public static String fileseparator = System.getProperty("file.separator");
/*     */ 
/*     */   public static void init() throws Exception {
/*  26 */     InputStream inputStream = null;
/*     */     try {
/*  28 */       properties = new Properties();
/*  29 */       inputStream = 
/*  31 */         ConfigReader.class.getClassLoader().getResourceAsStream(CONFIG_PATH);
/*  32 */       properties.load(inputStream);
/*     */     } finally {
/*     */       try {
/*  35 */         if (inputStream != null)
/*  36 */           inputStream.close();
/*     */       }
/*     */       catch (Exception eClose) {
/*  39 */         eClose.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void initDefaultModuleName(String defaultModuleName)
/*     */     throws Exception
/*     */   {
/*  50 */     if (defaultModuleName == null)
/*  51 */       defaultModuleName = defaultModuleName;
/*     */     else
/*  53 */       throw new Exception("重复的缺省模块名称初始化");
/*     */   }
/*     */ 
/*     */   public static String read(String name)
/*     */   {
/*  64 */     return properties.getProperty(name);
/*     */   }
/*     */ 
/*     */   public static String read(String type, String name)
/*     */     throws Exception
/*     */   {
/*  75 */     return properties.getProperty(type + "." + name);
/*     */   }
/*     */ 
/*     */   public static String read(String module, String type, String name)
/*     */     throws Exception
/*     */   {
/*  87 */     return properties.getProperty(module + "." + 
/*  88 */       type + "." + name);
/*     */   }
/*     */ 
/*     */   public static String readDefaultModule(String type, String name)
/*     */     throws Exception
/*     */   {
/*  99 */     if (defaultModuleName == null) {
/* 100 */       return read(type, name);
/*     */     }
/* 102 */     return read(defaultModuleName, type, name);
/*     */   }
/*     */ 
/*     */   public static String getRootPath()
/*     */   {
/* 108 */     if (rootPath != null) {
/* 109 */       return rootPath;
/*     */     }
/*     */ 
/* 112 */     String classPackageRootPath = null;
/*     */     try {
/* 114 */       classPackageRootPath = ConfigReader.class.getClass().getResource("/").getPath();
/* 115 */       if (!fileseparator.equals("/")) {
/* 116 */         classPackageRootPath = StringUtils.replace(classPackageRootPath, "/", fileseparator);
/*     */       }
/* 118 */       classPackageRootPath = StringUtils.replace(classPackageRootPath, "%20", " ");
/*     */ 
/* 120 */       rootPath = classPackageRootPath;
/*     */     } catch (Exception e) {
/* 122 */       classPackageRootPath = System.getProperty("user.dir") + 
/* 123 */         fileseparator;
/* 124 */       rootPath = classPackageRootPath;
/*     */     }
/* 126 */     return rootPath;
/*     */   }
/*     */ 
/*     */   public static String addRootPath(String fileName)
/*     */   {
/* 131 */     if (rootPath == null) {
/* 132 */       getRootPath();
/*     */     }
/* 134 */     if (rootPath == null) {
/* 135 */       return fileName;
/*     */     }
/* 137 */     return rootPath + "java/config/" + fileName;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try {
/* 143 */       init();
/* 144 */       System.out.println(read("make.xml.stmtdate"));
/*     */     } catch (Exception e) {
/* 146 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.util.config.ConfigReader
 * JD-Core Version:    0.6.2
 */