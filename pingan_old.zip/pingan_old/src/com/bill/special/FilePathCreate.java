/*    */ package com.bill.special;
/*    */ 
/*    */ import com.bill.bean.BaseParam;
/*    */ import com.bill.bean.Card;
/*    */ import com.bill.make.IFilePathCreate;
/*    */ import java.io.File;
/*    */ 
/*    */ public class FilePathCreate
/*    */   implements IFilePathCreate
/*    */ {
/*    */   public String getEmailFileNamePath(Card card)
/*    */   {
/* 15 */     String fileName = "HTML_" + card.getId() + "_" + System.currentTimeMillis() + ".xml";
/* 16 */     String fileDir = BaseParam.XML_PATH + card.getType() + File.separator + 
/* 17 */       "SPEC" + File.separator + 
/* 18 */       "XML" + File.separator + card.getPersonId() + File.separator;
/*    */ 
/* 20 */     return fileDir + fileName;
/*    */   }
/*    */ 
/*    */   public String getPaperFileNamePath(Card card, String yyz, String wbs)
/*    */   {
/* 28 */     String fileDir = BaseParam.XML_PATH + card.getType() + File.separator + 
/* 29 */       "SPEC" + File.separator + 
/* 30 */       "XML" + File.separator + card.getPersonId() + File.separator;
/* 31 */     String fileName = "TNO_" + card.getId() + "_" + yyz + "_" + wbs + "_" + System.currentTimeMillis() + ".xml";
/* 32 */     return fileDir + fileName;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.special.FilePathCreate
 * JD-Core Version:    0.6.2
 */