/*      */ package com.bill.special;
/*      */ 
/*      */ import com.bill.bean.Debitinfo;
/*      */ import com.bill.bean.Fodder;
/*      */ import com.bill.bean.Foldout;
/*      */ import com.bill.bean.PointInfo;
/*      */ import com.bill.bean.Rule;
/*      */ import com.bill.bean.RuleF;
/*      */ import com.bill.bean.RuleM;
/*      */ import com.bill.bean.TempArea;
/*      */ import com.bill.bean.UserAccinfo;
/*      */ import com.bill.bean.UserAccinfoDetail;
/*      */ import com.bill.bean.UserBase;
/*      */ import com.bill.bean.UserBuy;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.apache.log4j.Logger;
/*      */ 
/*      */ public class UserXml
/*      */ {
/*      */   private StringBuffer tab1;
/*      */   private StringBuffer tab2;
/*      */   private StringBuffer temp;
/*      */   private List<StringBuffer> tab2list;
/*      */   private List<UserAccinfo> listAccinfo;
/*      */   private List<UserAccinfoDetail> listAccinfoDetail;
/*      */   private List<Debitinfo> listDebitinfo;
/*      */   private List<PointInfo> listPointInfo;
/*      */   private List<Foldout> list;
/*      */   private List<TempArea> plist;
/*      */   private List<RuleF> rlist;
/*      */   private List<RuleF> dlist;
/*      */   private List<RuleM> mlist;
/*      */   private List<Rule> rulelist;
/*      */   private PointInfo point;
/*      */   private UserBuy ub;
/*      */   private DBDao dao;
/*   38 */   private Logger log = null;
/*      */ 
/*      */   public UserXml(DBDao dao) {
/*   41 */     this.log = Logger.getLogger(UserXml.class);
/*   42 */     this.dao = dao;
/*      */   }
/*      */ 
/*      */   public String getBaseXml(UserBase ub)
/*      */   {
/*   52 */     StringBuffer str = new StringBuffer();
/*   53 */     str.append("<acctnbr>").append(ub.getAcctnbr()).append("</acctnbr>\n");
/*   54 */     str.append("<rectype>").append(ub.getRectype()).append("</rectype>\n");
/*   55 */     str.append("<zip>").append(ub.getZip()).append("</zip>\n");
/*   56 */     str.append("<addrname3>").append(ub.getAddrname3()).append("</addrname3>\n");
/*   57 */     str.append("<addrname1>").append(ub.getAddrname1()).append("</addrname1>\n");
/*   58 */     str.append("<addrname2>").append(ub.getAddrname2()).append("</addrname2>\n");
/*   59 */     str.append("<name>").append(ub.getName()).append("</name>\n");
/*   60 */     str.append("<sex>").append(ub.getSex()).append("</sex>\n");
/*   61 */     str.append("<birthday>").append(ub.getBirthday()).append("</birthday>\n");
/*   62 */     str.append("<accnum>").append(ub.getAccnum()).append("</accnum>\n");
/*   63 */     str.append("<cusnum>").append(ub.getCusnum()).append("</cusnum>\n");
/*   64 */     str.append("<stfromdate>").append(ub.getStfromdate()).append("</stfromdate>\n");
/*   65 */     str.append("<enddate>").append(ub.getEnddate()).append("</enddate>\n");
/*   66 */     str.append("<specode>").append(ub.getSpecode()).append("</specode>\n");
/*   67 */     str.append("<pmtduemark>").append(ub.getPmtduemark()).append("</pmtduemark>\n");
/*   68 */     str.append("<cashmark>").append(ub.getCashmark()).append("</cashmark>\n");
/*   69 */     str.append("<indiv1>").append(ub.getIndiv1()).append("</indiv1>\n");
/*   70 */     str.append("<indiv2>").append(ub.getIndiv2()).append("</indiv2>\n");
/*   71 */     str.append("<indiv3>").append(ub.getIndiv3()).append("</indiv3>\n");
/*   72 */     str.append("<indiv4>").append(ub.getIndiv4()).append("</indiv4>\n");
/*   73 */     str.append("<indiv5>").append(ub.getIndiv5()).append("</indiv5>\n");
/*   74 */     str.append("<indiv6>").append(ub.getIndiv6()).append("</indiv6>\n");
/*   75 */     str.append("<indiv7>").append(ub.getIndiv7()).append("</indiv7>\n");
/*   76 */     str.append("<indiv8>").append(ub.getIndiv8()).append("</indiv8>\n");
/*   77 */     str.append("<actinfo>").append(ub.getActinfo()).append("</actinfo>\n");
/*   78 */     str.append("<dm1>").append(ub.getDm1()).append("</dm1>\n");
/*   79 */     str.append("<dm2>").append(ub.getDm2()).append("</dm2>\n");
/*   80 */     str.append("<dm3>").append(ub.getDm3()).append("</dm3>\n");
/*   81 */     str.append("<dm4>").append(ub.getDm4()).append("</dm4>\n");
/*   82 */     str.append("<brandmsg1>").append(ub.getBrandmsg1()).append("</brandmsg1>\n");
/*   83 */     str.append("<brandmsg2>").append(ub.getBrandmsg2()).append("</brandmsg2>\n");
/*   84 */     str.append("<brandmsg3>").append(ub.getBrandmsg3()).append("</brandmsg3>\n");
/*   85 */     str.append("<brandmsg4>").append(ub.getBrandmsg4()).append("</brandmsg4>\n");
/*   86 */     str.append("<brandmsg5>").append(ub.getBrandmsg5()).append("</brandmsg5>\n");
/*   87 */     str.append("<brandmsg6>").append(ub.getBrandmsg6()).append("</brandmsg6>\n");
/*   88 */     str.append("<brandmsg7>").append(ub.getBrandmsg7()).append("</brandmsg7>\n");
/*   89 */     str.append("<convexchmark>").append(ub.getConvexchmark()).append("</convexchmark>\n");
/*   90 */     str.append("<vipmsg1>").append(ub.getVipmsg1()).append("</vipmsg1>\n");
/*   91 */     str.append("<vipmsg2>").append(ub.getVipmsg2()).append("</vipmsg2>\n");
/*   92 */     str.append("<vipmsg3>").append(ub.getVipmsg3()).append("</vipmsg3>\n");
/*   93 */     str.append("<vipmsg4>").append(ub.getVipmsg4()).append("</vipmsg4>\n");
/*   94 */     str.append("<reprintflag>").append(ub.getReprintflag()).append("</reprintflag>\n");
/*   95 */     str.append("<emailflag>").append(ub.getEmailflag()).append("</emailflag>\n");
/*   96 */     str.append("<paperflag>").append(ub.getPaperflag()).append("</paperflag>\n");
/*   97 */     str.append("<emailaddr>").append(ub.getEmailaddr()).append("</emailaddr>\n");
/*   98 */     str.append("<custtype>").append(ub.getCusttype()).append("</custtype>\n");
/*   99 */     str.append("<mobilenbr>").append(ub.getMobilenbr()).append("</mobilenbr>\n");
/*  100 */     str.append("<ainbr>").append(ub.getAinbr()).append("</ainbr>\n");
/*  101 */     str.append("<mobdate>").append(ub.getMobdate()).append("</mobdate>\n");
/*  102 */     str.append("<filler>").append(ub.getFiller()).append("</filler>\n");
/*  103 */     str.append("<citycode>").append(ub.getCity()).append("</citycode>\n");
/*  104 */     return str.toString();
/*      */   }
/*      */ 
/*      */   public void writeBaseXml(UserBase ub, StringBuffer xml)
/*      */   {
/*  117 */     xml.append("<acctnbr>" + ub.getAcctnbr() + "</acctnbr>\n");
/*  118 */     xml.append("<rectype>" + ub.getRectype() + "</rectype>\n");
/*  119 */     xml.append("<zip>" + ub.getZip() + "</zip>\n");
/*  120 */     xml.append("<addrname3>" + ub.getAddrname3() + " </addrname3>\n");
/*  121 */     xml.append("<addrname1>" + ub.getAddrname1() + " </addrname1>\n");
/*  122 */     xml.append("<addrname2>" + ub.getAddrname2() + " </addrname2>\n");
/*  123 */     xml.append("<name>" + ub.getName() + " </name>\n");
/*  124 */     xml.append("<sex>" + ub.getSex() + "</sex>\n");
/*  125 */     xml.append("<birthday>" + ub.getBirthday() + "</birthday>\n");
/*  126 */     xml.append("<accnum>" + ub.getAccnum() + "</accnum>\n");
/*  127 */     xml.append("<cusnum>" + ub.getCusnum() + "</cusnum>\n");
/*  128 */     xml.append("<stfromdate>" + ub.getStfromdate() + "</stfromdate>\n");
/*  129 */     xml.append("<enddate>" + ub.getEnddate() + "</enddate>\n");
/*  130 */     xml.append("<specode>" + ub.getSpecode() + "</specode>\n");
/*  131 */     xml.append("<pmtduemark>" + ub.getPmtduemark() + "</pmtduemark>\n");
/*  132 */     xml.append("<cashmark>" + ub.getCashmark() + "</cashmark>\n");
/*  133 */     xml.append("<indiv1>" + ub.getIndiv1() + "</indiv1>\n");
/*  134 */     xml.append("<indiv2>" + ub.getIndiv2() + "</indiv2>\n");
/*  135 */     xml.append("<indiv3>" + ub.getIndiv3() + "</indiv3>\n");
/*  136 */     xml.append("<indiv4>" + ub.getIndiv4() + "</indiv4>\n");
/*  137 */     xml.append("<indiv5>" + ub.getIndiv5() + "</indiv5>\n");
/*  138 */     xml.append("<indiv6>" + ub.getIndiv6() + "</indiv6>\n");
/*  139 */     xml.append("<indiv7>" + ub.getIndiv7() + "</indiv7>\n");
/*  140 */     xml.append("<indiv8>" + ub.getIndiv8() + "</indiv8>\n");
/*  141 */     xml.append("<actinfo>" + ub.getActinfo() + "</actinfo>\n");
/*  142 */     xml.append("<dm1>" + ub.getDm1() + "</dm1>\n");
/*  143 */     xml.append("<dm2>" + ub.getDm2() + "</dm2>\n");
/*  144 */     xml.append("<dm3>" + ub.getDm3() + "</dm3>\n");
/*  145 */     xml.append("<dm4>" + ub.getDm4() + "</dm4>\n");
/*  146 */     xml.append("<brandmsg1>" + ub.getBrandmsg1() + "</brandmsg1>\n");
/*  147 */     xml.append("<brandmsg2>" + ub.getBrandmsg2() + "</brandmsg2>\n");
/*  148 */     xml.append("<brandmsg3>" + ub.getBrandmsg3() + "</brandmsg3>\n");
/*  149 */     xml.append("<brandmsg4>" + ub.getBrandmsg4() + "</brandmsg4>\n");
/*  150 */     xml.append("<brandmsg5>" + ub.getBrandmsg5() + "</brandmsg5>\n");
/*  151 */     xml.append("<brandmsg6>" + ub.getBrandmsg6() + "</brandmsg6>\n");
/*  152 */     xml.append("<brandmsg7>" + ub.getBrandmsg7() + "</brandmsg7>\n");
/*  153 */     xml.append("<convexchmark>" + ub.getConvexchmark() + "</convexchmark>\n");
/*  154 */     xml.append("<vipmsg1>" + ub.getVipmsg1() + "</vipmsg1>\n");
/*  155 */     xml.append("<vipmsg2>" + ub.getVipmsg2() + "</vipmsg2>\n");
/*  156 */     xml.append("<vipmsg3>" + ub.getVipmsg3() + "</vipmsg3>\n");
/*  157 */     xml.append("<vipmsg4>" + ub.getVipmsg4() + "</vipmsg4>\n");
/*  158 */     xml.append("<reprintflag>" + ub.getReprintflag() + "</reprintflag>\n");
/*  159 */     xml.append("<emailflag>" + ub.getEmailflag() + "</emailflag>\n");
/*  160 */     xml.append("<paperflag>" + ub.getPaperflag() + "</paperflag>\n");
/*  161 */     xml.append("<emailaddr>" + ub.getEmailaddr() + "</emailaddr>\n");
/*  162 */     xml.append("<custtype>" + ub.getCusttype() + "</custtype>\n");
/*  163 */     xml.append("<mobilenbr>" + ub.getMobilenbr() + "</mobilenbr>\n");
/*  164 */     xml.append("<ainbr>" + ub.getAinbr() + "</ainbr>\n");
/*  165 */     xml.append("<mobdate>" + ub.getMobdate() + "</mobdate>\n");
/*  166 */     xml.append("<filler>" + ub.getFiller() + "</filler>\n");
/*  167 */     xml.append("<citycode>" + ub.getCity() + "</citycode>\n");
/*      */   }
/*      */ 
/*      */   public String getEnvrule(String wbs, UserBase ub) {
/*  171 */     List list = Cache.getFoldout(wbs, ub.getCardNo(), this.dao);
/*  172 */     String tag = "";
/*  173 */     String temp = "";
/*  174 */     Foldout f = null;
/*  175 */     if (list.size() > 0) {
/*  176 */       for (int i = 0; i < list.size(); i++) {
/*  177 */         f = (Foldout)list.get(i);
/*      */ 
/*  179 */         if ("0".equals(f.getState())) {
/*  180 */           tag = tag + "0";
/*  181 */           temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */         }
/*  183 */         else if ("1".equals(f.getState())) {
/*  184 */           switch (i) {
/*      */           case 0:
/*  186 */             if ("Y".equals(ub.getDm1())) {
/*  187 */               tag = tag + "1";
/*  188 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*      */             } else {
/*  190 */               tag = tag + "0";
/*  191 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */             }
/*  193 */             break;
/*      */           case 1:
/*  195 */             if ("Y".equals(ub.getDm2())) {
/*  196 */               tag = tag + "1";
/*  197 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*      */             } else {
/*  199 */               tag = tag + "0";
/*  200 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */             }
/*  202 */             break;
/*      */           case 2:
/*  204 */             if ("Y".equals(ub.getDm3())) {
/*  205 */               tag = tag + "1";
/*  206 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*      */             } else {
/*  208 */               tag = tag + "0";
/*  209 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */             }
/*  211 */             break;
/*      */           case 3:
/*  213 */             if ("Y".equals(ub.getDm4())) {
/*  214 */               tag = tag + "1";
/*  215 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*      */             } else {
/*  217 */               tag = tag + "0";
/*  218 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */             }
/*  220 */             break;
/*      */           default:
/*  222 */             tag = tag + "0";
/*  223 */             temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*  224 */             break;
/*      */           }
/*      */         }
/*  227 */         else if ("2".equals(f.getState()))
/*      */         {
/*  229 */           Map city = Cache.getFoldoutCity(f.getId(), f.getIdx(), this.dao);
/*  230 */           if (city.containsKey(ub.getCity())) {
/*  231 */             tag = tag + "1";
/*  232 */             temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*      */           } else {
/*  234 */             tag = tag + "0";
/*  235 */             temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */           }
/*      */         } else {
/*  238 */           tag = tag + "0";
/*  239 */           temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */         }
/*      */       }
/*      */     } else {
/*  243 */       tag = "0000";
/*  244 */       temp = "<INPRIORITY1>0</INPRIORITY1>\n<INPRIORITY2>0</INPRIORITY2>\n<INPRIORITY3>0</INPRIORITY3>\n<INPRIORITY4>0</INPRIORITY4>\n";
/*      */     }
/*  246 */     String str = "<ENVRULE>" + tag + "</ENVRULE>\n" + temp;
/*  247 */     return str;
/*      */   }
/*      */ 
/*      */   public void writeEnvrule(String wbs, UserBase ub, StringBuffer xml)
/*      */   {
/*  258 */     this.list = Cache.getFoldout(wbs, ub.getCardNo(), this.dao);
/*  259 */     String tag = "";
/*  260 */     String temp = "";
/*  261 */     Foldout f = null;
/*  262 */     if (this.list.size() > 0) {
/*  263 */       for (int i = 0; i < this.list.size(); i++) {
/*  264 */         f = (Foldout)this.list.get(0);
/*      */ 
/*  266 */         if ("0".equals(f.getState())) {
/*  267 */           tag = tag + "0";
/*  268 */           temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */         }
/*  270 */         else if ("1".equals(f.getState())) {
/*  271 */           switch (i) {
/*      */           case 0:
/*  273 */             if ("Y".equals(ub.getDm1())) {
/*  274 */               tag = tag + "1";
/*  275 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*      */             } else {
/*  277 */               tag = tag + "0";
/*  278 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */             }
/*  280 */             break;
/*      */           case 1:
/*  282 */             if ("Y".equals(ub.getDm2())) {
/*  283 */               tag = tag + "1";
/*  284 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*      */             } else {
/*  286 */               tag = tag + "0";
/*  287 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */             }
/*  289 */             break;
/*      */           case 2:
/*  291 */             if ("Y".equals(ub.getDm3())) {
/*  292 */               tag = tag + "1";
/*  293 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*      */             } else {
/*  295 */               tag = tag + "0";
/*  296 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */             }
/*  298 */             break;
/*      */           case 3:
/*  300 */             if ("Y".equals(ub.getDm4())) {
/*  301 */               tag = tag + "1";
/*  302 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*      */             } else {
/*  304 */               tag = tag + "0";
/*  305 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */             }
/*  307 */             break;
/*      */           default:
/*  309 */             tag = tag + "0";
/*  310 */             temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*  311 */             break;
/*      */           }
/*      */         }
/*  314 */         else if ("2".equals(f.getState()))
/*      */         {
/*  316 */           Map city = Cache.getFoldoutCity(f.getId(), f.getIdx(), this.dao);
/*  317 */           if (city.containsKey(ub.getCity())) {
/*  318 */             tag = tag + "1";
/*  319 */             temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*      */           } else {
/*  321 */             tag = tag + "0";
/*  322 */             temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */           }
/*      */         } else {
/*  325 */           tag = tag + "0";
/*  326 */           temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */         }
/*      */       }
/*      */     } else {
/*  330 */       tag = "0000";
/*  331 */       temp = "<INPRIORITY1>0</INPRIORITY1>\n<INPRIORITY2>0</INPRIORITY2>\n<INPRIORITY3>0</INPRIORITY3>\n<INPRIORITY4>0</INPRIORITY4>\n";
/*      */     }
/*  333 */     xml.append("<ENVRULE>" + tag + "</ENVRULE>\n");
/*  334 */     xml.append(temp);
/*      */   }
/*      */ 
/*      */   public String getAccInfoXml(UserBase ub)
/*      */   {
/*  339 */     this.tab1 = new StringBuffer();
/*  340 */     this.tab2 = new StringBuffer();
/*      */ 
/*  342 */     this.listAccinfo = this.dao.getUserInfo(ub);
/*      */ 
/*  344 */     for (UserAccinfo ua : this.listAccinfo)
/*      */     {
/*  346 */       if ("B001".equals(ua.getRectype())) {
/*  347 */         readAccinfo(this.tab1, ua);
/*      */       }
/*  349 */       else if ("D001".equals(ua.getRectype())) {
/*  350 */         readAccinfo(this.tab2, ua);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  355 */     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
/*  356 */       StringBuilder xml = new StringBuilder();
/*  357 */       xml.append("<accinfo>\n");
/*  358 */       if (this.tab1.length() > 0) {
/*  359 */         xml.append("<tab1>\n");
/*  360 */         xml.append(this.tab1.toString());
/*  361 */         xml.append("</tab1>\n");
/*      */       }
/*  363 */       if (this.tab2.length() > 0) {
/*  364 */         xml.append("<tab2>\n");
/*  365 */         xml.append(this.tab2.toString());
/*  366 */         xml.append("</tab2>\n");
/*      */       }
/*  368 */       xml.append("</accinfo>\n");
/*  369 */       return xml.toString();
/*      */     }
/*  371 */     return null;
/*      */   }
/*      */ 
/*      */   public boolean writeAccinfoXml(UserBase ub, StringBuffer xml)
/*      */   {
/*  381 */     this.tab1 = new StringBuffer();
/*  382 */     this.tab2 = new StringBuffer();
/*      */ 
/*  384 */     this.listAccinfo = this.dao.getUserInfo(ub);
/*      */ 
/*  386 */     for (UserAccinfo ua : this.listAccinfo)
/*      */     {
/*  388 */       if ("B001".equals(ua.getRectype())) {
/*  389 */         readAccinfo(this.tab1, ua);
/*      */       }
/*  391 */       else if ("D001".equals(ua.getRectype())) {
/*  392 */         readAccinfo(this.tab2, ua);
/*      */       }
/*      */     }
/*      */ 
/*  396 */     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
/*  397 */       xml.append("<accinfo>\n");
/*  398 */       if (this.tab1.length() > 0) {
/*  399 */         xml.append("<tab1>\n");
/*  400 */         xml.append(this.tab1.toString());
/*  401 */         xml.append("</tab1>\n");
/*      */       }
/*  403 */       if (this.tab2.length() > 0) {
/*  404 */         xml.append("<tab2>\n");
/*  405 */         xml.append(this.tab2.toString());
/*  406 */         xml.append("</tab2>\n");
/*      */       }
/*  408 */       xml.append("</accinfo>\n");
/*  409 */       return false;
/*      */     }
/*  411 */     return true;
/*      */   }
/*      */ 
/*      */   private void readAccinfo(StringBuffer sb, UserAccinfo ua) {
/*  415 */     sb.append("<acctnbr>" + ua.getAcctnbr() + "</acctnbr>\n");
/*  416 */     sb.append("<rectype>" + ua.getRectype() + "</rectype>\n");
/*  417 */     sb.append("<stmtdate>" + ua.getStmtdate() + "</stmtdate>\n");
/*  418 */     sb.append("<pmtdate>" + ua.getPmtdate() + "</pmtdate>\n");
/*  419 */     sb.append("<totbegbal>" + ua.getTotbegbal() + "</totbegbal>\n");
/*  420 */     sb.append("<plantotpmt>" + ua.getPlantotpmt() + "</plantotpmt>\n");
/*  421 */     sb.append("<plantotnrlamt>" + ua.getPlantotnrlamt() + "</plantotnrlamt>\n");
/*  422 */     sb.append("<plantotadjamt>" + ua.getPlantotadjamt() + "</plantotadjamt>\n");
/*  423 */     sb.append("<intdueamt>" + ua.getIntdueamt() + "</intdueamt>\n");
/*  424 */     sb.append("<currbal>" + ua.getCurrbal() + "</currbal>\n");
/*  425 */     sb.append("<totdueamt>" + ua.getTotdueamt() + "</totdueamt>\n");
/*  426 */     sb.append("<pmtprint>" + ua.getPmtprint() + "</pmtprint>\n");
/*  427 */     sb.append("<crlim>" + ua.getCrlim() + "</crlim>\n");
/*  428 */     sb.append("<cashcrlim>" + ua.getCashcrlim() + "</cashcrlim>\n");
/*  429 */     sb.append("<pmtarn>" + ua.getPmtarn() + "</pmtarn>\n");
/*  430 */     sb.append("<pmtadn>" + ua.getPmtadn() + "</pmtadn>\n");
/*  431 */     sb.append("<projap>" + ua.getProjap() + "</projap>\n");
/*  432 */     sb.append("<pmtaflag>" + ua.getPmtaflag() + "</pmtaflag>\n");
/*  433 */     sb.append("<achflag>" + ua.getAchflag() + "</achflag>\n");
/*  434 */     sb.append("<pmtflag>" + ua.getPmtflag() + "</pmtflag>\n");
/*  435 */     sb.append("<filler>" + ua.getFiller() + "</filler>\n");
/*      */   }
/*      */ 
/*      */   public String getAccinfoDetail(UserBase ub) {
/*  439 */     this.tab1 = new StringBuffer();
/*  440 */     this.tab2 = new StringBuffer();
/*  441 */     this.listAccinfoDetail = this.dao.getAccinfoDetail(ub);
/*  442 */     for (UserAccinfoDetail uad : this.listAccinfoDetail)
/*      */     {
/*  444 */       if ("C001".equals(uad.getRectype())) {
/*  445 */         readAccinfoDetail(this.tab1, uad);
/*      */       }
/*  447 */       else if ("E001".equals(uad.getRectype())) {
/*  448 */         readAccinfoDetail(this.tab2, uad);
/*      */       }
/*      */     }
/*      */ 
/*  452 */     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
/*  453 */       StringBuilder xml = new StringBuilder();
/*  454 */       xml.append("<transinfo>\n");
/*  455 */       if (this.tab1.length() > 0) {
/*  456 */         xml.append("<tab1>\n<lists>\n");
/*  457 */         xml.append(this.tab1.toString());
/*  458 */         xml.append("</lists>\n</tab1>\n");
/*      */       }
/*  460 */       if (this.tab2.length() > 0) {
/*  461 */         xml.append("<tab2>\n<lists>\n");
/*  462 */         xml.append(this.tab2.toString());
/*  463 */         xml.append("</lists>\n</tab2>\n");
/*      */       }
/*  465 */       xml.append("</transinfo>\n");
/*  466 */       return xml.toString();
/*      */     }
/*  468 */     return "";
/*      */   }
/*      */ 
/*      */   public void writeAccinfoDetail(UserBase ub, StringBuffer xml)
/*      */   {
/*  478 */     this.tab1 = new StringBuffer();
/*  479 */     this.tab2 = new StringBuffer();
/*  480 */     this.listAccinfoDetail = this.dao.getAccinfoDetail(ub);
/*  481 */     for (UserAccinfoDetail uad : this.listAccinfoDetail)
/*      */     {
/*  483 */       if ("C001".equals(uad.getRectype())) {
/*  484 */         readAccinfoDetail(this.tab1, uad);
/*      */       }
/*  486 */       else if ("E001".equals(uad.getRectype())) {
/*  487 */         readAccinfoDetail(this.tab2, uad);
/*      */       }
/*      */     }
/*      */ 
/*  491 */     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
/*  492 */       xml.append("<transinfo>\n");
/*  493 */       if (this.tab1.length() > 0) {
/*  494 */         xml.append("<tab1>\n<lists>\n");
/*  495 */         xml.append(this.tab1);
/*  496 */         xml.append("</lists>\n</tab1>\n");
/*      */       }
/*  498 */       if (this.tab2.length() > 0) {
/*  499 */         xml.append("<tab2>\n<lists>\n");
/*  500 */         xml.append(this.tab2);
/*  501 */         xml.append("</lists>\n</tab2>\n");
/*      */       }
/*  503 */       xml.append("</transinfo>\n");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void readAccinfoDetail(StringBuffer sb, UserAccinfoDetail uad) {
/*  508 */     sb.append("<list>\n");
/*  509 */     sb.append("<acctnbr>" + uad.getAcctnbr() + "</acctnbr>\n");
/*  510 */     sb.append("<rectype>" + uad.getRectype() + "</rectype>\n");
/*  511 */     sb.append("<recseq>" + uad.getRecseq() + "</recseq>\n");
/*  512 */     sb.append("<effdate>" + uad.getEffdate() + "</effdate>\n");
/*  513 */     sb.append("<postdate>" + uad.getPostdate() + "</postdate>\n");
/*  514 */     sb.append("<cardnlast4>" + uad.getCardnlast4() + "</cardnlast4>\n");
/*  515 */     sb.append("<desc>" + uad.getDesc() + "</desc>\n");
/*  516 */     sb.append("<txnamt>" + uad.getTxnamt() + "</txnamt>\n");
/*  517 */     sb.append("<srctamt>" + uad.getSrctamt() + "</srctamt>\n");
/*  518 */     sb.append("<srctcurr>" + uad.getSrctcurr() + "</srctcurr>\n");
/*  519 */     sb.append("<purcty>" + uad.getPurcty() + "</purcty>\n");
/*  520 */     sb.append("<filler>" + uad.getFiller() + "</filler>\n");
/*  521 */     sb.append("</list>\n");
/*      */   }
/*      */ 
/*      */   public String getBuy(UserBase user) {
/*  525 */     this.ub = this.dao.getUserBuy(user);
/*      */ 
/*  527 */     if (this.ub == null)
/*  528 */       return "";
/*  529 */     StringBuilder xml = new StringBuilder();
/*  530 */     xml.append("<exchinfo>\n");
/*  531 */     xml.append("<acctnbr>" + this.ub.getAcctnbr() + "</acctnbr>\n");
/*  532 */     xml.append("<rectype>" + this.ub.getRectype() + "</rectype>\n");
/*  533 */     xml.append("<exchusdamt>" + this.ub.getExchusdamt() + "</exchusdamt>\n");
/*  534 */     xml.append("<sellrate>" + this.ub.getSellrate() + "</sellrate>\n");
/*  535 */     xml.append("<exchrmbamt>" + this.ub.getExchrmbamt() + "</exchrmbamt>\n");
/*  536 */     xml.append("<achrtnbr>" + this.ub.getAchrtnbr() + "</achrtnbr>\n");
/*  537 */     xml.append("<achdbnbr>" + this.ub.getAchdbnbr() + "</achdbnbr>\n");
/*  538 */     xml.append("<filler>" + this.ub.getFiller() + "</filler>\n");
/*  539 */     xml.append("</exchinfo>\n");
/*  540 */     return xml.toString();
/*      */   }
/*      */ 
/*      */   public void writeBuy(UserBase user, StringBuffer xml)
/*      */   {
/*  550 */     this.ub = this.dao.getUserBuy(user);
/*      */ 
/*  552 */     if (this.ub == null) return;
/*  553 */     xml.append("<exchinfo>\n");
/*  554 */     xml.append("<acctnbr>" + this.ub.getAcctnbr() + "</acctnbr>\n");
/*  555 */     xml.append("<rectype>" + this.ub.getRectype() + "</rectype>\n");
/*  556 */     xml.append("<exchusdamt>" + this.ub.getExchusdamt() + "</exchusdamt>\n");
/*  557 */     xml.append("<sellrate>" + this.ub.getSellrate() + "</sellrate>\n");
/*  558 */     xml.append("<exchrmbamt>" + this.ub.getExchrmbamt() + "</exchrmbamt>\n");
/*  559 */     xml.append("<achrtnbr>" + this.ub.getAchrtnbr() + "</achrtnbr>\n");
/*  560 */     xml.append("<achdbnbr>" + this.ub.getAchdbnbr() + "</achdbnbr>\n");
/*  561 */     xml.append("<filler>" + this.ub.getFiller() + "</filler>\n");
/*  562 */     xml.append("</exchinfo>\n");
/*      */   }
/*      */ 
/*      */   public String getDebitInfo(UserBase sb) {
/*  566 */     this.tab1 = new StringBuffer();
/*  567 */     this.tab2 = new StringBuffer();
/*  568 */     this.listDebitinfo = this.dao.getDebitinfo(sb);
/*  569 */     for (Debitinfo di : this.listDebitinfo) {
/*  570 */       if ("C002".equals(di.getRectype()))
/*  571 */         readDebitinfo(this.tab1, di);
/*  572 */       else if ("E002".equals(di.getRectype())) {
/*  573 */         readDebitinfo(this.tab2, di);
/*      */       }
/*      */     }
/*      */ 
/*  577 */     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
/*  578 */       StringBuilder xml = new StringBuilder();
/*  579 */       xml.append("<debitinfo>\n");
/*  580 */       if (this.tab1.length() > 0) {
/*  581 */         xml.append("<tab1>\n<lists>\n");
/*  582 */         xml.append(this.tab1.toString());
/*  583 */         xml.append("</lists>\n</tab1>\n");
/*      */       }
/*  585 */       if (this.tab2.length() > 0) {
/*  586 */         xml.append("<tab2>\n<lists>\n");
/*  587 */         xml.append(this.tab2.toString());
/*  588 */         xml.append("</lists>\n</tab2>\n");
/*      */       }
/*  590 */       xml.append("</debitinfo>\n");
/*  591 */       return xml.toString();
/*      */     }
/*  593 */     return "";
/*      */   }
/*      */ 
/*      */   public void writeDebitinfo(UserBase user, StringBuffer xml)
/*      */   {
/*  603 */     this.tab1 = new StringBuffer();
/*  604 */     this.tab2 = new StringBuffer();
/*  605 */     this.listDebitinfo = this.dao.getDebitinfo(user);
/*  606 */     for (Debitinfo di : this.listDebitinfo) {
/*  607 */       if ("C002".equals(di.getRectype()))
/*  608 */         readDebitinfo(this.tab1, di);
/*  609 */       else if ("E002".equals(di.getRectype())) {
/*  610 */         readDebitinfo(this.tab2, di);
/*      */       }
/*      */     }
/*      */ 
/*  614 */     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
/*  615 */       xml.append("<debitinfo>\n");
/*  616 */       if (this.tab1.length() > 0) {
/*  617 */         xml.append("<tab1>\n<lists>\n");
/*  618 */         xml.append(this.tab1.toString());
/*  619 */         xml.append("</lists>\n</tab1>\n");
/*      */       }
/*  621 */       if (this.tab2.length() > 0) {
/*  622 */         xml.append("<tab2>\n<lists>\n");
/*  623 */         xml.append(this.tab2.toString());
/*  624 */         xml.append("</lists>\n</tab2>\n");
/*      */       }
/*  626 */       xml.append("</debitinfo>\n");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void readDebitinfo(StringBuffer temp, Debitinfo di) {
/*  631 */     temp.append("<list>\n");
/*  632 */     temp.append("<acctnbr>" + di.getAcctnbr() + "</acctnbr>\n");
/*  633 */     temp.append("<rectype>" + di.getRectype() + "</rectype>\n");
/*  634 */     temp.append("<custnbr>" + di.getCustnbr() + "</custnbr>\n");
/*  635 */     temp.append("<effdate>" + di.getEffdate() + "</effdate>\n");
/*  636 */     temp.append("<txndesc>" + di.getTxndesc() + "</txndesc>\n");
/*  637 */     temp.append("<txncity>" + di.getTxncity() + "</txncity>\n");
/*  638 */     temp.append("<currcode>" + di.getCurrcode() + "</currcode>\n");
/*  639 */     temp.append("<txnamt>" + di.getTxnamt() + "</txnamt>\n");
/*  640 */     temp.append("<cardl4>" + di.getCardl4() + "</cardl4>\n");
/*  641 */     temp.append("<filler>" + di.getFiller() + "</filler>\n");
/*  642 */     temp.append("</list>\n");
/*      */   }
/*      */ 
/*      */   public String getPoint(UserBase ub)
/*      */   {
/*  647 */     this.tab1 = new StringBuffer();
/*  648 */     this.tab2list = new ArrayList();
/*  649 */     this.temp = new StringBuffer();
/*      */ 
/*  652 */     this.listPointInfo = this.dao.getPoint(ub);
/*      */ 
/*  654 */     this.point = this.dao.getPoint2(ub);
/*      */ 
/*  656 */     for (PointInfo pi : this.listPointInfo)
/*      */     {
/*  658 */       if ("3".equals(pi.getPointtype())) {
/*  659 */         readPoint(this.tab1, pi);
/*  660 */       } else if ("2".equals(pi.getPointtype())) {
/*  661 */         this.tab2 = new StringBuffer();
/*  662 */         readPoint(this.tab2, pi);
/*  663 */         this.tab2list.add(this.tab2);
/*  664 */       } else if ("4".equals(pi.getPointtype())) {
/*  665 */         if (this.point == null) {
/*  666 */           this.point = new PointInfo();
/*  667 */           this.point.setBilldate(ub.getStmtdate());
/*  668 */           this.point.setBusinessid(ub.getCusnum().substring(7));
/*  669 */           this.point.setAblepoint("0");
/*  670 */           this.point.setExpirespoint("0");
/*      */         }
/*  672 */         this.point.setAddpoint(pi.getAddpoint());
/*  673 */         this.point.setAdpoints(pi.getAdpoints());
/*      */       }
/*      */     }
/*      */ 
/*  677 */     if (this.point != null) {
/*  678 */       this.temp.append("<tab3>\n");
/*  679 */       this.temp.append("<billdate>" + this.point.getBilldate() + "</billdate>\n");
/*  680 */       this.temp.append("<ecifno>" + this.point.getBusinessid() + "</ecifno>\n");
/*  681 */       this.temp.append("<curpavalia>" + this.point.getAblepoint() + "</curpavalia>\n");
/*  682 */       this.temp.append("<pointavabf>" + this.point.getLastbalpoint() + "</pointavabf>\n");
/*  683 */       this.temp.append("<newpoint>" + this.point.getAddpoint() + "</newpoint>\n");
/*  684 */       this.temp.append("<pointredee>" + this.point.getExpoint() + "</pointredee>\n");
/*  685 */       this.temp.append("<adpoints>" + this.point.getAdpoints() + "</adpoints>\n");
/*  686 */       this.temp.append("<invalidpoint>" + this.point.getEndpoints() + "</invalidpoint>\n");
/*  687 */       this.temp.append("<expirespoint>").append(this.point.getExpirespoint()).append("</expirespoint>\n");
/*  688 */       this.temp.append("</tab3>\n");
/*      */     }
/*      */ 
/*  691 */     if ((this.tab1.length() > 0) || (this.tab2list.size() > 0) || (this.temp.length() > 0)) {
/*  692 */       StringBuilder xml = new StringBuilder();
/*  693 */       xml.append("<point-info>\n");
/*  694 */       if (this.tab1.length() > 0) {
/*  695 */         xml.append("<tab1>\n");
/*  696 */         xml.append(this.tab1.toString());
/*  697 */         xml.append("</tab1>\n");
/*      */       }
/*  699 */       if (this.tab2list.size() > 0) {
/*  700 */         xml.append("<tab2>\n<lists>\n");
/*  701 */         for (StringBuffer sb : this.tab2list) {
/*  702 */           xml.append("<list>\n").append(sb).append("</list>\n");
/*      */         }
/*  704 */         xml.append("</lists>\n</tab2>\n");
/*      */       }
/*  706 */       if (this.temp.length() > 0) {
/*  707 */         xml.append(this.temp.toString());
/*      */       }
/*  709 */       xml.append("</point-info>\n");
/*  710 */       return xml.toString();
/*      */     }
/*  712 */     return "";
/*      */   }
/*      */ 
/*      */   public void writePoint(UserBase user, StringBuffer xml)
/*      */   {
/*  722 */     this.tab1 = new StringBuffer();
/*  723 */     this.tab2list = new ArrayList();
/*  724 */     this.temp = new StringBuffer();
/*      */ 
/*  727 */     this.listPointInfo = this.dao.getPoint(user);
/*      */ 
/*  729 */     this.point = this.dao.getPoint2(user);
/*  730 */     for (PointInfo pi : this.listPointInfo)
/*      */     {
/*  732 */       if ("3".equals(pi.getPointtype())) {
/*  733 */         readPoint(this.tab1, pi);
/*  734 */       } else if ("2".equals(pi.getPointtype())) {
/*  735 */         this.tab2 = new StringBuffer();
/*  736 */         readPoint(this.tab2, pi);
/*  737 */         this.tab2list.add(this.tab2);
/*  738 */       } else if ("4".equals(pi.getPointtype())) {
/*  739 */         if (this.point == null) {
/*  740 */           this.point = new PointInfo();
/*  741 */           this.point.setBilldate(user.getStmtdate());
/*  742 */           this.point.setBusinessid(user.getCusnum().substring(7));
/*  743 */           this.point.setAblepoint("0");
/*  744 */           this.point.setExpirespoint("0");
/*      */         }
/*  746 */         this.point.setAddpoint(pi.getAddpoint());
/*  747 */         this.point.setAdpoints(pi.getAdpoints());
/*      */       }
/*      */     }
/*      */ 
/*  751 */     if (this.point != null) {
/*  752 */       this.temp.append("<tab3>\n");
/*  753 */       this.temp.append("<billdate>" + this.point.getBilldate() + "</billdate>\n");
/*  754 */       this.temp.append("<ecifno>" + this.point.getBusinessid() + "</ecifno>\n");
/*  755 */       this.temp.append("<curpavalia>" + this.point.getAblepoint() + "</curpavalia>\n");
/*  756 */       this.temp.append("<pointavabf>" + this.point.getLastbalpoint() + "</pointavabf>\n");
/*  757 */       this.temp.append("<newpoint>" + this.point.getAddpoint() + "</newpoint>\n");
/*  758 */       this.temp.append("<pointredee>" + this.point.getExpoint() + "</pointredee>\n");
/*  759 */       this.temp.append("<adpoints>" + this.point.getAdpoints() + "</adpoints>\n");
/*  760 */       this.temp.append("<invalidpoint>" + this.point.getEndpoints() + "</invalidpoint>\n");
/*  761 */       this.temp.append("</tab3>\n");
/*      */     }
/*      */ 
/*  764 */     if ((this.tab1.length() > 0) || (this.tab2list.size() > 0) || (this.temp.length() > 0)) {
/*  765 */       xml.append("<point-info>\n");
/*  766 */       if (this.tab1.length() > 0) {
/*  767 */         xml.append("<tab1>\n");
/*  768 */         xml.append(this.tab1.toString());
/*  769 */         xml.append("</tab1>\n");
/*      */       }
/*  771 */       if (this.tab2list.size() > 0) {
/*  772 */         xml.append("<tab2>\n<lists>\n");
/*  773 */         for (StringBuffer sb : this.tab2list) {
/*  774 */           xml.append("<list>\n" + sb.toString() + "</list>\n");
/*      */         }
/*  776 */         xml.append("</lists>\n</tab2>\n");
/*      */       }
/*  778 */       if (this.temp.length() > 0) {
/*  779 */         xml.append(this.temp.toString());
/*      */       }
/*  781 */       xml.append("</point-info>\n");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void readPoint(StringBuffer sb, PointInfo pi)
/*      */   {
/*  791 */     if ("1".equals(pi.getCardPointType())) {
/*  792 */       sb.append("<pointtype>A</pointtype>\n");
/*      */     }
/*  794 */     else if ("2".equals(pi.getCardPointType()))
/*  795 */       sb.append("<pointtype>B</pointtype>\n");
/*      */     else {
/*  797 */       sb.append("<pointtype>" + pi.getPointtype() + "</pointtype>\n");
/*      */     }
/*  799 */     sb.append("<cardportid>" + pi.getCardportid() + "</cardportid>\n");
/*  800 */     sb.append("<businessid>" + pi.getBusinessid() + "</businessid>\n");
/*  801 */     sb.append("<ablepoint>" + pi.getAblepoint() + "</ablepoint>\n");
/*  802 */     sb.append("<lastbalpoint>" + pi.getLastbalpoint() + "</lastbalpoint>\n");
/*  803 */     sb.append("<addpoint>" + pi.getAddpoint() + "</addpoint>\n");
/*  804 */     sb.append("<expoint>" + pi.getExpoint() + "</expoint>\n");
/*  805 */     sb.append("<adpoints>" + pi.getAdpoints() + "</adpoints>\n");
/*  806 */     sb.append("<endpoints>" + pi.getEndpoints() + "</endpoints>\n");
/*  807 */     sb.append("<ecifno>" + pi.getEcifno() + "</ecifno>\n");
/*  808 */     sb.append("<startdate>" + pi.getStartdate() + "</startdate>\n");
/*  809 */     sb.append("<enddate>" + pi.getEnddate() + "</enddate>\n");
/*  810 */     sb.append("<wholeconsume>" + pi.getWholeconsume() + "</wholeconsume>\n");
/*  811 */     sb.append("<inconsume>" + pi.getInconsume() + "</inconsume>\n");
/*  812 */     sb.append("<outconsume>" + pi.getOutconsume() + "</outconsume>\n");
/*  813 */     sb.append("<wholemoney>" + pi.getWholemoney() + "</wholemoney>\n");
/*  814 */     sb.append("<inmoney>" + pi.getInmoney() + "</inmoney>\n");
/*  815 */     sb.append("<outmoney>" + pi.getOutmoney() + "</outmoney>\n");
/*  816 */     sb.append("<usedmoney>" + pi.getUsedmoney() + "</usedmoney>\n");
/*  817 */     sb.append("<lavemoney>" + pi.getLavemoney() + "</lavemoney>\n");
/*  818 */     sb.append("<validdate>" + pi.getValiddate() + "</validdate>\n");
/*  819 */     sb.append("<laddermoney>" + pi.getLaddermoney() + "</laddermoney>\n");
/*  820 */     sb.append("<ladderscale>" + pi.getLadderscale() + "</ladderscale>\n");
/*      */ 
/*  822 */     if ("2".equals(pi.getPointtype())) {
/*  823 */       sb.append("<card4>" + pi.getCard4() + "</card4>\n");
/*      */     }
/*  825 */     sb.append("<cardname>" + pi.getCardname() + "</cardname>\n");
/*      */   }
/*      */ 
/*      */   public StringBuffer writeTemplate(UserBase user, String type)
/*      */   {
/*  839 */     this.temp = new StringBuffer();
/*      */ 
/*  841 */     String ptId = (String)Cache.templateMap.get(user.getCardNo() + "_" + type);
/*      */ 
/*  843 */     this.plist = Cache.getTemplateInfo(ptId, this.dao);
/*  844 */     Fodder f = null;
/*      */ 
/*  846 */     boolean isExtis = false;
/*      */ 
/*  848 */     int idx = 1;
/*  849 */     this.temp.append("<resourcesinfo>\n<lists>\n");
/*      */ 
/*  851 */     for (TempArea ta : this.plist) {
/*  852 */       isExtis = false;
/*  853 */       idx = 1;
/*      */ 
/*  855 */       this.rulelist = Cache.getRuleMap(ptId, "1", ta.getArea(), this.dao);
/*      */ 
/*  858 */       if ((this.rulelist != null) && (this.rulelist.size() > 0))
/*      */       {
/*  860 */         for (Rule rm : this.rulelist)
/*      */         {
/*  862 */           if (isExtis)
/*      */           {
/*      */             break;
/*      */           }
/*  866 */           this.rlist = Cache.getRuleFMap(rm.getRuleid(), this.dao);
/*  867 */           if (this.rlist != null)
/*      */           {
/*  869 */             for (RuleF rf : this.rlist)
/*      */             {
/*  872 */               f = Cache.getFodder(rf.getFodder(), this.dao);
/*      */ 
/*  874 */               if (f == null) {
/*  875 */                 this.log.error("素材无效!模板ID=" + ptId + ";区域规则ID=" + rm.getRuleid() + "条件个数=" + this.rlist.size() + ";素材=" + rf.getFodder());
/*      */               }
/*  879 */               else if ("3".equals(ta.getType())) {
/*  880 */                 isExtis = true;
/*  881 */                 readRuleXml(this.temp, type, ta.getArea(), Integer.valueOf(idx), f.getUrl(), f.getLinkurl());
/*  882 */                 idx++;
/*      */               }
/*      */               else
/*      */               {
/*  886 */                 this.mlist = Cache.getRuleFFList(rf.getId(), this.dao);
/*      */ 
/*  889 */                 if ((this.mlist == null) || (this.mlist.size() == 0) || (readRule(this.mlist, user))) {
/*  890 */                   isExtis = true;
/*      */ 
/*  892 */                   if ("4".equals(ta.getType()))
/*      */                   {
/*  894 */                     readRuleXml(this.temp, type, ta.getArea(), Integer.valueOf(idx), f.getUrl(), f.getLinkurl());
/*  895 */                     idx++;
/*      */                   }
/*      */                   else {
/*  898 */                     readRuleXml(this.temp, type, ta.getArea(), rf.getPri(), f.getUrl(), f.getLinkurl());
/*      */ 
/*  900 */                     break;
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*  906 */           else this.log.error("没有规则详情!模板ID=" + ptId + ";区域规则ID=" + rm.getRuleid());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  911 */       if (!isExtis) {
/*  912 */         idx = 1;
/*  913 */         this.rulelist = Cache.getRuleMap(ptId, "0", ta.getArea(), this.dao);
/*  914 */         if ((this.rulelist != null) && (this.rulelist.size() > 0))
/*      */         {
/*  916 */           this.dlist = Cache.getRuleFMap(((Rule)this.rulelist.get(0)).getRuleid(), this.dao);
/*  917 */           if ((this.dlist != null) && (this.dlist.size() > 0))
/*  918 */             for (RuleF rf : this.dlist)
/*      */             {
/*  920 */               f = Cache.getFodder(rf.getFodder(), this.dao);
/*      */ 
/*  922 */               if (f == null) {
/*  923 */                 this.log.error("没有默认规则的素材！模板=" + ptId + ",区域=" + ta.getArea() + ",素材=" + rf.getFodder());
/*      */               }
/*      */               else {
/*  926 */                 readRuleXml(this.temp, type, ta.getArea(), Integer.valueOf(idx), f.getUrl(), f.getLinkurl());
/*  927 */                 if ((!"3".equals(ta.getType())) && (!"4".equals(ta.getType()))) {
/*      */                   break;
/*      */                 }
/*  930 */                 idx++;
/*      */               }
/*      */             }
/*  933 */           else this.log.error("没有默认的规则！模板=" + ptId + ",区域=" + ta.getArea());
/*      */         }
/*      */       }
/*      */ 
/*  937 */       isExtis = false;
/*      */     }
/*  939 */     this.temp.append("</lists>\n</resourcesinfo>\n");
/*  940 */     return this.temp;
/*      */   }
/*      */ 
/*      */   public void readRuleXml(StringBuffer xml, String type, String area, Object pri, String url, String link)
/*      */   {
/*  952 */     xml.append("<list>\n<billtype>");
/*  953 */     xml.append(type);
/*  954 */     xml.append("</billtype>\n<area>");
/*  955 */     xml.append(area);
/*  956 */     xml.append("</area>\n<priority>");
/*  957 */     xml.append(pri);
/*  958 */     xml.append("</priority>\n<rescontent>");
/*  959 */     if ("1".equals(type)) {
/*  960 */       xml.append(url);
/*      */     } else {
/*  962 */       int i = url.lastIndexOf("/");
/*  963 */       if (i != -1) {
/*  964 */         xml.append((String)Cache.configMap.get("MATTERPATH"))
/*  965 */           .append(url.substring(i + 1));
/*      */       }
/*      */       else {
/*  968 */         xml.append(url);
/*      */       }
/*      */     }
/*  971 */     xml.append("</rescontent>\n<resurl>");
/*  972 */     xml.append(link);
/*  973 */     xml.append("</resurl>\n</list>\n");
/*      */   }
/*      */ 
/*      */   public boolean readRule(List<RuleM> list, UserBase user)
/*      */   {
/*  983 */     boolean result = false;
/*  984 */     boolean oldresult = false;
/*  985 */     int next_if = 0;
/*  986 */     String wd = "";
/*  987 */     for (RuleM rm : list)
/*      */     {
/*  989 */       wd = rm.getFieldid();
/*      */ 
/*  991 */       if ("birthday".equals(wd)) {
/*  992 */         String temp = user.birthday;
/*      */ 
/*  994 */         if (user.birthday.length() > 4) {
/*  995 */           temp = user.birthday.substring(4);
/*      */         }
/*  997 */         oldresult = checkValue(rm, temp);
/*      */       }
/*  999 */       else if ("sex".equals(wd))
/*      */       {
/* 1001 */         if (rm.getOpr1() != 0) {
/* 1002 */           return false;
/*      */         }
/*      */ 
/* 1005 */         oldresult = rm.getVal1().equals(user.sex);
/*      */       }
/* 1007 */       else if ("city".equals(wd))
/*      */       {
/* 1009 */         if (rm.getOpr1() != 0) {
/* 1010 */           return false;
/*      */         }
/*      */ 
/* 1013 */         oldresult = rm.getVal1().equals(user.city);
/*      */       }
/* 1015 */       else if ("mobilenbr".equals(wd))
/*      */       {
/* 1017 */         if (rm.getOpr1() != 0) {
/* 1018 */           return false;
/*      */         }
/*      */ 
/* 1021 */         if (user.mobilenbr.indexOf(rm.getVal1()) == 0)
/* 1022 */           oldresult = true;
/*      */         else {
/* 1024 */           oldresult = false;
/*      */         }
/*      */       }
/* 1027 */       else if ("ainbr".equals(wd))
/*      */       {
/* 1029 */         if (rm.getOpr1() != 0) {
/* 1030 */           return false;
/*      */         }
/* 1032 */         oldresult = rm.getVal1().equals(user.ainbr);
/*      */       }
/* 1034 */       else if ("mobdate".equals(wd)) {
/* 1035 */         oldresult = checkValue(rm, user.mobdate);
/*      */       }
/* 1037 */       else if ("crlim".equals(wd)) {
/* 1038 */         oldresult = checkValue(rm, user.crlim);
/*      */       }
/* 1040 */       else if ("currbal".equals(wd)) {
/* 1041 */         oldresult = checkValue(rm, user.currbal);
/*      */       }
/* 1043 */       else if ("totdueamt".equals(wd)) {
/* 1044 */         oldresult = checkValue(rm, user.totdueamt);
/*      */       }
/* 1046 */       else if ("cashcrlim".equals(wd)) {
/* 1047 */         oldresult = checkValue(rm, user.cashcrlim);
/*      */       }
/* 1049 */       else if ("indiv1".equals(wd))
/*      */       {
/* 1051 */         if (rm.getOpr1() != 0) {
/* 1052 */           return false;
/*      */         }
/*      */ 
/* 1055 */         oldresult = rm.getVal1().equals(user.indiv1);
/*      */       }
/* 1057 */       else if ("indiv2".equals(wd))
/*      */       {
/* 1059 */         if (rm.getOpr1() != 0) {
/* 1060 */           return false;
/*      */         }
/*      */ 
/* 1063 */         oldresult = rm.getVal1().equals(user.indiv2);
/*      */       }
/* 1065 */       else if ("indiv3".equals(wd))
/*      */       {
/* 1067 */         if (rm.getOpr1() != 0) {
/* 1068 */           return false;
/*      */         }
/*      */ 
/* 1071 */         oldresult = rm.getVal1().equals(user.indiv3);
/*      */       }
/* 1073 */       else if ("indiv4".equals(wd))
/*      */       {
/* 1075 */         if (rm.getOpr1() != 0) {
/* 1076 */           return false;
/*      */         }
/*      */ 
/* 1079 */         oldresult = rm.getVal1().equals(user.indiv4);
/*      */       }
/* 1081 */       else if ("indiv5".equals(wd))
/*      */       {
/* 1083 */         if (rm.getOpr1() != 0) {
/* 1084 */           return false;
/*      */         }
/*      */ 
/* 1087 */         oldresult = rm.getVal1().equals(user.indiv5);
/*      */       }
/* 1089 */       else if ("indiv6".equals(wd))
/*      */       {
/* 1091 */         if (rm.getOpr1() != 0) {
/* 1092 */           return false;
/*      */         }
/*      */ 
/* 1095 */         oldresult = rm.getVal1().equals(user.indiv6);
/*      */       }
/* 1097 */       else if ("indiv7".equals(wd))
/*      */       {
/* 1099 */         if (rm.getOpr1() != 0) {
/* 1100 */           return false;
/*      */         }
/*      */ 
/* 1103 */         oldresult = rm.getVal1().equals(user.indiv7);
/*      */       }
/* 1105 */       else if ("indiv8".equals(wd))
/*      */       {
/* 1107 */         if (rm.getOpr1() != 0) {
/* 1108 */           return false;
/*      */         }
/*      */ 
/* 1111 */         oldresult = rm.getVal1().equals(user.indiv8);
/*      */       }
/*      */ 
/* 1114 */       if (next_if == 0) {
/* 1115 */         result = oldresult;
/*      */       }
/* 1117 */       else if (1 == next_if) {
/* 1118 */         result = (result) && (oldresult);
/*      */       }
/* 1120 */       else if (2 == next_if) {
/* 1121 */         result = (result) || (oldresult);
/*      */       }
/*      */ 
/* 1124 */       next_if = rm.getCif();
/*      */     }
/* 1126 */     return result;
/*      */   }
/*      */ 
/*      */   private boolean checkValue(RuleM rm, Object val)
/*      */   {
/* 1136 */     boolean result = false;
/* 1137 */     boolean result1 = false;
/* 1138 */     boolean result2 = false;
/* 1139 */     float i_val = 0.0F;
/* 1140 */     float i_val1 = 0.0F;
/* 1141 */     float i_val2 = 0.0F;
/*      */     try
/*      */     {
/* 1145 */       if ((val instanceof String))
/* 1146 */         i_val = Float.valueOf(val.toString()).floatValue();
/*      */       else {
/* 1148 */         i_val = ((Float)val).floatValue();
/*      */       }
/* 1150 */       i_val1 = Float.parseFloat(rm.getVal1());
/* 1151 */       if ((rm.getVal2() == null) || ("".equals(rm.getVal2())))
/* 1152 */         i_val2 = -1.0F;
/*      */       else
/* 1154 */         i_val2 = Float.parseFloat(rm.getVal2());
/*      */     }
/*      */     catch (Exception e) {
/* 1157 */       this.log.error("规则条件参数转型失败！参数1=" + rm.getVal1() + ",参数2=" + rm.getVal2());
/* 1158 */       return false;
/*      */     }
/*      */ 
/* 1162 */     if (rm.getOpr1() == 0)
/*      */     {
/* 1164 */       result = rm.getVal1().equals(val);
/*      */     }
/*      */     else
/*      */     {
/* 1169 */       if (1 == rm.getOpr1())
/* 1170 */         result1 = i_val > i_val1;
/* 1171 */       else if (2 == rm.getOpr1())
/* 1172 */         result1 = i_val < i_val1;
/* 1173 */       else if (3 == rm.getOpr1())
/* 1174 */         result1 = i_val >= i_val1;
/* 1175 */       else if (4 == rm.getOpr1()) {
/* 1176 */         result1 = i_val <= i_val1;
/*      */       }
/*      */ 
/* 1180 */       if (-1.0F == i_val2) {
/* 1181 */         result2 = false;
/*      */       }
/* 1183 */       else if (1 == rm.getOpr2())
/* 1184 */         result2 = i_val > i_val2;
/* 1185 */       else if (2 == rm.getOpr2())
/* 1186 */         result2 = i_val < i_val2;
/* 1187 */       else if (3 == rm.getOpr2())
/* 1188 */         result2 = i_val >= i_val2;
/* 1189 */       else if (4 == rm.getOpr2()) {
/* 1190 */         result2 = i_val >= i_val2;
/*      */       }
/*      */ 
/* 1193 */       result = (result1) && (result2);
/*      */     }
/* 1195 */     return result;
/*      */   }
/*      */ 
/*      */   public List<UserBase> getUserBase(String cardid, String city, int page, int size)
/*      */   {
/* 1204 */     return this.dao.getUserBase(cardid, city, page, size);
/*      */   }
/*      */ 
/*      */   public List<UserBase> getUserBase(String cardid, int page, int size)
/*      */   {
/* 1213 */     return this.dao.getUserBase(cardid, page, size);
/*      */   }
/*      */ 
/*      */   public void close()
/*      */   {
/* 1219 */     this.dao.close();
/*      */   }
/*      */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.special.UserXml
 * JD-Core Version:    0.6.2
 */