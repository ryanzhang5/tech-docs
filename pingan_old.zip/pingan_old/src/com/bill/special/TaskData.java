/*    */ package com.bill.special;
/*    */ 
/*    */ import com.bill.bean.Card;
/*    */ import com.bill.bean.UserBase;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.concurrent.BlockingQueue;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class TaskData
/*    */   implements Runnable
/*    */ {
/* 19 */   private static Logger log = Logger.getLogger(TaskData.class);
/*    */   private DBDao dao;
/*    */   private int maxBatchNumber;
/*    */   private int maxThreedNumber;
/* 23 */   private int queryNum = 0;
/*    */   private Card card;
/*    */   private BlockingQueue<List<UserBase>> queue;
/*    */ 
/*    */   public TaskData(int maxBatchNumber, int maxThreedNumber, BlockingQueue<List<UserBase>> queue, Card card, String personId)
/*    */   {
/* 30 */     this.maxBatchNumber = maxBatchNumber;
/* 31 */     this.maxThreedNumber = maxThreedNumber;
/* 32 */     this.queue = queue;
/* 33 */     this.dao = new DBDao();
/* 34 */     this.dao.setPersonId(personId);
/* 35 */     this.card = card;
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/* 40 */     log.debug(this.card.getName() + "(" + this.card.getId() + ")  查询线程开始执行");
/* 41 */     int page = 0;
/* 42 */     List userList = null;
/*    */     while (true) {
/*    */       try {
/* 45 */         userList = this.dao.getUserBase(this.card.getId(), ++page, this.maxBatchNumber);
/*    */       } catch (Exception e) {
/* 47 */         log.error(this.card.getName() + "(" + this.card.getId() + ")  查询异常, 当前批次" + (page - 1) + 
/* 48 */           " " + e.getMessage());
/* 49 */         e.printStackTrace();
/* 50 */         break label251;
/*    */       }
/* 52 */       if (userList.size() == 0) {
/* 53 */         log.debug(this.card.getName() + "(" + this.card.getId() + ")  查询线程查询完成, 共" + this.queryNum + "条");
/*    */       }
/*    */       else {
/* 56 */         this.queryNum += userList.size();
/*    */         try {
/* 58 */           this.queue.put(userList);
/*    */         } catch (Exception e) {
/* 60 */           e.printStackTrace();
/*    */         }
/*    */       }
/*    */     }
/* 64 */     label251: for (int i = 0; i < this.maxThreedNumber; i++) {
/*    */       try {
/* 66 */         this.queue.put(Collections.EMPTY_LIST);
/*    */       } catch (InterruptedException e) {
/* 68 */         e.printStackTrace();
/*    */       }
/*    */     }
/* 71 */     this.dao.close();
/*    */ 
/* 73 */     log.debug(this.card.getName() + "(" + this.card.getId() + ")  查询线程结束执行.");
/*    */   }
/*    */ 
/*    */   public int getQueryNum() {
/* 77 */     return this.queryNum;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.special.TaskData
 * JD-Core Version:    0.6.2
 */