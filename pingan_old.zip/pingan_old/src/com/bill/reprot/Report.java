/*    */ package com.bill.reprot;
/*    */ 
/*    */ import com.bill.bean.BaseParam;
/*    */ import com.bill.db.DbConnectionForOracle;
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.Connection;
/*    */ 
/*    */ public class Report
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/*    */     try
/*    */     {
/* 23 */       DbConnectionForOracle dbconn = new DbConnectionForOracle(BaseParam.DB_IP, BaseParam.DB_PORT, BaseParam.DB_NAME, BaseParam.DB_USER, BaseParam.DB_PWD);
/* 24 */       Connection conn = dbconn.getConnection();
/*    */ 
/* 26 */       CallableStatement statement = conn.prepareCall("{call pro_update_code_name}");
/* 27 */       statement.execute();
/* 28 */       statement = conn.prepareCall("{call pro_update_bill_number}");
/* 29 */       statement.execute();
/* 30 */       statement = conn.prepareCall("{call pro_stat_area_bill}");
/* 31 */       statement.execute();
/* 32 */       statement = conn.prepareCall("{call pro_stat_month_cost}");
/* 33 */       statement.execute();
/* 34 */       statement = conn.prepareCall("{call pro_update_month_sum}");
/* 35 */       statement.execute();
/*    */ 
/* 37 */       conn.close();
/*    */     } catch (Exception e) {
/* 39 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.reprot.Report
 * JD-Core Version:    0.6.2
 */