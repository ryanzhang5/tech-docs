/*      */ package com.bill.makeXML.dao;
/*      */ 
/*      */ import com.bill.bean.BaseParam;
/*      */ import com.bill.bean.Busin;
/*      */ import com.bill.bean.Card;
/*      */ import com.bill.bean.Debitinfo;
/*      */ import com.bill.bean.Fodder;
/*      */ import com.bill.bean.Foldout;
/*      */ import com.bill.bean.Plog;
/*      */ import com.bill.bean.PointInfo;
/*      */ import com.bill.bean.Rule;
/*      */ import com.bill.bean.RuleF;
/*      */ import com.bill.bean.RuleM;
/*      */ import com.bill.bean.TempArea;
/*      */ import com.bill.bean.Template;
/*      */ import com.bill.bean.UserAccinfo;
/*      */ import com.bill.bean.UserAccinfoDetail;
/*      */ import com.bill.bean.UserBase;
/*      */ import com.bill.bean.UserBuy;
/*      */ import com.bill.bean.Yyz;
/*      */ import com.bill.db.DbConnectionForOracle;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.apache.log4j.Logger;
/*      */ 
/*      */ public class DBDao
/*      */ {
/*      */   private DbConnectionForOracle dbconn;
/*      */   private PreparedStatement statement;
/*      */   private ResultSet result;
/*      */   public static Logger log;
/*   23 */   private static String CARD_SQL = "select t.s_buss_prod_id,t.s_buss_prod_name,t.c_buss_type_id from T_S_BUSI_PROD_INFO t where t.c_buss_prod_flag='0' and t.C_BUSS_STATE='1' and t.c_buss_type_id='001'";
/*      */ 
/*   27 */   private static String BFPNT_SQL = "select t.s_id from t_s_befor_print_basic  t where  to_date(?,'yyyyMM')>= to_date(t.c_period_begen,'yyyy-MM') and to_date(?,'yyyyMM')<= to_date(t.c_period_end,'yyyy-MM') and t.c_period_day=?";
/*      */ 
/*   32 */   private static String CPB_CITY_SQL = "select t.s_city_no from t_s_bfpnt_cty_crdtp t where t.s_city_no is not null and t.s_card_no =? and t.s_id=? and t.s_businpnt_no=?";
/*      */ 
/*   37 */   private static String USER_BASE1 = "select * from (select tt.*, rownum RN from (select t.*, rownum from t_b_customer_bill t where C_CUR_PAPER_STMT_FLAG='Y' AND S_CARD_PROD_ID = ? and S_CITY_ID=? and rownum < ?) tt ) where RN >= ?";
/*      */ 
/*   39 */   private static String USER_BASE2 = "select * from (select tt.*, rownum RN from (select t.*, rownum from t_b_customer_bill t where S_CARD_PROD_ID = ? and rownum < ?) tt ) where RN >= ?";
/*      */ 
/*   44 */   private static String TEMPLATE_SQL = "select t.s_stencil_no,t.s_card_prod_id,t.c_type_no from T_S_STENCIL t where t.c_state='1'";
/*      */ 
/*   49 */   private static String RULE_SQL = "select * from t_s_rule_m t where t.s_stencil_no=? and t.c_rule_type=? and t.i_area_no=? and t.c_state='1' and to_date(?,'yyyyMM')>=to_date(t.c_period_begen,'yyyy-MM') and to_date(?,'yyyyMM')<=to_date(t.c_period_end,'yyyy-MM') and t.s_period like '%'||?||'%' order by t.i_pri desc";
/*      */ 
/*      */   public DBDao()
/*      */   {
/*   55 */     this.dbconn = new DbConnectionForOracle(BaseParam.getDBIP(), 
/*   56 */       BaseParam.getDBPort(), BaseParam.getDBName(), BaseParam.getDBUser(), 
/*   57 */       BaseParam.getDBPwd());
/*   58 */     log = Logger.getLogger(DBDao.class);
/*      */   }
/*      */ 
/*      */   public DBDao(DbConnectionForOracle db) {
/*   62 */     this.dbconn = db;
/*   63 */     log = Logger.getLogger(DBDao.class);
/*      */   }
/*      */ 
/*      */   public void close()
/*      */   {
/*   71 */     this.dbconn.close();
/*      */   }
/*      */ 
/*      */   public List<Busin> getBusin()
/*      */   {
/*   80 */     List list = new ArrayList();
/*      */     try {
/*   82 */       this.statement = this.dbconn
/*   83 */         .getConnection()
/*   84 */         .prepareStatement(
/*   85 */         "select t1.s_businpnt_no,t1.s_businpnt_name from T_S_EPLBOLY_PNT t1");
/*   86 */       this.result = this.statement.executeQuery();
/*      */ 
/*   88 */       while (this.result.next()) {
/*   89 */         Busin e = new Busin();
/*   90 */         e.setId(this.result.getString("s_businpnt_no"));
/*   91 */         e.setName(this.result.getString("s_businpnt_name"));
/*   92 */         list.add(e);
/*      */       }
/*   94 */       this.result.close();
/*   95 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*   97 */       e.printStackTrace();
/*      */     }
/*   99 */     return list;
/*      */   }
/*      */ 
/*      */   public List<Card> getCard()
/*      */   {
/*  108 */     List list = new ArrayList();
/*      */     try {
/*  110 */       this.statement = this.dbconn.getConnection().prepareStatement(CARD_SQL);
/*  111 */       this.result = this.statement.executeQuery();
/*      */ 
/*  113 */       while (this.result.next()) {
/*  114 */         Card e = new Card();
/*  115 */         e.setId(this.result.getString("s_buss_prod_id"));
/*  116 */         e.setName(this.result.getString("s_buss_prod_name"));
/*  117 */         e.setType(this.result.getString("c_buss_type_id"));
/*  118 */         list.add(e);
/*      */       }
/*  120 */       this.result.close();
/*  121 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  123 */       e.printStackTrace();
/*      */     }
/*  125 */     return list;
/*      */   }
/*      */ 
/*      */   public Map<String, String> getBfpntMap()
/*      */   {
/*  134 */     Map map = new HashMap();
/*      */ 
/*  136 */     String ym = BaseParam.PERIOD.substring(0, 6);
/*      */ 
/*  138 */     String d = BaseParam.PERIOD.substring(6);
/*      */     try {
/*  140 */       this.statement = this.dbconn.getConnection().prepareStatement(BFPNT_SQL);
/*  141 */       this.statement.setString(1, ym);
/*  142 */       this.statement.setString(2, ym);
/*  143 */       this.statement.setString(3, d);
/*  144 */       this.result = this.statement.executeQuery();
/*      */ 
/*  146 */       String id = "";
/*  147 */       while (this.result.next()) {
/*  148 */         id = this.result.getString(1);
/*  149 */         map.put(id, id);
/*      */       }
/*  151 */       this.result.close();
/*  152 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  154 */       e.printStackTrace();
/*  155 */       return null;
/*      */     }
/*  157 */     return map;
/*      */   }
/*      */ 
/*      */   public Map<String, List<Yyz>> getCardBfpntMap()
/*      */   {
/*  166 */     Map map = new HashMap();
/*  167 */     StringBuffer sb = new StringBuffer();
/*  168 */     sb.append("select ");
/*  169 */     sb.append("t.s_card_no,t.s_id,t2.S_PAPER_NO");
/*  170 */     sb.append(" from t_s_bfpnt_cty_crdtp t,T_S_BEFOR_PRINT_BASIC t2");
/*  171 */     sb.append(" where ");
/*  172 */     sb.append("t.s_id=t2.s_id and t2.c_period_day=? and t2.c_period_begen<=? and t2.c_period_end>=?");
/*  173 */     sb.append(" group by t.s_card_no,t.s_id,t2.S_PAPER_NO");
/*      */     try {
/*  175 */       this.statement = this.dbconn
/*  176 */         .getConnection()
/*  177 */         .prepareStatement(sb.toString());
/*  178 */       this.statement.setString(1, BaseParam.PERIOD_D);
/*  179 */       this.statement.setString(2, BaseParam.PERIOD_Y + "-" + BaseParam.PERIOD_M);
/*  180 */       this.statement.setString(3, BaseParam.PERIOD_Y + "-" + BaseParam.PERIOD_M);
/*  181 */       this.result = this.statement.executeQuery();
/*      */ 
/*  183 */       String id1 = "";
/*      */ 
/*  185 */       while (this.result.next()) {
/*  186 */         Yyz y = new Yyz();
/*  187 */         id1 = this.result.getString("s_card_no");
/*  188 */         y.setId(this.result.getString("s_id"));
/*  189 */         y.setPaperNo(this.result.getString("S_PAPER_NO"));
/*  190 */         if (map.containsKey(id1)) {
/*  191 */           ((List)map.get(id1)).add(y);
/*      */         } else {
/*  193 */           List list = new ArrayList();
/*  194 */           list.add(y);
/*  195 */           map.put(id1, list);
/*      */         }
/*      */       }
/*  198 */       this.result.close();
/*  199 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  201 */       e.printStackTrace();
/*  202 */       return null;
/*      */     }
/*  204 */     return map;
/*      */   }
/*      */ 
/*      */   public List<String> getCityByCPB(String cid, String pid, String bid)
/*      */   {
/*  219 */     List list = new ArrayList();
/*      */     try {
/*  221 */       this.statement = this.dbconn.getConnection().prepareStatement(CPB_CITY_SQL);
/*  222 */       this.statement.setString(1, cid);
/*  223 */       this.statement.setString(2, pid);
/*  224 */       this.statement.setString(3, bid);
/*  225 */       this.result = this.statement.executeQuery();
/*  226 */       while (this.result.next()) {
/*  227 */         list.add(this.result.getString("S_CITY_NO"));
/*      */       }
/*  229 */       this.result.close();
/*  230 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  232 */       e.printStackTrace();
/*      */     }
/*  234 */     return list;
/*      */   }
/*      */ 
/*      */   public List<UserBase> getUserBase(String cardid, String city, int page, int size)
/*      */   {
/*  253 */     List list = new ArrayList();
/*      */     try {
/*  255 */       this.statement = this.dbconn.getConnection().prepareStatement(USER_BASE1);
/*  256 */       this.statement.setString(1, cardid);
/*  257 */       this.statement.setString(2, city);
/*  258 */       this.statement.setInt(3, page * size);
/*  259 */       this.statement.setInt(4, (page - 1) * size);
/*  260 */       this.result = this.statement.executeQuery();
/*      */ 
/*  262 */       while (this.result.next()) {
/*  263 */         UserBase ub = new UserBase();
/*  264 */         ub.setAcctnbr(this.result.getString("S_ACCOUNT"));
/*  265 */         ub.setRectype(this.result.getString("S_CUR_TYPE"));
/*  266 */         ub.setZip(this.result.getString("S_CUR_ZIP"));
/*  267 */         ub.setAddrname3(this.result.getString("S_CUR_ADDR3"));
/*  268 */         ub.setAddrname1(this.result.getString("S_CUR_ADDR1"));
/*  269 */         ub.setAddrname2(this.result.getString("S_CUR_ADDR2"));
/*  270 */         ub.setName(this.result.getString("S_CUR_NAME"));
/*  271 */         ub.setSex(this.result.getString("C_CUR_SEX"));
/*  272 */         ub.setBirthday(this.result.getString("S_CUR_BIRTHDAY"));
/*  273 */         ub.setAccnum(this.result.getString("S_CUR_ACCOUNT"));
/*  274 */         ub.setCusnum(this.result.getString("S_CUR_CUST_NBR"));
/*  275 */         ub.setStfromdate(this.result.getString("S_CUR_START_DATE"));
/*  276 */         ub.setEnddate(this.result.getString("S_CUR_END_DATE"));
/*  277 */         ub.setSpecode(this.result.getString("S_CUR_SPECIAL_CHAR"));
/*  278 */         ub.setPmtduemark(this.result.getString("S_CUR_PMT_CYCLE_DUE"));
/*  279 */         ub.setCashmark(this.result.getString("S_CUR_PRINT"));
/*  280 */         ub.setIndiv1(this.result.getString("C_CUR_MSG_1"));
/*  281 */         ub.setIndiv2(this.result.getString("C_CUR_MSG_2"));
/*  282 */         ub.setIndiv3(this.result.getString("C_CUR_MSG_3"));
/*  283 */         ub.setIndiv4(this.result.getString("C_CUR_MSG_4"));
/*  284 */         ub.setIndiv5(this.result.getString("C_CUR_MSG_5"));
/*  285 */         ub.setIndiv6(this.result.getString("C_CUR_MSG_6"));
/*  286 */         ub.setIndiv7(this.result.getString("C_CUR_MSG_7"));
/*  287 */         ub.setIndiv8(this.result.getString("C_CUR_MSG_8"));
/*  288 */         ub.setActinfo(this.result.getString("C_CUR_ACTIVITY_MSG"));
/*  289 */         ub.setDm1(this.result.getString("C_CUR_DM_MSG_1"));
/*  290 */         ub.setDm2(this.result.getString("C_CUR_DM_MSG_2"));
/*  291 */         ub.setDm3(this.result.getString("C_CUR_DM_MSG_3"));
/*  292 */         ub.setDm4(this.result.getString("C_CUR_DM_MSG_4"));
/*  293 */         ub.setBrandmsg1(this.result.getString("C_CUR_BRAND_MSG_1"));
/*  294 */         ub.setBrandmsg2(this.result.getString("C_CUR_BRAND_MSG_2"));
/*  295 */         ub.setBrandmsg3(this.result.getString("C_CUR_BRAND_MSG_3"));
/*  296 */         ub.setBrandmsg4(this.result.getString("C_CUR_BRAND_MSG_4"));
/*  297 */         ub.setBrandmsg5(this.result.getString("C_CUR_BRAND_MSG_5"));
/*  298 */         ub.setBrandmsg6(this.result.getString("C_CUR_BRAND_MSG_6"));
/*  299 */         ub.setBrandmsg7(this.result.getString("C_CUR_BRAND_MSG_7"));
/*  300 */         ub.setConvexchmark(this.result.getString("C_CUR_CONV_EXCH_FLAG"));
/*  301 */         ub.setVipmsg1(this.result.getString("C_CUR_VIP_MSG_1"));
/*  302 */         ub.setVipmsg2(this.result.getString("C_CUR_VIP_MSG_2"));
/*  303 */         ub.setVipmsg3(this.result.getString("C_CUR_VIP_MSG_3"));
/*  304 */         ub.setVipmsg4(this.result.getString("C_CUR_VIP_MSG_4"));
/*  305 */         ub.setReprintflag(this.result.getString("C_CUR_REPRINT_FLAG"));
/*  306 */         ub.setEmailflag(this.result.getString("C_CUR_EMAIL_STMT_FLAG"));
/*  307 */         ub.setPaperflag(this.result.getString("C_CUR_PAPER_STMT_FLAG"));
/*  308 */         ub.setEmailaddr(this.result.getString("S_CUR_EMAIL_ADDR"));
/*  309 */         ub.setCusttype(this.result.getString("S_CUR_CUSTOMER_TYPE"));
/*  310 */         ub.setMobilenbr(this.result.getString("S_CUR_MOBILE_NBR"));
/*  311 */         ub.setAinbr(this.result.getString("S_CUR_AI_NBR"));
/*  312 */         ub.setMobdate(this.result.getString("C_CUR_MOB"));
/*  313 */         ub.setFiller(this.result.getString("S_CUR_FILLER"));
/*  314 */         ub.setCity(this.result.getString("S_CITY_ID"));
/*  315 */         ub.setCrlim(this.result.getString("I_CUR_CRLIM"));
/*  316 */         ub.setCurrbal(this.result.getString("I_CUR_BAL"));
/*  317 */         ub.setTotdueamt(this.result.getString("I_CUR_TOT_DUE_AMT"));
/*  318 */         ub.setCashcrlim(this.result.getString("I_CUR_CASH_CRLIM"));
/*  319 */         ub.setStmtdate(this.result.getString("C_STMT_DATE"));
/*  320 */         ub.setCardNo(this.result.getString("S_CARD_PROD_ID"));
/*  321 */         list.add(ub);
/*      */       }
/*  323 */       this.result.close();
/*  324 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  326 */       e.printStackTrace();
/*      */     }
/*  328 */     return list;
/*      */   }
/*      */ 
/*      */   public List<UserBase> getUserBase(String cardid, int page, int size) {
/*  332 */     List list = new ArrayList();
/*      */     try {
/*  334 */       this.statement = this.dbconn.getConnection().prepareStatement(USER_BASE2);
/*  335 */       this.statement.setString(1, cardid);
/*      */ 
/*  337 */       this.statement.setInt(2, page * size);
/*      */ 
/*  339 */       this.statement.setInt(3, (page - 1) * size);
/*  340 */       this.result = this.statement.executeQuery();
/*      */ 
/*  342 */       while (this.result.next()) {
/*  343 */         UserBase ub = new UserBase();
/*  344 */         ub.setAcctnbr(this.result.getString("S_ACCOUNT"));
/*  345 */         ub.setRectype(this.result.getString("S_CUR_TYPE"));
/*  346 */         ub.setZip(this.result.getString("S_CUR_ZIP"));
/*  347 */         ub.setAddrname3(this.result.getString("S_CUR_ADDR3"));
/*  348 */         ub.setAddrname1(this.result.getString("S_CUR_ADDR1"));
/*  349 */         ub.setAddrname2(this.result.getString("S_CUR_ADDR2"));
/*  350 */         ub.setName(this.result.getString("S_CUR_NAME"));
/*  351 */         ub.setSex(this.result.getString("C_CUR_SEX"));
/*  352 */         ub.setBirthday(this.result.getString("S_CUR_BIRTHDAY"));
/*  353 */         ub.setAccnum(this.result.getString("S_CUR_ACCOUNT"));
/*  354 */         ub.setCusnum(this.result.getString("S_CUR_CUST_NBR"));
/*  355 */         ub.setStfromdate(this.result.getString("S_CUR_START_DATE"));
/*  356 */         ub.setEnddate(this.result.getString("S_CUR_END_DATE"));
/*  357 */         ub.setSpecode(this.result.getString("S_CUR_SPECIAL_CHAR"));
/*  358 */         ub.setPmtduemark(this.result.getString("S_CUR_PMT_CYCLE_DUE"));
/*  359 */         ub.setCashmark(this.result.getString("S_CUR_PRINT"));
/*  360 */         ub.setIndiv1(this.result.getString("C_CUR_MSG_1"));
/*  361 */         ub.setIndiv2(this.result.getString("C_CUR_MSG_2"));
/*  362 */         ub.setIndiv3(this.result.getString("C_CUR_MSG_3"));
/*  363 */         ub.setIndiv4(this.result.getString("C_CUR_MSG_4"));
/*  364 */         ub.setIndiv5(this.result.getString("C_CUR_MSG_5"));
/*  365 */         ub.setIndiv6(this.result.getString("C_CUR_MSG_6"));
/*  366 */         ub.setIndiv7(this.result.getString("C_CUR_MSG_7"));
/*  367 */         ub.setIndiv8(this.result.getString("C_CUR_MSG_8"));
/*  368 */         ub.setActinfo(this.result.getString("C_CUR_ACTIVITY_MSG"));
/*  369 */         ub.setDm1(this.result.getString("C_CUR_DM_MSG_1"));
/*  370 */         ub.setDm2(this.result.getString("C_CUR_DM_MSG_2"));
/*  371 */         ub.setDm3(this.result.getString("C_CUR_DM_MSG_3"));
/*  372 */         ub.setDm4(this.result.getString("C_CUR_DM_MSG_4"));
/*  373 */         ub.setBrandmsg1(this.result.getString("C_CUR_BRAND_MSG_1"));
/*  374 */         ub.setBrandmsg2(this.result.getString("C_CUR_BRAND_MSG_2"));
/*  375 */         ub.setBrandmsg3(this.result.getString("C_CUR_BRAND_MSG_3"));
/*  376 */         ub.setBrandmsg4(this.result.getString("C_CUR_BRAND_MSG_4"));
/*  377 */         ub.setBrandmsg5(this.result.getString("C_CUR_BRAND_MSG_5"));
/*  378 */         ub.setBrandmsg6(this.result.getString("C_CUR_BRAND_MSG_6"));
/*  379 */         ub.setBrandmsg7(this.result.getString("C_CUR_BRAND_MSG_7"));
/*  380 */         ub.setConvexchmark(this.result.getString("C_CUR_CONV_EXCH_FLAG"));
/*  381 */         ub.setVipmsg1(this.result.getString("C_CUR_VIP_MSG_1"));
/*  382 */         ub.setVipmsg2(this.result.getString("C_CUR_VIP_MSG_2"));
/*  383 */         ub.setVipmsg3(this.result.getString("C_CUR_VIP_MSG_3"));
/*  384 */         ub.setVipmsg4(this.result.getString("C_CUR_VIP_MSG_4"));
/*  385 */         ub.setReprintflag(this.result.getString("C_CUR_REPRINT_FLAG"));
/*  386 */         ub.setEmailflag(this.result.getString("C_CUR_EMAIL_STMT_FLAG"));
/*  387 */         ub.setPaperflag(this.result.getString("C_CUR_PAPER_STMT_FLAG"));
/*  388 */         ub.setEmailaddr(this.result.getString("S_CUR_EMAIL_ADDR"));
/*  389 */         ub.setCusttype(this.result.getString("S_CUR_CUSTOMER_TYPE"));
/*  390 */         ub.setMobilenbr(this.result.getString("S_CUR_MOBILE_NBR"));
/*  391 */         ub.setAinbr(this.result.getString("S_CUR_AI_NBR"));
/*  392 */         ub.setMobdate(this.result.getString("C_CUR_MOB"));
/*  393 */         ub.setFiller(this.result.getString("S_CUR_FILLER"));
/*  394 */         ub.setCity(this.result.getString("S_CITY_ID"));
/*  395 */         ub.setCrlim(this.result.getString("I_CUR_CRLIM"));
/*  396 */         ub.setCurrbal(this.result.getString("I_CUR_BAL"));
/*  397 */         ub.setTotdueamt(this.result.getString("I_CUR_TOT_DUE_AMT"));
/*  398 */         ub.setCashcrlim(this.result.getString("I_CUR_CASH_CRLIM"));
/*  399 */         ub.setStmtdate(this.result.getString("C_STMT_DATE"));
/*  400 */         ub.setCardNo(this.result.getString("S_CARD_PROD_ID"));
/*  401 */         list.add(ub);
/*      */       }
/*  403 */       this.result.close();
/*  404 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  406 */       e.printStackTrace();
/*      */     }
/*  408 */     return list;
/*      */   }
/*      */ 
/*      */   public List<UserAccinfo> getUserInfo(UserBase base)
/*      */   {
/*  419 */     List list = new ArrayList();
/*  420 */     StringBuffer sql = new StringBuffer();
/*  421 */     sql.append("select ");
/*  422 */     sql.append("acctnbr,rectype,stmtdate,pmtdate,to_char(totbegbal,'fm9999999999999999990.00') as totbegbal");
/*  423 */     sql.append(",to_char(plantotpmt,'fm9999999999999999990.00') as plantotpmt");
/*  424 */     sql.append(",to_char(plantotnrlamt,'fm9999999999999999990.00') as plantotnrlamt,to_char(plantotadjamt,'fm9999999999999999990.00') as plantotadjamt");
/*  425 */     sql.append(",to_char(intdueamt,'fm9999999999999999990.00') as intdueamt,to_char(currbal,'fm9999999999999999990.00') as currbal");
/*  426 */     sql.append(",to_char(totdueamt,'fm9999999999999999990.00') as totdueamt,pmtprint,to_char(crlim,'fm9999999999999999990.00') as crlim,to_char(cashcrlim,'fm9999999999999999990.00') as cashcrlim");
/*  427 */     sql.append(",pmtarn,pmtadn,to_char(projap,'fm9999999999999999990.00') as projap,pmtaflag,achflag,pmtflag,filler");
/*  428 */     sql.append(" from view_b_customer_bill t where t.acctnbr=? and t.stmtdate=?");
/*      */     try {
/*  430 */       this.statement = this.dbconn
/*  431 */         .getConnection()
/*  432 */         .prepareStatement(sql.toString());
/*  433 */       this.statement.setString(1, base.getAcctnbr());
/*  434 */       this.statement.setString(2, base.getStmtdate());
/*  435 */       this.result = this.statement.executeQuery();
/*      */ 
/*  437 */       while (this.result.next()) {
/*  438 */         UserAccinfo ub = new UserAccinfo();
/*  439 */         ub.setAcctnbr(this.result.getString("acctnbr"));
/*  440 */         ub.setRectype(this.result.getString("rectype"));
/*  441 */         ub.setStmtdate(this.result.getString("stmtdate"));
/*  442 */         ub.setPmtdate(this.result.getString("pmtdate"));
/*  443 */         ub.setTotbegbal(this.result.getString("totbegbal"));
/*  444 */         ub.setPlantotpmt(this.result.getString("plantotpmt"));
/*  445 */         ub.setPlantotnrlamt(this.result.getString("plantotnrlamt"));
/*  446 */         ub.setPlantotadjamt(this.result.getString("plantotadjamt"));
/*  447 */         ub.setIntdueamt(this.result.getString("intdueamt"));
/*  448 */         ub.setCurrbal(this.result.getString("currbal"));
/*  449 */         ub.setTotdueamt(this.result.getString("totdueamt"));
/*  450 */         ub.setPmtprint(this.result.getString("pmtprint"));
/*  451 */         ub.setCrlim(this.result.getString("crlim"));
/*  452 */         ub.setCashcrlim(this.result.getString("cashcrlim"));
/*  453 */         ub.setPmtarn(this.result.getString("pmtarn"));
/*  454 */         ub.setPmtadn(this.result.getString("pmtadn"));
/*  455 */         ub.setProjap(this.result.getString("projap"));
/*  456 */         ub.setPmtaflag(this.result.getString("pmtaflag"));
/*  457 */         ub.setAchflag(this.result.getString("achflag"));
/*  458 */         ub.setPmtflag(this.result.getString("pmtflag"));
/*  459 */         ub.setFiller(this.result.getString("filler"));
/*  460 */         list.add(ub);
/*      */       }
/*  462 */       this.result.close();
/*  463 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  465 */       e.printStackTrace();
/*      */     }
/*  467 */     return list;
/*      */   }
/*      */ 
/*      */   public List<UserAccinfoDetail> getAccinfoDetail(UserBase user)
/*      */   {
/*  477 */     List list = new ArrayList();
/*  478 */     StringBuffer sb = new StringBuffer();
/*  479 */     sb.append("select ");
/*  480 */     sb.append("acctnbr,rectype,recseq,effdate,postdate,cardnlast4,curdesc,to_char(txnamt,'fm9999999999999999990.00') as txnamt,to_char(srctamt,'fm9999999999999999990.00') as srctamt,srctcurr,purcty,filler");
/*  481 */     sb.append(" from view_b_customer_bill_detail t where t.acctnbr=?");
/*      */     try {
/*  483 */       this.statement = this.dbconn
/*  484 */         .getConnection()
/*  485 */         .prepareStatement(sb.toString());
/*  486 */       this.statement.setString(1, user.getAcctnbr());
/*  487 */       this.result = this.statement.executeQuery();
/*      */ 
/*  489 */       while (this.result.next()) {
/*  490 */         UserAccinfoDetail ub = new UserAccinfoDetail();
/*  491 */         ub.setAcctnbr(this.result.getString("acctnbr"));
/*  492 */         ub.setRectype(this.result.getString("rectype"));
/*  493 */         ub.setRecseq(this.result.getString("recseq"));
/*  494 */         ub.setEffdate(this.result.getString("effdate"));
/*  495 */         ub.setPostdate(this.result.getString("postdate"));
/*  496 */         ub.setCardnlast4(this.result.getString("cardnlast4"));
/*  497 */         ub.setDesc(this.result.getString("curdesc"));
/*  498 */         ub.setTxnamt(this.result.getString("txnamt"));
/*  499 */         ub.setSrctamt(this.result.getString("srctamt"));
/*  500 */         ub.setSrctcurr(this.result.getString("srctcurr"));
/*  501 */         ub.setPurcty(this.result.getString("purcty"));
/*  502 */         ub.setFiller(this.result.getString("filler"));
/*  503 */         list.add(ub);
/*      */       }
/*  505 */       this.result.close();
/*  506 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  508 */       e.printStackTrace();
/*      */     }
/*  510 */     return list;
/*      */   }
/*      */ 
/*      */   public UserBuy getUserBuy(UserBase user) {
/*  514 */     UserBuy ub = null;
/*      */     try {
/*  516 */       this.statement = this.dbconn
/*  517 */         .getConnection()
/*  518 */         .prepareStatement(
/*  519 */         "select * from T_B_CUSTOMER_PURCHASE t where t.S_ACCOUNT=?");
/*  520 */       this.statement.setString(1, user.getAcctnbr());
/*  521 */       this.result = this.statement.executeQuery();
/*  522 */       while (this.result.next()) {
/*  523 */         ub = new UserBuy();
/*  524 */         ub.setAcctnbr(this.result.getString("S_ACCOUNT"));
/*  525 */         ub.setRectype(this.result.getString("S_CUR_PUR_REC_TYPE"));
/*  526 */         ub.setExchusdamt(this.result.getString("I_CUR_PUR_EXCH_USD_AMT"));
/*  527 */         ub.setSellrate(this.result.getString("I_CUR_PUR_SELL_RATE"));
/*  528 */         ub.setExchrmbamt(this.result.getString("I_CUR_PUR_EXCH_RMB_AMT"));
/*  529 */         ub.setAchrtnbr(this.result.getString("S_CUR_PUR_PMT_ACH_RT_NBR"));
/*  530 */         ub.setAchdbnbr(this.result.getString("S_CUR_PUR_PMT_ACH_DB_NBR"));
/*  531 */         ub.setFiller(this.result.getString("S_CUR_PUR_FILLER"));
/*      */       }
/*  533 */       this.result.close();
/*  534 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  536 */       e.printStackTrace();
/*  537 */       return null;
/*      */     }
/*  539 */     return ub;
/*      */   }
/*      */ 
/*      */   public List<Debitinfo> getDebitinfo(UserBase user)
/*      */   {
/*  549 */     List list = new ArrayList();
/*  550 */     Debitinfo deb = null;
/*  551 */     StringBuffer sb = new StringBuffer();
/*  552 */     sb.append("select ");
/*  553 */     sb.append("acctnbr,rectype,custnbr,effdate,txndesc,txncity,currcode,NVL(to_char(txnamt,'fm9999999999999999999990.00'),' ') as txnamt");
/*  554 */     sb.append(",cardl4,filler");
/*  555 */     sb.append(" from view_b_crad_trade_detail t where t.acctnbr=?");
/*      */     try {
/*  557 */       this.statement = this.dbconn
/*  558 */         .getConnection()
/*  559 */         .prepareStatement(sb.toString());
/*  560 */       this.statement.setString(1, user.getAcctnbr());
/*  561 */       this.result = this.statement.executeQuery();
/*  562 */       while (this.result.next()) {
/*  563 */         deb = new Debitinfo();
/*  564 */         deb.setAcctnbr(this.result.getString("acctnbr"));
/*  565 */         deb.setRectype(this.result.getString("rectype"));
/*  566 */         deb.setCustnbr(this.result.getString("custnbr"));
/*  567 */         deb.setEffdate(this.result.getString("effdate"));
/*  568 */         deb.setTxndesc(this.result.getString("txndesc"));
/*  569 */         deb.setTxncity(this.result.getString("txncity"));
/*  570 */         deb.setCurrcode(this.result.getString("currcode"));
/*  571 */         deb.setTxnamt(this.result.getString("txnamt"));
/*  572 */         deb.setCardl4(this.result.getString("cardl4"));
/*  573 */         deb.setFiller(this.result.getString("filler"));
/*  574 */         list.add(deb);
/*      */       }
/*  576 */       this.result.close();
/*  577 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  579 */       e.printStackTrace();
/*  580 */       return null;
/*      */     }
/*  582 */     return list;
/*      */   }
/*      */ 
/*      */   public List<PointInfo> getPoint(UserBase user)
/*      */   {
/*  593 */     List list = new ArrayList();
/*  594 */     PointInfo p = null;
/*  595 */     StringBuffer sb = new StringBuffer();
/*  596 */     sb.append("select ");
/*  597 */     sb.append("S_POINT_TYPE,S_ACCT_PROD_ID,S_BUSINESS_ID,");
/*  598 */     sb.append("to_char(I_ABLE_POINT,'fm99999990.00') as I_ABLE_POINT,to_char(I_LASTBAL_POINT,'fm99999990.00') as I_LASTBAL_POINT,");
/*  599 */     sb.append("to_char(I_ADDPOINT_POINT,'fm99999990.00') as I_ADDPOINT_POINT,to_char(I_EXPOINT_POINT,'fm99999990.00') as I_EXPOINT_POINT,");
/*  600 */     sb.append("to_char(I_ADPOINTS_POINT,'fm99999990.00') as I_ADPOINTS_POINT,to_char(I_ENDPOINTS_POINT,'fm99999990.00') as I_ENDPOINTS_POINT,");
/*  601 */     sb.append("S_ECIF_NO,S_START_DATE,S_END_DATE,");
/*  602 */     sb.append("to_char(I_WHOLE_CONSUME,'fm99999990.00') as I_WHOLE_CONSUME,to_char(I_IN_CONSUME,'fm99999990.00') as I_IN_CONSUME,");
/*  603 */     sb.append("to_char(I_OUT_CONSUME,'fm99999990.00') as I_OUT_CONSUME,to_char(I_WHOLE_MONEY,'fm99999990.00') as I_WHOLE_MONEY,");
/*  604 */     sb.append("to_char(I_IN_MONEY,'fm99999990.00') as I_IN_MONEY,to_char(I_OUT_MONEY,'fm99999990.00') as I_OUT_MONEY,");
/*  605 */     sb.append("to_char(I_USED_MONEY,'fm99999990.00') as I_USED_MONEY,to_char(I_LAVE_MONEY,'fm99999990.00') as I_LAVE_MONEY,S_VALID_DATE,");
/*  606 */     sb.append("to_char(I_LADDER_MONEY,'fm99999990.00') as I_LADDER_MONEY,S_LADDER_SCALE,C_CARD_LAST4,");
/*  607 */     sb.append("C_CARD_POINT_TYPE,S_CARD_POINT_NAME");
/*  608 */     sb.append(" from t_b_point_x where S_BUSINESS_ID=? and C_STMT_DATE=?");
/*      */     try {
/*  610 */       this.statement = this.dbconn
/*  611 */         .getConnection()
/*  612 */         .prepareStatement(sb.toString());
/*  613 */       this.statement.setString(1, user.getAcctnbr());
/*  614 */       this.statement.setString(2, user.getStmtdate());
/*  615 */       this.result = this.statement.executeQuery();
/*  616 */       while (this.result.next()) {
/*  617 */         p = new PointInfo();
/*  618 */         p.setPointtype(this.result.getString("S_POINT_TYPE"));
/*  619 */         p.setCardportid(this.result.getString("S_ACCT_PROD_ID"));
/*  620 */         p.setBusinessid(this.result.getString("S_BUSINESS_ID"));
/*  621 */         p.setAblepoint(this.result.getString("I_ABLE_POINT"));
/*  622 */         p.setLastbalpoint(this.result.getString("I_LASTBAL_POINT"));
/*  623 */         p.setAddpoint(this.result.getString("I_ADDPOINT_POINT"));
/*  624 */         p.setExpoint(this.result.getString("I_EXPOINT_POINT"));
/*  625 */         p.setAdpoints(this.result.getString("I_ADPOINTS_POINT"));
/*  626 */         p.setEndpoints(this.result.getString("I_ENDPOINTS_POINT"));
/*  627 */         p.setEcifno(this.result.getString("S_ECIF_NO"));
/*  628 */         p.setStartdate(this.result.getString("S_START_DATE"));
/*  629 */         p.setEnddate(this.result.getString("S_END_DATE"));
/*  630 */         p.setWholeconsume(this.result.getString("I_WHOLE_CONSUME"));
/*  631 */         p.setInconsume(this.result.getString("I_IN_CONSUME"));
/*  632 */         p.setOutconsume(this.result.getString("I_OUT_CONSUME"));
/*  633 */         p.setWholemoney(this.result.getString("I_WHOLE_MONEY"));
/*  634 */         p.setInmoney(this.result.getString("I_IN_MONEY"));
/*  635 */         p.setOutmoney(this.result.getString("I_OUT_MONEY"));
/*  636 */         p.setUsedmoney(this.result.getString("I_USED_MONEY"));
/*  637 */         p.setLavemoney(this.result.getString("I_LAVE_MONEY"));
/*  638 */         p.setValiddate(this.result.getString("S_VALID_DATE"));
/*  639 */         p.setLaddermoney(this.result.getString("I_LADDER_MONEY"));
/*  640 */         p.setLadderscale(this.result.getString("S_LADDER_SCALE"));
/*  641 */         p.setCard4(this.result.getString("C_CARD_LAST4"));
/*  642 */         p.setCardPointType(this.result.getString("C_CARD_POINT_TYPE"));
/*  643 */         p.setCardname(this.result.getString("S_CARD_POINT_NAME"));
/*  644 */         list.add(p);
/*      */       }
/*  646 */       this.result.close();
/*  647 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  649 */       e.printStackTrace();
/*  650 */       return null;
/*      */     }
/*  652 */     return list;
/*      */   }
/*      */ 
/*      */   public PointInfo getPoint2(UserBase user)
/*      */   {
/*  663 */     PointInfo p = null;
/*      */     try {
/*  665 */       this.statement = this.dbconn
/*  666 */         .getConnection()
/*  667 */         .prepareStatement(
/*  668 */         "select * from T_B_POINT_W where S_ECIF_NO=? and C_STMT_DATE=?");
/*  669 */       this.statement.setString(1, user.getCusnum().substring(7));
/*  670 */       this.statement.setString(2, user.getStmtdate());
/*  671 */       this.result = this.statement.executeQuery();
/*  672 */       while (this.result.next()) {
/*  673 */         p = new PointInfo();
/*  674 */         p.setBilldate(this.result.getString("C_STMT_DATE"));
/*  675 */         p.setBusinessid(this.result.getString("S_ECIF_NO"));
/*  676 */         p.setAblepoint(this.result.getString("I_ENDPOINT"));
/*  677 */         p.setEndpoints(this.result.getString("I_VALIDPOINT_B"));
/*  678 */         p.setLastbalpoint(this.result.getString("I_NEWPOINT"));
/*  679 */         p.setAddpoint(this.result.getString("I_USEDPOINT"));
/*  680 */         p.setExpoint(this.result.getString("I_ADJUSTPOINT"));
/*  681 */         p.setAdpoints(this.result.getString("I_INVAILPOINT"));
/*      */       }
/*  683 */       this.result.close();
/*  684 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  686 */       e.printStackTrace();
/*  687 */       return null;
/*      */     }
/*  689 */     return p;
/*      */   }
/*      */ 
/*      */   public List<Template> getTemplateList()
/*      */   {
/*  698 */     List list = new ArrayList();
/*      */     try {
/*  700 */       this.statement = this.dbconn.getConnection().prepareStatement(TEMPLATE_SQL);
/*  701 */       this.result = this.statement.executeQuery();
/*      */ 
/*  703 */       while (this.result.next()) {
/*  704 */         Template t = new Template();
/*  705 */         t.setId(this.result.getString("S_STENCIL_NO"));
/*  706 */         t.setCardid(this.result.getString("S_CARD_PROD_ID"));
/*  707 */         t.setType(this.result.getString("C_TYPE_NO"));
/*  708 */         list.add(t);
/*      */       }
/*  710 */       this.result.close();
/*  711 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  713 */       e.printStackTrace();
/*      */     }
/*  715 */     return list;
/*      */   }
/*      */ 
/*      */   public List<Rule> getRule(String tid, String type, String area, String billdayYM, String billdayD)
/*      */   {
/*  730 */     List list = new ArrayList();
/*      */     try {
/*  732 */       this.statement = this.dbconn.getConnection().prepareStatement(RULE_SQL);
/*  733 */       this.statement.setString(1, tid);
/*  734 */       this.statement.setString(2, type);
/*  735 */       this.statement.setString(3, area);
/*  736 */       this.statement.setString(4, billdayYM);
/*  737 */       this.statement.setString(5, billdayYM);
/*  738 */       this.statement.setString(6, billdayD);
/*  739 */       this.result = this.statement.executeQuery();
/*      */ 
/*  741 */       while (this.result.next()) {
/*  742 */         Rule r = new Rule();
/*  743 */         r.setRuleid(this.result.getString("S_RULE_NO"));
/*  744 */         r.setTid(this.result.getString("S_STENCIL_NO"));
/*  745 */         r.setRuleType(this.result.getString("C_RULE_TYPE"));
/*  746 */         r.setType(this.result.getString("C_TYPENO"));
/*  747 */         r.setPri(this.result.getString("I_PRI"));
/*  748 */         r.setAreaNo(this.result.getString("I_AREA_NO"));
/*  749 */         list.add(r);
/*      */       }
/*  751 */       this.result.close();
/*  752 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  754 */       e.printStackTrace();
/*      */     }
/*  756 */     return list;
/*      */   }
/*      */ 
/*      */   public List<RuleF> getRuleF(String rid)
/*      */   {
/*  765 */     List list = new ArrayList();
/*      */     try {
/*  767 */       this.statement = this.dbconn
/*  768 */         .getConnection()
/*  769 */         .prepareStatement(
/*  770 */         "select * from t_s_rule_f t where t.s_rule_no=? order by t.i_pri desc");
/*  771 */       this.statement.setString(1, rid);
/*  772 */       this.result = this.statement.executeQuery();
/*      */ 
/*  774 */       while (this.result.next()) {
/*  775 */         RuleF r = new RuleF();
/*  776 */         r.setId(this.result.getString("S_SEQUENCE"));
/*  777 */         r.setRid(this.result.getString("S_RULE_NO"));
/*  778 */         r.setFodder(this.result.getString("S_FODDER_NO"));
/*  779 */         r.setPri(this.result.getString("I_PRI"));
/*  780 */         list.add(r);
/*      */       }
/*  782 */       this.result.close();
/*  783 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  785 */       e.printStackTrace();
/*      */     }
/*  787 */     return list;
/*      */   }
/*      */ 
/*      */   public List<RuleM> getRuleFF(String rid)
/*      */   {
/*  796 */     List list = new ArrayList();
/*      */     try {
/*  798 */       this.statement = this.dbconn
/*  799 */         .getConnection()
/*  800 */         .prepareStatement(
/*  801 */         "select * from t_s_rule_ff t where t.s_sequence=? order by t.s_idx");
/*  802 */       this.statement.setString(1, rid);
/*  803 */       this.result = this.statement.executeQuery();
/*      */ 
/*  805 */       while (this.result.next()) {
/*  806 */         RuleM r = new RuleM();
/*  807 */         r.setFieldid(this.result.getString("S_FIELD"));
/*  808 */         r.setOpr1(this.result.getInt("C_OPR_1"));
/*  809 */         r.setVal1(this.result.getString("S_VALIUE_1"));
/*  810 */         r.setOpr2(this.result.getInt("C_OPR_2"));
/*  811 */         r.setVal2(this.result.getString("S_VALIUE_2"));
/*  812 */         r.setCif(this.result.getInt("C_IF"));
/*  813 */         list.add(r);
/*      */       }
/*  815 */       this.result.close();
/*  816 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  818 */       e.printStackTrace();
/*      */     }
/*  820 */     return list;
/*      */   }
/*      */ 
/*      */   public List<TempArea> getTemplateInfo(String tid)
/*      */   {
/*  827 */     List list = new ArrayList();
/*      */     try {
/*  829 */       this.statement = this.dbconn
/*  830 */         .getConnection()
/*  831 */         .prepareStatement(
/*  832 */         "select t.i_area_no,t.c_type_no from t_s_area t where t.s_stencil_no=?");
/*  833 */       this.statement.setString(1, tid);
/*  834 */       this.result = this.statement.executeQuery();
/*      */ 
/*  836 */       while (this.result.next()) {
/*  837 */         TempArea ta = new TempArea();
/*  838 */         ta.setArea(this.result.getString("i_area_no"));
/*  839 */         ta.setType(this.result.getString("c_type_no"));
/*  840 */         list.add(ta);
/*      */       }
/*  842 */       this.result.close();
/*  843 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  845 */       e.printStackTrace();
/*      */     }
/*  847 */     return list;
/*      */   }
/*      */ 
/*      */   public Fodder getFodder(String fid, String d)
/*      */   {
/*  860 */     Fodder fodder = null;
/*      */     try {
/*  862 */       this.statement = this.dbconn
/*  863 */         .getConnection()
/*  864 */         .prepareStatement(
/*  865 */         "select t.s_fodder_no,t.s_fodder_doc_name,t.s_url from T_S_FODDER  t where t.s_fodder_no=? and t.c_state='1' and to_date(?, 'yyyyMM') between to_date(t.c_period_begen, 'yyyy-MM') and to_date(t.c_period_end, 'yyyy-MM')");
/*  866 */       this.statement.setString(1, fid);
/*  867 */       this.statement.setString(2, d);
/*  868 */       this.result = this.statement.executeQuery();
/*  869 */       while (this.result.next()) {
/*  870 */         fodder = new Fodder();
/*  871 */         fodder.setFid(this.result.getString("s_fodder_no"));
/*  872 */         fodder.setUrl(this.result.getString("s_fodder_doc_name"));
/*  873 */         fodder.setLinkurl(this.result.getString("s_url"));
/*      */       }
/*  875 */       this.result.close();
/*  876 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  878 */       log.error("素材查询失败！1=" + fid + ",2=" + d);
/*  879 */       e.printStackTrace();
/*  880 */       return null;
/*      */     }
/*  882 */     return fodder;
/*      */   }
/*      */ 
/*      */   public List<Foldout> getFoldout(String bid, String cid, String billdate)
/*      */   {
/*  897 */     List list = new ArrayList();
/*  898 */     Foldout foldout = null;
/*      */     try {
/*  900 */       String sql = "select I_FOLDOUT_INDEX,S_FOLDOUT_PROD_NAME,I_FOLDOUT_PRI,C_FOLDOUT_STATE,I_ID from T_S_FOLDOUT_PROD t2 where t2.i_id =(select t.i_id from T_S_FOLDOUT_PROD_SUB t where t.s_foldout_businpnt_no = ? and t.s_foldout_prod_bpid = ? and t.c_period = ? and to_date(?,'yyyyMM') between to_date(t.c_period_begen,'yyyy-MM') and to_date(t.c_period_end,'yyyy-MM')) order by t2.i_foldout_index";
/*      */ 
/*  905 */       this.statement = this.dbconn.getConnection().prepareStatement(sql);
/*  906 */       this.statement.setString(1, bid);
/*  907 */       this.statement.setString(2, cid);
/*  908 */       this.statement.setString(3, billdate.substring(6));
/*  909 */       this.statement.setString(4, billdate.substring(0, 6));
/*  910 */       this.result = this.statement.executeQuery();
/*  911 */       while (this.result.next()) {
/*  912 */         foldout = new Foldout();
/*  913 */         foldout.setId(this.result.getString("I_ID"));
/*  914 */         foldout.setName(this.result.getString("S_FOLDOUT_PROD_NAME"));
/*  915 */         foldout.setPri(this.result.getInt("I_FOLDOUT_PRI"));
/*  916 */         foldout.setState(this.result.getString("C_FOLDOUT_STATE"));
/*  917 */         foldout.setIdx(this.result.getString("I_FOLDOUT_INDEX"));
/*  918 */         list.add(foldout);
/*      */       }
/*  920 */       this.result.close();
/*  921 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  923 */       e.printStackTrace();
/*      */     }
/*      */     finally {
/*  926 */       return list;
/*      */     }
/*      */   }
/*      */ 
/*      */   public Map<String, String> getFoldoutCity(String id, String idx)
/*      */   {
/*  941 */     Map map = new HashMap();
/*  942 */     String city = "";
/*      */     try {
/*  944 */       String sql = "select t.s_foldout_city from t_s_foldout_city t where t.i_id=? and t.i_foldout_index=?";
/*  945 */       this.statement = this.dbconn.getConnection().prepareStatement(sql);
/*  946 */       this.statement.setString(1, id);
/*  947 */       this.statement.setString(2, idx);
/*  948 */       this.result = this.statement.executeQuery();
/*  949 */       while (this.result.next()) {
/*  950 */         city = this.result.getString("s_foldout_city");
/*  951 */         map.put(city, city);
/*      */       }
/*  953 */       this.result.close();
/*  954 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  956 */       e.printStackTrace();
/*      */     }
/*      */     finally {
/*  959 */       return map;
/*      */     }
/*      */   }
/*      */ 
/*      */   public int delLog(String date)
/*      */   {
/*  967 */     int ret = -1;
/*      */     try {
/*  969 */       this.statement = this.dbconn.getConnection().prepareStatement(
/*  970 */         "delete T_B_XML_LOG where s_period=?");
/*  971 */       this.statement.setString(1, date);
/*  972 */       ret = this.statement.executeUpdate();
/*      */     } catch (SQLException e) {
/*  974 */       e.printStackTrace();
/*      */       try
/*      */       {
/*  977 */         if (this.statement != null)
/*  978 */           this.statement.close();
/*      */       }
/*      */       catch (SQLException e) {
/*  981 */         e.printStackTrace();
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/*  977 */         if (this.statement != null)
/*  978 */           this.statement.close();
/*      */       }
/*      */       catch (SQLException e) {
/*  981 */         e.printStackTrace();
/*      */       }
/*      */     }
/*  984 */     return ret;
/*      */   }
/*      */ 
/*      */   public void recordDBLog(Plog plog)
/*      */   {
/*  992 */     PreparedStatement ps = null;
/*      */     int i;
/*      */     try
/*      */     {
/*  996 */       ps = this.dbconn.getConnection().prepareStatement(
/*  997 */         "update T_B_XML_LOG set I_SHARE = ?, C_START_TIME = ?, C_END_TIME = ?, S_CARD_PROD_ID = ?, S_PAPER_NO = ?, C_STATE = ?, I_SHARE_ERROR = ? where S_PERIOD = ? and S_FILENAME = ?");
/*      */ 
/* 1006 */       ps.setInt(1, plog.getShare());
/* 1007 */       ps.setString(2, plog.getStart_time());
/* 1008 */       ps.setString(3, plog.getEnd_time());
/* 1009 */       ps.setString(4, plog.getCard_id());
/* 1010 */       ps.setString(5, plog.getPaper_no());
/* 1011 */       ps.setString(6, plog.getState());
/* 1012 */       ps.setInt(7, plog.getError());
/*      */ 
/* 1014 */       ps.setString(8, plog.getStmtdate());
/* 1015 */       ps.setString(9, plog.getFilename());
/*      */ 
/* 1021 */       i = ps.executeUpdate(); } catch (SQLException e) { int i;
/* 1023 */       log.error("更新生成日志失败, " + plog + ", " + e.getMessage());
/* 1024 */       e.printStackTrace();
/*      */       return; } finally { if (ps != null)
/*      */         try {
/* 1029 */           ps.close();
/*      */         } catch (SQLException e) {
/* 1031 */           log.error("更新生成日志后关闭Statement异常, " + plog + ", " + e.getMessage());
/* 1032 */           e.printStackTrace();
/*      */           return;
/*      */         }
/*      */     }
/*      */     int i;
/* 1038 */     if (i == 0)
/*      */       try {
/* 1040 */         ps = this.dbconn.getConnection().prepareStatement(
/* 1041 */           "insert into T_B_XML_LOG (S_PERIOD, S_FILENAME, S_BUSINPNT_NO, I_SHARE, C_START_TIME, C_END_TIME, S_CARD_PROD_ID, S_PAPER_NO, C_STATE, I_SHARE_ERROR) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
/*      */ 
/* 1054 */         ps.setString(1, plog.getStmtdate());
/* 1055 */         ps.setString(2, plog.getFilename());
/* 1056 */         ps.setString(3, plog.getBusinpnt_no());
/*      */ 
/* 1058 */         ps.setInt(4, plog.getShare());
/* 1059 */         ps.setString(5, plog.getStart_time());
/* 1060 */         ps.setString(6, plog.getEnd_time());
/* 1061 */         ps.setString(7, plog.getCard_id());
/* 1062 */         ps.setString(8, plog.getPaper_no());
/* 1063 */         ps.setString(9, plog.getState());
/* 1064 */         ps.setInt(10, plog.getError());
/*      */ 
/* 1066 */         ps.execute();
/*      */       } catch (SQLException e) {
/* 1068 */         log.error("新增生成日志失败, " + plog + ", " + e.getMessage());
/* 1069 */         e.printStackTrace();
/*      */ 
/* 1071 */         if (ps != null)
/*      */           try {
/* 1073 */             ps.close();
/*      */           } catch (SQLException e) {
/* 1075 */             log.error("新增生成日志后关闭Statement异常, " + plog + ", " + e.getMessage());
/* 1076 */             e.printStackTrace();
/*      */           }
/*      */       }
/*      */       finally
/*      */       {
/* 1071 */         if (ps != null)
/*      */           try {
/* 1073 */             ps.close();
/*      */           } catch (SQLException e) {
/* 1075 */             log.error("新增生成日志后关闭Statement异常, " + plog + ", " + e.getMessage());
/* 1076 */             e.printStackTrace();
/*      */           }
/*      */       }
/*      */   }
/*      */ 
/*      */   public int savePLogBegin(Plog plog)
/*      */   {
/* 1088 */     int ret = -1;
/*      */     try {
/* 1090 */       this.statement = this.dbconn
/* 1091 */         .getConnection()
/* 1092 */         .prepareStatement(
/* 1093 */         "insert into T_B_XML_LOG (S_PERIOD,S_FILENAME,S_BUSINPNT_NO,C_START_TIME,S_CARD_PROD_ID,S_PAPER_NO,C_STATE) values (?,?,?,?,?,?,'2')");
/* 1094 */       this.statement.setString(1, plog.getStmtdate());
/* 1095 */       this.statement.setString(2, plog.getFilename());
/* 1096 */       this.statement.setString(3, plog.getBusinpnt_no());
/* 1097 */       this.statement.setString(4, plog.getStart_time());
/* 1098 */       this.statement.setString(5, plog.getCard_id());
/* 1099 */       this.statement.setString(6, plog.getPaper_no());
/* 1100 */       ret = this.statement.executeUpdate();
/*      */     } catch (SQLException e) {
/* 1102 */       log.trace("增加xml生成日志失败！改为更新日志！");
/* 1103 */       updatePLogBegin(plog);
/*      */       try
/*      */       {
/* 1106 */         if (this.statement != null)
/* 1107 */           this.statement.close();
/*      */       }
/*      */       catch (SQLException e) {
/* 1110 */         e.printStackTrace();
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/* 1106 */         if (this.statement != null)
/* 1107 */           this.statement.close();
/*      */       }
/*      */       catch (SQLException e) {
/* 1110 */         e.printStackTrace();
/*      */       }
/*      */     }
/* 1113 */     return ret;
/*      */   }
/*      */ 
/*      */   public int updatePLogBegin(Plog log) {
/* 1117 */     int ret = -1;
/*      */     try {
/* 1119 */       this.statement = this.dbconn
/* 1120 */         .getConnection()
/* 1121 */         .prepareStatement(
/* 1122 */         "update T_B_XML_LOG set S_BUSINPNT_NO=?,C_START_TIME=?,S_CARD_PROD_ID=?,S_PAPER_NO=?,C_STATE='2' where S_PERIOD=? and S_FILENAME=?");
/*      */ 
/* 1125 */       this.statement.setString(1, log.getBusinpnt_no());
/* 1126 */       this.statement.setString(2, log.getStart_time());
/* 1127 */       this.statement.setString(3, log.getCard_id());
/* 1128 */       this.statement.setString(4, log.getPaper_no());
/* 1129 */       this.statement.setString(5, log.getStmtdate());
/* 1130 */       this.statement.setString(6, log.getFilename());
/* 1131 */       ret = this.statement.executeUpdate();
/* 1132 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1134 */       e.printStackTrace();
/* 1135 */       return -1;
/*      */     }
/* 1137 */     return ret;
/*      */   }
/*      */ 
/*      */   public int savePLogEnd(Plog log)
/*      */   {
/* 1144 */     int ret = -1;
/*      */     try {
/* 1146 */       this.statement = this.dbconn
/* 1147 */         .getConnection()
/* 1148 */         .prepareStatement(
/* 1149 */         "update T_B_XML_LOG set I_SHARE=?,C_END_TIME=?,C_STATE=?,I_SHARE_ERROR=? where S_FILENAME=?");
/* 1150 */       this.statement.setInt(1, log.getShare());
/* 1151 */       this.statement.setString(2, log.getEnd_time());
/* 1152 */       this.statement.setString(3, log.getState());
/* 1153 */       this.statement.setInt(4, log.getError());
/* 1154 */       this.statement.setString(5, log.getFilename());
/* 1155 */       ret = this.statement.executeUpdate();
/* 1156 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1158 */       e.printStackTrace();
/* 1159 */       return ret;
/*      */     }
/* 1161 */     return ret;
/*      */   }
/*      */ 
/*      */   public int avePLogDel(Plog log)
/*      */   {
/* 1171 */     int ret = -1;
/*      */     try {
/* 1173 */       this.statement = this.dbconn.getConnection().prepareStatement(
/* 1174 */         "delete T_B_XML_LOG t where t.s_filename=?");
/* 1175 */       this.statement.setString(1, log.getFilename());
/* 1176 */       ret = this.statement.executeUpdate();
/* 1177 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1179 */       e.printStackTrace();
/* 1180 */       return ret;
/*      */     }
/* 1182 */     return ret;
/*      */   }
/*      */ 
/*      */   public Map<String, String> getConfig()
/*      */   {
/* 1191 */     Map cmap = new HashMap();
/*      */     try {
/* 1193 */       this.statement = this.dbconn.getConnection().prepareStatement(
/* 1194 */         "select t.s_type,t.s_value from t_s_bill_para t");
/* 1195 */       this.result = this.statement.executeQuery();
/* 1196 */       while (this.result.next())
/* 1197 */         cmap.put(this.result.getString("s_type"), this.result
/* 1198 */           .getString("s_value"));
/*      */     }
/*      */     catch (SQLException e) {
/* 1201 */       e.printStackTrace();
/* 1202 */       return cmap;
/*      */     }
/* 1204 */     return cmap;
/*      */   }
/*      */ 
/*      */   public void beginWatchState()
/*      */   {
/* 1212 */     SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 1213 */     String sPrintTime = format1.format(new Date());
/*      */     try {
/* 1215 */       this.statement = this.dbconn
/* 1216 */         .getConnection()
/* 1217 */         .prepareStatement(
/* 1218 */         "insert into T_B_WATCH_STATE(S_PERIOD,C_WATCH_TIME,C_WATCH_TYPE,C_WATCH_STATE) values(?,?,'1','2')");
/* 1219 */       this.statement.setString(1, BaseParam.PERIOD_Y + "-" + 
/* 1220 */         BaseParam.PERIOD_M + "-" + 
/* 1221 */         BaseParam.PERIOD_D);
/* 1222 */       this.statement.setString(2, sPrintTime);
/* 1223 */       this.statement.executeUpdate();
/* 1224 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1226 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void endWatchState(String state)
/*      */   {
/* 1232 */     SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 1233 */     String sPrintTime = format1.format(new Date());
/*      */     try {
/* 1235 */       String period = BaseParam.PERIOD_Y + "-" + 
/* 1236 */         BaseParam.PERIOD_M + "-" + 
/* 1237 */         BaseParam.PERIOD_D;
/* 1238 */       this.statement = this.dbconn
/* 1239 */         .getConnection()
/* 1240 */         .prepareStatement(
/* 1241 */         "update T_B_WATCH_STATE set C_WATCH_STATE=?,C_WATCH_FINISH_TIME=? where S_PERIOD=? and C_WATCH_TYPE='1' and C_WATCH_STATE='2'");
/* 1242 */       this.statement.setString(1, state);
/* 1243 */       this.statement.setString(2, sPrintTime);
/* 1244 */       this.statement.setString(3, period);
/* 1245 */       this.statement.executeUpdate();
/* 1246 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1248 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void beginWatch()
/*      */   {
/* 1254 */     SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 1255 */     String sPrintTime = format1.format(new Date());
/*      */     try {
/* 1257 */       this.statement = this.dbconn
/* 1258 */         .getConnection()
/* 1259 */         .prepareStatement(
/* 1260 */         "update T_S_WATCH set C_START_TIME=?,C_STATE='1' WHERE I_ID=2");
/* 1261 */       this.statement.setString(1, sPrintTime);
/* 1262 */       this.statement.executeUpdate();
/* 1263 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1265 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void endWatch()
/*      */   {
/* 1271 */     SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 1272 */     String sPrintTime = format1.format(new Date());
/*      */     try {
/* 1274 */       this.statement = this.dbconn
/* 1275 */         .getConnection()
/* 1276 */         .prepareStatement(
/* 1277 */         "update T_S_WATCH set C_END_TIME=?,C_STATE='2' WHERE I_ID=2");
/* 1278 */       this.statement.setString(1, sPrintTime);
/* 1279 */       this.statement.executeUpdate();
/* 1280 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1282 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.makeXML.dao.DBDao
 * JD-Core Version:    0.6.2
 */