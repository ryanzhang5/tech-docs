/*     */ package com.bill.makeXML.handler;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.bean.Debitinfo;
/*     */ import com.bill.bean.Fodder;
/*     */ import com.bill.bean.Foldout;
/*     */ import com.bill.bean.PointInfo;
/*     */ import com.bill.bean.Rule;
/*     */ import com.bill.bean.RuleF;
/*     */ import com.bill.bean.RuleM;
/*     */ import com.bill.bean.TempArea;
/*     */ import com.bill.bean.UserAccinfo;
/*     */ import com.bill.bean.UserAccinfoDetail;
/*     */ import com.bill.bean.UserBase;
/*     */ import com.bill.bean.UserBuy;
/*     */ import com.bill.makeXML.cache.Cache;
/*     */ import com.bill.makeXML.dao.DBDao;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class UserXml
/*     */ {
/*     */   private StringBuffer tab1;
/*     */   private StringBuffer tab2;
/*     */   private StringBuffer temp;
/*     */   private List<StringBuffer> tab2list;
/*     */   private List<UserAccinfo> listAccinfo;
/*     */   private List<UserAccinfoDetail> listAccinfoDetail;
/*     */   private List<Debitinfo> listDebitinfo;
/*     */   private List<PointInfo> listPointInfo;
/*     */   private List<Foldout> list;
/*     */   private List<TempArea> plist;
/*     */   private List<RuleF> rlist;
/*     */   private List<RuleF> dlist;
/*     */   private List<RuleM> mlist;
/*     */   private List<Rule> rulelist;
/*     */   private PointInfo point;
/*     */   private UserBuy ub;
/*     */   private DBDao dao;
/*  35 */   private Logger log = null;
/*     */ 
/*  39 */   private String period = "";
/*     */ 
/*     */   public UserXml() {
/*  42 */     this.log = Logger.getLogger(UserXml.class);
/*  43 */     this.dao = new DBDao();
/*     */ 
/*  45 */     this.period = BaseParam.getPeriod("");
/*     */   }
/*     */ 
/*     */   public void writeBaseXml(UserBase ub, StringBuffer xml)
/*     */   {
/*  56 */     xml.append("<acctnbr>" + ub.getAcctnbr() + "</acctnbr>\n");
/*  57 */     xml.append("<rectype>" + ub.getRectype() + "</rectype>\n");
/*  58 */     xml.append("<zip>" + ub.getZip() + "</zip>\n");
/*  59 */     xml.append("<addrname3>" + ub.getAddrname3() + " </addrname3>\n");
/*  60 */     xml.append("<addrname1>" + ub.getAddrname1() + " </addrname1>\n");
/*  61 */     xml.append("<addrname2>" + ub.getAddrname2() + " </addrname2>\n");
/*  62 */     xml.append("<name>" + ub.getName() + " </name>\n");
/*  63 */     xml.append("<sex>" + ub.getSex() + "</sex>\n");
/*  64 */     xml.append("<birthday>" + ub.getBirthday() + "</birthday>\n");
/*  65 */     xml.append("<accnum>" + ub.getAccnum() + "</accnum>\n");
/*  66 */     xml.append("<cusnum>" + ub.getCusnum() + "</cusnum>\n");
/*  67 */     xml.append("<stfromdate>" + ub.getStfromdate() + "</stfromdate>\n");
/*  68 */     xml.append("<enddate>" + ub.getEnddate() + "</enddate>\n");
/*  69 */     xml.append("<specode>" + ub.getSpecode() + "</specode>\n");
/*  70 */     xml.append("<pmtduemark>" + ub.getPmtduemark() + "</pmtduemark>\n");
/*  71 */     xml.append("<cashmark>" + ub.getCashmark() + "</cashmark>\n");
/*  72 */     xml.append("<indiv1>" + ub.getIndiv1() + "</indiv1>\n");
/*  73 */     xml.append("<indiv2>" + ub.getIndiv2() + "</indiv2>\n");
/*  74 */     xml.append("<indiv3>" + ub.getIndiv3() + "</indiv3>\n");
/*  75 */     xml.append("<indiv4>" + ub.getIndiv4() + "</indiv4>\n");
/*  76 */     xml.append("<indiv5>" + ub.getIndiv5() + "</indiv5>\n");
/*  77 */     xml.append("<indiv6>" + ub.getIndiv6() + "</indiv6>\n");
/*  78 */     xml.append("<indiv7>" + ub.getIndiv7() + "</indiv7>\n");
/*  79 */     xml.append("<indiv8>" + ub.getIndiv8() + "</indiv8>\n");
/*  80 */     xml.append("<actinfo>" + ub.getActinfo() + "</actinfo>\n");
/*  81 */     xml.append("<dm1>" + ub.getDm1() + "</dm1>\n");
/*  82 */     xml.append("<dm2>" + ub.getDm2() + "</dm2>\n");
/*  83 */     xml.append("<dm3>" + ub.getDm3() + "</dm3>\n");
/*  84 */     xml.append("<dm4>" + ub.getDm4() + "</dm4>\n");
/*  85 */     xml.append("<brandmsg1>" + ub.getBrandmsg1() + "</brandmsg1>\n");
/*  86 */     xml.append("<brandmsg2>" + ub.getBrandmsg2() + "</brandmsg2>\n");
/*  87 */     xml.append("<brandmsg3>" + ub.getBrandmsg3() + "</brandmsg3>\n");
/*  88 */     xml.append("<brandmsg4>" + ub.getBrandmsg4() + "</brandmsg4>\n");
/*  89 */     xml.append("<brandmsg5>" + ub.getBrandmsg5() + "</brandmsg5>\n");
/*  90 */     xml.append("<brandmsg6>" + ub.getBrandmsg6() + "</brandmsg6>\n");
/*  91 */     xml.append("<brandmsg7>" + ub.getBrandmsg7() + "</brandmsg7>\n");
/*  92 */     xml.append("<convexchmark>" + ub.getConvexchmark() + 
/*  93 */       "</convexchmark>\n");
/*  94 */     xml.append("<vipmsg1>" + ub.getVipmsg1() + "</vipmsg1>\n");
/*  95 */     xml.append("<vipmsg2>" + ub.getVipmsg2() + "</vipmsg2>\n");
/*  96 */     xml.append("<vipmsg3>" + ub.getVipmsg3() + "</vipmsg3>\n");
/*  97 */     xml.append("<vipmsg4>" + ub.getVipmsg4() + "</vipmsg4>\n");
/*  98 */     xml.append("<reprintflag>" + ub.getReprintflag() + "</reprintflag>\n");
/*  99 */     xml.append("<emailflag>" + ub.getEmailflag() + "</emailflag>\n");
/* 100 */     xml.append("<paperflag>" + ub.getPaperflag() + "</paperflag>\n");
/* 101 */     xml.append("<emailaddr>" + ub.getEmailaddr() + "</emailaddr>\n");
/* 102 */     xml.append("<custtype>" + ub.getCusttype() + "</custtype>\n");
/* 103 */     xml.append("<mobilenbr>" + ub.getMobilenbr() + "</mobilenbr>\n");
/* 104 */     xml.append("<ainbr>" + ub.getAinbr() + "</ainbr>\n");
/* 105 */     xml.append("<mobdate>" + ub.getMobdate() + "</mobdate>\n");
/* 106 */     xml.append("<filler>" + ub.getFiller() + "</filler>\n");
/* 107 */     xml.append("<citycode>" + ub.getCity() + "</citycode>\n");
/*     */   }
/*     */ 
/*     */   public void writeEnvrule(String wbs, UserBase ub, StringBuffer xml)
/*     */   {
/* 122 */     this.list = Cache.getFoldout(wbs, ub.getCardNo());
/* 123 */     String tag = "";
/* 124 */     String temp = "";
/* 125 */     Foldout f = null;
/* 126 */     if (this.list.size() > 0) {
/* 127 */       for (int i = 0; i < this.list.size(); i++) {
/* 128 */         f = (Foldout)this.list.get(i);
/*     */ 
/* 130 */         if ("0".equals(f.getState())) {
/* 131 */           tag = tag + "0";
/* 132 */           temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (
/* 133 */             i + 1) + ">\n";
/*     */         }
/* 135 */         else if ("1".equals(f.getState())) {
/* 136 */           switch (i) {
/*     */           case 0:
/* 138 */             if ("Y".equals(ub.getDm1())) {
/* 139 */               tag = tag + "1";
/* 140 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (
/* 141 */                 i + 1) + ">\n";
/*     */             } else {
/* 143 */               tag = tag + "0";
/* 144 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (
/* 145 */                 i + 1) + ">\n";
/*     */             }
/* 147 */             break;
/*     */           case 1:
/* 149 */             if ("Y".equals(ub.getDm2())) {
/* 150 */               tag = tag + "1";
/* 151 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (
/* 152 */                 i + 1) + ">\n";
/*     */             } else {
/* 154 */               tag = tag + "0";
/* 155 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (
/* 156 */                 i + 1) + ">\n";
/*     */             }
/* 158 */             break;
/*     */           case 2:
/* 160 */             if ("Y".equals(ub.getDm3())) {
/* 161 */               tag = tag + "1";
/* 162 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (
/* 163 */                 i + 1) + ">\n";
/*     */             } else {
/* 165 */               tag = tag + "0";
/* 166 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (
/* 167 */                 i + 1) + ">\n";
/*     */             }
/* 169 */             break;
/*     */           case 3:
/* 171 */             if ("Y".equals(ub.getDm4())) {
/* 172 */               tag = tag + "1";
/* 173 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (
/* 174 */                 i + 1) + ">\n";
/*     */             } else {
/* 176 */               tag = tag + "0";
/* 177 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (
/* 178 */                 i + 1) + ">\n";
/*     */             }
/* 180 */             break;
/*     */           default:
/* 182 */             tag = tag + "0";
/* 183 */             temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (
/* 184 */               i + 1) + ">\n";
/* 185 */             break;
/*     */           }
/*     */         }
/* 188 */         else if ("2".equals(f.getState()))
/*     */         {
/* 190 */           Map city = Cache.getFoldoutCity(f.getId(), 
/* 191 */             f.getIdx());
/* 192 */           if (city.containsKey(ub.getCity())) {
/* 193 */             tag = tag + "1";
/* 194 */             temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (
/* 195 */               i + 1) + ">\n";
/*     */           } else {
/* 197 */             tag = tag + "0";
/* 198 */             temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (
/* 199 */               i + 1) + ">\n";
/*     */           }
/*     */         } else {
/* 202 */           tag = tag + "0";
/* 203 */           temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (
/* 204 */             i + 1) + ">\n";
/*     */         }
/*     */       }
/*     */     } else {
/* 208 */       tag = "0000";
/* 209 */       temp = "<INPRIORITY1>0</INPRIORITY1>\n<INPRIORITY2>0</INPRIORITY2>\n<INPRIORITY3>0</INPRIORITY3>\n<INPRIORITY4>0</INPRIORITY4>\n";
/*     */     }
/* 211 */     xml.append("<ENVRULE>" + tag + "</ENVRULE>\n");
/* 212 */     xml.append(temp);
/*     */   }
/*     */ 
/*     */   public boolean writeAccinfoXml(UserBase ub, StringBuffer xml)
/*     */   {
/* 222 */     this.tab1 = new StringBuffer();
/* 223 */     this.tab2 = new StringBuffer();
/*     */ 
/* 225 */     this.listAccinfo = this.dao.getUserInfo(ub);
/*     */ 
/* 227 */     for (UserAccinfo ua : this.listAccinfo)
/*     */     {
/* 229 */       if ("B001".equals(ua.getRectype())) {
/* 230 */         readAccinfo(this.tab1, ua);
/*     */       }
/* 232 */       else if ("D001".equals(ua.getRectype())) {
/* 233 */         readAccinfo(this.tab2, ua);
/*     */       }
/*     */     }
/*     */ 
/* 237 */     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
/* 238 */       xml.append("<accinfo>\n");
/* 239 */       if (this.tab1.length() > 0) {
/* 240 */         xml.append("<tab1>\n");
/* 241 */         xml.append(this.tab1.toString());
/* 242 */         xml.append("</tab1>\n");
/*     */       }
/* 244 */       if (this.tab2.length() > 0) {
/* 245 */         xml.append("<tab2>\n");
/* 246 */         xml.append(this.tab2.toString());
/* 247 */         xml.append("</tab2>\n");
/*     */       }
/* 249 */       xml.append("</accinfo>\n");
/* 250 */       return false;
/*     */     }
/* 252 */     return true;
/*     */   }
/*     */ 
/*     */   private void readAccinfo(StringBuffer sb, UserAccinfo ua)
/*     */   {
/* 257 */     sb.append("<acctnbr>" + ua.getAcctnbr() + "</acctnbr>\n");
/* 258 */     sb.append("<rectype>" + ua.getRectype() + "</rectype>\n");
/* 259 */     sb.append("<stmtdate>" + ua.getStmtdate() + "</stmtdate>\n");
/* 260 */     sb.append("<pmtdate>" + ua.getPmtdate() + "</pmtdate>\n");
/* 261 */     sb.append("<totbegbal>" + ua.getTotbegbal() + "</totbegbal>\n");
/* 262 */     sb.append("<plantotpmt>" + ua.getPlantotpmt() + "</plantotpmt>\n");
/* 263 */     sb.append("<plantotnrlamt>" + ua.getPlantotnrlamt() + 
/* 264 */       "</plantotnrlamt>\n");
/* 265 */     sb.append("<plantotadjamt>" + ua.getPlantotadjamt() + 
/* 266 */       "</plantotadjamt>\n");
/* 267 */     sb.append("<intdueamt>" + ua.getIntdueamt() + "</intdueamt>\n");
/* 268 */     sb.append("<currbal>" + ua.getCurrbal() + "</currbal>\n");
/* 269 */     sb.append("<totdueamt>" + ua.getTotdueamt() + "</totdueamt>\n");
/* 270 */     sb.append("<pmtprint>" + ua.getPmtprint() + "</pmtprint>\n");
/* 271 */     sb.append("<crlim>" + ua.getCrlim() + "</crlim>\n");
/* 272 */     sb.append("<cashcrlim>" + ua.getCashcrlim() + "</cashcrlim>\n");
/* 273 */     sb.append("<pmtarn>" + ua.getPmtarn() + "</pmtarn>\n");
/* 274 */     sb.append("<pmtadn>" + ua.getPmtadn() + "</pmtadn>\n");
/* 275 */     sb.append("<projap>" + ua.getProjap() + "</projap>\n");
/* 276 */     sb.append("<pmtaflag>" + ua.getPmtaflag() + "</pmtaflag>\n");
/* 277 */     sb.append("<achflag>" + ua.getAchflag() + "</achflag>\n");
/* 278 */     sb.append("<pmtflag>" + ua.getPmtflag() + "</pmtflag>\n");
/* 279 */     sb.append("<filler>" + ua.getFiller() + "</filler>\n");
/*     */   }
/*     */ 
/*     */   public void writeAccinfoDetail(UserBase ub, StringBuffer xml)
/*     */   {
/* 290 */     this.tab1 = new StringBuffer();
/* 291 */     this.tab2 = new StringBuffer();
/* 292 */     this.listAccinfoDetail = this.dao.getAccinfoDetail(ub);
/* 293 */     for (UserAccinfoDetail uad : this.listAccinfoDetail)
/*     */     {
/* 295 */       if ("C001".equals(uad.getRectype())) {
/* 296 */         readAccinfoDetail(this.tab1, uad);
/*     */       }
/* 298 */       else if ("E001".equals(uad.getRectype())) {
/* 299 */         readAccinfoDetail(this.tab2, uad);
/*     */       }
/*     */     }
/*     */ 
/* 303 */     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
/* 304 */       xml.append("<transinfo>\n");
/* 305 */       if (this.tab1.length() > 0) {
/* 306 */         xml.append("<tab1>\n<lists>\n");
/* 307 */         xml.append(this.tab1.toString());
/* 308 */         xml.append("</lists>\n</tab1>\n");
/*     */       }
/* 310 */       if (this.tab2.length() > 0) {
/* 311 */         xml.append("<tab2>\n<lists>\n");
/* 312 */         xml.append(this.tab2.toString());
/* 313 */         xml.append("</lists>\n</tab2>\n");
/*     */       }
/* 315 */       xml.append("</transinfo>\n");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void readAccinfoDetail(StringBuffer sb, UserAccinfoDetail uad) {
/* 320 */     sb.append("<list>\n");
/* 321 */     sb.append("<acctnbr>" + uad.getAcctnbr() + "</acctnbr>\n");
/* 322 */     sb.append("<rectype>" + uad.getRectype() + "</rectype>\n");
/* 323 */     sb.append("<recseq>" + uad.getRecseq() + "</recseq>\n");
/* 324 */     sb.append("<effdate>" + uad.getEffdate() + "</effdate>\n");
/* 325 */     sb.append("<postdate>" + uad.getPostdate() + "</postdate>\n");
/* 326 */     sb.append("<cardnlast4>" + uad.getCardnlast4() + "</cardnlast4>\n");
/* 327 */     sb.append("<desc>" + uad.getDesc() + "</desc>\n");
/* 328 */     sb.append("<txnamt>" + uad.getTxnamt() + "</txnamt>\n");
/* 329 */     sb.append("<srctamt>" + uad.getSrctamt() + "</srctamt>\n");
/* 330 */     sb.append("<srctcurr>" + uad.getSrctcurr() + "</srctcurr>\n");
/* 331 */     sb.append("<purcty>" + uad.getPurcty() + "</purcty>\n");
/* 332 */     sb.append("<filler>" + uad.getFiller() + "</filler>\n");
/* 333 */     sb.append("</list>\n");
/*     */   }
/*     */ 
/*     */   public void writeBuy(UserBase user, StringBuffer xml)
/*     */   {
/* 344 */     this.ub = this.dao.getUserBuy(user);
/*     */ 
/* 346 */     if (this.ub == null)
/* 347 */       return;
/* 348 */     xml.append("<exchinfo>\n");
/* 349 */     xml.append("<acctnbr>" + this.ub.getAcctnbr() + "</acctnbr>\n");
/* 350 */     xml.append("<rectype>" + this.ub.getRectype() + "</rectype>\n");
/* 351 */     xml.append("<exchusdamt>" + this.ub.getExchusdamt() + "</exchusdamt>\n");
/* 352 */     xml.append("<sellrate>" + this.ub.getSellrate() + "</sellrate>\n");
/* 353 */     xml.append("<exchrmbamt>" + this.ub.getExchrmbamt() + "</exchrmbamt>\n");
/* 354 */     xml.append("<achrtnbr>" + this.ub.getAchrtnbr() + "</achrtnbr>\n");
/* 355 */     xml.append("<achdbnbr>" + this.ub.getAchdbnbr() + "</achdbnbr>\n");
/* 356 */     xml.append("<filler>" + this.ub.getFiller() + "</filler>\n");
/* 357 */     xml.append("</exchinfo>\n");
/*     */   }
/*     */ 
/*     */   public void writeDebitinfo(UserBase user, StringBuffer xml)
/*     */   {
/* 368 */     this.tab1 = new StringBuffer();
/* 369 */     this.tab2 = new StringBuffer();
/* 370 */     this.listDebitinfo = this.dao.getDebitinfo(user);
/* 371 */     for (Debitinfo di : this.listDebitinfo) {
/* 372 */       if ("C002".equals(di.getRectype()))
/* 373 */         readDebitinfo(this.tab1, di);
/* 374 */       else if ("E002".equals(di.getRectype())) {
/* 375 */         readDebitinfo(this.tab2, di);
/*     */       }
/*     */     }
/*     */ 
/* 379 */     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
/* 380 */       xml.append("<debitinfo>\n");
/* 381 */       if (this.tab1.length() > 0) {
/* 382 */         xml.append("<tab1>\n<lists>\n");
/* 383 */         xml.append(this.tab1.toString());
/* 384 */         xml.append("</lists>\n</tab1>\n");
/*     */       }
/* 386 */       if (this.tab2.length() > 0) {
/* 387 */         xml.append("<tab2>\n<lists>\n");
/* 388 */         xml.append(this.tab2.toString());
/* 389 */         xml.append("</lists>\n</tab2>\n");
/*     */       }
/* 391 */       xml.append("</debitinfo>\n");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void readDebitinfo(StringBuffer temp, Debitinfo di) {
/* 396 */     temp.append("<list>\n");
/* 397 */     temp.append("<acctnbr>" + di.getAcctnbr() + "</acctnbr>\n");
/* 398 */     temp.append("<rectype>" + di.getRectype() + "</rectype>\n");
/* 399 */     temp.append("<custnbr>" + di.getCustnbr() + "</custnbr>\n");
/* 400 */     temp.append("<effdate>" + di.getEffdate() + "</effdate>\n");
/* 401 */     temp.append("<txndesc>" + di.getTxndesc() + "</txndesc>\n");
/* 402 */     temp.append("<txncity>" + di.getTxncity() + "</txncity>\n");
/* 403 */     temp.append("<currcode>" + di.getCurrcode() + "</currcode>\n");
/* 404 */     temp.append("<txnamt>" + di.getTxnamt() + "</txnamt>\n");
/* 405 */     temp.append("<cardl4>" + di.getCardl4() + "</cardl4>\n");
/* 406 */     temp.append("<filler>" + di.getFiller() + "</filler>\n");
/* 407 */     temp.append("</list>\n");
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void writePoint(UserBase user, StringBuffer xml)
/*     */   {
/* 422 */     this.tab1 = new StringBuffer();
/* 423 */     this.tab2list = new ArrayList();
/* 424 */     this.temp = new StringBuffer();
/*     */ 
/* 427 */     this.listPointInfo = this.dao.getPoint(user);
/* 428 */     for (PointInfo pi : this.listPointInfo)
/*     */     {
/* 430 */       if ("3".equals(pi.getPointtype())) {
/* 431 */         readPoint(this.tab1, pi);
/* 432 */       } else if ("2".equals(pi.getPointtype())) {
/* 433 */         this.tab2 = new StringBuffer();
/* 434 */         readPoint(this.tab2, pi);
/* 435 */         this.tab2list.add(this.tab2);
/*     */       }
/*     */     }
/*     */ 
/* 439 */     this.point = this.dao.getPoint2(user);
/* 440 */     if (this.point != null) {
/* 441 */       this.temp.append("<tab3>\n");
/* 442 */       this.temp.append("<billdate>" + this.point.getBilldate() + "</billdate>\n");
/* 443 */       this.temp.append("<ecifno>" + this.point.getBusinessid() + "</ecifno>\n");
/* 444 */       this.temp.append("<curpavalia>" + this.point.getAblepoint() + 
/* 445 */         "</curpavalia>\n");
/* 446 */       this.temp.append("<pointavabf>" + this.point.getLastbalpoint() + 
/* 447 */         "</pointavabf>\n");
/* 448 */       this.temp.append("<newpoint>" + this.point.getAddpoint() + "</newpoint>\n");
/* 449 */       this.temp
/* 450 */         .append("<pointredee>" + this.point.getExpoint() + 
/* 451 */         "</pointredee>\n");
/* 452 */       this.temp.append("<adpoints>" + this.point.getAdpoints() + "</adpoints>\n");
/* 453 */       this.temp.append("<invalidpoint>" + this.point.getEndpoints() + 
/* 454 */         "</invalidpoint>\n");
/* 455 */       this.temp.append("</tab3>\n");
/*     */     }
/*     */ 
/* 458 */     if ((this.tab1.length() > 0) || (this.tab2list.size() > 0) || (this.temp.length() > 0)) {
/* 459 */       xml.append("<point-info>\n");
/* 460 */       if (this.tab1.length() > 0) {
/* 461 */         xml.append("<tab1>\n");
/* 462 */         xml.append(this.tab1.toString());
/* 463 */         xml.append("</tab1>\n");
/*     */       }
/* 465 */       if (this.tab2list.size() > 0) {
/* 466 */         xml.append("<tab2>\n<lists>\n");
/* 467 */         for (StringBuffer sb : this.tab2list) {
/* 468 */           xml.append("<list>\n" + sb.toString() + "</list>\n");
/*     */         }
/* 470 */         xml.append("</lists>\n</tab2>\n");
/*     */       }
/* 472 */       if (this.temp.length() > 0) {
/* 473 */         xml.append(this.temp.toString());
/*     */       }
/* 475 */       xml.append("</point-info>\n");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void readPoint(StringBuffer sb, PointInfo pi)
/*     */   {
/* 486 */     if ((pi.getCardPointType() == null) || ("".equals(pi.getCardPointType())) || 
/* 487 */       ("0".equals(pi.getCardPointType()))) {
/* 488 */       sb.append("<pointtype>" + pi.getPointtype() + "</pointtype>\n");
/*     */     }
/* 491 */     else if ("1".equals(pi.getCardPointType())) {
/* 492 */       sb.append("<pointtype>A</pointtype>\n");
/*     */     }
/* 494 */     else if ("2".equals(pi.getCardPointType())) {
/* 495 */       sb.append("<pointtype>B</pointtype>\n");
/*     */     }
/*     */ 
/* 498 */     sb.append("<cardportid>" + pi.getCardportid() + "</cardportid>\n");
/* 499 */     sb.append("<businessid>" + pi.getBusinessid() + "</businessid>\n");
/* 500 */     sb.append("<ablepoint>" + pi.getAblepoint() + "</ablepoint>\n");
/* 501 */     sb.append("<lastbalpoint>").append(pi.getLastbalpoint()).append("</lastbalpoint>\n");
/* 502 */     sb.append("<addpoint>" + pi.getAddpoint() + "</addpoint>\n");
/* 503 */     sb.append("<expoint>" + pi.getExpoint() + "</expoint>\n");
/* 504 */     sb.append("<adpoints>" + pi.getAdpoints() + "</adpoints>\n");
/* 505 */     sb.append("<endpoints>" + pi.getEndpoints() + "</endpoints>\n");
/* 506 */     sb.append("<ecifno>" + pi.getEcifno() + "</ecifno>\n");
/* 507 */     sb.append("<startdate>" + pi.getStartdate() + "</startdate>\n");
/* 508 */     sb.append("<enddate>" + pi.getEnddate() + "</enddate>\n");
/* 509 */     sb.append("<wholeconsume>").append(pi.getWholeconsume()).append("</wholeconsume>\n");
/* 510 */     sb.append("<inconsume>" + pi.getInconsume() + "</inconsume>\n");
/* 511 */     sb.append("<outconsume>" + pi.getOutconsume() + "</outconsume>\n");
/* 512 */     sb.append("<wholemoney>" + pi.getWholemoney() + "</wholemoney>\n");
/* 513 */     sb.append("<inmoney>" + pi.getInmoney() + "</inmoney>\n");
/* 514 */     sb.append("<outmoney>" + pi.getOutmoney() + "</outmoney>\n");
/* 515 */     sb.append("<usedmoney>" + pi.getUsedmoney() + "</usedmoney>\n");
/* 516 */     sb.append("<lavemoney>" + pi.getLavemoney() + "</lavemoney>\n");
/* 517 */     sb.append("<validdate>" + pi.getValiddate() + "</validdate>\n");
/* 518 */     sb.append("<laddermoney>" + pi.getLaddermoney() + "</laddermoney>\n");
/* 519 */     sb.append("<ladderscale>" + pi.getLadderscale() + "</ladderscale>\n");
/*     */ 
/* 521 */     if ("2".equals(pi.getPointtype())) {
/* 522 */       sb.append("<card4>" + pi.getCard4() + "</card4>\n");
/*     */     }
/* 524 */     sb.append("<cardname>" + pi.getCardname() + "</cardname>\n");
/*     */   }
/*     */ 
/*     */   public StringBuffer writeTemplate(UserBase user, String type)
/*     */   {
/* 540 */     this.temp = new StringBuffer();
/*     */ 
/* 542 */     String ptId = (String)Cache.templateMap.get(user.getCardNo() + "_" + type);
/*     */ 
/* 544 */     this.plist = Cache.getTemplateInfo(ptId);
/* 545 */     Fodder f = null;
/*     */ 
/* 547 */     boolean isExtis = false;
/*     */ 
/* 549 */     int idx = 1;
/* 550 */     this.temp.append("<resourcesinfo>\n<lists>\n");
/*     */ 
/* 552 */     for (TempArea ta : this.plist) {
/* 553 */       isExtis = false;
/* 554 */       idx = 1;
/*     */ 
/* 556 */       this.rulelist = Cache.getRuleMap(ptId, "1", ta.getArea());
/*     */ 
/* 559 */       if ((this.rulelist != null) && (this.rulelist.size() > 0))
/*     */       {
/* 561 */         for (Rule rm : this.rulelist)
/*     */         {
/* 563 */           if (isExtis)
/*     */           {
/*     */             break;
/*     */           }
/* 567 */           this.rlist = Cache.getRuleFMap(rm.getRuleid());
/* 568 */           if (this.rlist != null)
/*     */           {
/* 570 */             for (RuleF rf : this.rlist)
/*     */             {
/* 573 */               f = Cache.getFodder(rf.getFodder());
/*     */ 
/* 575 */               if (f == null) {
/* 576 */                 this.log.error("素材无效!模板ID=" + ptId + ";区域规则ID=" + 
/* 577 */                   rm.getRuleid() + "条件个数=" + 
/* 578 */                   this.rlist.size() + ";素材=" + 
/* 579 */                   rf.getFodder());
/*     */               }
/* 583 */               else if ("3".equals(ta.getType())) {
/* 584 */                 isExtis = true;
/* 585 */                 readRuleXml(this.temp, type, ta.getArea(), Integer.valueOf(idx), f
/* 586 */                   .getUrl(), f.getLinkurl());
/* 587 */                 idx++;
/*     */               }
/*     */               else {
/* 590 */                 this.mlist = Cache.getRuleFFList(rf.getId());
/*     */ 
/* 593 */                 if ((this.mlist == null) || (this.mlist.size() == 0) || 
/* 594 */                   (readRule(this.mlist, user))) {
/* 595 */                   isExtis = true;
/*     */ 
/* 597 */                   if ("4".equals(ta.getType()))
/*     */                   {
/* 599 */                     readRuleXml(this.temp, type, ta.getArea(), 
/* 600 */                       Integer.valueOf(idx), f.getUrl(), f.getLinkurl());
/* 601 */                     idx++;
/*     */                   }
/*     */                   else {
/* 604 */                     readRuleXml(this.temp, type, ta.getArea(), 
/* 605 */                       rf.getPri(), f.getUrl(), f
/* 606 */                       .getLinkurl());
/*     */ 
/* 608 */                     break;
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/* 614 */           else this.log.error("没有规则详情!模板ID=" + ptId + ";区域规则ID=" + 
/* 615 */               rm.getRuleid());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 620 */       if (!isExtis) {
/* 621 */         this.rulelist = Cache.getRuleMap(ptId, "0", ta.getArea());
/* 622 */         if ((this.rulelist != null) && (this.rulelist.size() > 0))
/*     */         {
/* 624 */           this.dlist = Cache.getRuleFMap(((Rule)this.rulelist.get(0)).getRuleid());
/* 625 */           if ((this.dlist != null) && (this.dlist.size() > 0))
/* 626 */             for (RuleF rf : this.dlist)
/*     */             {
/* 628 */               f = Cache.getFodder(rf.getFodder());
/*     */ 
/* 630 */               if (f == null) {
/* 631 */                 this.log.error("没有默认规则的素材！模板=" + ptId + ",区域=" + 
/* 632 */                   ta.getArea() + ",素材=" + 
/* 633 */                   rf.getFodder());
/*     */               }
/*     */               else {
/* 636 */                 readRuleXml(this.temp, type, ta.getArea(), rf.getPri(), 
/* 637 */                   f.getUrl(), f.getLinkurl());
/* 638 */                 if ((!"3".equals(ta.getType())) && 
/* 639 */                   (!"4".equals(ta.getType())))
/*     */                   break;
/*     */               }
/*     */             }
/*     */           else {
/* 644 */             this.log.error("没有默认的规则！模板=" + ptId + ",区域=" + ta.getArea());
/*     */           }
/*     */         }
/*     */       }
/* 648 */       isExtis = false;
/*     */     }
/* 650 */     this.temp.append("</lists>\n</resourcesinfo>\n");
/* 651 */     return this.temp;
/*     */   }
/*     */ 
/*     */   public void readRuleXml(StringBuffer xml, String type, String area, Object pri, String url, String link)
/*     */   {
/* 667 */     xml.append("<list>\n<billtype>");
/* 668 */     xml.append(type);
/* 669 */     xml.append("</billtype>\n<area>");
/* 670 */     xml.append(area);
/* 671 */     xml.append("</area>\n<priority>");
/* 672 */     xml.append(pri);
/* 673 */     xml.append("</priority>\n<rescontent>");
/* 674 */     xml.append(url);
/* 675 */     xml.append("</rescontent>\n<resurl>");
/* 676 */     xml.append(link);
/* 677 */     xml.append("</resurl>\n</list>\n");
/*     */   }
/*     */ 
/*     */   public boolean readRule(List<RuleM> list, UserBase user)
/*     */   {
/* 688 */     boolean result = false;
/* 689 */     boolean oldresult = false;
/* 690 */     int next_if = 0;
/* 691 */     String wd = "";
/* 692 */     for (RuleM rm : list)
/*     */     {
/* 694 */       wd = rm.getFieldid();
/*     */ 
/* 696 */       if ("birthday".equals(wd)) {
/* 697 */         String temp = user.birthday;
/*     */ 
/* 699 */         if (user.birthday.length() > 4) {
/* 700 */           temp = user.birthday.substring(4);
/*     */         }
/* 702 */         oldresult = checkValue(rm, temp);
/*     */       }
/* 704 */       else if ("sex".equals(wd))
/*     */       {
/* 706 */         if (rm.getOpr1() != 0) {
/* 707 */           return false;
/*     */         }
/*     */ 
/* 710 */         oldresult = rm.getVal1().equals(user.sex);
/*     */       }
/* 712 */       else if ("city".equals(wd))
/*     */       {
/* 714 */         if (rm.getOpr1() != 0) {
/* 715 */           return false;
/*     */         }
/*     */ 
/* 718 */         oldresult = rm.getVal1().equals(user.city);
/*     */       }
/* 720 */       else if ("mobilenbr".equals(wd))
/*     */       {
/* 722 */         if (rm.getOpr1() != 0) {
/* 723 */           return false;
/*     */         }
/*     */ 
/* 726 */         if (user.mobilenbr.indexOf(rm.getVal1()) == 0)
/* 727 */           oldresult = true;
/*     */         else {
/* 729 */           oldresult = false;
/*     */         }
/*     */       }
/* 732 */       else if ("ainbr".equals(wd))
/*     */       {
/* 734 */         if (rm.getOpr1() != 0) {
/* 735 */           return false;
/*     */         }
/* 737 */         oldresult = rm.getVal1().equals(user.ainbr);
/*     */       }
/* 739 */       else if ("mobdate".equals(wd)) {
/* 740 */         oldresult = checkValue(rm, user.mobdate);
/*     */       }
/* 742 */       else if ("crlim".equals(wd)) {
/* 743 */         oldresult = checkValue(rm, user.crlim);
/*     */       }
/* 745 */       else if ("currbal".equals(wd)) {
/* 746 */         oldresult = checkValue(rm, user.currbal);
/*     */       }
/* 748 */       else if ("totdueamt".equals(wd)) {
/* 749 */         oldresult = checkValue(rm, user.totdueamt);
/*     */       }
/* 751 */       else if ("cashcrlim".equals(wd)) {
/* 752 */         oldresult = checkValue(rm, user.cashcrlim);
/* 753 */       } else if ("indiv1".equals(wd))
/*     */       {
/* 755 */         if (rm.getOpr1() != 0) {
/* 756 */           return false;
/*     */         }
/*     */ 
/* 759 */         oldresult = rm.getVal1().equals(user.indiv1);
/* 760 */       } else if ("indiv2".equals(wd))
/*     */       {
/* 762 */         if (rm.getOpr1() != 0) {
/* 763 */           return false;
/*     */         }
/*     */ 
/* 766 */         oldresult = rm.getVal1().equals(user.indiv2);
/* 767 */       } else if ("indiv3".equals(wd))
/*     */       {
/* 769 */         if (rm.getOpr1() != 0) {
/* 770 */           return false;
/*     */         }
/*     */ 
/* 773 */         oldresult = rm.getVal1().equals(user.indiv3);
/* 774 */       } else if ("indiv4".equals(wd))
/*     */       {
/* 776 */         if (rm.getOpr1() != 0) {
/* 777 */           return false;
/*     */         }
/*     */ 
/* 780 */         oldresult = rm.getVal1().equals(user.indiv4);
/* 781 */       } else if ("indiv5".equals(wd))
/*     */       {
/* 783 */         if (rm.getOpr1() != 0) {
/* 784 */           return false;
/*     */         }
/*     */ 
/* 787 */         oldresult = rm.getVal1().equals(user.indiv5);
/* 788 */       } else if ("indiv6".equals(wd))
/*     */       {
/* 790 */         if (rm.getOpr1() != 0) {
/* 791 */           return false;
/*     */         }
/*     */ 
/* 794 */         oldresult = rm.getVal1().equals(user.indiv6);
/* 795 */       } else if ("indiv7".equals(wd))
/*     */       {
/* 797 */         if (rm.getOpr1() != 0) {
/* 798 */           return false;
/*     */         }
/*     */ 
/* 801 */         oldresult = rm.getVal1().equals(user.indiv7);
/* 802 */       } else if ("indiv8".equals(wd))
/*     */       {
/* 804 */         if (rm.getOpr1() != 0) {
/* 805 */           return false;
/*     */         }
/*     */ 
/* 808 */         oldresult = rm.getVal1().equals(user.indiv8);
/*     */       }
/*     */ 
/* 811 */       if (next_if == 0) {
/* 812 */         result = oldresult;
/*     */       }
/* 814 */       else if (1 == next_if) {
/* 815 */         result = (result) && (oldresult);
/*     */       }
/* 817 */       else if (2 == next_if) {
/* 818 */         result = (result) || (oldresult);
/*     */       }
/*     */ 
/* 821 */       next_if = rm.getCif();
/*     */     }
/* 823 */     return result;
/*     */   }
/*     */ 
/*     */   private boolean checkValue(RuleM rm, Object val)
/*     */   {
/* 836 */     boolean result = false;
/* 837 */     boolean result1 = false;
/* 838 */     boolean result2 = false;
/* 839 */     float i_val = 0.0F;
/* 840 */     float i_val1 = 0.0F;
/* 841 */     float i_val2 = 0.0F;
/*     */     try
/*     */     {
/* 845 */       if ((val instanceof String))
/* 846 */         i_val = Float.valueOf(val.toString()).floatValue();
/*     */       else {
/* 848 */         i_val = ((Float)val).floatValue();
/*     */       }
/* 850 */       i_val1 = Float.parseFloat(rm.getVal1());
/* 851 */       if ((rm.getVal2() == null) || ("".equals(rm.getVal2())))
/* 852 */         i_val2 = -1.0F;
/*     */       else
/* 854 */         i_val2 = Float.parseFloat(rm.getVal2());
/*     */     }
/*     */     catch (Exception e) {
/* 857 */       this.log
/* 858 */         .error("规则条件参数转型失败！参数1=" + rm.getVal1() + ",参数2=" + 
/* 859 */         rm.getVal2());
/* 860 */       return false;
/*     */     }
/*     */ 
/* 864 */     if (rm.getOpr1() == 0)
/*     */     {
/* 866 */       result = rm.getVal1().equals(val);
/*     */     }
/*     */     else
/*     */     {
/* 870 */       if (1 == rm.getOpr1())
/* 871 */         result1 = i_val > i_val1;
/* 872 */       else if (2 == rm.getOpr1())
/* 873 */         result1 = i_val < i_val1;
/* 874 */       else if (3 == rm.getOpr1())
/* 875 */         result1 = i_val >= i_val1;
/* 876 */       else if (4 == rm.getOpr1()) {
/* 877 */         result1 = i_val <= i_val1;
/*     */       }
/*     */ 
/* 881 */       if (-1.0F == i_val2) {
/* 882 */         result2 = false;
/*     */       }
/* 884 */       else if (1 == rm.getOpr2())
/* 885 */         result2 = i_val > i_val2;
/* 886 */       else if (2 == rm.getOpr2())
/* 887 */         result2 = i_val < i_val2;
/* 888 */       else if (3 == rm.getOpr2())
/* 889 */         result2 = i_val >= i_val2;
/* 890 */       else if (4 == rm.getOpr2()) {
/* 891 */         result2 = i_val >= i_val2;
/*     */       }
/*     */ 
/* 894 */       result = (result1) && (result2);
/*     */     }
/* 896 */     return result;
/*     */   }
/*     */ 
/*     */   public List<UserBase> getUserBase(String cardid, String city, int page, int size)
/*     */   {
/* 908 */     return this.dao.getUserBase(cardid, city, page, size);
/*     */   }
/*     */ 
/*     */   public List<UserBase> getUserBase(String cardid, int page, int size)
/*     */   {
/* 919 */     return this.dao.getUserBase(cardid, page, size);
/*     */   }
/*     */ 
/*     */   public void colse()
/*     */   {
/* 926 */     this.dao.close();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.makeXML.handler.UserXml
 * JD-Core Version:    0.6.2
 */