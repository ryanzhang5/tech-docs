/*     */ package com.bill.makeXML.handler;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ 
/*     */ public class PXml
/*     */   implements WriteXML
/*     */ {
/*     */   public RandomAccessFile filew;
/*     */   public File file;
/*  24 */   public int c_count_error = 0;
/*     */ 
/*     */   public String create(String cardid, String wbs, String yyz, String cardtype)
/*     */   {
/*  38 */     String fpath = getFileInfo(wbs, cardtype);
/*  39 */     this.file = new File(fpath);
/*  40 */     if (!this.file.exists()) {
/*  41 */       this.file.mkdirs();
/*     */     }
/*     */ 
/*  44 */     this.file = new File(fpath + BaseParam.PERIOD + "_" + cardid + "_" + yyz + "_" + wbs + ".xml");
/*     */     try {
/*  46 */       if (this.file.exists()) {
/*  47 */         this.file.delete();
/*     */       }
/*     */ 
/*  50 */       if (this.file.createNewFile())
/*  51 */         this.filew = new RandomAccessFile(this.file.getPath(), "rw");
/*     */     }
/*     */     catch (IOException e) {
/*  54 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  57 */     write(BaseParam.XML_BEGIN);
/*  58 */     return this.file.getPath();
/*     */   }
/*     */ 
/*     */   public void write(String xml)
/*     */   {
/*     */     try
/*     */     {
/*  66 */       this.filew.write(xml.getBytes("utf-8"));
/*     */     } catch (IOException e) {
/*  68 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void over(int count)
/*     */   {
/*     */     try
/*     */     {
/*  78 */       this.filew.write(BaseParam.XML_END.getBytes("utf-8"));
/*  79 */       this.filew.close();
/*  80 */       if (count == 0)
/*  81 */         this.file.delete();
/*     */     }
/*     */     catch (IOException e) {
/*  84 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getFileInfo(String wbs, String cardtype)
/*     */   {
/*  97 */     String d = BaseParam.PERIOD;
/*  98 */     String y = d.substring(0, 4);
/*  99 */     String m = d.substring(4, 6);
/* 100 */     String day = d.substring(6, 8);
/* 101 */     String p = y + "/" + m + "/" + day;
/*     */ 
/* 103 */     String fpath = BaseParam.XML_PATH + cardtype + "/PRODUCT/XML/" + p + "/" + "TNO" + "/" + wbs + "/";
/* 104 */     File temp = new File(fpath);
/*     */ 
/* 106 */     if (!temp.exists()) {
/* 107 */       temp.mkdirs();
/*     */     }
/* 109 */     String tnopath = BaseParam.XML_PATH + cardtype + "/PRODUCT/TNO/" + wbs;
/* 110 */     temp = new File(tnopath);
/*     */ 
/* 112 */     if (!temp.exists()) {
/* 113 */       temp.mkdirs();
/*     */     }
/* 115 */     String pdfath = BaseParam.XML_PATH + cardtype + "/PRODUCT/PDF/" + y + "/" + m + "/" + day;
/* 116 */     temp = new File(pdfath);
/*     */ 
/* 118 */     if (!temp.exists()) {
/* 119 */       temp.mkdirs();
/*     */     }
/* 121 */     return fpath;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/* 125 */     PXml p = new PXml();
/* 126 */     p.create("11", "22", "33", "44");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.makeXML.handler.PXml
 * JD-Core Version:    0.6.2
 */