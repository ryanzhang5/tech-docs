/*     */ package com.bill.makeXML.handler;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.bean.Plog;
/*     */ import com.bill.makeXML.cache.Cache;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class EXml
/*     */ {
/*  20 */   public String path = "d:";
/*     */ 
/*  24 */   public int max = 10000;
/*     */ 
/*  28 */   public int count = 0;
/*     */ 
/*  32 */   public int c_count = 0;
/*  33 */   public int c_count_error = 0;
/*     */   public File file;
/*     */   public RandomAccessFile filew;
/*     */   private String cardid;
/*     */   private String cardtype;
/*  45 */   private String basepath = BaseParam.getXMLPATH();
/*  46 */   private String period = BaseParam.getPeriod("");
/*     */   private Plog plog1;
/*  49 */   private static Logger log = Logger.getLogger(EXml.class);
/*     */ 
/*     */   public void create(String cardid, String cardtype)
/*     */   {
/*  58 */     this.cardid = cardid;
/*  59 */     this.cardtype = cardtype;
/*     */ 
/*  61 */     String fpath = getFileInfo(cardid, cardtype);
/*  62 */     this.file = new File(fpath);
/*  63 */     if (!this.file.exists()) {
/*  64 */       this.file.mkdirs();
/*     */     }
/*     */ 
/*  67 */     this.file = new File(fpath + this.period + "_" + cardid + "_" + this.count + ".xml");
/*     */     try {
/*  69 */       if (this.file.exists()) {
/*  70 */         this.file.delete();
/*     */       }
/*  72 */       log.trace("file path=" + this.file.getPath());
/*     */ 
/*  74 */       if (this.file.createNewFile()) {
/*  75 */         this.filew = new RandomAccessFile(this.file.getPath(), "rw");
/*  76 */         this.c_count = 0;
/*  77 */         syswrite(BaseParam.XML_BEGIN);
/*     */       }
/*     */     } catch (IOException e) {
/*  80 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  83 */     this.plog1 = new Plog();
/*  84 */     this.plog1.setFilename(this.file.getPath());
/*  85 */     this.plog1.setBusinpnt_no("");
/*  86 */     this.plog1.setCard_id(cardid);
/*  87 */     this.plog1.setPaper_no("");
/*  88 */     Cache.savePLogBegin(this.plog1);
/*     */   }
/*     */ 
/*     */   public void syswrite(String xml) {
/*  92 */     if (this.filew == null) {
/*  93 */       return;
/*     */     }
/*     */     try
/*     */     {
/*  97 */       this.filew.write(xml.getBytes("utf-8"));
/*     */     } catch (IOException e) {
/*  99 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void write(String xml)
/*     */   {
/* 108 */     if (this.filew == null) {
/* 109 */       create(this.cardid, this.cardtype);
/*     */     }
/*     */     try
/*     */     {
/* 113 */       this.filew.write(xml.getBytes("utf-8"));
/*     */     } catch (IOException e) {
/* 115 */       e.printStackTrace();
/*     */     }
/* 117 */     this.c_count += 1;
/*     */ 
/* 119 */     if (this.max == this.c_count) {
/* 120 */       close();
/* 121 */       this.count += 1;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void close() {
/*     */     try {
/* 127 */       syswrite(BaseParam.XML_END);
/* 128 */       this.filew.close();
/* 129 */       if (this.c_count == 0) {
/* 130 */         this.file.delete();
/* 131 */         Cache.savePLogDel(this.plog1);
/*     */       }
/*     */       else {
/* 134 */         this.plog1.setError(this.c_count_error);
/* 135 */         this.plog1.setShare(this.c_count);
/* 136 */         this.plog1.setState("1");
/* 137 */         Cache.savePLogEnd(this.plog1);
/*     */       }
/*     */     } catch (IOException e) {
/* 140 */       e.printStackTrace();
/*     */     } finally {
/* 142 */       this.filew = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getFileInfo(String cardid, String cardtype)
/*     */   {
/* 156 */     String d = this.period;
/* 157 */     String y = d.substring(0, 4);
/* 158 */     String m = d.substring(4, 6);
/* 159 */     String day = d.substring(6, 8);
/* 160 */     String p = y + "/" + m + "/" + day;
/* 161 */     String fpath = this.basepath + cardtype + "/PRODUCT/XML/" + p + "/HTML/";
/* 162 */     File temp = new File(fpath);
/*     */ 
/* 164 */     if (!temp.exists()) {
/* 165 */       temp.mkdirs();
/*     */     }
/* 167 */     String htmlpath = this.basepath + cardtype + "/PRODUCT/HTML/" + y + "/" + m + "/" + day;
/* 168 */     temp = new File(htmlpath);
/*     */ 
/* 170 */     if (!temp.exists()) {
/* 171 */       temp.mkdirs();
/*     */     }
/* 173 */     return fpath;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/* 177 */     EXml e = new EXml();
/* 178 */     e.create("5678", "");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.makeXML.handler.EXml
 * JD-Core Version:    0.6.2
 */