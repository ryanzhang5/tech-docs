/*    */ package com.bill.makeXML.util.file;
/*    */ 
/*    */ import com.bill.bean.HisAmountBean;
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Calendar;
/*    */ import java.util.Date;
/*    */ import org.apache.commons.lang.time.DateFormatUtils;
/*    */ 
/*    */ public class HisAmountToXml
/*    */ {
/* 15 */   private String[] dates = null;
/*    */ 
/*    */   public HisAmountToXml(String period) {
/*    */     try { this.dates = getAmountDate(period);
/*    */     } catch (ParseException e) {
/* 20 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public String getHisAmount(HisAmountBean habean, String flag)
/*    */   {
/* 54 */     StringBuffer sb = new StringBuffer();
/* 55 */     sb.append("<").append(flag).append(">").append("\n<lists>\n");
/* 56 */     for (int i = 1; i < 13; i++) {
/* 57 */       sb
/* 58 */         .append("<list>\n")
/* 59 */         .append("<date>").append(this.dates[(i - 1)]).append("</date>\n")
/* 60 */         .append("<amount>").append(habean.getAmount(i)).append("</amount>\n")
/* 61 */         .append("</list>\n");
/*    */     }
/* 63 */     sb.append("</lists>\n</").append(flag).append(">\n");
/* 64 */     return sb.toString();
/*    */   }
/*    */ 
/*    */   private String[] getAmountDate(String period) throws ParseException {
/* 68 */     String[] result = new String[12];
/* 69 */     Calendar c = Calendar.getInstance();
/* 70 */     Date date = new SimpleDateFormat("yyyyMMdd").parse(period);
/* 71 */     for (int i = 0; i < 12; i++) {
/* 72 */       c.setTime(date);
/* 73 */       c.add(2, -(i + 1));
/* 74 */       result[i] = DateFormatUtils.format(c.getTime(), "yyyyMM");
/*    */     }
/* 76 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.makeXML.util.file.HisAmountToXml
 * JD-Core Version:    0.6.2
 */