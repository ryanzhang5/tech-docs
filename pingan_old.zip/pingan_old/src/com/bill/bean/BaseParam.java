/*    */ package com.bill.bean;
/*    */ 
/*    */ public class BaseParam
/*    */ {
/*  8 */   public static String XML_PATH = "d:/xml/";
/*    */ 
/* 15 */   public static String PERIOD = "20110805";
/* 16 */   public static String PERIOD_YM = "201108";
/* 17 */   public static String PERIOD_Y = "2011";
/* 18 */   public static String PERIOD_M = "08";
/* 19 */   public static String PERIOD_D = "05";
/* 20 */   public static String PERIOD_Y_M_D = "2011-08-05";
/*    */ 
/* 41 */   public static String DB_IP = "192.168.11.4";
/*    */ 
/* 45 */   public static String DB_PORT = "1521";
/*    */ 
/* 49 */   public static String DB_NAME = "BILLUAT";
/*    */ 
/* 53 */   public static String DB_USER = "billuser";
/*    */ 
/* 57 */   public static String DB_PWD = "billadmin";
/*    */ 
/* 69 */   public static String XML_BEGIN = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<xyk>\n<checksheets>\n";
/*    */ 
/* 74 */   public static String XML_END = "</checksheets>\n</xyk>\n";
/*    */ 
/*    */   public static synchronized String getXMLPATH()
/*    */   {
/* 10 */     return XML_PATH;
/*    */   }
/*    */ 
/*    */   public static synchronized String getPeriod(String s)
/*    */   {
/* 27 */     if ("".equals(s))
/* 28 */       return PERIOD;
/* 29 */     if ("YM".equals(s))
/* 30 */       return PERIOD_YM;
/* 31 */     if ("D".equals(s)) {
/* 32 */       return PERIOD_D;
/*    */     }
/* 34 */     return PERIOD;
/*    */   }
/*    */ 
/*    */   public static synchronized String getDBIP()
/*    */   {
/* 43 */     return DB_IP;
/*    */   }
/*    */ 
/*    */   public static synchronized String getDBPort() {
/* 47 */     return DB_PORT;
/*    */   }
/*    */ 
/*    */   public static synchronized String getDBName() {
/* 51 */     return DB_NAME;
/*    */   }
/*    */ 
/*    */   public static synchronized String getDBUser() {
/* 55 */     return DB_USER;
/*    */   }
/*    */ 
/*    */   public static synchronized String getDBPwd() {
/* 59 */     return DB_PWD;
/*    */   }
/*    */ 
/*    */   public static void setPeriod(String pd)
/*    */   {
/* 78 */     PERIOD = pd;
/* 79 */     PERIOD_YM = pd.substring(0, 6);
/* 80 */     PERIOD_Y = pd.substring(0, 4);
/* 81 */     PERIOD_M = pd.substring(4, 6);
/* 82 */     PERIOD_D = pd.substring(6, 8);
/* 83 */     PERIOD_Y_M_D = PERIOD_Y + "-" + PERIOD_M + "-" + PERIOD_D;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.BaseParam
 * JD-Core Version:    0.6.2
 */