/*    */ package com.bill.bean;
/*    */ 
/*    */ public class Foldout
/*    */ {
/*    */   private String id;
/*    */   private String name;
/*    */   private int weight;
/*    */   private int pri;
/*    */   private String state;
/*    */   private String idx;
/*    */ 
/*    */   public String getId()
/*    */   {
/* 32 */     return this.id;
/*    */   }
/*    */   public void setId(String id) {
/* 35 */     this.id = id;
/*    */   }
/*    */   public String getName() {
/* 38 */     return this.name;
/*    */   }
/*    */   public void setName(String name) {
/* 41 */     this.name = name;
/*    */   }
/*    */   public int getWeight() {
/* 44 */     return this.weight;
/*    */   }
/*    */   public void setWeight(int weight) {
/* 47 */     this.weight = weight;
/*    */   }
/*    */   public int getPri() {
/* 50 */     return this.pri;
/*    */   }
/*    */   public void setPri(int pri) {
/* 53 */     this.pri = pri;
/*    */   }
/*    */   public String getState() {
/* 56 */     return this.state;
/*    */   }
/*    */   public void setState(String state) {
/* 59 */     this.state = state;
/*    */   }
/*    */   public String getIdx() {
/* 62 */     return this.idx;
/*    */   }
/*    */   public void setIdx(String idx) {
/* 65 */     this.idx = idx;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.Foldout
 * JD-Core Version:    0.6.2
 */