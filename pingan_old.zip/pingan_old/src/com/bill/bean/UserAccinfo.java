/*     */ package com.bill.bean;
/*     */ 
/*     */ public class UserAccinfo
/*     */ {
/*     */   private String acctnbr;
/*     */   private String rectype;
/*     */   private String stmtdate;
/*     */   private String pmtdate;
/*     */   private String totbegbal;
/*     */   private String plantotpmt;
/*     */   private String plantotnrlamt;
/*     */   private String plantotadjamt;
/*     */   private String intdueamt;
/*     */   private String currbal;
/*     */   private String totdueamt;
/*     */   private String pmtprint;
/*     */   private String crlim;
/*     */   private String cashcrlim;
/*     */   private String pmtarn;
/*     */   private String pmtadn;
/*     */   private String projap;
/*     */   private String pmtaflag;
/*     */   private String achflag;
/*     */   private String pmtflag;
/*     */   private String filler;
/*     */ 
/*     */   public String getAcctnbr()
/*     */   {
/*  48 */     return this.acctnbr;
/*     */   }
/*     */   public void setAcctnbr(String acctnbr) {
/*  51 */     this.acctnbr = Util.check(acctnbr);
/*     */   }
/*     */   public String getRectype() {
/*  54 */     return this.rectype;
/*     */   }
/*     */   public void setRectype(String rectype) {
/*  57 */     this.rectype = Util.check(rectype);
/*     */   }
/*     */   public String getStmtdate() {
/*  60 */     return this.stmtdate;
/*     */   }
/*     */   public void setStmtdate(String stmtdate) {
/*  63 */     this.stmtdate = Util.check(stmtdate);
/*     */   }
/*     */   public String getPmtdate() {
/*  66 */     return this.pmtdate;
/*     */   }
/*     */   public void setPmtdate(String pmtdate) {
/*  69 */     this.pmtdate = Util.check(pmtdate);
/*     */   }
/*     */   public String getTotbegbal() {
/*  72 */     return this.totbegbal;
/*     */   }
/*     */   public void setTotbegbal(String totbegbal) {
/*  75 */     this.totbegbal = Util.check(totbegbal);
/*     */   }
/*     */   public String getPlantotpmt() {
/*  78 */     return this.plantotpmt;
/*     */   }
/*     */   public void setPlantotpmt(String plantotpmt) {
/*  81 */     this.plantotpmt = Util.check(plantotpmt);
/*     */   }
/*     */   public String getPlantotnrlamt() {
/*  84 */     return this.plantotnrlamt;
/*     */   }
/*     */   public void setPlantotnrlamt(String plantotnrlamt) {
/*  87 */     this.plantotnrlamt = Util.check(plantotnrlamt);
/*     */   }
/*     */   public String getPlantotadjamt() {
/*  90 */     return this.plantotadjamt;
/*     */   }
/*     */   public void setPlantotadjamt(String plantotadjamt) {
/*  93 */     this.plantotadjamt = Util.check(plantotadjamt);
/*     */   }
/*     */   public String getIntdueamt() {
/*  96 */     return this.intdueamt;
/*     */   }
/*     */   public void setIntdueamt(String intdueamt) {
/*  99 */     this.intdueamt = Util.check(intdueamt);
/*     */   }
/*     */   public String getCurrbal() {
/* 102 */     return this.currbal;
/*     */   }
/*     */   public void setCurrbal(String currbal) {
/* 105 */     this.currbal = Util.check(currbal);
/*     */   }
/*     */   public String getTotdueamt() {
/* 108 */     return this.totdueamt;
/*     */   }
/*     */   public void setTotdueamt(String totdueamt) {
/* 111 */     this.totdueamt = Util.check(totdueamt);
/*     */   }
/*     */   public String getPmtprint() {
/* 114 */     return this.pmtprint;
/*     */   }
/*     */   public void setPmtprint(String pmtprint) {
/* 117 */     this.pmtprint = Util.check(pmtprint);
/*     */   }
/*     */   public String getCrlim() {
/* 120 */     return this.crlim;
/*     */   }
/*     */   public void setCrlim(String crlim) {
/* 123 */     this.crlim = Util.check(crlim);
/*     */   }
/*     */   public String getCashcrlim() {
/* 126 */     return this.cashcrlim;
/*     */   }
/*     */   public void setCashcrlim(String cashcrlim) {
/* 129 */     this.cashcrlim = Util.check(cashcrlim);
/*     */   }
/*     */   public String getPmtarn() {
/* 132 */     return this.pmtarn;
/*     */   }
/*     */   public void setPmtarn(String pmtarn) {
/* 135 */     this.pmtarn = Util.check(pmtarn);
/*     */   }
/*     */   public String getPmtadn() {
/* 138 */     return this.pmtadn;
/*     */   }
/*     */   public void setPmtadn(String pmtadn) {
/* 141 */     this.pmtadn = Util.check(pmtadn);
/*     */   }
/*     */   public String getProjap() {
/* 144 */     return this.projap;
/*     */   }
/*     */   public void setProjap(String projap) {
/* 147 */     this.projap = Util.check(projap);
/*     */   }
/*     */   public String getPmtaflag() {
/* 150 */     return this.pmtaflag;
/*     */   }
/*     */   public void setPmtaflag(String pmtaflag) {
/* 153 */     this.pmtaflag = Util.check(pmtaflag);
/*     */   }
/*     */   public String getAchflag() {
/* 156 */     return this.achflag;
/*     */   }
/*     */   public void setAchflag(String achflag) {
/* 159 */     this.achflag = Util.check(achflag);
/*     */   }
/*     */   public String getPmtflag() {
/* 162 */     return this.pmtflag;
/*     */   }
/*     */   public void setPmtflag(String pmtflag) {
/* 165 */     this.pmtflag = Util.check(pmtflag);
/*     */   }
/*     */   public String getFiller() {
/* 168 */     return this.filler;
/*     */   }
/*     */   public void setFiller(String filler) {
/* 171 */     this.filler = Util.check(filler);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.UserAccinfo
 * JD-Core Version:    0.6.2
 */