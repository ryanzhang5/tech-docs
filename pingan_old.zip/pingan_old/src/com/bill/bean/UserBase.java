/*     */ package com.bill.bean;
/*     */ 
/*     */ public class UserBase
/*     */ {
/*     */   public String acctnbr;
/*     */   public String rectype;
/*     */   public String zip;
/*     */   public String addrname3;
/*     */   public String addrname1;
/*     */   public String addrname2;
/*     */   public String name;
/*     */   public String sex;
/*     */   public String birthday;
/*     */   public String accnum;
/*     */   public String cusnum;
/*     */   public String stfromdate;
/*     */   public String enddate;
/*     */   public String specode;
/*     */   public String pmtduemark;
/*     */   public String cashmark;
/*     */   public String indiv1;
/*     */   public String indiv2;
/*     */   public String indiv3;
/*     */   public String indiv4;
/*     */   public String indiv5;
/*     */   public String indiv6;
/*     */   public String indiv7;
/*     */   public String indiv8;
/*     */   public String actinfo;
/*     */   public String dm1;
/*     */   public String dm2;
/*     */   public String dm3;
/*     */   public String dm4;
/*     */   public String brandmsg1;
/*     */   public String brandmsg2;
/*     */   public String brandmsg3;
/*     */   public String brandmsg4;
/*     */   public String brandmsg5;
/*     */   public String brandmsg6;
/*     */   public String brandmsg7;
/*     */   public String convexchmark;
/*     */   public String vipmsg1;
/*     */   public String vipmsg2;
/*     */   public String vipmsg3;
/*     */   public String vipmsg4;
/*     */   public String reprintflag;
/*     */   public String emailflag;
/*     */   public String paperflag;
/*     */   public String emailaddr;
/*     */   public String custtype;
/*     */   public String mobilenbr;
/*     */   public String ainbr;
/*     */   public String mobdate;
/*     */   public String filler;
/*     */   public String city;
/*     */   public String cardNo;
/*     */   public String crlim;
/*     */   public String currbal;
/*     */   public String totdueamt;
/*     */   public String cashcrlim;
/*     */   public String stmtdate;
/*     */ 
/*     */   public String getAcctnbr()
/*     */   {
/* 134 */     return this.acctnbr;
/*     */   }
/*     */   public void setAcctnbr(String acctnbr) {
/* 137 */     this.acctnbr = Util.check(acctnbr);
/*     */   }
/*     */   public String getRectype() {
/* 140 */     return this.rectype;
/*     */   }
/*     */   public void setRectype(String rectype) {
/* 143 */     this.rectype = Util.check(rectype);
/*     */   }
/*     */   public String getZip() {
/* 146 */     return this.zip;
/*     */   }
/*     */   public void setZip(String zip) {
/* 149 */     this.zip = Util.check(zip);
/*     */   }
/*     */   public String getAddrname3() {
/* 152 */     return this.addrname3;
/*     */   }
/*     */   public void setAddrname3(String addrname3) {
/* 155 */     Util.check(addrname3);
/* 156 */     this.addrname3 = Util.check(addrname3);
/*     */   }
/*     */   public String getAddrname1() {
/* 159 */     return this.addrname1;
/*     */   }
/*     */   public void setAddrname1(String addrname1) {
/* 162 */     this.addrname1 = Util.check(addrname1);
/*     */   }
/*     */   public String getAddrname2() {
/* 165 */     return this.addrname2;
/*     */   }
/*     */   public void setAddrname2(String addrname2) {
/* 168 */     this.addrname2 = Util.check(addrname2);
/*     */   }
/*     */   public String getName() {
/* 171 */     return this.name;
/*     */   }
/*     */   public void setName(String name) {
/* 174 */     this.name = Util.check(name);
/*     */   }
/*     */   public String getSex() {
/* 177 */     return this.sex;
/*     */   }
/*     */   public void setSex(String sex) {
/* 180 */     this.sex = Util.check(sex);
/*     */   }
/*     */   public String getBirthday() {
/* 183 */     return this.birthday;
/*     */   }
/*     */   public void setBirthday(String birthday) {
/* 186 */     this.birthday = Util.check(birthday);
/*     */   }
/*     */   public String getAccnum() {
/* 189 */     return this.accnum;
/*     */   }
/*     */   public String getCusnum() {
/* 192 */     return this.cusnum;
/*     */   }
/*     */   public void setCusnum(String cusnum) {
/* 195 */     this.cusnum = Util.check(cusnum);
/*     */   }
/*     */   public String getStfromdate() {
/* 198 */     return this.stfromdate;
/*     */   }
/*     */   public void setStfromdate(String stfromdate) {
/* 201 */     this.stfromdate = Util.check(stfromdate);
/*     */   }
/*     */   public String getEnddate() {
/* 204 */     return this.enddate;
/*     */   }
/*     */   public void setEnddate(String enddate) {
/* 207 */     this.enddate = Util.check(enddate);
/*     */   }
/*     */   public String getSpecode() {
/* 210 */     return this.specode;
/*     */   }
/*     */   public void setSpecode(String specode) {
/* 213 */     this.specode = Util.check(specode);
/*     */   }
/*     */   public String getPmtduemark() {
/* 216 */     return this.pmtduemark;
/*     */   }
/*     */   public void setPmtduemark(String pmtduemark) {
/* 219 */     this.pmtduemark = Util.check(pmtduemark);
/*     */   }
/*     */   public String getCashmark() {
/* 222 */     return this.cashmark;
/*     */   }
/*     */   public void setCashmark(String cashmark) {
/* 225 */     this.cashmark = Util.check(cashmark);
/*     */   }
/*     */   public String getIndiv1() {
/* 228 */     return this.indiv1;
/*     */   }
/*     */   public void setIndiv1(String indiv1) {
/* 231 */     this.indiv1 = Util.check(indiv1);
/*     */   }
/*     */   public String getIndiv2() {
/* 234 */     return this.indiv2;
/*     */   }
/*     */   public void setIndiv2(String indiv2) {
/* 237 */     this.indiv2 = Util.check(indiv2);
/*     */   }
/*     */   public String getIndiv3() {
/* 240 */     return this.indiv3;
/*     */   }
/*     */   public void setIndiv3(String indiv3) {
/* 243 */     this.indiv3 = Util.check(indiv3);
/*     */   }
/*     */   public String getIndiv4() {
/* 246 */     return this.indiv4;
/*     */   }
/*     */   public void setIndiv4(String indiv4) {
/* 249 */     this.indiv4 = Util.check(indiv4);
/*     */   }
/*     */   public String getIndiv5() {
/* 252 */     return this.indiv5;
/*     */   }
/*     */   public void setIndiv5(String indiv5) {
/* 255 */     this.indiv5 = Util.check(indiv5);
/*     */   }
/*     */   public String getIndiv6() {
/* 258 */     return this.indiv6;
/*     */   }
/*     */   public void setIndiv6(String indiv6) {
/* 261 */     this.indiv6 = Util.check(indiv6);
/*     */   }
/*     */   public String getIndiv7() {
/* 264 */     return this.indiv7;
/*     */   }
/*     */   public void setIndiv7(String indiv7) {
/* 267 */     this.indiv7 = Util.check(indiv7);
/*     */   }
/*     */   public String getIndiv8() {
/* 270 */     return this.indiv8;
/*     */   }
/*     */   public void setIndiv8(String indiv8) {
/* 273 */     this.indiv8 = Util.check(indiv8);
/*     */   }
/*     */   public String getActinfo() {
/* 276 */     return this.actinfo;
/*     */   }
/*     */   public void setActinfo(String actinfo) {
/* 279 */     this.actinfo = Util.check(actinfo);
/*     */   }
/*     */   public String getDm1() {
/* 282 */     return this.dm1;
/*     */   }
/*     */   public void setDm1(String dm1) {
/* 285 */     this.dm1 = Util.check(dm1);
/*     */   }
/*     */   public String getDm2() {
/* 288 */     return this.dm2;
/*     */   }
/*     */   public void setDm2(String dm2) {
/* 291 */     this.dm2 = Util.check(dm2);
/*     */   }
/*     */   public String getDm3() {
/* 294 */     return this.dm3;
/*     */   }
/*     */   public void setDm3(String dm3) {
/* 297 */     this.dm3 = Util.check(dm3);
/*     */   }
/*     */   public String getDm4() {
/* 300 */     return this.dm4;
/*     */   }
/*     */   public void setDm4(String dm4) {
/* 303 */     this.dm4 = Util.check(dm4);
/*     */   }
/*     */   public String getBrandmsg1() {
/* 306 */     return this.brandmsg1;
/*     */   }
/*     */   public void setBrandmsg1(String brandmsg1) {
/* 309 */     this.brandmsg1 = Util.check(brandmsg1);
/*     */   }
/*     */   public String getBrandmsg2() {
/* 312 */     return this.brandmsg2;
/*     */   }
/*     */   public void setBrandmsg2(String brandmsg2) {
/* 315 */     this.brandmsg2 = Util.check(brandmsg2);
/*     */   }
/*     */   public String getBrandmsg3() {
/* 318 */     return this.brandmsg3;
/*     */   }
/*     */   public void setBrandmsg3(String brandmsg3) {
/* 321 */     this.brandmsg3 = Util.check(brandmsg3);
/*     */   }
/*     */   public String getBrandmsg4() {
/* 324 */     return this.brandmsg4;
/*     */   }
/*     */   public void setBrandmsg4(String brandmsg4) {
/* 327 */     this.brandmsg4 = Util.check(brandmsg4);
/*     */   }
/*     */   public String getBrandmsg5() {
/* 330 */     return this.brandmsg5;
/*     */   }
/*     */   public void setBrandmsg5(String brandmsg5) {
/* 333 */     this.brandmsg5 = Util.check(brandmsg5);
/*     */   }
/*     */   public String getBrandmsg6() {
/* 336 */     return this.brandmsg6;
/*     */   }
/*     */   public void setBrandmsg6(String brandmsg6) {
/* 339 */     this.brandmsg6 = Util.check(brandmsg6);
/*     */   }
/*     */   public String getBrandmsg7() {
/* 342 */     return this.brandmsg7;
/*     */   }
/*     */   public void setBrandmsg7(String brandmsg7) {
/* 345 */     this.brandmsg7 = Util.check(brandmsg7);
/*     */   }
/*     */   public String getConvexchmark() {
/* 348 */     return this.convexchmark;
/*     */   }
/*     */   public void setConvexchmark(String convexchmark) {
/* 351 */     this.convexchmark = Util.check(convexchmark);
/*     */   }
/*     */   public String getVipmsg1() {
/* 354 */     return this.vipmsg1;
/*     */   }
/*     */   public void setVipmsg1(String vipmsg1) {
/* 357 */     this.vipmsg1 = Util.check(vipmsg1);
/*     */   }
/*     */   public String getVipmsg2() {
/* 360 */     return this.vipmsg2;
/*     */   }
/*     */   public void setVipmsg2(String vipmsg2) {
/* 363 */     this.vipmsg2 = Util.check(vipmsg2);
/*     */   }
/*     */   public String getVipmsg3() {
/* 366 */     return this.vipmsg3;
/*     */   }
/*     */   public void setVipmsg3(String vipmsg3) {
/* 369 */     this.vipmsg3 = Util.check(vipmsg3);
/*     */   }
/*     */   public String getVipmsg4() {
/* 372 */     return this.vipmsg4;
/*     */   }
/*     */   public void setVipmsg4(String vipmsg4) {
/* 375 */     this.vipmsg4 = Util.check(vipmsg4);
/*     */   }
/*     */   public String getReprintflag() {
/* 378 */     return this.reprintflag;
/*     */   }
/*     */   public void setReprintflag(String reprintflag) {
/* 381 */     this.reprintflag = Util.check(reprintflag);
/*     */   }
/*     */   public String getEmailflag() {
/* 384 */     return this.emailflag;
/*     */   }
/*     */   public void setEmailflag(String emailflag) {
/* 387 */     this.emailflag = Util.check(emailflag);
/*     */   }
/*     */   public String getPaperflag() {
/* 390 */     return this.paperflag;
/*     */   }
/*     */   public void setPaperflag(String paperflag) {
/* 393 */     this.paperflag = Util.check(paperflag);
/*     */   }
/*     */   public String getEmailaddr() {
/* 396 */     return this.emailaddr;
/*     */   }
/*     */   public void setEmailaddr(String emailaddr) {
/* 399 */     this.emailaddr = Util.check(emailaddr);
/*     */   }
/*     */   public String getCusttype() {
/* 402 */     return this.custtype;
/*     */   }
/*     */   public void setCusttype(String custtype) {
/* 405 */     this.custtype = Util.check(custtype);
/*     */   }
/*     */   public String getMobilenbr() {
/* 408 */     return this.mobilenbr;
/*     */   }
/*     */   public void setMobilenbr(String mobilenbr) {
/* 411 */     this.mobilenbr = Util.check(mobilenbr);
/*     */   }
/*     */   public String getAinbr() {
/* 414 */     return this.ainbr;
/*     */   }
/*     */   public void setAinbr(String ainbr) {
/* 417 */     this.ainbr = Util.check(ainbr);
/*     */   }
/*     */   public String getMobdate() {
/* 420 */     return this.mobdate;
/*     */   }
/*     */   public void setMobdate(String mobdate) {
/* 423 */     this.mobdate = Util.check(mobdate);
/*     */   }
/*     */   public String getFiller() {
/* 426 */     return this.filler;
/*     */   }
/*     */   public void setFiller(String filler) {
/* 429 */     this.filler = Util.check(filler);
/*     */   }
/*     */   public void setAccnum(String accnum) {
/* 432 */     this.accnum = Util.check(accnum);
/*     */   }
/*     */   public String getCity() {
/* 435 */     return this.city;
/*     */   }
/*     */   public void setCity(String city) {
/* 438 */     this.city = Util.check(city);
/*     */   }
/*     */   public String getCrlim() {
/* 441 */     return this.crlim;
/*     */   }
/*     */   public void setCrlim(String crlim) {
/* 444 */     this.crlim = Util.check(crlim);
/*     */   }
/*     */   public String getCurrbal() {
/* 447 */     return this.currbal;
/*     */   }
/*     */   public void setCurrbal(String currbal) {
/* 450 */     this.currbal = Util.check(currbal);
/*     */   }
/*     */   public String getTotdueamt() {
/* 453 */     return this.totdueamt;
/*     */   }
/*     */   public void setTotdueamt(String totdueamt) {
/* 456 */     this.totdueamt = Util.check(totdueamt);
/*     */   }
/*     */   public String getCashcrlim() {
/* 459 */     return this.cashcrlim;
/*     */   }
/*     */   public void setCashcrlim(String cashcrlim) {
/* 462 */     this.cashcrlim = Util.check(cashcrlim);
/*     */   }
/*     */   public String getStmtdate() {
/* 465 */     return this.stmtdate;
/*     */   }
/*     */   public void setStmtdate(String stmtdate) {
/* 468 */     this.stmtdate = Util.check(stmtdate);
/*     */   }
/*     */   public String getCardNo() {
/* 471 */     return this.cardNo;
/*     */   }
/*     */   public void setCardNo(String cardNo) {
/* 474 */     this.cardNo = Util.check(cardNo);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.UserBase
 * JD-Core Version:    0.6.2
 */