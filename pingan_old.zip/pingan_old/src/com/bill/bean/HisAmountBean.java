/*     */ package com.bill.bean;
/*     */ 
/*     */ public class HisAmountBean
/*     */ {
/*  11 */   private String account = null;
/*  12 */   private String period = null;
/*  13 */   private String type = null;
/*  14 */   private String amount_1 = null;
/*  15 */   private String amount_2 = null;
/*  16 */   private String amount_3 = null;
/*  17 */   private String amount_4 = null;
/*  18 */   private String amount_5 = null;
/*  19 */   private String amount_6 = null;
/*  20 */   private String amount_7 = null;
/*  21 */   private String amount_8 = null;
/*  22 */   private String amount_9 = null;
/*  23 */   private String amount_10 = null;
/*  24 */   private String amount_11 = null;
/*  25 */   private String amount_12 = null;
/*     */ 
/*     */   public String getAmount(int months)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/*  34 */     String result = "";
/*  35 */     switch (months) {
/*     */     case 1:
/*  37 */       result = getAmount_1();
/*  38 */       break;
/*     */     case 2:
/*  40 */       result = getAmount_2();
/*  41 */       break;
/*     */     case 3:
/*  43 */       result = getAmount_3();
/*  44 */       break;
/*     */     case 4:
/*  46 */       result = getAmount_4();
/*  47 */       break;
/*     */     case 5:
/*  49 */       result = getAmount_5();
/*  50 */       break;
/*     */     case 6:
/*  52 */       result = getAmount_6();
/*  53 */       break;
/*     */     case 7:
/*  55 */       result = getAmount_7();
/*  56 */       break;
/*     */     case 8:
/*  58 */       result = getAmount_8();
/*  59 */       break;
/*     */     case 9:
/*  61 */       result = getAmount_9();
/*  62 */       break;
/*     */     case 10:
/*  64 */       result = getAmount_10();
/*  65 */       break;
/*     */     case 11:
/*  67 */       result = getAmount_11();
/*  68 */       break;
/*     */     case 12:
/*  70 */       result = getAmount_12();
/*  71 */       break;
/*     */     default:
/*  73 */       throw new IndexOutOfBoundsException("months parameter illegal. [1-12]");
/*     */     }
/*  75 */     return result;
/*     */   }
/*     */ 
/*     */   public void setAmount(int months, String value)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/*  85 */     switch (months) {
/*     */     case 1:
/*  87 */       setAmount_1(value);
/*  88 */       break;
/*     */     case 2:
/*  90 */       setAmount_2(value);
/*  91 */       break;
/*     */     case 3:
/*  93 */       setAmount_3(value);
/*  94 */       break;
/*     */     case 4:
/*  96 */       setAmount_4(value);
/*  97 */       break;
/*     */     case 5:
/*  99 */       setAmount_5(value);
/* 100 */       break;
/*     */     case 6:
/* 102 */       setAmount_6(value);
/* 103 */       break;
/*     */     case 7:
/* 105 */       setAmount_7(value);
/* 106 */       break;
/*     */     case 8:
/* 108 */       setAmount_8(value);
/* 109 */       break;
/*     */     case 9:
/* 111 */       setAmount_9(value);
/* 112 */       break;
/*     */     case 10:
/* 114 */       setAmount_10(value);
/* 115 */       break;
/*     */     case 11:
/* 117 */       setAmount_11(value);
/* 118 */       break;
/*     */     case 12:
/* 120 */       setAmount_12(value);
/* 121 */       break;
/*     */     default:
/* 123 */       throw new IndexOutOfBoundsException("months parameter illegal. [1-12]");
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getAccount()
/*     */   {
/* 129 */     return this.account;
/*     */   }
/*     */   public void setAccount(String account) {
/* 132 */     this.account = account;
/*     */   }
/*     */   public String getType() {
/* 135 */     return this.type;
/*     */   }
/*     */ 
/*     */   public void setType(String type) {
/* 139 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public String getPeriod() {
/* 143 */     return this.period;
/*     */   }
/*     */   public void setPeriod(String period) {
/* 146 */     this.period = period;
/*     */   }
/*     */ 
/*     */   private String getAmount_1() {
/* 150 */     return this.amount_1;
/*     */   }
/*     */   private void setAmount_1(String amount_1) {
/* 153 */     this.amount_1 = amount_1;
/*     */   }
/*     */ 
/*     */   private String getAmount_2() {
/* 157 */     return this.amount_2;
/*     */   }
/*     */   private void setAmount_2(String amount_2) {
/* 160 */     this.amount_2 = amount_2;
/*     */   }
/*     */   private String getAmount_3() {
/* 163 */     return this.amount_3;
/*     */   }
/*     */   private void setAmount_3(String amount_3) {
/* 166 */     this.amount_3 = amount_3;
/*     */   }
/*     */   private String getAmount_4() {
/* 169 */     return this.amount_4;
/*     */   }
/*     */   private void setAmount_4(String amount_4) {
/* 172 */     this.amount_4 = amount_4;
/*     */   }
/*     */   private String getAmount_5() {
/* 175 */     return this.amount_5;
/*     */   }
/*     */   private void setAmount_5(String amount_5) {
/* 178 */     this.amount_5 = amount_5;
/*     */   }
/*     */   private String getAmount_6() {
/* 181 */     return this.amount_6;
/*     */   }
/*     */   private void setAmount_6(String amount_6) {
/* 184 */     this.amount_6 = amount_6;
/*     */   }
/*     */   private String getAmount_7() {
/* 187 */     return this.amount_7;
/*     */   }
/*     */   private void setAmount_7(String amount_7) {
/* 190 */     this.amount_7 = amount_7;
/*     */   }
/*     */   private String getAmount_8() {
/* 193 */     return this.amount_8;
/*     */   }
/*     */   private void setAmount_8(String amount_8) {
/* 196 */     this.amount_8 = amount_8;
/*     */   }
/*     */   private String getAmount_9() {
/* 199 */     return this.amount_9;
/*     */   }
/*     */   private void setAmount_9(String amount_9) {
/* 202 */     this.amount_9 = amount_9;
/*     */   }
/*     */   private String getAmount_10() {
/* 205 */     return this.amount_10;
/*     */   }
/*     */   private void setAmount_10(String amount_10) {
/* 208 */     this.amount_10 = amount_10;
/*     */   }
/*     */   private String getAmount_11() {
/* 211 */     return this.amount_11;
/*     */   }
/*     */   private void setAmount_11(String amount_11) {
/* 214 */     this.amount_11 = amount_11;
/*     */   }
/*     */   private String getAmount_12() {
/* 217 */     return this.amount_12;
/*     */   }
/*     */   private void setAmount_12(String amount_12) {
/* 220 */     this.amount_12 = amount_12;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.HisAmountBean
 * JD-Core Version:    0.6.2
 */