/*    */ package com.bill.bean;
/*    */ 
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.net.URLEncoder;
/*    */ 
/*    */ public class Util
/*    */ {
/*    */   public static String changURL(String oldurl)
/*    */   {
/* 13 */     if ((oldurl != null) && (!"".equals(oldurl))) {
/* 14 */       int i = oldurl.indexOf("?");
/* 15 */       if (i != -1) {
/*    */         try {
/* 17 */           return oldurl.substring(0, i + 1) + URLEncoder.encode(oldurl.substring(i + 1), "UTF-8");
/*    */         } catch (UnsupportedEncodingException e) {
/* 19 */           e.printStackTrace();
/* 20 */           return "";
/*    */         }
/*    */       }
/*    */     }
/* 24 */     return oldurl;
/*    */   }
/*    */   public static String check(String input) {
/* 27 */     if ((input == null) || ("null".equals(input))) {
/* 28 */       return "";
/*    */     }
/* 30 */     return input.trim();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.Util
 * JD-Core Version:    0.6.2
 */