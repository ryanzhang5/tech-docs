/*    */ package com.bill.bean;
/*    */ 
/*    */ public class UserBuy
/*    */ {
/*    */   private String acctnbr;
/*    */   private String rectype;
/*    */   private String exchusdamt;
/*    */   private String sellrate;
/*    */   private String exchrmbamt;
/*    */   private String achrtnbr;
/*    */   private String achdbnbr;
/*    */   private String filler;
/*    */ 
/*    */   public String getAcctnbr()
/*    */   {
/* 22 */     return this.acctnbr;
/*    */   }
/*    */   public void setAcctnbr(String acctnbr) {
/* 25 */     this.acctnbr = Util.check(acctnbr);
/*    */   }
/*    */   public String getRectype() {
/* 28 */     return this.rectype;
/*    */   }
/*    */   public void setRectype(String rectype) {
/* 31 */     this.rectype = Util.check(rectype);
/*    */   }
/*    */   public String getExchusdamt() {
/* 34 */     return this.exchusdamt;
/*    */   }
/*    */   public void setExchusdamt(String exchusdamt) {
/* 37 */     this.exchusdamt = Util.check(exchusdamt);
/*    */   }
/*    */   public String getSellrate() {
/* 40 */     return this.sellrate;
/*    */   }
/*    */   public void setSellrate(String sellrate) {
/* 43 */     this.sellrate = Util.check(sellrate);
/*    */   }
/*    */   public String getExchrmbamt() {
/* 46 */     return this.exchrmbamt;
/*    */   }
/*    */   public void setExchrmbamt(String exchrmbamt) {
/* 49 */     this.exchrmbamt = Util.check(exchrmbamt);
/*    */   }
/*    */   public String getAchrtnbr() {
/* 52 */     return this.achrtnbr;
/*    */   }
/*    */   public void setAchrtnbr(String achrtnbr) {
/* 55 */     this.achrtnbr = Util.check(achrtnbr);
/*    */   }
/*    */   public String getAchdbnbr() {
/* 58 */     return this.achdbnbr;
/*    */   }
/*    */   public void setAchdbnbr(String achdbnbr) {
/* 61 */     this.achdbnbr = Util.check(achdbnbr);
/*    */   }
/*    */   public String getFiller() {
/* 64 */     return this.filler;
/*    */   }
/*    */   public void setFiller(String filler) {
/* 67 */     this.filler = Util.check(filler);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.UserBuy
 * JD-Core Version:    0.6.2
 */