/*    */ package com.bill.bean;
/*    */ 
/*    */ public class TempArea
/*    */ {
/*    */   private String area;
/*    */   private String type;
/*    */ 
/*    */   public String getArea()
/*    */   {
/*  7 */     return this.area;
/*    */   }
/*    */   public void setArea(String area) {
/* 10 */     this.area = area;
/*    */   }
/*    */   public String getType() {
/* 13 */     return this.type;
/*    */   }
/*    */   public void setType(String type) {
/* 16 */     this.type = type;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.TempArea
 * JD-Core Version:    0.6.2
 */