/*     */ package com.bill.reprintXML;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.db.DbConnectionForOracle;
/*     */ import com.bill.util.LogInit;
/*     */ import com.bill.util.config.ConfigReader;
/*     */ import java.io.File;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class CreateVF
/*     */ {
/*     */   private static Logger log;
/*     */ 
/*     */   public static void createVT(String[] args)
/*     */   {
/*  40 */     StringBuffer vf = new StringBuffer();
/*  41 */     String ftime = new SimpleDateFormat("yyyyMMddHHmmss").format(
/*  42 */       Long.valueOf(System.currentTimeMillis()));
/*  43 */     DecimalFormat df = new DecimalFormat("#");
/*  44 */     String YMD = ftime.substring(0, 8);
/*  45 */     String HMSC = ftime.substring(8, ftime.length()) + "00";
/*     */     try
/*     */     {
/*  48 */       ConfigReader.init();
/*  49 */       BaseParam.DB_IP = ConfigReader.read("db.ip");
/*  50 */       BaseParam.DB_PORT = ConfigReader.read("db.port");
/*  51 */       BaseParam.DB_NAME = ConfigReader.read("db.name");
/*  52 */       BaseParam.DB_USER = ConfigReader.read("db.user");
/*  53 */       BaseParam.DB_PWD = ConfigReader.read("db.pwd");
/*     */ 
/*  55 */       DbConnectionForOracle dbconn = new DbConnectionForOracle(BaseParam.DB_IP, 
/*  56 */         BaseParam.DB_PORT, BaseParam.DB_NAME, BaseParam.DB_USER, 
/*  57 */         BaseParam.DB_PWD);
/*     */ 
/*  60 */       PreparedStatement statement = dbconn.getConnection().prepareStatement(
/*  61 */         "select t.s_value,t.s_type from t_s_bill_para t");
/*  62 */       ResultSet result = statement.executeQuery();
/*  63 */       Map configMap = new HashMap();
/*  64 */       while (result.next())
/*     */       {
/*  66 */         configMap.put(result.getString("s_type"), result
/*  67 */           .getString("s_value"));
/*     */       }
/*     */ 
/*  70 */       LogInit.init((String)configMap.get("LOG4J_COFIG_PATH"), (String)configMap.get("LOG4J_FILENAME") + "Reprint_Create_V+.log");
/*  71 */       log = Logger.getLogger(CreateVF.class);
/*  72 */       statement.close();
/*  73 */       result.close();
/*  74 */       log.info("数据库构造配置完成，系统配置信息装载");
/*     */ 
/*  77 */       log.info("头记录数据拼装：");
/*  78 */       vf.append("00");
/*  79 */       vf.append(YMD);
/*  80 */       vf.append("00001");
/*  81 */       vf.append(HMSC);
/*  82 */       vf.append("00008389");
/*  83 */       for (int i = 0; i < 269; i++) {
/*  84 */         vf.append(" ");
/*     */       }
/*     */ 
/*  87 */       vf.append("\n");
/*     */ 
/*  89 */       log.info("明细记录数据拼装：");
/*     */ 
/*  91 */       StringBuffer sb = new StringBuffer();
/*  92 */       sb.append("SELECT   S_BUSINESS_ID,  S_PERIOD ,S_MAIL_TYPE FROM  ")
/*  93 */         .append(" t_b_reprint t  WHERE ").append(
/*  94 */         " t.S_APPLY_DATE  between ? and ? ").append(
/*  95 */         " and t.S_DEAL_RESULT='1' ").append(
/*  96 */         " and t.C_BUILDFLG='1'").append(
/*  97 */         " and t.S_PERIOD < ?");
/*     */ 
/*  99 */       statement = dbconn.getConnection().prepareStatement(sb.toString());
/*     */ 
/* 101 */       if (args == null) {
/* 102 */         Calendar cd = new GregorianCalendar();
/* 103 */         cd.setTime(new Date());
/* 104 */         cd.add(5, -1);
/* 105 */         String afterDay = new SimpleDateFormat("yyyy-MM-dd").format(cd.getTime());
/* 106 */         statement.setString(1, afterDay + " 00:00:00");
/* 107 */         statement.setString(2, afterDay + " 23:59:59");
/* 108 */         log.info("当前申请日期：" + afterDay);
/*     */ 
/* 110 */         Calendar c = new GregorianCalendar();
/* 111 */         c.setTime(new Date());
/* 112 */         c.add(2, -12);
/* 113 */         c.add(5, -1);
/* 114 */         String afterYear = new SimpleDateFormat("yyyyMMdd").format(c.getTime());
/* 115 */         statement.setString(3, afterYear);
/* 116 */         log.info("去年时间：" + afterYear);
/*     */       } else {
/* 118 */         Calendar cd = new GregorianCalendar();
/* 119 */         cd.setTime(new SimpleDateFormat("yyyy-MM-dd").parse(args[0]));
/* 120 */         cd.add(5, -1);
/* 121 */         String afterDay = new SimpleDateFormat("yyyy-MM-dd").format(cd.getTime());
/* 122 */         statement.setString(1, afterDay + " 00:00:00");
/* 123 */         statement.setString(2, afterDay + " 23:59:59");
/* 124 */         log.info("自定义申请日期：" + afterDay);
/*     */ 
/* 126 */         Calendar c = new GregorianCalendar();
/* 127 */         c.setTime(new SimpleDateFormat("yyyyMMdd").parse(args[1]));
/* 128 */         c.add(2, -12);
/* 129 */         c.add(5, -1);
/* 130 */         String afterYear = new SimpleDateFormat("yyyyMMdd").format(c.getTime());
/* 131 */         log.info("自定义去年时间：" + afterYear);
/* 132 */         statement.setString(3, afterYear);
/*     */       }
/* 134 */       log.info(sb.toString());
/*     */ 
/* 137 */       result = statement.executeQuery();
/* 138 */       int tranNum = 0;
/* 139 */       double sumMoney = 0.0D;
/* 140 */       String ISOM = "";
/* 141 */       String account = "";
/* 142 */       int addZ = 0;
/* 143 */       while (result.next()) {
/* 144 */         vf.append("50");
/*     */ 
/* 146 */         account = result.getString("S_BUSINESS_ID");
/* 147 */         addZ = 19 - account.length();
/* 148 */         for (int i = 0; i < addZ; i++) {
/* 149 */           account = "0" + account;
/*     */         }
/* 151 */         vf.append(account);
/*     */ 
/* 153 */         vf.append("0000000000000000000");
/* 154 */         vf.append(" ");
/* 155 */         vf.append("787");
/*     */ 
/* 157 */         if (result.getString("S_MAIL_TYPE").equals("3")) {
/* 158 */           ISOM = "1562D00000000000002000";
/* 159 */           sumMoney += 20.0D;
/*     */         } else {
/* 161 */           ISOM = "1562D00000000000001000";
/* 162 */           sumMoney += 10.0D;
/*     */         }
/* 164 */         vf.append(ISOM);
/* 165 */         vf.append(ISOM);
/*     */ 
/* 167 */         vf.append("1562D00000000000000000");
/* 168 */         vf.append(YMD);
/* 169 */         vf.append(HMSC);
/* 170 */         vf.append("000000000");
/* 171 */         for (int i = 0; i < 25; i++) {
/* 172 */           vf.append(" ");
/*     */         }
/* 174 */         for (int i = 0; i < 20; i++) {
/* 175 */           vf.append(" ");
/*     */         }
/* 177 */         vf.append("   ");
/*     */ 
/* 179 */         vf.append("00000");
/* 180 */         vf.append("0000");
/* 181 */         for (int i = 0; i < 30; i++) {
/* 182 */           vf.append(" ");
/*     */         }
/* 184 */         for (int i = 0; i < 23; i++) {
/* 185 */           vf.append(" ");
/*     */         }
/* 187 */         vf.append("      ");
/* 188 */         vf.append("000");
/* 189 */         vf.append("        ");
/* 190 */         vf.append("000000000000000");
/* 191 */         for (int i = 0; i < 20; i++) {
/* 192 */           vf.append(" ");
/*     */         }
/* 194 */         vf.append("   ");
/*     */ 
/* 196 */         vf.append("\n");
/* 197 */         tranNum++;
/*     */       }
/* 199 */       log.info("明细记录共有" + tranNum + "条！");
/* 200 */       statement.close();
/* 201 */       result.close();
/*     */ 
/* 203 */       log.info("尾记录数据拼装：");
/* 204 */       vf.append("99");
/* 205 */       vf.append(YMD);
/* 206 */       vf.append("00001");
/* 207 */       vf.append(HMSC);
/*     */ 
/* 209 */       String tranCode = String.valueOf(tranNum);
/* 210 */       int a0 = 9 - tranCode.length();
/* 211 */       for (int i = 0; i < a0; i++) {
/* 212 */         tranCode = "0" + tranCode;
/*     */       }
/* 214 */       vf.append(tranCode);
/*     */ 
/* 216 */       vf.append("000000000");
/*     */ 
/* 218 */       String tranMoney = df.format(sumMoney) + "00";
/* 219 */       int b0 = 17 - tranMoney.length();
/* 220 */       for (int i = 0; i < b0; i++) {
/* 221 */         tranMoney = "0" + tranMoney;
/*     */       }
/* 223 */       vf.append(tranMoney);
/*     */ 
/* 225 */       vf.append("00000000000000000");
/*     */ 
/* 227 */       vf.append(tranCode);
/*     */ 
/* 229 */       for (int i = 0; i < 216; i++) {
/* 230 */         vf.append(" ");
/*     */       }
/*     */ 
/* 234 */       log.info("生成文件");
/* 235 */       String path = (String)configMap.get("FTP_PATH");
/* 236 */       File file = new File(path + "FTP/V+");
/*     */ 
/* 238 */       if (!file.exists()) {
/* 239 */         file.mkdirs();
/*     */       }
/*     */ 
/* 242 */       file = new File(path + "FTP/V+/IBMS_SDB-VPLUS_" + YMD + "_001.txt");
/* 243 */       log.debug("生成V+文件：" + file.getPath());
/* 244 */       file.createNewFile();
/*     */ 
/* 246 */       RandomAccessFile filew = new RandomAccessFile(file.getPath(), "rw");
/* 247 */       filew.write(vf.toString().getBytes("utf-8"));
/*     */ 
/* 250 */       File fileck = new File(path + "FTP/V+/IBMS_SDB-VPLUS_" + YMD + "_001_CK.txt");
/* 251 */       log.debug("生成V+的CK文件：" + fileck.getPath());
/* 252 */       fileck.createNewFile();
/* 253 */       RandomAccessFile filewck = new RandomAccessFile(fileck.getPath(), "rw");
/* 254 */       StringBuffer sbck = new StringBuffer();
/* 255 */       sbck
/* 256 */         .append("SFILENAME=/paic/esgsintf/data/PABank_DCC/gettemp/").append(file.getName()).append("\n")
/* 258 */         .append("SNODENAME=CDPRD2\n")
/* 259 */         .append("SSHELLNAME=/wls/bank/bin/PACD_CallBack.sh?/paic/esgsintf/data/PABank_DCC/gettemp/").append(file.getName()).append("?IBMS_SDB-VPLUS?").append(YMD).append("?001\n")
/* 260 */         .append("PFILENAME=").append(file.getName());
/* 261 */       log.info("CK文件内容为：\n" + sbck.toString());
/* 262 */       filewck.write(sbck.toString().getBytes("utf-8"));
/* 263 */       filewck.close();
/* 264 */       filew.close();
/* 265 */       dbconn.close();
/*     */     } catch (Exception e) {
/* 267 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/* 272 */     if ((args != null) && (args.length > 0))
/* 273 */       createVT(args);
/*     */     else
/* 275 */       createVT(null);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.reprintXML.CreateVF
 * JD-Core Version:    0.6.2
 */