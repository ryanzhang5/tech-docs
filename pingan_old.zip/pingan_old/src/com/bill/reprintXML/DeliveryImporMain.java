/*    */ package com.bill.reprintXML;
/*    */ 
/*    */ import com.bill.util.LogInit;
/*    */ import com.bill.util.MyMain;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.PrintStream;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Calendar;
/*    */ import java.util.Date;
/*    */ import java.util.Map;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class DeliveryImporMain extends MyMain
/*    */ {
/* 21 */   private static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 26 */     System.out.println("##### Reprint Delivery Import start");
/*    */ 
/* 28 */     init();
/* 29 */     LogInit.init((String)config.get("LOG4J_COFIG_PATH"), 
/* 30 */       (String)config.get("LOG4J_FILENAME") + "delivery_import.log");
/* 31 */     log = Logger.getLogger(DeliveryImporMain.class);
/*    */ 
/* 33 */     File file = new File((String)config.get("reprint_delivery_path"));
/* 34 */     if (!file.exists()) {
/* 35 */       log.error("数据文件目录不存在！" + (String)config.get("reprint_delivery_path"));
/* 36 */       System.exit(-1);
/* 37 */       return;
/*    */     }
/*    */ 
/* 41 */     SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
/* 42 */     Date date = new Date();
/*    */ 
/* 44 */     Calendar calendar = Calendar.getInstance();
/* 45 */     calendar.setTime(date);
/* 46 */     calendar.add(5, -1);
/*    */ 
/* 48 */     String filename = "reprint_" + sdf.format(calendar.getTime());
/*    */ 
/* 50 */     log.info("数据文件 名！" + filename);
/* 51 */     file = new File((String)config.get("reprint_delivery_path") + filename);
/* 52 */     if (!file.exists()) {
/* 53 */       log.error("数据文件不存在!");
/* 54 */       System.exit(-1);
/* 55 */       return;
/*    */     }
/* 57 */     DBDao dao = new DBDao();
/*    */ 
/* 59 */     BufferedReader reader = null;
/* 60 */     String str = ""; String str3 = sdf2.format(calendar.getTime());
/* 61 */     String[] strs = (String[])null;
/* 62 */     int return_res = 0;
/*    */     try {
/* 64 */       reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
/* 65 */       dao.updateDeliveryNumBegin();
/* 66 */       while ((str = reader.readLine()) != null) {
/* 67 */         strs = str.split(",");
/* 68 */         if (2 != strs.length) {
/* 69 */           log.error("数据错误!" + str);
/*    */         }
/*    */         else {
/* 72 */           return_res = dao.updateDeliveryNum(strs[0], strs[1], str3);
/* 73 */           if (return_res == 0)
/* 74 */             log.error("update error:" + str);
/*    */         }
/*    */       }
/* 77 */       dao.updateDeliveryNumEnd();
/*    */     } catch (FileNotFoundException e) {
/* 79 */       e.printStackTrace();
/*    */     } catch (IOException e) {
/* 81 */       e.printStackTrace();
/*    */     }
/* 83 */     System.exit(0);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.reprintXML.DeliveryImporMain
 * JD-Core Version:    0.6.2
 */