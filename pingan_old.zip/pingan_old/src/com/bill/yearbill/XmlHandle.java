/*     */ package com.bill.yearbill;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class XmlHandle
/*     */ {
/*     */   public void user(Map<String, String> map, StringBuffer xml)
/*     */   {
/*   8 */     xml.append("<checksheet>\n");
/*   9 */     xml.append("<AccountNo>").append((String)map.get("AccountNo")).append("</AccountNo>\n");
/*  10 */     xml.append("<A001>A001邮寄地址信息</A001>\n");
/*  11 */     xml.append("<Zip>").append((String)map.get("Zip")).append("</Zip>\n");
/*  12 */     xml.append("<address1>").append((String)map.get("address1")).append("</address1>\n");
/*  13 */     xml.append("<address2>").append((String)map.get("address2")).append("</address2>\n");
/*  14 */     xml.append("<address3>").append((String)map.get("address3")).append("</address3>\n");
/*  15 */     xml.append("<Name>").append((String)map.get("Name")).append("</Name>\n");
/*  16 */     xml.append("<Sex>").append((String)map.get("Sex")).append("</Sex>\n");
/*  17 */     xml.append("<Special>").append(map.get("Special") == null ? "" : (String)map.get("Special")).append("</Special>\n");
/*  18 */     xml.append("<Rmbforyear>").append((String)map.get("Rmbforyear")).append("</Rmbforyear>\n");
/*  19 */     xml.append("<Usdforyear>").append((String)map.get("Usdforyear")).append("</Usdforyear>\n");
/*  20 */     xml.append("<totalforyear>").append((String)map.get("totalforyear")).append("</totalforyear>\n");
/*     */   }
/*     */ 
/*     */   public void monthly(List<Map<String, String>> list, StringBuffer xml) {
/*  24 */     String title = "";
/*  25 */     String type = "";
/*  26 */     for (Map map : list) {
/*  27 */       type = (String)map.get("type");
/*  28 */       if ("B001".equals(type))
/*  29 */         title = "B001每月人民币交易金";
/*  30 */       else if ("B002".equals(map.get("type")))
/*  31 */         title = "B002每月美元交易金";
/*  32 */       else if ("B003".equals(map.get("type")))
/*  33 */         title = "B003每月交易金额";
/*  34 */       else if ("B004".equals(map.get("type"))) {
/*  35 */         title = "B004每月交易占比";
/*     */       }
/*  37 */       xml.append("<").append(type).append(">\n");
/*  38 */       xml.append("<Title>").append(title).append("</Title>\n");
/*  39 */       xml.append("<Jan>").append((String)map.get("Jan")).append("</Jan>\n");
/*  40 */       xml.append("<Feb>").append((String)map.get("Feb")).append("</Feb>\n");
/*  41 */       xml.append("<Mar>").append((String)map.get("Mar")).append("</Mar>\n");
/*  42 */       xml.append("<Apr>").append((String)map.get("Apr")).append("</Apr>\n");
/*  43 */       xml.append("<May>").append((String)map.get("May")).append("</May>\n");
/*  44 */       xml.append("<Jun>").append((String)map.get("Jun")).append("</Jun>\n");
/*  45 */       xml.append("<Jul>").append((String)map.get("Jul")).append("</Jul>\n");
/*  46 */       xml.append("<Aug>").append((String)map.get("Aug")).append("</Aug>\n");
/*  47 */       xml.append("<Sep>").append((String)map.get("Sep")).append("</Sep>\n");
/*  48 */       xml.append("<Oct>").append((String)map.get("Oct")).append("</Oct>\n");
/*  49 */       xml.append("<Nov>").append((String)map.get("Nov")).append("</Nov>\n");
/*  50 */       xml.append("<Dec>").append((String)map.get("Dec")).append("</Dec>\n");
/*  51 */       xml.append("</").append(type).append(">\n");
/*     */     }
/*     */   }
/*     */ 
/*  55 */   public void detail(List<Map<String, String>> list, StringBuffer xml) { String type = "";
/*  56 */     for (Map map : list) {
/*  57 */       type = (String)map.get("type");
/*  58 */       xml.append("<").append(type).append(">\n");
/*  59 */       if (("C001".equals(type)) || ("C011".equals(type))) {
/*  60 */         if ("C001".equals(type))
/*  61 */           xml.append("<Title>C001购物消费人民币交易金额</Title>\n");
/*  62 */         else if ("C011".equals(type)) {
/*  63 */           xml.append("<Title>C011购物消费美元交易金额</Title>\n");
/*     */         }
/*  65 */         xml.append("<ShopingCost>").append((String)map.get("cost1")).append("</ShopingCost>\n");
/*  66 */         xml.append("<SupermarketCost>").append((String)map.get("cost2")).append("</SupermarketCost>\n");
/*  67 */         xml.append("<FoodCost>").append((String)map.get("cost3")).append("</FoodCost>\n");
/*  68 */         xml.append("<DressCost>").append((String)map.get("cost4")).append("</DressCost>\n");
/*  69 */         xml.append("<HouseholdCost>").append((String)map.get("cost5")).append("</HouseholdCost>\n");
/*  70 */         xml.append("<HousingCost>").append((String)map.get("cost6")).append("</HousingCost>\n");
/*  71 */         xml.append("<othershopingCost>").append((String)map.get("cost7")).append("</othershopingCost>\n");
/*     */       }
/*  73 */       else if (("C002".equals(type)) || ("C012".equals(type))) {
/*  74 */         if ("C002".equals(type))
/*  75 */           xml.append("<Title>C002休闲旅游人民币交易金额</Title>\n");
/*  76 */         else if ("C012".equals(type)) {
/*  77 */           xml.append("<Title>C012休闲旅游美元交易金额</Title>\n");
/*     */         }
/*  79 */         xml.append("<RelexationCost>").append((String)map.get("cost1")).append("</RelexationCost>\n");
/*  80 */         xml.append("<HotelCost>").append((String)map.get("cost2")).append("</HotelCost>\n");
/*  81 */         xml.append("<EntertainmentCost>").append((String)map.get("cost3")).append("</EntertainmentCost>\n");
/*  82 */         xml.append("<VoyageCost>").append((String)map.get("cost4")).append("</VoyageCost>\n");
/*     */       }
/*  84 */       else if (("C003".equals(type)) || ("C013".equals(type))) {
/*  85 */         if ("C003".equals(type))
/*  86 */           xml.append("<Title>C003交通运输人民币交易金额</Title>\n");
/*  87 */         else if ("C013".equals(type)) {
/*  88 */           xml.append("<Title>C013交通运输美元交易金额</Title>\n");
/*     */         }
/*  90 */         xml.append("<TransportationCost>").append((String)map.get("cost1")).append("</TransportationCost>\n");
/*  91 */         xml.append("<OilCost>").append((String)map.get("cost2")).append("</OilCost>\n");
/*  92 */         xml.append("<MasstransitCost>").append((String)map.get("cost3")).append("</MasstransitCost>\n");
/*  93 */         xml.append("<VehicleserviceCost>").append((String)map.get("cost4")).append("</VehicleserviceCost>\n");
/*     */       }
/*  95 */       else if (("C004".equals(type)) || ("C014".equals(type))) {
/*  96 */         if ("C004".equals(type))
/*  97 */           xml.append("<Title>C004家庭服务人民币交易金额</Title>\n");
/*  98 */         else if ("C014".equals(type)) {
/*  99 */           xml.append("<Title>C014家庭服务美元交易金额</Title>\n");
/*     */         }
/* 101 */         xml.append("<FamilyServiceCost>").append((String)map.get("cost1")).append("</FamilyServiceCost>\n");
/* 102 */         xml.append("<UtilitiesCost>").append((String)map.get("cost2")).append("</UtilitiesCost>\n");
/* 103 */         xml.append("<EducationCost>").append((String)map.get("cost3")).append("</EducationCost>\n");
/* 104 */         xml.append("<healtyCost>").append((String)map.get("cost4")).append("</healtyCost>\n");
/* 105 */         xml.append("<HouseholdServiceCost>").append((String)map.get("cost5")).append("</HouseholdServiceCost>\n");
/* 106 */         xml.append("<SocialserviceCost>").append((String)map.get("cost6")).append("</SocialserviceCost>\n");
/*     */       }
/* 108 */       else if (("C005".equals(type)) || ("C015".equals(type))) {
/* 109 */         if ("C005".equals(type))
/* 110 */           xml.append("<Title>C005金融服务人民币交易金额</Title>\n");
/* 111 */         else if ("C015".equals(type)) {
/* 112 */           xml.append("<Title>C015金融服务美元交易金额</Title>\n");
/*     */         }
/* 114 */         xml.append("<FinacialserviceCost>").append((String)map.get("cost1")).append("</FinacialserviceCost>\n");
/* 115 */         xml.append("<InsuranceCost>").append((String)map.get("cost2")).append("</InsuranceCost>\n");
/* 116 */         xml.append("<OtherCost>").append((String)map.get("cost3")).append("</OtherCost>\n");
/*     */       }
/* 118 */       else if (("C006".equals(type)) || ("C016".equals(type))) {
/* 119 */         if ("C006".equals(type))
/* 120 */           xml.append("<Title>C006其它商户人民币交易金额</Title>\n");
/* 121 */         else if ("C016".equals(type)) {
/* 122 */           xml.append("<Title>C016其它商户美元交易金额</Title>\n");
/*     */         }
/* 124 */         xml.append("<otherCost>").append((String)map.get("cost1")).append("</otherCost>\n");
/*     */       }
/* 126 */       else if ("C021".equals(type)) {
/* 127 */         xml.append("<Title>C021购物消费</Title>\n");
/* 128 */         xml.append("<ShopingCost>").append((String)map.get("cost1")).append("</ShopingCost>\n");
/* 129 */         xml.append("<ShopingPer>").append((String)map.get("cost8")).append("</ShopingPer>\n");
/* 130 */         xml.append("<SupermarketCost>").append((String)map.get("cost2")).append("</SupermarketCost>\n");
/* 131 */         xml.append("<FoodCost>").append((String)map.get("cost3")).append("</FoodCost>\n");
/* 132 */         xml.append("<DressCost>").append((String)map.get("cost4")).append("</DressCost>\n");
/* 133 */         xml.append("<HouseholdCost>").append((String)map.get("cost5")).append("</HouseholdCost>\n");
/* 134 */         xml.append("<HousingCost>").append((String)map.get("cost6")).append("</HousingCost>\n");
/* 135 */         xml.append("<othershopingCost>").append((String)map.get("cost7")).append("</othershopingCost>\n");
/*     */       }
/* 137 */       else if ("C022".equals(type)) {
/* 138 */         xml.append("<Title>C022休闲旅游</Title>\n");
/* 139 */         xml.append("<RelexationCost>").append((String)map.get("cost1")).append("</RelexationCost>\n");
/* 140 */         xml.append("<RelexationPer>").append((String)map.get("cost8")).append("</RelexationPer>\n");
/* 141 */         xml.append("<HotelCost>").append((String)map.get("cost2")).append("</HotelCost>\n");
/* 142 */         xml.append("<EntertainmentCost>").append((String)map.get("cost3")).append("</EntertainmentCost>\n");
/* 143 */         xml.append("<VoyageCost>").append((String)map.get("cost4")).append("</VoyageCost>\n");
/*     */       }
/* 145 */       else if ("C023".equals(type)) {
/* 146 */         xml.append("<Title>C023交通运输 </Title>\n");
/* 147 */         xml.append("<TransportationCost>").append((String)map.get("cost1")).append("</TransportationCost>\n");
/* 148 */         xml.append("<TransportationPer>").append((String)map.get("cost8")).append("</TransportationPer>\n");
/* 149 */         xml.append("<OilCost>").append((String)map.get("cost2")).append("</OilCost>\n");
/* 150 */         xml.append("<MasstransitCost>").append((String)map.get("cost3")).append("</MasstransitCost>\n");
/* 151 */         xml.append("<VehicleserviceCost>").append((String)map.get("cost4")).append("</VehicleserviceCost>\n");
/*     */       }
/* 153 */       else if ("C024".equals(type)) {
/* 154 */         xml.append("<Title>C024家庭服务 </Title>\n");
/* 155 */         xml.append("<FamilyServiceCost>").append((String)map.get("cost1")).append("</FamilyServiceCost>\n");
/* 156 */         xml.append("<FamilyServicePer>").append((String)map.get("cost8")).append("</FamilyServicePer>\n");
/* 157 */         xml.append("<UtilitiesCost>").append((String)map.get("cost2")).append("</UtilitiesCost>\n");
/* 158 */         xml.append("<EducationCost>").append((String)map.get("cost3")).append("</EducationCost>\n");
/* 159 */         xml.append("<healtyCost>").append((String)map.get("cost4")).append("</healtyCost>\n");
/* 160 */         xml.append("<HouseholdServiceCost>").append((String)map.get("cost5")).append("</HouseholdServiceCost>\n");
/* 161 */         xml.append("<SocialserviceCost>").append((String)map.get("cost6")).append("</SocialserviceCost>\n");
/*     */       }
/* 163 */       else if ("C025".equals(type)) {
/* 164 */         xml.append("<Title>C025金融服务 </Title>\n");
/* 165 */         xml.append("<FinacialserviceCost>").append((String)map.get("cost1")).append("</FinacialserviceCost>\n");
/* 166 */         xml.append("<FinacialservicePer>").append((String)map.get("cost8")).append("</FinacialservicePer>\n");
/* 167 */         xml.append("<InsuranceCost>").append((String)map.get("cost2")).append("</InsuranceCost>\n");
/* 168 */         xml.append("<OtherCost>").append((String)map.get("cost3")).append("</OtherCost>\n");
/*     */       }
/* 170 */       else if ("C026".equals(type)) {
/* 171 */         xml.append("<Title>C026其他商户</Title>\n");
/* 172 */         xml.append("<OtherCost>").append((String)map.get("cost1")).append("</OtherCost>\n");
/* 173 */         xml.append("<OtherPer>").append((String)map.get("cost8")).append("</OtherPer>\n");
/*     */       }
/* 175 */       xml.append("</").append(type).append(">\n");
/*     */     } }
/*     */ 
/*     */   public void total(List<Map<String, String>> list, StringBuffer xml)
/*     */   {
/* 180 */     String type = "";
/* 181 */     for (Map map : list) {
/* 182 */       type = (String)map.get("type");
/* 183 */       xml.append("<").append(type).append(">\n");
/* 184 */       if ("D001".equals(type)) {
/* 185 */         xml.append("<Title>D001一般消费</Title>\n");
/* 186 */         xml.append("<RmbTransaction>").append((String)map.get("cost1")).append("</RmbTransaction>\n");
/* 187 */         xml.append("<UsdTransaction>").append((String)map.get("cost2")).append("</UsdTransaction>\n");
/* 188 */         xml.append("<NormalCost>").append((String)map.get("cost3")).append("</NormalCost>\n");
/* 189 */         xml.append("<NormalPer>").append((String)map.get("cost4")).append("</NormalPer>\n");
/*     */       }
/* 191 */       else if ("D002".equals(type)) {
/* 192 */         xml.append("<Title>D002取现</Title>\n");
/* 193 */         xml.append("<RmbTransaction>").append((String)map.get("cost1")).append("</RmbTransaction>\n");
/* 194 */         xml.append("<UsdTransaction>").append((String)map.get("cost2")).append("</UsdTransaction>\n");
/* 195 */         xml.append("<TotalCash>").append((String)map.get("cost3")).append("</TotalCash>\n");
/* 196 */         xml.append("<CashPer>").append((String)map.get("cost4")).append("</CashPer>\n");
/*     */       }
/* 198 */       else if ("D003".equals(type)) {
/* 199 */         xml.append("<Title>D003邮购</Title>\n");
/* 200 */         xml.append("<RmbTransaction>").append((String)map.get("cost1")).append("</RmbTransaction>\n");
/* 201 */         xml.append("<UsdTransaction>").append((String)map.get("cost2")).append("</UsdTransaction>\n");
/* 202 */         xml.append("<Mailorder>").append((String)map.get("cost3")).append("</Mailorder>\n");
/* 203 */         xml.append("<MailorderPer>").append((String)map.get("cost4")).append("</MailorderPer>\n");
/*     */       }
/* 205 */       xml.append("</").append(type).append(">\n");
/*     */     }
/*     */   }
/*     */ 
/* 209 */   public void point(String credit, StringBuffer xml) { xml.append("<F001>\n");
/* 210 */     xml.append("<Title>F001万里通积分信息</Title>\n");
/* 211 */     xml.append("<CreditcardPoint>").append(credit).append("</CreditcardPoint>\n");
/* 212 */     xml.append("</F001>\n");
/* 213 */     xml.append("</checksheet>\n");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.yearbill.XmlHandle
 * JD-Core Version:    0.6.2
 */