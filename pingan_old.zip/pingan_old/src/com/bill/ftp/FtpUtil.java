/*     */ package com.bill.ftp;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import org.apache.commons.net.ftp.FTPClient;
/*     */ import org.apache.commons.net.ftp.FTPFile;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class FtpUtil
/*     */ {
/*  25 */   private static Logger log = Logger.getLogger(FtpUtil.class);
/*     */ 
/*  27 */   private FTPClient client = null;
/*  28 */   private String ip = null;
/*  29 */   private int port = 21;
/*  30 */   private String userName = null;
/*  31 */   private String password = null;
/*     */ 
/*     */   public FtpUtil(String ip, int port, String userName, String password) {
/*  34 */     this.ip = ip;
/*  35 */     this.port = port;
/*  36 */     this.userName = userName;
/*  37 */     this.password = password;
/*     */   }
/*     */ 
/*     */   public boolean connection()
/*     */   {
/*  44 */     boolean result = false;
/*     */     try {
/*  46 */       this.client = new FTPClient();
/*  47 */       this.client.connect(this.ip, this.port);
/*  48 */       result = this.client.login(this.userName, this.password);
/*     */     } catch (Throwable t) {
/*     */       try {
/*  51 */         if (this.client != null)
/*  52 */           this.client.disconnect();
/*     */       }
/*     */       catch (Throwable tClose) {
/*  55 */         log.error("ftp connect error", tClose);
/*     */       }
/*     */     }
/*  58 */     return result;
/*     */   }
/*     */ 
/*     */   public void closeConn()
/*     */   {
/*     */     try
/*     */     {
/*  67 */       if ((this.client != null) && (this.client.isConnected())) {
/*  68 */         this.client.disconnect();
/*  69 */         this.client = null;
/*  70 */         log.debug("ftp disconnect success.");
/*     */       }
/*     */     } catch (Throwable t) {
/*  73 */       log.error("ftp close error", t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean upload(String ftpFilePath, String newFileName, String path)
/*     */     throws Exception
/*     */   {
/*  86 */     log.debug("file upload start, " + ftpFilePath);
/*     */ 
/*  88 */     boolean result = true;
/*  89 */     InputStream input = null;
/*     */     try {
/*  91 */       String name = "";
/*  92 */       if ((newFileName != null) && (newFileName.length() > 0))
/*  93 */         name = getFileName(newFileName);
/*     */       else {
/*  95 */         name = getFileName(ftpFilePath);
/*     */       }
/*  97 */       if (name == null) {
/*  98 */         log.error("�ϴ��ļ����Ϊ��");
/*  99 */         throw new Exception("�ϴ��ļ����Ϊ��");
/*     */       }
/*     */ 
/* 102 */       log.debug("file from " + 
/* 103 */         ftpFilePath + 
/* 104 */         ", upload to " + 
/* 105 */         path);
/*     */ 
/* 107 */       if (path != null) {
/* 108 */         this.client.changeWorkingDirectory(path);
/*     */       }
/* 110 */       this.client.setFileType(2);
/* 111 */       this.client.enterLocalPassiveMode();
/* 112 */       this.client.setFileTransferMode(10);
/* 113 */       input = new FileInputStream(new File(ftpFilePath));
/* 114 */       result = this.client.storeFile(name, input);
/*     */ 
/* 116 */       log.info(result + ", <==result, file upload finish, " + ftpFilePath);
/* 117 */       return result;
/*     */     }
/*     */     catch (Throwable t) {
/* 120 */       throw new Exception(t);
/*     */     } finally {
/*     */       try {
/* 123 */         if (input != null)
/* 124 */           input.close();
/*     */       }
/*     */       catch (Exception eClose) {
/* 127 */         log.error("ftp input stream close error", eClose);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean downloadFile(String downloadDir, String fileName, String path)
/*     */     throws Exception
/*     */   {
/* 142 */     log.debug("ftp download start");
/* 143 */     log.debug("downloadDir=" + downloadDir + ", fileName=" + fileName + ", path=" + path);
/*     */ 
/* 145 */     boolean result = false;
/* 146 */     BufferedOutputStream bos = null;
/* 147 */     FileOutputStream fos = null;
/* 148 */     File file = null;
/*     */     try
/*     */     {
/* 151 */       if (fileName == null) {
/* 152 */         log.error("fileName is null!");
/* 153 */         throw new Exception("fileName is null!");
/*     */       }
/*     */ 
/* 156 */       file = new File(downloadDir + fileName);
/* 157 */       if (!file.exists()) {
/* 158 */         file.getParentFile().mkdirs();
/*     */       }
/* 160 */       fos = new FileOutputStream(file);
/* 161 */       bos = new BufferedOutputStream(fos);
/*     */ 
/* 163 */       log.debug("ftp get file:" + path + fileName + "  to  " + downloadDir + fileName + "  begin......");
/* 164 */       result = this.client.retrieveFile(path + fileName, bos);
/*     */ 
/* 166 */       log.debug("ftp download finish");
/* 167 */       return result;
/*     */     }
/*     */     catch (Throwable t) {
/*     */       try {
/* 171 */         File fileTemp = new File(downloadDir + fileName);
/* 172 */         if (fileTemp.exists())
/* 173 */           fileTemp.delete();
/*     */       }
/*     */       catch (Exception eDelFile) {
/* 176 */         log.error("download error, del file fail", eDelFile);
/*     */       }
/* 178 */       throw new Exception(t);
/*     */     }
/*     */     finally {
/*     */       try {
/* 182 */         if (bos != null)
/* 183 */           bos.close();
/*     */       }
/*     */       catch (IOException eClose) {
/* 186 */         log.error("ftp output stream close error", eClose);
/*     */       }
/*     */       try {
/* 189 */         if (fos != null)
/* 190 */           fos.close();
/*     */       }
/*     */       catch (IOException eClose) {
/* 193 */         log.error("ftp output stream close error", eClose);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean deleteFile(String fileName, String path)
/*     */     throws Exception
/*     */   {
/* 205 */     boolean result = false;
/*     */     try {
/* 207 */       return this.client.deleteFile(path + fileName);
/*     */     }
/*     */     catch (Throwable t) {
/* 210 */       throw new Exception(t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean deleteDirectory(String dirName, String path)
/*     */     throws Exception
/*     */   {
/* 224 */     boolean result = false;
/*     */     try {
/* 226 */       return this.client.removeDirectory(path + dirName);
/*     */     }
/*     */     catch (Throwable t) {
/* 229 */       log.error(t);
/* 230 */       throw new Exception(t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ArrayList<String> getFileList(String path, String extName)
/*     */     throws Exception
/*     */   {
/* 243 */     FTPFile[] ftpFiles = (FTPFile[])null;
/* 244 */     ArrayList retList = null;
/*     */     try
/*     */     {
/* 247 */       ftpFiles = this.client.listFiles(path);
/* 248 */       retList = new ArrayList();
/* 249 */       if ((ftpFiles == null) || (ftpFiles.length == 0)) {
/* 250 */         return retList;
/*     */       }
/*     */ 
/* 253 */       for (int i = 0; i < ftpFiles.length; i++) {
/* 254 */         FTPFile ftpFile = ftpFiles[i];
/* 255 */         if (ftpFile.isFile()) {
/* 256 */           String ext = getFileExtName(ftpFile.getName());
/* 257 */           if (extName.equals(ext)) {
/* 258 */             retList.add(ftpFile.getName());
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 263 */       return retList;
/*     */     }
/*     */     catch (Throwable t) {
/* 266 */       log.error(t);
/* 267 */       throw new Exception(t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ArrayList<String> getFileList(String path, String prefixName, String postfixName)
/*     */     throws Throwable
/*     */   {
/* 281 */     log.debug("scan ftp file, path is: " + path + ", " + "prefix name is: " + prefixName + ", postfix name is: " + postfixName);
/* 282 */     FTPFile[] ftpFiles = (FTPFile[])null;
/* 283 */     ArrayList retList = null;
/*     */     try
/*     */     {
/* 286 */       ftpFiles = this.client.listFiles(path);
/* 287 */       log.debug(Integer.valueOf(ftpFiles.length));
/* 288 */       retList = new ArrayList();
/* 289 */       if ((ftpFiles == null) || (ftpFiles.length == 0)) {
/* 290 */         return retList;
/*     */       }
/* 292 */       String fileName = null;
/* 293 */       FTPFile ftpFile = null;
/*     */ 
/* 295 */       for (int i = 0; i < ftpFiles.length; i++) {
/* 296 */         ftpFile = ftpFiles[i];
/* 297 */         if (ftpFile.isFile()) {
/* 298 */           fileName = ftpFile.getName();
/* 299 */           if ((fileName.startsWith(prefixName)) && (fileName.endsWith(postfixName))) {
/* 300 */             log.debug("fileName:" + fileName);
/* 301 */             log.debug(i + ", get list " + path + fileName);
/*     */ 
/* 303 */             retList.add(fileName);
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 309 */       return retList;
/*     */     } catch (Throwable t) {
/* 311 */       log.error(t);
/* 312 */       throw t;
/*     */     }
/*     */   }
/*     */ 
/*     */   public ArrayList<String> getFileListByName(String path, String fileName)
/*     */     throws Exception
/*     */   {
/* 324 */     FTPFile[] ftpFiles = (FTPFile[])null;
/* 325 */     ArrayList retList = null;
/*     */     try
/*     */     {
/* 328 */       ftpFiles = this.client.listFiles(path);
/* 329 */       retList = new ArrayList();
/* 330 */       if ((ftpFiles == null) || (ftpFiles.length == 0)) {
/* 331 */         return retList;
/*     */       }
/*     */ 
/* 334 */       FTPFile ftpFile = null;
/* 335 */       String name = null;
/* 336 */       for (int i = 0; i < ftpFiles.length; i++) {
/* 337 */         ftpFile = ftpFiles[i];
/* 338 */         if (ftpFile.isFile()) {
/* 339 */           name = ftpFile.getName();
/* 340 */           if (fileName.equals(name)) {
/* 341 */             retList.add(name);
/*     */           }
/*     */         }
/*     */       }
/* 345 */       return retList;
/*     */     } catch (Throwable t) {
/* 347 */       log.error(t);
/* 348 */       throw new Exception(t);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static String getFileExtName(String filePath)
/*     */   {
/* 358 */     return filePath.substring(filePath.lastIndexOf(".") + 1);
/*     */   }
/*     */ 
/*     */   public static String getFileName(String pathName)
/*     */   {
/* 377 */     int index1 = pathName.lastIndexOf('/');
/* 378 */     int index2 = pathName.lastIndexOf("\\");
/* 379 */     int index = index1 >= index2 ? index1 : index2;
/* 380 */     return pathName.substring(index + 1);
/*     */   }
/*     */ 
/*     */   public static String getExtName(String pathName)
/*     */   {
/* 389 */     int index1 = pathName.lastIndexOf('/');
/* 390 */     int index2 = pathName.lastIndexOf("\\");
/* 391 */     int index = index1 >= index2 ? index1 : index2;
/* 392 */     return pathName.substring(index - 3);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.ftp.FtpUtil
 * JD-Core Version:    0.6.2
 */