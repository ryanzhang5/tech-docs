/*     */ package com.bill.normal;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.bean.Card;
/*     */ import com.bill.make.Common;
/*     */ import com.bill.make.ThreadSleeper;
/*     */ import com.bill.util.FileUtil;
/*     */ import com.bill.util.LogInit;
/*     */ import com.bill.util.config.ConfigReader;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class ComposeXml
/*     */ {
/*  37 */   private static Logger log = Logger.getLogger(ComposeXml.class);
/*     */   public static Map<String, Object> argsMap;
/*     */   public static ThreadSleeper sleeper;
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/*  46 */       argsMap = checkArgs(args);
/*     */     } catch (Exception e) {
/*  48 */       System.out.println("##### program parameter is error.");
/*  49 */       e.printStackTrace();
/*  50 */       return;
/*     */     }
/*     */ 
/*  53 */     System.out.println("##### XML compound program start");
/*     */     try
/*     */     {
/*  57 */       ConfigReader.init();
/*     */     } catch (Exception e) {
/*  59 */       System.out.println("##### read properties file error, file path:" + 
/*  60 */         ConfigReader.class.getClassLoader().getResource(
/*  61 */         ConfigReader.CONFIG_PATH));
/*  62 */       e.printStackTrace();
/*  63 */       return;
/*     */     }
/*     */ 
/*  66 */     BaseParam.DB_IP = ConfigReader.read("db.ip");
/*  67 */     BaseParam.DB_PORT = ConfigReader.read("db.port");
/*  68 */     BaseParam.DB_NAME = ConfigReader.read("db.name");
/*  69 */     BaseParam.DB_USER = ConfigReader.read("db.user");
/*  70 */     BaseParam.DB_PWD = ConfigReader.read("db.pwd");
/*     */ 
/*  72 */     System.out.println("##### load config cache data");
/*     */ 
/*  75 */     Cache.init();
/*     */ 
/*  78 */     LogInit.init((String)Cache.configMap.get("LOG4J_COFIG_PATH"), 
/*  79 */       (String)Cache.configMap.get("LOG4J_FILENAME") + "make.log");
/*     */     List cardList;
/*  83 */     if ((String)argsMap.get("-c") == null) {
/*  84 */       List cardList = Cache.cardList;
/*     */ 
/*  86 */       if (!Cache.clearLog()) {
/*  87 */         System.out
/*  88 */           .println("##### XML compound program stop, clear log error.");
/*  89 */         log.info("程序清除生产日志异常(" + BaseParam.PERIOD + ")，停止执行.");
/*  90 */         Cache.close();
/*  91 */         return;
/*     */       }
/*  93 */       clearXmlFile((Card)cardList.get(0));
/*     */     }
/*     */     else {
/*  96 */       cardList = new ArrayList();
/*  97 */       List arrList = new ArrayList();
/*     */ 
/*  99 */       Collections.addAll(arrList, ((String)argsMap.get("-c")).split(","));
/*     */ 
/* 102 */       for (Iterator it = arrList.iterator(); it.hasNext(); ) {
/* 103 */         Card card = null;
/* 104 */         String cardId = (String)it.next();
/* 105 */         for (Card c : Cache.cardList) {
/* 106 */           if (c.getId().equals(cardId)) {
/* 107 */             card = c;
/* 108 */             break;
/*     */           }
/*     */         }
/* 111 */         if (card != null) {
/* 112 */           cardList.add(card);
/*     */         } else {
/* 114 */           log.info("传入卡id(" + cardId + ")不存在.");
/* 115 */           it.remove();
/*     */         }
/*     */       }
/*     */ 
/* 119 */       if (cardList.size() == 0) {
/* 120 */         log.info("没有匹配的卡产品(" + BaseParam.PERIOD + ", " + arrList + 
/* 121 */           ")，停止执行.");
/* 122 */         System.out
/* 123 */           .println("##### XML compound program stop, cardid is invalid.");
/* 124 */         Cache.close();
/* 125 */         return;
/*     */       }
/*     */ 
/* 128 */       if (!Cache.clearLog(arrList)) {
/* 129 */         log.info("程序清除生产日志异常(" + BaseParam.PERIOD + ")，停止执行.");
/* 130 */         System.out
/* 131 */           .println("##### XML compound program stop, clear log error.");
/* 132 */         Cache.close();
/* 133 */         return;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 138 */     List taskes = new ArrayList();
/* 139 */     int maxThread = ((Integer)argsMap.get("-t")).intValue();
/* 140 */     int average = maxThread / cardList.size();
/*     */ 
/* 142 */     if (average == 0)
/* 143 */       average = 1;
/* 144 */     maxThread = average * cardList.size();
/*     */ 
/* 147 */     sleeper = ThreadSleeper.getInstance(8, maxThread, 
/* 148 */       ((Integer)argsMap.get("-loop")).intValue());
/*     */ 
/* 150 */     StringBuffer sb = new StringBuffer();
/* 151 */     sb.append(BaseParam.getXMLPATH()).append("001").append(File.separator)
/* 152 */       .append("PRODUCT").append(File.separator).append("XML")
/* 153 */       .append(File.separator).append(BaseParam.PERIOD_Y)
/* 154 */       .append(File.separator).append(BaseParam.PERIOD_M)
/* 155 */       .append(File.separator).append(BaseParam.PERIOD_D);
/* 156 */     log.debug("delete all xml,path:" + sb.toString());
/* 157 */     FileUtil.delFolderFile(sb.toString());
/* 158 */     for (Card c : cardList) {
/* 159 */       taskes.add(new TaskAllot(c, average, ((Integer)argsMap.get("-b")).intValue(), 
/* 160 */         ((Boolean)argsMap.get("-lt")).booleanValue(), ((Boolean)argsMap.get("-lf")).booleanValue()));
/*     */     }
/*     */ 
/* 164 */     ExecutorService exec = Executors.newCachedThreadPool();
/* 165 */     List result = null;
/*     */ 
/* 167 */     SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*     */ 
/* 169 */     Cache.begin();
/* 170 */     Date date = new Date();
/* 171 */     long t1 = date.getTime();
/*     */ 
/* 173 */     log.info("程序开始执行, 任务线程:" + maxThread + ", 时间:" + sdf.format(date));
/*     */     try
/*     */     {
/* 177 */       result = exec.invokeAll(taskes);
/* 178 */       exec.shutdown();
/* 179 */       Cache.end("1");
/*     */     } catch (InterruptedException e) {
/* 181 */       Cache.end("2");
/*     */ 
/* 183 */       e.printStackTrace();
/*     */     } catch (RejectedExecutionException e) {
/* 185 */       Cache.end("2");
/* 186 */       log.error("任务无法安排执行");
/* 187 */       e.printStackTrace();
/*     */     } finally {
/* 189 */       Cache.close();
/*     */     }
/*     */ 
/* 192 */     date = new Date();
/* 193 */     long t2 = date.getTime();
/* 194 */     log.info("----------------------------------------------------------");
/*     */ 
/* 196 */     if (result != null) {
/* 197 */       for (Future f : result) {
/*     */         try {
/* 199 */           log.info(f.get());
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 203 */           e.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/* 207 */     log.info("生成结束, 时间:" + sdf.format(date) + ", 耗时:" + 
/* 208 */       Common.timeFormat(t2 - t1));
/* 209 */     System.out.println("##### program finish");
/* 210 */     System.exit(0);
/*     */   }
/*     */ 
/*     */   private static Map<String, Object> checkArgs(String[] args)
/*     */     throws Exception
/*     */   {
/* 221 */     Map argsMap = new HashMap();
/*     */ 
/* 223 */     argsMap.put("-t", Integer.valueOf(32));
/* 224 */     argsMap.put("-b", Integer.valueOf(500));
/* 225 */     argsMap.put("-c", null);
/* 226 */     argsMap.put("-lf", Boolean.valueOf(true));
/* 227 */     argsMap.put("-lt", Boolean.valueOf(false));
/* 228 */     argsMap.put("-loop", Integer.valueOf(30));
/* 229 */     argsMap.put("-xmlcount", Integer.valueOf(10000));
/* 230 */     int i = 0; for (int size = args.length; i < size; i++) {
/* 231 */       String s = args[i];
/* 232 */       if ((s.equals("-t")) || (s.equals("-b")) || (s.equals("-loop")) || 
/* 233 */         (s.equals("-xmlcount"))) {
/* 234 */         if (i + 1 < size) {
/* 235 */           i++;
/* 236 */           argsMap.put(s, Integer.valueOf(Integer.parseInt(args[i])));
/*     */         }
/* 238 */       } else if (s.equals("-c")) {
/* 239 */         if (i + 1 < size) {
/* 240 */           i++;
/* 241 */           argsMap.put(s, args[i]);
/*     */         }
/*     */ 
/*     */       }
/* 245 */       else if (argsMap.containsKey(s)) {
/* 246 */         argsMap.put(s, Boolean.valueOf(true));
/*     */       }
/*     */     }
/* 249 */     return argsMap;
/*     */   }
/*     */ 
/*     */   public static void clearXmlFile(Card card) {
/* 253 */     String xmlFilePath = BaseParam.XML_PATH + card.getType() + 
/* 254 */       File.separator + "PRODUCT" + File.separator + "XML" + 
/* 255 */       File.separator + BaseParam.PERIOD_Y + File.separator + 
/* 256 */       BaseParam.PERIOD_M + File.separator + BaseParam.PERIOD_D;
/*     */ 
/* 258 */     log.info("清理xml文件！path=" + xmlFilePath);
/*     */ 
/* 260 */     new File(xmlFilePath).deleteOnExit();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.normal.ComposeXml
 * JD-Core Version:    0.6.2
 */