package com.bill.normal;

import com.bill.bean.UserBase;
import com.mchange.v2.c3p0.debug.AfterCloseLoggingComboPooledDataSource;

import java.util.HashMap;
import java.util.Map;

import org.omg.CosNaming.NamingContextPackage.AlreadyBound;

public class UserXmlBuild {
	private Map<String, String> cache = new HashMap();
	private UserBase ub;
	private DBDao dao;
	private UserXml userXml;
	public long xml_setup1 = 0L;
	public long xml_setup2 = 0L;
	public long xml_setup3 = 0L;
	public long xml_setup4 = 0L;
	public long xml_setup5 = 0L;
	public long xml_setup6 = 0L;
	public long xml_setup7 = 0L;
	public long xml_setup8 = 0L;

	public UserXmlBuild() {
	}
	
	public UserXmlBuild(UserBase userBase) {
		this.ub = userBase;
	}

	public String getEmailXml() {
		String temp = getAccInfo();
		if (temp == null) {
			return null;
		}
		StringBuilder sb = new StringBuilder();
		sb.append("<checksheet>\n");

		sb.append(getBaseInfo()); //checked

		sb.append("<ENVRULE>0000</ENVRULE>\n")
		  .append("<INPRIORITY1>0</INPRIORITY1>\n")
		  .append("<INPRIORITY2>0</INPRIORITY2>\n")
		  .append("<INPRIORITY3>0</INPRIORITY3>\n")
		  .append("<INPRIORITY4>0</INPRIORITY4>\n");

		sb.append(getClickInfo());

		sb.append(temp);

		sb.append(getAccInfoDetail()); //checked

		sb.append("<mccs>\n</mccs>\n<historytrend></historytrend>");

		sb.append(getBuy());

		sb.append(getDebitInfo());

		sb.append(getStageplan());

		sb.append(getPoint());

		sb.append(getEmailTemplate());

		sb.append("<html5resources>\n<lists>\n</lists>\n</html5resources>\n");
		sb.append("</checksheet>\n");
		return sb.toString();
	}

	public String getPaperXml(String wbs) {
		String temp = getAccInfo();
		if (temp == null) {
			return null;
		}
		StringBuilder sb = new StringBuilder();
		sb.append("<checksheet>\n");

		sb.append(getBaseInfo());

		sb.append(getPaperEnvrule(wbs));

		sb.append(temp);

		sb.append(getAccInfoDetail());
		sb.append("<mccs>\n</mccs>\n<historytrend></historytrend>");

		sb.append(getBuy());

		sb.append(getDebitInfo());

		sb.append(getStageplan());

		sb.append(getPoint());

		sb.append(getPaperTemplate());
		sb.append("<html5resources>\n<lists>\n</lists>\n</html5resources>\n");
		sb.append("</checksheet>\n");
		return sb.toString();
	}

	public void close() {
		this.dao.close();
	}

	protected String getBaseInfo() {
		String value = (String) this.cache.get("base");
		if (value == null) {
			value = this.userXml.getBaseXml(this.ub);
			this.cache.put("base", value);
		}
		return value;
	}

	protected String getAccInfo() {
		String value = (String) this.cache.get("accinfo");
		if (value == null) {
			value = this.userXml.getAccInfoXml(this.ub);
			this.cache.put("accinfo", value);
		}
		return value;
	}

	protected String getAccInfoDetail() {
		if (this.cache.get("accinfodetail") == null) {
			this.cache.put("accinfodetail", this.userXml.getAccinfoDetail(this.ub));
		}
		return (String) this.cache.get("accinfodetail");
	}

	protected String getStageplan() {
		if (this.cache.get("stageplan") == null) {
			this.cache.put("stageplan", this.userXml.getStageplan(this.ub));
		}
		return (String) this.cache.get("stageplan");
	}

	protected String getBuy() {
		if (this.cache.get("buy") == null) {
			this.cache.put("buy", this.userXml.getBuy(this.ub));
		}
		return (String) this.cache.get("buy");
	}

	protected String getDebitInfo() {
		String value = (String) this.cache.get("debitinfo");
		if (value == null) {
			value = this.userXml.getDebitInfo(this.ub);
			this.cache.put("debitinfo", value);
		}
		return value;
	}

	protected String getPoint() {
		String value = (String) this.cache.get("point");
		if (value == null) {
			value = this.userXml.getPoint(this.ub);
			this.cache.put("point", value);
		}
		return value;
	}

	protected String getHtml5Template() {
		String temp = this.userXml.writeTemplateHtml5(this.ub).toString();
		return temp;
	}

	protected String getEmailTemplate() {
		String temp = this.userXml.writeTemplate(this.ub, "2").toString();
		return temp;
	}

	protected String getPaperTemplate() {
		String temp = this.userXml.writeTemplate(this.ub, "1").toString();
		return temp;
	}

	protected String getPaperEnvrule(String wbs) {
		String temp = this.userXml.getEnvrule(wbs, this.ub);
		return temp;
	}

	protected String getHisAmount() {
		if (this.cache.get("hisAmount") == null) {
			this.cache.put("hisAmount", this.userXml.getHisAmount(this.ub));
		}
		return (String) this.cache.get("hisAmount");
	}

	protected String getClickInfo() {
		return this.userXml.getClickInfo(this.ub);
	}
}

