package com.bill.normal.neww;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;

import com.bill.normal.UserXmlBuild;

public class AnalyerTask implements Runnable {
	private BlockingQueue<UserInfo> queue;
	private int total = 0;
	ExecutorService executorService;

	public AnalyerTask(BlockingQueue<UserInfo> queue, ExecutorService executorService) {
		this.queue = queue;
		this.executorService = executorService;
	}

	public void run() {
		try {
			while (true) {
				String fileName = "";
				List<String> xmlContent = null;
				boolean needWriteToFile = false;

				UserInfo userInfo = queue.take();

				if (userInfo.getCardId().equals(ReaderTask.poisonUserInfo.getCardId())
						&& userInfo.getCardName().equals(ReaderTask.poisonUserInfo.getCardName())
						&& userInfo.getCardType().equals(ReaderTask.poisonUserInfo.getCardType())) {
					queue.put(userInfo);
					return;
				}

				UserXmlBuild userXmlBuilder = new UserXmlBuild(userInfo);

				processEmailXML(userXmlBuilder, userInfo);
				processPaperXML(userXmlBuilder, userInfo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		executorService.shutdown();
	}

	private void processEmailXML(UserXmlBuild userXmlBuilder, UserInfo userInfo) {
		String fileName = "";
		List<String> xmlContent = null;
		boolean needWriteToFile = false;
		try {

			String email = userXmlBuilder.getEmailXml();

			synchronized (GlobalCache.emailTypeXMLMap) {
				CachedEmailTypeXML cachedEmailTypeXML = GlobalCache.emailTypeXMLMap.get(userInfo.getCardId());

				if (cachedEmailTypeXML == null) {
					cachedEmailTypeXML = new CachedEmailTypeXML();
					cachedEmailTypeXML.setCardId(userInfo.getCardId());
					cachedEmailTypeXML.setCurrentDate("20161010");
					cachedEmailTypeXML.setXmlContent(new ArrayList<String>());
					GlobalCache.emailTypeXMLMap.put(userInfo.getCardId(), cachedEmailTypeXML);
					cachedEmailTypeXML.setSerialNo(1);
				}

				cachedEmailTypeXML.getXmlContent().add(email);

				if (cachedEmailTypeXML.getXmlContent().size() == Config.getInstance().getMaxRowsInXML()) {
					xmlContent = cachedEmailTypeXML.getXmlContent();

					fileName = cachedEmailTypeXML.getCurrentDate() + "_" + cachedEmailTypeXML.getCardId() + "_"
							+ cachedEmailTypeXML.getSerialNo();
					needWriteToFile = true;

					cachedEmailTypeXML.setXmlContent(new ArrayList<String>());
					cachedEmailTypeXML.setSerialNo(cachedEmailTypeXML.getSerialNo() + 1);

				}
			}

			if (needWriteToFile) {
				BufferedWriter bufferedWriter = null;
				System.out.println(Thread.currentThread().getName() + " Writing file to " + fileName + " lines "
						+ xmlContent.size());
				bufferedWriter = new BufferedWriter(new FileWriter("/appbill/program/bin/xmlfolder/" + fileName));

				for (String line : xmlContent) {
					bufferedWriter.write(line);
				}
				xmlContent.clear();
				bufferedWriter.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private void processPaperXML(UserXmlBuild userXmlBuild, UserInfo userInfo) {
		String paperXML = userXmlBuild.getPaperXml(wbs);
	}

}
