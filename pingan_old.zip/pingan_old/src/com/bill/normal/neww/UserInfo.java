package com.bill.normal.neww;

import com.bill.bean.UserBase;

public class UserInfo extends UserBase {

	private String cardId;
	private String cardName;
	private String cardType;

	public String getCardId() {
		return cardId;
	}

	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

	public String getCardName() {
		return cardName;
	}

	public void setCardName(String cardName) {
		this.cardName = cardName;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

}
