package com.bill.normal.neww;

import java.util.concurrent.ConcurrentHashMap;

public class GlobalCache {
	public static ConcurrentHashMap<String, CachedEmailTypeXML> emailTypeXMLMap = new ConcurrentHashMap<String, CachedEmailTypeXML>();
}
