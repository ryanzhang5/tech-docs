package com.bill.normal.neww;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;


public class ReaderTask implements Runnable {
	
	private BlockingQueue<UserInfo> queue;
	private ExecutorService executorService;
	
	public static UserInfo poisonUserInfo = null;
	private static final String  POISON_CARD_ID = "poison_card_id";
	private static final String  POISON_CARD_NAME = "poison_card_name";
	private static final String  POISON_CARD_TYPE = "poison_card_type";
	
	public ReaderTask(BlockingQueue<UserInfo> queue, ExecutorService executorService) {
		this.queue = queue;
		this.executorService = executorService;
		
		poisonUserInfo = new UserInfo();
		poisonUserInfo.setCardId(POISON_CARD_ID);
		poisonUserInfo.setCardName(POISON_CARD_NAME);
		poisonUserInfo.setCardType(POISON_CARD_TYPE);;
	}

	public void run() {
		try {
			int total = 0;
			long start = System.currentTimeMillis();

			String sql = "select  CARD.s_buss_prod_id,CARD.s_buss_prod_name,CARD.c_buss_type_id,BILL.S_ACCOUNT,BILL.S_CUR_TYPE,BILL.S_CUR_ZIP,BILL.S_CUR_ADDR3,BILL.S_CUR_ADDR1,BILL.S_CUR_ADDR2,BILL.S_CUR_NAME,BILL.C_CUR_SEX,BILL.S_CUR_BIRTHDAY,BILL.S_CUR_ACCOUNT,BILL.S_CUR_CUST_NBR,BILL.S_CUR_START_DATE,BILL.S_CUR_END_DATE,BILL.S_CUR_SPECIAL_CHAR,BILL.S_CUR_PMT_CYCLE_DUE,BILL.S_CUR_PRINT,BILL.C_CUR_MSG_1,BILL.C_CUR_MSG_2,BILL.C_CUR_MSG_3,BILL.C_CUR_MSG_4,BILL.C_CUR_MSG_5,BILL.C_CUR_MSG_6,BILL.C_CUR_MSG_7,BILL.C_CUR_MSG_8,BILL.C_CUR_ACTIVITY_MSG,BILL.C_CUR_DM_MSG_1,BILL.C_CUR_DM_MSG_2,BILL.C_CUR_DM_MSG_3,BILL.C_CUR_DM_MSG_4,BILL.C_CUR_BRAND_MSG_1,BILL.C_CUR_BRAND_MSG_2,BILL.C_CUR_BRAND_MSG_3,BILL.C_CUR_BRAND_MSG_4,BILL.C_CUR_BRAND_MSG_5,BILL.C_CUR_BRAND_MSG_6,BILL.C_CUR_BRAND_MSG_7,BILL.C_CUR_CONV_EXCH_FLAG,BILL.C_CUR_VIP_MSG_1,BILL.C_CUR_VIP_MSG_2,BILL.C_CUR_VIP_MSG_3,BILL.C_CUR_VIP_MSG_4,BILL.C_CUR_REPRINT_FLAG,BILL.C_CUR_EMAIL_STMT_FLAG,BILL.C_CUR_PAPER_STMT_FLAG,BILL.S_CUR_EMAIL_ADDR,BILL.S_CUR_CUSTOMER_TYPE,BILL.S_CUR_MOBILE_NBR,BILL.S_CUR_AI_NBR,BILL.C_CUR_MOB,BILL.S_CUR_FILLER,BILL.S_CITY_ID,BILL.I_CUR_CRLIM,BILL.I_CUR_BAL,BILL.I_CUR_TOT_DUE_AMT,BILL.I_CUR_CASH_CRLIM,BILL.C_STMT_DATE,BILL.S_CARD_PROD_ID from T_S_BUSI_PROD_INFO CARD INNER JOIN t_b_customer_bill BILL ON CARD.c_buss_prod_flag='0' and CARD.C_BUSS_STATE='1' and CARD.c_buss_type_id='001' AND CARD.s_buss_prod_id = BILL.S_CARD_PROD_ID order by CARD.s_buss_prod_id";
			Connection dbconn = DataSource.getInstance().getConnection();
			PreparedStatement stmt = dbconn.prepareStatement(sql);
			ResultSet result = stmt.executeQuery();
			
			while (result.next()) {
				UserInfo ub = new UserInfo();
				total++;
				if (total % 10000 == 0) {
					System.out.println(total + "  "
							+ (System.currentTimeMillis() - start));
				}

				 ub.setCardId(result.getString("s_buss_prod_id"));
				 ub.setCardName(result.getString("s_buss_prod_name"));
				 ub.setCardType(result.getString("c_buss_type_id"));;

				ub.setAcctnbr(result.getString("S_ACCOUNT"));
				ub.setRectype(result.getString("S_CUR_TYPE"));
				ub.setZip(result.getString("S_CUR_ZIP"));
				ub.setAddrname3(result.getString("S_CUR_ADDR3"));
				ub.setAddrname1(result.getString("S_CUR_ADDR1"));
				ub.setAddrname2(result.getString("S_CUR_ADDR2"));
				ub.setName(result.getString("S_CUR_NAME"));
				ub.setSex(result.getString("C_CUR_SEX"));
				ub.setBirthday(result.getString("S_CUR_BIRTHDAY"));
				ub.setAccnum(result.getString("S_CUR_ACCOUNT"));
				ub.setCusnum(result.getString("S_CUR_CUST_NBR"));
				ub.setStfromdate(result.getString("S_CUR_START_DATE"));
				ub.setEnddate(result.getString("S_CUR_END_DATE"));
				ub.setSpecode(result.getString("S_CUR_SPECIAL_CHAR"));
				ub.setPmtduemark(result.getString("S_CUR_PMT_CYCLE_DUE"));
				ub.setCashmark(result.getString("S_CUR_PRINT"));
				ub.setIndiv1(result.getString("C_CUR_MSG_1"));
				ub.setIndiv2(result.getString("C_CUR_MSG_2"));
				ub.setIndiv3(result.getString("C_CUR_MSG_3"));
				ub.setIndiv4(result.getString("C_CUR_MSG_4"));
				ub.setIndiv5(result.getString("C_CUR_MSG_5"));
				ub.setIndiv6(result.getString("C_CUR_MSG_6"));
				ub.setIndiv7(result.getString("C_CUR_MSG_7"));
				ub.setIndiv8(result.getString("C_CUR_MSG_8"));
				ub.setActinfo(result.getString("C_CUR_ACTIVITY_MSG"));
				ub.setDm1(result.getString("C_CUR_DM_MSG_1"));
				ub.setDm2(result.getString("C_CUR_DM_MSG_2"));
				ub.setDm3(result.getString("C_CUR_DM_MSG_3"));
				ub.setDm4(result.getString("C_CUR_DM_MSG_4"));
				ub.setBrandmsg1(result.getString("C_CUR_BRAND_MSG_1"));
				ub.setBrandmsg2(result.getString("C_CUR_BRAND_MSG_2"));
				ub.setBrandmsg3(result.getString("C_CUR_BRAND_MSG_3"));
				ub.setBrandmsg4(result.getString("C_CUR_BRAND_MSG_4"));
				ub.setBrandmsg5(result.getString("C_CUR_BRAND_MSG_5"));
				ub.setBrandmsg6(result.getString("C_CUR_BRAND_MSG_6"));
				ub.setBrandmsg7(result.getString("C_CUR_BRAND_MSG_7"));
				ub.setConvexchmark(result.getString("C_CUR_CONV_EXCH_FLAG"));
				ub.setVipmsg1(result.getString("C_CUR_VIP_MSG_1"));
				ub.setVipmsg2(result.getString("C_CUR_VIP_MSG_2"));
				ub.setVipmsg3(result.getString("C_CUR_VIP_MSG_3"));
				ub.setVipmsg4(result.getString("C_CUR_VIP_MSG_4"));
				ub.setReprintflag(result.getString("C_CUR_REPRINT_FLAG"));
				ub.setEmailflag(result.getString("C_CUR_EMAIL_STMT_FLAG"));
				ub.setPaperflag(result.getString("C_CUR_PAPER_STMT_FLAG"));
				ub.setEmailaddr(result.getString("S_CUR_EMAIL_ADDR"));
				ub.setCusttype(result.getString("S_CUR_CUSTOMER_TYPE"));
				ub.setMobilenbr(result.getString("S_CUR_MOBILE_NBR"));
				ub.setAinbr(result.getString("S_CUR_AI_NBR"));
				ub.setMobdate(result.getString("C_CUR_MOB"));
				ub.setFiller(result.getString("S_CUR_FILLER"));
				ub.setCity(result.getString("S_CITY_ID"));
				ub.setCrlim(result.getString("I_CUR_CRLIM"));
				ub.setCurrbal(result.getString("I_CUR_BAL"));
				ub.setTotdueamt(result.getString("I_CUR_TOT_DUE_AMT"));
				ub.setCashcrlim(result.getString("I_CUR_CASH_CRLIM"));
				ub.setStmtdate(result.getString("C_STMT_DATE"));
				ub.setCardNo(result.getString("S_CARD_PROD_ID"));

				queue.put(ub);
				
			}
			System.out.println("----------------reader total " + total
					+ " time is " + (System.currentTimeMillis() - start));
			
			
			queue.put(poisonUserInfo);
			executorService.shutdown();
			
			result.close();
			stmt.close();
			dbconn.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
