package com.bill.normal.neww;

import java.util.List;

public class CachedEmailTypeXML {
	private String currentDate;
	private String cardId;
	private int serialNo;
	private int currentRows;
	private List<String> xmlContent;

	public String getCurrentDate() {
		return currentDate;
	}

	public void setCurrentDate(String currentDate) {
		this.currentDate = currentDate;
	}

	public String getCardId() {
		return cardId;
	}

	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

	public int getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}

	public int getCurrentRows() {
		return currentRows;
	}

	public void setCurrentRows(int currentRows) {
		this.currentRows = currentRows;
	}

	public List<String> getXmlContent() {
		return xmlContent;
	}

	public void setXmlContent(List<String> xmlContent) {
		this.xmlContent = xmlContent;
	}

}
