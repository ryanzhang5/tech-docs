package com.bill.normal.neww;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MSMain {
///\* *[0-9]* *\*/
	public static void main(String args[]) {
		//all thread = reader + analyser
		ExecutorService executorService = Executors.newFixedThreadPool(Config.getInstance().maxAnalyerThreadNum() + 1);

		BlockingQueue<UserInfo> queue = new ArrayBlockingQueue<UserInfo>(100);

		//first start consumer thread, then producer thread
		for (int i = 0; i < Config.getInstance().maxAnalyerThreadNum(); i++){
			executorService.execute(new AnalyerTask(queue,executorService));
		}

		executorService.execute(new ReaderTask(queue));
	}
}
