package com.bill.normal.neww;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Config {
	public static Config config = new Config();
	private Properties properties = null;
	private static final String CONFIG_FILE_PATH = "com/bill/normal/config.properties";

	private Config() {
		properties = new Properties();
		InputStream inputStream = getClass().getClassLoader().getResourceAsStream(CONFIG_FILE_PATH);
		try {
			properties.load(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				inputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public static Config getInstance() {
		return config;
	}

	public String getProperty(String key) {
		return properties.getProperty(key);
	}

	public int getMaxRowsInXML() {
		return Integer.parseInt(getProperty("maxRowsInXmlFile"));
	}

	public String getDBDriverClass() {
		return properties.getProperty("jdbc.driver");
	}

	public String getDBURL() {
		return properties.getProperty("jdbc.url");
	}

	public String getDBUsername() {
		return properties.getProperty("jdbc.username");
	}

	public String getDBPassword() {
		return properties.getProperty("jdbc.password");
	}
	public int maxAnalyerThreadNum() {
		return Integer.parseInt(properties.getProperty("maxAnalyerThreadNum"));
	}
	
	
}
