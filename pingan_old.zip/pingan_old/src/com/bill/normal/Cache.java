 package com.bill.normal;
 
 import com.bill.bean.BaseParam;
 import com.bill.bean.Busin;
 import com.bill.bean.Card;
 import com.bill.bean.Fodder;
 import com.bill.bean.Foldout;
 import com.bill.bean.Rule;
 import com.bill.bean.RuleF;
 import com.bill.bean.RuleM;
 import com.bill.bean.TempArea;
 import com.bill.bean.Yyz;
 import com.bill.bean.mcc;
 import com.bill.util.DESUtil;
 import java.util.Collections;
 import java.util.HashMap;
 import java.util.List;
 import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
 
 public class Cache
 {
   public static Map<String, String> configMap;
   public static List<Busin> businList;
   public static List<Card> cardList;
   public static Map<String, String> bfpntMap;
   public static Map<String, List<Yyz>> cardBfpntMap;
   public static Map<String, String> templateMap;
   public static List<mcc> mcclist;
   public static Map<String, String> mccmap;
   public static Map<String, String> mccMapMaster;
   public static Map<String, String> mccMapSub;
   private static DBDaoNew dao;
   private static String MCC_NAME_E = "";
 
   private static String MCC_NAME_M = "S_TYPE_NAME";
 
   private static String MCC_NAME_S = "S_NAME";
   public static Map<String, String> stageTypeMap;
   public static Map<String, String> prodIdMapping = null;
 
   public static DESUtil des = null;
 
   private static Map<String, List<TempArea>> templateInfo = new ConcurrentHashMap<>();
 
   private static Map<String, List<Rule>> ruleMap = new ConcurrentHashMap<>();
   private static Map<String, List<RuleF>> ruleFMap = new ConcurrentHashMap<>();
   private static Map<String, List<RuleM>> ruleMMap = new ConcurrentHashMap<>();
 
   private static Map<String, Fodder> fodderMap = new ConcurrentHashMap<>();
 
   private static Map<String, List<Foldout>> foldoutMap = new ConcurrentHashMap<>();
 
   private static Map<String, Map<String, String>> foldoutCityMap = new ConcurrentHashMap<>();
 
   public static Map<String, String> fqjyCard = new HashMap<String, String>();
 
   public static List<String> getCityByCPB(String cardid, String printid, String businId, DBDaoNew dbdao)
   {
     return dbdao.getCityByCPB(cardid, printid, businId);
   }
 
   public static List<Rule> getRuleMap(String tid, String type, String area, DBDaoNew dbdao)
   {
     String key = tid + "_" + type + "_" + area;
     List value = (List)ruleMap.get(key);
     if (value == null)
     {
       value = dbdao.getRule(tid, type, area, BaseParam.PERIOD_YM, BaseParam.PERIOD_D);
       ruleMap.put(key, value);
     }
     return value;
   }
 
   public static List<RuleF> getRuleFMap(String rid, DBDaoNew dbdao)
   {
     List value = (List)ruleFMap.get(rid);
     if (value == null) {
       value = dbdao.getRuleF(rid);
       ruleFMap.put(rid, value);
     }
     return value;
   }
 
   public static List<RuleM> getRuleFFList(String rid, DBDaoNew dbdao)
   {
     List value = (List)ruleMMap.get(rid);
     if (value == null) {
       value = dbdao.getRuleFF(rid);
       ruleMMap.put(rid, value);
     }
     return value;
   }
 
   public static List<TempArea> getTemplateInfo(String tid, DBDaoNew dbdao)
   {
     List value = (List)templateInfo.get(tid);
     if (value == null) {
       value = dbdao.getTemplateInfo(tid);
       templateInfo.put(tid, value);
     }
     return value;
   }
 
   public static Fodder getFodder(String fid, DBDaoNew dbdao)
   {
     Fodder value = null;
     if (fodderMap.containsKey(fid)) {
       value = (Fodder)fodderMap.get(fid);
     }
     else {
       value = dbdao.getFodder(fid, BaseParam.PERIOD_YM);
       fodderMap.put(fid, value);
     }
     return value;
   }
 
   public static List<Foldout> getFoldout(String bid, String cid, DBDaoNew dbdao)
   {
     String key = bid + "_" + cid;
     List value = (List)foldoutMap.get(key);
     if (value == null) {
       value = dbdao.getFoldout(bid, cid, BaseParam.PERIOD);
       int i = value.size();
       Foldout f = null;
       for (; i < 4; i++) {
         f = new Foldout();
         f.setPri(1);
         f.setState("0");
         value.add(f);
       }
       foldoutMap.put(key, value);
     }
     return value;
   }
 
   public static Map<String, String> getFoldoutCity(String id, String idx, DBDaoNew dbdao)
   {
     String key = id + "_" + idx;
     Map value = (Map)foldoutCityMap.get(key);
     if (value == null) {
       value = dbdao.getFoldoutCity(id, idx);
       foldoutCityMap.put(key, value);
     }
     return value;
   }
 
   public static synchronized void begin()
   {
     dao.cleanWatchState();
     dao.beginWatchState();
     dao.beginWatch();
   }
 
   public static synchronized void end(String state)
   {
     dao.endWatchState(state);
     dao.endWatch();
   }
 
   public static void init()
     throws Exception
   {
     if (configMap == null) {
       configMap = dao.getConfig();
 
       BaseParam.setPeriod((String)configMap.get("PERIOD"));
       BaseParam.XML_PATH = (String)configMap.get("BASEPATH");
     }
     if (businList == null)
     {
       businList = dao.getBusin();
     }
     if (cardList == null)
     {
       cardList = dao.getCard();
     }
     if (bfpntMap == null)
     {
       bfpntMap = dao.getBfpntMap();
     }
     if (cardBfpntMap == null)
     {
       cardBfpntMap = dao.getCardBfpntMap();
     }
     if (templateMap == null)
     {
       templateMap = dao.getTemplateList();
     }
 
     fqjyCard = dao.queryFQJY();
 
     mccmap = new HashMap<String,String>();
     mccMapMaster = new HashMap<String,String>();
     mccMapSub = new HashMap<String,String>();
 
     stageTypeMap = dao.queryStageType();
 
     des = new DESUtil("GLPp7Or8".getBytes());
   }
 
   public static void close()
   {
     dao.close();
   }
 
   public static boolean clearLog()
   {
     return dao.clearDBLog(BaseParam.PERIOD);
   }
 
   public static boolean clearLog(List<String> arr)
   {
     return dao.clearDBLog(BaseParam.PERIOD, arr);
   }
 }
