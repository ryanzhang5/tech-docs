package com.bill.normal;

import com.bill.bean.BaseParam;
import com.bill.bean.Busin;
import com.bill.bean.Card;
import com.bill.bean.Debitinfo;
import com.bill.bean.Fodder;
import com.bill.bean.Foldout;
import com.bill.bean.HisAmountBean;
import com.bill.bean.Plog;
import com.bill.bean.PointInfo;
import com.bill.bean.Rule;
import com.bill.bean.RuleF;
import com.bill.bean.RuleM;
import com.bill.bean.RuleMNew;
import com.bill.bean.Stageplan;
import com.bill.bean.TempArea;
import com.bill.bean.UserAccinfo;
import com.bill.bean.UserAccinfoDetail;
import com.bill.bean.UserBase;
import com.bill.bean.UserBuy;
import com.bill.bean.Yyz;
import com.bill.bean.mcc;
import com.bill.db.DbConnectionForOracle;
import com.bill.make.PaperRelatingWrap;
import com.bill.normal.neww.DataSource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.spi.DirStateFactory.Result;

import org.apache.log4j.Logger;

public class DBDaoNew {
	public Logger log;
	private static String CARD_SQL = "select t.s_buss_prod_id,t.s_buss_prod_name,t.c_buss_type_id from T_S_BUSI_PROD_INFO t where t.c_buss_prod_flag='0' and t.C_BUSS_STATE='1' and t.c_buss_type_id='001'";

	private static String BFPNT_SQL = "select t.s_id from t_s_befor_print_basic  t where  to_date(?,'yyyyMM')>= to_date(t.c_period_begen,'yyyy-MM') and to_date(?,'yyyyMM')<= to_date(t.c_period_end,'yyyy-MM') and t.c_period_day=?";

	private static String CPB_CITY_SQL = "select t.s_city_no from t_s_bfpnt_cty_crdtp t where t.s_city_no is not null and t.s_card_no =? and t.s_id=? and t.s_businpnt_no=?";

	private static String USER_BASE1 = "select * from (select tt.*, rownum RN from (select t.*, rownum from t_b_customer_bill t where C_CUR_PAPER_STMT_FLAG='Y' AND S_CARD_PROD_ID = ? and S_CITY_ID=? and rownum < ?) tt ) where RN >= ?";

	private static String USER_BASE2 = "select * from (select tt.*, rownum RN from (select t.*, rownum from t_b_customer_bill t where S_CARD_PROD_ID = ? and rownum < ?) tt ) where RN >= ?";

	private static String TEMPLATE_SQL = "select t.s_stencil_no,t.s_card_prod_id,t.c_type_no from T_S_STENCIL t where t.c_state='1'";

	private static String RULE_SQL = "select * from t_s_rule_m t where t.s_stencil_no=? and t.c_rule_type=? and t.i_area_no=? and t.c_state='1' and to_date(?,'yyyyMM')>=to_date(t.c_period_begen,'yyyy-MM') and to_date(?,'yyyyMM')<=to_date(t.c_period_end,'yyyy-MM') and t.s_period like '%'||?||'%' order by t.i_pri desc";

	private static String CityYyyzWbsByCard_SQL = "select B.s_id,       B.S_BUSINPNT_NO,       A.S_PAPER_NO,       B.s_city_no,       A.i_print_pri,       (select t1.c_buss_type_id          from t_s_busi_prod_info t1         where t1.s_buss_prod_id = B.s_card_no) as c_buss_type_id  from (select t2.s_paper_no, t2.s_id,t2.i_print_pri          from t_s_befor_print_basic t2         where ? between t2.c_period_begen and t2.c_period_end           and t2.c_period_day = ?         order by t2.i_print_pri desc) A,       (select t.s_id, t.s_businpnt_no, t.s_card_no,t.s_city_no          from t_s_bfpnt_cty_crdtp t         where t.s_card_no = ?           AND t.s_id > '0'           and t.s_businpnt_no > '0') B         where A.s_Id = B.S_ID";

	public DBDaoNew() {
	}

	public List<Busin> getBusin() {
		List<Busin> list = new ArrayList<Busin>();
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn
					.prepareStatement("select t1.s_businpnt_no,t1.s_businpnt_name from T_S_EPLBOLY_PNT t1");
			ResultSet resultSet = pstmt.executeQuery();

			while (resultSet.next()) {
				Busin e = new Busin();
				e.setId(resultSet.getString("s_businpnt_no"));
				e.setName(resultSet.getString("s_businpnt_name"));
				list.add(e);
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public List<Card> getCard() {
		List<Card> list = new ArrayList<Card>();
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(CARD_SQL);
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				Card e = new Card();
				e.setId(resultSet.getString("s_buss_prod_id"));
				e.setName(resultSet.getString("s_buss_prod_name"));
				e.setType(resultSet.getString("c_buss_type_id"));
				list.add(e);
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public Map<String, String> getBfpntMap() {
		Map<String, String> map = new HashMap<String, String>();

		String ym = BaseParam.PERIOD.substring(0, 6);

		String d = BaseParam.PERIOD.substring(6);
		try {

			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(BFPNT_SQL);
			pstmt.setString(1, ym);
			pstmt.setString(2, ym);
			pstmt.setString(3, d);
			ResultSet resultSet = pstmt.executeQuery();

			String id = "";
			while (resultSet.next()) {
				id = resultSet.getString(1);
				map.put(id, id);
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return map;
	}

	public Map<String, List<Yyz>> getCardBfpntMap() {
		Map<String, List<Yyz>> map = new HashMap<String, List<Yyz>>();
		StringBuffer sb = new StringBuffer();
		sb.append("select ");
		sb.append("t.s_card_no,t.s_id,t2.S_PAPER_NO");
		sb.append(" from t_s_bfpnt_cty_crdtp t,T_S_BEFOR_PRINT_BASIC t2");
		sb.append(" where ");
		sb.append("t.s_id=t2.s_id and t2.c_period_day=? and t2.c_period_begen<=? and t2.c_period_end>=?");
		sb.append(" group by t.s_card_no,t.s_id,t2.S_PAPER_NO");
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sb.toString());
			pstmt.setString(1, BaseParam.PERIOD_D);
			pstmt.setString(2, BaseParam.PERIOD_Y + "-" + BaseParam.PERIOD_M);
			pstmt.setString(3, BaseParam.PERIOD_Y + "-" + BaseParam.PERIOD_M);
			ResultSet resultSet = pstmt.executeQuery();

			String id1 = "";

			while (resultSet.next()) {
				Yyz y = new Yyz();
				id1 = resultSet.getString("s_card_no");
				y.setId(resultSet.getString("s_id"));
				y.setPaperNo(resultSet.getString("S_PAPER_NO"));
				if (map.containsKey(id1)) {
					map.get(id1).add(y);
				} else {
					List<Yyz> list = new ArrayList<Yyz>();
					list.add(y);
					map.put(id1, list);
				}
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return map;
	}

	public List<String> getCityByCPB(String cid, String pid, String bid) {
		List<String> list = new ArrayList<String>();
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(CPB_CITY_SQL);
			pstmt.setString(1, cid);
			pstmt.setString(2, pid);
			pstmt.setString(3, bid);
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				list.add(resultSet.getString("S_CITY_NO"));
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public List<UserBase> getUserBase(String cardid, String city, int page, int size) {
		List<UserBase> list = new ArrayList<UserBase>();
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(USER_BASE1);
			pstmt.setString(1, cardid);
			pstmt.setString(2, city);
			pstmt.setInt(3, page * size);
			pstmt.setInt(4, (page - 1) * size);
			ResultSet resultSet = pstmt.executeQuery();

			while (resultSet.next()) {
				UserBase ub = new UserBase();
				ub.setAcctnbr(resultSet.getString("S_ACCOUNT"));
				ub.setRectype(resultSet.getString("S_CUR_TYPE"));
				ub.setZip(resultSet.getString("S_CUR_ZIP"));
				ub.setAddrname3(resultSet.getString("S_CUR_ADDR3"));
				ub.setAddrname1(resultSet.getString("S_CUR_ADDR1"));
				ub.setAddrname2(resultSet.getString("S_CUR_ADDR2"));
				ub.setName(resultSet.getString("S_CUR_NAME"));
				ub.setSex(resultSet.getString("C_CUR_SEX"));
				ub.setBirthday(resultSet.getString("S_CUR_BIRTHDAY"));
				ub.setAccnum(resultSet.getString("S_CUR_ACCOUNT"));
				ub.setCusnum(resultSet.getString("S_CUR_CUST_NBR"));
				ub.setStfromdate(resultSet.getString("S_CUR_START_DATE"));
				ub.setEnddate(resultSet.getString("S_CUR_END_DATE"));
				ub.setSpecode(resultSet.getString("S_CUR_SPECIAL_CHAR"));
				ub.setPmtduemark(resultSet.getString("S_CUR_PMT_CYCLE_DUE"));
				ub.setCashmark(resultSet.getString("S_CUR_PRINT"));
				ub.setIndiv1(resultSet.getString("C_CUR_MSG_1"));
				ub.setIndiv2(resultSet.getString("C_CUR_MSG_2"));
				ub.setIndiv3(resultSet.getString("C_CUR_MSG_3"));
				ub.setIndiv4(resultSet.getString("C_CUR_MSG_4"));
				ub.setIndiv5(resultSet.getString("C_CUR_MSG_5"));
				ub.setIndiv6(resultSet.getString("C_CUR_MSG_6"));
				ub.setIndiv7(resultSet.getString("C_CUR_MSG_7"));
				ub.setIndiv8(resultSet.getString("C_CUR_MSG_8"));
				ub.setActinfo(resultSet.getString("C_CUR_ACTIVITY_MSG"));
				ub.setDm1(resultSet.getString("C_CUR_DM_MSG_1"));
				ub.setDm2(resultSet.getString("C_CUR_DM_MSG_2"));
				ub.setDm3(resultSet.getString("C_CUR_DM_MSG_3"));
				ub.setDm4(resultSet.getString("C_CUR_DM_MSG_4"));
				ub.setBrandmsg1(resultSet.getString("C_CUR_BRAND_MSG_1"));
				ub.setBrandmsg2(resultSet.getString("C_CUR_BRAND_MSG_2"));
				ub.setBrandmsg3(resultSet.getString("C_CUR_BRAND_MSG_3"));
				ub.setBrandmsg4(resultSet.getString("C_CUR_BRAND_MSG_4"));
				ub.setBrandmsg5(resultSet.getString("C_CUR_BRAND_MSG_5"));
				ub.setBrandmsg6(resultSet.getString("C_CUR_BRAND_MSG_6"));
				ub.setBrandmsg7(resultSet.getString("C_CUR_BRAND_MSG_7"));
				ub.setConvexchmark(resultSet.getString("C_CUR_CONV_EXCH_FLAG"));
				ub.setVipmsg1(resultSet.getString("C_CUR_VIP_MSG_1"));
				ub.setVipmsg2(resultSet.getString("C_CUR_VIP_MSG_2"));
				ub.setVipmsg3(resultSet.getString("C_CUR_VIP_MSG_3"));
				ub.setVipmsg4(resultSet.getString("C_CUR_VIP_MSG_4"));
				ub.setReprintflag(resultSet.getString("C_CUR_REPRINT_FLAG"));
				ub.setEmailflag(resultSet.getString("C_CUR_EMAIL_STMT_FLAG"));
				ub.setPaperflag(resultSet.getString("C_CUR_PAPER_STMT_FLAG"));
				ub.setEmailaddr(resultSet.getString("S_CUR_EMAIL_ADDR"));
				ub.setCusttype(resultSet.getString("S_CUR_CUSTOMER_TYPE"));
				ub.setMobilenbr(resultSet.getString("S_CUR_MOBILE_NBR"));
				ub.setAinbr(resultSet.getString("S_CUR_AI_NBR"));
				ub.setMobdate(resultSet.getString("C_CUR_MOB"));
				ub.setFiller(resultSet.getString("S_CUR_FILLER"));
				ub.setCity(resultSet.getString("S_CITY_ID"));
				ub.setCrlim(resultSet.getString("I_CUR_CRLIM"));
				ub.setCurrbal(resultSet.getString("I_CUR_BAL"));
				ub.setTotdueamt(resultSet.getString("I_CUR_TOT_DUE_AMT"));
				ub.setCashcrlim(resultSet.getString("I_CUR_CASH_CRLIM"));
				ub.setStmtdate(resultSet.getString("C_STMT_DATE"));
				ub.setCardNo(resultSet.getString("S_CARD_PROD_ID"));
				list.add(ub);
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public List<UserBase> getUserBase(String cardid, int page, int size) {
		List<UserBase> list = new ArrayList<UserBase>();
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(USER_BASE2);
			pstmt.setString(1, cardid);

			pstmt.setInt(2, page * size);

			pstmt.setInt(3, (page - 1) * size);
			ResultSet resultSet = pstmt.executeQuery();

			while (resultSet.next()) {
				UserBase ub = new UserBase();
				ub.setAcctnbr(resultSet.getString("S_ACCOUNT"));
				ub.setRectype(resultSet.getString("S_CUR_TYPE"));
				ub.setZip(resultSet.getString("S_CUR_ZIP"));
				ub.setAddrname3(resultSet.getString("S_CUR_ADDR3"));
				ub.setAddrname1(resultSet.getString("S_CUR_ADDR1"));
				ub.setAddrname2(resultSet.getString("S_CUR_ADDR2"));
				ub.setName(resultSet.getString("S_CUR_NAME"));
				ub.setSex(resultSet.getString("C_CUR_SEX"));
				ub.setBirthday(resultSet.getString("S_CUR_BIRTHDAY"));
				ub.setAccnum(resultSet.getString("S_CUR_ACCOUNT"));
				ub.setCusnum(resultSet.getString("S_CUR_CUST_NBR"));
				ub.setStfromdate(resultSet.getString("S_CUR_START_DATE"));
				ub.setEnddate(resultSet.getString("S_CUR_END_DATE"));
				ub.setSpecode(resultSet.getString("S_CUR_SPECIAL_CHAR"));
				ub.setPmtduemark(resultSet.getString("S_CUR_PMT_CYCLE_DUE"));
				ub.setCashmark(resultSet.getString("S_CUR_PRINT"));
				ub.setIndiv1(resultSet.getString("C_CUR_MSG_1"));
				ub.setIndiv2(resultSet.getString("C_CUR_MSG_2"));
				ub.setIndiv3(resultSet.getString("C_CUR_MSG_3"));
				ub.setIndiv4(resultSet.getString("C_CUR_MSG_4"));
				ub.setIndiv5(resultSet.getString("C_CUR_MSG_5"));
				ub.setIndiv6(resultSet.getString("C_CUR_MSG_6"));
				ub.setIndiv7(resultSet.getString("C_CUR_MSG_7"));
				ub.setIndiv8(resultSet.getString("C_CUR_MSG_8"));
				ub.setActinfo(resultSet.getString("C_CUR_ACTIVITY_MSG"));
				ub.setDm1(resultSet.getString("C_CUR_DM_MSG_1"));
				ub.setDm2(resultSet.getString("C_CUR_DM_MSG_2"));
				ub.setDm3(resultSet.getString("C_CUR_DM_MSG_3"));
				ub.setDm4(resultSet.getString("C_CUR_DM_MSG_4"));
				ub.setBrandmsg1(resultSet.getString("C_CUR_BRAND_MSG_1"));
				ub.setBrandmsg2(resultSet.getString("C_CUR_BRAND_MSG_2"));
				ub.setBrandmsg3(resultSet.getString("C_CUR_BRAND_MSG_3"));
				ub.setBrandmsg4(resultSet.getString("C_CUR_BRAND_MSG_4"));
				ub.setBrandmsg5(resultSet.getString("C_CUR_BRAND_MSG_5"));
				ub.setBrandmsg6(resultSet.getString("C_CUR_BRAND_MSG_6"));
				ub.setBrandmsg7(resultSet.getString("C_CUR_BRAND_MSG_7"));
				ub.setConvexchmark(resultSet.getString("C_CUR_CONV_EXCH_FLAG"));
				ub.setVipmsg1(resultSet.getString("C_CUR_VIP_MSG_1"));
				ub.setVipmsg2(resultSet.getString("C_CUR_VIP_MSG_2"));
				ub.setVipmsg3(resultSet.getString("C_CUR_VIP_MSG_3"));
				ub.setVipmsg4(resultSet.getString("C_CUR_VIP_MSG_4"));
				ub.setReprintflag(resultSet.getString("C_CUR_REPRINT_FLAG"));
				ub.setEmailflag(resultSet.getString("C_CUR_EMAIL_STMT_FLAG"));
				ub.setPaperflag(resultSet.getString("C_CUR_PAPER_STMT_FLAG"));
				ub.setEmailaddr(resultSet.getString("S_CUR_EMAIL_ADDR"));
				ub.setCusttype(resultSet.getString("S_CUR_CUSTOMER_TYPE"));
				ub.setMobilenbr(resultSet.getString("S_CUR_MOBILE_NBR"));
				ub.setAinbr(resultSet.getString("S_CUR_AI_NBR"));
				ub.setMobdate(resultSet.getString("C_CUR_MOB"));
				ub.setFiller(resultSet.getString("S_CUR_FILLER"));
				ub.setCity(resultSet.getString("S_CITY_ID"));
				ub.setCrlim(resultSet.getString("I_CUR_CRLIM"));
				ub.setCurrbal(resultSet.getString("I_CUR_BAL"));
				ub.setTotdueamt(resultSet.getString("I_CUR_TOT_DUE_AMT"));
				ub.setCashcrlim(resultSet.getString("I_CUR_CASH_CRLIM"));
				ub.setStmtdate(resultSet.getString("C_STMT_DATE"));
				ub.setCardNo(resultSet.getString("S_CARD_PROD_ID"));
				list.add(ub);
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public List<mcc> getMCCInfo() {
		List<mcc> list = new ArrayList<mcc>();
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement("select * from T_S_MCC_INFO t order by S_TYPE,s_id");
			ResultSet resultSet = pstmt.executeQuery();
			mcc m = null;
			while (resultSet.next()) {
				m = new mcc();
				m.setType(resultSet.getString("S_TYPE"));
				m.setTypeName(resultSet.getString("S_TYPE_NAME"));
				m.setId(resultSet.getString("S_ID"));
				m.setName(resultSet.getString("S_NAME"));
				list.add(m);
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public Map<String, String> getMCCMap(String type) {
		Map<String, String> map = new HashMap<String, String>();
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement("select * from T_S_MCC_INFO t order by S_TYPE,s_id");
			ResultSet resultSet = pstmt.executeQuery();

			while (resultSet.next()) {
				map.put(resultSet.getString("S_ID"), type == "" ? "" : resultSet.getString(type));
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return map;
	}

	public List<RuleMNew> getNewRuleMap(String period, String ruleType) {
		List<RuleMNew> list = new ArrayList<RuleMNew>();
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn
					.prepareStatement("SELECT * FROM T_S_RULE_M_E WHERE C_PERIOD = ? AND S_TYPE = ? ");
			pstmt.setString(1, period);
			pstmt.setString(2, ruleType);
			ResultSet resultSet = pstmt.executeQuery();
			RuleMNew bean = null;
			while (resultSet.next()) {
				bean = new RuleMNew();
				bean.setRuleNo(resultSet.getString("S_RULE_NO"));
				bean.setPeriod(resultSet.getString("C_PERIOD"));
				bean.setCardId(resultSet.getString("S_CARD_ID"));
				bean.setCityNo(resultSet.getString("S_CITY_NO"));
				list.add(bean);
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public Map<String, String> getProdIdMapping() {
		Map<String, String> map = new HashMap<String, String>();
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement("select * from t_s_dd");
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				map.put(resultSet.getString("s_html_card_prod_id"), resultSet.getString("s_html5_card_prod_id"));
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return map;
	}

	public List<UserAccinfo> getUserInfo(UserBase base) {
		List<UserAccinfo> list = new ArrayList<UserAccinfo>();
		StringBuffer sql = new StringBuffer();
		sql.append("select ");
		sql.append("acctnbr,rectype,stmtdate,pmtdate,to_char(totbegbal,'fm9999999999999999990.00') as totbegbal");
		sql.append(",to_char(plantotpmt,'fm9999999999999999990.00') as plantotpmt");
		sql.append(
				",to_char(plantotnrlamt,'fm9999999999999999990.00') as plantotnrlamt,to_char(plantotadjamt,'fm9999999999999999990.00') as plantotadjamt");
		sql.append(
				",to_char(intdueamt,'fm9999999999999999990.00') as intdueamt,to_char(currbal,'fm9999999999999999990.00') as currbal");
		sql.append(
				",to_char(totdueamt,'fm9999999999999999990.00') as totdueamt,pmtprint,to_char(crlim,'fm9999999999999999990.00') as crlim,to_char(cashcrlim,'fm9999999999999999990.00') as cashcrlim");
		sql.append(
				",pmtarn,pmtadn,to_char(projap,'fm9999999999999999990.00') as projap,pmtaflag,achflag,pmtflag,filler");
		sql.append(" from view_b_customer_bill t where t.acctnbr=? and t.stmtdate=?");
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, base.getAcctnbr());
			pstmt.setString(2, base.getStmtdate());
			ResultSet resultSet = pstmt.executeQuery();

			while (resultSet.next()) {
				UserAccinfo ub = new UserAccinfo();
				ub.setAcctnbr(resultSet.getString("acctnbr"));
				ub.setRectype(resultSet.getString("rectype"));
				ub.setStmtdate(resultSet.getString("stmtdate"));
				ub.setPmtdate(resultSet.getString("pmtdate"));
				ub.setTotbegbal(resultSet.getString("totbegbal"));
				ub.setPlantotpmt(resultSet.getString("plantotpmt"));
				ub.setPlantotnrlamt(resultSet.getString("plantotnrlamt"));
				ub.setPlantotadjamt(resultSet.getString("plantotadjamt"));
				ub.setIntdueamt(resultSet.getString("intdueamt"));
				ub.setCurrbal(resultSet.getString("currbal"));
				ub.setTotdueamt(resultSet.getString("totdueamt"));
				ub.setPmtprint(resultSet.getString("pmtprint"));
				ub.setCrlim(resultSet.getString("crlim"));
				ub.setCashcrlim(resultSet.getString("cashcrlim"));
				ub.setPmtarn(resultSet.getString("pmtarn"));
				ub.setPmtadn(resultSet.getString("pmtadn"));
				ub.setProjap(resultSet.getString("projap"));
				ub.setPmtaflag(resultSet.getString("pmtaflag"));
				ub.setAchflag(resultSet.getString("achflag"));
				ub.setPmtflag(resultSet.getString("pmtflag"));
				ub.setFiller(resultSet.getString("filler"));
				list.add(ub);
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public List<UserAccinfoDetail> getAccinfoDetail(UserBase user) {
		List<UserAccinfoDetail> list = new ArrayList<UserAccinfoDetail>();
		StringBuffer sb = new StringBuffer();
		sb.append("select ")
				.append("acctnbr,rectype,recseq,effdate,postdate,cardnlast4,curdesc,to_char(txnamt,'fm9999999999999999990.00') as txnamt,")
				.append("to_char(srctamt,'fm9999999999999999990.00') as srctamt,srctcurr,purcty,filler")
				.append(",catcode,cardnbr,accid,txncode,mainacc,cnname,pyname,cardname")
				.append(" from view_b_customer_bill_detail t where t.acctnbr=?")
				.append(" order by t.rectype, t.cardnbr, t.postdate, t.recseq");
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sb.toString());
			pstmt.setString(1, user.getAcctnbr());
			ResultSet resultSet = pstmt.executeQuery();

			while (resultSet.next()) {
				UserAccinfoDetail ub = new UserAccinfoDetail();
				ub.setAcctnbr(resultSet.getString("acctnbr"));
				ub.setRectype(resultSet.getString("rectype"));
				ub.setRecseq(resultSet.getString("recseq"));
				ub.setEffdate(resultSet.getString("effdate"));
				ub.setPostdate(resultSet.getString("postdate"));
				ub.setCardnlast4(resultSet.getString("cardnlast4"));
				ub.setDesc(resultSet.getString("curdesc"));
				ub.setTxnamt(resultSet.getString("txnamt"));
				ub.setSrctamt(resultSet.getString("srctamt"));
				ub.setSrctcurr(resultSet.getString("srctcurr"));
				ub.setPurcty(resultSet.getString("purcty"));
				ub.setFiller(resultSet.getString("filler"));
				ub.setMcc(resultSet.getString("catcode"));
				ub.setCardNbr(resultSet.getString("cardnbr"));
				ub.setAcceptorNbr(resultSet.getString("accid"));
				ub.setTxnCode(resultSet.getString("txncode"));
				ub.setMainAccount(resultSet.getString("mainacc"));
				ub.setCnName(resultSet.getString("cnname"));
				ub.setPyName(resultSet.getString("pyname"));
				ub.setCardName(resultSet.getString("cardname"));
				list.add(ub);
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public UserBuy getUserBuy(UserBase user) {
		UserBuy ub = null;
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn
					.prepareStatement("select * from T_B_CUSTOMER_PURCHASE t where t.S_ACCOUNT=?");
			pstmt.setString(1, user.getAcctnbr());
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				ub = new UserBuy();
				ub.setAcctnbr(resultSet.getString("S_ACCOUNT"));
				ub.setRectype(resultSet.getString("S_CUR_PUR_REC_TYPE"));
				ub.setExchusdamt(resultSet.getString("I_CUR_PUR_EXCH_USD_AMT"));
				ub.setSellrate(resultSet.getString("I_CUR_PUR_SELL_RATE"));
				ub.setExchrmbamt(resultSet.getString("I_CUR_PUR_EXCH_RMB_AMT"));
				ub.setAchrtnbr(resultSet.getString("S_CUR_PUR_PMT_ACH_RT_NBR"));
				ub.setAchdbnbr(resultSet.getString("S_CUR_PUR_PMT_ACH_DB_NBR"));
				ub.setFiller(resultSet.getString("S_CUR_PUR_FILLER"));
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return ub;
	}

	public List<Debitinfo> getDebitinfo(UserBase user) {
		List<Debitinfo> list = new ArrayList<Debitinfo>();
		Debitinfo deb = null;
		StringBuffer sb = new StringBuffer();
		sb.append("select ");
		sb.append(
				"acctnbr,rectype,custnbr,effdate,txndesc,txncity,currcode,NVL(to_char(txnamt,'fm9999999999999999999990.00'),' ') as txnamt");
		sb.append(",cardl4,filler");
		sb.append(" from view_b_crad_trade_detail t where t.acctnbr=? order by rectype, effdate, cardl4");
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sb.toString());
			pstmt.setString(1, user.getAcctnbr());
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				deb = new Debitinfo();
				deb.setAcctnbr(resultSet.getString("acctnbr"));
				deb.setRectype(resultSet.getString("rectype"));
				deb.setCustnbr(resultSet.getString("custnbr"));
				deb.setEffdate(resultSet.getString("effdate"));
				deb.setTxndesc(resultSet.getString("txndesc"));
				deb.setTxncity(resultSet.getString("txncity"));
				deb.setCurrcode(resultSet.getString("currcode"));
				deb.setTxnamt(resultSet.getString("txnamt"));
				deb.setCardl4(resultSet.getString("cardl4"));
				deb.setFiller(resultSet.getString("filler"));
				list.add(deb);
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return list;
	}

	public List<Stageplan> getStageplan(UserBase user) {
		List<Stageplan> list = new ArrayList<Stageplan>();
		Stageplan sta = null;
		StringBuffer sb = new StringBuffer();
		sb.append("select ").append("s_stagetype").append(",i_totalstage as totalstage")
				.append(",i_accstage as accstage")
				.append(",NVL(to_char(i_totalamt,'fm9999999999999999999990.00'),' ') as totalamt")
				.append(",NVL(to_char(i_unaccamt,'fm9999999999999999999990.00'),' ') as unaccamt")
				.append(",NVL(to_char(i_stagefee,'fm9999999999999999999990.00'),' ') as stagefee")
				.append(",NVL(to_char(i_unaccfee,'fm9999999999999999999990.00'),' ') as unaccfee")
				.append(" from T_B_CUSTOMER_STAGEPLAN where s_account=? and C_STMT_DATE=? ORDER BY S_STAGETYPE, I_TOTALSTAGE, I_ACCSTAGE");
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sb.toString());
			pstmt.setString(1, user.getAcctnbr());
			pstmt.setString(2, user.getStmtdate());
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				sta = new Stageplan();
				sta.setStagetype(resultSet.getString("s_stagetype"));
				sta.setTotalstage(resultSet.getInt("totalstage"));
				sta.setAccstage(resultSet.getInt("accstage"));
				sta.setTotalamt(resultSet.getString("totalamt"));
				sta.setUnaccamt(resultSet.getString("unaccamt"));
				sta.setStagefee(resultSet.getString("stagefee"));
				sta.setUnaccfee(resultSet.getString("unaccfee"));
				list.add(sta);
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return list;
	}

	public List<PointInfo> getPoint(UserBase user) {
		List<PointInfo> list = new ArrayList<PointInfo>();
		PointInfo p = null;
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(
					"select S_POINT_TYPE,S_ACCT_PROD_ID,S_BUSINESS_ID,I_ABLE_POINT,I_LASTBAL_POINT,I_ADDPOINT_POINT,I_EXPOINT_POINT,I_ADPOINTS_POINT,I_ENDPOINTS_POINT,S_ECIF_NO,S_START_DATE,S_END_DATE,to_char(I_WHOLE_CONSUME,'fm99999990.00') as I_WHOLE_CONSUME,to_char(I_IN_CONSUME,'fm99999990.00') as I_IN_CONSUME,to_char(I_OUT_CONSUME,'fm99999990.00') as I_OUT_CONSUME,to_char(I_WHOLE_MONEY,'fm99999990.00') as I_WHOLE_MONEY,to_char(I_IN_MONEY,'fm99999990.00') as I_IN_MONEY,to_char(I_OUT_MONEY,'fm99999990.00') as I_OUT_MONEY,to_char(I_USED_MONEY,'fm99999990.00') as I_USED_MONEY,to_char(I_LAVE_MONEY,'fm99999990.00') as I_LAVE_MONEY,S_VALID_DATE,I_LADDER_MONEY,S_LADDER_SCALE,C_CARD_LAST4,C_CARD_POINT_TYPE,S_CARD_POINT_NAME from t_b_point_x where S_BUSINESS_ID=? and C_STMT_DATE=?");

			pstmt.setString(1, user.getAcctnbr());
			pstmt.setString(2, user.getStmtdate());
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				p = new PointInfo();
				p.setPointtype(resultSet.getString("S_POINT_TYPE"));
				p.setCardportid(resultSet.getString("S_ACCT_PROD_ID"));
				p.setBusinessid(resultSet.getString("S_BUSINESS_ID"));
				p.setAblepoint(resultSet.getString("I_ABLE_POINT"));
				p.setLastbalpoint(resultSet.getString("I_LASTBAL_POINT"));
				p.setAddpoint(resultSet.getString("I_ADDPOINT_POINT"));
				p.setExpoint(resultSet.getString("I_EXPOINT_POINT"));
				p.setAdpoints(resultSet.getString("I_ADPOINTS_POINT"));
				p.setEndpoints(resultSet.getString("I_ENDPOINTS_POINT"));

				p.setEcifno(resultSet.getString("S_ECIF_NO"));
				p.setStartdate(resultSet.getString("S_START_DATE"));
				p.setEnddate(resultSet.getString("S_END_DATE"));
				p.setWholeconsume(resultSet.getString("I_WHOLE_CONSUME"));
				p.setInconsume(resultSet.getString("I_IN_CONSUME"));
				p.setOutconsume(resultSet.getString("I_OUT_CONSUME"));
				p.setWholemoney(resultSet.getString("I_WHOLE_MONEY"));
				p.setInmoney(resultSet.getString("I_IN_MONEY"));
				p.setOutmoney(resultSet.getString("I_OUT_MONEY"));
				p.setUsedmoney(resultSet.getString("I_USED_MONEY"));
				p.setLavemoney(resultSet.getString("I_LAVE_MONEY"));
				p.setValiddate(resultSet.getString("S_VALID_DATE"));
				p.setLaddermoney(resultSet.getString("I_LADDER_MONEY"));
				p.setLadderscale(resultSet.getString("S_LADDER_SCALE"));
				p.setCard4(resultSet.getString("C_CARD_LAST4"));
				p.setCardPointType(resultSet.getString("C_CARD_POINT_TYPE"));
				p.setCardname(resultSet.getString("S_CARD_POINT_NAME"));
				list.add(p);
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return list;
	}

	public PointInfo getPoint2(UserBase user) {
		PointInfo p = null;
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn
					.prepareStatement("select * from T_B_POINT_W where S_ECIF_NO=? and C_STMT_DATE=?");
			if (user.getCusnum().length() > 12) {
				pstmt.setString(1, user.getCusnum().substring(7));
			} else {
				pstmt.setString(1, user.getCusnum());
			}
			pstmt.setString(2, user.getStmtdate());
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				p = new PointInfo();
				p.setBilldate(resultSet.getString("C_STMT_DATE"));
				p.setBusinessid(resultSet.getString("S_ECIF_NO"));
				p.setAblepoint(resultSet.getString("I_ENDPOINT"));
				p.setEndpoints(resultSet.getString("I_VALIDPOINT_B"));
				p.setLastbalpoint(resultSet.getString("I_NEWPOINT"));
				p.setAddpoint(resultSet.getString("I_USEDPOINT"));
				p.setExpoint(resultSet.getString("I_ADJUSTPOINT"));
				p.setAdpoints(resultSet.getString("I_INVAILPOINT"));
				p.setExpirespoint(resultSet.getString("I_EXPIRES_POINT"));
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return p;
	}

	public Map<String, String> getTemplateList() {
		Map<String, String> map = new HashMap<String, String>();
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(TEMPLATE_SQL);
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				map.put(resultSet.getString("S_CARD_PROD_ID") + "_" + resultSet.getString("C_TYPE_NO"),
						resultSet.getString("S_STENCIL_NO"));
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return map;
		}
		return map;
	}

	public List<Rule> getRule(String tid, String type, String area, String billdayYM, String billdayD) {
		List<Rule> list = new ArrayList<Rule>();
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(RULE_SQL);
			pstmt.setString(1, tid);
			pstmt.setString(2, type);
			pstmt.setString(3, area);
			pstmt.setString(4, billdayYM);
			pstmt.setString(5, billdayYM);
			pstmt.setString(6, billdayD);
			ResultSet resultSet = pstmt.executeQuery();

			while (resultSet.next()) {
				Rule r = new Rule();
				r.setRuleid(resultSet.getString("S_RULE_NO"));
				r.setTid(resultSet.getString("S_STENCIL_NO"));
				r.setRuleType(resultSet.getString("C_RULE_TYPE"));
				r.setType(resultSet.getString("C_TYPENO"));
				r.setPri(resultSet.getString("I_PRI"));
				r.setAreaNo(resultSet.getString("I_AREA_NO"));
				list.add(r);
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public List<RuleF> getRuleF(String rid) {
		List<RuleF> list = new ArrayList<RuleF>();
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn
					.prepareStatement("select * from t_s_rule_f t where t.s_rule_no=? order by t.i_pri desc");
			pstmt.setString(1, rid);
			ResultSet resultSet = pstmt.executeQuery();

			while (resultSet.next()) {
				RuleF r = new RuleF();
				r.setId(resultSet.getString("S_SEQUENCE"));
				r.setRid(resultSet.getString("S_RULE_NO"));
				r.setFodder(resultSet.getString("S_FODDER_NO"));
				r.setPri(resultSet.getString("I_PRI"));
				list.add(r);
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public List<RuleM> getRuleFF(String rid) {
		List<RuleM> list = new ArrayList<RuleM>();
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn
					.prepareStatement("select * from t_s_rule_ff t where t.s_sequence=? order by t.s_idx");
			pstmt.setString(1, rid);
			ResultSet resultSet = pstmt.executeQuery();

			while (resultSet.next()) {
				RuleM r = new RuleM();
				r.setFieldid(resultSet.getString("S_FIELD"));
				r.setOpr1(resultSet.getInt("C_OPR_1"));
				r.setVal1(resultSet.getString("S_VALIUE_1"));
				r.setOpr2(resultSet.getInt("C_OPR_2"));
				r.setVal2(resultSet.getString("S_VALIUE_2"));
				r.setCif(resultSet.getInt("C_IF"));
				list.add(r);
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public List<TempArea> getTemplateInfo(String tid) {
		List<TempArea> list = new ArrayList<TempArea>();
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn
					.prepareStatement("select t.i_area_no,t.c_type_no from t_s_area t where t.s_stencil_no=?");
			pstmt.setString(1, tid);
			ResultSet resultSet = pstmt.executeQuery();

			while (resultSet.next()) {
				TempArea ta = new TempArea();
				ta.setArea(resultSet.getString("i_area_no"));
				ta.setType(resultSet.getString("c_type_no"));
				list.add(ta);
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public Fodder getFodder(String fid, String d) {
		Fodder fodder = null;
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(
					"select t.s_fodder_no,t.s_fodder_doc_name,t.s_url from T_S_FODDER  t where t.s_fodder_no=? and t.c_state='1' and to_date(?, 'yyyyMM') between to_date(t.c_period_begen, 'yyyy-MM') and to_date(t.c_period_end, 'yyyy-MM')");
			pstmt.setString(1, fid);
			pstmt.setString(2, d);
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				fodder = new Fodder();
				fodder.setFid(resultSet.getString("s_fodder_no"));
				fodder.setUrl(resultSet.getString("s_fodder_doc_name"));
				fodder.setLinkurl(resultSet.getString("s_url"));
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			this.log.error("素材查询失败！1=" + fid + ",2=" + d);
			e.printStackTrace();
			return null;
		}
		return fodder;
	}

	public List<Foldout> getFoldout(String bid, String cid, String billdate) {
		List<Foldout> list = new ArrayList<Foldout>();
		Foldout foldout = null;
		try {
			String sql = "select I_FOLDOUT_INDEX,S_FOLDOUT_PROD_NAME,I_FOLDOUT_PRI,C_FOLDOUT_STATE,I_ID from T_S_FOLDOUT_PROD t2 where t2.i_id =(select t.i_id from T_S_FOLDOUT_PROD_SUB t where t.s_foldout_businpnt_no = ? and t.s_foldout_prod_bpid = ? and t.c_period = ? and to_date(?,'yyyyMM') between to_date(t.c_period_begen,'yyyy-MM') and to_date(t.c_period_end,'yyyy-MM')) order by t2.i_foldout_index";
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bid);
			pstmt.setString(2, cid);
			pstmt.setString(3, billdate.substring(6));
			pstmt.setString(4, billdate.substring(0, 6));
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				foldout = new Foldout();
				foldout.setId(resultSet.getString("I_ID"));
				foldout.setName(resultSet.getString("S_FOLDOUT_PROD_NAME"));
				foldout.setPri(resultSet.getInt("I_FOLDOUT_PRI"));
				foldout.setState(resultSet.getString("C_FOLDOUT_STATE"));
				foldout.setIdx(resultSet.getString("I_FOLDOUT_INDEX"));
				list.add(foldout);
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			return list;
		}
	}

	public Map<String, String> getFoldoutCity(String id, String idx) {
		Map<String, String> map = new HashMap<String, String>();
		String city = "";
		try {
			String sql = "select t.s_foldout_city from t_s_foldout_city t where t.i_id=? and t.i_foldout_index=?";
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, idx);
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				city = resultSet.getString("s_foldout_city");
				map.put(city, city);
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			return map;
		}
	}

	public boolean clearDBLog(String period) {

		boolean bool;
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement("delete T_B_XML_LOG where S_PERIOD = ? and c_type = ?");
			pstmt.setString(1, period);
			pstmt.setString(2, "0");
			pstmt.executeUpdate();
			bool = true;

			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			bool = false;
			this.log.error("清除生成日志失败, (" + period + "), " + e.getMessage());
			e.printStackTrace();

		}
		return bool;
	}

	public boolean clearDBLog(String period, List<String> cardId) {
		PreparedStatement ps = null;
		boolean bool;
		try {
			StringBuilder sb = new StringBuilder(
					"delete T_B_XML_LOG where S_PERIOD = ? and c_type = ? and S_CARD_PROD_ID in (");
			for (String s : cardId) {
				sb.append("'").append(s).append("',");
			}
			sb.delete(sb.length() - 1, sb.length());
			sb.append(")");
			Connection conn = DataSource.getInstance().getConnection();
			ps = conn.prepareStatement(sb.toString());
			ps.setString(1, period);
			ps.setString(2, "0");
			ps.executeUpdate();
			bool = true;
			
			ps.close();
			conn.close();
		} catch (SQLException e) {
			bool = false;
			this.log.error("清除生成日志失败, (" + period + ", " + cardId + "), " + e.getMessage());
			e.printStackTrace();

		} 
		return bool;
	}

	public boolean recordDBLog(Plog plog) {

		boolean bool;
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement ps = conn.prepareStatement(
					"insert into T_B_XML_LOG (S_PERIOD, S_FILENAME, S_BUSINPNT_NO, I_SHARE, C_START_TIME, C_END_TIME, S_CARD_PROD_ID, S_PAPER_NO, C_STATE, I_SHARE_ERROR) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

			ps.setString(1, plog.getStmtdate());
			ps.setString(2, plog.getFilename());
			ps.setString(3, plog.getBusinpnt_no());
			ps.setInt(4, plog.getShare());
			ps.setString(5, plog.getStart_time());
			ps.setString(6, plog.getEnd_time());
			ps.setString(7, plog.getCard_id());
			ps.setString(8, plog.getPaper_no());
			ps.setString(9, plog.getState());
			ps.setInt(10, plog.getError());
			ps.execute();
			bool = true;

			ps.close();
			conn.close();
		} catch (SQLException e) {
			bool = false;
			this.log.error("新增生成日志失败, " + plog + ", " + e.getMessage());
			e.printStackTrace();
		}
		return bool;
	}

	public Map<String, String> getConfig() {
		Map<String, String> cmap = new HashMap<String, String>();
		try {
			Connection conn = DataSource.getInstance().getConnection();
			ResultSet resultSet = conn
					.prepareStatement("select t.s_type,t.s_value from t_s_bill_para t").executeQuery();
			while (resultSet.next())
				cmap.put(resultSet.getString("s_type"), resultSet.getString("s_value"));
			resultSet.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
			return cmap;
		}
		return cmap;
	}

	public void cleanWatchState() {
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement("delete T_B_WATCH_STATE where S_PERIOD=?");
			pstmt.setString(1, BaseParam.PERIOD_Y_M_D);
			pstmt.executeUpdate();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void beginWatchState() {
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String sPrintTime = format1.format(new Date());
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(
					"insert into T_B_WATCH_STATE(S_PERIOD,C_WATCH_TIME,C_WATCH_TYPE,C_WATCH_STATE) values(?,?,'1','2')");
			pstmt.setString(1, BaseParam.PERIOD_Y_M_D);
			pstmt.setString(2, sPrintTime);
			pstmt.executeUpdate();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void endWatchState(String state) {
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String sPrintTime = format1.format(new Date());
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(
					"update T_B_WATCH_STATE set C_WATCH_STATE=?,C_WATCH_FINISH_TIME=? where S_PERIOD=? and C_WATCH_TYPE='1' and C_WATCH_STATE='2'");
			pstmt.setString(1, state);
			pstmt.setString(2, sPrintTime);
			pstmt.setString(3, BaseParam.PERIOD_Y_M_D);
			pstmt.executeUpdate();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void beginWatch() {
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String sPrintTime = format1.format(new Date());
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn
					.prepareStatement("update T_S_WATCH set C_START_TIME=?,C_STATE='1' WHERE I_ID=2");
			pstmt.setString(1, sPrintTime);
			pstmt.executeUpdate();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void endWatch() {
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String sPrintTime = format1.format(new Date());
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn
					.prepareStatement("update T_S_WATCH set C_END_TIME=?,C_STATE='2' WHERE I_ID=2");
			pstmt.setString(1, sPrintTime);
			pstmt.executeUpdate();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public Map<String, PaperRelatingWrap> getCityYyyzWbsByCard(String cardId) {
		Map<String, String> map = new HashMap<String, String>();
		PaperRelatingWrap prw = null;
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(CityYyyzWbsByCard_SQL);
			pstmt.setString(1, BaseParam.PERIOD_Y + "-" + BaseParam.PERIOD_M);
			pstmt.setString(2, BaseParam.PERIOD_D);
			pstmt.setString(3, cardId);
			ResultSet resultSet = pstmt.executeQuery();
			String city = "";
			while (resultSet.next()) {
				city = resultSet.getString("S_CITY_NO");

				if (!map.containsKey(city)) {
					prw = new PaperRelatingWrap();
					prw.setBusin(resultSet.getString("S_BUSINPNT_NO"));
					prw.setCity(city);
					prw.setYyzNo(resultSet.getString("S_PAPER_NO"));
					prw.setYyzId(resultSet.getString("S_ID"));
					map.put(city, prw);
				}
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return map;
	}

	public Map<String, String> queryFQJY() {
		Map<String, String> map = new HashMap<String, String>();
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement("select * from T_S_TRADE_NUMBER t");
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				map.put(resultSet.getString("c_trade_num"), "");
			}
			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return map;
	}

	public ArrayList<HisAmountBean> queryHisAmount(String account, String period) {
		HisAmountBean bean = null;
		ArrayList<HisAmountBean> data = new ArrayList<HisAmountBean>();
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn
					.prepareStatement("SELECT * FROM T_B_BILL_HIS_AMOUNT WHERE S_ACCOUNT = ? AND S_PERIOD = ?");
			pstmt.setString(1, account);
			pstmt.setString(2, period);
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next()) {
				bean = new HisAmountBean();
				bean.setAccount(resultSet.getString("s_account"));
				bean.setType(resultSet.getString("s_type"));
				bean.setPeriod(resultSet.getString("s_period"));
				for (int i = 1; i < 13; i++) {
					bean.setAmount(i, resultSet.getString("i_amt_" + i));
				}
				data.add(bean);

				resultSet.close();
				pstmt.close();
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();

		}
		return data;
	}

	public Map<String, String> queryStageType() {
		Map<String, String> map = new HashMap<String, String>();
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM t_s_stageplan");
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next())
				map.put(resultSet.getString("s_stagetype"), resultSet.getString("s_stagetype_name"));

			resultSet.close();
			pstmt.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();

		}
		return map;
	}

	public String queryAsset(String account) {
		String returnStr = "";
		try {
			Connection conn = DataSource.getInstance().getConnection();
			PreparedStatement pstmt = conn.prepareStatement(
					"select * from t_b_customer_asset WHERE s_account = ? ORDER BY s_rec_type", 1005, 1008);
			pstmt.setString(1, account);
			ResultSet resultSet = pstmt.executeQuery();

			if (resultSet.last()) {
				resultSet.first();
				returnStr = returnStr + resultSet.getString("s_desc").trim();
			}
			while (resultSet.next()) {
				returnStr = returnStr + "、" + resultSet.getString("s_desc").trim();
			}
			if (!"".equals(returnStr))
				returnStr = returnStr + "。";

			resultSet.close();
			pstmt.close();
			conn.close();

		} catch (SQLException e) {
			e.printStackTrace();
			return returnStr;
		}
	}
}
