/*    */ package com.bill.normal;
/*    */ 
/*    */ import com.bill.bean.Card;
/*    */ import com.bill.bean.UserBase;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.concurrent.BlockingQueue;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class TaskData
/*    */   implements Runnable
/*    */ {
/* 19 */   private static Logger log = Logger.getLogger(TaskData.class);
/*    */   private DBDao dao;
/*    */   private int maxBatchNumber;
/*    */   private int maxThreedNumber;
/* 23 */   private int queryNum = 0;
/*    */   private Card card;
/*    */   private BlockingQueue<List<UserBase>> queue;
/*    */ 
/*    */   public TaskData(int maxBatchNumber, int maxThreedNumber, BlockingQueue<List<UserBase>> queue, Card card)
/*    */   {
/* 30 */     this.maxBatchNumber = maxBatchNumber;
/* 31 */     this.maxThreedNumber = maxThreedNumber;
/* 32 */     this.queue = queue;
/* 33 */     this.dao = DBDao.getInstance();
/* 34 */     this.card = card;
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/* 39 */     log.debug(this.card.getName() + "(" + this.card.getId() + ")  查询线程开始执行");
/* 40 */     int page = 0;
/* 41 */     List userList = null;
/*    */     while (true) {
/*    */       try {
/* 44 */         Thread.sleep(150L);
/*    */       }
/*    */       catch (InterruptedException e1) {
/* 47 */         e1.printStackTrace();
/*    */       }
/*    */       try {
/* 50 */         userList = this.dao.getUserBase(this.card.getId(), ++page, this.maxBatchNumber);
/*    */       } catch (Exception e) {
/* 52 */         log.error(this.card.getName() + "(" + this.card.getId() + ")  查询异常, 当前批次" + (page - 1) + 
/* 53 */           " " + e.getMessage());
/* 54 */         e.printStackTrace();
/* 55 */         break label265;
/*    */       }
/* 57 */       if (userList.size() == 0) {
/* 58 */         log.debug(this.card.getName() + "(" + this.card.getId() + ")  查询线程查询完成, 共" + this.queryNum + "条");
/*    */       }
/*    */       else {
/* 61 */         this.queryNum += userList.size();
/*    */         try {
/* 63 */           this.queue.put(userList);
/*    */         } catch (Exception e) {
/* 65 */           e.printStackTrace();
/*    */         }
/*    */       }
/*    */     }
/* 69 */     label265: for (int i = 0; i < this.maxThreedNumber; i++) {
/*    */       try {
/* 71 */         this.queue.put(Collections.EMPTY_LIST);
/*    */       } catch (InterruptedException e) {
/* 73 */         e.printStackTrace();
/*    */       }
/*    */     }
/* 76 */     this.dao.close();
/*    */ 
/* 78 */     log.debug(this.card.getName() + "(" + this.card.getId() + ")  查询线程结束执行.");
/*    */   }
/*    */ 
/*    */   public int getQueryNum() {
/* 82 */     return this.queryNum;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.normal.TaskData
 * JD-Core Version:    0.6.2
 */