/*     */ package com.bill.normal;
/*     */ 
/*     */ public class UserXmlBuildProxy extends UserXmlBuild
/*     */ {
/*     */   public String getEmailXml()
/*     */   {
/*  10 */     long xml_temp = System.currentTimeMillis();
/*     */ 
/*  12 */     String temp = getAccInfo();
/*  13 */     if (temp == null)
/*  14 */       return null;
/*  15 */     this.xml_setup3 = (System.currentTimeMillis() - xml_temp);
/*     */ 
/*  18 */     StringBuilder sb = new StringBuilder();
/*  19 */     sb.append("<checksheet>\n");
/*     */ 
/*  23 */     sb.append(getBaseInfo());
/*  24 */     this.xml_setup1 = (System.currentTimeMillis() - xml_temp);
/*     */ 
/*  27 */     xml_temp = System.currentTimeMillis();
/*  28 */     sb.append("<ENVRULE>0000</ENVRULE>\n")
/*  29 */       .append("<INPRIORITY1>0</INPRIORITY1>\n")
/*  30 */       .append("<INPRIORITY2>0</INPRIORITY2>\n")
/*  31 */       .append("<INPRIORITY3>0</INPRIORITY3>\n")
/*  32 */       .append("<INPRIORITY4>0</INPRIORITY4>\n");
/*  33 */     this.xml_setup2 = (System.currentTimeMillis() - xml_temp);
/*     */ 
/*  36 */     sb.append(temp);
/*     */ 
/*  39 */     xml_temp = System.currentTimeMillis();
/*  40 */     sb.append(getAccInfoDetail());
/*  41 */     this.xml_setup4 = (System.currentTimeMillis() - xml_temp);
/*     */ 
/*  44 */     xml_temp = System.currentTimeMillis();
/*  45 */     sb.append(getBuy());
/*  46 */     this.xml_setup5 = (System.currentTimeMillis() - xml_temp);
/*     */ 
/*  49 */     xml_temp = System.currentTimeMillis();
/*  50 */     sb.append(getDebitInfo());
/*  51 */     this.xml_setup6 = (System.currentTimeMillis() - xml_temp);
/*     */ 
/*  54 */     xml_temp = System.currentTimeMillis();
/*  55 */     sb.append(getPoint());
/*  56 */     this.xml_setup7 = (System.currentTimeMillis() - xml_temp);
/*     */ 
/*  59 */     xml_temp = System.currentTimeMillis();
/*  60 */     sb.append(getEmailTemplate());
/*  61 */     this.xml_setup8 = (System.currentTimeMillis() - xml_temp);
/*  62 */     sb.append("</checksheet>\n");
/*  63 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String getPaperXml(String wbs)
/*     */   {
/*  72 */     long xml_temp = System.currentTimeMillis();
/*     */ 
/*  74 */     String temp = getAccInfo();
/*  75 */     if (temp == null)
/*  76 */       return null;
/*  77 */     this.xml_setup3 = (System.currentTimeMillis() - xml_temp);
/*     */ 
/*  79 */     StringBuilder sb = new StringBuilder();
/*  80 */     sb.append("<checksheet>\n");
/*     */ 
/*  84 */     sb.append(getBaseInfo());
/*  85 */     this.xml_setup1 = (System.currentTimeMillis() - xml_temp);
/*     */ 
/*  88 */     xml_temp = System.currentTimeMillis();
/*  89 */     sb.append(getPaperEnvrule(wbs));
/*  90 */     this.xml_setup2 = (System.currentTimeMillis() - xml_temp);
/*     */ 
/*  93 */     sb.append(temp);
/*     */ 
/*  96 */     xml_temp = System.currentTimeMillis();
/*  97 */     sb.append(getAccInfoDetail());
/*  98 */     this.xml_setup4 = (System.currentTimeMillis() - xml_temp);
/*     */ 
/* 101 */     xml_temp = System.currentTimeMillis();
/* 102 */     sb.append(getBuy());
/* 103 */     this.xml_setup5 = (System.currentTimeMillis() - xml_temp);
/*     */ 
/* 106 */     xml_temp = System.currentTimeMillis();
/* 107 */     sb.append(getDebitInfo());
/* 108 */     this.xml_setup6 = (System.currentTimeMillis() - xml_temp);
/*     */ 
/* 111 */     xml_temp = System.currentTimeMillis();
/* 112 */     sb.append(getPoint());
/* 113 */     this.xml_setup7 = (System.currentTimeMillis() - xml_temp);
/*     */ 
/* 116 */     xml_temp = System.currentTimeMillis();
/* 117 */     sb.append(getPaperTemplate());
/* 118 */     this.xml_setup8 = (System.currentTimeMillis() - xml_temp);
/*     */ 
/* 120 */     sb.append("</checksheet>\n");
/* 121 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.normal.UserXmlBuildProxy
 * JD-Core Version:    0.6.2
 */