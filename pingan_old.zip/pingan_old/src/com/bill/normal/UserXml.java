 package com.bill.normal;
 
 import com.bill.bean.BaseParam;
 import com.bill.bean.Debitinfo;
 import com.bill.bean.Fodder;
 import com.bill.bean.Foldout;
 import com.bill.bean.HisAmountBean;
 import com.bill.bean.PointInfo;
 import com.bill.bean.Rule;
 import com.bill.bean.RuleF;
 import com.bill.bean.RuleM;
 import com.bill.bean.Stageplan;
 import com.bill.bean.TempArea;
 import com.bill.bean.UserAccinfo;
 import com.bill.bean.UserAccinfoDetail;
 import com.bill.bean.UserBase;
 import com.bill.bean.UserBuy;
 import com.bill.makeXML.util.file.HisAmountToXml;
 import com.bill.util.DESUtil;
 import java.net.URLEncoder;
 import java.util.ArrayList;
 import java.util.List;
 import java.util.Map;
 import org.apache.log4j.Logger;
 
 public class UserXml
 {
   private StringBuffer tab1;
   private StringBuffer tab2;
   private StringBuffer temp;
   private List<StringBuffer> tab2list;
   private List<UserAccinfo> listAccinfo;
   private List<UserAccinfoDetail> listAccinfoDetail;
   private List<Debitinfo> listDebitinfo;
   private List<PointInfo> listPointInfo;
   private List<TempArea> plist;
   private List<RuleF> rlist;
   private List<RuleM> mlist;
   private List<Rule> rulelist;
   private PointInfo point;
   private UserBuy userBuy;
   private DBDaoNew dao;
   private Logger log = null;
 
   private StringBuffer type1 = new StringBuffer();
   private StringBuffer type2 = new StringBuffer();
   private StringBuffer type3 = new StringBuffer();
   private StringBuffer type4 = new StringBuffer();
 
   private String cardid = "";
 
   boolean isExtis = false;
 
   private String ptId = "";
 
   public UserXml(DBDao dao)
   {
     this.log = Logger.getLogger(UserXml.class);
     this.dao = dao;
   }
 
   public String getBaseXml(UserBase ub)
   {
     StringBuffer str = new StringBuffer();
     str.append("<acctnbr>").append(ub.getAcctnbr()).append("</acctnbr>\n");
     str.append("<rectype>").append(ub.getRectype()).append("</rectype>\n");
     str.append("<zip>").append(ub.getZip()).append("</zip>\n");
     str.append("<addrname3>").append(ub.getAddrname3()).append("</addrname3>\n");
     str.append("<addrname1>").append(ub.getAddrname1()).append("</addrname1>\n");
     str.append("<addrname2>").append(ub.getAddrname2()).append("</addrname2>\n");
     str.append("<name>").append(ub.getName()).append("</name>\n");
     str.append("<sex>").append(ub.getSex()).append("</sex>\n");
     str.append("<birthday>").append(ub.getBirthday()).append("</birthday>\n");
     str.append("<accnum>").append(ub.getAccnum()).append("</accnum>\n");
     str.append("<cusnum>").append(ub.getCusnum()).append("</cusnum>\n");
     str.append("<stfromdate>").append(ub.getStfromdate()).append("</stfromdate>\n");
     str.append("<enddate>").append(ub.getEnddate()).append("</enddate>\n");
     str.append("<specode>").append(ub.getSpecode()).append("</specode>\n");
     str.append("<pmtduemark>").append(ub.getPmtduemark()).append("</pmtduemark>\n");
     str.append("<cashmark>").append(ub.getCashmark()).append("</cashmark>\n");
     str.append("<indiv1>").append(ub.getIndiv1()).append("</indiv1>\n");
     str.append("<indiv2>").append(ub.getIndiv2()).append("</indiv2>\n");
     str.append("<indiv3>").append(ub.getIndiv3()).append("</indiv3>\n");
     str.append("<indiv4>").append(ub.getIndiv4()).append("</indiv4>\n");
     str.append("<indiv5>").append(ub.getIndiv5()).append("</indiv5>\n");
     str.append("<indiv6>").append(ub.getIndiv6()).append("</indiv6>\n");
     str.append("<indiv7>").append(ub.getIndiv7()).append("</indiv7>\n");
     str.append("<indiv8>").append(ub.getIndiv8()).append("</indiv8>\n");
     str.append("<actinfo>").append(ub.getActinfo()).append("</actinfo>\n");
     str.append("<dm1>").append(ub.getDm1()).append("</dm1>\n");
     str.append("<dm2>").append(ub.getDm2()).append("</dm2>\n");
     str.append("<dm3>").append(ub.getDm3()).append("</dm3>\n");
     str.append("<dm4>").append(ub.getDm4()).append("</dm4>\n");
     str.append("<brandmsg1>").append(ub.getBrandmsg1()).append("</brandmsg1>\n");
     str.append("<brandmsg2>").append(ub.getBrandmsg2()).append("</brandmsg2>\n");
     str.append("<brandmsg3>").append(ub.getBrandmsg3()).append("</brandmsg3>\n");
     str.append("<brandmsg4>").append(ub.getBrandmsg4()).append("</brandmsg4>\n");
     str.append("<brandmsg5>").append(ub.getBrandmsg5()).append("</brandmsg5>\n");
     str.append("<brandmsg6>").append(ub.getBrandmsg6()).append("</brandmsg6>\n");
     str.append("<brandmsg7>").append(ub.getBrandmsg7()).append("</brandmsg7>\n");
     str.append("<convexchmark>").append(ub.getConvexchmark()).append("</convexchmark>\n");
     str.append("<vipmsg1>").append(ub.getVipmsg1()).append("</vipmsg1>\n");
     str.append("<vipmsg2>").append(ub.getVipmsg2()).append("</vipmsg2>\n");
     str.append("<vipmsg3>").append(ub.getVipmsg3()).append("</vipmsg3>\n");
     str.append("<vipmsg4>").append(ub.getVipmsg4()).append("</vipmsg4>\n");
     str.append("<reprintflag>").append(ub.getReprintflag()).append("</reprintflag>\n");
     str.append("<emailflag>").append(ub.getEmailflag()).append("</emailflag>\n");
     str.append("<paperflag>").append(ub.getPaperflag()).append("</paperflag>\n");
     str.append("<emailaddr>").append(ub.getEmailaddr()).append("</emailaddr>\n");
     str.append("<custtype>").append(ub.getCusttype()).append("</custtype>\n");
     str.append("<mobilenbr>").append(ub.getMobilenbr()).append("</mobilenbr>\n");
     str.append("<ainbr>").append(ub.getAinbr()).append("</ainbr>\n");
     str.append("<mobdate>").append(ub.getMobdate()).append("</mobdate>\n");
     str.append("<filler>").append(ub.getFiller()).append("</filler>\n");
     str.append("<citycode>").append(ub.getCity()).append("</citycode>\n");
     return str.toString();
   }
 
   public void writeBaseXml(UserBase ub, StringBuffer xml)
   {
     xml.append("<acctnbr>" + ub.getAcctnbr() + "</acctnbr>\n");
     xml.append("<rectype>" + ub.getRectype() + "</rectype>\n");
     xml.append("<zip>" + ub.getZip() + "</zip>\n");
     xml.append("<addrname3>" + ub.getAddrname3() + " </addrname3>\n");
     xml.append("<addrname1>" + ub.getAddrname1() + " </addrname1>\n");
     xml.append("<addrname2>" + ub.getAddrname2() + " </addrname2>\n");
     xml.append("<name>" + ub.getName() + " </name>\n");
     xml.append("<sex>" + ub.getSex() + "</sex>\n");
     xml.append("<birthday>" + ub.getBirthday() + "</birthday>\n");
     xml.append("<accnum>" + ub.getAccnum() + "</accnum>\n");
     xml.append("<cusnum>" + ub.getCusnum() + "</cusnum>\n");
     xml.append("<stfromdate>" + ub.getStfromdate() + "</stfromdate>\n");
     xml.append("<enddate>" + ub.getEnddate() + "</enddate>\n");
     xml.append("<specode>" + ub.getSpecode() + "</specode>\n");
     xml.append("<pmtduemark>" + ub.getPmtduemark() + "</pmtduemark>\n");
     xml.append("<cashmark>" + ub.getCashmark() + "</cashmark>\n");
     xml.append("<indiv1>" + ub.getIndiv1() + "</indiv1>\n");
     xml.append("<indiv2>" + ub.getIndiv2() + "</indiv2>\n");
     xml.append("<indiv3>" + ub.getIndiv3() + "</indiv3>\n");
     xml.append("<indiv4>" + ub.getIndiv4() + "</indiv4>\n");
     xml.append("<indiv5>" + ub.getIndiv5() + "</indiv5>\n");
     xml.append("<indiv6>" + ub.getIndiv6() + "</indiv6>\n");
     xml.append("<indiv7>" + ub.getIndiv7() + "</indiv7>\n");
     xml.append("<indiv8>" + ub.getIndiv8() + "</indiv8>\n");
     xml.append("<actinfo>" + ub.getActinfo() + "</actinfo>\n");
     xml.append("<dm1>" + ub.getDm1() + "</dm1>\n");
     xml.append("<dm2>" + ub.getDm2() + "</dm2>\n");
     xml.append("<dm3>" + ub.getDm3() + "</dm3>\n");
     xml.append("<dm4>" + ub.getDm4() + "</dm4>\n");
     xml.append("<brandmsg1>" + ub.getBrandmsg1() + "</brandmsg1>\n");
     xml.append("<brandmsg2>" + ub.getBrandmsg2() + "</brandmsg2>\n");
     xml.append("<brandmsg3>" + ub.getBrandmsg3() + "</brandmsg3>\n");
     xml.append("<brandmsg4>" + ub.getBrandmsg4() + "</brandmsg4>\n");
     xml.append("<brandmsg5>" + ub.getBrandmsg5() + "</brandmsg5>\n");
     xml.append("<brandmsg6>" + ub.getBrandmsg6() + "</brandmsg6>\n");
     xml.append("<brandmsg7>" + ub.getBrandmsg7() + "</brandmsg7>\n");
     xml.append("<convexchmark>" + ub.getConvexchmark() + "</convexchmark>\n");
     xml.append("<vipmsg1>" + ub.getVipmsg1() + "</vipmsg1>\n");
     xml.append("<vipmsg2>" + ub.getVipmsg2() + "</vipmsg2>\n");
     xml.append("<vipmsg3>" + ub.getVipmsg3() + "</vipmsg3>\n");
     xml.append("<vipmsg4>" + ub.getVipmsg4() + "</vipmsg4>\n");
     xml.append("<reprintflag>" + ub.getReprintflag() + "</reprintflag>\n");
     xml.append("<emailflag>" + ub.getEmailflag() + "</emailflag>\n");
     xml.append("<paperflag>" + ub.getPaperflag() + "</paperflag>\n");
     xml.append("<emailaddr>" + ub.getEmailaddr() + "</emailaddr>\n");
     xml.append("<custtype>" + ub.getCusttype() + "</custtype>\n");
     xml.append("<mobilenbr>" + ub.getMobilenbr() + "</mobilenbr>\n");
     xml.append("<ainbr>" + ub.getAinbr() + "</ainbr>\n");
     xml.append("<mobdate>" + ub.getMobdate() + "</mobdate>\n");
     xml.append("<filler>" + ub.getFiller() + "</filler>\n");
     xml.append("<citycode>" + ub.getCity() + "</citycode>\n");
   }
 
   public String getEnvrule(String wbs, UserBase ub) {
     List list = Cache.getFoldout(wbs, ub.getCardNo(), this.dao);
     String tag = "";
     String temp = "";
     Foldout f = null;
     if (list.size() > 0) {
       for (int i = 0; i < list.size(); i++) {
         f = (Foldout)list.get(i);
 
         if ("0".equals(f.getState())) {
           tag = tag + "0";
           temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
         }
         else if ("1".equals(f.getState())) {
           switch (i) {
           case 0:
             if ("Y".equals(ub.getDm1())) {
               tag = tag + "1";
               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
             } else {
               tag = tag + "0";
               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
             }
             break;
           case 1:
             if ("Y".equals(ub.getDm2())) {
               tag = tag + "1";
               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
             } else {
               tag = tag + "0";
               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
             }
             break;
           case 2:
             if ("Y".equals(ub.getDm3())) {
               tag = tag + "1";
               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
             } else {
               tag = tag + "0";
               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
             }
             break;
           case 3:
             if ("Y".equals(ub.getDm4())) {
               tag = tag + "1";
               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
             } else {
               tag = tag + "0";
               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
             }
             break;
           default:
             tag = tag + "0";
             temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
             break;
           }
         }
         else if ("2".equals(f.getState()))
         {
           Map city = Cache.getFoldoutCity(f.getId(), f.getIdx(), this.dao);
           if (city.containsKey(ub.getCity())) {
             tag = tag + "1";
             temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
           } else {
             tag = tag + "0";
             temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
           }
         } else {
           tag = tag + "0";
           temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
         }
       }
     } else {
       tag = "0000";
       temp = "<INPRIORITY1>0</INPRIORITY1>\n<INPRIORITY2>0</INPRIORITY2>\n<INPRIORITY3>0</INPRIORITY3>\n<INPRIORITY4>0</INPRIORITY4>\n";
     }
     String str = "<ENVRULE>" + tag + "</ENVRULE>\n" + temp;
     return str;
   }
 
   public String getAccInfoXml(UserBase ub)
   {
     this.tab1 = new StringBuffer();
     this.tab2 = new StringBuffer();
 
     this.listAccinfo = this.dao.getUserInfo(ub);
 
     for (UserAccinfo ua : this.listAccinfo)
     {
       if ("B001".equals(ua.getRectype())) {
         readAccinfo(this.tab1, ua);
       }
       else if ("D001".equals(ua.getRectype())) {
         readAccinfo(this.tab2, ua);
       }
 
     }
 
     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
       StringBuilder xml = new StringBuilder();
       xml.append("<accinfo>\n");
       if (this.tab1.length() > 0) {
         xml.append("<tab1>\n");
         xml.append(this.tab1.toString());
         xml.append("</tab1>\n");
       }
       if (this.tab2.length() > 0) {
         xml.append("<tab2>\n");
         xml.append(this.tab2.toString());
         xml.append("</tab2>\n");
       }
       xml.append("</accinfo>\n");
       return xml.toString();
     }
     return null;
   }
 
   public boolean writeAccinfoXml(UserBase ub, StringBuffer xml)
   {
     this.tab1 = new StringBuffer();
     this.tab2 = new StringBuffer();
 
     this.listAccinfo = this.dao.getUserInfo(ub);
 
     for (UserAccinfo ua : this.listAccinfo)
     {
       if ("B001".equals(ua.getRectype())) {
         readAccinfo(this.tab1, ua);
       }
       else if ("D001".equals(ua.getRectype())) {
         readAccinfo(this.tab2, ua);
       }
     }
 
     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
       xml.append("<accinfo>\n");
       if (this.tab1.length() > 0) {
         xml.append("<tab1>\n");
         xml.append(this.tab1.toString());
         xml.append("</tab1>\n");
       }
       if (this.tab2.length() > 0) {
         xml.append("<tab2>\n");
         xml.append(this.tab2.toString());
         xml.append("</tab2>\n");
       }
       xml.append("</accinfo>\n");
       return false;
     }
     return true;
   }
 
   private void readAccinfo(StringBuffer sb, UserAccinfo ua) {
     sb.append("<acctnbr>" + ua.getAcctnbr() + "</acctnbr>\n");
     sb.append("<rectype>" + ua.getRectype() + "</rectype>\n");
     sb.append("<stmtdate>" + ua.getStmtdate() + "</stmtdate>\n");
     sb.append("<pmtdate>" + ua.getPmtdate() + "</pmtdate>\n");
     sb.append("<totbegbal>" + ua.getTotbegbal() + "</totbegbal>\n");
     sb.append("<plantotpmt>" + ua.getPlantotpmt() + "</plantotpmt>\n");
     sb.append("<plantotnrlamt>" + ua.getPlantotnrlamt() + "</plantotnrlamt>\n");
     sb.append("<plantotadjamt>" + ua.getPlantotadjamt() + "</plantotadjamt>\n");
     sb.append("<intdueamt>" + ua.getIntdueamt() + "</intdueamt>\n");
     sb.append("<currbal>" + ua.getCurrbal() + "</currbal>\n");
     sb.append("<totdueamt>" + ua.getTotdueamt() + "</totdueamt>\n");
     sb.append("<pmtprint>" + ua.getPmtprint() + "</pmtprint>\n");
     sb.append("<crlim>" + ua.getCrlim() + "</crlim>\n");
     sb.append("<cashcrlim>" + ua.getCashcrlim() + "</cashcrlim>\n");
     sb.append("<pmtarn>" + ua.getPmtarn() + "</pmtarn>\n");
     sb.append("<pmtadn>" + ua.getPmtadn() + "</pmtadn>\n");
     sb.append("<projap>" + ua.getProjap() + "</projap>\n");
     sb.append("<pmtaflag>" + ua.getPmtaflag() + "</pmtaflag>\n");
     sb.append("<achflag>" + ua.getAchflag() + "</achflag>\n");
     sb.append("<pmtflag>" + ua.getPmtflag() + "</pmtflag>\n");
     sb.append("<filler>" + ua.getFiller() + "</filler>\n");
   }
 
   public String getAccinfoDetail(UserBase ub)
   {
     this.tab1 = new StringBuffer();
     this.tab2 = new StringBuffer();
 
     this.type1 = new StringBuffer();
     this.type2 = new StringBuffer();
     this.type3 = new StringBuffer();
     this.type4 = new StringBuffer();
 
     this.listAccinfoDetail = this.dao.getAccinfoDetail(ub);
 
     String type = "";
     for (UserAccinfoDetail uad : this.listAccinfoDetail)
     {
       if ("".equals(uad.getMcc()))
         uad.setMcc("00000");
       else if (!Cache.mccmap.containsKey(uad.getMcc())) {
         uad.setMcc("00000");
       }
 
       if ("C001".equals(uad.getRectype())) {
         if ("".equals(type)) {
           type = "C001";
         }
         readAccinfoDetail1(uad);
       }
       else if ("E001".equals(uad.getRectype())) {
         if ("C001".equals(type)) {
           if (this.type1.length() > 0) {
             this.tab1.append(this.type1)
               .append("</card>\n</lists>\n</type1>\n");
           }
           if (this.type2.length() > 0) {
             this.tab1.append(this.type2)
               .append("</card>\n</user>\n</lists>\n</type2>\n");
           }
           if (this.type3.length() > 0) {
             this.tab1.append(this.type3)
               .append("</lists>\n</type3>\n");
           }
           if (this.type4.length() > 0) {
             this.tab1.append(this.type4)
               .append("</lists>\n</type4>\n");
           }
         }
         if (("".equals(type)) || ("C001".equals(type))) {
           type = "E001";
           this.type1 = new StringBuffer();
           this.type2 = new StringBuffer();
           this.type3 = new StringBuffer();
           this.type4 = new StringBuffer();
         }
 
         readAccinfoDetail1(uad);
       }
 
     }
 
     if ("C001".equals(type)) {
       if (this.type1.length() != 0) {
         this.tab1.append(this.type1)
           .append("</card>\n</lists>\n</type1>\n");
       }
       if (this.type2.length() != 0) {
         this.tab1.append(this.type2)
           .append("</card>\n</user>\n</lists>\n</type2>\n");
       }
       if (this.type3.length() != 0) {
         this.tab1.append(this.type3)
           .append("</lists>\n</type3>\n");
       }
       if (this.type4.length() != 0) {
         this.tab1.append(this.type4)
           .append("</lists>\n</type4>\n");
       }
     }
     else if ("E001".equals(type)) {
       if (this.type1.length() != 0) {
         this.tab2.append(this.type1)
           .append("</card>\n</lists>\n</type1>\n");
       }
       if (this.type2.length() != 0) {
         this.tab2.append(this.type2)
           .append("</card>\n</user>\n</lists>\n</type2>\n");
       }
       if (this.type3.length() != 0) {
         this.tab2.append(this.type3)
           .append("</lists>\n</type3>\n");
       }
       if (this.type4.length() != 0) {
         this.tab2.append(this.type4)
           .append("</lists>\n</type4>\n");
       }
 
     }
 
     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
       StringBuilder xml = new StringBuilder();
       xml.append("<transinfo>\n");
       if (this.tab1.length() > 0) {
         xml.append("<tab1>\n");
         xml.append(this.tab1.toString());
         xml.append("</tab1>\n");
       }
       if (this.tab2.length() > 0) {
         xml.append("<tab2>\n");
         xml.append(this.tab2.toString());
         xml.append("</tab2>\n");
       }
       xml.append("</transinfo>\n");
       return xml.toString();
     }
     return "";
   }
 
   private void readAccinfoDetail1(UserAccinfoDetail uad)
   {
     if (Cache.fqjyCard.containsKey(uad.getTxnCode())) {
       if (this.type3.length() == 0) {
         this.type3.append("<type3>\n").append("<lists>\n");
       }
       readAccinfoDetail3(this.type3, uad);
     }
     else if (("".equals(uad.getCardNbr())) || (uad.getCardNbr().startsWith("000299"))) {
       if (this.type4.length() == 0) {
         this.type4.append("<type4>\n").append("<lists>\n");
       }
       readAccinfoDetail3(this.type4, uad);
     }
     else if ("0".equals(uad.getMainAccount()))
     {
       if (this.type1.length() == 0) {
         this.type1.append("<type1>\n<lists>\n<card>\n<cname>")
           .append(uad.getCardName())
           .append("</cname>\n<last4>")
           .append(uad.getCardnlast4())
           .append("</last4>\n");
         this.cardid = uad.getCardNbr();
       }
       else if (!this.cardid.equals(uad.getCardNbr())) {
         this.type1.append("</card>\n<card>\n<cname>")
           .append(uad.getCardName())
           .append("</cname>\n<last4>")
           .append(uad.getCardnlast4())
           .append("</last4>\n");
         this.cardid = uad.getCardNbr();
       }
       readAccinfoDetail2(this.type1, uad);
     }
     else if ("1".equals(uad.getMainAccount()))
     {
       if (this.type2.length() == 0) {
         this.type2.append("<type2>\n<lists>\n<user>\n<user>")
           .append(uad.getCnName())
           .append("</user>\n<ename>")
           .append(uad.getPyName())
           .append("</ename>\n<card>\n<cname>")
           .append(uad.getCardName())
           .append("</cname>\n<last4>")
           .append(uad.getCardnlast4())
           .append("</last4>\n");
         this.cardid = uad.getCardNbr();
       }
       else if (!this.cardid.equals(uad.getCardNbr())) {
         this.type2.append("</card>\n</user>\n<user>\n")
           .append("<user>")
           .append(uad.getCnName())
           .append("</user>\n<ename>")
           .append(uad.getPyName())
           .append("</ename>\n<card>\n<cname>")
           .append(uad.getCardName())
           .append("</cname>\n<last4>")
           .append(uad.getCardnlast4())
           .append("</last4>\n");
         this.cardid = uad.getCardNbr();
       }
       readAccinfoDetail2(this.type2, uad);
     } else {
       if (this.type4.length() == 0) {
         this.type4.append("<type4>\n").append("<lists>\n");
       }
       readAccinfoDetail3(this.type4, uad);
     }
   }
 
   private void readAccinfoDetail2(StringBuffer sb, UserAccinfoDetail uad)
   {
     sb.append("<list>\n");
     sb.append("<acctnbr>" + uad.getAcctnbr() + "</acctnbr>\n");
     sb.append("<rectype>" + uad.getRectype() + "</rectype>\n");
     sb.append("<recseq>" + uad.getRecseq() + "</recseq>\n");
     sb.append("<effdate>" + uad.getEffdate() + "</effdate>\n");
     sb.append("<postdate>" + uad.getPostdate() + "</postdate>\n");
 
     sb.append("<desc>" + uad.getDesc() + "</desc>\n");
     sb.append("<txnamt>" + uad.getTxnamt() + "</txnamt>\n");
     sb.append("<srctamt>" + uad.getSrctamt() + "</srctamt>\n");
     sb.append("<srctcurr>" + uad.getSrctcurr() + "</srctcurr>\n");
     sb.append("<purcty>" + uad.getPurcty() + "</purcty>\n");
     sb.append("<filler>" + uad.getFiller() + "</filler>\n");
     sb.append("<mccid>" + uad.getMcc() + "</mccid>\n");
 
     sb.append("<mccmname></mccmname>\n");
     sb.append("<mccsname></mccsname>\n");
     sb.append("</list>\n");
   }
 
   private void readAccinfoDetail3(StringBuffer sb, UserAccinfoDetail uad)
   {
     sb.append("<list>\n");
     sb.append("<acctnbr>" + uad.getAcctnbr() + "</acctnbr>\n");
     sb.append("<rectype>" + uad.getRectype() + "</rectype>\n");
     sb.append("<recseq>" + uad.getRecseq() + "</recseq>\n");
     sb.append("<effdate>" + uad.getEffdate() + "</effdate>\n");
     sb.append("<postdate>" + uad.getPostdate() + "</postdate>\n");
     sb.append("<desc>" + uad.getDesc() + "</desc>\n");
     sb.append("<txnamt>" + uad.getTxnamt() + "</txnamt>\n");
     sb.append("<srctamt>" + uad.getSrctamt() + "</srctamt>\n");
     sb.append("<srctcurr>" + uad.getSrctcurr() + "</srctcurr>\n");
     sb.append("<purcty>" + uad.getPurcty() + "</purcty>\n");
     sb.append("<filler>" + uad.getFiller() + "</filler>\n");
     sb.append("<cardlast4>").append(uad.getCardnlast4()).append("</cardlast4>\n");
     sb.append("<mccid>" + uad.getMcc() + "</mccid>\n");
 
     sb.append("<mccmname></mccmname>\n");
     sb.append("<mccsname></mccsname>\n");
     sb.append("</list>\n");
   }
 
   public String getBuy(UserBase user)
   {
     this.userBuy = this.dao.getUserBuy(user);
 
     if (this.userBuy == null)
       return "";
     StringBuilder xml = new StringBuilder();
 
     xml.append("<exchinfo>\n");
     xml.append("<acctnbr>" + this.userBuy.getAcctnbr() + "</acctnbr>\n");
     xml.append("<rectype>" + this.userBuy.getRectype() + "</rectype>\n");
     xml.append("<exchusdamt>" + this.userBuy.getExchusdamt() + "</exchusdamt>\n");
     xml.append("<sellrate>" + this.userBuy.getSellrate() + "</sellrate>\n");
     xml.append("<exchrmbamt>" + this.userBuy.getExchrmbamt() + "</exchrmbamt>\n");
     xml.append("<achrtnbr>" + this.userBuy.getAchrtnbr() + "</achrtnbr>\n");
     xml.append("<achdbnbr>" + this.userBuy.getAchdbnbr() + "</achdbnbr>\n");
     xml.append("<filler>" + this.userBuy.getFiller() + "</filler>\n");
     xml.append("</exchinfo>\n");
     return xml.toString();
   }
 
   public String getDebitInfo(UserBase sb)
   {
     this.tab1 = new StringBuffer();
     this.tab2 = new StringBuffer();
     this.listDebitinfo = this.dao.getDebitinfo(sb);
     for (Debitinfo di : this.listDebitinfo) {
       if ("C002".equals(di.getRectype()))
         readDebitinfo(this.tab1, di);
       else if ("E002".equals(di.getRectype())) {
         readDebitinfo(this.tab2, di);
       }
     }
 
     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
       StringBuilder xml = new StringBuilder();
       xml.append("<debitinfo>\n");
       if (this.tab1.length() > 0) {
         xml.append("<tab1>\n<lists>\n");
         xml.append(this.tab1.toString());
         xml.append("</lists>\n</tab1>\n");
       }
       if (this.tab2.length() > 0) {
         xml.append("<tab2>\n<lists>\n");
         xml.append(this.tab2.toString());
         xml.append("</lists>\n</tab2>\n");
       }
       xml.append("</debitinfo>\n");
       return xml.toString();
     }
     return "";
   }
 
   private void readDebitinfo(StringBuffer temp, Debitinfo di) {
     temp.append("<list>\n");
     temp.append("<acctnbr>" + di.getAcctnbr() + "</acctnbr>\n");
     temp.append("<rectype>" + di.getRectype() + "</rectype>\n");
     temp.append("<custnbr>" + di.getCustnbr() + "</custnbr>\n");
     temp.append("<effdate>" + di.getEffdate() + "</effdate>\n");
     temp.append("<txndesc>" + di.getTxndesc() + "</txndesc>\n");
     temp.append("<txncity>" + di.getTxncity() + "</txncity>\n");
     temp.append("<currcode>" + di.getCurrcode() + "</currcode>\n");
     temp.append("<txnamt>" + di.getTxnamt() + "</txnamt>\n");
     temp.append("<cardl4>" + di.getCardl4() + "</cardl4>\n");
     temp.append("<filler>" + di.getFiller() + "</filler>\n");
     temp.append("</list>\n");
   }
 
   public String getStageplan(UserBase sb)
   {
     List<Stageplan> list = this.dao.getStageplan(sb);
     if ((list == null) || (list.size() == 0)) {
       return "";
     }
     StringBuffer tsb = new StringBuffer();
     tsb.append("<stageplan>\n<lists>\n");
     for (Stageplan s : list) {
       tsb.append("<list>\n")
         .append("<stagetype>").append(getStageTypeName(s.getStagetype())).append("</stagetype>\n")
         .append("<totalstage>").append(s.getTotalstage()).append("期</totalstage>\n")
         .append("<accstage>").append(s.getAccstage()).append("期</accstage>\n")
         .append("<totalamt>").append(s.getTotalamt()).append("</totalamt>\n")
         .append("<unaccamt>").append(s.getUnaccamt()).append("</unaccamt>\n")
         .append("<stagefee>").append(s.getStagefee()).append("</stagefee>\n")
         .append("<unaccfee>").append(s.getUnaccfee()).append("</unaccfee>\n")
         .append("</list>\n");
     }
     tsb.append("</lists>\n</stageplan>\n");
     return tsb.toString();
   }
 
   private String getStageTypeName(String stageType) {
     if (Cache.stageTypeMap.get(stageType) != null) {
       return (String)Cache.stageTypeMap.get(stageType);
     }
     return stageType;
   }
 
   public String getPoint(UserBase ub)
   {
     this.tab1 = new StringBuffer();
     this.tab2list = new ArrayList();
     this.temp = new StringBuffer();
 
     this.listPointInfo = this.dao.getPoint(ub);
 
     this.point = this.dao.getPoint2(ub);
 
     for (PointInfo pi : this.listPointInfo)
     {
       if ("3".equals(pi.getPointtype())) {
         readPoint(this.tab1, pi);
       } else if ("2".equals(pi.getPointtype())) {
         this.tab2 = new StringBuffer();
         readPoint(this.tab2, pi);
         this.tab2list.add(this.tab2);
       } else if ("4".equals(pi.getPointtype())) {
         if (this.point == null) {
           this.point = new PointInfo();
           this.point.setBilldate(ub.getStmtdate());
           this.point.setBusinessid(ub.getCusnum().substring(7));
           this.point.setAblepoint("0");
           this.point.setExpirespoint("0");
         }
         this.point.setAddpoint(pi.getAddpoint());
         this.point.setAdpoints(pi.getAdpoints());
       }
     }
 
     if (this.point != null) {
       this.temp.append("<tab3>\n");
       this.temp.append("<billdate>").append(this.point.getBilldate()).append("</billdate>\n");
       this.temp.append("<ecifno>").append(this.point.getBusinessid()).append("</ecifno>\n");
       this.temp.append("<curpavalia>").append(this.point.getAblepoint()).append("</curpavalia>\n");
       this.temp.append("<pointavabf>").append(this.point.getLastbalpoint()).append("</pointavabf>\n");
       this.temp.append("<newpoint>").append(this.point.getAddpoint()).append("</newpoint>\n");
       this.temp.append("<pointredee>").append(this.point.getExpoint()).append("</pointredee>\n");
       this.temp.append("<adpoints>").append(this.point.getAdpoints()).append("</adpoints>\n");
       this.temp.append("<invalidpoint>").append(this.point.getEndpoints()).append("</invalidpoint>\n");
       this.temp.append("<expirespoint>").append(this.point.getExpirespoint()).append("</expirespoint>\n");
       this.temp.append("</tab3>\n");
     }
 
     if ((this.tab1.length() > 0) || (this.tab2list.size() > 0) || (this.temp.length() > 0)) {
       StringBuilder xml = new StringBuilder();
       xml.append("<point-info>\n");
       if (this.tab1.length() > 0) {
         xml.append("<tab1>\n");
         xml.append(this.tab1.toString());
         xml.append("</tab1>\n");
       }
       if (this.tab2list.size() > 0) {
         xml.append("<tab2>\n<lists>\n");
         for (StringBuffer sb : this.tab2list) {
           xml.append("<list>\n").append(sb).append("</list>\n");
         }
         xml.append("</lists>\n</tab2>\n");
       }
       if (this.temp.length() > 0) {
         xml.append(this.temp.toString());
       }
       xml.append("</point-info>\n");
       return xml.toString();
     }
     return "";
   }
 
   public void writePoint(UserBase user, StringBuffer xml)
   {
     this.tab1 = new StringBuffer();
     this.tab2list = new ArrayList();
     this.temp = new StringBuffer();
 
     this.listPointInfo = this.dao.getPoint(user);
     for (PointInfo pi : this.listPointInfo)
     {
       if ("3".equals(pi.getPointtype())) {
         readPoint(this.tab1, pi);
       } else if ("2".equals(pi.getPointtype())) {
         this.tab2 = new StringBuffer();
         readPoint(this.tab2, pi);
         this.tab2list.add(this.tab2);
       }
     }
 
     this.point = this.dao.getPoint2(user);
     if (this.point != null) {
       this.temp.append("<tab3>\n");
       this.temp.append("<billdate>" + this.point.getBilldate() + "</billdate>\n");
       this.temp.append("<ecifno>" + this.point.getBusinessid() + "</ecifno>\n");
       this.temp.append("<curpavalia>" + this.point.getAblepoint() + "</curpavalia>\n");
       this.temp.append("<pointavabf>" + this.point.getLastbalpoint() + "</pointavabf>\n");
       this.temp.append("<newpoint>" + this.point.getAddpoint() + "</newpoint>\n");
       this.temp.append("<pointredee>" + this.point.getExpoint() + "</pointredee>\n");
       this.temp.append("<adpoints>" + this.point.getAdpoints() + "</adpoints>\n");
       this.temp.append("<invalidpoint>" + this.point.getEndpoints() + "</invalidpoint>\n");
       this.temp.append("<expirespoint>" + this.point.getExpirespoint() + "</expirespoint>\n");
       this.temp.append("</tab3>\n");
     }
 
     if ((this.tab1.length() > 0) || (this.tab2list.size() > 0) || (this.temp.length() > 0)) {
       xml.append("<point-info>\n");
       if (this.tab1.length() > 0) {
         xml.append("<tab1>\n");
         xml.append(this.tab1.toString());
         xml.append("</tab1>\n");
       }
       if (this.tab2list.size() > 0) {
         xml.append("<tab2>\n<lists>\n");
         for (StringBuffer sb : this.tab2list) {
           xml.append("<list>\n" + sb.toString() + "</list>\n");
         }
         xml.append("</lists>\n</tab2>\n");
       }
       if (this.temp.length() > 0) {
         xml.append(this.temp.toString());
       }
       xml.append("</point-info>\n");
     }
   }
 
   private void readPoint(StringBuffer sb, PointInfo pi)
   {
     if ("1".equals(pi.getCardPointType())) {
       sb.append("<pointtype>A</pointtype>\n");
     }
     else if ("2".equals(pi.getCardPointType()))
       sb.append("<pointtype>B</pointtype>\n");
     else {
       sb.append("<pointtype>" + pi.getPointtype() + "</pointtype>\n");
     }
     sb.append("<cardportid>" + pi.getCardportid() + "</cardportid>\n");
     sb.append("<businessid>" + pi.getBusinessid() + "</businessid>\n");
     sb.append("<ablepoint>" + pi.getAblepoint() + "</ablepoint>\n");
     sb.append("<lastbalpoint>" + pi.getLastbalpoint() + "</lastbalpoint>\n");
     sb.append("<addpoint>" + pi.getAddpoint() + "</addpoint>\n");
     sb.append("<expoint>" + pi.getExpoint() + "</expoint>\n");
     sb.append("<adpoints>" + pi.getAdpoints() + "</adpoints>\n");
     sb.append("<endpoints>" + pi.getEndpoints() + "</endpoints>\n");
     sb.append("<ecifno>" + pi.getEcifno() + "</ecifno>\n");
     sb.append("<startdate>" + pi.getStartdate() + "</startdate>\n");
     sb.append("<enddate>" + pi.getEnddate() + "</enddate>\n");
     sb.append("<wholeconsume>" + pi.getWholeconsume() + "</wholeconsume>\n");
     sb.append("<inconsume>" + pi.getInconsume() + "</inconsume>\n");
     sb.append("<outconsume>" + pi.getOutconsume() + "</outconsume>\n");
     sb.append("<wholemoney>" + pi.getWholemoney() + "</wholemoney>\n");
     sb.append("<inmoney>" + pi.getInmoney() + "</inmoney>\n");
     sb.append("<outmoney>" + pi.getOutmoney() + "</outmoney>\n");
     sb.append("<usedmoney>" + pi.getUsedmoney() + "</usedmoney>\n");
     sb.append("<lavemoney>" + pi.getLavemoney() + "</lavemoney>\n");
     sb.append("<validdate>" + pi.getValiddate() + "</validdate>\n");
     sb.append("<laddermoney>" + pi.getLaddermoney() + "</laddermoney>\n");
     sb.append("<ladderscale>" + pi.getLadderscale() + "</ladderscale>\n");
 
     if ("2".equals(pi.getPointtype())) {
       sb.append("<card4>" + pi.getCard4() + "</card4>\n");
     }
     sb.append("<cardname>" + pi.getCardname() + "</cardname>\n");
   }
 
   public StringBuffer writeTemplate(UserBase user, String type)
   {
     this.temp = new StringBuffer();
     this.temp.append("<resourcesinfo>\n<lists>\n");
     this.ptId = ((String)Cache.templateMap.get(user.getCardNo() + "_" + type));
 
     this.plist = Cache.getTemplateInfo(this.ptId, this.dao);
 
     int idx = 1;
 
     for (TempArea ta : this.plist) {
       this.isExtis = false;
       idx = 1;
 
       this.rulelist = Cache.getRuleMap(this.ptId, "1", ta.getArea(), this.dao);
 
       if ((this.rulelist != null) && (this.rulelist.size() > 0)) {
         ruleXml(this.ptId, ta, type, idx, user, true);
       }
 
       if (!this.isExtis) {
         this.rulelist = Cache.getRuleMap(this.ptId, "0", ta.getArea(), this.dao);
         idx = 1;
         if ((this.rulelist != null) && (this.rulelist.size() > 0)) {
           ruleXml(this.ptId, ta, type, idx, user, false);
         }
       }
       this.isExtis = false;
     }
     this.temp.append("</lists>\n</resourcesinfo>\n");
     return this.temp;
   }
 
   public StringBuffer writeTemplateHtml5(UserBase user) {
     this.temp = new StringBuffer();
 
     this.ptId = ((String)Cache.templateMap.get((String)Cache.prodIdMapping.get(user.getCardNo()) + "_3"));
 
     this.plist = Cache.getTemplateInfo(this.ptId, this.dao);
 
     int idx = 1;
     this.temp.append("<html5resources>\n<lists>\n");
 
     for (TempArea ta : this.plist) {
       this.isExtis = false;
       idx = 1;
 
       this.rulelist = Cache.getRuleMap(this.ptId, "1", ta.getArea(), this.dao);
 
       if ((this.rulelist != null) && (this.rulelist.size() > 0)) {
         ruleXml(this.ptId, ta, "3", idx, user, true);
       }
 
       if (!this.isExtis) {
         this.rulelist = Cache.getRuleMap(this.ptId, "0", ta.getArea(), this.dao);
         idx = 1;
         if ((this.rulelist != null) && (this.rulelist.size() > 0)) {
           ruleXml(this.ptId, ta, "3", idx, user, false);
         }
       }
       this.isExtis = false;
     }
     this.temp.append("</lists>\n</html5resources>\n");
     return this.temp;
   }
 
   public int ruleXml(String ptId, TempArea ta, String type, int idx, UserBase user, boolean isCheck)
   {
     Fodder f = null;
 
     for (Rule rm : this.rulelist)
     {
       if (this.isExtis)
       {
         break;
       }
       this.rlist = Cache.getRuleFMap(rm.getRuleid(), this.dao);
 
       if (this.rlist != null)
       {
         for (RuleF rf : this.rlist)
         {
           f = Cache.getFodder(rf.getFodder(), this.dao);
 
           if (f == null) {
             this.log.debug("素材无效!模板ID=" + ptId + ";区域规则ID=" + rm.getRuleid() + "条件个数=" + this.rlist.size() + ";素材=" + rf.getFodder());
           }
           else if (isCheck)
           {
             if ("3".equals(ta.getType())) {
               this.isExtis = true;
               readRuleXml(this.temp, type, ta.getArea(), Integer.valueOf(idx), f.getUrl(), f.getLinkurl());
               idx++;
             }
             else
             {
               this.mlist = Cache.getRuleFFList(rf.getId(), this.dao);
 
               if ((this.mlist == null) || (this.mlist.size() == 0) || (readRule(this.mlist, user))) {
                 this.isExtis = true;
 
                 if ("4".equals(ta.getType()))
                 {
                   readRuleXml(this.temp, type, ta.getArea(), Integer.valueOf(idx), f.getUrl(), f.getLinkurl());
                   idx++;
                 }
                 else {
                   readRuleXml(this.temp, type, ta.getArea(), rf.getPri(), f.getUrl(), f.getLinkurl());
 
                   break;
                 }
               }
             }
           }
           else {
             readRuleXml(this.temp, type, ta.getArea(), Integer.valueOf(idx), f.getUrl(), f.getLinkurl());
             if ((!"3".equals(ta.getType())) && (!"4".equals(ta.getType()))) {
               break;
             }
             idx++;
           }
         }
       }
       else this.log.error("没有规则详情!模板ID=" + ptId + ";区域规则ID=" + rm.getRuleid());
     }
 
     return 0;
   }
 
   public void readRuleXml(StringBuffer xml, String type, String area, Object pri, String url, String link)
   {
     xml.append("<list>\n<billtype>");
     xml.append(type);
     xml.append("</billtype>\n<area>");
     xml.append(area);
     xml.append("</area>\n<priority>");
     xml.append(pri);
     xml.append("</priority>\n<rescontent>");
     if ("1".equals(type)) {
       xml.append(url);
     } else {
       int i = url.lastIndexOf("/");
       if (i != -1) {
         xml.append((String)Cache.configMap.get("MATTERPATH"))
           .append(url.substring(i + 1));
       }
       else {
         xml.append(url);
       }
     }
     xml.append("</rescontent>\n<resurl>");
     xml.append(link);
     xml.append("</resurl>\n</list>\n");
   }
 
   public boolean readRule(List<RuleM> list, UserBase user)
   {
     boolean result = false;
     boolean oldresult = false;
     int next_if = 0;
     String wd = "";
     for (RuleM rm : list)
     {
       wd = rm.getFieldid();
 
       if ("birthday".equals(wd)) {
         String temp = user.birthday;
 
         if (user.birthday.length() > 4) {
           temp = user.birthday.substring(4);
         }
         oldresult = checkValue(rm, temp);
       }
       else if ("sex".equals(wd))
       {
         if (rm.getOpr1() != 0) {
           return false;
         }
 
         oldresult = rm.getVal1().equals(user.sex);
       }
       else if ("city".equals(wd))
       {
         if (rm.getOpr1() != 0) {
           return false;
         }
 
         oldresult = rm.getVal1().equals(user.city);
       }
       else if ("mobilenbr".equals(wd))
       {
         if (rm.getOpr1() != 0) {
           return false;
         }
 
         if (user.mobilenbr.indexOf(rm.getVal1()) == 0)
           oldresult = true;
         else {
           oldresult = false;
         }
       }
       else if ("ainbr".equals(wd))
       {
         if (rm.getOpr1() != 0) {
           return false;
         }
         oldresult = rm.getVal1().equals(user.ainbr);
       }
       else if ("mobdate".equals(wd)) {
         oldresult = checkValue(rm, user.mobdate);
       }
       else if ("crlim".equals(wd)) {
         oldresult = checkValue(rm, user.crlim);
       }
       else if ("currbal".equals(wd)) {
         oldresult = checkValue(rm, user.currbal);
       }
       else if ("totdueamt".equals(wd)) {
         oldresult = checkValue(rm, user.totdueamt);
       }
       else if ("cashcrlim".equals(wd)) {
         oldresult = checkValue(rm, user.cashcrlim);
       }
       else if ("indiv1".equals(wd))
       {
         if (rm.getOpr1() != 0) {
           return false;
         }
 
         oldresult = rm.getVal1().equals(user.indiv1);
       }
       else if ("indiv2".equals(wd))
       {
         if (rm.getOpr1() != 0) {
           return false;
         }
 
         oldresult = rm.getVal1().equals(user.indiv2);
       }
       else if ("indiv3".equals(wd))
       {
         if (rm.getOpr1() != 0) {
           return false;
         }
 
         oldresult = rm.getVal1().equals(user.indiv3);
       }
       else if ("indiv4".equals(wd))
       {
         if (rm.getOpr1() != 0) {
           return false;
         }
 
         oldresult = rm.getVal1().equals(user.indiv4);
       }
       else if ("indiv5".equals(wd))
       {
         if (rm.getOpr1() != 0) {
           return false;
         }
 
         oldresult = rm.getVal1().equals(user.indiv5);
       }
       else if ("indiv6".equals(wd))
       {
         if (rm.getOpr1() != 0) {
           return false;
         }
 
         oldresult = rm.getVal1().equals(user.indiv6);
       }
       else if ("indiv7".equals(wd))
       {
         if (rm.getOpr1() != 0) {
           return false;
         }
 
         oldresult = rm.getVal1().equals(user.indiv7);
       }
       else if ("indiv8".equals(wd))
       {
         if (rm.getOpr1() != 0) {
           return false;
         }
 
         oldresult = rm.getVal1().equals(user.indiv8);
       }
 
       if (next_if == 0) {
         result = oldresult;
       }
       else if (1 == next_if) {
         result = (result) && (oldresult);
       }
       else if (2 == next_if) {
         result = (result) || (oldresult);
       }
 
       next_if = rm.getCif();
     }
     return result;
   }
 
   private boolean checkValue(RuleM rm, Object val)
   {
     boolean result = false;
     boolean result1 = false;
     boolean result2 = false;
     float i_val = 0.0F;
     float i_val1 = 0.0F;
     float i_val2 = 0.0F;
     try
     {
       if ((val instanceof String))
         i_val = Float.valueOf(val.toString()).floatValue();
       else {
         i_val = ((Float)val).floatValue();
       }
       i_val1 = Float.parseFloat(rm.getVal1());
       if ((rm.getVal2() == null) || ("".equals(rm.getVal2())))
         i_val2 = -1.0F;
       else
         i_val2 = Float.parseFloat(rm.getVal2());
     }
     catch (Exception e) {
       this.log.error("规则条件参数转型失败！参数1=" + rm.getVal1() + ",参数2=" + rm.getVal2());
       return false;
     }
 
     if (rm.getOpr1() == 0)
     {
       result = rm.getVal1().equals(val);
     }
     else
     {
       if (1 == rm.getOpr1())
         result1 = i_val > i_val1;
       else if (2 == rm.getOpr1())
         result1 = i_val < i_val1;
       else if (3 == rm.getOpr1())
         result1 = i_val >= i_val1;
       else if (4 == rm.getOpr1()) {
         result1 = i_val <= i_val1;
       }
 
       if (-1.0F == i_val2) {
         result2 = false;
       }
       else if (1 == rm.getOpr2())
         result2 = i_val > i_val2;
       else if (2 == rm.getOpr2())
         result2 = i_val < i_val2;
       else if (3 == rm.getOpr2())
         result2 = i_val >= i_val2;
       else if (4 == rm.getOpr2()) {
         result2 = i_val >= i_val2;
       }
 
       result = (result1) && (result2);
     }
     return result;
   }
 
   public List<UserBase> getUserBase(String cardid, String city, int page, int size)
   {
     return this.dao.getUserBase(cardid, city, page, size);
   }
 
   public List<UserBase> getUserBase(String cardid, int page, int size)
   {
     return this.dao.getUserBase(cardid, page, size);
   }
 
   public void colse()
   {
     this.dao.close();
   }
 
   public String getHisAmount(UserBase ub)
   {
     ArrayList data = this.dao.queryHisAmount(ub.getAccnum(), ub.getStmtdate());
     String result = "";
     HisAmountToXml haToXml = new HisAmountToXml(ub.getStmtdate());
     result = "<historytrend>\n";
     for (HisAmountBean bean : data) {
       if ("B001".equals(bean.getType()))
         result = result + haToXml.getHisAmount(bean, "tab1");
       else if ("D001".equals(bean.getType())) {
         result = result + haToXml.getHisAmount(bean, "tab2");
       }
     }
     result = result + "</historytrend>\n";
     return result;
   }
 
   public String getClickInfo(UserBase ub)
   {
     String imgUrl = BaseParam.PERIOD + "," + ub.acctnbr + "," + ub.cardNo + "," + 1;
 
     String clickUrl = BaseParam.PERIOD + "," + ub.acctnbr + "," + ub.cusnum + "," + ub.cardNo + "," + 1;
 
     StringBuffer res = new StringBuffer();
     try {
       res
         .append("<clickurl>")
         .append((String)Cache.configMap.get("LINK_URL"))
         .append("/bill/bcs?parameterStr=")
         .append(URLEncoder.encode(Cache.des.encryptStr(clickUrl), "gbk"))
         .append("</clickurl>\n<imgurl>")
         .append((String)Cache.configMap.get("LINK_URL"))
         .append("/bill/pic?parameterStr=")
         .append(URLEncoder.encode(Cache.des.encryptStr(imgUrl), "gbk"))
         .append("</imgurl>\n");
     } catch (Exception e) {
       this.log.error(e);
     }
     return res.toString();
   }
 }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.normal.UserXml
 * JD-Core Version:    0.6.2
 */