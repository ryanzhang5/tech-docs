/*     */ package com.bill.importcheck;
/*     */ 
/*     */ import com.bill.db.DbConnectionForOracle;
/*     */ import com.bill.makeXML.util.LogInit;
/*     */ import com.bill.util.config.ConfigReader;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class XPointCheck
/*     */ {
/*  28 */   private static Logger log = Logger.getLogger(XPointCheck.class);
/*  29 */   private static String filePath = "";
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  35 */     System.out.println("##### XPointCheck program start");
/*     */     try
/*     */     {
/*  38 */       ConfigReader.init();
/*     */     } catch (Exception e) {
/*  40 */       System.out.println("##### read properties file error, file path:" + ConfigReader.class.getClassLoader().getResource(ConfigReader.CONFIG_PATH));
/*  41 */       return;
/*     */     }
/*     */ 
/*  45 */     DbConnectionForOracle db = new DbConnectionForOracle(
/*  46 */       ConfigReader.read("db.ip"), 
/*  47 */       ConfigReader.read("db.port"), 
/*  48 */       ConfigReader.read("db.name"), 
/*  49 */       ConfigReader.read("db.user"), 
/*  50 */       ConfigReader.read("db.pwd"));
/*     */     try
/*     */     {
/*  54 */       config = initConfig(db);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       Map config;
/*  56 */       System.out.println("##### load db config error");
/*  57 */       db.close();
/*     */       return;
/*     */     }
/*     */     Map config;
/*  60 */     LogInit.init((String)config.get("LOG4J_COFIG_PATH"), (String)config.get("LOG4J_FILENAME") + "xpointcheck.log");
/*     */ 
/*  62 */     filePath = (String)config.get("xpc_filePath");
/*  63 */     boolean status = readFile(db.getConnection());
/*     */ 
/*  65 */     if (status)
/*  66 */       System.exit(-1);
/*     */     else
/*  68 */       System.exit(0);
/*     */   }
/*     */ 
/*     */   public static boolean readFile(Connection conn)
/*     */   {
/*  78 */     log.debug("file: " + filePath);
/*     */ 
/*  80 */     File file = new File(filePath);
/*  81 */     BufferedReader br = null;
/*  82 */     boolean status = false;
/*     */     try
/*     */     {
/*  85 */       br = new BufferedReader(new FileReader(file));
/*  86 */       String str = "";
/*  87 */       while ((str = br.readLine()) != null)
/*     */       {
/*  89 */         boolean statusTemp = process(conn, str);
/*  90 */         if (statusTemp)
/*     */         {
/*  92 */           status = statusTemp;
/*     */         }
/*     */       }
/*  95 */       return status;
/*     */     }
/*     */     catch (FileNotFoundException e) {
/*  98 */       log.debug("FileNotFoundException......");
/*  99 */       status = false;
/*     */     } catch (IOException e) {
/* 101 */       log.debug("IOException......");
/* 102 */       status = true;
/*     */     } finally {
/*     */       try {
/* 105 */         if (br != null)
/* 106 */           br.close();
/*     */       } catch (IOException e) {
/* 108 */         log.debug("br.close() IOException......");
/* 109 */         status = true;
/*     */       }
/*     */     }
/* 112 */     return status;
/*     */   }
/*     */ 
/*     */   public static boolean process(Connection conn, String str)
/*     */   {
/* 122 */     String[] strArr = str.split("\\|");
/* 123 */     int count = 0;
/*     */     try {
/* 125 */       InsertBean bean = null;
/*     */ 
/* 127 */       if (!"".equals(str))
/*     */       {
/* 129 */         count = getDataCount(conn);
/* 130 */         log.debug(str + ";  sql count is:" + count);
/* 131 */         if (count != Integer.parseInt(strArr[(strArr.length - 1)].trim()))
/*     */         {
/* 133 */           bean = new InsertBean();
/* 134 */           bean.setS_name("积分(xpoint)");
/* 135 */           bean.setS_type("");
/* 136 */           bean.setS_des_count1("数据文件数量");
/* 137 */           bean.setS_count1(Integer.parseInt(strArr[(strArr.length - 1)].trim()));
/* 138 */           bean.setS_des_count2("数据库数量");
/* 139 */           bean.setS_count2(count);
/* 140 */           bean.setS_desc("xpoint check");
/*     */ 
/* 142 */           InsertCheck.insertData(bean);
/* 143 */           return true;
/*     */         }
/*     */       }
/*     */     } catch (SQLException e) {
/* 147 */       log.debug("getDataCount SQLException......");
/* 148 */       return true;
/*     */     }
/*     */ 
/* 151 */     return false;
/*     */   }
/*     */ 
/*     */   public static int getDataCount(Connection conn)
/*     */     throws SQLException
/*     */   {
/* 164 */     PreparedStatement statement = null;
/* 165 */     String sql = "select count(1) from T_B_POINT_X t ";
/*     */     try
/*     */     {
/* 168 */       statement = conn.prepareStatement(sql);
/* 169 */       ResultSet result = statement.executeQuery();
/* 170 */       result.next();
/* 171 */       return result.getInt(1);
/*     */     }
/*     */     finally {
/* 174 */       if (statement != null)
/* 175 */         statement.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static Map<String, String> initConfig(DbConnectionForOracle db)
/*     */     throws SQLException
/*     */   {
/* 186 */     Connection conn = db.getConnection();
/* 187 */     Map map = new HashMap();
/* 188 */     PreparedStatement statement = conn.prepareStatement("select * from t_s_bill_para t");
/* 189 */     ResultSet result = statement.executeQuery();
/* 190 */     while (result.next()) {
/* 191 */       map.put(result.getString("s_type"), result.getString("s_value"));
/*     */     }
/* 193 */     result.close();
/* 194 */     statement.close();
/* 195 */     return map;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.importcheck.XPointCheck
 * JD-Core Version:    0.6.2
 */