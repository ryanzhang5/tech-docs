/*    */ package com.bill.importcheck;
/*    */ 
/*    */ public class InsertBean
/*    */ {
/*    */   private int s_id;
/*    */   private String s_name;
/*    */   private String s_type;
/*    */   private String s_des_count1;
/*    */   private long s_count1;
/*    */   private String s_des_count2;
/*    */   private long s_count2;
/*    */   private String s_desc;
/*    */ 
/*    */   public int getS_id()
/*    */   {
/* 14 */     return this.s_id;
/*    */   }
/*    */   public void setS_id(int s_id) {
/* 17 */     this.s_id = s_id;
/*    */   }
/*    */   public String getS_name() {
/* 20 */     return this.s_name;
/*    */   }
/*    */   public void setS_name(String s_name) {
/* 23 */     this.s_name = s_name;
/*    */   }
/*    */   public String getS_type() {
/* 26 */     return this.s_type;
/*    */   }
/*    */   public void setS_type(String s_type) {
/* 29 */     this.s_type = s_type;
/*    */   }
/*    */   public String getS_des_count1() {
/* 32 */     return this.s_des_count1;
/*    */   }
/*    */   public void setS_des_count1(String s_des_count1) {
/* 35 */     this.s_des_count1 = s_des_count1;
/*    */   }
/*    */   public long getS_count1() {
/* 38 */     return this.s_count1;
/*    */   }
/*    */   public void setS_count1(long s_count1) {
/* 41 */     this.s_count1 = s_count1;
/*    */   }
/*    */   public String getS_des_count2() {
/* 44 */     return this.s_des_count2;
/*    */   }
/*    */   public void setS_des_count2(String s_des_count2) {
/* 47 */     this.s_des_count2 = s_des_count2;
/*    */   }
/*    */   public long getS_count2() {
/* 50 */     return this.s_count2;
/*    */   }
/*    */   public void setS_count2(long s_count2) {
/* 53 */     this.s_count2 = s_count2;
/*    */   }
/*    */   public String getS_desc() {
/* 56 */     return this.s_desc;
/*    */   }
/*    */   public void setS_desc(String s_desc) {
/* 59 */     this.s_desc = s_desc;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 64 */     return this.s_name + ", " + 
/* 65 */       this.s_type + ", " + 
/* 66 */       this.s_des_count1 + ", " + 
/* 67 */       this.s_count1 + ", " + 
/* 68 */       this.s_des_count2 + ", " + 
/* 69 */       this.s_count2 + ", " + 
/* 70 */       this.s_desc;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.importcheck.InsertBean
 * JD-Core Version:    0.6.2
 */