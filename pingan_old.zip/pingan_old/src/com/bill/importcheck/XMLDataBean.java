/*    */ package com.bill.importcheck;
/*    */ 
/*    */ public class XMLDataBean
/*    */ {
/*    */   private String card1;
/*    */   private long count1;
/*    */   private String card2;
/*    */   private long count2;
/*    */ 
/*    */   public String getCard1()
/*    */   {
/* 10 */     return this.card1;
/*    */   }
/*    */   public void setCard1(String card1) {
/* 13 */     this.card1 = card1;
/*    */   }
/*    */   public long getCount1() {
/* 16 */     return this.count1;
/*    */   }
/*    */   public void setCount1(long count1) {
/* 19 */     this.count1 = count1;
/*    */   }
/*    */   public String getCard2() {
/* 22 */     return this.card2;
/*    */   }
/*    */   public void setCard2(String card2) {
/* 25 */     this.card2 = card2;
/*    */   }
/*    */   public long getCount2() {
/* 28 */     return this.count2;
/*    */   }
/*    */   public void setCount2(long count2) {
/* 31 */     this.count2 = count2;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.importcheck.XMLDataBean
 * JD-Core Version:    0.6.2
 */