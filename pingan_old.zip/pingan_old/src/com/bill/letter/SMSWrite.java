/*     */ package com.bill.letter;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.security.AccessController;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ import sun.security.action.GetPropertyAction;
/*     */ 
/*     */ public class SMSWrite
/*     */ {
/*  18 */   private static Logger log = Logger.getLogger(SMSWrite.class);
/*     */ 
/*  20 */   private static String lineSeparator = (String)AccessController.doPrivileged(
/*  21 */     new GetPropertyAction("line.separator"));
/*     */ 
/*  23 */   private int index = 0;
/*     */   private String path;
/*     */   private String fileName;
/*     */   private File tempFile;
/*     */   private BufferedWriter writer;
/*     */   private RandomAccessFile rf;
/*     */ 
/*     */   public SMSWrite(String path, String fileName)
/*     */     throws Exception
/*     */   {
/*  35 */     this.path = path;
/*  36 */     this.fileName = fileName;
/*     */ 
/*  38 */     this.tempFile = new File(path + File.separator + fileName.replace(".txt", ".tmp"));
/*  39 */     createTempFile(this.tempFile);
/*     */   }
/*     */ 
/*     */   public void println(Record record, Map<String, String> param) throws Exception
/*     */   {
/*     */     try {
/*  45 */       String str = this.index + 1 + "|" + getLine(record, param);
/*     */ 
/*  50 */       this.rf.write(str.getBytes("GBK"));
/*  51 */       this.index += 1;
/*     */     } catch (IOException e) {
/*  53 */       log.error("写入临时文件错误..");
/*  54 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getLine(Record record, Map<String, String> param)
/*     */   {
/*  65 */     if (param != null) {
/*  66 */       int type = Integer.parseInt(record.getType());
/*  67 */       if ((44 >= type) && (type >= 40)) {
/*  68 */         return String.format("%s|%s|%s|%s|%s|" + lineSeparator, new Object[] { 
/*  69 */           record.getMobile(), 
/*  70 */           record.getCustomer(), 
/*  71 */           param.get("param5"), 
/*  72 */           record.getStmt_date().substring(0, 6), 
/*  73 */           param.get("param7") });
/*     */       }
/*  75 */       if (type == 25) {
/*  76 */         return String.format("%s|%s|%s|%s|%s|" + lineSeparator, new Object[] { 
/*  77 */           record.getMobile(), 
/*  78 */           record.getCustomer(), 
/*  79 */           param.get("param6"), 
/*  80 */           record.getStmt_date().substring(0, 6), 
/*  81 */           param.get("param8") });
/*     */       }
/*     */     }
/*     */ 
/*  85 */     return String.format("%s|%s|%s|" + lineSeparator, new Object[] { 
/*  87 */       record.getMobile(), 
/*  88 */       record.getCustomer(), 
/*  89 */       record.getStmt_date().substring(0, 6) });
/*     */   }
/*     */ 
/*     */   public void createBackLetterFile(String template, String creator, String beginTime, String endTime, String date)
/*     */     throws Exception
/*     */   {
/* 106 */     BufferedReader read = null;
/* 107 */     BufferedWriter writer = null;
/* 108 */     BufferedWriter writerCK = null;
/*     */     File outFile;
/*     */     try
/*     */     {
/* 111 */       File outFile = new File(this.path + File.separator + this.fileName);
/* 112 */       System.out.println(outFile.getPath());
/* 113 */       if (!outFile.exists()) {
/* 114 */         outFile.getParentFile().mkdirs();
/*     */       }
/* 116 */       log.trace("写入" + this.index + "条数据..");
/* 117 */       if (this.index == 0) {
/* 118 */         log.trace("没有数据...");
/*     */       }
/* 120 */       read = new BufferedReader(new InputStreamReader(new FileInputStream(this.tempFile)));
/* 121 */       writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outFile)));
/*     */ 
/* 123 */       writer.write(new String(getHead(template, creator, beginTime, endTime, this.index).getBytes(), "GBK"));
/*     */ 
/* 125 */       String str = "";
/* 126 */       while ((str = read.readLine()) != null)
/*     */       {
/* 128 */         writer.write(str + lineSeparator);
/*     */       }
/*     */ 
/* 132 */       File ck = new File(this.path + File.separator + this.fileName.replace(".txt", "_CK.txt"));
/* 133 */       writerCK = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(ck)));
/* 134 */       StringBuilder sb = new StringBuilder();
/* 135 */       sb.append("SFILENAME=/paic/esgsintf/data/PABank_DCC/gettemp/" + this.fileName + "\n");
/*     */ 
/* 137 */       sb.append("SNODENAME=CDPRD2\n");
/* 138 */       sb.append("SSHELLNAME=/wls/bank/bin/PACD_CallBack.sh?/paic/esgsintf/data/PABank_DCC/gettemp/" + this.fileName + "?" + this.fileName.split(new StringBuilder("_").append(date).toString())[0] + "?" + date + "?001\n");
/* 139 */       sb.append("PFILENAME=" + this.fileName);
/* 140 */       writerCK.write(sb.toString());
/* 141 */       writerCK.flush();
/*     */     }
/*     */     catch (FileNotFoundException e) {
/* 144 */       log.error("createBackLetterFile FileNotFoundException..");
/* 145 */       throw e;
/*     */     } catch (IOException e) {
/* 147 */       log.error("createBackLetterFile IOException..");
/* 148 */       throw e;
/*     */     } finally {
/*     */       try {
/* 151 */         read.close();
/*     */       } catch (IOException e) {
/* 153 */         log.error("read.close IOException..");
/* 154 */         throw e;
/*     */       }
/*     */       try {
/* 157 */         writer.close();
/*     */       } catch (IOException e) {
/* 159 */         log.error("writer.close IOException..");
/* 160 */         throw e;
/*     */       }
/* 162 */       writerCK.close();
/*     */     }File outFile;
/*     */   }
/*     */ 
/*     */   public void clearTempFile() throws Exception {
/* 167 */     if (this.tempFile.exists())
/*     */     {
/*     */       try {
/* 170 */         this.writer.close();
/*     */       } catch (IOException e) {
/* 172 */         log.error("临时文件writer.close  IOException");
/*     */       }
/* 174 */       this.rf.close();
/* 175 */       this.tempFile.delete();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void createTempFile(File tempFile) throws Exception
/*     */   {
/* 181 */     if (!tempFile.exists())
/* 182 */       tempFile.getParentFile().mkdirs();
/*     */     try
/*     */     {
/* 185 */       this.writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(tempFile)));
/* 186 */       this.rf = new RandomAccessFile(tempFile, "rwd");
/*     */     } catch (FileNotFoundException e) {
/* 188 */       log.error("临时文件未找到....");
/* 189 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getHead(String template, String creator, String beginTime, String endTime, int count)
/*     */   {
/* 211 */     String str = String.format("%s|%d|%s|%s|%s|%s|%s|" + lineSeparator, new Object[] { 
/* 212 */       "S", 
/* 213 */       Integer.valueOf(1), 
/* 214 */       template, 
/* 215 */       creator == null ? "" : creator, 
/* 216 */       "", 
/* 217 */       "", 
/* 218 */       Integer.valueOf(count) });
/*     */ 
/* 221 */     log.trace("生成文件批头:" + str);
/*     */ 
/* 223 */     return str;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/* 230 */       SMSWrite sms = new SMSWrite("E:\\tt", "ttt.txt");
/*     */ 
/* 232 */       Map param = null;
/* 233 */       for (int i = 0; i < 10; i++)
/*     */       {
/* 235 */         Record record = new Record();
/* 236 */         record.setRowId(i + 1);
/* 237 */         record.setAccount(i);
/* 238 */         record.setCustomer("13711234567" + i);
/* 239 */         record.setMobile(i);
/* 240 */         record.setName(i);
/* 241 */         record.setSex(i);
/* 242 */         record.setTelephone(i);
/*     */ 
/* 244 */         sms.println(record, param);
/*     */       }
/*     */ 
/* 247 */       sms.createBackLetterFile("S0222", "FUEYUN", "2011-12-08", "2012-12-08", "2012-12-08");
/*     */ 
/* 249 */       sms.clearTempFile();
/*     */     } catch (Exception e) {
/* 251 */       e.printStackTrace();
/* 252 */       System.exit(-1);
/*     */     }
/* 254 */     System.exit(0);
/*     */   }
/*     */ 
/*     */   public int getIndex()
/*     */   {
/* 259 */     return this.index;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.letter.SMSWrite
 * JD-Core Version:    0.6.2
 */