/*    */ package com.bill.letter;
/*    */ 
/*    */ public class Record
/*    */ {
/*    */   private String rowId;
/*    */   private String mobile;
/*    */   private String customer;
/*    */   private String account;
/*    */   private String sex;
/*    */   private String name;
/*    */   private String telephone;
/*    */   private String type;
/*    */   private String stmt_date;
/*    */ 
/*    */   public String getMobile()
/*    */   {
/* 15 */     return this.mobile;
/*    */   }
/*    */   public void setMobile(String mobile) {
/* 18 */     this.mobile = mobile;
/*    */   }
/*    */   public String getCustomer() {
/* 21 */     return this.customer;
/*    */   }
/*    */   public void setCustomer(String customer) {
/* 24 */     int length = customer.length();
/* 25 */     if (length > 12)
/* 26 */       this.customer = customer.substring(length - 12);
/*    */     else
/* 28 */       this.customer = customer; 
/*    */   }
/*    */ 
/* 31 */   public String getAccount() { return this.account; }
/*    */ 
/*    */   public void setAccount(String account) {
/* 34 */     this.account = account;
/*    */   }
/*    */   public String getSex() {
/* 37 */     return this.sex;
/*    */   }
/*    */   public void setSex(String sex) {
/* 40 */     if (sex.equalsIgnoreCase("M"))
/* 41 */       this.sex = "男";
/* 42 */     else if (sex.equalsIgnoreCase("F"))
/* 43 */       this.sex = "女";
/*    */     else
/* 45 */       this.sex = ""; 
/*    */   }
/*    */ 
/* 48 */   public String getName() { return this.name; }
/*    */ 
/*    */   public void setName(String name) {
/* 51 */     this.name = name;
/*    */   }
/*    */   public String getTelephone() {
/* 54 */     return this.telephone;
/*    */   }
/*    */   public void setTelephone(String telephone) {
/* 57 */     this.telephone = telephone;
/*    */   }
/*    */   public String getRowId() {
/* 60 */     return this.rowId;
/*    */   }
/*    */   public void setRowId(String rowId) {
/* 63 */     this.rowId = rowId;
/*    */   }
/*    */   public String getType() {
/* 66 */     return this.type;
/*    */   }
/*    */   public void setType(String type) {
/* 69 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public String getStmt_date() {
/* 73 */     return this.stmt_date;
/*    */   }
/*    */   public void setStmt_date(String stmt_date) {
/* 76 */     this.stmt_date = stmt_date;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 80 */     return "rowId=" + this.rowId + 
/* 81 */       ", type=" + this.type + 
/* 82 */       ", account=" + this.account + 
/* 83 */       ", customer=" + this.customer + 
/* 84 */       ", mobile=" + this.mobile + 
/* 85 */       ", name=" + this.name + 
/* 86 */       ", stmt_date=" + this.stmt_date;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.letter.Record
 * JD-Core Version:    0.6.2
 */