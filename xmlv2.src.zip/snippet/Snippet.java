package snippet;

public class Snippet
{
}

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     snippet.Snippet
 * JD-Core Version:    0.6.2
 */