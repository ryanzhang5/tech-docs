/*    */ package com.bill.reprot;
/*    */ 
/*    */ import com.bill.bean.BaseParam;
/*    */ import com.bill.db.DbConnectionForOracle;
/*    */ import com.bill.util.config.ConfigReader;
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.Connection;
/*    */ 
/*    */ public class Reprint
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/*    */     try
/*    */     {
/* 16 */       ConfigReader.init();
/* 17 */       BaseParam.DB_IP = ConfigReader.read("db.ip");
/* 18 */       BaseParam.DB_PORT = ConfigReader.read("db.port");
/* 19 */       BaseParam.DB_NAME = ConfigReader.read("db.name");
/* 20 */       BaseParam.DB_USER = ConfigReader.read("db.user");
/* 21 */       BaseParam.DB_PWD = ConfigReader.read("db.pwd");
/*    */ 
/* 24 */       DbConnectionForOracle dbconn = new DbConnectionForOracle(BaseParam.DB_IP, BaseParam.DB_PORT, BaseParam.DB_NAME, BaseParam.DB_USER, BaseParam.DB_PWD);
/* 25 */       Connection conn = dbconn.getConnection();
/*    */ 
/* 27 */       CallableStatement statement = conn.prepareCall("{call PRO_REPRINT_END}");
/* 28 */       statement.execute();
/* 29 */       statement = conn.prepareCall("{call PRO_STA_REPRINT_W}");
/* 30 */       statement.execute();
/* 31 */       statement = conn.prepareCall("{call PRO_STA_RPRINT_COST}");
/* 32 */       statement.execute();
/* 33 */       conn.close();
/*    */     } catch (Exception e) {
/* 35 */       e.printStackTrace();
/* 36 */       System.exit(1);
/*    */     }
/* 38 */     System.exit(0);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.reprot.Reprint
 * JD-Core Version:    0.6.2
 */