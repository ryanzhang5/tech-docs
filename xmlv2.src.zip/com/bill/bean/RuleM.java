/*    */ package com.bill.bean;
/*    */ 
/*    */ public class RuleM
/*    */ {
/*    */   private String idx;
/*    */   private int opr1;
/*    */   private String val1;
/*    */   private int opr2;
/*    */   private String val2;
/*    */   private int cif;
/*    */   private String fieldid;
/*    */ 
/*    */   public String getIdx()
/*    */   {
/* 41 */     return this.idx;
/*    */   }
/*    */   public void setIdx(String idx) {
/* 44 */     this.idx = idx;
/*    */   }
/*    */   public int getOpr1() {
/* 47 */     return this.opr1;
/*    */   }
/*    */   public void setOpr1(int opr1) {
/* 50 */     this.opr1 = opr1;
/*    */   }
/*    */   public String getVal1() {
/* 53 */     return this.val1;
/*    */   }
/*    */   public void setVal1(String val1) {
/* 56 */     this.val1 = val1;
/*    */   }
/*    */   public int getOpr2() {
/* 59 */     return this.opr2;
/*    */   }
/*    */   public void setOpr2(int opr2) {
/* 62 */     this.opr2 = opr2;
/*    */   }
/*    */   public String getVal2() {
/* 65 */     return this.val2;
/*    */   }
/*    */   public void setVal2(String val2) {
/* 68 */     this.val2 = val2;
/*    */   }
/*    */   public int getCif() {
/* 71 */     return this.cif;
/*    */   }
/*    */   public void setCif(int cif) {
/* 74 */     this.cif = cif;
/*    */   }
/*    */   public String getFieldid() {
/* 77 */     return this.fieldid;
/*    */   }
/*    */   public void setFieldid(String fieldid) {
/* 80 */     this.fieldid = fieldid;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.RuleM
 * JD-Core Version:    0.6.2
 */