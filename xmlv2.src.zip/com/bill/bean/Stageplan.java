/*    */ package com.bill.bean;
/*    */ 
/*    */ public class Stageplan
/*    */ {
/*    */   private String stagetype;
/*    */   private int totalstage;
/*    */   private int accstage;
/*    */   private String totalamt;
/*    */   private String unaccamt;
/*    */   private String stagefee;
/*    */   private String unaccfee;
/*    */   private String account;
/*    */ 
/*    */   public String getStagetype()
/*    */   {
/* 14 */     return this.stagetype;
/*    */   }
/*    */   public void setStagetype(String stagetype) {
/* 17 */     this.stagetype = stagetype;
/*    */   }
/*    */   public int getTotalstage() {
/* 20 */     return this.totalstage;
/*    */   }
/*    */   public void setTotalstage(int totalstage) {
/* 23 */     this.totalstage = totalstage;
/*    */   }
/*    */   public int getAccstage() {
/* 26 */     return this.accstage;
/*    */   }
/*    */   public void setAccstage(int accstage) {
/* 29 */     this.accstage = accstage;
/*    */   }
/*    */   public String getTotalamt() {
/* 32 */     return this.totalamt;
/*    */   }
/*    */   public void setTotalamt(String totalamt) {
/* 35 */     this.totalamt = totalamt;
/*    */   }
/*    */   public String getUnaccamt() {
/* 38 */     return this.unaccamt;
/*    */   }
/*    */   public void setUnaccamt(String unaccamt) {
/* 41 */     this.unaccamt = unaccamt;
/*    */   }
/*    */   public String getStagefee() {
/* 44 */     return this.stagefee;
/*    */   }
/*    */   public void setStagefee(String stagefee) {
/* 47 */     this.stagefee = stagefee;
/*    */   }
/*    */   public String getUnaccfee() {
/* 50 */     return this.unaccfee;
/*    */   }
/*    */   public void setUnaccfee(String unaccfee) {
/* 53 */     this.unaccfee = unaccfee;
/*    */   }
/*    */   public String getAccount() {
/* 56 */     return this.account;
/*    */   }
/*    */   public void setAccount(String account) {
/* 59 */     this.account = account;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.Stageplan
 * JD-Core Version:    0.6.2
 */