/*    */ package com.bill.bean;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class RuleF
/*    */ {
/*    */   private String id;
/*    */   private String rid;
/*    */   private String fodder;
/*    */   private String pri;
/*    */   private List<RuleM> rm;
/*    */ 
/*    */   public String getId()
/*    */   {
/* 25 */     return this.id;
/*    */   }
/*    */   public void setId(String id) {
/* 28 */     this.id = id;
/*    */   }
/*    */   public String getRid() {
/* 31 */     return this.rid;
/*    */   }
/*    */   public void setRid(String rid) {
/* 34 */     this.rid = rid;
/*    */   }
/*    */   public String getFodder() {
/* 37 */     return this.fodder;
/*    */   }
/*    */   public void setFodder(String fodder) {
/* 40 */     this.fodder = fodder;
/*    */   }
/*    */   public String getPri() {
/* 43 */     return this.pri;
/*    */   }
/*    */   public void setPri(String pri) {
/* 46 */     this.pri = pri;
/*    */   }
/*    */   public List<RuleM> getRm() {
/* 49 */     return this.rm;
/*    */   }
/*    */   public void setRm(List<RuleM> rm) {
/* 52 */     this.rm = rm;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.RuleF
 * JD-Core Version:    0.6.2
 */