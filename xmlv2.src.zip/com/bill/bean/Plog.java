/*     */ package com.bill.bean;
/*     */ 
/*     */ public class Plog
/*     */ {
/*     */   private String stmtdate;
/*     */   private String filename;
/*     */   private String businpnt_no;
/*     */   private int share;
/*     */   private int error;
/*     */   private String start_time;
/*     */   private String end_time;
/*     */   private String card_id;
/*     */   private String paper_no;
/*     */   private String state;
/*     */ 
/*     */   public String getStmtdate()
/*     */   {
/*  48 */     return this.stmtdate;
/*     */   }
/*     */   public void setStmtdate(String stmtdate) {
/*  51 */     this.stmtdate = stmtdate;
/*     */   }
/*     */   public String getFilename() {
/*  54 */     return this.filename;
/*     */   }
/*     */   public void setFilename(String filename) {
/*  57 */     this.filename = filename;
/*     */   }
/*     */   public String getBusinpnt_no() {
/*  60 */     return this.businpnt_no;
/*     */   }
/*     */   public void setBusinpnt_no(String businpntNo) {
/*  63 */     this.businpnt_no = businpntNo;
/*     */   }
/*     */   public int getShare() {
/*  66 */     return this.share;
/*     */   }
/*     */   public void setShare(int share) {
/*  69 */     this.share = share;
/*     */   }
/*     */   public String getStart_time() {
/*  72 */     return this.start_time;
/*     */   }
/*     */   public void setStart_time(String startTime) {
/*  75 */     this.start_time = startTime;
/*     */   }
/*     */   public String getCard_id() {
/*  78 */     return this.card_id;
/*     */   }
/*     */   public void setCard_id(String cardId) {
/*  81 */     this.card_id = cardId;
/*     */   }
/*     */   public String getPaper_no() {
/*  84 */     return this.paper_no;
/*     */   }
/*     */   public void setPaper_no(String paperNo) {
/*  87 */     this.paper_no = paperNo;
/*     */   }
/*     */   public String getState() {
/*  90 */     return this.state;
/*     */   }
/*     */   public void setState(String state) {
/*  93 */     this.state = state;
/*     */   }
/*     */   public String getEnd_time() {
/*  96 */     return this.end_time;
/*     */   }
/*     */   public void setEnd_time(String endTime) {
/*  99 */     this.end_time = endTime;
/*     */   }
/*     */   public int getError() {
/* 102 */     return this.error;
/*     */   }
/*     */   public void setError(int error) {
/* 105 */     this.error = error;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 109 */     return "stmtdate=" + this.stmtdate + ", file=" + this.filename + ", busin=" + this.businpnt_no;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.Plog
 * JD-Core Version:    0.6.2
 */