/*    */ package com.bill.bean;
/*    */ 
/*    */ public class Bfpnt
/*    */ {
/*    */   private String id;
/*    */ 
/*    */   public String getId()
/*    */   {
/* 14 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(String id) {
/* 18 */     this.id = Util.check(id);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.Bfpnt
 * JD-Core Version:    0.6.2
 */