/*    */ package com.bill.bean;
/*    */ 
/*    */ public class Template
/*    */ {
/*    */   private String id;
/*    */   private String cardid;
/*    */   private String type;
/*    */ 
/*    */   public String getId()
/*    */   {
/*  8 */     return this.id;
/*    */   }
/*    */   public void setId(String id) {
/* 11 */     this.id = id;
/*    */   }
/*    */   public String getCardid() {
/* 14 */     return this.cardid;
/*    */   }
/*    */   public void setCardid(String cardid) {
/* 17 */     this.cardid = cardid;
/*    */   }
/*    */   public String getType() {
/* 20 */     return this.type;
/*    */   }
/*    */   public void setType(String type) {
/* 23 */     this.type = type;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.Template
 * JD-Core Version:    0.6.2
 */