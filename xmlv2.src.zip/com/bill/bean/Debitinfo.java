/*    */ package com.bill.bean;
/*    */ 
/*    */ public class Debitinfo
/*    */ {
/*    */   private String acctnbr;
/*    */   private String rectype;
/*    */   private String custnbr;
/*    */   private String effdate;
/*    */   private String txndesc;
/*    */   private String txncity;
/*    */   private String currcode;
/*    */   private String txnamt;
/*    */   private String cardl4;
/*    */   private String filler;
/*    */ 
/*    */   public String getAcctnbr()
/*    */   {
/* 30 */     return this.acctnbr;
/*    */   }
/*    */   public void setAcctnbr(String acctnbr) {
/* 33 */     this.acctnbr = Util.check(acctnbr);
/*    */   }
/*    */   public String getRectype() {
/* 36 */     return this.rectype;
/*    */   }
/*    */   public void setRectype(String rectype) {
/* 39 */     this.rectype = Util.check(rectype);
/*    */   }
/*    */   public String getCustnbr() {
/* 42 */     return this.custnbr;
/*    */   }
/*    */   public void setCustnbr(String custnbr) {
/* 45 */     this.custnbr = Util.check(custnbr);
/*    */   }
/*    */   public String getEffdate() {
/* 48 */     return this.effdate;
/*    */   }
/*    */   public void setEffdate(String effdate) {
/* 51 */     this.effdate = Util.check(effdate);
/*    */   }
/*    */   public String getTxndesc() {
/* 54 */     return this.txndesc;
/*    */   }
/*    */   public void setTxndesc(String txndesc) {
/* 57 */     this.txndesc = Util.check(txndesc);
/*    */   }
/*    */   public String getTxncity() {
/* 60 */     return this.txncity;
/*    */   }
/*    */   public void setTxncity(String txncity) {
/* 63 */     this.txncity = Util.check(txncity);
/*    */   }
/*    */   public String getCurrcode() {
/* 66 */     return this.currcode;
/*    */   }
/*    */   public void setCurrcode(String currcode) {
/* 69 */     this.currcode = Util.check(currcode);
/*    */   }
/*    */   public String getTxnamt() {
/* 72 */     return this.txnamt;
/*    */   }
/*    */   public void setTxnamt(String txnamt) {
/* 75 */     this.txnamt = Util.check(txnamt);
/*    */   }
/*    */   public String getCardl4() {
/* 78 */     return this.cardl4;
/*    */   }
/*    */   public void setCardl4(String cardl4) {
/* 81 */     this.cardl4 = Util.check(cardl4);
/*    */   }
/*    */   public String getFiller() {
/* 84 */     return this.filler;
/*    */   }
/*    */   public void setFiller(String filler) {
/* 87 */     this.filler = Util.check(filler);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.Debitinfo
 * JD-Core Version:    0.6.2
 */