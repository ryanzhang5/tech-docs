/*    */ package com.bill.bean;
/*    */ 
/*    */ public class mcc
/*    */ {
/*    */   private String type;
/*    */   private String typeName;
/*    */   private String id;
/*    */   private String name;
/*    */ 
/*    */   public String getId()
/*    */   {
/* 11 */     return this.id;
/*    */   }
/*    */   public void setId(String id) {
/* 14 */     this.id = id;
/*    */   }
/*    */   public String getName() {
/* 17 */     return this.name;
/*    */   }
/*    */   public void setName(String name) {
/* 20 */     this.name = name;
/*    */   }
/*    */   public String getType() {
/* 23 */     return this.type;
/*    */   }
/*    */   public void setType(String type) {
/* 26 */     this.type = type;
/*    */   }
/*    */   public String getTypeName() {
/* 29 */     return this.typeName;
/*    */   }
/*    */   public void setTypeName(String typeName) {
/* 32 */     this.typeName = typeName;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.mcc
 * JD-Core Version:    0.6.2
 */