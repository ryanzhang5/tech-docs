/*    */ package com.bill.bean;
/*    */ 
/*    */ public class Fodder
/*    */ {
/*    */   private String fid;
/*    */   private String url;
/*    */   private String linkurl;
/*    */ 
/*    */   public String getFid()
/*    */   {
/* 20 */     return this.fid;
/*    */   }
/*    */ 
/*    */   public void setFid(String fid) {
/* 24 */     this.fid = Util.check(fid);
/*    */   }
/*    */ 
/*    */   public String getUrl() {
/* 28 */     return this.url;
/*    */   }
/*    */ 
/*    */   public void setUrl(String url) {
/* 32 */     this.url = Util.check(url);
/*    */   }
/*    */ 
/*    */   public String getLinkurl() {
/* 36 */     return this.linkurl;
/*    */   }
/*    */ 
/*    */   public void setLinkurl(String linkurl) {
/* 40 */     this.linkurl = Util.check(linkurl);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.Fodder
 * JD-Core Version:    0.6.2
 */