/*    */ package com.bill.bean;
/*    */ 
/*    */ public class Busin
/*    */ {
/*    */   private String id;
/*    */   private String name;
/*    */ 
/*    */   public String getId()
/*    */   {
/* 11 */     return this.id;
/*    */   }
/*    */   public void setId(String id) {
/* 14 */     this.id = Util.check(id);
/*    */   }
/*    */   public String getName() {
/* 17 */     return this.name;
/*    */   }
/*    */   public void setName(String name) {
/* 20 */     this.name = Util.check(name);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.Busin
 * JD-Core Version:    0.6.2
 */