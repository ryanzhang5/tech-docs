/*    */ package com.bill.bean;
/*    */ 
/*    */ public class Rule
/*    */ {
/*    */   private String tid;
/*    */   private String ruleid;
/*    */   private String type;
/*    */   private String ruleType;
/*    */   private String areaNo;
/*    */   private String pri;
/*    */   private int foddertype;
/*    */ 
/*    */   public String getTid()
/*    */   {
/* 35 */     return this.tid;
/*    */   }
/*    */   public void setTid(String tid) {
/* 38 */     this.tid = tid;
/*    */   }
/*    */ 
/*    */   public String getRuleid()
/*    */   {
/* 44 */     return this.ruleid;
/*    */   }
/*    */   public void setRuleid(String ruleid) {
/* 47 */     this.ruleid = ruleid;
/*    */   }
/*    */   public String getType() {
/* 50 */     return this.type;
/*    */   }
/*    */   public void setType(String type) {
/* 53 */     this.type = type;
/*    */   }
/*    */   public String getRuleType() {
/* 56 */     return this.ruleType;
/*    */   }
/*    */   public void setRuleType(String ruleType) {
/* 59 */     this.ruleType = ruleType;
/*    */   }
/*    */   public String getAreaNo() {
/* 62 */     return this.areaNo;
/*    */   }
/*    */   public void setAreaNo(String areaNo) {
/* 65 */     this.areaNo = areaNo;
/*    */   }
/*    */   public String getPri() {
/* 68 */     return this.pri;
/*    */   }
/*    */   public void setPri(String pri) {
/* 71 */     this.pri = pri;
/*    */   }
/*    */   public int getFoddertype() {
/* 74 */     return this.foddertype;
/*    */   }
/*    */   public void setFoddertype(int foddertype) {
/* 77 */     this.foddertype = foddertype;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.Rule
 * JD-Core Version:    0.6.2
 */