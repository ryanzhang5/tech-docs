/*     */ package com.bill.bean;
/*     */ 
/*     */ public class PrintInfo
/*     */ {
/*     */   private String id;
/*     */   private String card_no;
/*     */   private String businpnt_no;
/*     */   private String account;
/*     */   private String period;
/*     */   private String isUpAddr;
/*     */   private String addrname3;
/*     */   private String addrname1;
/*     */   private String addrname2;
/*     */   private String addpost;
/*     */   private String printType;
/*     */   private String flg;
/*     */   private String cityid;
/*     */   private String email;
/*     */ 
/*     */   public String getCard_no()
/*     */   {
/*  61 */     return this.card_no;
/*     */   }
/*     */ 
/*     */   public void setCard_no(String cardNo) {
/*  65 */     this.card_no = Util.check(cardNo);
/*     */   }
/*     */ 
/*     */   public String getBusinpnt_no() {
/*  69 */     return this.businpnt_no;
/*     */   }
/*     */ 
/*     */   public void setBusinpnt_no(String businpntNo) {
/*  73 */     this.businpnt_no = Util.check(businpntNo);
/*     */   }
/*     */ 
/*     */   public String getPeriod() {
/*  77 */     return this.period;
/*     */   }
/*     */ 
/*     */   public void setPeriod(String period) {
/*  81 */     this.period = Util.check(period);
/*     */   }
/*     */ 
/*     */   public String getAddrname3() {
/*  85 */     return this.addrname3;
/*     */   }
/*     */ 
/*     */   public void setAddrname3(String addrname3) {
/*  89 */     this.addrname3 = Util.check(addrname3);
/*     */   }
/*     */ 
/*     */   public String getAddrname1() {
/*  93 */     return this.addrname1;
/*     */   }
/*     */ 
/*     */   public void setAddrname1(String addrname1) {
/*  97 */     this.addrname1 = Util.check(addrname1);
/*     */   }
/*     */ 
/*     */   public String getAddrname2() {
/* 101 */     return this.addrname2;
/*     */   }
/*     */ 
/*     */   public void setAddrname2(String addrname2) {
/* 105 */     this.addrname2 = Util.check(addrname2);
/*     */   }
/*     */ 
/*     */   public String getAddpost() {
/* 109 */     return this.addpost;
/*     */   }
/*     */ 
/*     */   public void setAddpost(String addpost) {
/* 113 */     this.addpost = Util.check(addpost);
/*     */   }
/*     */ 
/*     */   public String getIsUpAddr() {
/* 117 */     return this.isUpAddr;
/*     */   }
/*     */ 
/*     */   public void setIsUpAddr(String isUpAddr) {
/* 121 */     this.isUpAddr = Util.check(isUpAddr);
/*     */   }
/*     */ 
/*     */   public String getPrintType() {
/* 125 */     return this.printType;
/*     */   }
/*     */ 
/*     */   public void setPrintType(String printType) {
/* 129 */     this.printType = Util.check(printType);
/*     */   }
/*     */ 
/*     */   public String getId() {
/* 133 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(String id) {
/* 137 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public String getFlg() {
/* 141 */     return this.flg;
/*     */   }
/*     */ 
/*     */   public void setFlg(String flg) {
/* 145 */     this.flg = Util.check(flg);
/*     */   }
/*     */ 
/*     */   public String getCityid() {
/* 149 */     return this.cityid;
/*     */   }
/*     */ 
/*     */   public void setCityid(String cityid) {
/* 153 */     this.cityid = cityid;
/*     */   }
/*     */ 
/*     */   public String getEmail() {
/* 157 */     return this.email;
/*     */   }
/*     */ 
/*     */   public void setEmail(String email) {
/* 161 */     this.email = email;
/*     */   }
/*     */ 
/*     */   public String getAccount() {
/* 165 */     return this.account;
/*     */   }
/*     */ 
/*     */   public void setAccount(String account) {
/* 169 */     this.account = account;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.PrintInfo
 * JD-Core Version:    0.6.2
 */