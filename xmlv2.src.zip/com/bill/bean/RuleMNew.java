/*    */ package com.bill.bean;
/*    */ 
/*    */ public class RuleMNew
/*    */ {
/*    */   private String ruleNo;
/*    */   private String period;
/*    */   private String cardId;
/*    */   private String cityNo;
/*    */   private String type;
/*    */ 
/*    */   public String getRuleNo()
/*    */   {
/* 14 */     return this.ruleNo;
/*    */   }
/*    */   public void setRuleNo(String ruleNo) {
/* 17 */     this.ruleNo = ruleNo;
/*    */   }
/*    */ 
/*    */   public String getPeriod() {
/* 21 */     return this.period;
/*    */   }
/*    */   public void setPeriod(String period) {
/* 24 */     this.period = period;
/*    */   }
/*    */ 
/*    */   public String getCardId() {
/* 28 */     return this.cardId;
/*    */   }
/*    */   public void setCardId(String cardId) {
/* 31 */     this.cardId = cardId;
/*    */   }
/*    */ 
/*    */   public String getCityNo() {
/* 35 */     return this.cityNo;
/*    */   }
/*    */   public void setCityNo(String cityNo) {
/* 38 */     this.cityNo = cityNo;
/*    */   }
/*    */ 
/*    */   public String getType() {
/* 42 */     return this.type;
/*    */   }
/*    */   public void setType(String type) {
/* 45 */     this.type = type;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.RuleMNew
 * JD-Core Version:    0.6.2
 */