/*     */ package com.bill.bean;
/*     */ 
/*     */ public class UserAccinfoDetail
/*     */ {
/*     */   private String acctnbr;
/*     */   private String rectype;
/*     */   private String recseq;
/*     */   private String effdate;
/*     */   private String postdate;
/*     */   private String cardnlast4;
/*     */   private String desc;
/*     */   private String txnamt;
/*     */   private String srctamt;
/*     */   private String srctcurr;
/*     */   private String purcty;
/*     */   private String filler;
/*     */   private String mcc;
/*     */   private String cardNbr;
/*     */   private String acceptorNbr;
/*     */   private String txnCode;
/*     */   private String mainAccount;
/*     */   private String cnName;
/*     */   private String pyName;
/*     */   private String cardName;
/*     */ 
/*     */   public String getAcctnbr()
/*     */   {
/*  69 */     return this.acctnbr;
/*     */   }
/*     */   public void setAcctnbr(String acctnbr) {
/*  72 */     this.acctnbr = Util.check(acctnbr);
/*     */   }
/*     */   public String getRectype() {
/*  75 */     return this.rectype;
/*     */   }
/*     */   public void setRectype(String rectype) {
/*  78 */     this.rectype = Util.check(rectype);
/*     */   }
/*     */   public String getRecseq() {
/*  81 */     return this.recseq;
/*     */   }
/*     */   public void setRecseq(String recseq) {
/*  84 */     this.recseq = Util.check(recseq);
/*     */   }
/*     */   public String getEffdate() {
/*  87 */     return this.effdate;
/*     */   }
/*     */   public void setEffdate(String effdate) {
/*  90 */     this.effdate = Util.check(effdate);
/*     */   }
/*     */   public String getPostdate() {
/*  93 */     return this.postdate;
/*     */   }
/*     */   public void setPostdate(String postdate) {
/*  96 */     this.postdate = Util.check(postdate);
/*     */   }
/*     */   public String getCardnlast4() {
/*  99 */     return this.cardnlast4;
/*     */   }
/*     */   public void setCardnlast4(String cardnlast4) {
/* 102 */     this.cardnlast4 = Util.check(cardnlast4);
/*     */   }
/*     */   public String getDesc() {
/* 105 */     return this.desc;
/*     */   }
/*     */   public void setDesc(String desc) {
/* 108 */     this.desc = Util.check(desc);
/*     */   }
/*     */   public String getTxnamt() {
/* 111 */     return this.txnamt;
/*     */   }
/*     */   public void setTxnamt(String txnamt) {
/* 114 */     this.txnamt = Util.check(txnamt);
/*     */   }
/*     */   public String getSrctamt() {
/* 117 */     return this.srctamt;
/*     */   }
/*     */   public void setSrctamt(String srctamt) {
/* 120 */     this.srctamt = Util.check(srctamt);
/*     */   }
/*     */   public String getSrctcurr() {
/* 123 */     return this.srctcurr;
/*     */   }
/*     */   public void setSrctcurr(String srctcurr) {
/* 126 */     this.srctcurr = Util.check(srctcurr);
/*     */   }
/*     */   public String getPurcty() {
/* 129 */     return this.purcty;
/*     */   }
/*     */   public void setPurcty(String purcty) {
/* 132 */     this.purcty = Util.check(purcty);
/*     */   }
/*     */   public String getFiller() {
/* 135 */     return this.filler;
/*     */   }
/*     */   public void setFiller(String filler) {
/* 138 */     this.filler = Util.check(filler);
/*     */   }
/*     */ 
/*     */   public String getCardNbr() {
/* 142 */     return this.cardNbr;
/*     */   }
/*     */   public void setCardNbr(String cardNbr) {
/* 145 */     this.cardNbr = Util.check(cardNbr);
/*     */   }
/*     */   public String getAcceptorNbr() {
/* 148 */     return this.acceptorNbr;
/*     */   }
/*     */   public void setAcceptorNbr(String acceptorNbr) {
/* 151 */     this.acceptorNbr = acceptorNbr;
/*     */   }
/*     */   public String getTxnCode() {
/* 154 */     return this.txnCode;
/*     */   }
/*     */   public void setTxnCode(String txnCode) {
/* 157 */     this.txnCode = txnCode;
/*     */   }
/*     */   public String getMainAccount() {
/* 160 */     return this.mainAccount;
/*     */   }
/*     */   public void setMainAccount(String mainAccount) {
/* 163 */     this.mainAccount = Util.check(mainAccount);
/*     */   }
/*     */ 
/*     */   public String getCardName() {
/* 167 */     return this.cardName;
/*     */   }
/*     */   public void setCardName(String cardName) {
/* 170 */     this.cardName = Util.check(cardName);
/*     */   }
/*     */   public String getMcc() {
/* 173 */     return this.mcc;
/*     */   }
/*     */   public void setMcc(String mcc) {
/* 176 */     this.mcc = Util.check(mcc);
/*     */   }
/*     */   public String getCnName() {
/* 179 */     return this.cnName;
/*     */   }
/*     */   public void setCnName(String cnName) {
/* 182 */     this.cnName = Util.check(cnName);
/*     */   }
/*     */   public String getPyName() {
/* 185 */     return this.pyName;
/*     */   }
/*     */   public void setPyName(String pyName) {
/* 188 */     this.pyName = Util.check(pyName);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.UserAccinfoDetail
 * JD-Core Version:    0.6.2
 */