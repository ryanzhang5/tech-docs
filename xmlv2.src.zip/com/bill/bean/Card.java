/*    */ package com.bill.bean;
/*    */ 
/*    */ public class Card
/*    */ {
/*    */   private String id;
/*    */   private String name;
/*    */   private String type;
/*    */   private String personId;
/*    */ 
/*    */   public String getId()
/*    */   {
/* 14 */     return this.id;
/*    */   }
/*    */   public void setId(String id) {
/* 17 */     this.id = id;
/*    */   }
/*    */   public String getName() {
/* 20 */     return this.name;
/*    */   }
/*    */   public void setName(String name) {
/* 23 */     this.name = name;
/*    */   }
/*    */   public String getType() {
/* 26 */     return this.type;
/*    */   }
/*    */   public void setType(String type) {
/* 29 */     this.type = type;
/*    */   }
/*    */   public String getPersonId() {
/* 32 */     return this.personId;
/*    */   }
/*    */   public void setPersonId(String personId) {
/* 35 */     this.personId = personId;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.Card
 * JD-Core Version:    0.6.2
 */