/*     */ package com.bill.bean;
/*     */ 
/*     */ public class PointInfo
/*     */ {
/*     */   private String pointtype;
/*     */   private String cardportid;
/*     */   private String businessid;
/*     */   private String ablepoint;
/*     */   private String lastbalpoint;
/*     */   private String addpoint;
/*     */   private String expoint;
/*     */   private String adpoints;
/*     */   private String endpoints;
/*     */   private String ecifno;
/*     */   private String startdate;
/*     */   private String enddate;
/*     */   private String wholeconsume;
/*     */   private String inconsume;
/*     */   private String outconsume;
/*     */   private String wholemoney;
/*     */   private String inmoney;
/*     */   private String outmoney;
/*     */   private String usedmoney;
/*     */   private String lavemoney;
/*     */   private String validdate;
/*     */   private String laddermoney;
/*     */   private String ladderscale;
/*     */   private String billdate;
/*     */   private String card4;
/*     */   private String cardid;
/*     */   private String cardPointType;
/*     */   private String cardname;
/*     */   private String expirespoint;
/*     */ 
/*     */   public String getCard4()
/*     */   {
/*  64 */     return this.card4;
/*     */   }
/*     */ 
/*     */   public void setCard4(String card4) {
/*  68 */     this.card4 = Util.check(card4);
/*     */   }
/*     */ 
/*     */   public String getCardid() {
/*  72 */     return this.cardid;
/*     */   }
/*     */ 
/*     */   public void setCardid(String cardid) {
/*  76 */     this.cardid = Util.check(cardid);
/*     */   }
/*     */ 
/*     */   public String getPointtype() {
/*  80 */     return this.pointtype;
/*     */   }
/*     */ 
/*     */   public void setPointtype(String pointtype) {
/*  84 */     this.pointtype = Util.check(pointtype);
/*     */   }
/*     */ 
/*     */   public String getCardportid() {
/*  88 */     return this.cardportid;
/*     */   }
/*     */ 
/*     */   public void setCardportid(String cardportid) {
/*  92 */     this.cardportid = Util.check(cardportid);
/*     */   }
/*     */ 
/*     */   public String getBusinessid() {
/*  96 */     return this.businessid;
/*     */   }
/*     */ 
/*     */   public void setBusinessid(String businessid) {
/* 100 */     this.businessid = Util.check(businessid);
/*     */   }
/*     */ 
/*     */   public String getAblepoint() {
/* 104 */     return this.ablepoint;
/*     */   }
/*     */ 
/*     */   public void setAblepoint(String ablepoint) {
/* 108 */     this.ablepoint = Util.check(ablepoint);
/* 109 */     if (this.ablepoint.indexOf(".") == 0)
/* 110 */       this.ablepoint = ("0" + this.ablepoint);
/* 111 */     else if ("".equals(this.ablepoint))
/* 112 */       this.ablepoint = "0";
/*     */   }
/*     */ 
/*     */   public String getLastbalpoint()
/*     */   {
/* 117 */     return this.lastbalpoint;
/*     */   }
/*     */ 
/*     */   public void setLastbalpoint(String lastbalpoint) {
/* 121 */     this.lastbalpoint = Util.check(lastbalpoint);
/* 122 */     if (this.lastbalpoint.indexOf(".") == 0)
/* 123 */       this.lastbalpoint = ("0" + this.lastbalpoint);
/* 124 */     else if ("".equals(this.lastbalpoint))
/* 125 */       this.lastbalpoint = "0";
/*     */   }
/*     */ 
/*     */   public String getAddpoint()
/*     */   {
/* 131 */     return this.addpoint;
/*     */   }
/*     */ 
/*     */   public void setAddpoint(String addpoint) {
/* 135 */     this.addpoint = Util.check(addpoint);
/* 136 */     if (this.addpoint.indexOf(".") == 0)
/* 137 */       this.addpoint = ("0" + this.addpoint);
/* 138 */     else if ("".equals(this.addpoint))
/* 139 */       this.addpoint = "0";
/*     */   }
/*     */ 
/*     */   public String getExpoint()
/*     */   {
/* 144 */     return this.expoint;
/*     */   }
/*     */ 
/*     */   public void setExpoint(String expoint) {
/* 148 */     this.expoint = Util.check(expoint);
/* 149 */     if (this.expoint.indexOf(".") == 0)
/* 150 */       this.expoint = ("0" + this.expoint);
/* 151 */     else if ("".equals(this.expoint))
/* 152 */       this.expoint = "0";
/*     */   }
/*     */ 
/*     */   public String getAdpoints()
/*     */   {
/* 157 */     return this.adpoints;
/*     */   }
/*     */ 
/*     */   public void setAdpoints(String adpoints) {
/* 161 */     this.adpoints = Util.check(adpoints);
/* 162 */     if (this.adpoints.indexOf(".") == 0)
/* 163 */       this.adpoints = ("0" + this.adpoints);
/* 164 */     else if ("".equals(this.adpoints))
/* 165 */       this.adpoints = "0";
/*     */   }
/*     */ 
/*     */   public String getEndpoints()
/*     */   {
/* 170 */     return this.endpoints;
/*     */   }
/*     */ 
/*     */   public void setEndpoints(String endpoints) {
/* 174 */     this.endpoints = Util.check(endpoints);
/* 175 */     if (this.endpoints.indexOf(".") == 0)
/* 176 */       this.endpoints = ("0" + this.endpoints);
/* 177 */     else if ("".equals(this.endpoints))
/* 178 */       this.endpoints = "0";
/*     */   }
/*     */ 
/*     */   public String getEcifno()
/*     */   {
/* 183 */     return this.ecifno;
/*     */   }
/*     */ 
/*     */   public void setEcifno(String ecifno) {
/* 187 */     this.ecifno = Util.check(ecifno);
/*     */   }
/*     */ 
/*     */   public String getStartdate() {
/* 191 */     return this.startdate;
/*     */   }
/*     */ 
/*     */   public void setStartdate(String startdate) {
/* 195 */     this.startdate = Util.check(startdate);
/*     */   }
/*     */ 
/*     */   public String getEnddate() {
/* 199 */     return this.enddate;
/*     */   }
/*     */ 
/*     */   public void setEnddate(String enddate) {
/* 203 */     this.enddate = Util.check(enddate);
/*     */   }
/*     */ 
/*     */   public String getWholeconsume() {
/* 207 */     return this.wholeconsume;
/*     */   }
/*     */ 
/*     */   public void setWholeconsume(String wholeconsume) {
/* 211 */     this.wholeconsume = Util.check(wholeconsume);
/*     */   }
/*     */ 
/*     */   public String getInconsume() {
/* 215 */     return this.inconsume;
/*     */   }
/*     */ 
/*     */   public void setInconsume(String inconsume) {
/* 219 */     this.inconsume = Util.check(inconsume);
/*     */   }
/*     */ 
/*     */   public String getOutconsume() {
/* 223 */     return this.outconsume;
/*     */   }
/*     */ 
/*     */   public void setOutconsume(String outconsume) {
/* 227 */     this.outconsume = Util.check(outconsume);
/*     */   }
/*     */ 
/*     */   public String getWholemoney() {
/* 231 */     return this.wholemoney;
/*     */   }
/*     */ 
/*     */   public void setWholemoney(String wholemoney) {
/* 235 */     this.wholemoney = Util.check(wholemoney);
/*     */   }
/*     */ 
/*     */   public String getInmoney() {
/* 239 */     return this.inmoney;
/*     */   }
/*     */ 
/*     */   public void setInmoney(String inmoney) {
/* 243 */     this.inmoney = Util.check(inmoney);
/*     */   }
/*     */ 
/*     */   public String getOutmoney() {
/* 247 */     return this.outmoney;
/*     */   }
/*     */ 
/*     */   public void setOutmoney(String outmoney) {
/* 251 */     this.outmoney = Util.check(outmoney);
/*     */   }
/*     */ 
/*     */   public String getUsedmoney() {
/* 255 */     return this.usedmoney;
/*     */   }
/*     */ 
/*     */   public void setUsedmoney(String usedmoney) {
/* 259 */     this.usedmoney = Util.check(usedmoney);
/*     */   }
/*     */ 
/*     */   public String getLavemoney() {
/* 263 */     return this.lavemoney;
/*     */   }
/*     */ 
/*     */   public void setLavemoney(String lavemoney) {
/* 267 */     this.lavemoney = Util.check(lavemoney);
/*     */   }
/*     */ 
/*     */   public String getValiddate() {
/* 271 */     return this.validdate;
/*     */   }
/*     */ 
/*     */   public void setValiddate(String validdate) {
/* 275 */     this.validdate = Util.check(validdate);
/*     */   }
/*     */ 
/*     */   public String getLaddermoney() {
/* 279 */     return this.laddermoney;
/*     */   }
/*     */ 
/*     */   public void setLaddermoney(String laddermoney) {
/* 283 */     this.laddermoney = Util.check(laddermoney);
/*     */   }
/*     */ 
/*     */   public String getLadderscale() {
/* 287 */     return this.ladderscale;
/*     */   }
/*     */ 
/*     */   public void setLadderscale(String ladderscale) {
/* 291 */     this.ladderscale = Util.check(ladderscale);
/*     */   }
/*     */ 
/*     */   public String getBilldate() {
/* 295 */     return this.billdate;
/*     */   }
/*     */ 
/*     */   public void setBilldate(String billdate) {
/* 299 */     this.billdate = Util.check(billdate);
/*     */   }
/*     */ 
/*     */   public String getCardPointType() {
/* 303 */     return this.cardPointType;
/*     */   }
/*     */ 
/*     */   public void setCardPointType(String cardPointType) {
/* 307 */     this.cardPointType = Util.check(cardPointType);
/*     */   }
/*     */ 
/*     */   public String getCardname() {
/* 311 */     return this.cardname;
/*     */   }
/*     */ 
/*     */   public void setCardname(String cardname) {
/* 315 */     this.cardname = Util.check(cardname);
/*     */   }
/*     */ 
/*     */   public String getExpirespoint() {
/* 319 */     return this.expirespoint;
/*     */   }
/*     */ 
/*     */   public void setExpirespoint(String expirespoint)
/*     */   {
/* 326 */     this.expirespoint = Util.check(expirespoint);
/* 327 */     if (this.expirespoint.indexOf(".") == 0)
/* 328 */       this.expirespoint = ("0" + this.expirespoint);
/* 329 */     else if ("".equals(this.expirespoint))
/* 330 */       this.expirespoint = "0";
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.PointInfo
 * JD-Core Version:    0.6.2
 */