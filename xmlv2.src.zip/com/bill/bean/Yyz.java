/*    */ package com.bill.bean;
/*    */ 
/*    */ public class Yyz
/*    */ {
/*    */   private String id;
/*    */   private String paperNo;
/*    */ 
/*    */   public String getId()
/*    */   {
/* 14 */     return this.id;
/*    */   }
/*    */   public void setId(String id) {
/* 17 */     this.id = id;
/*    */   }
/*    */   public String getPaperNo() {
/* 20 */     return this.paperNo;
/*    */   }
/*    */   public void setPaperNo(String paperNo) {
/* 23 */     this.paperNo = paperNo;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.bean.Yyz
 * JD-Core Version:    0.6.2
 */