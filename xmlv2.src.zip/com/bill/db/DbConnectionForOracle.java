/*    */ package com.bill.db;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.DriverManager;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public class DbConnectionForOracle
/*    */ {
/*    */   private Connection conn;
/*  9 */   private String ip = null;
/* 10 */   private String port = null;
/* 11 */   private String dbName = null;
/* 12 */   private String userName = null;
/* 13 */   private String password = null;
/*    */ 
/*    */   public DbConnectionForOracle(String ip, String port, String dbName, String userName, String password)
/*    */   {
/* 26 */     this.ip = ip;
/* 27 */     this.port = port;
/* 28 */     this.dbName = dbName;
/* 29 */     this.userName = userName;
/* 30 */     this.password = password;
/*    */   }
/*    */ 
/*    */   public DbConnectionForOracle(String ip, String dbName, String userName, String password)
/*    */   {
/* 42 */     this.ip = ip;
/* 43 */     this.port = "1521";
/* 44 */     this.dbName = dbName;
/* 45 */     this.userName = userName;
/* 46 */     this.password = password;
/*    */   }
/*    */ 
/*    */   public Connection getConnection()
/*    */   {
/*    */     try
/*    */     {
/* 55 */       if ((this.conn == null) || (this.conn.isClosed())) {
/* 56 */         Class.forName("oracle.jdbc.driver.OracleDriver");
/* 57 */         this.conn = DriverManager.getConnection("jdbc:oracle:thin:@" + this.ip + ":" + 
/* 58 */           this.port + ":" + this.dbName, this.userName, this.password);
/*    */       }
/*    */     }
/*    */     catch (ClassNotFoundException e)
/*    */     {
/* 63 */       e.printStackTrace();
/* 64 */       return null;
/*    */     } catch (SQLException e) {
/* 66 */       e.printStackTrace();
/* 67 */       return null;
/*    */     }
/* 69 */     return this.conn;
/*    */   }
/*    */ 
/*    */   public void close()
/*    */   {
/*    */     try
/*    */     {
/* 76 */       if (this.conn != null)
/* 77 */         this.conn.close();
/*    */     } catch (SQLException e) {
/* 79 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.db.DbConnectionForOracle
 * JD-Core Version:    0.6.2
 */