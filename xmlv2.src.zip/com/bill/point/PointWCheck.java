/*     */ package com.bill.point;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.db.DbConnectionForOracle;
/*     */ import com.bill.util.LogInit;
/*     */ import com.bill.util.config.ConfigReader;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class PointWCheck
/*     */ {
/*  18 */   private static Logger log = null;
/*  19 */   private static Map<String, String> configMap = null;
/*  20 */   private static DbConnectionForOracle dbconn = null;
/*  21 */   private static PreparedStatement statement = null;
/*  22 */   private static ResultSet result = null;
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  28 */     init();
/*     */ 
/*  30 */     step1();
/*     */ 
/*  32 */     step2();
/*     */ 
/*  34 */     boolean res = step3();
/*  35 */     dbconn.close();
/*     */ 
/*  37 */     if (res)
/*  38 */       System.exit(0);
/*     */     else
/*  40 */       System.exit(1);
/*     */   }
/*     */ 
/*     */   public static void init()
/*     */   {
/*     */     try
/*     */     {
/*  47 */       ConfigReader.init();
/*     */     } catch (Exception e) {
/*  49 */       log.error(e.getMessage());
/*  50 */       System.exit(1);
/*     */     }
/*  52 */     BaseParam.DB_IP = ConfigReader.read("db.ip");
/*  53 */     BaseParam.DB_PORT = ConfigReader.read("db.port");
/*  54 */     BaseParam.DB_NAME = ConfigReader.read("db.name");
/*  55 */     BaseParam.DB_USER = ConfigReader.read("db.user");
/*  56 */     BaseParam.DB_PWD = ConfigReader.read("db.pwd");
/*     */ 
/*  58 */     dbconn = new DbConnectionForOracle(BaseParam.DB_IP, BaseParam.DB_PORT, 
/*  59 */       BaseParam.DB_NAME, BaseParam.DB_USER, BaseParam.DB_PWD);
/*     */ 
/*  61 */     configMap = new HashMap();
/*     */     try {
/*  63 */       statement = dbconn.getConnection().prepareStatement(
/*  64 */         "select t.s_value,t.s_type from t_s_bill_para t");
/*  65 */       result = statement.executeQuery();
/*     */ 
/*  67 */       while (result.next()) {
/*  68 */         configMap.put(result.getString("s_type"), 
/*  69 */           result.getString("s_value"));
/*     */       }
/*  71 */       statement.close();
/*  72 */       result.close();
/*     */ 
/*  74 */       LogInit.init((String)configMap.get("LOG4J_COFIG_PATH"), 
/*  75 */         (String)configMap.get("LOG4J_FILENAME") + "pointwcheck.log");
/*  76 */       log = Logger.getLogger(PointWCheck.class);
/*     */     } catch (SQLException e) {
/*  78 */       e.printStackTrace();
/*  79 */       log.error("get system config error!");
/*  80 */       System.exit(1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void step1() {
/*  85 */     String sql = "DELETE T_B_POINT_W_ERR e where e.c_stmt_date=(select p.s_value from t_s_bill_para p where p.s_type='PERIOD')";
/*     */     try {
/*  87 */       statement = dbconn.getConnection().prepareStatement(sql);
/*  88 */       int i = statement.executeUpdate();
/*  89 */       statement.close();
/*  90 */       log.debug("清理历史数据。" + i + "条！");
/*     */     } catch (SQLException e) {
/*  92 */       e.printStackTrace();
/*  93 */       log.error("step1=" + e.getMessage());
/*  94 */       System.exit(1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void step2() {
/*  99 */     String sql = "INSERT INTO T_B_POINT_W_ERR (S_ECIF_NO,  I_ENDPOINT,  I_NEWPOINT,  I_USEDPOINT,  I_ADJUSTPOINT,  I_INVAILPOINT,  I_VALIDPOINT_B,  C_STMT_DATE,   C_TYPE)  select        x.s_ecif_no,        x.I_ENDPOINT,        x.I_NEWPOINT,        x.I_USEDPOINT,        x.I_ADJUSTPOINT,        x.I_INVAILPOINT,        x.I_VALIDPOINT_B,        x.C_STMT_DATE,        '0'   FROM T_B_POINT_W x  where NOT EXISTS(select 1 from t_b_Customer_Bill b where b.S_CUR_CUST_NBR='0000000'||x.s_ecif_no)";
/*     */ 
/* 121 */     String sql1 = "DELETE T_B_POINT_W w where w.s_ecif_no in (select e.s_ecif_no from T_B_POINT_W_ERR e where e.C_TYPE='0' and e.c_stmt_date=(select p.s_value from t_s_bill_para p where p.s_type='PERIOD'))";
/*     */     try
/*     */     {
/* 125 */       statement = dbconn.getConnection().prepareStatement(sql);
/* 126 */       int i = statement.executeUpdate();
/* 127 */       statement.close();
/* 128 */       log.debug("无账号积分数据=" + i);
/*     */ 
/* 130 */       statement = dbconn.getConnection().prepareStatement(sql1);
/* 131 */       i = statement.executeUpdate();
/* 132 */       statement.close();
/* 133 */       log.debug("清理无账号积分数据=" + i);
/*     */     }
/*     */     catch (SQLException e) {
/* 136 */       e.printStackTrace();
/* 137 */       log.error("step2=" + e.getMessage());
/* 138 */       dbconn.close();
/* 139 */       System.exit(1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean step3() {
/* 144 */     String sql1 = "INSERT INTO T_B_POINT_W_ERR(S_ECIF_NO, I_ENDPOINT, I_NEWPOINT, I_USEDPOINT, I_ADJUSTPOINT, I_INVAILPOINT, I_VALIDPOINT_B, C_STMT_DATE, C_TYPE) select       x.s_ecif_no,       x.I_ENDPOINT,       x.I_NEWPOINT,       x.I_USEDPOINT,       x.I_ADJUSTPOINT,       x.I_INVAILPOINT,       x.I_VALIDPOINT_B,       x.C_STMT_DATE,\t\t  '2'  FROM T_B_POINT_w x  where x.s_ecif_no in (select t.s_ecif_no from T_B_POINT_W t group by t.s_ecif_no having count(1)>1)";
/*     */ 
/* 167 */     String sql11 = "DELETE T_B_POINT_W w where w.s_ecif_no in (select e.s_ecif_no from T_B_POINT_W_ERR e where e.C_TYPE='2' and e.c_stmt_date=(select p.s_value from t_s_bill_para p where p.s_type='PERIOD'))";
/*     */ 
/* 185 */     String sql3 = "select count(1) from (select 1 from T_B_POINT_W_err err where (err.c_type='1' or  err.c_type='2') and err.c_stmt_date=(select p.s_value from t_s_bill_para p where p.s_type='PERIOD')  group by err.s_ecif_no)";
/*     */     try
/*     */     {
/* 188 */       statement = dbconn.getConnection().prepareStatement(sql1);
/* 189 */       int i = statement.executeUpdate();
/* 190 */       statement.close();
/* 191 */       log.debug("重复积分验证完成！重复积分数据=" + i);
/*     */ 
/* 193 */       statement = dbconn.getConnection().prepareStatement(sql11);
/* 194 */       i = statement.executeUpdate();
/* 195 */       statement.close();
/* 196 */       log.debug("清理重复积分异常数据=" + i);
/*     */ 
/* 208 */       int err = 10;
/* 209 */       if (configMap.get("POINTX_ERR_NUM") != null) {
/* 210 */         err = Integer.parseInt((String)configMap.get("POINTX_ERR_NUM"));
/*     */       }
/* 212 */       log.debug("异常数据法阀值=" + err);
/*     */ 
/* 214 */       statement = dbconn.getConnection().prepareStatement(sql3);
/* 215 */       result = statement.executeQuery();
/* 216 */       int err2 = 0;
/* 217 */       while (result.next()) {
/* 218 */         err2 = result.getInt(1);
/*     */       }
/* 220 */       log.debug("异常数据法总数=" + err2);
/*     */ 
/* 222 */       if (err2 <= err) {
/* 223 */         log.debug("异常数据总数小于等于阀值");
/* 224 */         return true;
/*     */       }
/* 226 */       log.debug("异常数据总数大于阀值");
/* 227 */       step32();
/* 228 */       return false;
/*     */     }
/*     */     catch (SQLException e) {
/* 231 */       e.printStackTrace();
/* 232 */       log.error("step3=" + e.getMessage());
/* 233 */       dbconn.close();
/* 234 */     }return false;
/*     */   }
/*     */ 
/*     */   public static void step32()
/*     */   {
/* 240 */     String sql = "update T_S_WATCH t set t.C_STATE='3',t.C_END_TIME=to_char(sysdate,'yyyy-MM-dd hh24:mi:ss') where t.i_id=10";
/*     */     try {
/* 242 */       statement = dbconn.getConnection().prepareStatement(sql);
/* 243 */       statement.executeUpdate();
/* 244 */       statement.close();
/* 245 */       log.debug("设置万里通积分导入监控状态为失败!");
/*     */     } catch (SQLException e) {
/* 247 */       e.printStackTrace();
/* 248 */       log.error("step31=" + e.getMessage());
/* 249 */       dbconn.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.point.PointWCheck
 * JD-Core Version:    0.6.2
 */