/*    */ package com.bill.special;
/*    */ 
/*    */ import com.bill.bean.Card;
/*    */ import com.bill.bean.UserBase;
/*    */ import com.bill.make.PaperRelatingWrap;
/*    */ import com.bill.make.ResultTask;
/*    */ import com.bill.make.XMLWrite;
/*    */ import java.io.IOException;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.BlockingQueue;
/*    */ import java.util.concurrent.Callable;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class TaskComplex
/*    */   implements Callable<ResultTask>
/*    */ {
/* 25 */   private static Logger log = Logger.getLogger(TaskComplex.class);
/*    */   private BlockingQueue<List<UserBase>> queue;
/*    */   private XMLWrite write;
/*    */   private ResultTask result;
/*    */   private UserXmlBuild uxb;
/*    */   private Map<String, PaperRelatingWrap> map;
/* 31 */   private int complexNum = 0;
/* 32 */   private int receiveNum = 0;
/*    */   private Card card;
/*    */ 
/*    */   public TaskComplex(Card card, BlockingQueue<List<UserBase>> queue, XMLWrite write, Map<String, PaperRelatingWrap> map, String personId)
/*    */   {
/* 39 */     this.card = card;
/* 40 */     this.queue = queue;
/* 41 */     this.write = write;
/* 42 */     this.map = map;
/* 43 */     this.result = new ResultTask();
/*    */ 
/* 45 */     DBDao dao = new DBDao();
/* 46 */     dao.setPersonId(personId);
/* 47 */     this.uxb = new UserXmlBuild(
/* 48 */       new UserXml(dao));
/*    */   }
/*    */ 
/*    */   public ResultTask call()
/*    */   {
/* 54 */     long t1 = System.currentTimeMillis();
/*    */ 
/* 56 */     log.debug(this.card.getName() + "(" + this.card.getId() + ")  合成线程(" + Thread.currentThread().getName() + ")开始执行");
/*    */     try
/*    */     {
/*    */       List userList;
/* 59 */       while ((userList = (List)this.queue.take()) != Collections.EMPTY_LIST)
/*    */       {
/*    */         List userList;
/* 60 */         this.receiveNum += userList.size();
/* 61 */         process(userList);
/*    */       }
/* 63 */       this.result.setState(true);
/*    */     } catch (InterruptedException e) {
/* 65 */       this.result.setState(false);
/* 66 */       this.result.setErrorMessage(e.getMessage());
/* 67 */       log.error(this.card.getName() + "(" + this.card.getId() + ")  合成线程(" + Thread.currentThread().getName() + ")发生线程异常. " + e.getMessage());
/* 68 */       e.printStackTrace();
/*    */     } catch (IOException e) {
/* 70 */       this.result.setState(false);
/* 71 */       this.result.setErrorMessage(e.getMessage());
/* 72 */       log.error(this.card.getName() + "(" + this.card.getId() + ")  合成线程(" + Thread.currentThread().getName() + ")发生IO异常. " + e.getMessage());
/* 73 */       e.printStackTrace();
/*    */     }
/* 75 */     long t2 = System.currentTimeMillis();
/* 76 */     this.result.setTime(t2 - t1);
/* 77 */     this.result.setComplex(this.complexNum);
/* 78 */     this.result.setReceive(this.receiveNum);
/* 79 */     this.uxb.close();
/*    */ 
/* 81 */     log.debug(this.card.getName() + "(" + this.card.getId() + ")  合成线程(" + Thread.currentThread().getName() + ")结束执行");
/* 82 */     return this.result;
/*    */   }
/*    */ 
/*    */   private void process(List<UserBase> userList)
/*    */     throws IOException
/*    */   {
/* 91 */     int i = 0; for (int size = userList.size(); i < size; i++) {
/* 92 */       String email = null;
/* 93 */       String paper = null;
/* 94 */       UserBase ub = (UserBase)userList.get(i);
/* 95 */       this.uxb.setUser((UserBase)userList.get(i));
/*    */ 
/* 98 */       PaperRelatingWrap wrap = (PaperRelatingWrap)this.map.get(ub.getCity());
/* 99 */       if ((wrap != null) && ("Y".equals(ub.getPaperflag())))
/* 100 */         paper = this.uxb.getPaperXml(wrap.getBusin());
/*    */       else {
/* 102 */         log.trace(this.card.getName() + "(" + this.card.getId() + ")  没有纸制映射关系. 帐号:" + ub.getAcctnbr() + ", 城市:" + ub.getCity());
/*    */       }
/* 104 */       email = this.uxb.getEmailXml();
/*    */ 
/* 106 */       if ((paper == null) && (email == null)) {
/* 107 */         log.trace(this.card.getName() + "(" + this.card.getId() + ")  没有汇总信息. 账号= " + ub.getAcctnbr());
/*    */       }
/*    */       else {
/* 110 */         this.complexNum += 1;
/*    */ 
/* 113 */         this.write.println(email, paper, wrap);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.special.TaskComplex
 * JD-Core Version:    0.6.2
 */