/*      */ package com.bill.special;
/*      */ 
/*      */ import com.bill.bean.BaseParam;
/*      */ import com.bill.bean.Busin;
/*      */ import com.bill.bean.Card;
/*      */ import com.bill.bean.Debitinfo;
/*      */ import com.bill.bean.Fodder;
/*      */ import com.bill.bean.Foldout;
/*      */ import com.bill.bean.Plog;
/*      */ import com.bill.bean.PointInfo;
/*      */ import com.bill.bean.Rule;
/*      */ import com.bill.bean.RuleF;
/*      */ import com.bill.bean.RuleM;
/*      */ import com.bill.bean.TempArea;
/*      */ import com.bill.bean.Template;
/*      */ import com.bill.bean.UserAccinfo;
/*      */ import com.bill.bean.UserAccinfoDetail;
/*      */ import com.bill.bean.UserBase;
/*      */ import com.bill.bean.UserBuy;
/*      */ import com.bill.bean.Yyz;
/*      */ import com.bill.db.DbConnectionForOracle;
/*      */ import com.bill.make.PaperRelatingWrap;
/*      */ import com.bill.util.DBUtil;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.apache.log4j.Logger;
/*      */ 
/*      */ public class DBDao
/*      */ {
/*      */   private DbConnectionForOracle dbconn;
/*      */   private PreparedStatement statement;
/*      */   private ResultSet result;
/*      */   public Logger log;
/*      */   public DBUtil du;
/*      */   private String personId;
/*   48 */   private static String CARD_SQL = "select t.s_buss_prod_id,t.s_buss_prod_name,t.c_buss_type_id from T_S_BUSI_PROD_INFO t where t.c_buss_prod_flag='0' and t.C_BUSS_STATE='1' and t.c_buss_type_id='001'";
/*      */ 
/*   52 */   private static String BFPNT_SQL = "select t.s_id from t_s_befor_print_basic  t where  to_date(?,'yyyyMM')>= to_date(t.c_period_begen,'yyyy-MM') and to_date(?,'yyyyMM')<= to_date(t.c_period_end,'yyyy-MM') and t.c_period_day=?";
/*      */ 
/*   57 */   private static String CPB_CITY_SQL = "select t.s_city_no from t_s_bfpnt_cty_crdtp t where t.s_city_no is not null and t.s_card_no =? and t.s_id=? and t.s_businpnt_no=?";
/*      */ 
/*   62 */   private static String USER_BASE1 = "select * from (select tt.*, rownum RN from (select t.*, rownum from t_n_customer_bill t where C_CUR_PAPER_STMT_FLAG='Y' AND S_CARD_PROD_ID = ? and S_CITY_ID=? AND S_PERSON_NO=? and rownum < ?) tt ) where RN >= ?";
/*      */ 
/*   64 */   private static String USER_BASE2 = "select * from (select tt.*, rownum RN from (select t.*, rownum from t_n_customer_bill t where S_CARD_PROD_ID = ? AND S_PERSON_NO=? and rownum < ?) tt ) where RN >= ?";
/*      */ 
/*   69 */   private static String TEMPLATE_SQL = "select t.s_stencil_no,t.s_card_prod_id,t.c_type_no from T_S_STENCIL t where t.c_state='1'";
/*      */ 
/*   74 */   private static String RULE_SQL = "select * from t_s_rule_m t where t.s_stencil_no=? and t.c_rule_type=? and t.i_area_no=? and t.c_state='1' and to_date(?,'yyyyMM')>=to_date(t.c_period_begen,'yyyy-MM') and to_date(?,'yyyyMM')<=to_date(t.c_period_end,'yyyy-MM') and t.s_period like '%'||?||'%' order by t.i_pri desc";
/*      */ 
/* 1181 */   private static String CityYyyzWbsByCard_SQL = "select B.s_id,       B.S_BUSINPNT_NO,       A.S_PAPER_NO,       B.s_city_no,       A.i_print_pri,       (select t1.c_buss_type_id          from t_s_busi_prod_info t1         where t1.s_buss_prod_id = B.s_card_no) as c_buss_type_id  from (select t2.s_paper_no, t2.s_id,t2.i_print_pri          from t_s_befor_print_basic t2         where ? between t2.c_period_begen and t2.c_period_end           and t2.c_period_day = ?         order by t2.i_print_pri desc) A,       (select t.s_id, t.s_businpnt_no, t.s_card_no,t.s_city_no          from t_s_bfpnt_cty_crdtp t         where t.s_card_no = ?           AND t.s_id > '0'           and t.s_businpnt_no > '0') B         where A.s_Id = B.S_ID";
/*      */ 
/*      */   public DBDao()
/*      */   {
/*   80 */     this.dbconn = new DbConnectionForOracle(BaseParam.getDBIP(), 
/*   81 */       BaseParam.getDBPort(), BaseParam.getDBName(), BaseParam.getDBUser(), 
/*   82 */       BaseParam.getDBPwd());
/*   83 */     this.log = Logger.getLogger(DBDao.class);
/*   84 */     this.du = new DBUtil();
/*      */   }
/*      */ 
/*      */   public void close()
/*      */   {
/*   91 */     this.dbconn.close();
/*      */   }
/*      */ 
/*      */   public List<Busin> getBusin()
/*      */   {
/*   99 */     List list = new ArrayList();
/*      */     try {
/*  101 */       this.statement = this.dbconn
/*  102 */         .getConnection()
/*  103 */         .prepareStatement(
/*  104 */         "select t1.s_businpnt_no,t1.s_businpnt_name from T_S_EPLBOLY_PNT t1");
/*  105 */       this.result = this.statement.executeQuery();
/*      */ 
/*  107 */       while (this.result.next()) {
/*  108 */         Busin e = new Busin();
/*  109 */         e.setId(this.result.getString("s_businpnt_no"));
/*  110 */         e.setName(this.result.getString("s_businpnt_name"));
/*  111 */         list.add(e);
/*      */       }
/*  113 */       this.result.close();
/*  114 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  116 */       e.printStackTrace();
/*      */     }
/*  118 */     return list;
/*      */   }
/*      */ 
/*      */   public List<Card> getCard()
/*      */   {
/*  126 */     List list = new ArrayList();
/*      */     try {
/*  128 */       this.statement = this.dbconn.getConnection().prepareStatement(CARD_SQL);
/*  129 */       this.result = this.statement.executeQuery();
/*      */ 
/*  131 */       while (this.result.next()) {
/*  132 */         Card e = new Card();
/*  133 */         e.setId(this.result.getString("s_buss_prod_id"));
/*  134 */         e.setName(this.result.getString("s_buss_prod_name"));
/*  135 */         e.setType(this.result.getString("c_buss_type_id"));
/*  136 */         list.add(e);
/*      */       }
/*  138 */       this.result.close();
/*  139 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  141 */       e.printStackTrace();
/*      */     }
/*  143 */     return list;
/*      */   }
/*      */ 
/*      */   public Map<String, String> getBfpntMap()
/*      */   {
/*  151 */     Map map = new HashMap();
/*      */ 
/*  153 */     String ym = BaseParam.PERIOD.substring(0, 6);
/*      */ 
/*  155 */     String d = BaseParam.PERIOD.substring(6);
/*      */     try {
/*  157 */       this.statement = this.dbconn.getConnection().prepareStatement(BFPNT_SQL);
/*  158 */       this.statement.setString(1, ym);
/*  159 */       this.statement.setString(2, ym);
/*  160 */       this.statement.setString(3, d);
/*  161 */       this.result = this.statement.executeQuery();
/*      */ 
/*  163 */       String id = "";
/*  164 */       while (this.result.next()) {
/*  165 */         id = this.result.getString(1);
/*  166 */         map.put(id, id);
/*      */       }
/*  168 */       this.result.close();
/*  169 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  171 */       e.printStackTrace();
/*  172 */       return null;
/*      */     }
/*  174 */     return map;
/*      */   }
/*      */ 
/*      */   public Map<String, List<Yyz>> getCardBfpntMap()
/*      */   {
/*  182 */     Map map = new HashMap();
/*  183 */     StringBuffer sb = new StringBuffer();
/*  184 */     sb.append("select ");
/*  185 */     sb.append("t.s_card_no,t.s_id,t2.S_PAPER_NO");
/*  186 */     sb.append(" from t_s_bfpnt_cty_crdtp t,T_S_BEFOR_PRINT_BASIC t2");
/*  187 */     sb.append(" where ");
/*  188 */     sb.append("t.s_id=t2.s_id and t2.c_period_day=? and t2.c_period_begen<=? and t2.c_period_end>=?");
/*  189 */     sb.append(" group by t.s_card_no,t.s_id,t2.S_PAPER_NO");
/*      */     try {
/*  191 */       this.statement = this.dbconn
/*  192 */         .getConnection()
/*  193 */         .prepareStatement(sb.toString());
/*  194 */       this.statement.setString(1, BaseParam.PERIOD_D);
/*  195 */       this.statement.setString(2, BaseParam.PERIOD_Y + "-" + BaseParam.PERIOD_M);
/*  196 */       this.statement.setString(3, BaseParam.PERIOD_Y + "-" + BaseParam.PERIOD_M);
/*  197 */       this.result = this.statement.executeQuery();
/*      */ 
/*  199 */       String id1 = "";
/*      */ 
/*  201 */       while (this.result.next()) {
/*  202 */         Yyz y = new Yyz();
/*  203 */         id1 = this.result.getString("s_card_no");
/*  204 */         y.setId(this.result.getString("s_id"));
/*  205 */         y.setPaperNo(this.result.getString("S_PAPER_NO"));
/*  206 */         if (map.containsKey(id1)) {
/*  207 */           ((List)map.get(id1)).add(y);
/*      */         } else {
/*  209 */           List list = new ArrayList();
/*  210 */           list.add(y);
/*  211 */           map.put(id1, list);
/*      */         }
/*      */       }
/*  214 */       this.result.close();
/*  215 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  217 */       e.printStackTrace();
/*  218 */       return null;
/*      */     }
/*  220 */     return map;
/*      */   }
/*      */ 
/*      */   public List<String> getCityByCPB(String cid, String pid, String bid)
/*      */   {
/*  231 */     List list = new ArrayList();
/*      */     try {
/*  233 */       this.statement = this.dbconn.getConnection().prepareStatement(CPB_CITY_SQL);
/*  234 */       this.statement.setString(1, cid);
/*  235 */       this.statement.setString(2, pid);
/*  236 */       this.statement.setString(3, bid);
/*  237 */       this.result = this.statement.executeQuery();
/*  238 */       while (this.result.next()) {
/*  239 */         list.add(this.result.getString("S_CITY_NO"));
/*      */       }
/*  241 */       this.result.close();
/*  242 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  244 */       e.printStackTrace();
/*      */     }
/*  246 */     return list;
/*      */   }
/*      */ 
/*      */   public List<UserBase> getUserBase(String cardid, String city, int page, int size)
/*      */   {
/*  259 */     List list = new ArrayList();
/*      */     try {
/*  261 */       this.statement = this.dbconn.getConnection().prepareStatement(USER_BASE1);
/*  262 */       this.statement.setString(1, cardid);
/*  263 */       this.statement.setString(2, city);
/*  264 */       this.statement.setString(3, this.personId);
/*  265 */       this.statement.setInt(4, page * size);
/*  266 */       this.statement.setInt(5, (page - 1) * size);
/*  267 */       this.result = this.statement.executeQuery();
/*      */ 
/*  269 */       while (this.result.next()) {
/*  270 */         UserBase ub = new UserBase();
/*  271 */         ub.setAcctnbr(this.result.getString("S_ACCOUNT"));
/*  272 */         ub.setRectype(this.result.getString("S_CUR_TYPE"));
/*  273 */         ub.setZip(this.result.getString("S_CUR_ZIP"));
/*  274 */         ub.setAddrname3(this.result.getString("S_CUR_ADDR3"));
/*  275 */         ub.setAddrname1(this.result.getString("S_CUR_ADDR1"));
/*  276 */         ub.setAddrname2(this.result.getString("S_CUR_ADDR2"));
/*  277 */         ub.setName(this.result.getString("S_CUR_NAME"));
/*  278 */         ub.setSex(this.result.getString("C_CUR_SEX"));
/*  279 */         ub.setBirthday(this.result.getString("S_CUR_BIRTHDAY"));
/*  280 */         ub.setAccnum(this.result.getString("S_CUR_ACCOUNT"));
/*  281 */         ub.setCusnum(this.result.getString("S_CUR_CUST_NBR"));
/*  282 */         ub.setStfromdate(this.result.getString("S_CUR_START_DATE"));
/*  283 */         ub.setEnddate(this.result.getString("S_CUR_END_DATE"));
/*  284 */         ub.setSpecode(this.result.getString("S_CUR_SPECIAL_CHAR"));
/*  285 */         ub.setPmtduemark(this.result.getString("S_CUR_PMT_CYCLE_DUE"));
/*  286 */         ub.setCashmark(this.result.getString("S_CUR_PRINT"));
/*  287 */         ub.setIndiv1(this.result.getString("C_CUR_MSG_1"));
/*  288 */         ub.setIndiv2(this.result.getString("C_CUR_MSG_2"));
/*  289 */         ub.setIndiv3(this.result.getString("C_CUR_MSG_3"));
/*  290 */         ub.setIndiv4(this.result.getString("C_CUR_MSG_4"));
/*  291 */         ub.setIndiv5(this.result.getString("C_CUR_MSG_5"));
/*  292 */         ub.setIndiv6(this.result.getString("C_CUR_MSG_6"));
/*  293 */         ub.setIndiv7(this.result.getString("C_CUR_MSG_7"));
/*  294 */         ub.setIndiv8(this.result.getString("C_CUR_MSG_8"));
/*  295 */         ub.setActinfo(this.result.getString("C_CUR_ACTIVITY_MSG"));
/*  296 */         ub.setDm1(this.result.getString("C_CUR_DM_MSG_1"));
/*  297 */         ub.setDm2(this.result.getString("C_CUR_DM_MSG_2"));
/*  298 */         ub.setDm3(this.result.getString("C_CUR_DM_MSG_3"));
/*  299 */         ub.setDm4(this.result.getString("C_CUR_DM_MSG_4"));
/*  300 */         ub.setBrandmsg1(this.result.getString("C_CUR_BRAND_MSG_1"));
/*  301 */         ub.setBrandmsg2(this.result.getString("C_CUR_BRAND_MSG_2"));
/*  302 */         ub.setBrandmsg3(this.result.getString("C_CUR_BRAND_MSG_3"));
/*  303 */         ub.setBrandmsg4(this.result.getString("C_CUR_BRAND_MSG_4"));
/*  304 */         ub.setBrandmsg5(this.result.getString("C_CUR_BRAND_MSG_5"));
/*  305 */         ub.setBrandmsg6(this.result.getString("C_CUR_BRAND_MSG_6"));
/*  306 */         ub.setBrandmsg7(this.result.getString("C_CUR_BRAND_MSG_7"));
/*  307 */         ub.setConvexchmark(this.result.getString("C_CUR_CONV_EXCH_FLAG"));
/*  308 */         ub.setVipmsg1(this.result.getString("C_CUR_VIP_MSG_1"));
/*  309 */         ub.setVipmsg2(this.result.getString("C_CUR_VIP_MSG_2"));
/*  310 */         ub.setVipmsg3(this.result.getString("C_CUR_VIP_MSG_3"));
/*  311 */         ub.setVipmsg4(this.result.getString("C_CUR_VIP_MSG_4"));
/*  312 */         ub.setReprintflag(this.result.getString("C_CUR_REPRINT_FLAG"));
/*  313 */         ub.setEmailflag(this.result.getString("C_CUR_EMAIL_STMT_FLAG"));
/*  314 */         ub.setPaperflag(this.result.getString("C_CUR_PAPER_STMT_FLAG"));
/*  315 */         ub.setEmailaddr(this.result.getString("S_CUR_EMAIL_ADDR"));
/*  316 */         ub.setCusttype(this.result.getString("S_CUR_CUSTOMER_TYPE"));
/*  317 */         ub.setMobilenbr(this.result.getString("S_CUR_MOBILE_NBR"));
/*  318 */         ub.setAinbr(this.result.getString("S_CUR_AI_NBR"));
/*  319 */         ub.setMobdate(this.result.getString("C_CUR_MOB"));
/*  320 */         ub.setFiller(this.result.getString("S_CUR_FILLER"));
/*  321 */         ub.setCity(this.result.getString("S_CITY_ID"));
/*  322 */         ub.setCrlim(this.result.getString("I_CUR_CRLIM"));
/*  323 */         ub.setCurrbal(this.result.getString("I_CUR_BAL"));
/*  324 */         ub.setTotdueamt(this.result.getString("I_CUR_TOT_DUE_AMT"));
/*  325 */         ub.setCashcrlim(this.result.getString("I_CUR_CASH_CRLIM"));
/*  326 */         ub.setStmtdate(this.result.getString("C_STMT_DATE"));
/*  327 */         ub.setCardNo(this.result.getString("S_CARD_PROD_ID"));
/*  328 */         list.add(ub);
/*      */       }
/*  330 */       this.result.close();
/*  331 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  333 */       e.printStackTrace();
/*      */     }
/*  335 */     return list;
/*      */   }
/*      */ 
/*      */   public List<UserBase> getUserBase(String cardid, int page, int size)
/*      */   {
/*  346 */     List list = new ArrayList();
/*      */     try {
/*  348 */       this.statement = this.dbconn.getConnection().prepareStatement(USER_BASE2);
/*  349 */       this.statement.setString(1, cardid);
/*  350 */       this.statement.setString(2, this.personId);
/*      */ 
/*  352 */       this.statement.setInt(3, page * size);
/*      */ 
/*  354 */       this.statement.setInt(4, (page - 1) * size);
/*  355 */       this.result = this.statement.executeQuery();
/*      */ 
/*  357 */       while (this.result.next()) {
/*  358 */         UserBase ub = new UserBase();
/*  359 */         ub.setAcctnbr(this.result.getString("S_ACCOUNT"));
/*  360 */         ub.setRectype(this.result.getString("S_CUR_TYPE"));
/*  361 */         ub.setZip(this.result.getString("S_CUR_ZIP"));
/*  362 */         ub.setAddrname3(this.result.getString("S_CUR_ADDR3"));
/*  363 */         ub.setAddrname1(this.result.getString("S_CUR_ADDR1"));
/*  364 */         ub.setAddrname2(this.result.getString("S_CUR_ADDR2"));
/*  365 */         ub.setName(this.result.getString("S_CUR_NAME"));
/*  366 */         ub.setSex(this.result.getString("C_CUR_SEX"));
/*  367 */         ub.setBirthday(this.result.getString("S_CUR_BIRTHDAY"));
/*  368 */         ub.setAccnum(this.result.getString("S_CUR_ACCOUNT"));
/*  369 */         ub.setCusnum(this.result.getString("S_CUR_CUST_NBR"));
/*  370 */         ub.setStfromdate(this.result.getString("S_CUR_START_DATE"));
/*  371 */         ub.setEnddate(this.result.getString("S_CUR_END_DATE"));
/*  372 */         ub.setSpecode(this.result.getString("S_CUR_SPECIAL_CHAR"));
/*  373 */         ub.setPmtduemark(this.result.getString("S_CUR_PMT_CYCLE_DUE"));
/*  374 */         ub.setCashmark(this.result.getString("S_CUR_PRINT"));
/*  375 */         ub.setIndiv1(this.result.getString("C_CUR_MSG_1"));
/*  376 */         ub.setIndiv2(this.result.getString("C_CUR_MSG_2"));
/*  377 */         ub.setIndiv3(this.result.getString("C_CUR_MSG_3"));
/*  378 */         ub.setIndiv4(this.result.getString("C_CUR_MSG_4"));
/*  379 */         ub.setIndiv5(this.result.getString("C_CUR_MSG_5"));
/*  380 */         ub.setIndiv6(this.result.getString("C_CUR_MSG_6"));
/*  381 */         ub.setIndiv7(this.result.getString("C_CUR_MSG_7"));
/*  382 */         ub.setIndiv8(this.result.getString("C_CUR_MSG_8"));
/*  383 */         ub.setActinfo(this.result.getString("C_CUR_ACTIVITY_MSG"));
/*  384 */         ub.setDm1(this.result.getString("C_CUR_DM_MSG_1"));
/*  385 */         ub.setDm2(this.result.getString("C_CUR_DM_MSG_2"));
/*  386 */         ub.setDm3(this.result.getString("C_CUR_DM_MSG_3"));
/*  387 */         ub.setDm4(this.result.getString("C_CUR_DM_MSG_4"));
/*  388 */         ub.setBrandmsg1(this.result.getString("C_CUR_BRAND_MSG_1"));
/*  389 */         ub.setBrandmsg2(this.result.getString("C_CUR_BRAND_MSG_2"));
/*  390 */         ub.setBrandmsg3(this.result.getString("C_CUR_BRAND_MSG_3"));
/*  391 */         ub.setBrandmsg4(this.result.getString("C_CUR_BRAND_MSG_4"));
/*  392 */         ub.setBrandmsg5(this.result.getString("C_CUR_BRAND_MSG_5"));
/*  393 */         ub.setBrandmsg6(this.result.getString("C_CUR_BRAND_MSG_6"));
/*  394 */         ub.setBrandmsg7(this.result.getString("C_CUR_BRAND_MSG_7"));
/*  395 */         ub.setConvexchmark(this.result.getString("C_CUR_CONV_EXCH_FLAG"));
/*  396 */         ub.setVipmsg1(this.result.getString("C_CUR_VIP_MSG_1"));
/*  397 */         ub.setVipmsg2(this.result.getString("C_CUR_VIP_MSG_2"));
/*  398 */         ub.setVipmsg3(this.result.getString("C_CUR_VIP_MSG_3"));
/*  399 */         ub.setVipmsg4(this.result.getString("C_CUR_VIP_MSG_4"));
/*  400 */         ub.setReprintflag(this.result.getString("C_CUR_REPRINT_FLAG"));
/*  401 */         ub.setEmailflag(this.result.getString("C_CUR_EMAIL_STMT_FLAG"));
/*  402 */         ub.setPaperflag(this.result.getString("C_CUR_PAPER_STMT_FLAG"));
/*  403 */         ub.setEmailaddr(this.result.getString("S_CUR_EMAIL_ADDR"));
/*  404 */         ub.setCusttype(this.result.getString("S_CUR_CUSTOMER_TYPE"));
/*  405 */         ub.setMobilenbr(this.result.getString("S_CUR_MOBILE_NBR"));
/*  406 */         ub.setAinbr(this.result.getString("S_CUR_AI_NBR"));
/*  407 */         ub.setMobdate(this.result.getString("C_CUR_MOB"));
/*  408 */         ub.setFiller(this.result.getString("S_CUR_FILLER"));
/*  409 */         ub.setCity(this.result.getString("S_CITY_ID"));
/*  410 */         ub.setCrlim(this.result.getString("I_CUR_CRLIM"));
/*  411 */         ub.setCurrbal(this.result.getString("I_CUR_BAL"));
/*  412 */         ub.setTotdueamt(this.result.getString("I_CUR_TOT_DUE_AMT"));
/*  413 */         ub.setCashcrlim(this.result.getString("I_CUR_CASH_CRLIM"));
/*  414 */         ub.setStmtdate(this.result.getString("C_STMT_DATE"));
/*  415 */         ub.setCardNo(this.result.getString("S_CARD_PROD_ID"));
/*  416 */         list.add(ub);
/*      */       }
/*  418 */       this.result.close();
/*  419 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  421 */       e.printStackTrace();
/*      */     }
/*  423 */     return list;
/*      */   }
/*      */ 
/*      */   public List<UserAccinfo> getUserInfo(UserBase base)
/*      */   {
/*  433 */     List list = new ArrayList();
/*  434 */     StringBuffer sql = new StringBuffer();
/*  435 */     sql.append("select ");
/*  436 */     sql.append("acctnbr,rectype,stmtdate,pmtdate,to_char(totbegbal,'fm9999999999999999990.00') as totbegbal");
/*  437 */     sql.append(",to_char(plantotpmt,'fm9999999999999999990.00') as plantotpmt");
/*  438 */     sql.append(",to_char(plantotnrlamt,'fm9999999999999999990.00') as plantotnrlamt,to_char(plantotadjamt,'fm9999999999999999990.00') as plantotadjamt");
/*  439 */     sql.append(",to_char(intdueamt,'fm9999999999999999990.00') as intdueamt,to_char(currbal,'fm9999999999999999990.00') as currbal");
/*  440 */     sql.append(",to_char(totdueamt,'fm9999999999999999990.00') as totdueamt,pmtprint,to_char(crlim,'fm9999999999999999990.00') as crlim,to_char(cashcrlim,'fm9999999999999999990.00') as cashcrlim");
/*  441 */     sql.append(",pmtarn,pmtadn,to_char(projap,'fm9999999999999999990.00') as projap,pmtaflag,achflag,pmtflag,filler");
/*  442 */     sql.append(" from view_n_customer_bill t where t.acctnbr=?  AND personid=?");
/*      */     try {
/*  444 */       this.statement = this.dbconn
/*  445 */         .getConnection()
/*  446 */         .prepareStatement(sql.toString());
/*  447 */       this.statement.setString(1, base.getAcctnbr());
/*  448 */       this.statement.setString(2, this.personId);
/*  449 */       this.result = this.statement.executeQuery();
/*      */ 
/*  451 */       while (this.result.next()) {
/*  452 */         UserAccinfo ub = new UserAccinfo();
/*  453 */         ub.setAcctnbr(this.result.getString("acctnbr"));
/*  454 */         ub.setRectype(this.result.getString("rectype"));
/*  455 */         ub.setStmtdate(this.result.getString("stmtdate"));
/*  456 */         ub.setPmtdate(this.result.getString("pmtdate"));
/*  457 */         ub.setTotbegbal(this.result.getString("totbegbal"));
/*  458 */         ub.setPlantotpmt(this.result.getString("plantotpmt"));
/*  459 */         ub.setPlantotnrlamt(this.result.getString("plantotnrlamt"));
/*  460 */         ub.setPlantotadjamt(this.result.getString("plantotadjamt"));
/*  461 */         ub.setIntdueamt(this.result.getString("intdueamt"));
/*  462 */         ub.setCurrbal(this.result.getString("currbal"));
/*  463 */         ub.setTotdueamt(this.result.getString("totdueamt"));
/*  464 */         ub.setPmtprint(this.result.getString("pmtprint"));
/*  465 */         ub.setCrlim(this.result.getString("crlim"));
/*  466 */         ub.setCashcrlim(this.result.getString("cashcrlim"));
/*  467 */         ub.setPmtarn(this.result.getString("pmtarn"));
/*  468 */         ub.setPmtadn(this.result.getString("pmtadn"));
/*  469 */         ub.setProjap(this.result.getString("projap"));
/*  470 */         ub.setPmtaflag(this.result.getString("pmtaflag"));
/*  471 */         ub.setAchflag(this.result.getString("achflag"));
/*  472 */         ub.setPmtflag(this.result.getString("pmtflag"));
/*  473 */         ub.setFiller(this.result.getString("filler"));
/*  474 */         list.add(ub);
/*      */       }
/*  476 */       this.result.close();
/*  477 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  479 */       e.printStackTrace();
/*      */     }
/*  481 */     return list;
/*      */   }
/*      */ 
/*      */   public List<UserAccinfoDetail> getAccinfoDetail(UserBase user)
/*      */   {
/*  490 */     List list = new ArrayList();
/*  491 */     StringBuffer sb = new StringBuffer();
/*  492 */     sb.append("select ");
/*  493 */     sb.append("acctnbr,rectype,recseq,effdate,postdate,cardnlast4,curdesc,to_char(txnamt,'fm9999999999999999990.00') as txnamt,to_char(srctamt,'fm9999999999999999990.00') as srctamt,srctcurr,purcty,filler");
/*  494 */     sb.append(" from view_n_customer_bill_detail t where t.acctnbr=? AND personid=?");
/*      */     try {
/*  496 */       this.statement = this.dbconn
/*  497 */         .getConnection()
/*  498 */         .prepareStatement(sb.toString());
/*  499 */       this.statement.setString(1, user.getAcctnbr());
/*  500 */       this.statement.setString(2, this.personId);
/*  501 */       this.result = this.statement.executeQuery();
/*      */ 
/*  503 */       while (this.result.next()) {
/*  504 */         UserAccinfoDetail ub = new UserAccinfoDetail();
/*  505 */         ub.setAcctnbr(this.result.getString("acctnbr"));
/*  506 */         ub.setRectype(this.result.getString("rectype"));
/*  507 */         ub.setRecseq(this.result.getString("recseq"));
/*  508 */         ub.setEffdate(this.result.getString("effdate"));
/*  509 */         ub.setPostdate(this.result.getString("postdate"));
/*  510 */         ub.setCardnlast4(this.result.getString("cardnlast4"));
/*  511 */         ub.setDesc(this.result.getString("curdesc"));
/*  512 */         ub.setTxnamt(this.result.getString("txnamt"));
/*  513 */         ub.setSrctamt(this.result.getString("srctamt"));
/*  514 */         ub.setSrctcurr(this.result.getString("srctcurr"));
/*  515 */         ub.setPurcty(this.result.getString("purcty"));
/*  516 */         ub.setFiller(this.result.getString("filler"));
/*  517 */         list.add(ub);
/*      */       }
/*  519 */       this.result.close();
/*  520 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  522 */       e.printStackTrace();
/*      */     }
/*  524 */     return list;
/*      */   }
/*      */ 
/*      */   public UserBuy getUserBuy(UserBase user) {
/*  528 */     UserBuy ub = null;
/*      */     try {
/*  530 */       this.statement = this.dbconn
/*  531 */         .getConnection()
/*  532 */         .prepareStatement(
/*  533 */         "select * from T_N_CUSTOMER_PURCHASE t where t.S_ACCOUNT=? AND t.S_PERSON_NO=?");
/*  534 */       this.statement.setString(1, user.getAcctnbr());
/*  535 */       this.statement.setString(2, this.personId);
/*  536 */       this.result = this.statement.executeQuery();
/*  537 */       while (this.result.next()) {
/*  538 */         ub = new UserBuy();
/*  539 */         ub.setAcctnbr(this.result.getString("S_ACCOUNT"));
/*  540 */         ub.setRectype(this.result.getString("S_CUR_PUR_REC_TYPE"));
/*  541 */         ub.setExchusdamt(this.result.getString("I_CUR_PUR_EXCH_USD_AMT"));
/*  542 */         ub.setSellrate(this.result.getString("I_CUR_PUR_SELL_RATE"));
/*  543 */         ub.setExchrmbamt(this.result.getString("I_CUR_PUR_EXCH_RMB_AMT"));
/*  544 */         ub.setAchrtnbr(this.result.getString("S_CUR_PUR_PMT_ACH_RT_NBR"));
/*  545 */         ub.setAchdbnbr(this.result.getString("S_CUR_PUR_PMT_ACH_DB_NBR"));
/*  546 */         ub.setFiller(this.result.getString("S_CUR_PUR_FILLER"));
/*      */       }
/*  548 */       this.result.close();
/*  549 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  551 */       e.printStackTrace();
/*  552 */       return null;
/*      */     }
/*  554 */     return ub;
/*      */   }
/*      */ 
/*      */   public List<Debitinfo> getDebitinfo(UserBase user)
/*      */   {
/*  563 */     List list = new ArrayList();
/*  564 */     Debitinfo deb = null;
/*  565 */     StringBuffer sb = new StringBuffer();
/*  566 */     sb.append("select ");
/*  567 */     sb.append("acctnbr,rectype,custnbr,effdate,txndesc,txncity,currcode,NVL(to_char(txnamt,'fm9999999999999999999990.00'),' ') as txnamt");
/*  568 */     sb.append(",cardl4,filler");
/*  569 */     sb.append(" from view_n_crad_trade_detail t where t.acctnbr=? AND t.personid=?");
/*      */     try {
/*  571 */       this.statement = this.dbconn
/*  572 */         .getConnection()
/*  573 */         .prepareStatement(sb.toString());
/*  574 */       this.statement.setString(1, user.getAcctnbr());
/*  575 */       this.statement.setString(2, this.personId);
/*  576 */       this.result = this.statement.executeQuery();
/*  577 */       while (this.result.next()) {
/*  578 */         deb = new Debitinfo();
/*  579 */         deb.setAcctnbr(this.result.getString("acctnbr"));
/*  580 */         deb.setRectype(this.result.getString("rectype"));
/*  581 */         deb.setCustnbr(this.result.getString("custnbr"));
/*  582 */         deb.setEffdate(this.result.getString("effdate"));
/*  583 */         deb.setTxndesc(this.result.getString("txndesc"));
/*  584 */         deb.setTxncity(this.result.getString("txncity"));
/*  585 */         deb.setCurrcode(this.result.getString("currcode"));
/*  586 */         deb.setTxnamt(this.result.getString("txnamt"));
/*  587 */         deb.setCardl4(this.result.getString("cardl4"));
/*  588 */         deb.setFiller(this.result.getString("filler"));
/*  589 */         list.add(deb);
/*      */       }
/*  591 */       this.result.close();
/*  592 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  594 */       e.printStackTrace();
/*  595 */       return null;
/*      */     }
/*  597 */     return list;
/*      */   }
/*      */ 
/*      */   public List<PointInfo> getPoint(UserBase user)
/*      */   {
/*      */     try
/*      */     {
/*  609 */       String sql = "select S_POINT_TYPE,S_ACCT_PROD_ID,S_BUSINESS_ID,I_ABLE_POINT,I_LASTBAL_POINT,I_ADDPOINT_POINT,I_EXPOINT_POINT,I_ADPOINTS_POINT,I_ENDPOINTS_POINT,S_ECIF_NO,S_START_DATE,S_END_DATE,to_char(I_WHOLE_CONSUME,'fm99999990.00') as I_WHOLE_CONSUME,to_char(I_IN_CONSUME,'fm99999990.00') as I_IN_CONSUME,to_char(I_OUT_CONSUME,'fm99999990.00') as I_OUT_CONSUME,to_char(I_WHOLE_MONEY,'fm99999990.00') as I_WHOLE_MONEY,to_char(I_IN_MONEY,'fm99999990.00') as I_IN_MONEY,to_char(I_OUT_MONEY,'fm99999990.00') as I_OUT_MONEY,to_char(I_USED_MONEY,'fm99999990.00') as I_USED_MONEY,to_char(I_LAVE_MONEY,'fm99999990.00') as I_LAVE_MONEY,S_VALID_DATE,I_LADDER_MONEY,S_LADDER_SCALE,C_CARD_LAST4,C_CARD_POINT_TYPE,S_CARD_POINT_NAME from t_n_point_x where S_BUSINESS_ID=? and S_PERSON_NO=?";
/*      */ 
/*  620 */       this.statement = this.dbconn
/*  621 */         .getConnection()
/*  622 */         .prepareStatement(sql);
/*  623 */       this.statement.setString(1, user.getAcctnbr());
/*  624 */       this.statement.setString(2, this.personId);
/*  625 */       this.result = this.statement.executeQuery();
/*      */ 
/*  627 */       List list = this.du.getPointXResult(this.result);
/*  628 */       this.result.close();
/*  629 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  631 */       e.printStackTrace();
/*  632 */       return null;
/*      */     }
/*      */     List list;
/*  634 */     return list;
/*      */   }
/*      */ 
/*      */   public PointInfo getPoint2(UserBase user)
/*      */   {
/*  644 */     PointInfo p = null;
/*      */     try {
/*  646 */       this.statement = this.dbconn
/*  647 */         .getConnection()
/*  648 */         .prepareStatement(
/*  649 */         "select * from T_N_POINT_W where S_ECIF_NO=?  AND S_PERSON_NO=?");
/*  650 */       if (user.getCusnum().length() > 12) {
/*  651 */         this.statement.setString(1, user.getCusnum().substring(7));
/*      */       }
/*      */       else {
/*  654 */         this.statement.setString(1, user.getCusnum());
/*      */       }
/*  656 */       this.statement.setString(2, this.personId);
/*  657 */       this.result = this.statement.executeQuery();
/*  658 */       while (this.result.next()) {
/*  659 */         p = new PointInfo();
/*  660 */         p.setBilldate(this.result.getString("C_STMT_DATE"));
/*  661 */         p.setBusinessid(this.result.getString("S_ECIF_NO"));
/*  662 */         p.setAblepoint(this.result.getString("I_ENDPOINT"));
/*  663 */         p.setEndpoints(this.result.getString("I_VALIDPOINT_B"));
/*  664 */         p.setLastbalpoint(this.result.getString("I_NEWPOINT"));
/*  665 */         p.setAddpoint(this.result.getString("I_USEDPOINT"));
/*  666 */         p.setExpoint(this.result.getString("I_ADJUSTPOINT"));
/*  667 */         p.setAdpoints(this.result.getString("I_INVAILPOINT"));
/*  668 */         p.setExpirespoint(this.result.getString("I_EXPIRES_POINT"));
/*      */       }
/*  670 */       this.result.close();
/*  671 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  673 */       e.printStackTrace();
/*  674 */       return null;
/*      */     }
/*  676 */     return p;
/*      */   }
/*      */ 
/*      */   public List<Template> getTemplateList()
/*      */   {
/*  684 */     List list = new ArrayList();
/*      */     try {
/*  686 */       this.statement = this.dbconn.getConnection().prepareStatement(TEMPLATE_SQL);
/*  687 */       this.result = this.statement.executeQuery();
/*      */ 
/*  689 */       while (this.result.next()) {
/*  690 */         Template t = new Template();
/*  691 */         t.setId(this.result.getString("S_STENCIL_NO"));
/*  692 */         t.setCardid(this.result.getString("S_CARD_PROD_ID"));
/*  693 */         t.setType(this.result.getString("C_TYPE_NO"));
/*  694 */         list.add(t);
/*      */       }
/*  696 */       this.result.close();
/*  697 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  699 */       e.printStackTrace();
/*      */     }
/*  701 */     return list;
/*      */   }
/*      */ 
/*      */   public List<Rule> getRule(String tid, String type, String area, String billdayYM, String billdayD)
/*      */   {
/*  715 */     List list = new ArrayList();
/*      */     try {
/*  717 */       this.statement = this.dbconn.getConnection().prepareStatement(RULE_SQL);
/*  718 */       this.statement.setString(1, tid);
/*  719 */       this.statement.setString(2, type);
/*  720 */       this.statement.setString(3, area);
/*  721 */       this.statement.setString(4, billdayYM);
/*  722 */       this.statement.setString(5, billdayYM);
/*  723 */       this.statement.setString(6, billdayD);
/*  724 */       this.result = this.statement.executeQuery();
/*      */ 
/*  726 */       while (this.result.next()) {
/*  727 */         Rule r = new Rule();
/*  728 */         r.setRuleid(this.result.getString("S_RULE_NO"));
/*  729 */         r.setTid(this.result.getString("S_STENCIL_NO"));
/*  730 */         r.setRuleType(this.result.getString("C_RULE_TYPE"));
/*  731 */         r.setType(this.result.getString("C_TYPENO"));
/*  732 */         r.setPri(this.result.getString("I_PRI"));
/*  733 */         r.setAreaNo(this.result.getString("I_AREA_NO"));
/*  734 */         list.add(r);
/*      */       }
/*  736 */       this.result.close();
/*  737 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  739 */       e.printStackTrace();
/*      */     }
/*  741 */     return list;
/*      */   }
/*      */ 
/*      */   public List<RuleF> getRuleF(String rid)
/*      */   {
/*  749 */     List list = new ArrayList();
/*      */     try {
/*  751 */       this.statement = this.dbconn
/*  752 */         .getConnection()
/*  753 */         .prepareStatement(
/*  754 */         "select * from t_s_rule_f t where t.s_rule_no=? order by t.i_pri desc");
/*  755 */       this.statement.setString(1, rid);
/*  756 */       this.result = this.statement.executeQuery();
/*      */ 
/*  758 */       while (this.result.next()) {
/*  759 */         RuleF r = new RuleF();
/*  760 */         r.setId(this.result.getString("S_SEQUENCE"));
/*  761 */         r.setRid(this.result.getString("S_RULE_NO"));
/*  762 */         r.setFodder(this.result.getString("S_FODDER_NO"));
/*  763 */         r.setPri(this.result.getString("I_PRI"));
/*  764 */         list.add(r);
/*      */       }
/*  766 */       this.result.close();
/*  767 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  769 */       e.printStackTrace();
/*      */     }
/*  771 */     return list;
/*      */   }
/*      */ 
/*      */   public List<RuleM> getRuleFF(String rid)
/*      */   {
/*  779 */     List list = new ArrayList();
/*      */     try {
/*  781 */       this.statement = this.dbconn
/*  782 */         .getConnection()
/*  783 */         .prepareStatement(
/*  784 */         "select * from t_s_rule_ff t where t.s_sequence=? order by t.s_idx");
/*  785 */       this.statement.setString(1, rid);
/*  786 */       this.result = this.statement.executeQuery();
/*      */ 
/*  788 */       while (this.result.next()) {
/*  789 */         RuleM r = new RuleM();
/*  790 */         r.setFieldid(this.result.getString("S_FIELD"));
/*  791 */         r.setOpr1(this.result.getInt("C_OPR_1"));
/*  792 */         r.setVal1(this.result.getString("S_VALIUE_1"));
/*  793 */         r.setOpr2(this.result.getInt("C_OPR_2"));
/*  794 */         r.setVal2(this.result.getString("S_VALIUE_2"));
/*  795 */         r.setCif(this.result.getInt("C_IF"));
/*  796 */         list.add(r);
/*      */       }
/*  798 */       this.result.close();
/*  799 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  801 */       e.printStackTrace();
/*      */     }
/*  803 */     return list;
/*      */   }
/*      */ 
/*      */   public List<TempArea> getTemplateInfo(String tid)
/*      */   {
/*  810 */     List list = new ArrayList();
/*      */     try {
/*  812 */       this.statement = this.dbconn
/*  813 */         .getConnection()
/*  814 */         .prepareStatement(
/*  815 */         "select t.i_area_no,t.c_type_no from t_s_area t where t.s_stencil_no=?");
/*  816 */       this.statement.setString(1, tid);
/*  817 */       this.result = this.statement.executeQuery();
/*      */ 
/*  819 */       while (this.result.next()) {
/*  820 */         TempArea ta = new TempArea();
/*  821 */         ta.setArea(this.result.getString("i_area_no"));
/*  822 */         ta.setType(this.result.getString("c_type_no"));
/*  823 */         list.add(ta);
/*      */       }
/*  825 */       this.result.close();
/*  826 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  828 */       e.printStackTrace();
/*      */     }
/*  830 */     return list;
/*      */   }
/*      */ 
/*      */   public Fodder getFodder(String fid, String d)
/*      */   {
/*  840 */     Fodder fodder = null;
/*      */     try {
/*  842 */       this.statement = this.dbconn
/*  843 */         .getConnection()
/*  844 */         .prepareStatement(
/*  845 */         "select t.s_fodder_no,t.s_fodder_doc_name,t.s_url from T_S_FODDER  t where t.s_fodder_no=? and t.c_state='1' and to_date(?, 'yyyyMM') between to_date(t.c_period_begen, 'yyyy-MM') and to_date(t.c_period_end, 'yyyy-MM')");
/*  846 */       this.statement.setString(1, fid);
/*  847 */       this.statement.setString(2, d);
/*  848 */       this.result = this.statement.executeQuery();
/*  849 */       while (this.result.next()) {
/*  850 */         fodder = new Fodder();
/*  851 */         fodder.setFid(this.result.getString("s_fodder_no"));
/*  852 */         fodder.setUrl(this.result.getString("s_fodder_doc_name"));
/*  853 */         fodder.setLinkurl(this.result.getString("s_url"));
/*      */       }
/*  855 */       this.result.close();
/*  856 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  858 */       this.log.error("素材查询失败！1=" + fid + ",2=" + d);
/*  859 */       e.printStackTrace();
/*  860 */       return null;
/*      */     }
/*  862 */     return fodder;
/*      */   }
/*      */ 
/*      */   public List<Foldout> getFoldout(String bid, String cid, String billdate)
/*      */   {
/*  873 */     List list = new ArrayList();
/*  874 */     Foldout foldout = null;
/*      */     try {
/*  876 */       String sql = "select I_FOLDOUT_INDEX,S_FOLDOUT_PROD_NAME,I_FOLDOUT_PRI,C_FOLDOUT_STATE,I_ID from T_S_FOLDOUT_PROD t2 where t2.i_id =(select t.i_id from T_S_FOLDOUT_PROD_SUB t where t.s_foldout_businpnt_no = ? and t.s_foldout_prod_bpid = ? and t.c_period = ? and to_date(?,'yyyyMM') between to_date(t.c_period_begen,'yyyy-MM') and to_date(t.c_period_end,'yyyy-MM')) order by t2.i_foldout_index";
/*      */ 
/*  881 */       this.statement = this.dbconn.getConnection().prepareStatement(sql);
/*  882 */       this.statement.setString(1, bid);
/*  883 */       this.statement.setString(2, cid);
/*  884 */       this.statement.setString(3, billdate.substring(6));
/*  885 */       this.statement.setString(4, billdate.substring(0, 6));
/*  886 */       this.result = this.statement.executeQuery();
/*  887 */       while (this.result.next()) {
/*  888 */         foldout = new Foldout();
/*  889 */         foldout.setId(this.result.getString("I_ID"));
/*  890 */         foldout.setName(this.result.getString("S_FOLDOUT_PROD_NAME"));
/*  891 */         foldout.setPri(this.result.getInt("I_FOLDOUT_PRI"));
/*  892 */         foldout.setState(this.result.getString("C_FOLDOUT_STATE"));
/*  893 */         foldout.setIdx(this.result.getString("I_FOLDOUT_INDEX"));
/*  894 */         list.add(foldout);
/*      */       }
/*  896 */       this.result.close();
/*  897 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  899 */       e.printStackTrace();
/*      */     }
/*      */     finally {
/*  902 */       return list;
/*      */     }
/*      */   }
/*      */ 
/*      */   public Map<String, String> getFoldoutCity(String id, String idx)
/*      */   {
/*  915 */     Map map = new HashMap();
/*  916 */     String city = "";
/*      */     try {
/*  918 */       String sql = "select t.s_foldout_city from t_s_foldout_city t where t.i_id=? and t.i_foldout_index=?";
/*  919 */       this.statement = this.dbconn.getConnection().prepareStatement(sql);
/*  920 */       this.statement.setString(1, id);
/*  921 */       this.statement.setString(2, idx);
/*  922 */       this.result = this.statement.executeQuery();
/*  923 */       while (this.result.next()) {
/*  924 */         city = this.result.getString("s_foldout_city");
/*  925 */         map.put(city, city);
/*      */       }
/*  927 */       this.result.close();
/*  928 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  930 */       e.printStackTrace();
/*      */     }
/*      */     finally {
/*  933 */       return map;
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean clearDBLog(String personid)
/*      */   {
/*  966 */     PreparedStatement ps = null;
/*      */     boolean bool;
/*      */     boolean bool;
/*      */     try
/*      */     {
/*  969 */       ps = this.dbconn.getConnection().prepareStatement(
/*  970 */         "delete T_N_XML_LOG where S_PERSON_NO=?");
/*  971 */       ps.setString(1, personid);
/*  972 */       ps.executeUpdate();
/*  973 */       bool = true;
/*      */     }
/*      */     catch (SQLException e)
/*      */     {
/*      */       boolean bool;
/*  975 */       boolean bool = false;
/*  976 */       this.log.error("清除生成日志失败, (" + personid + "), " + e.getMessage());
/*  977 */       e.printStackTrace();
/*      */ 
/*  980 */       if (ps != null)
/*      */         try {
/*  982 */           ps.close();
/*      */         } catch (SQLException e) {
/*  984 */           boolean bool = false;
/*  985 */           this.log.error("清除生成日志后关闭Statement异常, (" + this.personId + "), " + e.getMessage());
/*  986 */           e.printStackTrace();
/*      */         }
/*      */     }
/*      */     finally
/*      */     {
/*  980 */       if (ps != null) {
/*      */         try {
/*  982 */           ps.close();
/*      */         } catch (SQLException e) {
/*  984 */           boolean bool = false;
/*  985 */           this.log.error("清除生成日志后关闭Statement异常, (" + this.personId + "), " + e.getMessage());
/*  986 */           e.printStackTrace();
/*      */         }
/*      */       }
/*      */     }
/*  990 */     return bool;
/*      */   }
/*      */ 
/*      */   public boolean recordDBLog(Plog plog)
/*      */   {
/*  998 */     PreparedStatement ps = null;
/*      */     boolean bool;
/*      */     boolean bool;
/*      */     try {
/* 1001 */       ps = this.dbconn.getConnection().prepareStatement(
/* 1002 */         "insert into T_N_XML_LOG (S_PERIOD, S_FILENAME, S_BUSINPNT_NO, I_SHARE, C_START_TIME, C_END_TIME, S_CARD_PROD_ID, S_PAPER_NO, C_STATE, S_PERSON_NO) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
/*      */ 
/* 1015 */       ps.setString(1, BaseParam.PERIOD);
/* 1016 */       ps.setString(2, plog.getFilename());
/* 1017 */       ps.setString(3, plog.getBusinpnt_no());
/* 1018 */       ps.setInt(4, plog.getShare());
/* 1019 */       ps.setString(5, plog.getStart_time());
/* 1020 */       ps.setString(6, plog.getEnd_time());
/* 1021 */       ps.setString(7, plog.getCard_id());
/* 1022 */       ps.setString(8, plog.getPaper_no());
/* 1023 */       ps.setString(9, plog.getState());
/* 1024 */       ps.setString(10, this.personId);
/* 1025 */       ps.execute();
/* 1026 */       bool = true;
/*      */     }
/*      */     catch (SQLException e)
/*      */     {
/*      */       boolean bool;
/* 1028 */       boolean bool = false;
/* 1029 */       this.log.error("新增生成日志失败, " + plog + ", " + e.getMessage());
/* 1030 */       e.printStackTrace();
/*      */ 
/* 1032 */       if (ps != null)
/*      */         try {
/* 1034 */           ps.close();
/*      */         } catch (SQLException e) {
/* 1036 */           boolean bool = false;
/* 1037 */           this.log.error("新增生成日志后关闭Statement异常, " + plog + ", " + e.getMessage());
/* 1038 */           e.printStackTrace();
/*      */         }
/*      */     }
/*      */     finally
/*      */     {
/* 1032 */       if (ps != null) {
/*      */         try {
/* 1034 */           ps.close();
/*      */         } catch (SQLException e) {
/* 1036 */           boolean bool = false;
/* 1037 */           this.log.error("新增生成日志后关闭Statement异常, " + plog + ", " + e.getMessage());
/* 1038 */           e.printStackTrace();
/*      */         }
/*      */       }
/*      */     }
/* 1042 */     return bool;
/*      */   }
/*      */ 
/*      */   public Map<String, String> getConfig()
/*      */   {
/* 1156 */     Map cmap = new HashMap();
/*      */     try {
/* 1158 */       this.statement = this.dbconn.getConnection().prepareStatement(
/* 1159 */         "select t.s_type,t.s_value from t_s_bill_para t");
/* 1160 */       this.result = this.statement.executeQuery();
/* 1161 */       while (this.result.next())
/* 1162 */         cmap.put(this.result.getString("s_type"), this.result
/* 1163 */           .getString("s_value"));
/*      */     }
/*      */     catch (SQLException e) {
/* 1166 */       e.printStackTrace();
/* 1167 */       return cmap;
/*      */     }
/* 1169 */     return cmap;
/*      */   }
/*      */ 
/*      */   public String getPersonId() {
/* 1173 */     return this.personId;
/*      */   }
/*      */ 
/*      */   public void setPersonId(String personId) {
/* 1177 */     this.personId = personId;
/*      */   }
/*      */ 
/*      */   public Map<String, PaperRelatingWrap> getCityYyyzWbsByCard(String cardId)
/*      */   {
/* 1202 */     Map map = new HashMap();
/* 1203 */     PaperRelatingWrap prw = null;
/*      */     try {
/* 1205 */       this.statement = this.dbconn.getConnection().prepareStatement(CityYyyzWbsByCard_SQL);
/* 1206 */       this.statement.setString(1, BaseParam.PERIOD_Y + "-" + BaseParam.PERIOD_M);
/* 1207 */       this.statement.setString(2, BaseParam.PERIOD_D);
/* 1208 */       this.statement.setString(3, cardId);
/* 1209 */       this.result = this.statement.executeQuery();
/* 1210 */       String city = "";
/* 1211 */       while (this.result.next()) {
/* 1212 */         city = this.result.getString("S_CITY_NO");
/*      */ 
/* 1214 */         if (!map.containsKey(city))
/*      */         {
/* 1217 */           prw = new PaperRelatingWrap();
/* 1218 */           prw.setBusin(this.result.getString("S_BUSINPNT_NO"));
/* 1219 */           prw.setCity(city);
/* 1220 */           prw.setYyzNo(this.result.getString("S_PAPER_NO"));
/* 1221 */           prw.setYyzId(this.result.getString("S_ID"));
/* 1222 */           map.put(city, prw);
/*      */         }
/*      */       }
/* 1225 */       this.result.close();
/* 1226 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1228 */       e.printStackTrace();
/*      */     }
/* 1230 */     return map;
/*      */   }
/*      */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.special.DBDao
 * JD-Core Version:    0.6.2
 */