/*     */ package com.bill.special;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.bean.Busin;
/*     */ import com.bill.bean.Card;
/*     */ import com.bill.bean.Debitinfo;
/*     */ import com.bill.bean.Fodder;
/*     */ import com.bill.bean.Foldout;
/*     */ import com.bill.bean.PointInfo;
/*     */ import com.bill.bean.Rule;
/*     */ import com.bill.bean.RuleF;
/*     */ import com.bill.bean.RuleM;
/*     */ import com.bill.bean.TempArea;
/*     */ import com.bill.bean.Template;
/*     */ import com.bill.bean.UserAccinfo;
/*     */ import com.bill.bean.UserAccinfoDetail;
/*     */ import com.bill.bean.UserBase;
/*     */ import com.bill.bean.UserBuy;
/*     */ import com.bill.bean.Yyz;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class Cache
/*     */ {
/*     */   public static Map<String, String> configMap;
/*     */   public static List<Busin> businList;
/*     */   public static List<Card> cardList;
/*     */   public static Map<String, String> bfpntMap;
/*     */   public static Map<String, List<Yyz>> cardBfpntMap;
/*     */   public static Map<String, String> templateMap;
/*     */   private static DBDao dao;
/*  69 */   private static Map<String, List<TempArea>> templateInfo = Collections.synchronizedMap(new HashMap());
/*     */ 
/*  76 */   private static Map<String, List<Rule>> ruleMap = Collections.synchronizedMap(new HashMap());
/*  77 */   private static Map<String, List<RuleF>> ruleFMap = Collections.synchronizedMap(new HashMap());
/*  78 */   private static Map<String, List<RuleM>> ruleMMap = Collections.synchronizedMap(new HashMap());
/*     */ 
/*  83 */   private static Map<String, Fodder> fodderMap = Collections.synchronizedMap(new HashMap());
/*     */ 
/*  88 */   private static Map<String, List<Foldout>> foldoutMap = Collections.synchronizedMap(new HashMap());
/*     */ 
/*  93 */   private static Map<String, Map<String, String>> foldoutCityMap = Collections.synchronizedMap(new HashMap());
/*     */ 
/*     */   public static List<String> getCityByCPB(String cardid, String printid, String businId, DBDao dbdao)
/*     */   {
/* 103 */     return dbdao.getCityByCPB(cardid, printid, businId);
/*     */   }
/*     */ 
/*     */   public static List<UserBase> getUserBase(String cardid, String city, int page, int size, DBDao dbdao)
/*     */   {
/* 113 */     return dbdao.getUserBase(cardid, city, page, size);
/*     */   }
/*     */ 
/*     */   public static List<UserAccinfo> getUserInfo(UserBase ub, DBDao dbdao)
/*     */   {
/* 122 */     return dbdao.getUserInfo(ub);
/*     */   }
/*     */ 
/*     */   public static List<UserAccinfoDetail> getAccinfoDetail(UserBase ub, DBDao dbdao)
/*     */   {
/* 131 */     return dbdao.getAccinfoDetail(ub);
/*     */   }
/*     */ 
/*     */   public static UserBuy getUserBuy(UserBase ub, DBDao dbdao)
/*     */   {
/* 140 */     return dbdao.getUserBuy(ub);
/*     */   }
/*     */ 
/*     */   public static List<Debitinfo> getDebitinfo(UserBase user, DBDao dbdao) {
/* 144 */     return dbdao.getDebitinfo(user);
/*     */   }
/*     */ 
/*     */   public static List<PointInfo> getPoint(UserBase user, DBDao dbdao) {
/* 148 */     return dbdao.getPoint(user);
/*     */   }
/*     */ 
/*     */   public static PointInfo getPoint2(UserBase user, DBDao dbdao) {
/* 152 */     return dbdao.getPoint2(user);
/*     */   }
/*     */ 
/*     */   public static List<Rule> getRuleMap(String tid, String type, String area, DBDao dbdao)
/*     */   {
/* 179 */     String key = tid + "_" + type + "_" + area;
/* 180 */     List value = (List)ruleMap.get(key);
/* 181 */     if (value == null)
/*     */     {
/* 183 */       value = dbdao.getRule(tid, type, area, BaseParam.PERIOD_YM, BaseParam.PERIOD_D);
/* 184 */       ruleMap.put(key, value);
/*     */     }
/* 186 */     return value;
/*     */   }
/*     */ 
/*     */   public static List<RuleF> getRuleFMap(String rid, DBDao dbdao)
/*     */   {
/* 195 */     List value = (List)ruleFMap.get(rid);
/* 196 */     if (value == null) {
/* 197 */       value = dbdao.getRuleF(rid);
/* 198 */       ruleFMap.put(rid, value);
/*     */     }
/* 200 */     return value;
/*     */   }
/*     */ 
/*     */   public static List<RuleM> getRuleFFList(String rid, DBDao dbdao)
/*     */   {
/* 210 */     List value = (List)ruleMMap.get(rid);
/* 211 */     if (value == null) {
/* 212 */       value = dbdao.getRuleFF(rid);
/* 213 */       ruleMMap.put(rid, value);
/*     */     }
/* 215 */     return value;
/*     */   }
/*     */ 
/*     */   public static List<TempArea> getTemplateInfo(String tid, DBDao dbdao)
/*     */   {
/* 224 */     List value = (List)templateInfo.get(tid);
/* 225 */     if (value == null) {
/* 226 */       value = dbdao.getTemplateInfo(tid);
/* 227 */       templateInfo.put(tid, value);
/*     */     }
/* 229 */     return value;
/*     */   }
/*     */ 
/*     */   public static Fodder getFodder(String fid, DBDao dbdao)
/*     */   {
/* 238 */     Fodder value = (Fodder)fodderMap.get(fid);
/* 239 */     if (value == null) {
/* 240 */       value = dbdao.getFodder(fid, BaseParam.PERIOD_YM);
/* 241 */       fodderMap.put(fid, value);
/*     */     }
/* 243 */     return value;
/*     */   }
/*     */ 
/*     */   public static List<Foldout> getFoldout(String bid, String cid, DBDao dbdao)
/*     */   {
/* 253 */     String key = bid + "_" + cid;
/* 254 */     List value = (List)foldoutMap.get(key);
/* 255 */     if (value == null) {
/* 256 */       value = dbdao.getFoldout(bid, cid, BaseParam.getPeriod(""));
/* 257 */       int i = value.size();
/* 258 */       Foldout f = null;
/* 259 */       for (; i < 4; i++) {
/* 260 */         f = new Foldout();
/* 261 */         f.setPri(1);
/* 262 */         f.setState("0");
/* 263 */         value.add(f);
/*     */       }
/* 265 */       foldoutMap.put(key, value);
/*     */     }
/* 267 */     return value;
/*     */   }
/*     */ 
/*     */   public static Map<String, String> getFoldoutCity(String id, String idx, DBDao dbdao)
/*     */   {
/* 276 */     String key = id + "_" + idx;
/* 277 */     Map value = (Map)foldoutCityMap.get(key);
/* 278 */     if (value == null) {
/* 279 */       value = dbdao.getFoldoutCity(id, idx);
/* 280 */       foldoutCityMap.put(key, value);
/*     */     }
/* 282 */     return value;
/*     */   }
/*     */ 
/*     */   public static void init()
/*     */   {
/* 314 */     if (dao == null) {
/* 315 */       dao = new DBDao();
/*     */     }
/* 317 */     if (configMap == null) {
/* 318 */       configMap = dao.getConfig();
/*     */ 
/* 320 */       BaseParam.setPeriod((String)configMap.get("PERIOD"));
/* 321 */       BaseParam.XML_PATH = (String)configMap.get("BASEPATH");
/*     */     }
/* 323 */     if (businList == null)
/*     */     {
/* 325 */       businList = dao.getBusin();
/*     */     }
/* 327 */     if (cardList == null)
/*     */     {
/* 329 */       cardList = dao.getCard();
/*     */     }
/* 331 */     if (bfpntMap == null)
/*     */     {
/* 333 */       bfpntMap = dao.getBfpntMap();
/*     */     }
/* 335 */     if (cardBfpntMap == null)
/*     */     {
/* 337 */       cardBfpntMap = dao.getCardBfpntMap();
/*     */     }
/* 339 */     if (templateMap == null)
/*     */     {
/* 341 */       templateMap = getTemplateMap();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static Map<String, String> getTemplateMap()
/*     */   {
/* 353 */     List list = dao.getTemplateList();
/* 354 */     Map map = new HashMap();
/* 355 */     String key = "";
/* 356 */     for (Template t : list) {
/* 357 */       key = t.getCardid() + "_" + t.getType();
/* 358 */       map.put(key, t.getId());
/*     */     }
/* 360 */     return map;
/*     */   }
/*     */ 
/*     */   public static void close()
/*     */   {
/* 367 */     dao.close();
/*     */   }
/*     */ 
/*     */   public static boolean clearLog(String personId)
/*     */   {
/* 376 */     return dao.clearDBLog(personId);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.special.Cache
 * JD-Core Version:    0.6.2
 */