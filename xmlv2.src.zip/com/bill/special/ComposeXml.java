/*     */ package com.bill.special;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.bean.Card;
/*     */ import com.bill.make.Common;
/*     */ import com.bill.make.LogInit;
/*     */ import com.bill.util.config.ConfigReader;
/*     */ import java.io.PrintStream;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class ComposeXml
/*     */ {
/*  28 */   private static Logger log = Logger.getLogger(ComposeXml.class);
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/*  36 */       Map argsMap = checkArgs(args);
/*     */ 
/*  38 */       if (argsMap.get("-u").equals("")) {
/*  39 */         System.out.println("##### userid is empty program finish.");
/*  40 */         return;
/*     */       }
/*     */     } catch (Exception e) {
/*  43 */       System.out.println("##### program parameter is error.");
/*  44 */       e.printStackTrace();
/*     */       return;
/*     */     }
/*     */     Map argsMap;
/*  48 */     System.out.println("##### XML compound program start");
/*     */     try
/*     */     {
/*  52 */       ConfigReader.init();
/*     */     } catch (Exception e) {
/*  54 */       System.out.println("##### read properties file error, file path:" + ConfigReader.class.getClassLoader().getResource(ConfigReader.CONFIG_PATH));
/*  55 */       e.printStackTrace();
/*  56 */       return;
/*     */     }
/*  58 */     BaseParam.DB_IP = ConfigReader.read("db.ip");
/*  59 */     BaseParam.DB_PORT = ConfigReader.read("db.port");
/*  60 */     BaseParam.DB_NAME = ConfigReader.read("db.name");
/*  61 */     BaseParam.DB_USER = ConfigReader.read("db.user");
/*  62 */     BaseParam.DB_PWD = ConfigReader.read("db.pwd");
/*     */ 
/*  64 */     System.out.println("##### load config cache data");
/*     */ 
/*  67 */     Cache.init();
/*     */ 
/*  70 */     LogInit.init((String)Cache.configMap.get("LOG4J_COFIG_PATH"), 
/*  71 */       (String)Cache.configMap.get("BASEPATH") + "WEB/LOG/spec_xml.log");
/*     */ 
/*  74 */     if (!Cache.clearLog((String)argsMap.get("-u"))) {
/*  75 */       System.out.println("##### XML compound program stop, clear log error.");
/*  76 */       log.info("程序清除生产日志异常(" + (String)argsMap.get("-u") + ", " + BaseParam.PERIOD + ")，停止执行.");
/*  77 */       Cache.close();
/*  78 */       return;
/*     */     }
/*     */ 
/*  82 */     List taskes = new ArrayList();
/*  83 */     int maxThread = ((Integer)argsMap.get("-t")).intValue();
/*  84 */     int average = maxThread / Cache.cardList.size();
/*     */ 
/*  86 */     if (average == 0) {
/*  87 */       average = 1;
/*     */     }
/*  89 */     for (Card card : Cache.cardList) {
/*  90 */       taskes.add(new TaskAllot(
/*  91 */         card, 
/*  92 */         average, 
/*  93 */         ((Integer)argsMap.get("-b")).intValue(), 
/*  94 */         (String)argsMap.get("-u"), 
/*  95 */         ((Boolean)argsMap.get("-lt")).booleanValue(), 
/*  96 */         ((Boolean)argsMap.get("-lf")).booleanValue()));
/*     */     }
/*     */ 
/* 101 */     ExecutorService exec = Executors.newCachedThreadPool();
/* 102 */     List result = null;
/*     */ 
/* 104 */     SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*     */ 
/* 106 */     Date date = new Date();
/* 107 */     long t1 = date.getTime();
/*     */ 
/* 109 */     log.info("程序开始执行, 任务线程:" + maxThread + ", 时间:" + sdf.format(date));
/*     */     try
/*     */     {
/* 113 */       result = exec.invokeAll(taskes);
/* 114 */       exec.shutdown();
/*     */     }
/*     */     catch (InterruptedException e) {
/* 117 */       e.printStackTrace();
/*     */     } catch (RejectedExecutionException e) {
/* 119 */       log.error("任务无法安排执行");
/* 120 */       e.printStackTrace();
/*     */     } finally {
/* 122 */       Cache.close();
/*     */     }
/*     */ 
/* 125 */     date = new Date();
/* 126 */     long t2 = date.getTime();
/* 127 */     log.info("----------------------------------------------------------");
/*     */ 
/* 129 */     if (result != null) {
/* 130 */       for (Future f : result) {
/*     */         try {
/* 132 */           log.info(f.get());
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 136 */           e.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/* 140 */     log.info("生成结束, 时间:" + sdf.format(date) + ", 耗时:" + Common.timeFormat(t2 - t1));
/* 141 */     System.out.println("##### program finish");
/* 142 */     System.exit(0);
/*     */   }
/*     */ 
/*     */   private static Map<String, Object> checkArgs(String[] args)
/*     */     throws Exception
/*     */   {
/* 150 */     Map argsMap = new HashMap();
/*     */ 
/* 152 */     argsMap.put("-t", Integer.valueOf(20));
/* 153 */     argsMap.put("-b", Integer.valueOf(500));
/* 154 */     argsMap.put("-lf", Boolean.valueOf(true));
/* 155 */     argsMap.put("-lt", Boolean.valueOf(false));
/* 156 */     argsMap.put("-u", "");
/*     */ 
/* 158 */     int i = 0; for (int size = args.length; i < size; i++) {
/* 159 */       String s = args[i];
/* 160 */       if ((s.equals("-t")) || (s.equals("-b"))) {
/* 161 */         if (i + 1 < size) {
/* 162 */           i++;
/* 163 */           argsMap.put(s, Integer.valueOf(Integer.parseInt(args[i])));
/*     */         }
/*     */       }
/* 166 */       else if ("-u".equals(s)) {
/* 167 */         if (i + 1 < size) {
/* 168 */           i++;
/* 169 */           argsMap.put(s, args[i]);
/*     */         }
/*     */ 
/*     */       }
/* 173 */       else if (argsMap.containsKey(s)) {
/* 174 */         argsMap.put(s, Boolean.valueOf(true));
/*     */       }
/*     */     }
/* 177 */     return argsMap;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.special.ComposeXml
 * JD-Core Version:    0.6.2
 */