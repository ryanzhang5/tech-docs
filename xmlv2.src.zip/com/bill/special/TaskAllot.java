/*     */ package com.bill.special;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.bean.Busin;
/*     */ import com.bill.bean.Card;
/*     */ import com.bill.bean.Plog;
/*     */ import com.bill.bean.Yyz;
/*     */ import com.bill.make.Common;
/*     */ import com.bill.make.PaperRelatingWrap;
/*     */ import com.bill.make.ResultTask;
/*     */ import com.bill.make.ResultWrite;
/*     */ import com.bill.make.XMLWrite;
/*     */ import com.bill.make.XmlFileOutput;
/*     */ import java.io.File;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ArrayBlockingQueue;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class TaskAllot
/*     */   implements Callable<String>
/*     */ {
/*  42 */   private static Logger log = Logger.getLogger(TaskAllot.class);
/*     */   private Card card;
/*     */   private int maxThreedNumber;
/*     */   private int maxBatchNumber;
/*     */   private boolean hasCompleInfo;
/*     */   private boolean hasFileInfo;
/*     */   private String personId;
/*     */ 
/*     */   public TaskAllot(Card card, int maxThreedNumber, int maxBatchNumber, String personId, boolean hasCompleInfo, boolean hasFileInfo)
/*     */   {
/*  55 */     this.card = card;
/*  56 */     this.maxThreedNumber = maxThreedNumber;
/*  57 */     this.maxBatchNumber = maxBatchNumber;
/*  58 */     this.personId = personId;
/*  59 */     this.hasCompleInfo = hasCompleInfo;
/*  60 */     this.hasFileInfo = hasFileInfo;
/*  61 */     this.card.setPersonId(personId);
/*     */   }
/*     */ 
/*     */   public String call()
/*     */     throws Exception
/*     */   {
/*  68 */     log.debug(this.card.getName() + "(" + this.card.getId() + ")  任务线程开始执行. 启动线程数:" + 
/*  69 */       this.maxThreedNumber + " 批次数据:" + this.maxBatchNumber);
/*     */ 
/*  71 */     clearFile();
/*     */ 
/*  75 */     ExecutorService exec = Executors.newFixedThreadPool(this.maxThreedNumber + 1);
/*     */ 
/*  77 */     BlockingQueue queue = new ArrayBlockingQueue(this.maxThreedNumber);
/*     */ 
/*  80 */     TaskData select = new TaskData(this.maxBatchNumber, this.maxThreedNumber, queue, this.card, this.personId);
/*  81 */     exec.execute(select);
/*     */ 
/*  83 */     DBDao dao = new DBDao();
/*  84 */     dao.setPersonId(this.personId);
/*     */ 
/*  87 */     Map relatMap = getMap(dao);
/*     */ 
/*  90 */     XMLWrite write = new XMLWrite(this.card, new FilePathCreate());
/*     */ 
/*  93 */     List tasks = new ArrayList();
/*  94 */     for (int i = 0; i < this.maxThreedNumber; i++) {
/*  95 */       tasks.add(new TaskComplex(this.card, queue, write, relatMap, this.personId));
/*     */     }
/*     */ 
/*  98 */     long t1 = System.currentTimeMillis();
/*  99 */     List resList = null;
/*     */     try
/*     */     {
/* 102 */       resList = exec.invokeAll(tasks);
/*     */     } catch (InterruptedException e) {
/* 104 */       e.printStackTrace();
/*     */     }
/* 106 */     exec.shutdown();
/* 107 */     long t2 = System.currentTimeMillis();
/*     */ 
/* 110 */     write.close();
/*     */ 
/* 113 */     writeDBLog(write, dao);
/*     */ 
/* 116 */     dao.close();
/*     */ 
/* 119 */     String str = this.card.getName() + ": " + 
/* 120 */       " 查询:" + select.getQueryNum() + 
/* 121 */       "条, 写入:" + write.getWriteNum() + 
/* 122 */       "条, 耗时:" + Common.timeFormat(t2 - t1);
/*     */ 
/* 124 */     if (this.hasCompleInfo) {
/* 125 */       str = str + getComplexResult(resList);
/*     */     }
/* 127 */     if (this.hasFileInfo) {
/* 128 */       str = str + getWriteResult(write);
/*     */     }
/* 130 */     log.debug(this.card.getName() + "(" + this.card.getId() + ")  任务线程结束执行");
/* 131 */     return str;
/*     */   }
/*     */ 
/*     */   private void clearFile()
/*     */   {
/* 140 */     String xmlDir = BaseParam.XML_PATH + this.card.getType() + File.separator + "SPEC" + File.separator + 
/* 141 */       "XML" + File.separator + this.card.getPersonId();
/* 142 */     File file = new File(xmlDir);
/* 143 */     if (file.exists()) {
/* 144 */       File[] fileList = file.listFiles();
/* 145 */       for (File f : fileList) {
/* 146 */         f.delete();
/*     */       }
/* 148 */       file.delete();
/* 149 */       log.trace(this.card.getName() + "(" + this.card.getId() + ")  删除(" + this.card.getPersonId() + ")下xml文件");
/*     */     }
/*     */ 
/* 152 */     String pdfDir = BaseParam.XML_PATH + this.card.getType() + File.separator + "SPEC" + File.separator + 
/* 153 */       "PDF" + File.separator + this.card.getPersonId();
/*     */ 
/* 155 */     file = new File(pdfDir);
/* 156 */     if (file.exists()) {
/* 157 */       File[] fileList = file.listFiles();
/* 158 */       for (File f : fileList) {
/* 159 */         f.delete();
/*     */       }
/* 161 */       file.delete();
/* 162 */       log.trace(this.card.getName() + "(" + this.card.getId() + ")  删除(" + this.card.getPersonId() + ")下pdf文件");
/*     */     }
/*     */ 
/* 165 */     String htmlDir = BaseParam.XML_PATH + this.card.getType() + File.separator + "SPEC" + File.separator + 
/* 166 */       "HTML" + File.separator + this.card.getPersonId();
/* 167 */     file = new File(htmlDir);
/* 168 */     if (file.exists()) {
/* 169 */       File[] fileList = file.listFiles();
/* 170 */       for (File f : fileList) {
/* 171 */         f.delete();
/*     */       }
/* 173 */       file.delete();
/* 174 */       log.trace(this.card.getName() + "(" + this.card.getId() + ")  删除(" + this.card.getPersonId() + ")下html文件");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void writeDBLog(XMLWrite write, DBDao dao)
/*     */   {
/* 183 */     Plog p = new Plog();
/* 184 */     p.setCard_id(this.card.getId());
/* 185 */     p.setPaper_no("");
/* 186 */     p.setState("1");
/* 187 */     SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 188 */     Date date = new Date();
/*     */ 
/* 190 */     XmlFileOutput eOut = write.getEmailOut();
/*     */ 
/* 192 */     for (ResultWrite rw : eOut.getHistory()) {
/* 193 */       p.setShare(rw.getWriteNum());
/* 194 */       p.setFilename(rw.getFilePath());
/*     */ 
/* 196 */       date.setTime(rw.getCreateTime());
/* 197 */       p.setStart_time(sdf.format(date));
/*     */ 
/* 199 */       date.setTime(rw.getEndTime());
/* 200 */       p.setEnd_time(sdf.format(date));
/*     */ 
/* 203 */       if (!dao.recordDBLog(p)) {
/* 204 */         log.error(this.card.getName() + "(" + this.card.getId() + ") 文件:" + rw.getFileName() + " 记录生产日志失败");
/*     */       }
/*     */     }
/*     */ 
/* 208 */     Collection list = write.getPaperOut();
/*     */     Iterator localIterator3;
/* 209 */     for (Iterator localIterator2 = list.iterator(); localIterator2.hasNext(); 
/* 214 */       localIterator3.hasNext())
/*     */     {
/* 209 */       XmlFileOutput pOut = (XmlFileOutput)localIterator2.next();
/*     */ 
/* 211 */       p.setBusinpnt_no(pOut.getWbsId());
/* 212 */       p.setPaper_no(pOut.getYyzId());
/*     */ 
/* 214 */       localIterator3 = pOut.getHistory().iterator(); continue; ResultWrite rw = (ResultWrite)localIterator3.next();
/* 215 */       p.setShare(rw.getWriteNum());
/* 216 */       p.setFilename(rw.getFilePath());
/*     */ 
/* 218 */       date.setTime(rw.getCreateTime());
/* 219 */       p.setStart_time(sdf.format(date));
/*     */ 
/* 221 */       date.setTime(rw.getEndTime());
/* 222 */       p.setEnd_time(sdf.format(date));
/*     */ 
/* 225 */       if (!dao.recordDBLog(p))
/* 226 */         log.error(this.card.getName() + "(" + this.card.getId() + ") 文件:" + rw.getFileName() + " 记录生产日志失败");
/*     */     }
/*     */   }
/*     */ 
/*     */   private Map<String, PaperRelatingWrap> getMap(DBDao dao)
/*     */   {
/* 239 */     List yyzlist = (List)Cache.cardBfpntMap.get(this.card.getId());
/* 240 */     List wbsList = Cache.businList;
/*     */ 
/* 243 */     if ((yyzlist == null) || (yyzlist.size() == 0)) {
/* 244 */       log.info(this.card.getName() + "(" + this.card.getId() + ")  不存在卡产品对应的预印纸");
/* 245 */       return Collections.EMPTY_MAP;
/*     */     }
/* 247 */     if ((wbsList == null) || (wbsList.size() == 0)) {
/* 248 */       log.info(this.card.getName() + "(" + this.card.getId() + ")  不存在外包商");
/* 249 */       return Collections.EMPTY_MAP;
/*     */     }
/*     */ 
/* 253 */     Map relatMap = new HashMap();
/*     */     Iterator localIterator2;
/* 255 */     for (Iterator localIterator1 = yyzlist.iterator(); localIterator1.hasNext(); 
/* 256 */       localIterator2.hasNext())
/*     */     {
/* 255 */       Yyz yyz = (Yyz)localIterator1.next();
/* 256 */       localIterator2 = wbsList.iterator(); continue; Busin busin = (Busin)localIterator2.next();
/* 257 */       List cityList = Cache.getCityByCPB(this.card.getId(), yyz.getId(), busin.getId(), dao);
/* 258 */       if (cityList.size() == 0) {
/* 259 */         log.info(this.card.getName() + "(" + this.card.getId() + ")  没有关联的城市, 预印纸:" + yyz.getId() + ", 外包商:" + busin.getId());
/*     */       }
/*     */       else {
/* 262 */         for (String city : cityList) {
/* 263 */           PaperRelatingWrap wrap = new PaperRelatingWrap();
/* 264 */           wrap.setBusin(busin.getId());
/* 265 */           wrap.setCity(city);
/* 266 */           wrap.setYyzNo(yyz.getPaperNo());
/* 267 */           wrap.setYyzId(yyz.getId());
/* 268 */           relatMap.put(city, wrap);
/*     */         }
/*     */       }
/*     */     }
/* 272 */     return relatMap;
/*     */   }
/*     */ 
/*     */   private String getWriteResult(XMLWrite write)
/*     */   {
/* 281 */     StringBuilder sb = new StringBuilder();
/* 282 */     XmlFileOutput eOut = write.getEmailOut();
/* 283 */     if (eOut.getHistory().size() > 0) {
/* 284 */       sb.append("\n   电子xml文件:");
/* 285 */       for (ResultWrite rw : eOut.getHistory()) {
/* 286 */         sb.append("\n   ").append(rw.getFileName()).append("   ").append(rw.getWriteNum());
/*     */       }
/*     */     }
/* 289 */     Collection coll = write.getPaperOut();
/* 290 */     if (coll.size() > 0) {
/* 291 */       String temp = "\n   纸制xml文件:";
/* 292 */       StringBuilder s = new StringBuilder();
/*     */       Iterator localIterator3;
/* 293 */       for (Iterator localIterator2 = coll.iterator(); localIterator2.hasNext(); 
/* 294 */         localIterator3.hasNext())
/*     */       {
/* 293 */         XmlFileOutput pOut = (XmlFileOutput)localIterator2.next();
/* 294 */         localIterator3 = pOut.getHistory().iterator(); continue; ResultWrite rw = (ResultWrite)localIterator3.next();
/* 295 */         s.append("\n   ").append(rw.getFileName()).append("   ").append(rw.getWriteNum());
/*     */       }
/*     */ 
/* 298 */       if (s.length() > 0) {
/* 299 */         sb.append(temp).append(s.toString());
/*     */       }
/*     */     }
/* 302 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private String getComplexResult(List<Future<ResultTask>> resList)
/*     */   {
/* 311 */     StringBuilder sb = new StringBuilder();
/*     */ 
/* 325 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.special.TaskAllot
 * JD-Core Version:    0.6.2
 */