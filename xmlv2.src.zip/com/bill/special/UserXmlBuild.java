/*     */ package com.bill.special;
/*     */ 
/*     */ import com.bill.bean.UserBase;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class UserXmlBuild
/*     */ {
/*  15 */   private Map<String, String> cache = new HashMap();
/*     */   private UserBase ub;
/*     */   private UserXml ux;
/*     */ 
/*     */   public UserXmlBuild(UserXml ux)
/*     */   {
/*  21 */     this.ux = ux;
/*     */   }
/*     */ 
/*     */   public void setUser(UserBase ub) {
/*  25 */     this.cache.clear();
/*  26 */     this.ub = ub;
/*     */   }
/*     */ 
/*     */   public String getEmailXml()
/*     */   {
/*  35 */     String temp = getAccInfo();
/*  36 */     if (temp == null) {
/*  37 */       return null;
/*     */     }
/*  39 */     StringBuilder sb = new StringBuilder();
/*  40 */     sb.append("<checksheet>\n");
/*     */ 
/*  43 */     sb.append(getBaseInfo());
/*     */ 
/*  46 */     sb.append("<ENVRULE>0000</ENVRULE>\n")
/*  47 */       .append("<INPRIORITY1>0</INPRIORITY1>\n")
/*  48 */       .append("<INPRIORITY2>0</INPRIORITY2>\n")
/*  49 */       .append("<INPRIORITY3>0</INPRIORITY3>\n")
/*  50 */       .append("<INPRIORITY4>0</INPRIORITY4>\n");
/*     */ 
/*  53 */     sb.append(temp);
/*     */ 
/*  56 */     sb.append(getAccInfoDetail());
/*     */ 
/*  59 */     sb.append(getBuy());
/*     */ 
/*  62 */     sb.append(getDebitInfo());
/*     */ 
/*  65 */     sb.append(getPoint());
/*     */ 
/*  68 */     sb.append(getEmailTemplate());
/*     */ 
/*  70 */     sb.append("</checksheet>\n");
/*  71 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String getPaperXml(String wbs)
/*     */   {
/*  81 */     String temp = getAccInfo();
/*  82 */     if (temp == null) {
/*  83 */       return null;
/*     */     }
/*  85 */     StringBuilder sb = new StringBuilder();
/*  86 */     sb.append("<checksheet>\n");
/*     */ 
/*  89 */     sb.append(getBaseInfo());
/*     */ 
/*  92 */     sb.append(getPaperEnvrule(wbs));
/*     */ 
/*  95 */     sb.append(temp);
/*     */ 
/*  98 */     sb.append(getAccInfoDetail());
/*     */ 
/* 101 */     sb.append(getBuy());
/*     */ 
/* 104 */     sb.append(getDebitInfo());
/*     */ 
/* 107 */     sb.append(getPoint());
/*     */ 
/* 110 */     sb.append(getPaperTemplate());
/*     */ 
/* 112 */     sb.append("</checksheet>\n");
/* 113 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public void close() {
/* 117 */     this.ux.close();
/*     */   }
/*     */ 
/*     */   protected String getBaseInfo()
/*     */   {
/* 125 */     String value = (String)this.cache.get("base");
/* 126 */     if (value == null) {
/* 127 */       value = this.ux.getBaseXml(this.ub);
/* 128 */       this.cache.put("base", value);
/*     */     }
/* 130 */     return value;
/*     */   }
/*     */ 
/*     */   protected String getAccInfo()
/*     */   {
/* 138 */     String value = (String)this.cache.get("accinfo");
/* 139 */     if (value == null) {
/* 140 */       value = this.ux.getAccInfoXml(this.ub);
/* 141 */       this.cache.put("accinfo", value);
/*     */     }
/* 143 */     return value;
/*     */   }
/*     */ 
/*     */   protected String getAccInfoDetail()
/*     */   {
/* 151 */     String value = (String)this.cache.get("accinfodetail");
/* 152 */     if (value == null) {
/* 153 */       value = this.ux.getAccinfoDetail(this.ub);
/* 154 */       this.cache.put("accinfodetail", value);
/*     */     }
/* 156 */     return value;
/*     */   }
/*     */ 
/*     */   protected String getBuy()
/*     */   {
/* 164 */     String value = (String)this.cache.get("buy");
/* 165 */     if (value == null) {
/* 166 */       value = this.ux.getBuy(this.ub);
/* 167 */       this.cache.put("buy", value);
/*     */     }
/* 169 */     return value;
/*     */   }
/*     */ 
/*     */   protected String getDebitInfo()
/*     */   {
/* 177 */     String value = (String)this.cache.get("debitinfo");
/* 178 */     if (value == null) {
/* 179 */       value = this.ux.getDebitInfo(this.ub);
/* 180 */       this.cache.put("debitinfo", value);
/*     */     }
/* 182 */     return value;
/*     */   }
/*     */ 
/*     */   protected String getPoint()
/*     */   {
/* 190 */     String value = (String)this.cache.get("point");
/* 191 */     if (value == null) {
/* 192 */       value = this.ux.getPoint(this.ub);
/* 193 */       this.cache.put("point", value);
/*     */     }
/* 195 */     return value;
/*     */   }
/*     */ 
/*     */   protected String getEmailTemplate()
/*     */   {
/* 203 */     String temp = this.ux.writeTemplate(this.ub, "2").toString();
/* 204 */     return temp;
/*     */   }
/*     */ 
/*     */   protected String getPaperTemplate()
/*     */   {
/* 212 */     String temp = this.ux.writeTemplate(this.ub, "1").toString();
/* 213 */     return temp;
/*     */   }
/*     */ 
/*     */   protected String getPaperEnvrule(String wbs) {
/* 217 */     String temp = this.ux.getEnvrule(wbs, this.ub);
/* 218 */     return temp;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.special.UserXmlBuild
 * JD-Core Version:    0.6.2
 */