/*    */ package com.bill.ftp;
/*    */ 
/*    */ import com.bill.makeXML.cache.Cache;
/*    */ import com.bill.makeXML.util.LogInit;
/*    */ import com.bill.util.config.ConfigReader;
/*    */ import java.io.File;
/*    */ import java.util.Map;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class UploadLetter
/*    */ {
/*    */   private static Logger log;
/*    */ 
/*    */   public static void uploadDeductMoneyFile(String filePath)
/*    */     throws Throwable
/*    */   {
/* 17 */     ConfigReader.init();
/* 18 */     com.bill.bean.BaseParam.DB_IP = ConfigReader.read("db.ip");
/* 19 */     com.bill.bean.BaseParam.DB_PORT = ConfigReader.read("db.port");
/* 20 */     com.bill.bean.BaseParam.DB_NAME = ConfigReader.read("db.name");
/* 21 */     com.bill.bean.BaseParam.DB_USER = ConfigReader.read("db.user");
/* 22 */     com.bill.bean.BaseParam.DB_PWD = ConfigReader.read("db.pwd");
/*    */ 
/* 24 */     Cache.initPARAData();
/* 25 */     String ip = (String)Cache.configMap.get("ftp_reprint_ip");
/* 26 */     int port = Integer.parseInt((String)Cache.configMap.get("ftp_reprint_port"));
/* 27 */     String username = (String)Cache.configMap.get("ftp_reprint_username");
/* 28 */     String password = (String)Cache.configMap.get("ftp_reprint_userpass");
/* 29 */     String toPath = (String)Cache.configMap.get("ftp_reprint_to_path");
/* 30 */     String reprintDeductMoneyFilePath = (String)Cache.configMap.get("FTP_PATH") + "FTP/LETTER/SMS/";
/*    */ 
/* 32 */     LogInit.init((String)Cache.configMap.get("LOG4J_COFIG_PATH"), 
/* 33 */       (String)Cache.configMap
/* 33 */       .get("FTP_PATH") + 
/* 34 */       "LOG/letter_upload_ftp.log");
/* 35 */     log = Logger.getLogger(UploadLetter.class);
/* 36 */     Cache.colse();
/*    */ 
/* 38 */     log.debug("ip:" + ip + ", port:" + port + ", username:" + username + ", password:" + password + ", 上传ftp上传路径" + toPath + ",文件：" + filePath);
/* 39 */     FtpUtil ftpUtil = new FtpUtil(ip, port, username, password);
/*    */ 
/* 41 */     ftpUtil.connection();
/* 42 */     if (filePath != null) {
/* 43 */       if (ftpUtil.upload(filePath, null, toPath)) {
/* 44 */         log.info("文件：" + filePath + "上传成功！");
/*    */ 
/* 46 */         if (new File(filePath).delete())
/* 47 */           log.info("文件：" + filePath + "删除成功！");
/*    */         else
/* 49 */           log.info("文件：" + filePath + "删除成功！");
/*    */       }
/*    */       else {
/* 52 */         log.info("文件：" + filePath + "上传失败！");
/*    */       }
/*    */     } else {
/* 55 */       log.info("文件路径未传入！默认的：" + reprintDeductMoneyFilePath);
/* 56 */       File frdm = new File(reprintDeductMoneyFilePath);
/* 57 */       for (String rdm : frdm.list()) {
/* 58 */         if (rdm.indexOf("_CK.txt") == -1) {
/* 59 */           if (ftpUtil.upload(reprintDeductMoneyFilePath + rdm, null, toPath)) {
/* 60 */             log.info("文件：" + reprintDeductMoneyFilePath + rdm + "上传成功！");
/* 61 */             log.info("上传CK文件：");
/* 62 */             String ckfile = reprintDeductMoneyFilePath + rdm.substring(0, rdm.length() - 4) + "_CK.txt";
/* 63 */             File file = new File(ckfile);
/* 64 */             if (ftpUtil.upload(ckfile, null, toPath)) {
/* 65 */               log.info("文件：" + ckfile + "上传CK文件成功！");
/* 66 */               if (file.delete())
/* 67 */                 log.info("文件：" + ckfile + "CK文件删除成功！");
/*    */               else
/* 69 */                 log.info("文件：" + ckfile + "CK文件删除失败！");
/*    */             }
/*    */             else {
/* 72 */               log.info("上传CK文件失败！");
/*    */             }
/* 74 */             if (new File(reprintDeductMoneyFilePath + rdm).delete())
/* 75 */               log.info("文件：" + reprintDeductMoneyFilePath + rdm + "删除成功！");
/*    */             else
/* 77 */               log.info("文件：" + reprintDeductMoneyFilePath + rdm + "删除失败！");
/*    */           }
/*    */           else {
/* 80 */             log.info("文件：" + reprintDeductMoneyFilePath + rdm + "上传失败！");
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 85 */     ftpUtil.closeConn();
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Throwable {
/* 89 */     if ((args != null) && (args.length > 0))
/* 90 */       uploadDeductMoneyFile(args[0]);
/*    */     else
/* 92 */       uploadDeductMoneyFile(null);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.ftp.UploadLetter
 * JD-Core Version:    0.6.2
 */