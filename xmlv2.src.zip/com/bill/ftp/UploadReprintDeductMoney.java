/*    */ package com.bill.ftp;
/*    */ 
/*    */ import com.bill.makeXML.cache.Cache;
/*    */ import com.bill.makeXML.util.LogInit;
/*    */ import com.bill.util.config.ConfigReader;
/*    */ import java.io.File;
/*    */ import java.util.Map;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class UploadReprintDeductMoney
/*    */ {
/*    */   private static Logger log;
/*    */ 
/*    */   public static void uploadDeductMoneyFile(String filePath)
/*    */     throws Throwable
/*    */   {
/* 18 */     ConfigReader.init();
/* 19 */     com.bill.bean.BaseParam.DB_IP = ConfigReader.read("db.ip");
/* 20 */     com.bill.bean.BaseParam.DB_PORT = ConfigReader.read("db.port");
/* 21 */     com.bill.bean.BaseParam.DB_NAME = ConfigReader.read("db.name");
/* 22 */     com.bill.bean.BaseParam.DB_USER = ConfigReader.read("db.user");
/* 23 */     com.bill.bean.BaseParam.DB_PWD = ConfigReader.read("db.pwd");
/*    */ 
/* 25 */     Cache.initPARAData();
/* 26 */     String ip = (String)Cache.configMap.get("ftp_reprint_ip");
/* 27 */     int port = Integer.parseInt((String)Cache.configMap.get("ftp_reprint_port"));
/* 28 */     String username = (String)Cache.configMap.get("ftp_reprint_username");
/* 29 */     String password = (String)Cache.configMap.get("ftp_reprint_userpass");
/* 30 */     String toPath = (String)Cache.configMap.get("ftp_reprint_to_path");
/* 31 */     String reprintDeductMoneyFilePath = (String)Cache.configMap.get("FTP_PATH") + 
/* 32 */       "FTP/V+/";
/*    */ 
/* 34 */     LogInit.init((String)Cache.configMap.get("LOG4J_COFIG_PATH"), (String)Cache.configMap.get("FTP_PATH") + "LOG/Reprint_Upload_FTP_V+.log");
/* 35 */     log = Logger.getLogger(UploadReprintDeductMoney.class);
/* 36 */     Cache.colse();
/*    */ 
/* 38 */     log.debug("ip:" + ip + ", port:" + port + ", username:" + username + 
/* 39 */       ", password:" + password + ", 上传ftp上传路径" + toPath + ",文件：" + 
/* 40 */       filePath);
/* 41 */     FtpUtil ftpUtil = new FtpUtil(ip, port, username, password);
/*    */ 
/* 43 */     ftpUtil.connection();
/* 44 */     if (filePath != null) {
/* 45 */       if (ftpUtil.upload(filePath, null, toPath)) {
/* 46 */         log.info("文件：" + filePath + "上传成功！");
/* 47 */         if (new File(filePath).delete())
/* 48 */           log.info("文件：" + filePath + "删除成功！");
/*    */         else
/* 50 */           log.info("文件：" + filePath + "删除成功！");
/*    */       }
/*    */       else {
/* 53 */         log.info("文件：" + filePath + "上传失败！");
/*    */       }
/*    */     } else {
/* 56 */       log.info("文件路径未传入！默认的：" + reprintDeductMoneyFilePath);
/* 57 */       File frdm = new File(reprintDeductMoneyFilePath);
/* 58 */       for (String rdm : frdm.list()) {
/* 59 */         if (rdm.indexOf("_CK.txt") == -1) {
/* 60 */           if (ftpUtil.upload(reprintDeductMoneyFilePath + rdm, null, toPath)) {
/* 61 */             log.info("文件：" + reprintDeductMoneyFilePath + rdm + "上传成功！");
/* 62 */             log.info("上传CK文件：");
/* 63 */             String ckfile = reprintDeductMoneyFilePath + rdm.substring(0, rdm.length() - 4) + "_CK.txt";
/* 64 */             File file = new File(ckfile);
/* 65 */             if (ftpUtil.upload(ckfile, null, toPath)) {
/* 66 */               log.info("文件：" + ckfile + "上传CK文件成功！");
/* 67 */               if (file.delete())
/* 68 */                 log.info("文件：" + ckfile + "CK文件删除成功！");
/*    */               else
/* 70 */                 log.info("文件：" + ckfile + "CK文件删除失败！");
/*    */             }
/*    */             else {
/* 73 */               log.info("上传CK文件失败！");
/*    */             }
/* 75 */             if (new File(reprintDeductMoneyFilePath + rdm).delete())
/* 76 */               log.info("文件：" + reprintDeductMoneyFilePath + rdm + "删除成功！");
/*    */             else
/* 78 */               log.info("文件：" + reprintDeductMoneyFilePath + rdm + "删除失败！");
/*    */           }
/*    */           else {
/* 81 */             log.info("文件：" + reprintDeductMoneyFilePath + rdm + "上传失败！");
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 86 */     ftpUtil.closeConn();
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Throwable {
/* 90 */     if ((args != null) && (args.length > 0))
/* 91 */       uploadDeductMoneyFile(args[0]);
/*    */     else
/* 93 */       uploadDeductMoneyFile(null);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.ftp.UploadReprintDeductMoney
 * JD-Core Version:    0.6.2
 */