/*     */ package com.bill.ftp;
/*     */ 
/*     */ import com.bill.makeXML.cache.Cache;
/*     */ import com.bill.makeXML.util.LogInit;
/*     */ import com.bill.util.config.ConfigReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.time.DateFormatUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class GetWData
/*     */ {
/*     */   private static Logger log;
/*     */ 
/*     */   public static void getWData(String date)
/*     */     throws Throwable
/*     */   {
/*  27 */     ConfigReader.init();
/*  28 */     com.bill.bean.BaseParam.DB_IP = ConfigReader.read("db.ip");
/*  29 */     com.bill.bean.BaseParam.DB_PORT = ConfigReader.read("db.port");
/*  30 */     com.bill.bean.BaseParam.DB_NAME = ConfigReader.read("db.name");
/*  31 */     com.bill.bean.BaseParam.DB_USER = ConfigReader.read("db.user");
/*  32 */     com.bill.bean.BaseParam.DB_PWD = ConfigReader.read("db.pwd");
/*     */ 
/*  34 */     Cache.initPARAData();
/*  35 */     String ip = ((String)Cache.configMap.get("ftp_vdata_ip")).trim();
/*  36 */     int port = Integer.parseInt(((String)Cache.configMap.get("ftp_vdata_port")).trim());
/*  37 */     String username = ((String)Cache.configMap.get("ftp_vdata_username")).trim();
/*  38 */     String password = ((String)Cache.configMap.get("ftp_vdata_userpass")).trim();
/*  39 */     String fromPath = ((String)Cache.configMap.get("ftp_vdata_fromPath")).trim();
/*  40 */     String toPath = ((String)Cache.configMap.get("ftp_vdata_toPath")).trim();
/*  41 */     String waitTime = ((String)Cache.configMap.get("ftp_vdata_waitTime")).trim();
/*  42 */     String scanPrefix = ((String)Cache.configMap.get("ftp_vdata_scanPrefix")).trim();
/*  43 */     String scanPostfix = ((String)Cache.configMap.get("ftp_vdata_scanPostfix")).trim();
/*     */ 
/*  46 */     LogInit.init((String)Cache.configMap.get("LOG4J_COFIG_PATH"), (String)Cache.configMap.get("FTP_PATH") + "LOG/WData_download_FTP.log");
/*  47 */     log = Logger.getLogger(GetWData.class);
/*  48 */     Cache.colse();
/*     */ 
/*  50 */     log.debug("ip:" + ip + ", port:" + port + ", username:" + username + ", password:" + password + 
/*  51 */       ", fromPath" + fromPath + ", toPath:" + toPath + ", waitTime:" + waitTime + 
/*  52 */       ", scanPrefix:" + scanPrefix + ", scanPostfix:" + scanPostfix);
/*  53 */     FtpUtil ftpUtil = null;
/*     */ 
/*  55 */     int successCount = 0;
/*     */     while (true)
/*     */     {
/*     */       try
/*     */       {
/*  60 */         ftpUtil = new FtpUtil(ip, port, username, password);
/*  61 */         ftpUtil.connection();
/*  62 */         ArrayList fileNameList = null;
/*  63 */         String[] scanPrefixArr = scanPrefix.split(",");
/*  64 */         int i = 0; continue;
/*     */ 
/*  67 */         fileNameList = ftpUtil.getFileList(
/*  69 */           fromPath, 
/*  70 */           scanPrefixArr[i], 
/*  71 */           date + "_CK.txt");
/*     */ 
/*  74 */         if (fileNameList.size() == 0) {
/*  75 */           log.info(scanPrefixArr[i] + "   file size is 0.");
/*     */         } else {
/*  77 */           String _fileName = "";
/*  78 */           int j = 0; continue;
/*  79 */           _fileName = ((String)fileNameList.get(j)).replaceAll("_0799", "").replaceAll("_CK.txt", scanPostfix);
/*  80 */           if (ftpUtil.downloadFile(toPath, _fileName, fromPath)) {
/*  81 */             successCount++;
/*  82 */             log.info("index" + j + ", fileName:" + _fileName);
/*     */           }
/*  78 */           j++; if (j < fileNameList.size())
/*     */             continue;
/*     */         }
/*  64 */         i++; if (i < scanPrefixArr.length)
/*     */         {
/*     */           continue;
/*     */         }
/*     */ 
/*  88 */         if (successCount >= 1) {
/*  89 */           log.info("files count is >= 1. normal exit.");
/*     */ 
/* 112 */           if (ftpUtil == null) break;
/* 113 */           ftpUtil.closeConn();
/*     */ 
/*  90 */           break;
/*     */         }
/*     */         String[] scanPrefixArr;
/*     */         ArrayList fileNameList;
/*  93 */         successCount = 0;
/*  94 */         ftpUtil.closeConn();
/*  95 */         log.debug("close ftp connection. wait next time scan files. minute: " + waitTime);
/*  96 */         Thread.sleep(Long.parseLong(waitTime) * 1000L * 60L);
/*     */       } catch (Throwable t) {
/*  98 */         successCount = 0;
/*  99 */         log.error(t);
/*     */         try {
/* 101 */           log.debug("wait next time scan files. minute: " + waitTime);
/* 102 */           Thread.sleep(Long.parseLong(waitTime) * 1000L * 60L);
/*     */         } catch (NumberFormatException e) {
/* 104 */           log.error("exception sleep NumberFormatException.", e);
/*     */         } catch (InterruptedException e) {
/* 106 */           log.error("exception sleep InterruptedException.", e);
/*     */         }
/* 108 */         if (ftpUtil != null) {
/* 109 */           ftpUtil.closeConn();
/*     */         }
/*     */ 
/* 112 */         if (ftpUtil == null) continue;
/* 113 */         ftpUtil.closeConn(); continue;
/*     */       }
/*     */       finally
/*     */       {
/* 112 */         if (ftpUtil != null)
/* 113 */           ftpUtil.closeConn();
/*     */       }
/* 112 */       if (ftpUtil != null)
/* 113 */         ftpUtil.closeConn();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String now()
/*     */   {
/* 121 */     Calendar cal = Calendar.getInstance();
/* 122 */     cal.add(5, -1);
/* 123 */     return DateFormatUtils.format(cal.getTime(), "yyyyMMdd");
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Throwable
/*     */   {
/* 128 */     if ((args != null) && (args.length > 0))
/* 129 */       getWData(args[0]);
/*     */     else
/* 131 */       getWData(null);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.ftp.GetWData
 * JD-Core Version:    0.6.2
 */