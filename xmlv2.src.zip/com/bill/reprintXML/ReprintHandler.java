/*     */ package com.bill.reprintXML;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.bean.Plog;
/*     */ import com.bill.bean.PrintInfo;
/*     */ import com.bill.bean.UserBase;
/*     */ import com.bill.util.FileUtil;
/*     */ import java.io.PrintStream;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class ReprintHandler
/*     */ {
/*     */   private Map<String, String> glmap;
/*     */   private StringBuffer xmlbase;
/*     */   private StringBuffer xmlp;
/*     */   private StringBuffer xmle;
/*     */   private EXml ex;
/*     */   private PXml px;
/*     */   private String bid;
/*     */   private String period;
/*  26 */   private int count = 1;
/*     */   private Plog elog;
/*     */   private String xmlpath;
/*     */   private UserXml ux;
/*  34 */   private static Logger log = Logger.getLogger(ReprintHandler.class);
/*     */ 
/*     */   public ReprintHandler() {
/*  37 */     this.ux = new UserXml();
/*  38 */     this.ex = new EXml();
/*  39 */     this.px = new PXml();
/*     */   }
/*     */ 
/*     */   public void handler()
/*     */   {
/*  44 */     log.debug("delete: " + BaseParam.XML_PATH + "/001/REPRINT/XML/");
/*  45 */     System.out.println(BaseParam.XML_PATH + "/001/REPRINT/XML/");
/*  46 */     FileUtil.delFolderFile(BaseParam.XML_PATH + "/001/REPRINT/XML/");
/*     */ 
/*  48 */     this.period = new SimpleDateFormat("yyyyMMdd").format(new Date());
/*     */ 
/*  50 */     log.debug("clear folder end!");
/*     */ 
/*  53 */     List list = Cache.getRePrintInfo("01");
/*  54 */     log.debug("待补制的纸制账单数=" + list.size());
/*     */ 
/*  57 */     for (int i = 0; i < list.size(); i++) {
/*  58 */       PrintInfo pi = (PrintInfo)list.get(i);
/*     */ 
/*  60 */       UserBase ub = Cache.getUserBase(pi);
/*  61 */       if (ub == null) {
/*  62 */         log.error("没有找到相应的用户数据！账号=" + pi.getAccount() + ",账期=" + 
/*  63 */           pi.getPeriod() + ",产品=" + pi.getCard_no());
/*  64 */         pi.setFlg("2");
/*  65 */         Cache.setRePrintFlg(pi);
/*     */       }
/*     */       else
/*     */       {
/*  69 */         if ("Y".equals(pi.getIsUpAddr()))
/*     */         {
/*  71 */           ub.setAddrname1(pi.getAddrname1());
/*  72 */           ub.setAddrname2(pi.getAddrname2());
/*  73 */           ub.setAddrname3(pi.getAddrname3());
/*     */ 
/*  75 */           ub.setZip(pi.getAddpost());
/*     */         }
/*     */ 
/*  78 */         ub.setCity(pi.getCityid());
/*     */ 
/*  80 */         ub.setPaperflag("Y");
/*     */ 
/*  82 */         this.glmap = Cache.getGL(ub.getCardNo(), ub.getCity());
/*  83 */         if ((this.glmap == null) || (this.glmap.get("wbs") == null) || 
/*  84 */           (this.glmap.get("yyz") == null) || 
/*  85 */           (this.glmap.get("cardtype") == null)) {
/*  86 */           log.error("没有设置对应的外包商、预印纸，卡类型！城市=" + ub.getCity() + ",产品=" + 
/*  87 */             ub.getCardNo());
/*     */ 
/*  89 */           pi.setFlg("2");
/*  90 */           Cache.setRePrintFlg(pi);
/*     */         }
/*     */         else
/*     */         {
/*  94 */           this.xmlbase = new StringBuffer();
/*  95 */           this.xmlbase.append("<checksheet>\n");
/*     */ 
/*  97 */           this.ux.writeBaseXml(ub, this.xmlbase);
/*     */ 
/*  99 */           this.ux.writeEnvrule((String)this.glmap.get("wbs"), ub, this.xmlbase);
/*     */ 
/* 101 */           if (this.ux.writeAccinfoXml(ub, this.xmlbase)) {
/* 102 */             log.error("没有汇总信息!账号=" + ub.getAcctnbr());
/*     */ 
/* 104 */             pi.setFlg("2");
/* 105 */             Cache.setRePrintFlg(pi);
/*     */           }
/*     */           else
/*     */           {
/* 109 */             this.ux.writeAccinfoDetail(ub, this.xmlbase);
/* 110 */             this.xmlbase.append("<mccs>\n</mccs>\n<historytrend>\n</historytrend>\n");
/*     */ 
/* 112 */             this.ux.writeBuy(ub, this.xmlbase);
/*     */ 
/* 114 */             this.ux.writeDebitinfo(ub, this.xmlbase);
/*     */ 
/* 116 */             this.ux.getStageplan(ub, this.xmlbase);
/*     */ 
/* 118 */             this.ux.writePoint(ub, this.xmlbase);
/*     */ 
/* 120 */             this.xmlp = new StringBuffer(this.xmlbase);
/* 121 */             this.xmlp.append(this.ux.writeTemplate(ub, "1").toString());
/* 122 */             this.xmlp.append("<html5resources>\n<lists>\n</lists>\n</html5resources>\n");
/* 123 */             this.xmlp.append("</checksheet>\n");
/*     */ 
/* 125 */             this.px.write(this.xmlp.toString(), this.glmap, this.period, pi.getId());
/*     */ 
/* 127 */             pi.setFlg("1");
/* 128 */             Cache.setRePrintFlg(pi);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 131 */     pageColse();
/*     */ 
/* 133 */     list = Cache.getRePrintInfo("02");
/* 134 */     log.debug("待补制的电子账单数=" + list.size());
/* 135 */     for (int i = 0; i < list.size(); i++) {
/* 136 */       PrintInfo pi = (PrintInfo)list.get(i);
/* 137 */       UserBase ub = Cache.getUserBase(pi);
/* 138 */       if (ub == null) {
/* 139 */         log.error("没有账号数据，账号=" + pi.getAccount());
/*     */       }
/*     */       else
/*     */       {
/* 143 */         if ("Y".equals(pi.getIsUpAddr())) {
/* 144 */           ub.setEmailaddr(pi.getEmail());
/*     */         }
/*     */ 
/* 147 */         if ((pi.getAccount().equals(this.bid)) && (pi.getPeriod().equals(this.period))) {
/* 148 */           this.count += 1;
/*     */         } else {
/* 150 */           this.bid = pi.getAccount();
/* 151 */           this.period = pi.getPeriod();
/* 152 */           this.count = 1;
/*     */         }
/*     */ 
/* 155 */         this.xmlpath = this.ex.create(pi.getPeriod(), ub.getCardNo(), "001", this.count, 
/* 156 */           pi.getId());
/*     */ 
/* 158 */         this.elog = new Plog();
/* 159 */         this.elog.setStmtdate(pi.getPeriod());
/* 160 */         this.elog.setFilename(this.xmlpath);
/* 161 */         this.elog.setBusinpnt_no("");
/* 162 */         this.elog.setCard_id(ub.getCardNo());
/* 163 */         this.elog.setPaper_no("");
/* 164 */         Cache.savePLogBegin(this.elog);
/*     */ 
/* 166 */         this.xmlbase = new StringBuffer();
/* 167 */         this.xmlbase.append("<checksheet>\n");
/*     */ 
/* 169 */         this.ux.writeBaseXml(ub, this.xmlbase);
/*     */ 
/* 171 */         this.xmlbase.append("<ENVRULE>0000</ENVRULE>\n");
/* 172 */         this.xmlbase.append("<INPRIORITY1>0</INPRIORITY1>\n<INPRIORITY2>0</INPRIORITY2>\n<INPRIORITY3>0</INPRIORITY3>\n<INPRIORITY4>0</INPRIORITY4>\n");
/*     */ 
/* 174 */         this.xmlbase.append(this.ux.getClickInfo(ub));
/*     */ 
/* 177 */         if (this.ux.writeAccinfoXml(ub, this.xmlbase)) {
/* 178 */           log.error("没有汇总信息!账号=" + ub.getAcctnbr());
/*     */ 
/* 180 */           pi.setFlg("2");
/* 181 */           Cache.setRePrintFlg(pi);
/*     */         }
/*     */         else
/*     */         {
/* 185 */           this.ux.writeAccinfoDetail(ub, this.xmlbase);
/* 186 */           this.xmlbase.append("<mccs>\n</mccs>\n<historytrend>\n</historytrend>\n");
/*     */ 
/* 188 */           this.ux.writeBuy(ub, this.xmlbase);
/*     */ 
/* 190 */           this.ux.writeDebitinfo(ub, this.xmlbase);
/*     */ 
/* 192 */           this.ux.getStageplan(ub, this.xmlbase);
/*     */ 
/* 194 */           this.ux.writePoint(ub, this.xmlbase);
/*     */ 
/* 198 */           this.xmle = new StringBuffer(this.xmlbase);
/* 199 */           this.xmle.append(this.ux.writeTemplate(ub, "2").toString());
/* 200 */           this.xmle.append("<html5resources>\n<lists>\n</lists>\n</html5resources>\n");
/* 201 */           this.xmle.append("</checksheet>\n");
/* 202 */           this.ex.write(this.xmle.toString());
/* 203 */           this.ex.close(1);
/* 204 */           this.elog.setShare(1);
/* 205 */           this.elog.setState("1");
/* 206 */           Cache.savePLogEnd(this.elog);
/* 207 */           pi.setFlg("1");
/* 208 */           Cache.setRePrintFlg(pi);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/* 214 */   public void pageColse() { this.px.close(); }
/*     */ 
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.reprintXML.ReprintHandler
 * JD-Core Version:    0.6.2
 */