/*      */ package com.bill.reprintXML;
/*      */ 
/*      */ import com.bill.bean.BaseParam;
/*      */ import com.bill.bean.Busin;
/*      */ import com.bill.bean.Card;
/*      */ import com.bill.bean.Debitinfo;
/*      */ import com.bill.bean.Fodder;
/*      */ import com.bill.bean.Foldout;
/*      */ import com.bill.bean.Plog;
/*      */ import com.bill.bean.PointInfo;
/*      */ import com.bill.bean.PrintInfo;
/*      */ import com.bill.bean.Rule;
/*      */ import com.bill.bean.RuleF;
/*      */ import com.bill.bean.RuleM;
/*      */ import com.bill.bean.Stageplan;
/*      */ import com.bill.bean.TempArea;
/*      */ import com.bill.bean.Template;
/*      */ import com.bill.bean.UserAccinfo;
/*      */ import com.bill.bean.UserAccinfoDetail;
/*      */ import com.bill.bean.UserBase;
/*      */ import com.bill.bean.UserBuy;
/*      */ import com.bill.bean.Yyz;
/*      */ import com.bill.bean.mcc;
/*      */ import com.bill.db.DbConnectionForOracle;
/*      */ import java.io.PrintStream;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.apache.commons.lang.time.DateFormatUtils;
/*      */ 
/*      */ public class DBDao
/*      */ {
/*      */   public DbConnectionForOracle dbconn;
/*      */   private PreparedStatement statement;
/*      */   private ResultSet result;
/*   20 */   private static String CARD_SQL = "select t.s_buss_prod_id,t.s_buss_prod_name,t.c_buss_type_id from T_S_BUSI_PROD_INFO t where t.c_buss_prod_flag='0'";
/*      */ 
/*   25 */   private static String CPB_CITY_SQL = "select t.s_city_no from t_s_bfpnt_cty_crdtp t where t.s_city_no is not null and t.s_card_no =? and t.s_id=? and t.s_businpnt_no=?";
/*      */ 
/*   30 */   private static String TEMPLATE_SQL = "select t.s_stencil_no,t.s_card_prod_id,t.c_type_no from T_S_STENCIL t where t.c_state='1'";
/*      */ 
/*   35 */   private static String RULE_SQL = "select * from t_s_rule_m t where t.s_stencil_no=? and t.c_rule_type=? and t.i_area_no=? and t.c_state='1' and to_date(?,'yyyyMM')>=to_date(t.c_period_begen,'yyyy-MM') and to_date(?,'yyyyMM')<=to_date(t.c_period_end,'yyyy-MM') and t.s_period like '%'||?||'%' order by t.i_pri desc";
/*      */ 
/*  354 */   private static String UserInfo_SQL = "select acctnbr,      rectype,      stmtdate,      pmtdate,      to_char(totbegbal, 'fm9999999999999999990.00') as totbegbal,      to_char(plantotpmt, 'fm9999999999999999990.00') as plantotpmt,      to_char(plantotnrlamt, 'fm9999999999999999990.00') as plantotnrlamt,      to_char(plantotadjamt, 'fm9999999999999999990.00') as plantotadjamt,      to_char(intdueamt, 'fm9999999999999999990.00') as intdueamt,      to_char(currbal, 'fm9999999999999999990.00') as currbal,      to_char(totdueamt, 'fm9999999999999999990.00') as totdueamt,      pmtprint,      to_char(crlim, 'fm9999999999999999990.00') as crlim,      to_char(cashcrlim, 'fm9999999999999999990.00') as cashcrlim,      pmtarn,      pmtadn,      to_char(projap, 'fm9999999999999999990.00') as projap,      pmtaflag,      achflag,      pmtflag,      filler from view_h_customer_bill t where t.acctnbr = ?  and t.stmtdate = ?";
/*      */ 
/*  424 */   private static String AccinfoDetail_SQL = "select acctnbr,       rectype,       recseq,       effdate,       postdate,       cardnlast4,       curdesc,       to_char(txnamt,'fm9999999999999999990.00') as txnamt,       to_char(srctamt,'fm9999999999999999990.00') as srctamt,       srctcurr,       purcty,       filler,       catcode,cardnbr,accid,txncode,mainacc,cnname,pyname,cardname  from view_h_customer_bill_detail t  where t.acctnbr=?    and t.stmtdate=? order by t.rectype,t.cardnbr,t.postdate, t.recseq";
/*      */ 
/*  488 */   private static String UserBuy_SQL = "select S_ACCOUNT,       S_CUR_PUR_REC_TYPE,       to_char(I_CUR_PUR_EXCH_USD_AMT,'fm999999999999999999990.00') as I_CUR_PUR_EXCH_USD_AMT,       to_char(I_CUR_PUR_SELL_RATE,'fm99999999999999990.00') as I_CUR_PUR_SELL_RATE,       to_char(I_CUR_PUR_EXCH_RMB_AMT,'fm999999999999999999990.00') as I_CUR_PUR_EXCH_RMB_AMT,       S_CUR_PUR_PMT_ACH_RT_NBR,       S_CUR_PUR_PMT_ACH_DB_NBR,       S_CUR_PUR_FILLER  from T_H_CUSTOMER_PURCHASE t  where t.S_ACCOUNT=?    and t.C_STMT_DATE=?";
/*      */ 
/*  527 */   private static String Debitinfo_SQL = "select acctnbr,       rectype,       custnbr,       effdate,       txndesc,       txncity,       currcode,       NVL(to_char(txnamt,'fm9999999999999999999990.00'),' ') as txnamt,       cardl4,       filler  from view_H_crad_trade_detail t  where t.acctnbr=?    and t.stmtdate=?  order by rectype, effdate, cardl4";
/*      */ 
/*  577 */   private static String Point_SQL = "select S_POINT_TYPE,S_ACCT_PROD_ID,S_BUSINESS_ID,I_ABLE_POINT,I_LASTBAL_POINT,I_ADDPOINT_POINT,I_EXPOINT_POINT,I_ADPOINTS_POINT,I_ENDPOINTS_POINT,S_ECIF_NO,S_START_DATE,S_END_DATE,to_char(I_WHOLE_CONSUME,'fm99999990.00') as I_WHOLE_CONSUME,to_char(I_IN_CONSUME,'fm99999990.00') as I_IN_CONSUME,to_char(I_OUT_CONSUME,'fm99999990.00') as I_OUT_CONSUME,to_char(I_WHOLE_MONEY,'fm99999990.00') as I_WHOLE_MONEY,to_char(I_IN_MONEY,'fm99999990.00') as I_IN_MONEY,to_char(I_OUT_MONEY,'fm99999990.00') as I_OUT_MONEY,to_char(I_USED_MONEY,'fm99999990.00') as I_USED_MONEY,to_char(I_LAVE_MONEY,'fm99999990.00') as I_LAVE_MONEY,S_VALID_DATE,I_LADDER_MONEY,S_LADDER_SCALE,C_CARD_LAST4,C_CARD_POINT_TYPE,S_CARD_POINT_NAME from t_H_point_x where S_BUSINESS_ID=? and C_STMT_DATE=?";
/*      */   private Connection conn;
/* 1183 */   private String sql = "update t_b_reprint t set t.s_express_num =? where (t.s_period,t.s_business_id)=(select replace(t1.s_fperiod,'-',''), t1.s_account from T_B_BILL_P_LIST_HIS t1 where t1.s_bar =?) and t.s_repair_type='01' and t.c_buildflg='1' and t.s_apply_date between ? and ?";
/*      */ 
/*      */   public DBDao()
/*      */   {
/*   42 */     this.dbconn = new DbConnectionForOracle(BaseParam.DB_IP, BaseParam.DB_PORT, BaseParam.DB_NAME, BaseParam.DB_USER, BaseParam.DB_PWD);
/*      */   }
/*      */ 
/*      */   public void close()
/*      */   {
/*   48 */     this.dbconn.close();
/*      */   }
/*      */ 
/*      */   public List<Busin> getBusin()
/*      */   {
/*   55 */     List list = new ArrayList();
/*      */     try {
/*   57 */       this.statement = this.dbconn.getConnection().prepareStatement("select t1.s_businpnt_no,t1.s_businpnt_name from T_S_EPLBOLY_PNT t1");
/*   58 */       this.result = this.statement.executeQuery();
/*      */ 
/*   60 */       while (this.result.next()) {
/*   61 */         Busin e = new Busin();
/*   62 */         e.setId(this.result.getString("s_businpnt_no"));
/*   63 */         e.setName(this.result.getString("s_businpnt_name"));
/*   64 */         list.add(e);
/*      */       }
/*   66 */       this.result.close();
/*   67 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*   69 */       e.printStackTrace();
/*      */     }
/*   71 */     return list;
/*      */   }
/*      */ 
/*      */   public List<Card> getCard()
/*      */   {
/*   78 */     List list = new ArrayList();
/*      */     try {
/*   80 */       this.statement = this.dbconn.getConnection().prepareStatement(CARD_SQL);
/*   81 */       this.result = this.statement.executeQuery();
/*      */ 
/*   83 */       while (this.result.next()) {
/*   84 */         Card e = new Card();
/*   85 */         e.setId(this.result.getString("s_buss_prod_id"));
/*   86 */         e.setName(this.result.getString("s_buss_prod_name"));
/*   87 */         e.setType(this.result.getString("c_buss_type_id"));
/*   88 */         list.add(e);
/*      */       }
/*   90 */       this.result.close();
/*   91 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*   93 */       e.printStackTrace();
/*      */     }
/*   95 */     return list;
/*      */   }
/*      */ 
/*      */   public Map<String, List<Yyz>> getCardBfpntMap()
/*      */   {
/*  103 */     Map map = new HashMap();
/*      */     try {
/*  105 */       this.statement = this.dbconn.getConnection().prepareStatement("select t.s_card_no,t.s_id,t2.S_PAPER_NO from t_s_bfpnt_cty_crdtp t,T_S_BEFOR_PRINT_BASIC t2 where t.s_id<>'0' and t.s_id=t2.s_id group by t.s_card_no,t.s_id,t2.S_PAPER_NO");
/*  106 */       this.result = this.statement.executeQuery();
/*      */ 
/*  108 */       String id1 = "";
/*      */ 
/*  110 */       while (this.result.next()) {
/*  111 */         Yyz y = new Yyz();
/*  112 */         id1 = this.result.getString("s_card_no");
/*  113 */         y.setId(this.result.getString("s_id"));
/*  114 */         y.setPaperNo(this.result.getString("S_PAPER_NO"));
/*  115 */         if (map.containsKey(id1)) {
/*  116 */           ((List)map.get(id1)).add(y);
/*      */         } else {
/*  118 */           List list = new ArrayList();
/*  119 */           list.add(y);
/*  120 */           map.put(id1, list);
/*      */         }
/*      */       }
/*  123 */       this.result.close();
/*  124 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  126 */       e.printStackTrace();
/*  127 */       return null;
/*      */     }
/*  129 */     return map;
/*      */   }
/*      */ 
/*      */   public List<String> getCityByCPB(String cid, String pid, String bid)
/*      */   {
/*  139 */     List list = new ArrayList();
/*      */     try {
/*  141 */       this.statement = this.dbconn.getConnection().prepareStatement(CPB_CITY_SQL);
/*  142 */       this.statement.setString(1, cid);
/*  143 */       this.statement.setString(2, pid);
/*  144 */       this.statement.setString(3, bid);
/*  145 */       this.result = this.statement.executeQuery();
/*  146 */       while (this.result.next()) {
/*  147 */         list.add(this.result.getString("S_CITY_NO"));
/*      */       }
/*  149 */       this.result.close();
/*  150 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  152 */       e.printStackTrace();
/*      */     }
/*  154 */     return list;
/*      */   }
/*      */ 
/*      */   public List<mcc> getMCCInfo()
/*      */   {
/*  162 */     List list = new ArrayList();
/*      */     try {
/*  164 */       this.statement = this.dbconn
/*  165 */         .getConnection()
/*  166 */         .prepareStatement("select * from T_S_MCC_INFO t order by S_TYPE,s_id");
/*  167 */       this.result = this.statement.executeQuery();
/*  168 */       mcc m = null;
/*  169 */       while (this.result.next()) {
/*  170 */         m = new mcc();
/*  171 */         m.setType(this.result.getString("S_TYPE"));
/*  172 */         m.setTypeName(this.result.getString("S_TYPE_NAME"));
/*  173 */         m.setId(this.result.getString("S_ID"));
/*  174 */         m.setName(this.result.getString("S_NAME"));
/*  175 */         list.add(m);
/*      */       }
/*  177 */       this.result.close();
/*  178 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  180 */       e.printStackTrace();
/*      */     }
/*  182 */     return list;
/*      */   }
/*      */ 
/*      */   public List<Stageplan> getStageplan(UserBase user)
/*      */   {
/*  191 */     List list = new ArrayList();
/*  192 */     Stageplan sta = null;
/*  193 */     StringBuffer sb = new StringBuffer();
/*  194 */     sb.append("select ")
/*  195 */       .append("s_stagetype")
/*  196 */       .append(",i_totalstage as totalstage")
/*  197 */       .append(",i_accstage as accstage")
/*  198 */       .append(",NVL(to_char(i_totalamt,'fm9999999999999999999990.00'),' ') as totalamt")
/*  199 */       .append(",NVL(to_char(i_unaccamt,'fm9999999999999999999990.00'),' ') as unaccamt")
/*  200 */       .append(",NVL(to_char(i_stagefee,'fm9999999999999999999990.00'),' ') as stagefee")
/*  201 */       .append(",NVL(to_char(i_unaccfee,'fm9999999999999999999990.00'),' ') as unaccfee")
/*  202 */       .append(" from T_H_CUSTOMER_STAGEPLAN where s_account=? and C_STMT_DATE=? ORDER BY S_STAGETYPE, I_TOTALSTAGE, I_ACCSTAGE");
/*      */     try {
/*  204 */       this.statement = this.dbconn
/*  205 */         .getConnection()
/*  206 */         .prepareStatement(sb.toString());
/*  207 */       this.statement.setString(1, user.getAcctnbr());
/*  208 */       this.statement.setString(2, user.getStmtdate());
/*  209 */       this.result = this.statement.executeQuery();
/*  210 */       while (this.result.next()) {
/*  211 */         sta = new Stageplan();
/*  212 */         sta.setStagetype(this.result.getString("s_stagetype"));
/*  213 */         sta.setTotalstage(this.result.getInt("totalstage"));
/*  214 */         sta.setAccstage(this.result.getInt("accstage"));
/*  215 */         sta.setTotalamt(this.result.getString("totalamt"));
/*  216 */         sta.setUnaccamt(this.result.getString("unaccamt"));
/*  217 */         sta.setStagefee(this.result.getString("stagefee"));
/*  218 */         sta.setUnaccfee(this.result.getString("unaccfee"));
/*  219 */         list.add(sta);
/*      */       }
/*  221 */       this.result.close();
/*  222 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  224 */       e.printStackTrace();
/*  225 */       return null;
/*      */     }
/*  227 */     return list;
/*      */   }
/*      */   public Map<String, String> getMCCMap(String type) {
/*  230 */     Map map = new HashMap();
/*      */     try {
/*  232 */       this.statement = this.dbconn
/*  233 */         .getConnection()
/*  234 */         .prepareStatement("select * from T_S_MCC_INFO t order by S_TYPE,s_id");
/*  235 */       this.result = this.statement.executeQuery();
/*      */ 
/*  237 */       while (this.result.next()) {
/*  238 */         map.put(this.result.getString("S_ID"), type == "" ? "" : this.result.getString(type));
/*      */       }
/*  240 */       this.result.close();
/*  241 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  243 */       e.printStackTrace();
/*      */     }
/*  245 */     return map;
/*      */   }
/*      */ 
/*      */   public Map<String, String> queryStageType()
/*      */   {
/*  253 */     Map map = new HashMap();
/*      */     try {
/*  255 */       this.statement = this.dbconn.getConnection().prepareStatement("SELECT * FROM t_s_stageplan");
/*  256 */       this.result = this.statement.executeQuery();
/*  257 */       while (this.result.next())
/*  258 */         map.put(this.result.getString("s_stagetype"), this.result.getString("s_stagetype_name"));
/*      */     }
/*      */     catch (SQLException e) {
/*  261 */       e.printStackTrace();
/*      */       try
/*      */       {
/*  264 */         if (this.result != null) this.result.close();
/*  265 */         if (this.statement != null) this.statement.close(); 
/*      */       }
/*  267 */       catch (SQLException e) { e.printStackTrace(); }
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/*  264 */         if (this.result != null) this.result.close();
/*  265 */         if (this.statement != null) this.statement.close(); 
/*      */       }
/*  267 */       catch (SQLException e) { e.printStackTrace(); }
/*      */ 
/*      */     }
/*  270 */     return map;
/*      */   }
/*      */ 
/*      */   public UserBase getUserBase(PrintInfo pi)
/*      */   {
/*  278 */     UserBase ub = null;
/*      */     try {
/*  280 */       this.statement = this.dbconn.getConnection().prepareStatement("select * from t_h_customer_bill t where S_ACCOUNT=? and C_STMT_DATE=? and  S_CARD_PROD_ID=?");
/*  281 */       this.statement.setString(1, pi.getAccount());
/*  282 */       this.statement.setString(2, pi.getPeriod());
/*  283 */       this.statement.setString(3, pi.getCard_no());
/*  284 */       this.result = this.statement.executeQuery();
/*  285 */       while (this.result.next()) {
/*  286 */         ub = new UserBase();
/*  287 */         ub.setAcctnbr(this.result.getString("S_ACCOUNT"));
/*  288 */         ub.setRectype(this.result.getString("S_CUR_TYPE"));
/*  289 */         ub.setZip(this.result.getString("S_CUR_ZIP"));
/*  290 */         ub.setAddrname3(this.result.getString("S_CUR_ADDR3"));
/*  291 */         ub.setAddrname1(this.result.getString("S_CUR_ADDR1"));
/*  292 */         ub.setAddrname2(this.result.getString("S_CUR_ADDR2"));
/*  293 */         ub.setName(this.result.getString("S_CUR_NAME"));
/*  294 */         ub.setSex(this.result.getString("C_CUR_SEX"));
/*  295 */         ub.setBirthday(this.result.getString("S_CUR_BIRTHDAY"));
/*  296 */         ub.setAccnum(this.result.getString("S_CUR_ACCOUNT"));
/*  297 */         ub.setCusnum(this.result.getString("S_CUR_CUST_NBR"));
/*  298 */         ub.setStfromdate(this.result.getString("S_CUR_START_DATE"));
/*  299 */         ub.setEnddate(this.result.getString("S_CUR_END_DATE"));
/*  300 */         ub.setSpecode(this.result.getString("S_CUR_SPECIAL_CHAR"));
/*  301 */         ub.setPmtduemark(this.result.getString("S_CUR_PMT_CYCLE_DUE"));
/*  302 */         ub.setCashmark(this.result.getString("S_CUR_PRINT"));
/*  303 */         ub.setIndiv1(this.result.getString("C_CUR_MSG_1"));
/*  304 */         ub.setIndiv2(this.result.getString("C_CUR_MSG_2"));
/*  305 */         ub.setIndiv3(this.result.getString("C_CUR_MSG_3"));
/*  306 */         ub.setIndiv4(this.result.getString("C_CUR_MSG_4"));
/*  307 */         ub.setIndiv5(this.result.getString("C_CUR_MSG_5"));
/*  308 */         ub.setIndiv6(this.result.getString("C_CUR_MSG_6"));
/*  309 */         ub.setIndiv7(this.result.getString("C_CUR_MSG_7"));
/*  310 */         ub.setIndiv8(this.result.getString("C_CUR_MSG_8"));
/*  311 */         ub.setActinfo(this.result.getString("C_CUR_ACTIVITY_MSG"));
/*  312 */         ub.setDm1(this.result.getString("C_CUR_DM_MSG_1"));
/*  313 */         ub.setDm2(this.result.getString("C_CUR_DM_MSG_2"));
/*  314 */         ub.setDm3(this.result.getString("C_CUR_DM_MSG_3"));
/*  315 */         ub.setDm4(this.result.getString("C_CUR_DM_MSG_4"));
/*  316 */         ub.setBrandmsg1(this.result.getString("C_CUR_BRAND_MSG_1"));
/*  317 */         ub.setBrandmsg2(this.result.getString("C_CUR_BRAND_MSG_2"));
/*  318 */         ub.setBrandmsg3(this.result.getString("C_CUR_BRAND_MSG_3"));
/*  319 */         ub.setBrandmsg4(this.result.getString("C_CUR_BRAND_MSG_4"));
/*  320 */         ub.setBrandmsg5(this.result.getString("C_CUR_BRAND_MSG_5"));
/*  321 */         ub.setBrandmsg6(this.result.getString("C_CUR_BRAND_MSG_6"));
/*  322 */         ub.setBrandmsg7(this.result.getString("C_CUR_BRAND_MSG_7"));
/*  323 */         ub.setConvexchmark(this.result.getString("C_CUR_CONV_EXCH_FLAG"));
/*  324 */         ub.setVipmsg1(this.result.getString("C_CUR_VIP_MSG_1"));
/*  325 */         ub.setVipmsg2(this.result.getString("C_CUR_VIP_MSG_2"));
/*  326 */         ub.setVipmsg3(this.result.getString("C_CUR_VIP_MSG_3"));
/*  327 */         ub.setVipmsg4(this.result.getString("C_CUR_VIP_MSG_4"));
/*  328 */         ub.setReprintflag(this.result.getString("C_CUR_REPRINT_FLAG"));
/*  329 */         ub.setEmailflag(this.result.getString("C_CUR_EMAIL_STMT_FLAG"));
/*  330 */         ub.setPaperflag(this.result.getString("C_CUR_PAPER_STMT_FLAG"));
/*  331 */         ub.setEmailaddr(this.result.getString("S_CUR_EMAIL_ADDR"));
/*  332 */         ub.setCusttype(this.result.getString("S_CUR_CUSTOMER_TYPE"));
/*  333 */         ub.setMobilenbr(this.result.getString("S_CUR_MOBILE_NBR"));
/*  334 */         ub.setAinbr(this.result.getString("S_CUR_AI_NBR"));
/*  335 */         ub.setMobdate(this.result.getString("C_CUR_MOB"));
/*  336 */         ub.setFiller(this.result.getString("S_CUR_FILLER"));
/*  337 */         ub.setCity(this.result.getString("S_CITY_ID"));
/*  338 */         ub.setCrlim(this.result.getString("I_CUR_CRLIM"));
/*  339 */         ub.setCurrbal(this.result.getString("I_CUR_BAL"));
/*  340 */         ub.setTotdueamt(this.result.getString("I_CUR_TOT_DUE_AMT"));
/*  341 */         ub.setCashcrlim(this.result.getString("I_CUR_CASH_CRLIM"));
/*  342 */         ub.setStmtdate(this.result.getString("C_STMT_DATE"));
/*  343 */         ub.setCardNo(this.result.getString("S_CARD_PROD_ID"));
/*      */       }
/*  345 */       this.result.close();
/*  346 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  348 */       e.printStackTrace();
/*  349 */       return null;
/*      */     }
/*  351 */     return ub;
/*      */   }
/*      */ 
/*      */   public List<UserAccinfo> getUserInfo(UserBase ubase)
/*      */   {
/*  384 */     List list = new ArrayList();
/*      */     try {
/*  386 */       this.statement = this.dbconn.getConnection().prepareStatement(UserInfo_SQL);
/*  387 */       this.statement.setString(1, ubase.getAcctnbr());
/*  388 */       this.statement.setString(2, ubase.getStmtdate());
/*  389 */       this.result = this.statement.executeQuery();
/*      */ 
/*  391 */       while (this.result.next()) {
/*  392 */         UserAccinfo ub = new UserAccinfo();
/*  393 */         ub.setAcctnbr(this.result.getString("acctnbr"));
/*  394 */         ub.setRectype(this.result.getString("rectype"));
/*  395 */         ub.setStmtdate(this.result.getString("stmtdate"));
/*  396 */         ub.setPmtdate(this.result.getString("pmtdate"));
/*  397 */         ub.setTotbegbal(this.result.getString("totbegbal"));
/*  398 */         ub.setPlantotpmt(this.result.getString("plantotpmt"));
/*  399 */         ub.setPlantotnrlamt(this.result.getString("plantotnrlamt"));
/*  400 */         ub.setPlantotadjamt(this.result.getString("plantotadjamt"));
/*  401 */         ub.setIntdueamt(this.result.getString("intdueamt"));
/*  402 */         ub.setCurrbal(this.result.getString("currbal"));
/*  403 */         ub.setTotdueamt(this.result.getString("totdueamt"));
/*  404 */         ub.setPmtprint(this.result.getString("pmtprint"));
/*  405 */         ub.setCrlim(this.result.getString("crlim"));
/*  406 */         ub.setCashcrlim(this.result.getString("cashcrlim"));
/*  407 */         ub.setPmtarn(this.result.getString("pmtarn"));
/*  408 */         ub.setPmtadn(this.result.getString("pmtadn"));
/*  409 */         ub.setProjap(this.result.getString("projap"));
/*  410 */         ub.setPmtaflag(this.result.getString("pmtaflag"));
/*  411 */         ub.setAchflag(this.result.getString("achflag"));
/*  412 */         ub.setPmtflag(this.result.getString("pmtflag"));
/*  413 */         ub.setFiller(this.result.getString("filler"));
/*  414 */         list.add(ub);
/*      */       }
/*  416 */       this.result.close();
/*  417 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  419 */       e.printStackTrace();
/*      */     }
/*  421 */     return list;
/*      */   }
/*      */ 
/*      */   public List<UserAccinfoDetail> getAccinfoDetail(UserBase ub)
/*      */   {
/*  449 */     List list = new ArrayList();
/*      */     try {
/*  451 */       this.statement = this.dbconn.getConnection().prepareStatement(AccinfoDetail_SQL);
/*  452 */       this.statement.setString(1, ub.getAcctnbr());
/*  453 */       this.statement.setString(2, ub.getStmtdate());
/*  454 */       this.result = this.statement.executeQuery();
/*      */ 
/*  456 */       while (this.result.next()) {
/*  457 */         UserAccinfoDetail uad = new UserAccinfoDetail();
/*  458 */         uad.setAcctnbr(this.result.getString("acctnbr"));
/*  459 */         uad.setRectype(this.result.getString("rectype"));
/*  460 */         uad.setRecseq(this.result.getString("recseq"));
/*  461 */         uad.setEffdate(this.result.getString("effdate"));
/*  462 */         uad.setPostdate(this.result.getString("postdate"));
/*  463 */         uad.setCardnlast4(this.result.getString("cardnlast4"));
/*  464 */         uad.setDesc(this.result.getString("curdesc"));
/*  465 */         uad.setTxnamt(this.result.getString("txnamt"));
/*  466 */         uad.setSrctamt(this.result.getString("srctamt"));
/*  467 */         uad.setSrctcurr(this.result.getString("srctcurr"));
/*  468 */         uad.setPurcty(this.result.getString("purcty"));
/*  469 */         uad.setFiller(this.result.getString("filler"));
/*  470 */         uad.setMcc(this.result.getString("catcode"));
/*  471 */         uad.setCardNbr(this.result.getString("cardnbr"));
/*  472 */         uad.setAcceptorNbr(this.result.getString("accid"));
/*  473 */         uad.setTxnCode(this.result.getString("txncode"));
/*  474 */         uad.setMainAccount(this.result.getString("mainacc"));
/*  475 */         uad.setCnName(this.result.getString("cnname"));
/*  476 */         uad.setPyName(this.result.getString("pyname"));
/*  477 */         uad.setCardName(this.result.getString("cardname"));
/*  478 */         list.add(uad);
/*      */       }
/*  480 */       this.result.close();
/*  481 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  483 */       e.printStackTrace();
/*      */     }
/*  485 */     return list;
/*      */   }
/*      */ 
/*      */   public UserBuy getUserBuy(UserBase user)
/*      */   {
/*  501 */     UserBuy ub = null;
/*      */     try {
/*  503 */       this.statement = this.dbconn.getConnection().prepareStatement(UserBuy_SQL);
/*  504 */       this.statement.setString(1, user.getAcctnbr());
/*  505 */       this.statement.setString(2, user.getStmtdate());
/*  506 */       this.result = this.statement.executeQuery();
/*  507 */       while (this.result.next()) {
/*  508 */         ub = new UserBuy();
/*  509 */         ub.setAcctnbr(this.result.getString("S_ACCOUNT"));
/*  510 */         ub.setRectype(this.result.getString("S_CUR_PUR_REC_TYPE"));
/*  511 */         ub.setExchusdamt(this.result.getString("I_CUR_PUR_EXCH_USD_AMT"));
/*  512 */         ub.setSellrate(this.result.getString("I_CUR_PUR_SELL_RATE"));
/*  513 */         ub.setExchrmbamt(this.result.getString("I_CUR_PUR_EXCH_RMB_AMT"));
/*  514 */         ub.setAchrtnbr(this.result.getString("S_CUR_PUR_PMT_ACH_RT_NBR"));
/*  515 */         ub.setAchdbnbr(this.result.getString("S_CUR_PUR_PMT_ACH_DB_NBR"));
/*  516 */         ub.setFiller(this.result.getString("S_CUR_PUR_FILLER"));
/*      */       }
/*  518 */       this.result.close();
/*  519 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  521 */       e.printStackTrace();
/*  522 */       return null;
/*      */     }
/*  524 */     return ub;
/*      */   }
/*      */ 
/*      */   public List<Debitinfo> getDebitinfo(UserBase user)
/*      */   {
/*  547 */     List list = new ArrayList();
/*  548 */     Debitinfo deb = null;
/*      */     try {
/*  550 */       this.statement = this.dbconn.getConnection().prepareStatement(Debitinfo_SQL);
/*  551 */       this.statement.setString(1, user.getAcctnbr());
/*  552 */       this.statement.setString(2, user.getStmtdate());
/*  553 */       this.result = this.statement.executeQuery();
/*  554 */       while (this.result.next()) {
/*  555 */         deb = new Debitinfo();
/*  556 */         deb.setAcctnbr(this.result.getString("acctnbr"));
/*  557 */         deb.setRectype(this.result.getString("rectype"));
/*  558 */         deb.setCustnbr(this.result.getString("custnbr"));
/*  559 */         deb.setEffdate(this.result.getString("effdate"));
/*  560 */         deb.setTxndesc(this.result.getString("txndesc"));
/*  561 */         deb.setTxncity(this.result.getString("txncity"));
/*  562 */         deb.setCurrcode(this.result.getString("currcode"));
/*  563 */         deb.setTxnamt(this.result.getString("txnamt"));
/*  564 */         deb.setCardl4(this.result.getString("cardl4"));
/*  565 */         deb.setFiller(this.result.getString("filler"));
/*  566 */         list.add(deb);
/*      */       }
/*  568 */       this.result.close();
/*  569 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  571 */       e.printStackTrace();
/*  572 */       return null;
/*      */     }
/*  574 */     return list;
/*      */   }
/*      */ 
/*      */   public List<PointInfo> getPoint(UserBase user)
/*      */   {
/*  595 */     List list = new ArrayList();
/*  596 */     PointInfo p = null;
/*      */     try {
/*  598 */       this.statement = this.dbconn.getConnection().prepareStatement(Point_SQL);
/*  599 */       this.statement.setString(1, user.getAcctnbr());
/*  600 */       this.statement.setString(2, user.getStmtdate());
/*  601 */       this.result = this.statement.executeQuery();
/*  602 */       while (this.result.next()) {
/*  603 */         p = new PointInfo();
/*  604 */         p.setPointtype(this.result.getString("S_POINT_TYPE"));
/*  605 */         p.setCardportid(this.result.getString("S_ACCT_PROD_ID"));
/*  606 */         p.setBusinessid(this.result.getString("S_BUSINESS_ID"));
/*  607 */         p.setAblepoint(this.result.getString("I_ABLE_POINT"));
/*  608 */         p.setLastbalpoint(this.result.getString("I_LASTBAL_POINT"));
/*  609 */         p.setAddpoint(this.result.getString("I_ADDPOINT_POINT"));
/*  610 */         p.setExpoint(this.result.getString("I_EXPOINT_POINT"));
/*  611 */         p.setAdpoints(this.result.getString("I_ADPOINTS_POINT"));
/*  612 */         p.setEndpoints(this.result.getString("I_ENDPOINTS_POINT"));
/*  613 */         p.setEcifno(this.result.getString("S_ECIF_NO"));
/*  614 */         p.setStartdate(this.result.getString("S_START_DATE"));
/*  615 */         p.setEnddate(this.result.getString("S_END_DATE"));
/*  616 */         p.setWholeconsume(this.result.getString("I_WHOLE_CONSUME"));
/*  617 */         p.setInconsume(this.result.getString("I_IN_CONSUME"));
/*  618 */         p.setOutconsume(this.result.getString("I_OUT_CONSUME"));
/*  619 */         p.setWholemoney(this.result.getString("I_WHOLE_MONEY"));
/*  620 */         p.setInmoney(this.result.getString("I_IN_MONEY"));
/*  621 */         p.setOutmoney(this.result.getString("I_OUT_MONEY"));
/*  622 */         p.setUsedmoney(this.result.getString("I_USED_MONEY"));
/*  623 */         p.setLavemoney(this.result.getString("I_LAVE_MONEY"));
/*  624 */         p.setValiddate(this.result.getString("S_VALID_DATE"));
/*  625 */         p.setLaddermoney(this.result.getString("I_LADDER_MONEY"));
/*  626 */         p.setLadderscale(this.result.getString("S_LADDER_SCALE"));
/*  627 */         p.setCard4(this.result.getString("C_CARD_LAST4"));
/*  628 */         p.setCardPointType(this.result.getString("C_CARD_POINT_TYPE"));
/*  629 */         p.setCardname(this.result.getString("S_CARD_POINT_NAME"));
/*  630 */         list.add(p);
/*      */       }
/*  632 */       this.result.close();
/*  633 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  635 */       e.printStackTrace();
/*  636 */       return null;
/*      */     }
/*  638 */     return list;
/*      */   }
/*      */ 
/*      */   public PointInfo getPoint2(UserBase user)
/*      */   {
/*  647 */     PointInfo p = null;
/*      */     try {
/*  649 */       this.statement = this.dbconn.getConnection().prepareStatement("select * from T_H_POINT_W where S_ECIF_NO=? and C_STMT_DATE=?");
/*  650 */       if (user.getCusnum().length() > 12) {
/*  651 */         this.statement.setString(1, user.getCusnum().substring(7));
/*      */       }
/*      */       else {
/*  654 */         this.statement.setString(1, user.getCusnum());
/*      */       }
/*  656 */       this.statement.setString(2, user.getStmtdate());
/*  657 */       this.result = this.statement.executeQuery();
/*  658 */       while (this.result.next()) {
/*  659 */         p = new PointInfo();
/*  660 */         p.setBilldate(this.result.getString("C_STMT_DATE"));
/*  661 */         p.setBusinessid(this.result.getString("S_ECIF_NO"));
/*  662 */         p.setAblepoint(this.result.getString("I_ENDPOINT"));
/*  663 */         p.setEndpoints(this.result.getString("I_VALIDPOINT_B"));
/*  664 */         p.setLastbalpoint(this.result.getString("I_NEWPOINT"));
/*  665 */         p.setAddpoint(this.result.getString("I_USEDPOINT"));
/*  666 */         p.setExpoint(this.result.getString("I_ADJUSTPOINT"));
/*  667 */         p.setAdpoints(this.result.getString("I_INVAILPOINT"));
/*  668 */         p.setExpirespoint(this.result.getString("I_EXPIRES_POINT"));
/*      */       }
/*  670 */       this.result.close();
/*  671 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  673 */       e.printStackTrace();
/*  674 */       return null;
/*      */     }
/*  676 */     return p;
/*      */   }
/*      */ 
/*      */   public String getPointCardName(String cardportid, String pointtype)
/*      */   {
/*  686 */     String ss = "";
/*      */     try {
/*  688 */       this.statement = this.dbconn.getConnection().prepareStatement("select t.s_card_name from t_s_busi_card2 t where t.c_card_id=? and t.c_pointtype=?");
/*  689 */       this.statement.setString(1, cardportid);
/*  690 */       this.statement.setString(2, pointtype);
/*  691 */       this.result = this.statement.executeQuery();
/*  692 */       while (this.result.next()) {
/*  693 */         ss = this.result.getString(1);
/*      */       }
/*  695 */       this.result.close();
/*  696 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  698 */       e.printStackTrace();
/*  699 */       return "";
/*      */     }
/*  701 */     return ss;
/*      */   }
/*      */ 
/*      */   public List<Template> getTemplateList()
/*      */   {
/*  708 */     List list = new ArrayList();
/*      */     try {
/*  710 */       this.statement = this.dbconn.getConnection().prepareStatement(TEMPLATE_SQL);
/*  711 */       this.result = this.statement.executeQuery();
/*      */ 
/*  713 */       while (this.result.next()) {
/*  714 */         Template t = new Template();
/*  715 */         t.setId(this.result.getString("S_STENCIL_NO"));
/*  716 */         t.setCardid(this.result.getString("S_CARD_PROD_ID"));
/*  717 */         t.setType(this.result.getString("C_TYPE_NO"));
/*  718 */         list.add(t);
/*      */       }
/*  720 */       this.result.close();
/*  721 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  723 */       e.printStackTrace();
/*      */     }
/*  725 */     return list;
/*      */   }
/*      */ 
/*      */   public List<Rule> getRule(String tid, String type, String area, String billdayYM, String billdayD)
/*      */   {
/*  738 */     List list = new ArrayList();
/*      */     try {
/*  740 */       this.statement = this.dbconn.getConnection().prepareStatement(RULE_SQL);
/*  741 */       this.statement.setString(1, tid);
/*  742 */       this.statement.setString(2, type);
/*  743 */       this.statement.setString(3, area);
/*  744 */       this.statement.setString(4, billdayYM);
/*  745 */       this.statement.setString(5, billdayYM);
/*  746 */       this.statement.setString(6, billdayD);
/*  747 */       this.result = this.statement.executeQuery();
/*      */ 
/*  749 */       while (this.result.next()) {
/*  750 */         Rule r = new Rule();
/*  751 */         r.setRuleid(this.result.getString("S_RULE_NO"));
/*  752 */         r.setTid(this.result.getString("S_STENCIL_NO"));
/*  753 */         r.setRuleType(this.result.getString("C_RULE_TYPE"));
/*  754 */         r.setType(this.result.getString("C_TYPENO"));
/*  755 */         r.setPri(this.result.getString("I_PRI"));
/*  756 */         r.setAreaNo(this.result.getString("I_AREA_NO"));
/*  757 */         list.add(r);
/*      */       }
/*  759 */       this.result.close();
/*  760 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  762 */       e.printStackTrace();
/*      */     }
/*  764 */     return list;
/*      */   }
/*      */ 
/*      */   public List<RuleF> getRuleF(String rid)
/*      */   {
/*  771 */     List list = new ArrayList();
/*      */     try {
/*  773 */       this.statement = this.dbconn.getConnection().prepareStatement("select * from t_s_rule_f t where t.s_rule_no=? order by t.i_pri desc");
/*  774 */       this.statement.setString(1, rid);
/*  775 */       this.result = this.statement.executeQuery();
/*      */ 
/*  777 */       while (this.result.next()) {
/*  778 */         RuleF r = new RuleF();
/*  779 */         r.setId(this.result.getString("S_SEQUENCE"));
/*  780 */         r.setRid(this.result.getString("S_RULE_NO"));
/*  781 */         r.setFodder(this.result.getString("S_FODDER_NO"));
/*  782 */         r.setPri(this.result.getString("I_PRI"));
/*  783 */         list.add(r);
/*      */       }
/*  785 */       this.result.close();
/*  786 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  788 */       e.printStackTrace();
/*      */     }
/*  790 */     return list;
/*      */   }
/*      */ 
/*      */   public List<RuleM> getRuleFF(String rid)
/*      */   {
/*  797 */     List list = new ArrayList();
/*      */     try {
/*  799 */       this.statement = this.dbconn.getConnection().prepareStatement("select * from t_s_rule_ff t where t.s_sequence=? order by t.s_idx");
/*  800 */       this.statement.setString(1, rid);
/*  801 */       this.result = this.statement.executeQuery();
/*      */ 
/*  803 */       while (this.result.next()) {
/*  804 */         RuleM r = new RuleM();
/*  805 */         r.setFieldid(this.result.getString("S_FIELD"));
/*  806 */         r.setOpr1(this.result.getInt("C_OPR_1"));
/*  807 */         r.setVal1(this.result.getString("S_VALIUE_1"));
/*  808 */         r.setOpr2(this.result.getInt("C_OPR_2"));
/*  809 */         r.setVal2(this.result.getString("S_VALIUE_2"));
/*  810 */         r.setCif(this.result.getInt("C_IF"));
/*  811 */         list.add(r);
/*      */       }
/*  813 */       this.result.close();
/*  814 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  816 */       e.printStackTrace();
/*      */     }
/*  818 */     return list;
/*      */   }
/*      */ 
/*      */   public List<TempArea> getTemplateInfo(String tid)
/*      */   {
/*  825 */     List list = new ArrayList();
/*      */     try {
/*  827 */       this.statement = this.dbconn.getConnection().prepareStatement("select t.i_area_no,t.c_type_no from t_s_area t where t.s_stencil_no=?");
/*  828 */       this.statement.setString(1, tid);
/*  829 */       this.result = this.statement.executeQuery();
/*      */ 
/*  831 */       while (this.result.next()) {
/*  832 */         TempArea ta = new TempArea();
/*  833 */         ta.setArea(this.result.getString("i_area_no"));
/*  834 */         ta.setType(this.result.getString("c_type_no"));
/*  835 */         list.add(ta);
/*      */       }
/*  837 */       this.result.close();
/*  838 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  840 */       e.printStackTrace();
/*      */     }
/*  842 */     return list;
/*      */   }
/*      */ 
/*      */   public Fodder getFodder(String fid, String d)
/*      */   {
/*  852 */     Fodder fodder = null;
/*      */     try {
/*  854 */       this.statement = this.dbconn.getConnection().prepareStatement("select t.s_fodder_no,t.s_fodder_doc_name,t.s_url from T_S_FODDER  t where t.s_fodder_no=? and t.c_state='1' and to_date(?, 'yyyyMM') between to_date(t.c_period_begen, 'yyyy-MM') and to_date(t.c_period_end, 'yyyy-MM')");
/*  855 */       this.statement.setString(1, fid);
/*  856 */       this.statement.setString(2, d);
/*  857 */       this.result = this.statement.executeQuery();
/*  858 */       while (this.result.next()) {
/*  859 */         fodder = new Fodder();
/*  860 */         fodder.setFid(this.result.getString("s_fodder_no"));
/*  861 */         fodder.setUrl(this.result.getString("s_fodder_doc_name"));
/*  862 */         fodder.setLinkurl(this.result.getString("s_url"));
/*      */       }
/*  864 */       this.result.close();
/*  865 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  867 */       e.printStackTrace();
/*  868 */       return null;
/*      */     }
/*  870 */     return fodder;
/*      */   }
/*      */ 
/*      */   public List<Foldout> getFoldout(String bid, String cid, String billdate)
/*      */   {
/*  881 */     List list = new ArrayList();
/*  882 */     Foldout foldout = null;
/*      */     try {
/*  884 */       this.statement = this.dbconn.getConnection().prepareStatement("select * from T_S_FOLDOUT_PROD t2 where t2.i_id= (select t.i_id from T_S_FOLDOUT_PROD_SUB t where t.s_foldout_businpnt_no=? and t.s_foldout_prod_bpid=? and t.c_period=substr(?,7,2) and to_date(?,'yyyyMMdd') >= to_date(t.c_period_begen,'yyyy-MM')and to_date(?,'yyyyMMdd') <= to_date(t.c_period_end,'yyyy-MM')) order by t2.i_foldout_index");
/*  885 */       this.statement.setString(1, bid);
/*  886 */       this.statement.setString(2, cid);
/*  887 */       this.statement.setString(3, billdate);
/*  888 */       this.statement.setString(4, billdate);
/*  889 */       this.statement.setString(5, billdate);
/*  890 */       this.result = this.statement.executeQuery();
/*  891 */       while (this.result.next()) {
/*  892 */         foldout = new Foldout();
/*  893 */         foldout.setId(this.result.getString("I_FOLDOUT_INDEX"));
/*  894 */         foldout.setName(this.result.getString("S_FOLDOUT_PROD_NAME"));
/*  895 */         foldout.setPri(this.result.getInt("I_FOLDOUT_PRI"));
/*  896 */         list.add(foldout);
/*      */       }
/*  898 */       this.result.close();
/*  899 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  901 */       e.printStackTrace();
/*  902 */       return null;
/*      */     }
/*  904 */     return list;
/*      */   }
/*      */ 
/*      */   public Map<String, String> getFoldoutCity(String id, String idx)
/*      */   {
/*  918 */     Map map = new HashMap();
/*  919 */     String city = "";
/*      */     try {
/*  921 */       String sql = "select t.s_foldout_city from t_s_foldout_city t where t.i_id=? and t.i_foldout_index=?";
/*  922 */       this.statement = this.dbconn.getConnection().prepareStatement(sql);
/*  923 */       this.statement.setString(1, id);
/*  924 */       this.statement.setString(2, idx);
/*  925 */       this.result = this.statement.executeQuery();
/*  926 */       while (this.result.next()) {
/*  927 */         city = this.result.getString("s_foldout_city");
/*  928 */         map.put(city, city);
/*      */       }
/*  930 */       this.result.close();
/*  931 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  933 */       e.printStackTrace();
/*      */     }
/*      */     finally {
/*  936 */       return map;
/*      */     }
/*      */   }
/*      */ 
/*      */   public int savePLogBegin(Plog log)
/*      */   {
/*  943 */     int ret = -1;
/*      */     try {
/*  945 */       this.statement = this.dbconn.getConnection().prepareStatement("insert into T_H_XML_LOG (S_PERIOD,S_FILENAME,S_BUSINPNT_NO,C_START_TIME,S_CARD_PROD_ID,S_PAPER_NO,C_STATE) values (?,?,?,?,?,?,'2')");
/*  946 */       this.statement.setString(1, log.getStmtdate());
/*  947 */       this.statement.setString(2, log.getFilename());
/*  948 */       this.statement.setString(3, log.getBusinpnt_no());
/*  949 */       this.statement.setString(4, log.getStart_time());
/*  950 */       this.statement.setString(5, log.getCard_id());
/*  951 */       this.statement.setString(6, log.getPaper_no());
/*  952 */       ret = this.statement.executeUpdate();
/*  953 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  955 */       e.printStackTrace();
/*  956 */       return ret;
/*      */     }
/*  958 */     return ret;
/*      */   }
/*      */ 
/*      */   public int savePLog(Plog log)
/*      */   {
/*  965 */     int ret = -1;
/*  966 */     String sql = "insert into T_H_XML_LOG (S_PERIOD,S_FILENAME,S_BUSINPNT_NO,C_START_TIME,S_CARD_PROD_ID,S_PAPER_NO,C_STATE,I_SHARE,C_END_TIME) values (?,?,?,?,?,?,?,?,?)";
/*      */     try {
/*  968 */       this.statement = this.dbconn.getConnection().prepareStatement(sql);
/*  969 */       this.statement.setString(1, log.getStmtdate());
/*  970 */       this.statement.setString(2, log.getFilename());
/*  971 */       this.statement.setString(3, log.getBusinpnt_no());
/*  972 */       this.statement.setString(4, log.getStart_time());
/*  973 */       this.statement.setString(5, log.getCard_id());
/*  974 */       this.statement.setString(6, log.getPaper_no());
/*      */ 
/*  976 */       this.statement.setString(7, log.getState());
/*  977 */       this.statement.setInt(8, log.getShare());
/*  978 */       this.statement.setString(9, log.getEnd_time());
/*  979 */       ret = this.statement.executeUpdate();
/*  980 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  982 */       e.printStackTrace();
/*  983 */       return ret;
/*      */     }
/*  985 */     return ret;
/*      */   }
/*      */ 
/*      */   public int savePLogEnd(Plog log)
/*      */   {
/*  992 */     int ret = -1;
/*      */     try {
/*  994 */       this.statement = this.dbconn.getConnection().prepareStatement("update T_H_XML_LOG set I_SHARE=?,C_END_TIME=?,C_STATE=? where S_FILENAME=?");
/*  995 */       this.statement.setInt(1, log.getShare());
/*  996 */       this.statement.setString(2, log.getEnd_time());
/*  997 */       this.statement.setString(3, log.getState());
/*  998 */       this.statement.setString(4, log.getFilename());
/*  999 */       ret = this.statement.executeUpdate();
/* 1000 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1002 */       e.printStackTrace();
/* 1003 */       return ret;
/*      */     }
/* 1005 */     return ret;
/*      */   }
/*      */ 
/*      */   public int avePLogDel(Plog log)
/*      */   {
/* 1013 */     int ret = -1;
/*      */     try {
/* 1015 */       this.statement = this.dbconn.getConnection().prepareStatement("delete T_H_XML_LOG t where t.s_filename=?");
/* 1016 */       this.statement.setString(1, log.getFilename());
/* 1017 */       ret = this.statement.executeUpdate();
/* 1018 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1020 */       e.printStackTrace();
/* 1021 */       return ret;
/*      */     }
/* 1023 */     return ret;
/*      */   }
/*      */ 
/*      */   public List<PrintInfo> getRePrintInfo(String tag)
/*      */   {
/* 1031 */     List list = new ArrayList();
/* 1032 */     Calendar cal = Calendar.getInstance();
/* 1033 */     cal.add(5, -1);
/* 1034 */     String today = DateFormatUtils.format(cal.getTime(), "yyyy-MM-dd");
/* 1035 */     String sql = "select * from T_B_REPRINT t where t.c_buildflg='0'   and t.S_REPAIR_TYPE='" + 
/* 1037 */       tag + "'" + 
/* 1038 */       "   and t.S_APPLY_DATE between '" + today + " 00:00:00' " + 
/* 1039 */       "   and '" + today + " 23:59:59'" + 
/* 1040 */       " order by t.S_REPAIR_TYPE,S_CARD_PROD_ID,S_BUSINPNT_NO";
/* 1041 */     System.out.println(sql);
/*      */     try {
/* 1043 */       this.statement = this.dbconn.getConnection().prepareStatement(sql);
/* 1044 */       this.result = this.statement.executeQuery();
/*      */ 
/* 1046 */       while (this.result.next()) {
/* 1047 */         PrintInfo pi = new PrintInfo();
/* 1048 */         pi.setId(this.result.getString("S_SEQ"));
/* 1049 */         pi.setCard_no(this.result.getString("S_CARD_PROD_ID"));
/* 1050 */         pi.setAccount(this.result.getString("S_BUSINESS_ID"));
/* 1051 */         pi.setBusinpnt_no(this.result.getString("S_BUSINPNT_NO"));
/* 1052 */         pi.setPeriod(this.result.getString("S_PERIOD"));
/* 1053 */         pi.setIsUpAddr(this.result.getString("C_IS_ADDR"));
/* 1054 */         pi.setAddrname3(this.result.getString("S_ADDPROV"));
/* 1055 */         pi.setAddrname1(this.result.getString("S_ADDCIYT"));
/* 1056 */         pi.setAddrname2(this.result.getString("S_ADDL1"));
/* 1057 */         pi.setAddpost(this.result.getString("S_ADDPOST"));
/* 1058 */         pi.setPrintType(this.result.getString("S_REPAIR_TYPE"));
/* 1059 */         pi.setEmail(this.result.getString("S_EMAIL"));
/* 1060 */         pi.setCityid(this.result.getString("S_CITY_ID"));
/* 1061 */         list.add(pi);
/*      */       }
/* 1063 */       this.result.close();
/* 1064 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1066 */       e.printStackTrace();
/*      */     }
/* 1068 */     return list;
/*      */   }
/*      */ 
/*      */   public Map<String, String> getCity(String addpos)
/*      */   {
/* 1077 */     Map citymap = new HashMap();
/*      */     try {
/* 1079 */       this.statement = this.dbconn.getConnection().prepareStatement("select * from t_s_code_tmp t");
/* 1080 */       this.result = this.statement.executeQuery();
/* 1081 */       while (this.result.next()) {
/* 1082 */         citymap.put(this.result.getString("C_ZIPCODE"), this.result.getString("S_CITY_NO"));
/*      */       }
/* 1084 */       this.result.close();
/* 1085 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1087 */       e.printStackTrace();
/* 1088 */       return citymap;
/*      */     }
/* 1090 */     return citymap;
/*      */   }
/*      */ 
/*      */   public Map<String, String> getGL(String cardNo, String cityNo)
/*      */   {
/* 1098 */     Map map = null;
/* 1099 */     String sql = "select B.s_id,       B.S_BUSINPNT_NO,       A.S_PAPER_NO,       (select t1.c_buss_type_id          from t_s_busi_prod_info t1         where t1.s_buss_prod_id = B.s_card_no) as c_buss_type_id  from (select t2.s_paper_no, t2.s_id          from t_s_befor_print_basic t2         where ? between t2.c_period_begen and t2.c_period_end           and t2.c_period_day = ?         order by t2.i_print_pri desc) A,       (select t.s_id, t.s_businpnt_no, t.s_card_no          from t_s_bfpnt_cty_crdtp t         where t.s_city_no = ?           and t.s_card_no = ?           AND t.s_id <> '0'           and t.s_businpnt_no > '0') B where A.s_Id = B.S_ID   and rownum = 1";
/*      */     try
/*      */     {
/* 1119 */       this.statement = this.dbconn.getConnection().prepareStatement(sql);
/* 1120 */       this.statement.setString(1, BaseParam.PERIOD_Y + "-" + BaseParam.PERIOD_M);
/* 1121 */       this.statement.setString(2, BaseParam.PERIOD_D);
/* 1122 */       this.statement.setString(3, cityNo);
/* 1123 */       this.statement.setString(4, cardNo);
/* 1124 */       this.result = this.statement.executeQuery();
/* 1125 */       while (this.result.next()) {
/* 1126 */         map = new HashMap();
/* 1127 */         map.put("yyz", this.result.getString("s_id"));
/* 1128 */         map.put("yyzno", this.result.getString("s_paper_no"));
/* 1129 */         map.put("wbs", this.result.getString("s_businpnt_no"));
/* 1130 */         map.put("cardtype", this.result.getString("c_buss_type_id"));
/* 1131 */         map.put("cardid", cardNo);
/* 1132 */         map.put("cityid", cityNo);
/*      */       }
/* 1134 */       this.result.close();
/* 1135 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1137 */       e.printStackTrace();
/* 1138 */       return null;
/*      */     }
/* 1140 */     return map;
/*      */   }
/*      */ 
/*      */   public int setRePrintFlg(PrintInfo pi)
/*      */   {
/* 1148 */     int i = 0;
/*      */     try {
/* 1150 */       this.statement = this.dbconn.getConnection().prepareStatement("update T_B_REPRINT t set t.c_buildflg=? where t.s_seq=?");
/* 1151 */       this.statement.setString(1, pi.getFlg());
/* 1152 */       this.statement.setString(2, pi.getId());
/* 1153 */       i = this.statement.executeUpdate();
/* 1154 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1156 */       e.printStackTrace();
/* 1157 */       return -1;
/*      */     }
/* 1159 */     return i;
/*      */   }
/*      */ 
/*      */   public Map<String, String> getConfig()
/*      */   {
/* 1167 */     Map cmap = new HashMap();
/*      */     try {
/* 1169 */       this.statement = this.dbconn.getConnection().prepareStatement("select t.s_type,t.s_value from t_s_bill_para t");
/* 1170 */       this.result = this.statement.executeQuery();
/* 1171 */       while (this.result.next()) {
/* 1172 */         cmap.put(this.result.getString("s_type"), this.result.getString("s_value"));
/*      */       }
/* 1174 */       this.result.close();
/* 1175 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1177 */       e.printStackTrace();
/* 1178 */       return cmap;
/*      */     }
/* 1180 */     return cmap;
/*      */   }
/*      */ 
/*      */   public int updateDeliveryNum(String bar_num, String delivery_num, String appdate)
/*      */   {
/* 1185 */     int i = 0;
/*      */     try {
/* 1187 */       this.statement.setString(1, delivery_num);
/* 1188 */       this.statement.setString(2, bar_num);
/* 1189 */       this.statement.setString(3, appdate + " 00:00:00");
/* 1190 */       this.statement.setString(4, appdate + " 24:00:00");
/* 1191 */       this.statement.executeUpdate();
/*      */     } catch (SQLException e) {
/* 1193 */       e.printStackTrace();
/* 1194 */       return 0;
/*      */     }
/* 1196 */     return i;
/*      */   }
/*      */   public void updateDeliveryNumBegin() {
/*      */     try {
/* 1200 */       this.conn = this.dbconn.getConnection();
/* 1201 */       this.statement = this.conn.prepareStatement(this.sql);
/*      */     }
/*      */     catch (SQLException e) {
/* 1204 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void updateDeliveryNumEnd() {
/*      */     try {
/* 1210 */       this.conn.commit();
/* 1211 */       this.statement.close();
/* 1212 */       this.conn.close();
/*      */     } catch (SQLException e) {
/* 1214 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public Map<String, String> queryFQJY() {
/* 1219 */     Map map = new HashMap();
/*      */     try {
/* 1221 */       this.statement = this.dbconn.getConnection().prepareStatement("select * from T_S_TRADE_NUMBER t");
/* 1222 */       this.result = this.statement.executeQuery();
/* 1223 */       while (this.result.next()) {
/* 1224 */         map.put(this.result.getString("c_trade_num"), "");
/*      */       }
/* 1226 */       this.result.close();
/* 1227 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1229 */       e.printStackTrace();
/*      */     }
/* 1231 */     return map;
/*      */   }
/*      */ 
/*      */   public String queryAsset(String account)
/*      */   {
/* 1239 */     String returnStr = "";
/*      */     try {
/* 1241 */       this.statement = this.dbconn.getConnection().prepareStatement("select * from t_H_customer_asset WHERE s_account = ? ORDER BY s_rec_type", 
/* 1242 */         1005, 1008);
/* 1243 */       this.statement.setString(1, account);
/* 1244 */       this.result = this.statement.executeQuery();
/*      */ 
/* 1246 */       if (this.result.last()) {
/* 1247 */         this.result.first();
/* 1248 */         returnStr = returnStr + this.result.getString("s_desc").trim();
/*      */       }
/* 1250 */       while (this.result.next()) {
/* 1251 */         returnStr = returnStr + "、" + this.result.getString("s_desc").trim();
/*      */       }
/* 1253 */       if (!"".equals(returnStr))
/* 1254 */         returnStr = returnStr + "。";
/*      */     }
/*      */     catch (SQLException e) {
/* 1257 */       e.printStackTrace();
/*      */       try
/*      */       {
/* 1260 */         if (this.result != null) this.result.close();
/* 1261 */         if (this.statement != null) this.statement.close(); 
/*      */       }
/* 1263 */       catch (SQLException e) { e.printStackTrace(); }
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/* 1260 */         if (this.result != null) this.result.close();
/* 1261 */         if (this.statement != null) this.statement.close(); 
/*      */       }
/* 1263 */       catch (SQLException e) { e.printStackTrace(); }
/*      */ 
/*      */     }
/* 1266 */     return returnStr;
/*      */   }
/*      */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.reprintXML.DBDao
 * JD-Core Version:    0.6.2
 */