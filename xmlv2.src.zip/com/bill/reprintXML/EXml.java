/*     */ package com.bill.reprintXML;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.makeXML.handler.WriteXML;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ 
/*     */ public class EXml
/*     */   implements WriteXML
/*     */ {
/*  18 */   public String path = "d:";
/*     */   public File file;
/*     */   public RandomAccessFile filew;
/*     */ 
/*     */   public String create(String stmtdate, String cardid, String cardtype, int count, String id)
/*     */   {
/*  38 */     String fpath = getFileInfo(cardid, cardtype);
/*     */ 
/*  41 */     this.file = new File(fpath + stmtdate + "_" + cardid + "_" + count + "_" + id + ".xml");
/*     */     try {
/*  43 */       if (this.file.exists()) {
/*  44 */         this.file.delete();
/*     */       }
/*     */ 
/*  47 */       if (this.file.createNewFile()) {
/*  48 */         this.filew = new RandomAccessFile(this.file.getPath(), "rw");
/*  49 */         write(BaseParam.XML_BEGIN);
/*     */       }
/*     */     } catch (IOException e) {
/*  52 */       e.printStackTrace();
/*     */     }
/*  54 */     return this.file.getPath();
/*     */   }
/*     */ 
/*     */   public void write(String xml)
/*     */   {
/*  61 */     if (this.filew == null) return;
/*     */     try
/*     */     {
/*  64 */       this.filew.write(xml.getBytes("utf-8"));
/*     */     } catch (IOException e) {
/*  66 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void over(int count)
/*     */   {
/*  74 */     if (this.filew == null) return;
/*  75 */     write(BaseParam.XML_END);
/*     */     try {
/*  77 */       this.filew.close();
/*     */     } catch (IOException e) {
/*  79 */       e.printStackTrace();
/*     */     } finally {
/*  81 */       this.filew = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void close(int count) {
/*     */     try {
/*  87 */       write(BaseParam.XML_END);
/*  88 */       this.filew.close();
/*  89 */       if (count == 0)
/*  90 */         this.file.delete();
/*     */     }
/*     */     catch (IOException e) {
/*  93 */       e.printStackTrace();
/*     */     } finally {
/*  95 */       this.filew = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getFileInfo(String cardid, String cardtype)
/*     */   {
/* 107 */     String fpath = BaseParam.XML_PATH + cardtype + "/REPRINT/XML/HTML/";
/* 108 */     File temp = new File(fpath);
/*     */ 
/* 110 */     if (!temp.exists()) {
/* 111 */       temp.mkdirs();
/*     */     }
/*     */ 
/* 114 */     String d = BaseParam.PERIOD;
/* 115 */     String y = d.substring(0, 4);
/* 116 */     String m = d.substring(4, 6);
/* 117 */     String day = d.substring(6, 8);
/* 118 */     String htmlpath = BaseParam.XML_PATH + cardtype + "/REPRINT/HTML/" + y + "/" + m + "/" + day;
/* 119 */     temp = new File(htmlpath);
/*     */ 
/* 121 */     if (!temp.exists()) {
/* 122 */       temp.mkdirs();
/*     */     }
/* 124 */     return fpath;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.reprintXML.EXml
 * JD-Core Version:    0.6.2
 */