/*     */ package com.bill.reprintXML;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.bean.Busin;
/*     */ import com.bill.bean.Card;
/*     */ import com.bill.bean.Debitinfo;
/*     */ import com.bill.bean.Fodder;
/*     */ import com.bill.bean.Foldout;
/*     */ import com.bill.bean.Plog;
/*     */ import com.bill.bean.PointInfo;
/*     */ import com.bill.bean.PrintInfo;
/*     */ import com.bill.bean.Rule;
/*     */ import com.bill.bean.RuleF;
/*     */ import com.bill.bean.RuleM;
/*     */ import com.bill.bean.Stageplan;
/*     */ import com.bill.bean.TempArea;
/*     */ import com.bill.bean.Template;
/*     */ import com.bill.bean.UserAccinfo;
/*     */ import com.bill.bean.UserAccinfoDetail;
/*     */ import com.bill.bean.UserBase;
/*     */ import com.bill.bean.UserBuy;
/*     */ import com.bill.bean.Yyz;
/*     */ import com.bill.bean.mcc;
/*     */ import com.bill.util.DESUtil;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class Cache
/*     */ {
/*     */   private static DBDao dao;
/*  12 */   public static Map<String, String> configMap = null;
/*     */ 
/*  16 */   public static List<Busin> businList = null;
/*     */ 
/*  20 */   public static List<Card> cardList = null;
/*  21 */   public static DESUtil des = null;
/*     */ 
/*  25 */   public static Map<String, List<Yyz>> cardBfpntMap = null;
/*     */   private static Map<String, Map<String, String>> cardCityMap;
/*     */   public static List<mcc> mcclist;
/*     */   public static Map<String, String> mccmap;
/*     */   public static Map<String, String> mccMapMaster;
/*     */   public static Map<String, String> mccMapSub;
/*  33 */   private static String MCC_NAME_E = "";
/*     */ 
/*  35 */   private static String MCC_NAME_M = "S_TYPE_NAME";
/*     */ 
/*  37 */   private static String MCC_NAME_S = "S_NAME";
/*     */   public static Map<String, String> stageTypeMap;
/*  45 */   public static Map<String, String> pointCardNameMap = new HashMap();
/*     */ 
/*  52 */   public static Map<String, String> templateMap = null;
/*     */ 
/*  59 */   public static Map<String, List<TempArea>> templateInfo = new HashMap();
/*     */ 
/*  66 */   public static Map<String, List<Rule>> ruleMap = null;
/*  67 */   public static Map<String, List<RuleF>> ruleFMap = new HashMap();
/*  68 */   public static Map<String, List<RuleM>> ruleMMap = new HashMap();
/*     */ 
/*  72 */   public static Map<String, Fodder> fodderMap = new HashMap();
/*     */ 
/*  77 */   public static Map<String, List<Foldout>> foldoutMap = new HashMap();
/*     */ 
/*  81 */   public static Map<String, Map<String, String>> foldoutCityMap = new HashMap();
/*     */   private static Map<String, String> cityMap;
/*  87 */   public static Map<String, String> fqjyCard = new HashMap();
/*     */ 
/*     */   public static List<String> getCityByCPB(String cardid, String printid, String businId)
/*     */   {
/*  97 */     return dao.getCityByCPB(cardid, printid, businId);
/*     */   }
/*     */ 
/*     */   public static UserBase getUserBase(PrintInfo pi)
/*     */   {
/* 106 */     return dao.getUserBase(pi);
/*     */   }
/*     */ 
/*     */   public static List<UserAccinfo> getUserInfo(UserBase ub)
/*     */   {
/* 114 */     return dao.getUserInfo(ub);
/*     */   }
/*     */ 
/*     */   public static List<UserAccinfoDetail> getAccinfoDetail(UserBase ub)
/*     */   {
/* 122 */     return dao.getAccinfoDetail(ub);
/*     */   }
/*     */ 
/*     */   public static UserBuy getUserBuy(UserBase ub)
/*     */   {
/* 130 */     return dao.getUserBuy(ub);
/*     */   }
/*     */ 
/*     */   public static List<Debitinfo> getDebitinfo(UserBase user) {
/* 134 */     return dao.getDebitinfo(user);
/*     */   }
/*     */   public static List<PointInfo> getPoint(UserBase user) {
/* 137 */     return dao.getPoint(user);
/*     */   }
/*     */   public static PointInfo getPoint2(UserBase user) {
/* 140 */     return dao.getPoint2(user);
/*     */   }
/*     */ 
/*     */   public static String getPointCardName(PointInfo pi)
/*     */   {
/* 148 */     if (pointCardNameMap.containsKey(pi.getCardportid() + "_" + pi.getPointtype())) {
/* 149 */       return (String)pointCardNameMap.get(pi.getCardportid() + "_" + pi.getPointtype());
/*     */     }
/* 151 */     String s = dao.getPointCardName(pi.getCardportid(), pi.getPointtype());
/* 152 */     pointCardNameMap.put(pi.getCardportid() + "_" + pi.getPointtype(), s);
/* 153 */     return s;
/*     */   }
/*     */ 
/*     */   public static Map<String, String> getTemplateMap()
/*     */   {
/* 164 */     Map map = new HashMap();
/* 165 */     List list = dao.getTemplateList();
/* 166 */     String key = "";
/* 167 */     for (Template t : list) {
/* 168 */       key = t.getCardid() + "_" + t.getType();
/* 169 */       map.put(key, t.getId());
/*     */     }
/* 171 */     return map;
/*     */   }
/*     */ 
/*     */   public static List<Rule> getRuleMap(String tid, String type, String area)
/*     */   {
/* 181 */     if (ruleMap == null) {
/* 182 */       ruleMap = new HashMap();
/*     */     }
/* 184 */     if (ruleMap.containsKey(tid + "_" + type + "_" + area))
/*     */     {
/* 186 */       return (List)ruleMap.get(tid + "_" + type + "_" + area);
/*     */     }
/* 188 */     List list = dao.getRule(tid, type, area, BaseParam.PERIOD_YM, BaseParam.PERIOD_D);
/* 189 */     ruleMap.put(tid + "_" + type + "_" + area, list);
/* 190 */     return list;
/*     */   }
/*     */ 
/*     */   public static List<RuleF> getRuleFMap(String rid)
/*     */   {
/* 199 */     if (ruleFMap.containsKey(rid)) {
/* 200 */       return (List)ruleFMap.get(rid);
/*     */     }
/*     */ 
/* 203 */     List list = dao.getRuleF(rid);
/* 204 */     ruleFMap.put(rid, list);
/* 205 */     return list;
/*     */   }
/*     */ 
/*     */   public static List<RuleM> getRuleFFList(String rid)
/*     */   {
/* 214 */     if (ruleMMap.containsKey(rid)) {
/* 215 */       return (List)ruleMMap.get(rid);
/*     */     }
/*     */ 
/* 218 */     List list = dao.getRuleFF(rid);
/* 219 */     ruleMMap.put(rid, list);
/* 220 */     return list;
/*     */   }
/*     */ 
/*     */   public static List<TempArea> getTemplateInfo(String tid)
/*     */   {
/* 231 */     if ((templateInfo != null) && (templateInfo.containsKey(tid))) {
/* 232 */       return (List)templateInfo.get(tid);
/*     */     }
/* 234 */     List list = dao.getTemplateInfo(tid);
/* 235 */     templateInfo.put(tid, list);
/* 236 */     return list;
/*     */   }
/*     */ 
/*     */   public static Fodder getFodder(String fid)
/*     */   {
/* 245 */     if (fodderMap.containsKey(fid)) {
/* 246 */       return (Fodder)fodderMap.get(fid);
/*     */     }
/* 248 */     Fodder f = null;
/* 249 */     f = dao.getFodder(fid, BaseParam.PERIOD_YM);
/* 250 */     fodderMap.put(fid, f);
/* 251 */     return f;
/*     */   }
/*     */ 
/*     */   public static List<Stageplan> getStageplan(UserBase sb)
/*     */   {
/* 260 */     return dao.getStageplan(sb);
/*     */   }
/*     */ 
/*     */   public static List<Foldout> getFoldout(String bid, String cid)
/*     */   {
/* 270 */     if (foldoutMap.containsKey(bid + "_" + cid)) {
/* 271 */       return (List)foldoutMap.get(bid + "_" + cid);
/*     */     }
/*     */ 
/* 274 */     List list = dao.getFoldout(bid, cid, BaseParam.PERIOD);
/* 275 */     if (list.size() < 4) {
/* 276 */       for (int i = list.size(); 
/* 278 */         i < 4; i++) {
/* 279 */         Foldout f = new Foldout();
/* 280 */         f.setPri(1);
/* 281 */         f.setState("0");
/* 282 */         list.add(f);
/*     */       }
/*     */     }
/* 285 */     foldoutMap.put(bid + "_" + cid, list);
/* 286 */     return list;
/*     */   }
/*     */ 
/*     */   public static synchronized Map<String, String> getFoldoutCity(String id, String idx)
/*     */   {
/* 296 */     if (foldoutCityMap.containsKey(id + "_" + idx)) {
/* 297 */       return (Map)foldoutCityMap.get(id + "_" + id);
/*     */     }
/*     */ 
/* 300 */     Map cityMap = dao.getFoldoutCity(id, idx);
/* 301 */     foldoutCityMap.put(id + "_" + id, cityMap);
/* 302 */     return cityMap;
/*     */   }
/*     */ 
/*     */   public static int savePLogBegin(Plog log)
/*     */   {
/* 311 */     log.setStmtdate(BaseParam.PERIOD);
/* 312 */     log.setStart_time(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Long.valueOf(System.currentTimeMillis())));
/* 313 */     return dao.savePLogBegin(log);
/*     */   }
/*     */ 
/*     */   public static int savePLog(Plog log)
/*     */   {
/* 322 */     return dao.savePLog(log);
/*     */   }
/*     */ 
/*     */   public static int savePLogEnd(Plog log)
/*     */   {
/* 331 */     log.setEnd_time(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Long.valueOf(System.currentTimeMillis())));
/* 332 */     return dao.savePLogEnd(log);
/*     */   }
/*     */ 
/*     */   public static int savePLogDel(Plog log) {
/* 336 */     return dao.avePLogDel(log);
/*     */   }
/*     */ 
/*     */   public static List<PrintInfo> getRePrintInfo(String tag)
/*     */   {
/* 344 */     return dao.getRePrintInfo(tag);
/*     */   }
/*     */ 
/*     */   public static String getCity(String addpos)
/*     */   {
/* 353 */     String city = "";
/* 354 */     String zip = "";
/* 355 */     if (cityMap == null) {
/* 356 */       cityMap = dao.getCity(addpos);
/*     */     }
/* 358 */     if (addpos.length() > 4) {
/* 359 */       zip = addpos.substring(0, 4);
/* 360 */       if (cityMap.containsKey(zip)) {
/* 361 */         city = (String)cityMap.get(zip);
/*     */       }
/* 363 */       return city;
/*     */     }
/* 365 */     return "";
/*     */   }
/*     */ 
/*     */   public static Map<String, String> getGL(String cardNo, String cityNo)
/*     */   {
/* 376 */     Map m = null;
/* 377 */     if (cardCityMap == null) {
/* 378 */       cardCityMap = new HashMap();
/*     */     }
/* 380 */     if (cardCityMap.containsKey(cardNo + "_" + cityNo)) {
/* 381 */       m = (Map)cardCityMap.get(cardNo + "_" + cityNo);
/*     */     } else {
/* 383 */       m = dao.getGL(cardNo, cityNo);
/* 384 */       cardCityMap.put(cardNo + "_" + cityNo, m);
/*     */     }
/* 386 */     return m;
/*     */   }
/*     */ 
/*     */   public static int setRePrintFlg(PrintInfo pi)
/*     */   {
/* 394 */     return dao.setRePrintFlg(pi);
/*     */   }
/*     */ 
/*     */   public static void init()
/*     */   {
/* 402 */     if (dao == null) {
/* 403 */       dao = new DBDao();
/*     */     }
/* 405 */     if (configMap == null) {
/* 406 */       configMap = dao.getConfig();
/*     */ 
/* 408 */       BaseParam.setPeriod((String)configMap.get("PERIOD"));
/* 409 */       BaseParam.XML_PATH = (String)configMap.get("BASEPATH");
/*     */     }
/* 411 */     if (businList == null)
/*     */     {
/* 413 */       businList = dao.getBusin();
/*     */     }
/* 415 */     if (cardList == null)
/*     */     {
/* 417 */       cardList = dao.getCard();
/*     */     }
/* 419 */     if (cardBfpntMap == null)
/*     */     {
/* 421 */       cardBfpntMap = dao.getCardBfpntMap();
/*     */     }
/* 423 */     if (templateMap == null)
/*     */     {
/* 425 */       templateMap = getTemplateMap();
/*     */     }
/*     */ 
/* 429 */     fqjyCard = dao.queryFQJY();
/*     */ 
/* 431 */     mccmap = new HashMap();
/* 432 */     mccMapMaster = new HashMap();
/* 433 */     mccMapSub = new HashMap();
/*     */ 
/* 442 */     stageTypeMap = dao.queryStageType();
/*     */     try
/*     */     {
/* 445 */       des = new DESUtil("GLPp7Or8".getBytes());
/*     */     } catch (Exception e) {
/* 447 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void colse()
/*     */   {
/* 456 */     dao.close();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.reprintXML.Cache
 * JD-Core Version:    0.6.2
 */