/*      */ package com.bill.reprintXML;
/*      */ 
/*      */ import com.bill.bean.BaseParam;
/*      */ import com.bill.bean.Debitinfo;
/*      */ import com.bill.bean.Fodder;
/*      */ import com.bill.bean.Foldout;
/*      */ import com.bill.bean.PointInfo;
/*      */ import com.bill.bean.Rule;
/*      */ import com.bill.bean.RuleF;
/*      */ import com.bill.bean.RuleM;
/*      */ import com.bill.bean.Stageplan;
/*      */ import com.bill.bean.TempArea;
/*      */ import com.bill.bean.UserAccinfo;
/*      */ import com.bill.bean.UserAccinfoDetail;
/*      */ import com.bill.bean.UserBase;
/*      */ import com.bill.bean.UserBuy;
/*      */ import com.bill.util.DESUtil;
/*      */ import java.net.URLEncoder;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.apache.log4j.Logger;
/*      */ 
/*      */ public class UserXml
/*      */ {
/*      */   private StringBuffer tab1;
/*      */   private StringBuffer tab2;
/*      */   private StringBuffer temp;
/*      */   private List<StringBuffer> tab2list;
/*      */   private List<UserAccinfo> listAccinfo;
/*      */   private List<UserAccinfoDetail> listAccinfoDetail;
/*      */   private List<Debitinfo> listDebitinfo;
/*      */   private List<PointInfo> listPointInfo;
/*      */   private List<Foldout> list;
/*      */   private List<TempArea> plist;
/*      */   private List<RuleF> rlist;
/*      */   private List<RuleF> dlist;
/*      */   private List<RuleM> mlist;
/*      */   private List<Rule> rulelist;
/*      */   private PointInfo point;
/*      */   private UserBuy ub;
/*   38 */   private Logger log = null;
/*      */ 
/*  302 */   private StringBuffer type1 = new StringBuffer();
/*  303 */   private StringBuffer type2 = new StringBuffer();
/*  304 */   private StringBuffer type3 = new StringBuffer();
/*  305 */   private StringBuffer type4 = new StringBuffer();
/*      */ 
/*  494 */   private String cardid = "";
/*      */ 
/*      */   public UserXml()
/*      */   {
/*   41 */     this.log = Logger.getLogger(UserXml.class);
/*      */   }
/*      */ 
/*      */   public void writeBaseXml(UserBase ub, StringBuffer xml)
/*      */   {
/*   50 */     xml.append("<acctnbr>" + ub.getAcctnbr() + "</acctnbr>\n");
/*   51 */     xml.append("<rectype>" + ub.getRectype() + "</rectype>\n");
/*   52 */     xml.append("<zip>" + ub.getZip() + "</zip>\n");
/*   53 */     xml.append("<addrname3>" + ub.getAddrname3() + " </addrname3>\n");
/*   54 */     xml.append("<addrname1>" + ub.getAddrname1() + " </addrname1>\n");
/*   55 */     xml.append("<addrname2>" + ub.getAddrname2() + " </addrname2>\n");
/*   56 */     xml.append("<name>" + ub.getName() + " </name>\n");
/*   57 */     xml.append("<sex>" + ub.getSex() + "</sex>\n");
/*   58 */     xml.append("<birthday>" + ub.getBirthday() + "</birthday>\n");
/*   59 */     xml.append("<accnum>" + ub.getAccnum() + "</accnum>\n");
/*   60 */     xml.append("<cusnum>" + ub.getCusnum() + "</cusnum>\n");
/*   61 */     xml.append("<stfromdate>" + ub.getStfromdate() + "</stfromdate>\n");
/*   62 */     xml.append("<enddate>" + ub.getEnddate() + "</enddate>\n");
/*   63 */     xml.append("<specode>" + ub.getSpecode() + "</specode>\n");
/*   64 */     xml.append("<pmtduemark>" + ub.getPmtduemark() + "</pmtduemark>\n");
/*   65 */     xml.append("<cashmark>" + ub.getCashmark() + "</cashmark>\n");
/*   66 */     xml.append("<indiv1>" + ub.getIndiv1() + "</indiv1>\n");
/*   67 */     xml.append("<indiv2>" + ub.getIndiv2() + "</indiv2>\n");
/*   68 */     xml.append("<indiv3>" + ub.getIndiv3() + "</indiv3>\n");
/*   69 */     xml.append("<indiv4>" + ub.getIndiv4() + "</indiv4>\n");
/*   70 */     xml.append("<indiv5>" + ub.getIndiv5() + "</indiv5>\n");
/*   71 */     xml.append("<indiv6>" + ub.getIndiv6() + "</indiv6>\n");
/*   72 */     xml.append("<indiv7>" + ub.getIndiv7() + "</indiv7>\n");
/*   73 */     xml.append("<indiv8>" + ub.getIndiv8() + "</indiv8>\n");
/*   74 */     xml.append("<actinfo>" + ub.getActinfo() + "</actinfo>\n");
/*   75 */     xml.append("<dm1>" + ub.getDm1() + "</dm1>\n");
/*   76 */     xml.append("<dm2>" + ub.getDm2() + "</dm2>\n");
/*   77 */     xml.append("<dm3>" + ub.getDm3() + "</dm3>\n");
/*   78 */     xml.append("<dm4>" + ub.getDm4() + "</dm4>\n");
/*   79 */     xml.append("<brandmsg1>" + ub.getBrandmsg1() + "</brandmsg1>\n");
/*   80 */     xml.append("<brandmsg2>" + ub.getBrandmsg2() + "</brandmsg2>\n");
/*   81 */     xml.append("<brandmsg3>" + ub.getBrandmsg3() + "</brandmsg3>\n");
/*   82 */     xml.append("<brandmsg4>" + ub.getBrandmsg4() + "</brandmsg4>\n");
/*   83 */     xml.append("<brandmsg5>" + ub.getBrandmsg5() + "</brandmsg5>\n");
/*   84 */     xml.append("<brandmsg6>" + ub.getBrandmsg6() + "</brandmsg6>\n");
/*   85 */     xml.append("<brandmsg7>" + ub.getBrandmsg7() + "</brandmsg7>\n");
/*   86 */     xml.append("<convexchmark>" + ub.getConvexchmark() + "</convexchmark>\n");
/*   87 */     xml.append("<vipmsg1>" + ub.getVipmsg1() + "</vipmsg1>\n");
/*   88 */     xml.append("<vipmsg2>" + ub.getVipmsg2() + "</vipmsg2>\n");
/*   89 */     xml.append("<vipmsg3>" + ub.getVipmsg3() + "</vipmsg3>\n");
/*   90 */     xml.append("<vipmsg4>" + ub.getVipmsg4() + "</vipmsg4>\n");
/*   91 */     xml.append("<reprintflag>" + ub.getReprintflag() + "</reprintflag>\n");
/*   92 */     xml.append("<emailflag>" + ub.getEmailflag() + "</emailflag>\n");
/*   93 */     xml.append("<paperflag>" + ub.getPaperflag() + "</paperflag>\n");
/*   94 */     xml.append("<emailaddr>" + ub.getEmailaddr() + "</emailaddr>\n");
/*   95 */     xml.append("<custtype>" + ub.getCusttype() + "</custtype>\n");
/*   96 */     xml.append("<mobilenbr>" + ub.getMobilenbr() + "</mobilenbr>\n");
/*   97 */     xml.append("<ainbr>" + ub.getAinbr() + "</ainbr>\n");
/*   98 */     xml.append("<mobdate>" + ub.getMobdate() + "</mobdate>\n");
/*   99 */     xml.append("<filler>" + ub.getFiller() + "</filler>\n");
/*  100 */     xml.append("<citycode>" + ub.getCity() + "</citycode>\n");
/*      */   }
/*      */ 
/*      */   public void writeEnvrule(String wbs, UserBase ub, StringBuffer xml)
/*      */   {
/*  109 */     this.list = Cache.getFoldout(wbs, ub.getCardNo());
/*  110 */     String tag = "";
/*  111 */     String temp = "";
/*  112 */     Foldout f = null;
/*  113 */     if (this.list.size() > 0) {
/*  114 */       for (int i = 0; i < this.list.size(); i++) {
/*  115 */         f = (Foldout)this.list.get(i);
/*      */ 
/*  117 */         if ("0".equals(f.getState())) {
/*  118 */           tag = tag + "0";
/*  119 */           temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */         }
/*  121 */         else if ("1".equals(f.getState())) {
/*  122 */           switch (i) {
/*      */           case 0:
/*  124 */             if ("Y".equals(ub.getDm1())) {
/*  125 */               tag = tag + "1";
/*  126 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*      */             } else {
/*  128 */               tag = tag + "0";
/*  129 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */             }
/*  131 */             break;
/*      */           case 1:
/*  133 */             if ("Y".equals(ub.getDm2())) {
/*  134 */               tag = tag + "1";
/*  135 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*      */             } else {
/*  137 */               tag = tag + "0";
/*  138 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */             }
/*  140 */             break;
/*      */           case 2:
/*  142 */             if ("Y".equals(ub.getDm3())) {
/*  143 */               tag = tag + "1";
/*  144 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*      */             } else {
/*  146 */               tag = tag + "0";
/*  147 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */             }
/*  149 */             break;
/*      */           case 3:
/*  151 */             if ("Y".equals(ub.getDm4())) {
/*  152 */               tag = tag + "1";
/*  153 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*      */             } else {
/*  155 */               tag = tag + "0";
/*  156 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */             }
/*  158 */             break;
/*      */           default:
/*  160 */             tag = tag + "0";
/*  161 */             temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*  162 */             break;
/*      */           }
/*      */         }
/*  165 */         else if ("2".equals(f.getState())) {
/*  166 */           Map city = Cache.getFoldoutCity(f.getId(), f.getIdx());
/*  167 */           if (city.containsKey(ub.getCity())) {
/*  168 */             tag = tag + "1";
/*  169 */             temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*      */           } else {
/*  171 */             tag = tag + "0";
/*  172 */             temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */           }
/*      */         } else {
/*  175 */           tag = tag + "0";
/*  176 */           temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */         }
/*      */       }
/*      */     } else {
/*  180 */       tag = "0000";
/*  181 */       temp = "<INPRIORITY1>0</INPRIORITY1>\n<INPRIORITY2>0</INPRIORITY2>\n<INPRIORITY3>0</INPRIORITY3>\n<INPRIORITY4>0</INPRIORITY4>\n";
/*      */     }
/*  183 */     xml.append("<ENVRULE>" + tag + "</ENVRULE>\n");
/*  184 */     xml.append(temp);
/*      */   }
/*      */ 
/*      */   public boolean writeAccinfoXml(UserBase ub, StringBuffer xml)
/*      */   {
/*  192 */     this.tab1 = new StringBuffer();
/*  193 */     this.tab2 = new StringBuffer();
/*      */ 
/*  195 */     this.listAccinfo = Cache.getUserInfo(ub);
/*      */ 
/*  197 */     for (UserAccinfo ua : this.listAccinfo)
/*      */     {
/*  199 */       if ("B001".equals(ua.getRectype())) {
/*  200 */         readAccinfo(this.tab1, ua);
/*      */       }
/*  202 */       else if ("D001".equals(ua.getRectype())) {
/*  203 */         readAccinfo(this.tab2, ua);
/*      */       }
/*      */     }
/*      */ 
/*  207 */     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
/*  208 */       xml.append("<accinfo>\n");
/*  209 */       if (this.tab1.length() > 0) {
/*  210 */         xml.append("<tab1>\n");
/*  211 */         xml.append(this.tab1.toString());
/*  212 */         xml.append("</tab1>\n");
/*      */       }
/*  214 */       if (this.tab2.length() > 0) {
/*  215 */         xml.append("<tab2>\n");
/*  216 */         xml.append(this.tab2.toString());
/*  217 */         xml.append("</tab2>\n");
/*      */       }
/*  219 */       xml.append("</accinfo>\n");
/*  220 */       return false;
/*      */     }
/*  222 */     return true;
/*      */   }
/*      */ 
/*      */   private void readAccinfo(StringBuffer sb, UserAccinfo ua) {
/*  226 */     sb.append("<acctnbr>" + ua.getAcctnbr() + "</acctnbr>\n");
/*  227 */     sb.append("<rectype>" + ua.getRectype() + "</rectype>\n");
/*  228 */     sb.append("<stmtdate>" + ua.getStmtdate() + "</stmtdate>\n");
/*  229 */     sb.append("<pmtdate>" + ua.getPmtdate() + "</pmtdate>\n");
/*  230 */     sb.append("<totbegbal>" + ua.getTotbegbal() + "</totbegbal>\n");
/*  231 */     sb.append("<plantotpmt>" + ua.getPlantotpmt() + "</plantotpmt>\n");
/*  232 */     sb.append("<plantotnrlamt>" + ua.getPlantotnrlamt() + "</plantotnrlamt>\n");
/*  233 */     sb.append("<plantotadjamt>" + ua.getPlantotadjamt() + "</plantotadjamt>\n");
/*  234 */     sb.append("<intdueamt>" + ua.getIntdueamt() + "</intdueamt>\n");
/*  235 */     sb.append("<currbal>" + ua.getCurrbal() + "</currbal>\n");
/*  236 */     sb.append("<totdueamt>" + ua.getTotdueamt() + "</totdueamt>\n");
/*  237 */     sb.append("<pmtprint>" + ua.getPmtprint() + "</pmtprint>\n");
/*  238 */     sb.append("<crlim>" + ua.getCrlim() + "</crlim>\n");
/*  239 */     sb.append("<cashcrlim>" + ua.getCashcrlim() + "</cashcrlim>\n");
/*  240 */     sb.append("<pmtarn>" + ua.getPmtarn() + "</pmtarn>\n");
/*  241 */     sb.append("<pmtadn>" + ua.getPmtadn() + "</pmtadn>\n");
/*  242 */     sb.append("<projap>" + ua.getProjap() + "</projap>\n");
/*  243 */     sb.append("<pmtaflag>" + ua.getPmtaflag() + "</pmtaflag>\n");
/*  244 */     sb.append("<achflag>" + ua.getAchflag() + "</achflag>\n");
/*  245 */     sb.append("<pmtflag>" + ua.getPmtflag() + "</pmtflag>\n");
/*  246 */     sb.append("<filler>" + ua.getFiller() + "</filler>\n");
/*      */   }
/*      */ 
/*      */   public void writeAccinfoDetail(UserBase ub, StringBuffer xml)
/*      */   {
/*  313 */     this.tab1 = new StringBuffer();
/*  314 */     this.tab2 = new StringBuffer();
/*      */ 
/*  316 */     this.type1 = new StringBuffer();
/*  317 */     this.type2 = new StringBuffer();
/*  318 */     this.type3 = new StringBuffer();
/*  319 */     this.type4 = new StringBuffer();
/*      */ 
/*  321 */     String type = "";
/*      */ 
/*  323 */     this.listAccinfoDetail = Cache.getAccinfoDetail(ub);
/*  324 */     for (UserAccinfoDetail uad : this.listAccinfoDetail)
/*      */     {
/*  327 */       if ("".equals(uad.getMcc()))
/*  328 */         uad.setMcc("00000");
/*  329 */       else if (!Cache.mccmap.containsKey(uad.getMcc())) {
/*  330 */         uad.setMcc("00000");
/*      */       }
/*      */ 
/*  334 */       if ("C001".equals(uad.getRectype())) {
/*  335 */         if ("".equals(type)) {
/*  336 */           type = "C001";
/*      */         }
/*  338 */         readAccinfoDetail1(uad);
/*      */       }
/*  352 */       else if ("E001".equals(uad.getRectype())) {
/*  353 */         if ("C001".equals(type)) {
/*  354 */           if (this.type1.length() > 0) {
/*  355 */             this.tab1.append(this.type1)
/*  356 */               .append("</card>\n</lists>\n</type1>\n");
/*      */           }
/*  358 */           if (this.type2.length() > 0) {
/*  359 */             this.tab1.append(this.type2)
/*  360 */               .append("</card>\n</user>\n</lists>\n</type2>\n");
/*      */           }
/*  362 */           if (this.type3.length() > 0) {
/*  363 */             this.tab1.append(this.type3)
/*  364 */               .append("</lists>\n</type3>\n");
/*      */           }
/*  366 */           if (this.type4.length() > 0) {
/*  367 */             this.tab1.append(this.type4)
/*  368 */               .append("</lists>\n</type4>\n");
/*      */           }
/*      */         }
/*  371 */         if (("".equals(type)) || ("C001".equals(type))) {
/*  372 */           type = "E001";
/*  373 */           this.type1 = new StringBuffer();
/*  374 */           this.type2 = new StringBuffer();
/*  375 */           this.type3 = new StringBuffer();
/*  376 */           this.type4 = new StringBuffer();
/*      */         }
/*      */ 
/*  379 */         readAccinfoDetail1(uad);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  392 */     if ("C001".equals(type)) {
/*  393 */       if (this.type1.length() != 0) {
/*  394 */         this.tab1.append(this.type1)
/*  395 */           .append("</card>\n</lists>\n</type1>\n");
/*      */       }
/*  397 */       if (this.type2.length() != 0) {
/*  398 */         this.tab1.append(this.type2)
/*  399 */           .append("</card>\n</user>\n</lists>\n</type2>\n");
/*      */       }
/*  401 */       if (this.type3.length() != 0) {
/*  402 */         this.tab1.append(this.type3)
/*  403 */           .append("</lists>\n</type3>\n");
/*      */       }
/*  405 */       if (this.type4.length() != 0) {
/*  406 */         this.tab1.append(this.type4)
/*  407 */           .append("</lists>\n</type4>\n");
/*      */       }
/*      */     }
/*  410 */     else if ("E001".equals(type)) {
/*  411 */       if (this.type1.length() != 0) {
/*  412 */         this.tab2.append(this.type1)
/*  413 */           .append("</card>\n</lists>\n</type1>\n");
/*      */       }
/*  415 */       if (this.type2.length() != 0) {
/*  416 */         this.tab2.append(this.type2)
/*  417 */           .append("</card>\n</user>\n</lists>\n</type2>\n");
/*      */       }
/*  419 */       if (this.type3.length() != 0) {
/*  420 */         this.tab2.append(this.type3)
/*  421 */           .append("</lists>\n</type3>\n");
/*      */       }
/*  423 */       if (this.type4.length() != 0) {
/*  424 */         this.tab2.append(this.type4)
/*  425 */           .append("</lists>\n</type4>\n");
/*      */       }
/*      */     }
/*      */ 
/*  429 */     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
/*  430 */       xml.append("<transinfo>\n");
/*  431 */       if (this.tab1.length() > 0) {
/*  432 */         xml.append("<tab1>");
/*  433 */         xml.append(this.tab1.toString());
/*  434 */         xml.append("</tab1>\n");
/*      */       }
/*  436 */       if (this.tab2.length() > 0) {
/*  437 */         xml.append("<tab2>\n");
/*  438 */         xml.append(this.tab2.toString());
/*  439 */         xml.append("</tab2>\n");
/*      */       }
/*  441 */       xml.append("</transinfo>\n");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void readAccinfoDetail2(StringBuffer sb, UserAccinfoDetail uad)
/*      */   {
/*  451 */     sb.append("<list>\n");
/*  452 */     sb.append("<acctnbr>" + uad.getAcctnbr() + "</acctnbr>\n");
/*  453 */     sb.append("<rectype>" + uad.getRectype() + "</rectype>\n");
/*  454 */     sb.append("<recseq>" + uad.getRecseq() + "</recseq>\n");
/*  455 */     sb.append("<effdate>" + uad.getEffdate() + "</effdate>\n");
/*  456 */     sb.append("<postdate>" + uad.getPostdate() + "</postdate>\n");
/*      */ 
/*  458 */     sb.append("<desc>" + uad.getDesc() + "</desc>\n");
/*  459 */     sb.append("<txnamt>" + uad.getTxnamt() + "</txnamt>\n");
/*  460 */     sb.append("<srctamt>" + uad.getSrctamt() + "</srctamt>\n");
/*  461 */     sb.append("<srctcurr>" + uad.getSrctcurr() + "</srctcurr>\n");
/*  462 */     sb.append("<purcty>" + uad.getPurcty() + "</purcty>\n");
/*  463 */     sb.append("<filler>" + uad.getFiller() + "</filler>\n");
/*  464 */     sb.append("<mccid>" + uad.getMcc() + "</mccid>\n");
/*  465 */     sb.append("<mccmname></mccmname>\n");
/*  466 */     sb.append("<mccsname></mccsname>\n");
/*  467 */     sb.append("</list>\n");
/*      */   }
/*      */ 
/*      */   private void readAccinfoDetail3(StringBuffer sb, UserAccinfoDetail uad)
/*      */   {
/*  476 */     sb.append("<list>\n");
/*  477 */     sb.append("<acctnbr>" + uad.getAcctnbr() + "</acctnbr>\n");
/*  478 */     sb.append("<rectype>" + uad.getRectype() + "</rectype>\n");
/*  479 */     sb.append("<recseq>" + uad.getRecseq() + "</recseq>\n");
/*  480 */     sb.append("<effdate>" + uad.getEffdate() + "</effdate>\n");
/*  481 */     sb.append("<postdate>" + uad.getPostdate() + "</postdate>\n");
/*  482 */     sb.append("<desc>" + uad.getDesc() + "</desc>\n");
/*  483 */     sb.append("<txnamt>" + uad.getTxnamt() + "</txnamt>\n");
/*  484 */     sb.append("<srctamt>" + uad.getSrctamt() + "</srctamt>\n");
/*  485 */     sb.append("<srctcurr>" + uad.getSrctcurr() + "</srctcurr>\n");
/*  486 */     sb.append("<purcty>" + uad.getPurcty() + "</purcty>\n");
/*  487 */     sb.append("<filler>" + uad.getFiller() + "</filler>\n");
/*  488 */     sb.append("<cardlast4>").append(uad.getCardnlast4()).append("</cardlast4>\n");
/*  489 */     sb.append("<mccid>" + uad.getMcc() + "</mccid>\n");
/*  490 */     sb.append("<mccmname></mccmname>\n");
/*  491 */     sb.append("<mccsname></mccsname>\n");
/*  492 */     sb.append("</list>\n");
/*      */   }
/*      */ 
/*      */   private void readAccinfoDetail1(UserAccinfoDetail uad)
/*      */   {
/*  497 */     if (Cache.fqjyCard.containsKey(uad.getTxnCode())) {
/*  498 */       if (this.type3.length() == 0) {
/*  499 */         this.type3.append("<type3>\n")
/*  500 */           .append("<lists>\n");
/*      */       }
/*  502 */       readAccinfoDetail3(this.type3, uad);
/*      */     }
/*  504 */     else if (("".equals(uad.getCardNbr())) || (uad.getCardNbr().startsWith("000299"))) {
/*  505 */       if (this.type4.length() == 0) {
/*  506 */         this.type4.append("<type4>\n").append("<lists>\n");
/*      */       }
/*  508 */       readAccinfoDetail3(this.type4, uad);
/*      */     }
/*  511 */     else if ("0".equals(uad.getMainAccount()))
/*      */     {
/*  513 */       if (this.type1.length() == 0) {
/*  514 */         this.type1.append("<type1>\n<lists>\n<card>\n<cname>")
/*  515 */           .append(uad.getCardName())
/*  516 */           .append("</cname>\n<last4>")
/*  517 */           .append(uad.getCardnlast4())
/*  518 */           .append("</last4>\n");
/*  519 */         this.cardid = uad.getCardNbr();
/*      */       }
/*  521 */       else if (!this.cardid.equals(uad.getCardNbr())) {
/*  522 */         this.type1.append("</card>\n<card>\n<cname>")
/*  523 */           .append(uad.getCardName())
/*  524 */           .append("</cname>\n<last4>")
/*  525 */           .append(uad.getCardnlast4())
/*  526 */           .append("</last4>\n");
/*  527 */         this.cardid = uad.getCardNbr();
/*      */       }
/*  529 */       readAccinfoDetail2(this.type1, uad);
/*      */     }
/*  531 */     else if ("1".equals(uad.getMainAccount()))
/*      */     {
/*  533 */       if (this.type2.length() == 0) {
/*  534 */         this.type2.append("<type2>\n<lists>\n<user>\n<user>")
/*  535 */           .append(uad.getCnName())
/*  536 */           .append("</user>\n<ename>")
/*  537 */           .append(uad.getPyName())
/*  538 */           .append("</ename>\n<card>\n<cname>")
/*  539 */           .append(uad.getCardName())
/*  540 */           .append("</cname>\n<last4>")
/*  541 */           .append(uad.getCardnlast4())
/*  542 */           .append("</last4>\n");
/*  543 */         this.cardid = uad.getCardNbr();
/*      */       }
/*  545 */       else if (!this.cardid.equals(uad.getCardNbr())) {
/*  546 */         this.type2.append("</card>\n</user>\n<user>\n")
/*  547 */           .append("<user>")
/*  548 */           .append(uad.getCnName())
/*  549 */           .append("</user>\n<ename>")
/*  550 */           .append(uad.getPyName())
/*  551 */           .append("</ename>\n<card>\n<cname>")
/*  552 */           .append(uad.getCardName())
/*  553 */           .append("</cname>\n<last4>")
/*  554 */           .append(uad.getCardnlast4())
/*  555 */           .append("</last4>\n");
/*  556 */         this.cardid = uad.getCardNbr();
/*      */       }
/*  558 */       readAccinfoDetail2(this.type2, uad);
/*      */     } else {
/*  560 */       if (this.type4.length() == 0) {
/*  561 */         this.type4.append("<type4>\n").append("<lists>\n");
/*      */       }
/*  563 */       readAccinfoDetail3(this.type4, uad);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void writeBuy(UserBase user, StringBuffer xml)
/*      */   {
/*  573 */     this.ub = Cache.getUserBuy(user);
/*      */ 
/*  575 */     if (this.ub == null) return;
/*  576 */     xml.append("<exchinfo>\n");
/*  577 */     xml.append("<acctnbr>" + this.ub.getAcctnbr() + "</acctnbr>\n");
/*  578 */     xml.append("<rectype>" + this.ub.getRectype() + "</rectype>\n");
/*  579 */     xml.append("<exchusdamt>" + this.ub.getExchusdamt() + "</exchusdamt>\n");
/*  580 */     xml.append("<sellrate>" + this.ub.getSellrate() + "</sellrate>\n");
/*  581 */     xml.append("<exchrmbamt>" + this.ub.getExchrmbamt() + "</exchrmbamt>\n");
/*  582 */     xml.append("<achrtnbr>" + this.ub.getAchrtnbr() + "</achrtnbr>\n");
/*  583 */     xml.append("<achdbnbr>" + this.ub.getAchdbnbr() + "</achdbnbr>\n");
/*  584 */     xml.append("<filler>" + this.ub.getFiller() + "</filler>\n");
/*  585 */     xml.append("</exchinfo>\n");
/*      */   }
/*      */ 
/*      */   public void writeDebitinfo(UserBase user, StringBuffer xml)
/*      */   {
/*  594 */     this.tab1 = new StringBuffer();
/*  595 */     this.tab2 = new StringBuffer();
/*  596 */     this.listDebitinfo = Cache.getDebitinfo(user);
/*  597 */     for (Debitinfo di : this.listDebitinfo) {
/*  598 */       if ("C002".equals(di.getRectype()))
/*  599 */         readDebitinfo(this.tab1, di);
/*  600 */       else if ("E002".equals(di.getRectype())) {
/*  601 */         readDebitinfo(this.tab2, di);
/*      */       }
/*      */     }
/*      */ 
/*  605 */     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
/*  606 */       xml.append("<debitinfo>\n");
/*  607 */       if (this.tab1.length() > 0) {
/*  608 */         xml.append("<tab1>\n<lists>\n");
/*  609 */         xml.append(this.tab1.toString());
/*  610 */         xml.append("</lists>\n</tab1>\n");
/*      */       }
/*  612 */       if (this.tab2.length() > 0) {
/*  613 */         xml.append("<tab2>\n<lists>\n");
/*  614 */         xml.append(this.tab2.toString());
/*  615 */         xml.append("</lists>\n</tab2>\n");
/*      */       }
/*  617 */       xml.append("</debitinfo>\n");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void readDebitinfo(StringBuffer temp, Debitinfo di) {
/*  622 */     temp.append("<list>\n");
/*  623 */     temp.append("<acctnbr>" + di.getAcctnbr() + "</acctnbr>\n");
/*  624 */     temp.append("<rectype>" + di.getRectype() + "</rectype>\n");
/*  625 */     temp.append("<custnbr>" + di.getCustnbr() + "</custnbr>\n");
/*  626 */     temp.append("<effdate>" + di.getEffdate() + "</effdate>\n");
/*  627 */     temp.append("<txndesc>" + di.getTxndesc() + "</txndesc>\n");
/*  628 */     temp.append("<txncity>" + di.getTxncity() + "</txncity>\n");
/*  629 */     temp.append("<currcode>" + di.getCurrcode() + "</currcode>\n");
/*  630 */     temp.append("<txnamt>" + di.getTxnamt() + "</txnamt>\n");
/*  631 */     temp.append("<cardl4>" + di.getCardl4() + "</cardl4>\n");
/*  632 */     temp.append("<filler>" + di.getFiller() + "</filler>\n");
/*  633 */     temp.append("</list>\n");
/*      */   }
/*      */ 
/*      */   public void writePoint(UserBase user, StringBuffer xml)
/*      */   {
/*  646 */     this.tab1 = new StringBuffer();
/*  647 */     this.tab2list = new ArrayList();
/*  648 */     this.temp = new StringBuffer();
/*      */ 
/*  650 */     this.listPointInfo = Cache.getPoint(user);
/*      */ 
/*  652 */     this.point = Cache.getPoint2(user);
/*  653 */     for (PointInfo pi : this.listPointInfo)
/*      */     {
/*  655 */       if ("3".equals(pi.getPointtype())) {
/*  656 */         readPoint(this.tab1, pi);
/*  657 */       } else if ("2".equals(pi.getPointtype())) {
/*  658 */         this.tab2 = new StringBuffer();
/*  659 */         readPoint(this.tab2, pi);
/*  660 */         this.tab2list.add(this.tab2);
/*  661 */       } else if ("4".equals(pi.getPointtype())) {
/*  662 */         if (this.point == null) {
/*  663 */           this.point = new PointInfo();
/*  664 */           this.point.setBilldate(user.getStmtdate());
/*  665 */           this.point.setBusinessid(user.getCusnum().substring(7));
/*  666 */           this.point.setAblepoint("0");
/*  667 */           this.point.setExpirespoint("0");
/*      */         }
/*  669 */         this.point.setAddpoint(pi.getAddpoint());
/*  670 */         this.point.setAdpoints(pi.getAdpoints());
/*      */       }
/*      */     }
/*  673 */     if (this.point != null) {
/*  674 */       this.temp.append("<tab3>\n");
/*  675 */       this.temp.append("<billdate>" + this.point.getBilldate() + "</billdate>\n");
/*  676 */       this.temp.append("<ecifno>" + this.point.getBusinessid() + "</ecifno>\n");
/*  677 */       this.temp.append("<curpavalia>" + this.point.getAblepoint() + "</curpavalia>\n");
/*  678 */       this.temp.append("<pointavabf>" + this.point.getLastbalpoint() + "</pointavabf>\n");
/*  679 */       this.temp.append("<newpoint>" + this.point.getAddpoint() + "</newpoint>\n");
/*  680 */       this.temp.append("<pointredee>" + this.point.getExpoint() + "</pointredee>\n");
/*  681 */       this.temp.append("<adpoints>" + this.point.getAdpoints() + "</adpoints>\n");
/*  682 */       this.temp.append("<invalidpoint>" + this.point.getEndpoints() + "</invalidpoint>\n");
/*  683 */       this.temp.append("<expirespoint></expirespoint>\n");
/*  684 */       this.temp.append("</tab3>\n");
/*      */     }
/*      */ 
/*  687 */     if ((this.tab1.length() > 0) || (this.tab2list.size() > 0) || (this.temp.length() > 0)) {
/*  688 */       xml.append("<point-info>\n");
/*  689 */       if (this.tab1.length() > 0) {
/*  690 */         xml.append("<tab1>\n");
/*  691 */         xml.append(this.tab1.toString());
/*  692 */         xml.append("</tab1>\n");
/*      */       }
/*  694 */       if (this.tab2list.size() > 0) {
/*  695 */         xml.append("<tab2>\n<lists>\n");
/*  696 */         for (StringBuffer sb : this.tab2list) {
/*  697 */           xml.append("<list>\n" + sb.toString() + "</list>\n");
/*      */         }
/*  699 */         xml.append("</lists>\n</tab2>\n");
/*      */       }
/*  701 */       if (this.temp.length() > 0) {
/*  702 */         xml.append(this.temp.toString());
/*      */       }
/*  704 */       xml.append("</point-info>\n");
/*      */     }
/*      */   }
/*      */ 
/*  708 */   private void readPoint(StringBuffer sb, PointInfo pi) { if ((pi.getCardPointType() == null) || ("".equals(pi.getCardPointType())) || 
/*  709 */       ("0".equals(pi.getCardPointType()))) {
/*  710 */       sb.append("<pointtype>" + pi.getPointtype() + "</pointtype>\n");
/*      */     }
/*  713 */     else if ("1".equals(pi.getCardPointType()))
/*  714 */       sb.append("<pointtype>A</pointtype>\n");
/*  715 */     else if ("2".equals(pi.getCardPointType())) {
/*  716 */       sb.append("<pointtype>B</pointtype>\n");
/*      */     }
/*      */ 
/*  719 */     sb.append("<cardportid>" + pi.getCardportid() + "</cardportid>\n");
/*  720 */     sb.append("<businessid>" + pi.getBusinessid() + "</businessid>\n");
/*  721 */     sb.append("<ablepoint>" + pi.getAblepoint() + "</ablepoint>\n");
/*  722 */     sb.append("<lastbalpoint>" + pi.getLastbalpoint() + "</lastbalpoint>\n");
/*  723 */     sb.append("<addpoint>" + pi.getAddpoint() + "</addpoint>\n");
/*  724 */     sb.append("<expoint>" + pi.getExpoint() + "</expoint>\n");
/*  725 */     sb.append("<adpoints>" + pi.getAdpoints() + "</adpoints>\n");
/*  726 */     sb.append("<endpoints>" + pi.getEndpoints() + "</endpoints>\n");
/*  727 */     sb.append("<ecifno>" + pi.getEcifno() + "</ecifno>\n");
/*  728 */     sb.append("<startdate>" + pi.getStartdate() + "</startdate>\n");
/*  729 */     sb.append("<enddate>" + pi.getEnddate() + "</enddate>\n");
/*  730 */     sb.append("<wholeconsume>" + pi.getWholeconsume() + "</wholeconsume>\n");
/*  731 */     sb.append("<inconsume>" + pi.getInconsume() + "</inconsume>\n");
/*  732 */     sb.append("<outconsume>" + pi.getOutconsume() + "</outconsume>\n");
/*  733 */     sb.append("<wholemoney>" + pi.getWholemoney() + "</wholemoney>\n");
/*  734 */     sb.append("<inmoney>" + pi.getInmoney() + "</inmoney>\n");
/*  735 */     sb.append("<outmoney>" + pi.getOutmoney() + "</outmoney>\n");
/*  736 */     sb.append("<usedmoney>" + pi.getUsedmoney() + "</usedmoney>\n");
/*  737 */     sb.append("<lavemoney>" + pi.getLavemoney() + "</lavemoney>\n");
/*  738 */     sb.append("<validdate>" + pi.getValiddate() + "</validdate>\n");
/*  739 */     sb.append("<laddermoney>" + pi.getLaddermoney() + "</laddermoney>\n");
/*  740 */     sb.append("<ladderscale>" + pi.getLadderscale() + "</ladderscale>\n");
/*  741 */     if ("2".equals(pi.getPointtype())) {
/*  742 */       sb.append("<card4>" + pi.getCard4() + "</card4>\n");
/*      */     }
/*  744 */     sb.append("<cardname>" + pi.getCardname() + "</cardname>\n");
/*      */   }
/*      */ 
/*      */   public StringBuffer writeTemplate(UserBase user, String type)
/*      */   {
/*  754 */     this.temp = new StringBuffer();
/*      */ 
/*  756 */     String ptId = (String)Cache.templateMap.get(user.getCardNo() + "_" + type);
/*      */ 
/*  758 */     this.plist = Cache.getTemplateInfo(ptId);
/*      */ 
/*  760 */     Fodder f = null;
/*      */ 
/*  762 */     boolean isExtis = false;
/*      */ 
/*  764 */     int idx = 1;
/*  765 */     this.temp.append("<resourcesinfo>\n<lists>\n");
/*      */ 
/*  767 */     for (TempArea ta : this.plist) {
/*  768 */       isExtis = false;
/*  769 */       idx = 1;
/*      */ 
/*  771 */       this.rulelist = Cache.getRuleMap(ptId, "1", ta.getArea());
/*      */ 
/*  773 */       if ((this.rulelist != null) && (this.rulelist.size() > 0))
/*      */       {
/*  775 */         for (Rule r : this.rulelist)
/*      */         {
/*  777 */           if (isExtis)
/*      */           {
/*      */             break;
/*      */           }
/*  781 */           this.rlist = Cache.getRuleFMap(r.getRuleid());
/*  782 */           if (this.rlist != null)
/*      */           {
/*  784 */             for (RuleF rf : this.rlist)
/*      */             {
/*  786 */               f = Cache.getFodder(rf.getFodder());
/*      */ 
/*  788 */               if (f != null)
/*      */               {
/*  790 */                 if ("3".equals(ta.getType())) {
/*  791 */                   isExtis = true;
/*  792 */                   readRuleXml(this.temp, type, ta.getArea(), Integer.valueOf(idx), f.getUrl(), f.getLinkurl());
/*  793 */                   idx++;
/*      */                 }
/*      */                 else
/*      */                 {
/*  797 */                   this.mlist = Cache.getRuleFFList(rf.getId());
/*      */ 
/*  799 */                   if ((this.mlist == null) || (this.mlist.size() == 0) || (readRule(this.mlist, user))) {
/*  800 */                     isExtis = true;
/*      */ 
/*  802 */                     if ("4".equals(ta.getType()))
/*      */                     {
/*  804 */                       readRuleXml(this.temp, type, ta.getArea(), Integer.valueOf(idx), f.getUrl(), f.getLinkurl());
/*  805 */                       idx++;
/*      */                     }
/*      */                     else {
/*  808 */                       readRuleXml(this.temp, type, ta.getArea(), rf.getPri(), f.getUrl(), f.getLinkurl());
/*      */ 
/*  810 */                       break;
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*  819 */       if (!isExtis) {
/*  820 */         this.rulelist = Cache.getRuleMap(ptId, "0", ta.getArea());
/*  821 */         if ((this.rulelist != null) && (this.rulelist.size() > 0))
/*      */         {
/*  823 */           this.dlist = Cache.getRuleFMap(((Rule)this.rulelist.get(0)).getRuleid());
/*  824 */           if ((this.dlist != null) && (this.dlist.size() > 0)) {
/*  825 */             idx = 1;
/*  826 */             for (RuleF rf : this.dlist)
/*      */             {
/*  828 */               f = Cache.getFodder(rf.getFodder());
/*      */ 
/*  830 */               if (f == null) {
/*  831 */                 this.log.error("没有默认规则的素材！模板=" + ptId + ",区域=" + ta.getArea() + ",素材=" + rf.getFodder());
/*      */               }
/*  834 */               else if (("3".equals(ta.getType())) || ("4".equals(ta.getType())))
/*      */               {
/*  836 */                 readRuleXml(this.temp, type, ta.getArea(), Integer.valueOf(idx), f.getUrl(), f.getLinkurl());
/*  837 */                 idx++;
/*      */               } else {
/*  839 */                 readRuleXml(this.temp, type, ta.getArea(), rf.getPri(), f.getUrl(), f.getLinkurl());
/*  840 */                 break;
/*      */               }
/*      */             }
/*      */           } else {
/*  844 */             this.log.debug("没有默认的规则！模板=" + ptId + ",区域=" + ta.getArea());
/*      */           }
/*      */         }
/*      */       }
/*  848 */       isExtis = false;
/*      */     }
/*  850 */     this.temp.append("</lists>\n</resourcesinfo>\n");
/*  851 */     return this.temp;
/*      */   }
/*      */ 
/*      */   public void readRuleXml(StringBuffer xml, String type, String area, Object pri, String url, String link)
/*      */   {
/*  864 */     xml.append("<list>\n<billtype>");
/*  865 */     xml.append(type);
/*  866 */     xml.append("</billtype>\n<area>");
/*  867 */     xml.append(area);
/*  868 */     xml.append("</area>\n<priority>");
/*  869 */     xml.append(pri);
/*  870 */     xml.append("</priority>\n<rescontent>");
/*  871 */     if ("1".equals(type)) {
/*  872 */       xml.append(url);
/*      */     } else {
/*  874 */       int i = url.lastIndexOf("/");
/*  875 */       if (i != -1) {
/*  876 */         xml.append((String)Cache.configMap.get("MATTERPATH"))
/*  877 */           .append(url.substring(i + 1));
/*      */       }
/*      */       else {
/*  880 */         xml.append(url);
/*      */       }
/*      */     }
/*  883 */     xml.append("</rescontent>\n<resurl>");
/*  884 */     xml.append(link);
/*  885 */     xml.append("</resurl>\n</list>\n");
/*      */   }
/*      */ 
/*      */   public boolean readRule(List<RuleM> list, UserBase user)
/*      */   {
/*  895 */     boolean result = false;
/*  896 */     boolean oldresult = false;
/*  897 */     int next_if = 0;
/*  898 */     String wd = "";
/*  899 */     for (RuleM rm : list)
/*      */     {
/*  901 */       wd = rm.getFieldid();
/*      */ 
/*  903 */       if ("birthday".equals(wd)) {
/*  904 */         oldresult = checkValue(rm, user.birthday);
/*      */       }
/*  906 */       else if ("sex".equals(wd))
/*      */       {
/*  908 */         if (rm.getOpr1() != 0) {
/*  909 */           return false;
/*      */         }
/*      */ 
/*  912 */         oldresult = rm.getVal1().equals(user.sex);
/*      */       }
/*  914 */       else if ("city".equals(wd))
/*      */       {
/*  916 */         if (rm.getOpr1() != 0) {
/*  917 */           return false;
/*      */         }
/*      */ 
/*  920 */         oldresult = rm.getVal1().equals(user.city);
/*      */       }
/*  922 */       else if ("mobilenbr".equals(wd))
/*      */       {
/*  924 */         if (rm.getOpr1() != 0) {
/*  925 */           return false;
/*      */         }
/*      */ 
/*  928 */         if (user.mobilenbr.indexOf(rm.getVal1()) == 0)
/*  929 */           oldresult = true;
/*      */         else {
/*  931 */           oldresult = false;
/*      */         }
/*      */       }
/*  934 */       else if ("ainbr".equals(wd))
/*      */       {
/*  936 */         if (rm.getOpr1() != 0) {
/*  937 */           return false;
/*      */         }
/*  939 */         oldresult = rm.getVal1().equals(user.ainbr);
/*      */       }
/*  941 */       else if ("mobdate".equals(wd)) {
/*  942 */         oldresult = checkValue(rm, user.mobdate);
/*      */       }
/*  944 */       else if ("crlim".equals(wd)) {
/*  945 */         oldresult = checkValue(rm, user.crlim);
/*      */       }
/*  947 */       else if ("currbal".equals(wd)) {
/*  948 */         oldresult = checkValue(rm, user.currbal);
/*      */       }
/*  950 */       else if ("totdueamt".equals(wd)) {
/*  951 */         oldresult = checkValue(rm, user.totdueamt);
/*      */       }
/*  953 */       else if ("cashcrlim".equals(wd)) {
/*  954 */         oldresult = checkValue(rm, user.cashcrlim);
/*      */       }
/*  956 */       else if ("indiv1".equals(wd))
/*      */       {
/*  958 */         if (rm.getOpr1() != 0) {
/*  959 */           return false;
/*      */         }
/*      */ 
/*  962 */         oldresult = rm.getVal1().equals(user.indiv1);
/*      */       }
/*  964 */       else if ("indiv2".equals(wd))
/*      */       {
/*  966 */         if (rm.getOpr1() != 0) {
/*  967 */           return false;
/*      */         }
/*      */ 
/*  970 */         oldresult = rm.getVal1().equals(user.indiv2);
/*      */       }
/*  972 */       else if ("indiv3".equals(wd))
/*      */       {
/*  974 */         if (rm.getOpr1() != 0) {
/*  975 */           return false;
/*      */         }
/*      */ 
/*  978 */         oldresult = rm.getVal1().equals(user.indiv3);
/*      */       }
/*  980 */       else if ("indiv4".equals(wd))
/*      */       {
/*  982 */         if (rm.getOpr1() != 0) {
/*  983 */           return false;
/*      */         }
/*      */ 
/*  986 */         oldresult = rm.getVal1().equals(user.indiv4);
/*      */       }
/*  988 */       else if ("indiv5".equals(wd))
/*      */       {
/*  990 */         if (rm.getOpr1() != 0) {
/*  991 */           return false;
/*      */         }
/*      */ 
/*  994 */         oldresult = rm.getVal1().equals(user.indiv5);
/*      */       }
/*  996 */       else if ("indiv6".equals(wd))
/*      */       {
/*  998 */         if (rm.getOpr1() != 0) {
/*  999 */           return false;
/*      */         }
/*      */ 
/* 1002 */         oldresult = rm.getVal1().equals(user.indiv6);
/*      */       }
/* 1004 */       else if ("indiv7".equals(wd))
/*      */       {
/* 1006 */         if (rm.getOpr1() != 0) {
/* 1007 */           return false;
/*      */         }
/*      */ 
/* 1010 */         oldresult = rm.getVal1().equals(user.indiv7);
/*      */       }
/* 1012 */       else if ("indiv8".equals(wd))
/*      */       {
/* 1014 */         if (rm.getOpr1() != 0) {
/* 1015 */           return false;
/*      */         }
/*      */ 
/* 1018 */         oldresult = rm.getVal1().equals(user.indiv8);
/*      */       }
/*      */ 
/* 1021 */       if (next_if == 0) {
/* 1022 */         result = oldresult;
/*      */       }
/* 1024 */       else if (1 == next_if) {
/* 1025 */         result = (result) && (oldresult);
/*      */       }
/* 1027 */       else if (2 == next_if) {
/* 1028 */         result = (result) || (oldresult);
/*      */       }
/*      */ 
/* 1031 */       next_if = rm.getCif();
/*      */     }
/* 1033 */     return result;
/*      */   }
/*      */ 
/*      */   private boolean checkValue(RuleM rm, Object val)
/*      */   {
/* 1043 */     boolean result = false;
/* 1044 */     boolean result1 = false;
/* 1045 */     boolean result2 = false;
/* 1046 */     float i_val = 0.0F;
/* 1047 */     float i_val1 = 0.0F;
/* 1048 */     float i_val2 = 0.0F;
/*      */     try
/*      */     {
/* 1051 */       if ((val instanceof String))
/* 1052 */         i_val = Float.valueOf(val.toString()).floatValue();
/*      */       else {
/* 1054 */         i_val = ((Float)val).floatValue();
/*      */       }
/* 1056 */       i_val1 = Float.parseFloat(rm.getVal1());
/*      */ 
/* 1058 */       if ((rm.getVal2() == null) || ("".equals(rm.getVal2())))
/* 1059 */         i_val2 = -1.0F;
/*      */       else
/* 1061 */         i_val2 = Float.parseFloat(rm.getVal2());
/*      */     }
/*      */     catch (Exception e) {
/* 1064 */       return false;
/*      */     }
/*      */ 
/* 1068 */     if (rm.getOpr1() == 0)
/*      */     {
/* 1070 */       result = rm.getVal1().equals(val);
/*      */     }
/*      */     else
/*      */     {
/* 1075 */       if (1 == rm.getOpr1())
/* 1076 */         result1 = i_val > i_val1;
/* 1077 */       else if (2 == rm.getOpr1())
/* 1078 */         result1 = i_val < i_val1;
/* 1079 */       else if (3 == rm.getOpr1())
/* 1080 */         result1 = i_val >= i_val1;
/* 1081 */       else if (4 == rm.getOpr1()) {
/* 1082 */         result1 = i_val <= i_val1;
/*      */       }
/*      */ 
/* 1085 */       if (-1.0F == i_val2) {
/* 1086 */         result2 = false;
/*      */       }
/* 1088 */       else if (1 == rm.getOpr2())
/* 1089 */         result2 = i_val > i_val2;
/* 1090 */       else if (2 == rm.getOpr2())
/* 1091 */         result2 = i_val < i_val2;
/* 1092 */       else if (3 == rm.getOpr2())
/* 1093 */         result2 = i_val >= i_val2;
/* 1094 */       else if (4 == rm.getOpr2()) {
/* 1095 */         result2 = i_val >= i_val2;
/*      */       }
/*      */ 
/* 1098 */       result = (result1) && (result2);
/*      */     }
/* 1100 */     return result;
/*      */   }
/*      */ 
/*      */   public String getStageplan(UserBase sb, StringBuffer tsb)
/*      */   {
/* 1109 */     List list = Cache.getStageplan(sb);
/* 1110 */     if ((list == null) || (list.size() == 0)) {
/* 1111 */       return "";
/*      */     }
/* 1113 */     tsb.append("<stageplan>\n<lists>\n");
/* 1114 */     for (Stageplan s : list) {
/* 1115 */       tsb.append("<list>\n")
/* 1116 */         .append("<stagetype>").append(getStageTypeName(s.getStagetype())).append("</stagetype>\n")
/* 1117 */         .append("<totalstage>").append(s.getTotalstage()).append("期</totalstage>\n")
/* 1118 */         .append("<accstage>").append(s.getAccstage()).append("期</accstage>\n")
/* 1119 */         .append("<totalamt>").append(s.getTotalamt()).append("</totalamt>\n")
/* 1120 */         .append("<unaccamt>").append(s.getUnaccamt()).append("</unaccamt>\n")
/* 1121 */         .append("<stagefee>").append(s.getStagefee()).append("</stagefee>\n")
/* 1122 */         .append("<unaccfee>").append(s.getUnaccfee()).append("</unaccfee>\n")
/* 1123 */         .append("</list>\n");
/*      */     }
/* 1125 */     tsb.append("</lists>\n</stageplan>\n");
/* 1126 */     return tsb.toString();
/*      */   }
/*      */ 
/*      */   private String getStageTypeName(String stageType) {
/* 1130 */     if (Cache.stageTypeMap.get(stageType) != null) {
/* 1131 */       return (String)Cache.stageTypeMap.get(stageType);
/*      */     }
/* 1133 */     return stageType;
/*      */   }
/*      */ 
/*      */   public String getClickInfo(UserBase ub)
/*      */   {
/* 1139 */     String imgUrl = BaseParam.PERIOD + "," + ub.acctnbr + "," + ub.cardNo + "," + 2;
/*      */ 
/* 1141 */     String clickUrl = BaseParam.PERIOD + "," + ub.acctnbr + "," + ub.cusnum + "," + ub.cardNo + "," + 2;
/*      */ 
/* 1143 */     StringBuffer res = new StringBuffer();
/*      */     try {
/* 1145 */       res
/* 1146 */         .append("<clickurl>")
/* 1147 */         .append((String)Cache.configMap.get("LINK_URL"))
/* 1148 */         .append("/bill/bcs?parameterStr=")
/* 1149 */         .append(URLEncoder.encode(Cache.des.encryptStr(clickUrl), "gbk"))
/* 1150 */         .append("</clickurl>\n<imgurl>")
/* 1151 */         .append((String)Cache.configMap.get("LINK_URL"))
/* 1152 */         .append("/bill/pic?parameterStr=")
/* 1153 */         .append(URLEncoder.encode(Cache.des.encryptStr(imgUrl), "gbk"))
/* 1154 */         .append("</imgurl>\n");
/*      */     } catch (Exception e) {
/* 1156 */       this.log.error(e);
/*      */     }
/* 1158 */     return res.toString();
/*      */   }
/*      */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.reprintXML.UserXml
 * JD-Core Version:    0.6.2
 */