/*     */ package com.bill.reprintXML;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.bean.Plog;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ 
/*     */ public class PXml
/*     */ {
/*     */   public RandomAccessFile filew;
/*     */   public File file;
/*     */   public Map<String, RandomAccessFile> fileMap;
/*     */   public Map<String, Plog> logMap;
/*     */   public Plog plog;
/*  37 */   public int count = 0;
/*     */   public String tmp_yyzno;
/*     */ 
/*     */   public void create(String stmtdate, String cardid, String wbs, String yyzno, String cardtype, String id)
/*     */   {
/*  57 */     String fpath = getFileInfo(wbs, cardtype);
/*     */ 
/*  62 */     this.file = new File(fpath + stmtdate + "_" + cardid + "_" + yyzno + "_" + 
/*  63 */       wbs + "_1.xml");
/*     */     try {
/*  65 */       if (this.file.exists()) {
/*  66 */         this.file.delete();
/*     */       }
/*     */ 
/*  69 */       if (this.file.createNewFile())
/*  70 */         this.filew = new RandomAccessFile(this.file.getPath(), "rw");
/*     */     }
/*     */     catch (IOException e) {
/*  73 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  76 */     write(BaseParam.XML_BEGIN);
/*     */   }
/*     */ 
/*     */   public void write(String xml, Map<String, String> map, String period, String id) {
/*  80 */     if (this.fileMap == null) {
/*  81 */       this.fileMap = new HashMap();
/*     */     }
/*     */ 
/*  84 */     if (!((String)map.get("yyzno")).equals(this.tmp_yyzno))
/*     */     {
/*  88 */       this.tmp_yyzno = ((String)map.get("yyzno"));
/*     */ 
/*  90 */       if (this.fileMap.containsKey(map.get("yyzno"))) {
/*  91 */         this.filew = ((RandomAccessFile)this.fileMap.get(map.get("yyzno")));
/*  92 */         this.plog = ((Plog)this.logMap.get(map.get("yyzno")));
/*     */       } else {
/*  94 */         create(period, (String)map.get("cardid"), (String)map.get("wbs"), 
/*  95 */           (String)map.get("yyzno"), (String)map.get("cardtype"), id);
/*  96 */         this.fileMap.put((String)map.get("yyzno"), this.filew);
/*     */ 
/*  98 */         this.plog = new Plog();
/*  99 */         this.plog.setStmtdate(BaseParam.PERIOD);
/* 100 */         this.plog.setFilename(this.file.getPath());
/* 101 */         this.plog.setBusinpnt_no((String)map.get("wbs"));
/* 102 */         this.plog.setCard_id((String)map.get("cardid"));
/* 103 */         this.plog.setPaper_no((String)map.get("yyz"));
/* 104 */         this.plog.setStart_time(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Long.valueOf(System.currentTimeMillis())));
/* 105 */         this.plog.setShare(0);
/* 106 */         this.plog.setState("1");
/* 107 */         if (this.logMap == null) {
/* 108 */           this.logMap = new HashMap();
/*     */         }
/* 110 */         this.logMap.put((String)map.get("yyzno"), this.plog);
/*     */       }
/*     */     }
/*     */     try {
/* 114 */       this.filew.write(xml.getBytes("utf-8"));
/* 115 */       this.plog.setShare(this.plog.getShare() + 1);
/* 116 */       this.logMap.put((String)map.get("yyzno"), this.plog);
/*     */     } catch (IOException e) {
/* 118 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void close() {
/* 123 */     if (this.fileMap == null)
/* 124 */       return;
/*     */     try
/*     */     {
/* 127 */       for (Map.Entry entry : this.fileMap.entrySet()) {
/* 128 */         this.filew = ((RandomAccessFile)entry.getValue());
/* 129 */         this.filew.write(BaseParam.XML_END.getBytes("utf-8"));
/* 130 */         this.filew.close();
/*     */ 
/* 132 */         this.plog = ((Plog)this.logMap.get(entry.getKey()));
/* 133 */         if (this.plog == null) {
/* 134 */           System.out.println("error:page log is null!key=" + (String)entry.getKey());
/*     */         }
/* 136 */         this.plog.setEnd_time(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Long.valueOf(System.currentTimeMillis())));
/* 137 */         Cache.savePLog(this.plog);
/*     */       }
/*     */     } catch (UnsupportedEncodingException e) {
/* 140 */       e.printStackTrace();
/*     */     } catch (IOException e) {
/* 142 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void write(String xml)
/*     */   {
/* 152 */     if (this.filew == null)
/* 153 */       return;
/*     */     try {
/* 155 */       this.filew.write(xml.getBytes("utf-8"));
/*     */     } catch (IOException e) {
/* 157 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void over(int input_count)
/*     */   {
/* 167 */     if (this.filew == null)
/* 168 */       return;
/*     */     try
/*     */     {
/* 171 */       this.filew.write(BaseParam.XML_END.getBytes("utf-8"));
/* 172 */       this.filew.close();
/* 173 */       if (input_count == 0) {
/* 174 */         this.file.delete();
/*     */       }
/* 176 */       this.filew = null;
/*     */     } catch (IOException e) {
/* 178 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getFileInfo(String wbs, String cardtype)
/*     */   {
/* 192 */     String fpath = BaseParam.XML_PATH + cardtype + "/REPRINT/XML/TNO" + "/" + 
/* 193 */       wbs + "/";
/* 194 */     File temp = new File(fpath);
/*     */ 
/* 196 */     if (!temp.exists()) {
/* 197 */       temp.mkdirs();
/*     */     }
/*     */ 
/* 200 */     return fpath;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.reprintXML.PXml
 * JD-Core Version:    0.6.2
 */