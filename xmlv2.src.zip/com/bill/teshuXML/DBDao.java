/*     */ package com.bill.teshuXML;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.bean.Busin;
/*     */ import com.bill.bean.Card;
/*     */ import com.bill.bean.Debitinfo;
/*     */ import com.bill.bean.Fodder;
/*     */ import com.bill.bean.Foldout;
/*     */ import com.bill.bean.Plog;
/*     */ import com.bill.bean.PointInfo;
/*     */ import com.bill.bean.Rule;
/*     */ import com.bill.bean.RuleF;
/*     */ import com.bill.bean.RuleM;
/*     */ import com.bill.bean.TempArea;
/*     */ import com.bill.bean.Template;
/*     */ import com.bill.bean.UserAccinfo;
/*     */ import com.bill.bean.UserAccinfoDetail;
/*     */ import com.bill.bean.UserBase;
/*     */ import com.bill.bean.UserBuy;
/*     */ import com.bill.bean.Yyz;
/*     */ import com.bill.db.DbConnectionForOracle;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class DBDao
/*     */ {
/*     */   private DbConnectionForOracle dbconn;
/*     */   private PreparedStatement statement;
/*     */   private ResultSet result;
/*  18 */   private static String CARD_SQL = "select t.s_buss_prod_id,t.s_buss_prod_name,t.c_buss_type_id from T_S_BUSI_PROD_INFO t where t.c_buss_prod_flag='0'";
/*     */ 
/*  22 */   private static String BFPNT_SQL = "select t.s_id from t_s_befor_print_nasic  t where  to_date(?,'yyyyMM')>= to_date(t.c_period_begen,'yyyy-MM') and to_date(?,'yyyyMM')<= to_date(t.c_period_end,'yyyy-MM') and t.c_period_day=?";
/*     */ 
/*  27 */   private static String CPB_CITY_SQL = "select t.s_city_no from t_s_bfpnt_cty_crdtp t where t.s_city_no is not null and t.s_card_no =? and t.s_id=? and t.s_businpnt_no=?";
/*     */ 
/*  32 */   private static String USER_BASE = "select * from t_n_customer_bill t where S_CARD_PROD_ID=? and S_CITY_ID=? and ";
/*     */ 
/*  38 */   private static String TEMPLATE_SQL = "";
/*     */ 
/*  43 */   private static String RULE_SQL = "select * from t_s_rule_m t where t.s_stencil_no=? and t.c_rule_type=? and t.i_area_no=? and t.c_state='1' and to_date(?,'yyyyMMdd')>=to_date(t.c_period_begen,'yyyy-MM') and to_date(?,'yyyyMMdd')<=to_date(t.c_period_end,'yyyy-MM') order by t.i_pri desc";
/*     */ 
/*     */   public DBDao()
/*     */   {
/*  50 */     this.dbconn = new DbConnectionForOracle(BaseParam.DB_IP, BaseParam.DB_PORT, BaseParam.DB_NAME, BaseParam.DB_USER, BaseParam.DB_PWD);
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/*  56 */     this.dbconn.close();
/*     */   }
/*     */ 
/*     */   public List<Busin> getBusin()
/*     */   {
/*  63 */     List list = new ArrayList();
/*     */     try {
/*  65 */       this.statement = this.dbconn.getConnection().prepareStatement("select t1.s_businpnt_no,t1.s_businpnt_name from T_S_EPLBOLY_PNT t1");
/*  66 */       this.result = this.statement.executeQuery();
/*     */ 
/*  68 */       while (this.result.next()) {
/*  69 */         Busin e = new Busin();
/*  70 */         e.setId(this.result.getString("s_businpnt_no"));
/*  71 */         e.setName(this.result.getString("s_businpnt_name"));
/*  72 */         list.add(e);
/*     */       }
/*  74 */       this.result.close();
/*  75 */       this.statement.close();
/*     */     } catch (SQLException e) {
/*  77 */       e.printStackTrace();
/*     */     }
/*  79 */     return list;
/*     */   }
/*     */ 
/*     */   public List<Card> getCard()
/*     */   {
/*  86 */     List list = new ArrayList();
/*     */     try {
/*  88 */       this.statement = this.dbconn.getConnection().prepareStatement(CARD_SQL);
/*  89 */       this.result = this.statement.executeQuery();
/*     */ 
/*  91 */       while (this.result.next()) {
/*  92 */         Card e = new Card();
/*  93 */         e.setId(this.result.getString("s_buss_prod_id"));
/*  94 */         e.setName(this.result.getString("s_buss_prod_name"));
/*  95 */         e.setType(this.result.getString("c_buss_type_id"));
/*  96 */         list.add(e);
/*     */       }
/*  98 */       this.result.close();
/*  99 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 101 */       e.printStackTrace();
/*     */     }
/* 103 */     return list;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getBfpntMap()
/*     */   {
/* 110 */     Map map = new HashMap();
/*     */ 
/* 112 */     String ym = BaseParam.PERIOD.substring(0, 6);
/*     */ 
/* 114 */     String d = BaseParam.PERIOD.substring(6);
/*     */     try {
/* 116 */       this.statement = this.dbconn.getConnection().prepareStatement(BFPNT_SQL);
/* 117 */       this.statement.setString(1, ym);
/* 118 */       this.statement.setString(2, ym);
/* 119 */       this.statement.setString(3, d);
/* 120 */       this.result = this.statement.executeQuery();
/*     */ 
/* 122 */       String id = "";
/* 123 */       while (this.result.next()) {
/* 124 */         id = this.result.getString(1);
/* 125 */         map.put(id, id);
/*     */       }
/* 127 */       this.result.close();
/* 128 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 130 */       e.printStackTrace();
/* 131 */       return null;
/*     */     }
/* 133 */     return map;
/*     */   }
/*     */ 
/*     */   public Map<String, List<Yyz>> getCardBfpntMap()
/*     */   {
/* 141 */     Map map = new HashMap();
/*     */     try {
/* 143 */       this.statement = this.dbconn.getConnection().prepareStatement("select t.s_card_no,t.s_id,t2.S_PAPER_NO from t_s_bfpnt_cty_crdtp t,T_S_BEFOR_PRINT_BASIC t2 where t.s_id<>'0' and t.s_id=t2.s_id group by t.s_card_no,t.s_id,t2.S_PAPER_NO");
/* 144 */       this.result = this.statement.executeQuery();
/*     */ 
/* 146 */       String id1 = "";
/*     */ 
/* 148 */       while (this.result.next()) {
/* 149 */         Yyz y = new Yyz();
/* 150 */         id1 = this.result.getString("s_card_no");
/* 151 */         y.setId(this.result.getString("s_id"));
/* 152 */         y.setPaperNo(this.result.getString("S_PAPER_NO"));
/* 153 */         if (map.containsKey(id1)) {
/* 154 */           ((List)map.get(id1)).add(y);
/*     */         } else {
/* 156 */           List list = new ArrayList();
/* 157 */           list.add(y);
/* 158 */           map.put(id1, list);
/*     */         }
/*     */       }
/* 161 */       this.result.close();
/* 162 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 164 */       e.printStackTrace();
/* 165 */       return null;
/*     */     }
/* 167 */     return map;
/*     */   }
/*     */ 
/*     */   public List<String> getCityByCPB(String cid, String pid, String bid)
/*     */   {
/* 177 */     List list = new ArrayList();
/*     */     try {
/* 179 */       this.statement = this.dbconn.getConnection().prepareStatement(CPB_CITY_SQL);
/* 180 */       this.statement.setString(1, cid);
/* 181 */       this.statement.setString(2, pid);
/* 182 */       this.statement.setString(3, bid);
/* 183 */       this.result = this.statement.executeQuery();
/* 184 */       while (this.result.next()) {
/* 185 */         list.add(this.result.getString("S_CITY_NO"));
/*     */       }
/* 187 */       this.result.close();
/* 188 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 190 */       e.printStackTrace();
/*     */     }
/* 192 */     return list;
/*     */   }
/*     */ 
/*     */   public List<UserBase> getUserBase(String cardid, String city)
/*     */   {
/* 201 */     List list = new ArrayList();
/*     */     try {
/* 203 */       this.statement = this.dbconn.getConnection().prepareStatement(USER_BASE);
/* 204 */       this.statement.setString(1, cardid);
/* 205 */       this.statement.setString(2, city);
/* 206 */       this.result = this.statement.executeQuery();
/*     */ 
/* 208 */       while (this.result.next()) {
/* 209 */         UserBase ub = new UserBase();
/* 210 */         ub.setAcctnbr(this.result.getString("S_ACCOUNT"));
/* 211 */         ub.setRectype(this.result.getString("S_CUR_TYPE"));
/* 212 */         ub.setZip(this.result.getString("S_CUR_ZIP"));
/* 213 */         ub.setAddrname3(this.result.getString("S_CUR_ADDR3"));
/* 214 */         ub.setAddrname1(this.result.getString("S_CUR_ADDR1"));
/* 215 */         ub.setAddrname2(this.result.getString("S_CUR_ADDR2"));
/* 216 */         ub.setName(this.result.getString("S_CUR_NAME"));
/* 217 */         ub.setSex(this.result.getString("C_CUR_SEX"));
/* 218 */         ub.setBirthday(this.result.getString("S_CUR_BIRTHDAY"));
/* 219 */         ub.setAccnum(this.result.getString("S_CUR_ACCOUNT"));
/* 220 */         ub.setCusnum(this.result.getString("S_CUR_CUST_NBR"));
/* 221 */         ub.setStfromdate(this.result.getString("S_CUR_START_DATE"));
/* 222 */         ub.setEnddate(this.result.getString("S_CUR_END_DATE"));
/* 223 */         ub.setSpecode(this.result.getString("S_CUR_SPECIAL_CHAR"));
/* 224 */         ub.setPmtduemark(this.result.getString("S_CUR_PMT_CYCLE_DUE"));
/* 225 */         ub.setCashmark(this.result.getString("S_CUR_PRINT"));
/* 226 */         ub.setIndiv1(this.result.getString("C_CUR_MSG_1"));
/* 227 */         ub.setIndiv2(this.result.getString("C_CUR_MSG_2"));
/* 228 */         ub.setIndiv3(this.result.getString("C_CUR_MSG_3"));
/* 229 */         ub.setIndiv4(this.result.getString("C_CUR_MSG_4"));
/* 230 */         ub.setIndiv5(this.result.getString("C_CUR_MSG_5"));
/* 231 */         ub.setIndiv6(this.result.getString("C_CUR_MSG_6"));
/* 232 */         ub.setIndiv7(this.result.getString("C_CUR_MSG_7"));
/* 233 */         ub.setIndiv8(this.result.getString("C_CUR_MSG_8"));
/* 234 */         ub.setActinfo(this.result.getString("C_CUR_ACTIVITY_MSG"));
/* 235 */         ub.setDm1(this.result.getString("C_CUR_DM_MSG_1"));
/* 236 */         ub.setDm2(this.result.getString("C_CUR_DM_MSG_2"));
/* 237 */         ub.setDm3(this.result.getString("C_CUR_DM_MSG_3"));
/* 238 */         ub.setDm4(this.result.getString("C_CUR_DM_MSG_4"));
/* 239 */         ub.setBrandmsg1(this.result.getString("C_CUR_BRAND_MSG_1"));
/* 240 */         ub.setBrandmsg2(this.result.getString("C_CUR_BRAND_MSG_2"));
/* 241 */         ub.setBrandmsg3(this.result.getString("C_CUR_BRAND_MSG_3"));
/* 242 */         ub.setBrandmsg4(this.result.getString("C_CUR_BRAND_MSG_4"));
/* 243 */         ub.setBrandmsg5(this.result.getString("C_CUR_BRAND_MSG_5"));
/* 244 */         ub.setBrandmsg6(this.result.getString("C_CUR_BRAND_MSG_6"));
/* 245 */         ub.setBrandmsg7(this.result.getString("C_CUR_BRAND_MSG_7"));
/* 246 */         ub.setConvexchmark(this.result.getString("C_CUR_CONV_EXCH_FLAG"));
/* 247 */         ub.setVipmsg1(this.result.getString("C_CUR_VIP_MSG_1"));
/* 248 */         ub.setVipmsg2(this.result.getString("C_CUR_VIP_MSG_2"));
/* 249 */         ub.setVipmsg3(this.result.getString("C_CUR_VIP_MSG_3"));
/* 250 */         ub.setVipmsg4(this.result.getString("C_CUR_VIP_MSG_4"));
/* 251 */         ub.setReprintflag(this.result.getString("C_CUR_REPRINT_FLAG"));
/* 252 */         ub.setEmailflag(this.result.getString("C_CUR_EMAIL_STMT_FLAG"));
/* 253 */         ub.setPaperflag(this.result.getString("C_CUR_PAPER_STMT_FLAG"));
/* 254 */         ub.setEmailaddr(this.result.getString("S_CUR_EMAIL_ADDR"));
/* 255 */         ub.setCusttype(this.result.getString("S_CUR_CUSTOMER_TYPE"));
/* 256 */         ub.setMobilenbr(this.result.getString("S_CUR_MOBILE_NBR"));
/* 257 */         ub.setAinbr(this.result.getString("S_CUR_AI_NBR"));
/* 258 */         ub.setMobdate(this.result.getString("C_CUR_MOB"));
/* 259 */         ub.setFiller(this.result.getString("S_CUR_FILLER"));
/* 260 */         ub.setCity(this.result.getString("S_CITY_ID"));
/* 261 */         ub.setCrlim(this.result.getString("I_CUR_CRLIM"));
/* 262 */         ub.setCurrbal(this.result.getString("I_CUR_BAL"));
/* 263 */         ub.setTotdueamt(this.result.getString("I_CUR_TOT_DUE_AMT"));
/* 264 */         ub.setCashcrlim(this.result.getString("I_CUR_CASH_CRLIM"));
/* 265 */         ub.setStmtdate(this.result.getString("C_STMT_DATE"));
/* 266 */         ub.setCardNo(this.result.getString("S_CARD_PROD_ID"));
/* 267 */         list.add(ub);
/*     */       }
/* 269 */       this.result.close();
/* 270 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 272 */       e.printStackTrace();
/*     */     }
/* 274 */     return list;
/*     */   }
/*     */ 
/*     */   public List<UserAccinfo> getUserInfo(String acctnbr, String period)
/*     */   {
/* 282 */     List list = new ArrayList();
/*     */     try {
/* 284 */       this.statement = this.dbconn.getConnection().prepareStatement("select * from view_n_customer_bill t where t.acctnbr=? and t.stmtdate=?");
/* 285 */       this.statement.setString(1, acctnbr);
/* 286 */       this.statement.setString(2, period);
/* 287 */       this.result = this.statement.executeQuery();
/*     */ 
/* 289 */       while (this.result.next()) {
/* 290 */         UserAccinfo ub = new UserAccinfo();
/* 291 */         ub.setAcctnbr(this.result.getString("acctnbr"));
/* 292 */         ub.setRectype(this.result.getString("rectype"));
/* 293 */         ub.setStmtdate(this.result.getString("stmtdate"));
/* 294 */         ub.setPmtdate(this.result.getString("pmtdate"));
/* 295 */         ub.setTotbegbal(this.result.getString("totbegbal"));
/* 296 */         ub.setPlantotpmt(this.result.getString("plantotpmt"));
/* 297 */         ub.setPlantotnrlamt(this.result.getString("plantotnrlamt"));
/* 298 */         ub.setPlantotadjamt(this.result.getString("plantotadjamt"));
/* 299 */         ub.setIntdueamt(this.result.getString("intdueamt"));
/* 300 */         ub.setCurrbal(this.result.getString("currbal"));
/* 301 */         ub.setTotdueamt(this.result.getString("totdueamt"));
/* 302 */         ub.setPmtprint(this.result.getString("pmtprint"));
/* 303 */         ub.setCrlim(this.result.getString("crlim"));
/* 304 */         ub.setCashcrlim(this.result.getString("cashcrlim"));
/* 305 */         ub.setPmtarn(this.result.getString("pmtarn"));
/* 306 */         ub.setPmtadn(this.result.getString("pmtadn"));
/* 307 */         ub.setProjap(this.result.getString("projap"));
/* 308 */         ub.setPmtaflag(this.result.getString("pmtaflag"));
/* 309 */         ub.setAchflag(this.result.getString("achflag"));
/* 310 */         ub.setPmtflag(this.result.getString("pmtflag"));
/* 311 */         ub.setFiller(this.result.getString("filler"));
/* 312 */         list.add(ub);
/*     */       }
/* 314 */       this.result.close();
/* 315 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 317 */       e.printStackTrace();
/*     */     }
/* 319 */     return list;
/*     */   }
/*     */ 
/*     */   public List<UserAccinfoDetail> getAccinfoDetail(UserBase user)
/*     */   {
/* 327 */     List list = new ArrayList();
/*     */     try {
/* 329 */       this.statement = this.dbconn.getConnection().prepareStatement("select * from view_n_customer_bill_detail t where t.acctnbr=?");
/* 330 */       this.statement.setString(1, user.getAcctnbr());
/* 331 */       this.result = this.statement.executeQuery();
/*     */ 
/* 333 */       while (this.result.next()) {
/* 334 */         UserAccinfoDetail ub = new UserAccinfoDetail();
/* 335 */         ub.setAcctnbr(this.result.getString("acctnbr"));
/* 336 */         ub.setRectype(this.result.getString("rectype"));
/* 337 */         ub.setRecseq(this.result.getString("recseq"));
/* 338 */         ub.setEffdate(this.result.getString("effdate"));
/* 339 */         ub.setPostdate(this.result.getString("postdate"));
/* 340 */         ub.setCardnlast4(this.result.getString("cardnlast4"));
/* 341 */         ub.setDesc(this.result.getString("curdesc"));
/* 342 */         ub.setTxnamt(this.result.getString("txnamt"));
/* 343 */         ub.setSrctamt(this.result.getString("srctamt"));
/* 344 */         ub.setSrctcurr(this.result.getString("srctcurr"));
/* 345 */         ub.setPurcty(this.result.getString("purcty"));
/* 346 */         ub.setFiller(this.result.getString("filler"));
/* 347 */         list.add(ub);
/*     */       }
/* 349 */       this.result.close();
/* 350 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 352 */       e.printStackTrace();
/*     */     }
/* 354 */     return list;
/*     */   }
/*     */ 
/*     */   public UserBuy getUserBuy(UserBase user) {
/* 358 */     UserBuy ub = null;
/*     */     try {
/* 360 */       this.statement = this.dbconn.getConnection().prepareStatement("select * from T_N_CUSTOMER_PURCHASE t where t.S_ACCOUNT=?");
/* 361 */       this.statement.setString(1, user.getAcctnbr());
/* 362 */       this.result = this.statement.executeQuery();
/* 363 */       while (this.result.next()) {
/* 364 */         ub = new UserBuy();
/* 365 */         ub.setAcctnbr(this.result.getString("S_ACCOUNT"));
/* 366 */         ub.setRectype(this.result.getString("S_CUR_PUR_REC_TYPE"));
/* 367 */         ub.setExchusdamt(this.result.getString("I_CUR_PUR_EXCH_USD_AMT"));
/* 368 */         ub.setSellrate(this.result.getString("I_CUR_PUR_SELL_RATE"));
/* 369 */         ub.setExchrmbamt(this.result.getString("I_CUR_PUR_EXCH_RMB_AMT"));
/* 370 */         ub.setAchrtnbr(this.result.getString("S_CUR_PUR_PMT_ACH_RT_NBR"));
/* 371 */         ub.setAchdbnbr(this.result.getString("S_CUR_PUR_PMT_ACH_DB_NBR"));
/* 372 */         ub.setFiller(this.result.getString("S_CUR_PUR_FILLER"));
/*     */       }
/* 374 */       this.result.close();
/* 375 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 377 */       e.printStackTrace();
/* 378 */       return null;
/*     */     }
/* 380 */     return ub;
/*     */   }
/*     */ 
/*     */   public List<Debitinfo> getDebitinfo(UserBase user)
/*     */   {
/* 388 */     List list = new ArrayList();
/* 389 */     Debitinfo deb = null;
/*     */     try {
/* 391 */       this.statement = this.dbconn.getConnection().prepareStatement("select * from view_n_crad_trade_detail t where t.acctnbr=?");
/* 392 */       this.statement.setString(1, user.getAcctnbr());
/* 393 */       this.result = this.statement.executeQuery();
/* 394 */       while (this.result.next()) {
/* 395 */         deb = new Debitinfo();
/* 396 */         deb.setAcctnbr(this.result.getString("acctnbr"));
/* 397 */         deb.setRectype(this.result.getString("rectype"));
/* 398 */         deb.setCustnbr(this.result.getString("custnbr"));
/* 399 */         deb.setEffdate(this.result.getString("effdate"));
/* 400 */         deb.setTxndesc(this.result.getString("txndesc"));
/* 401 */         deb.setTxncity(this.result.getString("txncity"));
/* 402 */         deb.setCurrcode(this.result.getString("currcode"));
/* 403 */         deb.setTxnamt(this.result.getString("txnamt"));
/* 404 */         deb.setCardl4(this.result.getString("cardl4"));
/* 405 */         deb.setFiller(this.result.getString("filler"));
/* 406 */         list.add(deb);
/*     */       }
/* 408 */       this.result.close();
/* 409 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 411 */       e.printStackTrace();
/* 412 */       return null;
/*     */     }
/* 414 */     return list;
/*     */   }
/*     */ 
/*     */   public List<PointInfo> getPoint(String acctnbr, String billday)
/*     */   {
/* 424 */     List list = new ArrayList();
/* 425 */     PointInfo p = null;
/*     */     try {
/* 427 */       this.statement = this.dbconn.getConnection().prepareStatement("select * from t_n_point_x where S_BUSINESS_ID=? and C_STMT_DATE=?");
/* 428 */       this.statement.setString(1, acctnbr);
/* 429 */       this.statement.setString(2, billday);
/* 430 */       this.result = this.statement.executeQuery();
/* 431 */       while (this.result.next()) {
/* 432 */         p = new PointInfo();
/* 433 */         p.setPointtype(this.result.getString("S_POINT_TYPE"));
/* 434 */         p.setCardportid(this.result.getString("S_ACCT_PROD_ID"));
/* 435 */         p.setBusinessid(this.result.getString("S_BUSINESS_ID"));
/* 436 */         p.setAblepoint(this.result.getString("I_ABLE_POINT"));
/* 437 */         p.setLastbalpoint(this.result.getString("I_LASTBAL_POINT"));
/* 438 */         p.setAddpoint(this.result.getString("I_ADDPOINT_POINT"));
/* 439 */         p.setExpoint(this.result.getString("I_EXPOINT_POINT"));
/* 440 */         p.setAdpoints(this.result.getString("I_ADPOINTS_POINT"));
/* 441 */         p.setEndpoints(this.result.getString("I_ENDPOINTS_POINT"));
/* 442 */         p.setEcifno(this.result.getString("S_ECIF_NO"));
/* 443 */         p.setStartdate(this.result.getString("S_START_DATE"));
/* 444 */         p.setEnddate(this.result.getString("S_END_DATE"));
/* 445 */         p.setWholeconsume(this.result.getString("I_WHOLE_CONSUME"));
/* 446 */         p.setInconsume(this.result.getString("I_IN_CONSUME"));
/* 447 */         p.setOutconsume(this.result.getString("I_OUT_CONSUME"));
/* 448 */         p.setWholemoney(this.result.getString("I_WHOLE_MONEY"));
/* 449 */         p.setInmoney(this.result.getString("I_IN_MONEY"));
/* 450 */         p.setOutmoney(this.result.getString("I_OUT_MONEY"));
/* 451 */         p.setUsedmoney(this.result.getString("I_USED_MONEY"));
/* 452 */         p.setLavemoney(this.result.getString("I_LAVE_MONEY"));
/* 453 */         p.setValiddate(this.result.getString("S_VALID_DATE"));
/* 454 */         p.setLaddermoney(this.result.getString("I_LADDER_MONEY"));
/* 455 */         p.setLadderscale(this.result.getString("S_LADDER_SCALE"));
/* 456 */         p.setCard4(this.result.getString("C_CARD_LAST4"));
/* 457 */         p.setCardPointType(this.result.getString("C_CARD_POINT_TYPE"));
/* 458 */         p.setCardname(this.result.getString("S_CARD_POINT_NAME"));
/* 459 */         list.add(p);
/*     */       }
/* 461 */       this.result.close();
/* 462 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 464 */       e.printStackTrace();
/* 465 */       return null;
/*     */     }
/* 467 */     return list;
/*     */   }
/*     */ 
/*     */   public PointInfo getPoint2(String acctnbr, String billday)
/*     */   {
/* 476 */     PointInfo p = null;
/*     */     try {
/* 478 */       this.statement = this.dbconn.getConnection().prepareStatement("select * from t_n_POINT_W where S_ECIF_NO=? and to_date(S_POINT_FPERIOD,'yyyy-MM-dd')=to_date(?,'yyyyMMdd')");
/* 479 */       this.statement.setString(1, acctnbr);
/* 480 */       this.statement.setString(2, billday);
/* 481 */       this.result = this.statement.executeQuery();
/* 482 */       while (this.result.next()) {
/* 483 */         p = new PointInfo();
/* 484 */         p.setBilldate(this.result.getString("S_POINT_FPERIOD"));
/* 485 */         p.setBusinessid(this.result.getString("S_ECIF_NO"));
/* 486 */         p.setAblepoint(this.result.getString("I_ENDPOINT"));
/* 487 */         p.setLastbalpoint(this.result.getString("I_VALIDPOINt_n"));
/* 488 */         p.setAddpoint(this.result.getString("I_NEWPOINT"));
/* 489 */         p.setExpoint(this.result.getString("I_USEDPOINT"));
/* 490 */         p.setAdpoints(this.result.getString("I_ADJUSTPOINT"));
/* 491 */         p.setEndpoints(this.result.getString("I_INVAILPOINT"));
/*     */       }
/* 493 */       this.result.close();
/* 494 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 496 */       e.printStackTrace();
/* 497 */       return null;
/*     */     }
/* 499 */     return p;
/*     */   }
/*     */ 
/*     */   public List<Template> getTemplateList()
/*     */   {
/* 508 */     List list = new ArrayList();
/*     */     try {
/* 510 */       this.statement = this.dbconn.getConnection().prepareStatement(TEMPLATE_SQL);
/* 511 */       this.result = this.statement.executeQuery();
/*     */ 
/* 513 */       while (this.result.next()) {
/* 514 */         Template t = new Template();
/* 515 */         t.setId(this.result.getString("S_STENCIL_NO"));
/* 516 */         t.setCardid(this.result.getString("S_CARD_PROD_ID"));
/* 517 */         t.setType(this.result.getString("C_TYPE_NO"));
/* 518 */         list.add(t);
/*     */       }
/* 520 */       this.result.close();
/* 521 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 523 */       e.printStackTrace();
/*     */     }
/* 525 */     return list;
/*     */   }
/*     */ 
/*     */   public List<Rule> getRule(String tid, String type, String area, String billday)
/*     */   {
/* 538 */     List list = new ArrayList();
/*     */     try {
/* 540 */       this.statement = this.dbconn.getConnection().prepareStatement(RULE_SQL);
/* 541 */       this.statement.setString(1, tid);
/* 542 */       this.statement.setString(2, type);
/* 543 */       this.statement.setString(3, area);
/* 544 */       this.statement.setString(4, billday);
/* 545 */       this.statement.setString(5, billday);
/* 546 */       this.result = this.statement.executeQuery();
/*     */ 
/* 548 */       while (this.result.next()) {
/* 549 */         Rule r = new Rule();
/* 550 */         r.setRuleid(this.result.getString("S_RULE_NO"));
/* 551 */         r.setTid(this.result.getString("S_STENCIL_NO"));
/* 552 */         r.setRuleType(this.result.getString("C_RULE_TYPE"));
/* 553 */         r.setType(this.result.getString("C_TYPENO"));
/* 554 */         r.setPri(this.result.getString("I_PRI"));
/* 555 */         r.setAreaNo(this.result.getString("I_AREA_NO"));
/* 556 */         list.add(r);
/*     */       }
/* 558 */       this.result.close();
/* 559 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 561 */       e.printStackTrace();
/*     */     }
/* 563 */     return list;
/*     */   }
/*     */ 
/*     */   public List<RuleF> getRuleF(String rid)
/*     */   {
/* 570 */     List list = new ArrayList();
/*     */     try {
/* 572 */       this.statement = this.dbconn.getConnection().prepareStatement("select * from t_s_rule_f t where t.s_rule_no=? order by t.i_pri desc");
/* 573 */       this.statement.setString(1, rid);
/* 574 */       this.result = this.statement.executeQuery();
/*     */ 
/* 576 */       while (this.result.next()) {
/* 577 */         RuleF r = new RuleF();
/* 578 */         r.setId(this.result.getString("S_SEQUENCE"));
/* 579 */         r.setRid(this.result.getString("S_RULE_NO"));
/* 580 */         r.setFodder(this.result.getString("S_FODDER_NO"));
/* 581 */         r.setPri(this.result.getString("I_PRI"));
/* 582 */         list.add(r);
/*     */       }
/* 584 */       this.result.close();
/* 585 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 587 */       e.printStackTrace();
/*     */     }
/* 589 */     return list;
/*     */   }
/*     */ 
/*     */   public List<RuleM> getRuleFF(String rid)
/*     */   {
/* 596 */     List list = new ArrayList();
/*     */     try {
/* 598 */       this.statement = this.dbconn.getConnection().prepareStatement("select * from t_s_rule_ff t where t.s_sequence=? order by t.s_idx");
/* 599 */       this.statement.setString(1, rid);
/* 600 */       this.result = this.statement.executeQuery();
/*     */ 
/* 602 */       while (this.result.next()) {
/* 603 */         RuleM r = new RuleM();
/* 604 */         r.setFieldid(this.result.getString("I_FIELD_TYPE"));
/* 605 */         r.setOpr1(this.result.getInt("C_OPR_1"));
/* 606 */         r.setVal1(this.result.getString("S_VALIUE_1"));
/* 607 */         r.setOpr2(this.result.getInt("C_OPR_2"));
/* 608 */         r.setVal2(this.result.getString("S_VALIUE_2"));
/* 609 */         r.setCif(this.result.getInt("C_IF"));
/* 610 */         list.add(r);
/*     */       }
/* 612 */       this.result.close();
/* 613 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 615 */       e.printStackTrace();
/*     */     }
/* 617 */     return list;
/*     */   }
/*     */ 
/*     */   public List<RuleM> getRuleM(String rfid)
/*     */   {
/* 625 */     List list = new ArrayList();
/*     */     try {
/* 627 */       this.statement = this.dbconn.getConnection().prepareStatement("select * from t_s_rule_ff t where t.s_sequence=? order by t.s_idx");
/* 628 */       this.statement.setString(1, rfid);
/* 629 */       this.result = this.statement.executeQuery();
/*     */ 
/* 631 */       while (this.result.next()) {
/* 632 */         RuleM r = new RuleM();
/* 633 */         r.setIdx(this.result.getString("S_IDX"));
/* 634 */         r.setOpr1(this.result.getInt("C_OPR_1"));
/* 635 */         r.setVal1(this.result.getString("S_VALIUE_1"));
/* 636 */         r.setOpr2(this.result.getInt("C_OPR_2"));
/* 637 */         r.setVal2(this.result.getString("S_VALIUE_2"));
/* 638 */         r.setCif(this.result.getInt("C_IF"));
/* 639 */         r.setFieldid(this.result.getString("I_FIELD_TYPE"));
/* 640 */         list.add(r);
/*     */       }
/* 642 */       this.result.close();
/* 643 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 645 */       e.printStackTrace();
/*     */     }
/* 647 */     return list;
/*     */   }
/*     */ 
/*     */   public List<TempArea> getTemplateInfo(String tid)
/*     */   {
/* 654 */     List list = new ArrayList();
/*     */     try {
/* 656 */       this.statement = this.dbconn.getConnection().prepareStatement("select t.i_area_no,t.c_type_no from t_s_area t where t.s_stencil_no=?");
/* 657 */       this.statement.setString(1, tid);
/* 658 */       this.result = this.statement.executeQuery();
/*     */ 
/* 660 */       while (this.result.next()) {
/* 661 */         TempArea ta = new TempArea();
/* 662 */         ta.setArea(this.result.getString("i_area_no"));
/* 663 */         ta.setType(this.result.getString("c_type_no"));
/* 664 */         list.add(ta);
/*     */       }
/* 666 */       this.result.close();
/* 667 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 669 */       e.printStackTrace();
/*     */     }
/* 671 */     return list;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getWDInfo()
/*     */   {
/* 678 */     Map map = new HashMap();
/*     */     try {
/* 680 */       this.statement = this.dbconn.getConnection().prepareStatement("select t.i_field_type,t.s_field from T_S_WD_INFO t");
/* 681 */       this.result = this.statement.executeQuery();
/* 682 */       while (this.result.next()) {
/* 683 */         map.put(this.result.getString("i_field_type"), this.result.getString("s_field"));
/*     */       }
/* 685 */       this.result.close();
/* 686 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 688 */       e.printStackTrace();
/*     */     }
/* 690 */     return map;
/*     */   }
/*     */ 
/*     */   public Fodder getFodder(String fid, String d)
/*     */   {
/* 699 */     Fodder fodder = null;
/*     */     try {
/* 701 */       this.statement = this.dbconn.getConnection().prepareStatement("");
/* 702 */       this.statement.setString(1, fid);
/* 703 */       this.statement.setString(2, d);
/* 704 */       this.statement.setString(3, d);
/* 705 */       this.result = this.statement.executeQuery();
/* 706 */       while (this.result.next()) {
/* 707 */         fodder = new Fodder();
/* 708 */         fodder.setFid(this.result.getString("s_fodder_no"));
/* 709 */         fodder.setUrl(this.result.getString("s_fodder_doc_name"));
/* 710 */         fodder.setLinkurl(this.result.getString("s_url"));
/*     */       }
/* 712 */       this.result.close();
/* 713 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 715 */       e.printStackTrace();
/* 716 */       return null;
/*     */     }
/* 718 */     return fodder;
/*     */   }
/*     */ 
/*     */   public List<Foldout> getFoldout(String bid, String cid, String billdate)
/*     */   {
/* 729 */     List list = new ArrayList();
/* 730 */     Foldout foldout = null;
/*     */     try {
/* 732 */       this.statement = this.dbconn.getConnection().prepareStatement("select * from T_S_FOLDOUT_PROD t2 where t2.i_id= (select t.i_id from T_S_FOLDOUT_PROD_SUB t where t.s_foldout_nusinpnt_no=? and t.s_foldout_prod_bpid=? and t.c_period=substr(?,7,2) and to_date(?,'yyyyMMdd') >= to_date(t.c_period_begen,'yyyy-MM')and to_date(?,'yyyyMMdd') <= to_date(t.c_period_end,'yyyy-MM')) order by t2.i_foldout_index");
/* 733 */       this.statement.setString(1, bid);
/* 734 */       this.statement.setString(2, cid);
/* 735 */       this.statement.setString(3, billdate);
/* 736 */       this.statement.setString(4, billdate);
/* 737 */       this.statement.setString(5, billdate);
/* 738 */       this.result = this.statement.executeQuery();
/* 739 */       while (this.result.next()) {
/* 740 */         foldout = new Foldout();
/* 741 */         foldout.setId(this.result.getString("I_FOLDOUT_INDEX"));
/* 742 */         foldout.setName(this.result.getString("S_FOLDOUT_PROD_NAME"));
/* 743 */         foldout.setPri(this.result.getInt("I_FOLDOUT_PRI"));
/* 744 */         list.add(foldout);
/*     */       }
/* 746 */       this.result.close();
/* 747 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 749 */       e.printStackTrace();
/* 750 */       return null;
/*     */     }
/* 752 */     return list;
/*     */   }
/*     */ 
/*     */   public Map<String, String> getFoldoutCity(String id, String idx)
/*     */   {
/* 765 */     Map map = new HashMap();
/* 766 */     String city = "";
/*     */     try {
/* 768 */       String sql = "select t.s_foldout_city from t_s_foldout_city t where t.i_id=? and t.i_foldout_index=?";
/* 769 */       this.statement = this.dbconn.getConnection().prepareStatement(sql);
/* 770 */       this.statement.setString(1, id);
/* 771 */       this.statement.setString(2, idx);
/* 772 */       this.result = this.statement.executeQuery();
/* 773 */       while (this.result.next()) {
/* 774 */         city = this.result.getString("s_foldout_city");
/* 775 */         map.put(city, city);
/*     */       }
/* 777 */       this.result.close();
/* 778 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 780 */       e.printStackTrace();
/*     */     }
/*     */     finally {
/* 783 */       return map;
/*     */     }
/*     */   }
/*     */ 
/*     */   public int savePLogBegin(Plog log)
/*     */   {
/* 791 */     int ret = -1;
/*     */     try {
/* 793 */       this.statement = this.dbconn.getConnection().prepareStatement("insert into t_n_XML_LOG (S_PERIOD,S_FILENAME,S_BUSINPNT_NO,C_START_TIME,S_CARD_PROD_ID,S_PAPER_NO,C_STATE) values (?,?,?,?,?,?,'2')");
/* 794 */       this.statement.setString(1, log.getStmtdate());
/* 795 */       this.statement.setString(2, log.getFilename());
/* 796 */       this.statement.setString(3, log.getBusinpnt_no());
/* 797 */       this.statement.setString(4, log.getStart_time());
/* 798 */       this.statement.setString(5, log.getCard_id());
/* 799 */       this.statement.setString(6, log.getPaper_no());
/* 800 */       ret = this.statement.executeUpdate();
/* 801 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 803 */       e.printStackTrace();
/* 804 */       return ret;
/*     */     }
/* 806 */     return ret;
/*     */   }
/*     */ 
/*     */   public int savePLogEnd(Plog log)
/*     */   {
/* 812 */     int ret = -1;
/*     */     try {
/* 814 */       this.statement = this.dbconn.getConnection().prepareStatement("update t_n_XML_LOG set I_SHARE=?,C_END_TIME=?,C_STATE=? where S_FILENAME=?");
/* 815 */       this.statement.setInt(1, log.getShare());
/* 816 */       this.statement.setString(2, log.getEnd_time());
/* 817 */       this.statement.setString(3, log.getState());
/* 818 */       this.statement.setString(4, log.getFilename());
/* 819 */       ret = this.statement.executeUpdate();
/* 820 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 822 */       e.printStackTrace();
/* 823 */       return ret;
/*     */     }
/* 825 */     return ret;
/*     */   }
/*     */ 
/*     */   public int avePLogDel(Plog log)
/*     */   {
/* 833 */     int ret = -1;
/*     */     try {
/* 835 */       this.statement = this.dbconn.getConnection().prepareStatement("delete T_n_XML_LOG t where t.s_filename=?");
/* 836 */       this.statement.setString(1, log.getFilename());
/* 837 */       ret = this.statement.executeUpdate();
/* 838 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 840 */       e.printStackTrace();
/* 841 */       return ret;
/*     */     }
/* 843 */     return ret;
/*     */   }
/*     */ 
/*     */   public int saveProduct(String cardno, String cardname, String filepath, String billtype)
/*     */   {
/* 851 */     int ret = -1;
/*     */     try {
/* 853 */       this.statement = this.dbconn.getConnection().prepareStatement("insert into t_n_product t (t.card_no,t.card_name,t.filename,t.filepath,bill_type,create_date) values (?,?,?,?,?,to_char(sysdate,'yyyy-MM-dd hh:mi:ss'))");
/* 854 */       this.statement.setString(1, cardno);
/* 855 */       this.statement.setString(2, cardname);
/* 856 */       this.statement.setString(3, filepath.substring(filepath.lastIndexOf("/") + 1));
/* 857 */       this.statement.setString(4, filepath);
/* 858 */       this.statement.setString(5, billtype);
/* 859 */       ret = this.statement.executeUpdate();
/* 860 */       this.statement.close();
/*     */     } catch (SQLException e) {
/* 862 */       e.printStackTrace();
/* 863 */       return ret;
/*     */     }
/* 865 */     return ret;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.teshuXML.DBDao
 * JD-Core Version:    0.6.2
 */