/*     */ package com.bill.teshuXML;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.makeXML.handler.WriteXML;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ 
/*     */ public class PXml
/*     */   implements WriteXML
/*     */ {
/*     */   public RandomAccessFile filew;
/*     */   public File file;
/*     */ 
/*     */   public String create(String cardid, String wbs, String yyz, String cardtype)
/*     */   {
/*  36 */     String fpath = getFileInfo(wbs, cardtype);
/*  37 */     File temp = new File(fpath);
/*     */ 
/*  39 */     if (!temp.exists()) {
/*  40 */       temp.mkdirs();
/*     */     }
/*     */ 
/*  43 */     this.file = new File(fpath + "TNO_" + cardid + "_" + yyz + "_" + wbs + "_" + System.currentTimeMillis() + ".xml");
/*     */     try {
/*  45 */       if (this.file.exists()) {
/*  46 */         this.file.delete();
/*     */       }
/*     */ 
/*  49 */       if (this.file.createNewFile())
/*  50 */         this.filew = new RandomAccessFile(this.file.getPath(), "rw");
/*     */     }
/*     */     catch (IOException e) {
/*  53 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  56 */     write(BaseParam.XML_BEGIN);
/*  57 */     return this.file.getPath();
/*     */   }
/*     */ 
/*     */   public void write(String xml)
/*     */   {
/*     */     try
/*     */     {
/*  65 */       this.filew.write(xml.getBytes("utf-8"));
/*     */     } catch (IOException e) {
/*  67 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void over(int count)
/*     */   {
/*     */     try
/*     */     {
/*  77 */       this.filew.write(BaseParam.XML_END.getBytes("utf-8"));
/*  78 */       this.filew.close();
/*  79 */       if (count == 0)
/*  80 */         this.file.delete();
/*     */     }
/*     */     catch (IOException e) {
/*  83 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getFileInfo(String cardid, String cardtype)
/*     */   {
/*  95 */     return BaseParam.XML_PATH + cardtype + "/SPEC/XML/";
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/*  99 */     PXml p = new PXml();
/* 100 */     p.create("11", "22", "33", "44");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.teshuXML.PXml
 * JD-Core Version:    0.6.2
 */