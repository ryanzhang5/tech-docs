/*     */ package com.bill.teshuXML;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.makeXML.handler.WriteXML;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ 
/*     */ public class EXml
/*     */   implements WriteXML
/*     */ {
/*  18 */   public String path = "d:";
/*     */   public File file;
/*     */   public RandomAccessFile filew;
/*     */   private String cardid;
/*     */   private String cardtype;
/*     */ 
/*     */   public String create(String cardid, String cardtype)
/*     */   {
/*  39 */     this.cardid = cardid;
/*  40 */     this.cardtype = cardtype;
/*     */ 
/*  42 */     String fpath = getFileInfo(cardid, cardtype);
/*  43 */     File temp = new File(fpath);
/*     */ 
/*  45 */     if (!temp.exists()) {
/*  46 */       temp.mkdirs();
/*     */     }
/*     */ 
/*  49 */     this.file = new File(fpath + "HTML_" + cardid + "_" + System.currentTimeMillis() + ".xml");
/*     */     try {
/*  51 */       if (this.file.exists()) {
/*  52 */         this.file.delete();
/*     */       }
/*     */ 
/*  55 */       if (this.file.createNewFile()) {
/*  56 */         this.filew = new RandomAccessFile(this.file.getPath(), "rw");
/*  57 */         write(BaseParam.XML_BEGIN);
/*     */       }
/*     */     } catch (IOException e) {
/*  60 */       e.printStackTrace();
/*     */     }
/*  62 */     return this.file.getPath();
/*     */   }
/*     */ 
/*     */   public void write(String xml)
/*     */   {
/*  70 */     if (this.filew == null) {
/*  71 */       create(this.cardid, this.cardtype);
/*     */     }
/*     */     try
/*     */     {
/*  75 */       this.filew.write(xml.getBytes("utf-8"));
/*     */     } catch (IOException e) {
/*  77 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void over(int count)
/*     */   {
/*  85 */     write(BaseParam.XML_END);
/*     */     try {
/*  87 */       this.filew.close();
/*     */     } catch (IOException e) {
/*  89 */       e.printStackTrace();
/*     */     } finally {
/*  91 */       this.filew = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void close(int count) {
/*     */     try {
/*  97 */       write(BaseParam.XML_END);
/*  98 */       this.filew.close();
/*  99 */       if (count == 0)
/* 100 */         this.file.delete();
/*     */     }
/*     */     catch (IOException e) {
/* 103 */       e.printStackTrace();
/*     */     } finally {
/* 105 */       this.filew = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getFileInfo(String cardid, String cardtype)
/*     */   {
/* 117 */     return BaseParam.XML_PATH + cardtype + "/SPEC/XML/";
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/* 121 */     EXml e = new EXml();
/* 122 */     e.create("5678", "");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.teshuXML.EXml
 * JD-Core Version:    0.6.2
 */