/*     */ package com.bill.teshuXML;
/*     */ 
/*     */ import com.bill.bean.Debitinfo;
/*     */ import com.bill.bean.Fodder;
/*     */ import com.bill.bean.Foldout;
/*     */ import com.bill.bean.PointInfo;
/*     */ import com.bill.bean.Rule;
/*     */ import com.bill.bean.RuleF;
/*     */ import com.bill.bean.RuleM;
/*     */ import com.bill.bean.TempArea;
/*     */ import com.bill.bean.UserAccinfo;
/*     */ import com.bill.bean.UserAccinfoDetail;
/*     */ import com.bill.bean.UserBase;
/*     */ import com.bill.bean.UserBuy;
/*     */ import com.bill.bean.Util;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class UserXml
/*     */ {
/*     */   private StringBuffer tab1;
/*     */   private StringBuffer tab2;
/*     */   private StringBuffer temp;
/*     */   private List<StringBuffer> tab2list;
/*     */   private List<UserAccinfo> listAccinfo;
/*     */   private List<UserAccinfoDetail> listAccinfoDetail;
/*     */   private List<Debitinfo> listDebitinfo;
/*     */   private List<PointInfo> listPointInfo;
/*     */   private List<Foldout> list;
/*     */   private List<TempArea> plist;
/*     */   private List<RuleF> rlist;
/*     */   private List<RuleF> dlist;
/*     */   private List<RuleM> mlist;
/*     */   private List<Rule> rulelist;
/*     */   private PointInfo point;
/*     */   private UserBuy ub;
/*  34 */   private Logger log = null;
/*     */ 
/*     */   public UserXml() {
/*  37 */     this.log = Logger.getLogger(UserXml.class);
/*     */   }
/*     */ 
/*     */   public void writeBaseXml(UserBase ub, StringBuffer xml)
/*     */   {
/*  46 */     xml.append("<acctnbr>" + ub.getAcctnbr() + "</acctnbr>\n");
/*  47 */     xml.append("<rectype>" + ub.getRectype() + "</rectype>\n");
/*  48 */     xml.append("<zip>" + ub.getZip() + "</zip>\n");
/*  49 */     xml.append("<addrname3>" + ub.getAddrname3() + " </addrname3>\n");
/*  50 */     xml.append("<addrname1>" + ub.getAddrname1() + " </addrname1>\n");
/*  51 */     xml.append("<addrname2>" + ub.getAddrname2() + " </addrname2>\n");
/*  52 */     xml.append("<name>" + ub.getName() + " </name>\n");
/*  53 */     xml.append("<sex>" + ub.getSex() + "</sex>\n");
/*  54 */     xml.append("<birthday>" + ub.getBirthday() + "</birthday>\n");
/*  55 */     xml.append("<accnum>" + ub.getAccnum() + "</accnum>\n");
/*  56 */     xml.append("<cusnum>" + ub.getCusnum() + "</cusnum>\n");
/*  57 */     xml.append("<stfromdate>" + ub.getStfromdate() + "</stfromdate>\n");
/*  58 */     xml.append("<enddate>" + ub.getEnddate() + "</enddate>\n");
/*  59 */     xml.append("<specode>" + ub.getSpecode() + "</specode>\n");
/*  60 */     xml.append("<pmtduemark>" + ub.getPmtduemark() + "</pmtduemark>\n");
/*  61 */     xml.append("<cashmark>" + ub.getCashmark() + "</cashmark>\n");
/*  62 */     xml.append("<indiv1>" + ub.getIndiv1() + "</indiv1>\n");
/*  63 */     xml.append("<indiv2>" + ub.getIndiv2() + "</indiv2>\n");
/*  64 */     xml.append("<indiv3>" + ub.getIndiv3() + "</indiv3>\n");
/*  65 */     xml.append("<indiv4>" + ub.getIndiv4() + "</indiv4>\n");
/*  66 */     xml.append("<indiv5>" + ub.getIndiv5() + "</indiv5>\n");
/*  67 */     xml.append("<indiv6>" + ub.getIndiv6() + "</indiv6>\n");
/*  68 */     xml.append("<indiv7>" + ub.getIndiv7() + "</indiv7>\n");
/*  69 */     xml.append("<indiv8>" + ub.getIndiv8() + "</indiv8>\n");
/*  70 */     xml.append("<actinfo>" + ub.getActinfo() + "</actinfo>\n");
/*  71 */     xml.append("<dm1>" + ub.getDm1() + "</dm1>\n");
/*  72 */     xml.append("<dm2>" + ub.getDm2() + "</dm2>\n");
/*  73 */     xml.append("<dm3>" + ub.getDm3() + "</dm3>\n");
/*  74 */     xml.append("<dm4>" + ub.getDm4() + "</dm4>\n");
/*  75 */     xml.append("<brandmsg1>" + ub.getBrandmsg1() + "</brandmsg1>\n");
/*  76 */     xml.append("<brandmsg2>" + ub.getBrandmsg2() + "</brandmsg2>\n");
/*  77 */     xml.append("<brandmsg3>" + ub.getBrandmsg3() + "</brandmsg3>\n");
/*  78 */     xml.append("<brandmsg4>" + ub.getBrandmsg4() + "</brandmsg4>\n");
/*  79 */     xml.append("<brandmsg5>" + ub.getBrandmsg5() + "</brandmsg5>\n");
/*  80 */     xml.append("<brandmsg6>" + ub.getBrandmsg6() + "</brandmsg6>\n");
/*  81 */     xml.append("<brandmsg7>" + ub.getBrandmsg7() + "</brandmsg7>\n");
/*  82 */     xml.append("<convexchmark>" + ub.getConvexchmark() + "</convexchmark>\n");
/*  83 */     xml.append("<vipmsg1>" + ub.getVipmsg1() + "</vipmsg1>\n");
/*  84 */     xml.append("<vipmsg2>" + ub.getVipmsg2() + "</vipmsg2>\n");
/*  85 */     xml.append("<vipmsg3>" + ub.getVipmsg3() + "</vipmsg3>\n");
/*  86 */     xml.append("<vipmsg4>" + ub.getVipmsg4() + "</vipmsg4>\n");
/*  87 */     xml.append("<reprintflag>" + ub.getReprintflag() + "</reprintflag>\n");
/*  88 */     xml.append("<emailflag>" + ub.getEmailflag() + "</emailflag>\n");
/*  89 */     xml.append("<paperflag>" + ub.getPaperflag() + "</paperflag>\n");
/*  90 */     xml.append("<emailaddr>" + ub.getEmailaddr() + "</emailaddr>\n");
/*  91 */     xml.append("<custtype>" + ub.getCusttype() + "</custtype>\n");
/*  92 */     xml.append("<mobilenbr>" + ub.getMobilenbr() + "</mobilenbr>\n");
/*  93 */     xml.append("<ainbr>" + ub.getAinbr() + "</ainbr>\n");
/*  94 */     xml.append("<mobdate>" + ub.getMobdate() + "</mobdate>\n");
/*  95 */     xml.append("<filler>" + ub.getFiller() + "</filler>\n");
/*  96 */     xml.append("<citycode>" + ub.getCity() + "</citycode>\n");
/*     */   }
/*     */ 
/*     */   public void writeEnvrule(String wbs, UserBase ub, StringBuffer xml)
/*     */   {
/* 105 */     this.list = Cache.getFoldout(wbs, ub.getCardNo());
/* 106 */     String tag = "";
/* 107 */     String temp = "";
/* 108 */     Foldout f = null;
/* 109 */     if (this.list.size() > 0) {
/* 110 */       for (int i = 0; i < this.list.size(); i++) {
/* 111 */         f = (Foldout)this.list.get(0);
/*     */ 
/* 113 */         if ("0".equals(f.getState())) {
/* 114 */           tag = tag + "0";
/* 115 */           temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*     */         }
/* 117 */         else if ("1".equals(f.getState())) {
/* 118 */           switch (i) {
/*     */           case 0:
/* 120 */             if ("Y".equals(ub.getDm1())) {
/* 121 */               tag = tag + "1";
/* 122 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*     */             } else {
/* 124 */               tag = tag + "0";
/* 125 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*     */             }
/* 127 */             break;
/*     */           case 1:
/* 129 */             if ("Y".equals(ub.getDm2())) {
/* 130 */               tag = tag + "1";
/* 131 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*     */             } else {
/* 133 */               tag = tag + "0";
/* 134 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*     */             }
/* 136 */             break;
/*     */           case 2:
/* 138 */             if ("Y".equals(ub.getDm3())) {
/* 139 */               tag = tag + "1";
/* 140 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*     */             } else {
/* 142 */               tag = tag + "0";
/* 143 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*     */             }
/* 145 */             break;
/*     */           case 3:
/* 147 */             if ("Y".equals(ub.getDm4())) {
/* 148 */               tag = tag + "1";
/* 149 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*     */             } else {
/* 151 */               tag = tag + "0";
/* 152 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*     */             }
/* 154 */             break;
/*     */           default:
/* 156 */             tag = tag + "0";
/* 157 */             temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/* 158 */             break;
/*     */           }
/*     */         }
/* 161 */         else if ("2".equals(f.getState())) {
/* 162 */           Map city = Cache.getFoldoutCity(f.getId(), f.getIdx());
/* 163 */           if (city.containsKey(ub.getCity())) {
/* 164 */             tag = tag + "1";
/* 165 */             temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*     */           } else {
/* 167 */             tag = tag + "0";
/* 168 */             temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*     */           }
/*     */         } else {
/* 171 */           tag = tag + "0";
/* 172 */           temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*     */         }
/*     */       }
/*     */     } else {
/* 176 */       tag = "0000";
/* 177 */       temp = "<INPRIORITY1>0</INPRIORITY1>\n<INPRIORITY2>0</INPRIORITY2>\n<INPRIORITY3>0</INPRIORITY3>\n<INPRIORITY4>0</INPRIORITY4>\n";
/*     */     }
/* 179 */     xml.append("<ENVRULE>" + tag + "</ENVRULE>\n");
/* 180 */     xml.append(temp);
/*     */   }
/*     */ 
/*     */   public boolean writeAccinfoXml(UserBase ub, StringBuffer xml)
/*     */   {
/* 188 */     this.tab1 = new StringBuffer();
/* 189 */     this.tab2 = new StringBuffer();
/*     */ 
/* 191 */     this.listAccinfo = Cache.getUserInfo(ub.getAcctnbr());
/*     */ 
/* 193 */     for (UserAccinfo ua : this.listAccinfo)
/*     */     {
/* 195 */       if ("B001".equals(ua.getRectype())) {
/* 196 */         readAccinfo(this.tab1, ua);
/*     */       }
/* 198 */       else if ("D001".equals(ua.getRectype())) {
/* 199 */         readAccinfo(this.tab2, ua);
/*     */       }
/*     */     }
/*     */ 
/* 203 */     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
/* 204 */       xml.append("<accinfo>\n");
/* 205 */       if (this.tab1.length() > 0) {
/* 206 */         xml.append("<tab1>\n");
/* 207 */         xml.append(this.tab1.toString());
/* 208 */         xml.append("</tab1>\n");
/*     */       }
/* 210 */       if (this.tab2.length() > 0) {
/* 211 */         xml.append("<tab2>\n");
/* 212 */         xml.append(this.tab2.toString());
/* 213 */         xml.append("</tab2>\n");
/*     */       }
/* 215 */       xml.append("</accinfo>\n");
/* 216 */       return false;
/*     */     }
/* 218 */     return true;
/*     */   }
/*     */ 
/*     */   private void readAccinfo(StringBuffer sb, UserAccinfo ua) {
/* 222 */     sb.append("<acctnbr>" + ua.getAcctnbr() + "</acctnbr>\n");
/* 223 */     sb.append("<rectype>" + ua.getRectype() + "</rectype>\n");
/* 224 */     sb.append("<stmtdate>" + ua.getStmtdate() + "</stmtdate>\n");
/* 225 */     sb.append("<pmtdate>" + ua.getPmtdate() + "</pmtdate>\n");
/* 226 */     sb.append("<totbegbal>" + ua.getTotbegbal() + "</totbegbal>\n");
/* 227 */     sb.append("<plantotpmt>" + ua.getPlantotpmt() + "</plantotpmt>\n");
/* 228 */     sb.append("<plantotnrlamt>" + ua.getPlantotnrlamt() + "</plantotnrlamt>\n");
/* 229 */     sb.append("<plantotadjamt>" + ua.getPlantotadjamt() + "</plantotadjamt>\n");
/* 230 */     sb.append("<intdueamt>" + ua.getIntdueamt() + "</intdueamt>\n");
/* 231 */     sb.append("<currbal>" + ua.getCurrbal() + "</currbal>\n");
/* 232 */     sb.append("<totdueamt>" + ua.getTotdueamt() + "</totdueamt>\n");
/* 233 */     sb.append("<pmtprint>" + ua.getPmtprint() + "</pmtprint>\n");
/* 234 */     sb.append("<crlim>" + ua.getCrlim() + "</crlim>\n");
/* 235 */     sb.append("<cashcrlim>" + ua.getCashcrlim() + "</cashcrlim>\n");
/* 236 */     sb.append("<pmtarn>" + ua.getPmtarn() + "</pmtarn>\n");
/* 237 */     sb.append("<pmtadn>" + ua.getPmtadn() + "</pmtadn>\n");
/* 238 */     sb.append("<projap>" + ua.getProjap() + "</projap>\n");
/* 239 */     sb.append("<pmtaflag>" + ua.getPmtaflag() + "</pmtaflag>\n");
/* 240 */     sb.append("<achflag>" + ua.getAchflag() + "</achflag>\n");
/* 241 */     sb.append("<pmtflag>" + ua.getPmtflag() + "</pmtflag>\n");
/* 242 */     sb.append("<filler>" + ua.getFiller() + "</filler>\n");
/*     */   }
/*     */ 
/*     */   public void writeAccinfoDetail(UserBase ub, StringBuffer xml)
/*     */   {
/* 251 */     this.tab1 = new StringBuffer();
/* 252 */     this.tab2 = new StringBuffer();
/* 253 */     this.listAccinfoDetail = Cache.getAccinfoDetail(ub);
/* 254 */     for (UserAccinfoDetail uad : this.listAccinfoDetail)
/*     */     {
/* 256 */       if ("C001".equals(uad.getRectype())) {
/* 257 */         readAccinfoDetail(this.tab1, uad);
/*     */       }
/* 259 */       else if ("E001".equals(uad.getRectype())) {
/* 260 */         readAccinfoDetail(this.tab2, uad);
/*     */       }
/*     */     }
/*     */ 
/* 264 */     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
/* 265 */       xml.append("<transinfo>\n");
/* 266 */       if (this.tab1.length() > 0) {
/* 267 */         xml.append("<tab1>\n<lists>\n");
/* 268 */         xml.append(this.tab1.toString());
/* 269 */         xml.append("</lists>\n</tab1>\n");
/*     */       }
/* 271 */       if (this.tab2.length() > 0) {
/* 272 */         xml.append("<tab2>\n<lists>\n");
/* 273 */         xml.append(this.tab2.toString());
/* 274 */         xml.append("</lists>\n</tab2>\n");
/*     */       }
/* 276 */       xml.append("</transinfo>\n");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void readAccinfoDetail(StringBuffer sb, UserAccinfoDetail uad) {
/* 281 */     sb.append("<list>\n");
/* 282 */     sb.append("<acctnbr>" + uad.getAcctnbr() + "</acctnbr>\n");
/* 283 */     sb.append("<rectype>" + uad.getRectype() + "</rectype>\n");
/* 284 */     sb.append("<recseq>" + uad.getRecseq() + "</recseq>\n");
/* 285 */     sb.append("<effdate>" + uad.getEffdate() + "</effdate>\n");
/* 286 */     sb.append("<postdate>" + uad.getPostdate() + "</postdate>\n");
/* 287 */     sb.append("<cardnlast4>" + uad.getCardnlast4() + "</cardnlast4>\n");
/* 288 */     sb.append("<desc>" + uad.getDesc() + "</desc>\n");
/* 289 */     sb.append("<txnamt>" + uad.getTxnamt() + "</txnamt>\n");
/* 290 */     sb.append("<srctamt>" + uad.getSrctamt() + "</srctamt>\n");
/* 291 */     sb.append("<srctcurr>" + uad.getSrctcurr() + "</srctcurr>\n");
/* 292 */     sb.append("<purcty>" + uad.getPurcty() + "</purcty>\n");
/* 293 */     sb.append("<filler>" + uad.getFiller() + "</filler>\n");
/* 294 */     sb.append("</list>\n");
/*     */   }
/*     */ 
/*     */   public void writeBuy(UserBase user, StringBuffer xml)
/*     */   {
/* 303 */     this.ub = Cache.getUserBuy(user);
/*     */ 
/* 305 */     if (this.ub == null) return;
/* 306 */     xml.append("<exchinfo>\n");
/* 307 */     xml.append("<acctnbr>" + this.ub.getAcctnbr() + "</acctnbr>\n");
/* 308 */     xml.append("<rectype>" + this.ub.getRectype() + "</rectype>\n");
/* 309 */     xml.append("<exchusdamt>" + this.ub.getExchusdamt() + "</exchusdamt>\n");
/* 310 */     xml.append("<sellrate>" + this.ub.getSellrate() + "</sellrate>\n");
/* 311 */     xml.append("<exchrmbamt>" + this.ub.getExchrmbamt() + "</exchrmbamt>\n");
/* 312 */     xml.append("<achrtnbr>" + this.ub.getAchrtnbr() + "</achrtnbr>\n");
/* 313 */     xml.append("<achdbnbr>" + this.ub.getAchdbnbr() + "</achdbnbr>\n");
/* 314 */     xml.append("<filler>" + this.ub.getFiller() + "</filler>\n");
/* 315 */     xml.append("</exchinfo>\n");
/*     */   }
/*     */ 
/*     */   public void writeDebitinfo(UserBase user, StringBuffer xml)
/*     */   {
/* 324 */     this.tab1 = new StringBuffer();
/* 325 */     this.tab2 = new StringBuffer();
/* 326 */     this.listDebitinfo = Cache.getDebitinfo(user);
/* 327 */     for (Debitinfo di : this.listDebitinfo) {
/* 328 */       if ("C002".equals(di.getRectype()))
/* 329 */         readDebitinfo(this.tab1, di);
/* 330 */       else if ("E002".equals(di.getRectype())) {
/* 331 */         readDebitinfo(this.tab2, di);
/*     */       }
/*     */     }
/*     */ 
/* 335 */     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
/* 336 */       xml.append("<debitinfo>\n");
/* 337 */       if (this.tab1.length() > 0) {
/* 338 */         xml.append("<tab1>\n<lists>\n");
/* 339 */         xml.append(this.tab1.toString());
/* 340 */         xml.append("</lists>\n</tab1>\n");
/*     */       }
/* 342 */       if (this.tab2.length() > 0) {
/* 343 */         xml.append("<tab2>\n<lists>\n");
/* 344 */         xml.append(this.tab2.toString());
/* 345 */         xml.append("</lists>\n</tab2>\n");
/*     */       }
/* 347 */       xml.append("</debitinfo>\n");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void readDebitinfo(StringBuffer temp, Debitinfo di) {
/* 352 */     temp.append("<list>\n");
/* 353 */     temp.append("<acctnbr>" + di.getAcctnbr() + "</acctnbr>\n");
/* 354 */     temp.append("<rectype>" + di.getRectype() + "</rectype>\n");
/* 355 */     temp.append("<custnbr>" + di.getCustnbr() + "</custnbr>\n");
/* 356 */     temp.append("<effdate>" + di.getEffdate() + "</effdate>\n");
/* 357 */     temp.append("<txndesc>" + di.getTxndesc() + "</txndesc>\n");
/* 358 */     temp.append("<txncity>" + di.getTxncity() + "</txncity>\n");
/* 359 */     temp.append("<currcode>" + di.getCurrcode() + "</currcode>\n");
/* 360 */     temp.append("<txnamt>" + di.getTxnamt() + "</txnamt>\n");
/* 361 */     temp.append("<cardl4>" + di.getCardl4() + "</cardl4>\n");
/* 362 */     temp.append("<filler>" + di.getFiller() + "</filler>\n");
/* 363 */     temp.append("</list>\n");
/*     */   }
/*     */ 
/*     */   public void writePoint(UserBase user, StringBuffer xml)
/*     */   {
/* 372 */     this.tab1 = new StringBuffer();
/* 373 */     this.tab2 = new StringBuffer();
/* 374 */     this.temp = new StringBuffer();
/*     */ 
/* 376 */     this.listPointInfo = Cache.getPoint(user.getCusnum());
/* 377 */     for (PointInfo pi : this.listPointInfo)
/*     */     {
/* 379 */       if ("3".equals(pi.getPointtype())) {
/* 380 */         readPoint(this.tab1, pi);
/* 381 */       } else if ("2".equals(pi.getPointtype())) {
/* 382 */         this.tab2 = new StringBuffer();
/* 383 */         readPoint(this.tab2, pi);
/* 384 */         this.tab2list.add(this.tab2);
/*     */       }
/*     */     }
/* 387 */     this.point = Cache.getPoint2(user.getCusnum());
/* 388 */     if (this.point != null) {
/* 389 */       this.temp.append("<tab3>\n");
/* 390 */       this.temp.append("<billdate>" + this.point.getBilldate() + "</billdate>\n");
/* 391 */       this.temp.append("<ecifno>" + this.point.getBusinessid() + "</ecifno>\n");
/* 392 */       this.temp.append("<curpavalia>" + this.point.getAblepoint() + "</curpavalia>\n");
/* 393 */       this.temp.append("<pointavabf>" + this.point.getLastbalpoint() + "</pointavabf>\n");
/* 394 */       this.temp.append("<newpoint>" + this.point.getAddpoint() + "</newpoint>\n");
/* 395 */       this.temp.append("<pointredee>" + this.point.getExpoint() + "</pointredee>\n");
/* 396 */       this.temp.append("<adpoints>" + this.point.getAdpoints() + "</adpoints>\n");
/* 397 */       this.temp.append("<invalidpoint>" + this.point.getEndpoints() + "</invalidpoint>\n");
/* 398 */       this.temp.append("</tab3>\n");
/*     */     }
/*     */ 
/* 402 */     if ((this.tab1.length() > 0) || (this.tab2list.size() > 0) || (this.temp.length() > 0)) {
/* 403 */       xml.append("<point-info>\n");
/* 404 */       if (this.tab1.length() > 0) {
/* 405 */         xml.append("<tab1>\n");
/* 406 */         xml.append(this.tab1.toString());
/* 407 */         xml.append("</tab1>\n");
/*     */       }
/* 409 */       if (this.tab2list.size() > 0) {
/* 410 */         xml.append("<tab2>\n<lists>\n");
/* 411 */         for (StringBuffer sb : this.tab2list) {
/* 412 */           xml.append("<list>\n" + sb.toString() + "</list>\n");
/*     */         }
/* 414 */         xml.append("</lists>\n</tab2>\n");
/*     */       }
/* 416 */       if (this.temp.length() > 0) {
/* 417 */         xml.append(this.temp.toString());
/*     */       }
/* 419 */       xml.append("</point-info>\n");
/*     */     }
/*     */   }
/*     */ 
/* 423 */   private void readPoint(StringBuffer sb, PointInfo pi) { if ((pi.getCardPointType() == null) || ("".equals(pi.getCardPointType())) || ("0".equals(pi.getCardPointType()))) {
/* 424 */       sb.append("<pointtype>" + pi.getPointtype() + "</pointtype>\n");
/*     */     }
/* 428 */     else if ("1".equals(pi.getCardPointType())) {
/* 429 */       sb.append("<pointtype>A</pointtype>\n");
/*     */     }
/* 431 */     else if ("2".equals(pi.getCardPointType())) {
/* 432 */       sb.append("<pointtype>B</pointtype>\n");
/*     */     }
/*     */ 
/* 435 */     sb.append("<pointtype>" + pi.getPointtype() + "</pointtype>\n");
/* 436 */     sb.append("<cardportid>" + pi.getCardportid() + "</cardportid>\n");
/* 437 */     sb.append("<businessid>" + pi.getBusinessid() + "</businessid>\n");
/* 438 */     sb.append("<ablepoint>" + pi.getAblepoint() + "</ablepoint>\n");
/* 439 */     sb.append("<lastbalpoint>" + pi.getLastbalpoint() + "</lastbalpoint>\n");
/* 440 */     sb.append("<addpoint>" + pi.getAddpoint() + "</addpoint>\n");
/* 441 */     sb.append("<expoint>" + pi.getExpoint() + "</expoint>\n");
/* 442 */     sb.append("<adpoints>" + pi.getAdpoints() + "</adpoints>\n");
/* 443 */     sb.append("<endpoints>" + pi.getEndpoints() + "</endpoints>\n");
/* 444 */     sb.append("<ecifno>" + pi.getEcifno() + "</ecifno>\n");
/* 445 */     sb.append("<startdate>" + pi.getStartdate() + "</startdate>\n");
/* 446 */     sb.append("<enddate>" + pi.getEnddate() + "</enddate>\n");
/* 447 */     sb.append("<wholeconsume>" + pi.getWholeconsume() + "</wholeconsume>\n");
/* 448 */     sb.append("<inconsume>" + pi.getInconsume() + "</inconsume>\n");
/* 449 */     sb.append("<outconsume>" + pi.getOutconsume() + "</outconsume>\n");
/* 450 */     sb.append("<wholemoney>" + pi.getWholemoney() + "</wholemoney>\n");
/* 451 */     sb.append("<inmoney>" + pi.getInmoney() + "</inmoney>\n");
/* 452 */     sb.append("<outmoney>" + pi.getOutmoney() + "</outmoney>\n");
/* 453 */     sb.append("<usedmoney>" + pi.getUsedmoney() + "</usedmoney>\n");
/* 454 */     sb.append("<lavemoney>" + pi.getLavemoney() + "</lavemoney>\n");
/* 455 */     sb.append("<validdate>" + pi.getValiddate() + "</validdate>\n");
/* 456 */     sb.append("<laddermoney>" + pi.getLaddermoney() + "</laddermoney>\n");
/* 457 */     sb.append("<ladderscale>" + pi.getLadderscale() + "</ladderscale>\n");
/*     */ 
/* 459 */     if ("2".equals(pi.getPointtype())) {
/* 460 */       sb.append("<card4>" + pi.getCard4() + "</card4>\n");
/*     */     }
/* 462 */     sb.append("<cardname>" + pi.getCardname() + "</cardname>\n");
/*     */   }
/*     */ 
/*     */   public StringBuffer writeTemplate(UserBase user, String type)
/*     */   {
/* 472 */     this.temp = new StringBuffer();
/*     */ 
/* 474 */     String ptId = (String)Cache.templateMap.get(user.getCardNo() + "_" + type);
/*     */ 
/* 476 */     this.plist = Cache.getTemplateInfo(ptId);
/*     */ 
/* 478 */     Fodder f = null;
/*     */ 
/* 480 */     boolean isExtis = false;
/* 481 */     this.temp.append("<resourcesinfo>\n<lists>\n");
/*     */ 
/* 483 */     for (TempArea ta : this.plist)
/*     */     {
/* 485 */       this.rulelist = Cache.getRuleMap(ptId, "1", ta.getArea());
/* 486 */       this.log.debug("规则主表信息.模板ID=" + ptId + ",区域ID=" + ta.getArea() + ",规则个数=" + this.rulelist.size());
/*     */ 
/* 488 */       if ((this.rulelist != null) && (this.rulelist.size() > 0))
/*     */       {
/* 490 */         for (Rule r : this.rulelist)
/*     */         {
/* 492 */           if (isExtis)
/*     */             break;
/* 494 */           this.rlist = Cache.getRuleFMap(r.getRuleid());
/* 495 */           if (this.rlist != null)
/*     */           {
/* 497 */             for (RuleF rf : this.rlist)
/*     */             {
/* 499 */               f = Cache.getFodder(rf.getFodder());
/*     */ 
/* 501 */               if (f != null)
/*     */               {
/* 504 */                 if ("3".equals(ta.getType())) {
/* 505 */                   isExtis = true;
/* 506 */                   readRuleXml(this.temp, type, ta.getArea(), rf.getPri(), f.getUrl(), f.getLinkurl());
/*     */                 }
/*     */                 else
/*     */                 {
/* 510 */                   this.mlist = Cache.getRuleFFList(rf.getId());
/*     */ 
/* 512 */                   if (readRule(this.mlist, user)) {
/* 513 */                     isExtis = true;
/*     */ 
/* 515 */                     readRuleXml(this.temp, type, ta.getArea(), rf.getPri(), f.getUrl(), f.getLinkurl());
/*     */                   }
/*     */ 
/* 518 */                   if (!"4".equals(ta.getType()))
/*     */                   {
/*     */                     break;
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 528 */       if (!isExtis) {
/* 529 */         this.rulelist = Cache.getRuleMap(ptId, "0", ta.getArea());
/* 530 */         if ((this.rulelist != null) && (this.rulelist.size() > 0))
/*     */         {
/* 532 */           this.dlist = Cache.getRuleFMap(((Rule)this.rulelist.get(0)).getRuleid());
/* 533 */           if (this.dlist != null)
/* 534 */             for (RuleF rf : this.dlist)
/*     */             {
/* 536 */               f = Cache.getFodder(rf.getFodder());
/*     */ 
/* 538 */               if (f == null) {
/* 539 */                 this.log.debug("没有默认规则的素材！模板=" + ptId + ",区域=" + ta.getArea() + ",素材=" + rf.getFodder());
/*     */               }
/*     */               else
/*     */               {
/* 543 */                 readRuleXml(this.temp, type, ta.getArea(), rf.getPri(), f.getUrl(), f.getLinkurl());
/* 544 */                 break;
/*     */               }
/*     */             }
/* 547 */           else this.log.debug("没有默认的规则！模板=" + ptId + ",区域=" + ta.getArea());
/*     */         }
/*     */       }
/*     */ 
/* 551 */       isExtis = false;
/*     */     }
/* 553 */     this.temp.append("</lists>\n</resourcesinfo>\n");
/* 554 */     return this.temp;
/*     */   }
/*     */ 
/*     */   public void readRuleXml(StringBuffer xml, String type, String area, String pri, String url, String link) {
/* 558 */     xml.append("<list>\n<billtype>");
/* 559 */     xml.append(type);
/* 560 */     xml.append("</billtype>\n<area>");
/* 561 */     xml.append(area);
/* 562 */     xml.append("</area>\n<priority>");
/* 563 */     xml.append(pri);
/* 564 */     xml.append("</priority>\n<rescontent>");
/* 565 */     xml.append(url);
/* 566 */     xml.append("</rescontent>\n<resurl>");
/* 567 */     xml.append(Util.changURL(link));
/* 568 */     xml.append("</resurl>\n</list>\n");
/*     */   }
/*     */ 
/*     */   public boolean readRule(List<RuleM> list, UserBase user)
/*     */   {
/* 578 */     boolean result = false;
/* 579 */     boolean oldresult = false;
/* 580 */     int next_if = 0;
/* 581 */     String wd = "";
/* 582 */     for (RuleM rm : list)
/*     */     {
/* 584 */       wd = (String)Cache.wdMap.get(rm.getFieldid());
/*     */ 
/* 586 */       if ("birthday".equals(wd)) {
/* 587 */         oldresult = checkValue(rm, user.birthday);
/*     */       }
/* 589 */       else if ("sex".equals(wd))
/*     */       {
/* 591 */         if (rm.getOpr1() != 0) {
/* 592 */           return false;
/*     */         }
/*     */ 
/* 595 */         oldresult = rm.getVal1().equals(user.sex);
/*     */       }
/* 597 */       else if ("city".equals(wd))
/*     */       {
/* 599 */         if (rm.getOpr1() != 0) {
/* 600 */           return false;
/*     */         }
/*     */ 
/* 603 */         oldresult = rm.getVal1().equals(user.city);
/*     */       }
/* 605 */       else if ("mobilenbr".equals(wd))
/*     */       {
/* 607 */         if (rm.getOpr1() != 0) {
/* 608 */           return false;
/*     */         }
/*     */ 
/* 611 */         if (user.mobilenbr.indexOf(rm.getVal1()) == 0)
/* 612 */           oldresult = true;
/*     */         else {
/* 614 */           oldresult = false;
/*     */         }
/*     */       }
/* 617 */       else if ("ainbr".equals(wd))
/*     */       {
/* 619 */         if (rm.getOpr1() != 0) {
/* 620 */           return false;
/*     */         }
/* 622 */         oldresult = rm.getVal1().equals(user.ainbr);
/*     */       }
/* 624 */       else if ("mobdate".equals(wd)) {
/* 625 */         oldresult = checkValue(rm, user.mobdate);
/*     */       }
/* 627 */       else if ("crlim".equals(wd)) {
/* 628 */         oldresult = checkValue(rm, user.crlim);
/*     */       }
/* 630 */       else if ("currbal".equals(wd)) {
/* 631 */         oldresult = checkValue(rm, user.currbal);
/*     */       }
/* 633 */       else if ("totdueamt".equals(wd)) {
/* 634 */         oldresult = checkValue(rm, user.totdueamt);
/*     */       }
/* 636 */       else if ("cashcrlim".equals(wd)) {
/* 637 */         oldresult = checkValue(rm, user.cashcrlim);
/*     */       }
/* 639 */       else if ("indiv1".equals(wd))
/*     */       {
/* 641 */         if (rm.getOpr1() != 0) {
/* 642 */           return false;
/*     */         }
/*     */ 
/* 645 */         oldresult = rm.getVal1().equals(user.indiv1);
/*     */       }
/* 647 */       else if ("indiv2".equals(wd))
/*     */       {
/* 649 */         if (rm.getOpr1() != 0) {
/* 650 */           return false;
/*     */         }
/*     */ 
/* 653 */         oldresult = rm.getVal1().equals(user.indiv2);
/*     */       }
/* 655 */       else if ("indiv3".equals(wd))
/*     */       {
/* 657 */         if (rm.getOpr1() != 0) {
/* 658 */           return false;
/*     */         }
/*     */ 
/* 661 */         oldresult = rm.getVal1().equals(user.indiv3);
/*     */       }
/* 663 */       else if ("indiv4".equals(wd))
/*     */       {
/* 665 */         if (rm.getOpr1() != 0) {
/* 666 */           return false;
/*     */         }
/*     */ 
/* 669 */         oldresult = rm.getVal1().equals(user.indiv4);
/*     */       }
/* 671 */       else if ("indiv5".equals(wd))
/*     */       {
/* 673 */         if (rm.getOpr1() != 0) {
/* 674 */           return false;
/*     */         }
/*     */ 
/* 677 */         oldresult = rm.getVal1().equals(user.indiv5);
/*     */       }
/* 679 */       else if ("indiv6".equals(wd))
/*     */       {
/* 681 */         if (rm.getOpr1() != 0) {
/* 682 */           return false;
/*     */         }
/*     */ 
/* 685 */         oldresult = rm.getVal1().equals(user.indiv6);
/*     */       }
/* 687 */       else if ("indiv7".equals(wd))
/*     */       {
/* 689 */         if (rm.getOpr1() != 0) {
/* 690 */           return false;
/*     */         }
/*     */ 
/* 693 */         oldresult = rm.getVal1().equals(user.indiv7);
/*     */       }
/* 695 */       else if ("indiv8".equals(wd))
/*     */       {
/* 697 */         if (rm.getOpr1() != 0) {
/* 698 */           return false;
/*     */         }
/*     */ 
/* 701 */         oldresult = rm.getVal1().equals(user.indiv8);
/*     */       }
/*     */ 
/* 704 */       if (next_if == 0) {
/* 705 */         result = oldresult;
/*     */       }
/* 707 */       else if (1 == next_if) {
/* 708 */         result = (result) && (oldresult);
/*     */       }
/* 710 */       else if (2 == next_if) {
/* 711 */         result = (result) || (oldresult);
/*     */       }
/*     */ 
/* 714 */       next_if = rm.getCif();
/*     */     }
/* 716 */     return result;
/*     */   }
/*     */ 
/*     */   private boolean checkValue(RuleM rm, Object val)
/*     */   {
/* 726 */     boolean result = false;
/* 727 */     boolean result1 = false;
/* 728 */     boolean result2 = false;
/* 729 */     float i_val = 0.0F;
/* 730 */     float i_val1 = 0.0F;
/* 731 */     float i_val2 = 0.0F;
/*     */     try
/*     */     {
/* 734 */       if ((val instanceof String))
/* 735 */         i_val = Float.valueOf(val.toString()).floatValue();
/*     */       else {
/* 737 */         i_val = ((Float)val).floatValue();
/*     */       }
/* 739 */       i_val1 = Float.parseFloat(rm.getVal1());
/* 740 */       i_val2 = Float.parseFloat(rm.getVal2());
/*     */     } catch (Exception e) {
/* 742 */       return false;
/*     */     }
/*     */ 
/* 746 */     if (rm.getOpr1() == 0)
/*     */     {
/* 748 */       result = rm.getVal1().equals(val);
/*     */     }
/*     */     else
/*     */     {
/* 754 */       if (1 == rm.getOpr1())
/* 755 */         result1 = i_val > i_val1;
/* 756 */       else if (2 == rm.getOpr1())
/* 757 */         result1 = i_val < i_val1;
/* 758 */       else if (3 == rm.getOpr1())
/* 759 */         result1 = i_val >= i_val1;
/* 760 */       else if (4 == rm.getOpr1()) {
/* 761 */         result1 = i_val <= i_val1;
/*     */       }
/*     */ 
/* 764 */       if (1 == rm.getOpr2())
/* 765 */         result2 = i_val > i_val2;
/* 766 */       else if (2 == rm.getOpr2())
/* 767 */         result2 = i_val < i_val2;
/* 768 */       else if (3 == rm.getOpr2())
/* 769 */         result2 = i_val >= i_val2;
/* 770 */       else if (4 == rm.getOpr2()) {
/* 771 */         result2 = i_val >= i_val2;
/*     */       }
/* 773 */       result = (result1) && (result2);
/*     */     }
/* 775 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.teshuXML.UserXml
 * JD-Core Version:    0.6.2
 */