/*      */ package com.bill.normal;
/*      */ 
/*      */ import com.bill.bean.BaseParam;
/*      */ import com.bill.bean.Debitinfo;
/*      */ import com.bill.bean.Fodder;
/*      */ import com.bill.bean.Foldout;
/*      */ import com.bill.bean.HisAmountBean;
/*      */ import com.bill.bean.PointInfo;
/*      */ import com.bill.bean.Rule;
/*      */ import com.bill.bean.RuleF;
/*      */ import com.bill.bean.RuleM;
/*      */ import com.bill.bean.Stageplan;
/*      */ import com.bill.bean.TempArea;
/*      */ import com.bill.bean.UserAccinfo;
/*      */ import com.bill.bean.UserAccinfoDetail;
/*      */ import com.bill.bean.UserBase;
/*      */ import com.bill.bean.UserBuy;
/*      */ import com.bill.makeXML.util.file.HisAmountToXml;
/*      */ import com.bill.util.DESUtil;
/*      */ import java.net.URLEncoder;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.apache.log4j.Logger;
/*      */ 
/*      */ public class UserXml
/*      */ {
/*      */   private StringBuffer tab1;
/*      */   private StringBuffer tab2;
/*      */   private StringBuffer temp;
/*      */   private List<StringBuffer> tab2list;
/*      */   private List<UserAccinfo> listAccinfo;
/*      */   private List<UserAccinfoDetail> listAccinfoDetail;
/*      */   private List<Debitinfo> listDebitinfo;
/*      */   private List<PointInfo> listPointInfo;
/*      */   private List<TempArea> plist;
/*      */   private List<RuleF> rlist;
/*      */   private List<RuleM> mlist;
/*      */   private List<Rule> rulelist;
/*      */   private PointInfo point;
/*      */   private UserBuy ub;
/*      */   private DBDao dao;
/*   54 */   private Logger log = null;
/*      */ 
/*  414 */   private StringBuffer type1 = new StringBuffer();
/*  415 */   private StringBuffer type2 = new StringBuffer();
/*  416 */   private StringBuffer type3 = new StringBuffer();
/*  417 */   private StringBuffer type4 = new StringBuffer();
/*      */ 
/*  573 */   private String cardid = "";
/*      */ 
/*  987 */   boolean isExtis = false;
/*      */ 
/*  996 */   private String ptId = "";
/*      */ 
/*      */   public UserXml(DBDao dao)
/*      */   {
/*   57 */     this.log = Logger.getLogger(UserXml.class);
/*   58 */     this.dao = dao;
/*      */   }
/*      */ 
/*      */   public String getBaseXml(UserBase ub)
/*      */   {
/*   68 */     StringBuffer str = new StringBuffer();
/*   69 */     str.append("<acctnbr>").append(ub.getAcctnbr()).append("</acctnbr>\n");
/*   70 */     str.append("<rectype>").append(ub.getRectype()).append("</rectype>\n");
/*   71 */     str.append("<zip>").append(ub.getZip()).append("</zip>\n");
/*   72 */     str.append("<addrname3>").append(ub.getAddrname3()).append("</addrname3>\n");
/*   73 */     str.append("<addrname1>").append(ub.getAddrname1()).append("</addrname1>\n");
/*   74 */     str.append("<addrname2>").append(ub.getAddrname2()).append("</addrname2>\n");
/*   75 */     str.append("<name>").append(ub.getName()).append("</name>\n");
/*   76 */     str.append("<sex>").append(ub.getSex()).append("</sex>\n");
/*   77 */     str.append("<birthday>").append(ub.getBirthday()).append("</birthday>\n");
/*   78 */     str.append("<accnum>").append(ub.getAccnum()).append("</accnum>\n");
/*   79 */     str.append("<cusnum>").append(ub.getCusnum()).append("</cusnum>\n");
/*   80 */     str.append("<stfromdate>").append(ub.getStfromdate()).append("</stfromdate>\n");
/*   81 */     str.append("<enddate>").append(ub.getEnddate()).append("</enddate>\n");
/*   82 */     str.append("<specode>").append(ub.getSpecode()).append("</specode>\n");
/*   83 */     str.append("<pmtduemark>").append(ub.getPmtduemark()).append("</pmtduemark>\n");
/*   84 */     str.append("<cashmark>").append(ub.getCashmark()).append("</cashmark>\n");
/*   85 */     str.append("<indiv1>").append(ub.getIndiv1()).append("</indiv1>\n");
/*   86 */     str.append("<indiv2>").append(ub.getIndiv2()).append("</indiv2>\n");
/*   87 */     str.append("<indiv3>").append(ub.getIndiv3()).append("</indiv3>\n");
/*   88 */     str.append("<indiv4>").append(ub.getIndiv4()).append("</indiv4>\n");
/*   89 */     str.append("<indiv5>").append(ub.getIndiv5()).append("</indiv5>\n");
/*   90 */     str.append("<indiv6>").append(ub.getIndiv6()).append("</indiv6>\n");
/*   91 */     str.append("<indiv7>").append(ub.getIndiv7()).append("</indiv7>\n");
/*   92 */     str.append("<indiv8>").append(ub.getIndiv8()).append("</indiv8>\n");
/*   93 */     str.append("<actinfo>").append(ub.getActinfo()).append("</actinfo>\n");
/*   94 */     str.append("<dm1>").append(ub.getDm1()).append("</dm1>\n");
/*   95 */     str.append("<dm2>").append(ub.getDm2()).append("</dm2>\n");
/*   96 */     str.append("<dm3>").append(ub.getDm3()).append("</dm3>\n");
/*   97 */     str.append("<dm4>").append(ub.getDm4()).append("</dm4>\n");
/*   98 */     str.append("<brandmsg1>").append(ub.getBrandmsg1()).append("</brandmsg1>\n");
/*   99 */     str.append("<brandmsg2>").append(ub.getBrandmsg2()).append("</brandmsg2>\n");
/*  100 */     str.append("<brandmsg3>").append(ub.getBrandmsg3()).append("</brandmsg3>\n");
/*  101 */     str.append("<brandmsg4>").append(ub.getBrandmsg4()).append("</brandmsg4>\n");
/*  102 */     str.append("<brandmsg5>").append(ub.getBrandmsg5()).append("</brandmsg5>\n");
/*  103 */     str.append("<brandmsg6>").append(ub.getBrandmsg6()).append("</brandmsg6>\n");
/*  104 */     str.append("<brandmsg7>").append(ub.getBrandmsg7()).append("</brandmsg7>\n");
/*  105 */     str.append("<convexchmark>").append(ub.getConvexchmark()).append("</convexchmark>\n");
/*  106 */     str.append("<vipmsg1>").append(ub.getVipmsg1()).append("</vipmsg1>\n");
/*  107 */     str.append("<vipmsg2>").append(ub.getVipmsg2()).append("</vipmsg2>\n");
/*  108 */     str.append("<vipmsg3>").append(ub.getVipmsg3()).append("</vipmsg3>\n");
/*  109 */     str.append("<vipmsg4>").append(ub.getVipmsg4()).append("</vipmsg4>\n");
/*  110 */     str.append("<reprintflag>").append(ub.getReprintflag()).append("</reprintflag>\n");
/*  111 */     str.append("<emailflag>").append(ub.getEmailflag()).append("</emailflag>\n");
/*  112 */     str.append("<paperflag>").append(ub.getPaperflag()).append("</paperflag>\n");
/*  113 */     str.append("<emailaddr>").append(ub.getEmailaddr()).append("</emailaddr>\n");
/*  114 */     str.append("<custtype>").append(ub.getCusttype()).append("</custtype>\n");
/*  115 */     str.append("<mobilenbr>").append(ub.getMobilenbr()).append("</mobilenbr>\n");
/*  116 */     str.append("<ainbr>").append(ub.getAinbr()).append("</ainbr>\n");
/*  117 */     str.append("<mobdate>").append(ub.getMobdate()).append("</mobdate>\n");
/*  118 */     str.append("<filler>").append(ub.getFiller()).append("</filler>\n");
/*  119 */     str.append("<citycode>").append(ub.getCity()).append("</citycode>\n");
/*  120 */     return str.toString();
/*      */   }
/*      */ 
/*      */   public void writeBaseXml(UserBase ub, StringBuffer xml)
/*      */   {
/*  130 */     xml.append("<acctnbr>" + ub.getAcctnbr() + "</acctnbr>\n");
/*  131 */     xml.append("<rectype>" + ub.getRectype() + "</rectype>\n");
/*  132 */     xml.append("<zip>" + ub.getZip() + "</zip>\n");
/*  133 */     xml.append("<addrname3>" + ub.getAddrname3() + " </addrname3>\n");
/*  134 */     xml.append("<addrname1>" + ub.getAddrname1() + " </addrname1>\n");
/*  135 */     xml.append("<addrname2>" + ub.getAddrname2() + " </addrname2>\n");
/*  136 */     xml.append("<name>" + ub.getName() + " </name>\n");
/*  137 */     xml.append("<sex>" + ub.getSex() + "</sex>\n");
/*  138 */     xml.append("<birthday>" + ub.getBirthday() + "</birthday>\n");
/*  139 */     xml.append("<accnum>" + ub.getAccnum() + "</accnum>\n");
/*  140 */     xml.append("<cusnum>" + ub.getCusnum() + "</cusnum>\n");
/*  141 */     xml.append("<stfromdate>" + ub.getStfromdate() + "</stfromdate>\n");
/*  142 */     xml.append("<enddate>" + ub.getEnddate() + "</enddate>\n");
/*  143 */     xml.append("<specode>" + ub.getSpecode() + "</specode>\n");
/*  144 */     xml.append("<pmtduemark>" + ub.getPmtduemark() + "</pmtduemark>\n");
/*  145 */     xml.append("<cashmark>" + ub.getCashmark() + "</cashmark>\n");
/*  146 */     xml.append("<indiv1>" + ub.getIndiv1() + "</indiv1>\n");
/*  147 */     xml.append("<indiv2>" + ub.getIndiv2() + "</indiv2>\n");
/*  148 */     xml.append("<indiv3>" + ub.getIndiv3() + "</indiv3>\n");
/*  149 */     xml.append("<indiv4>" + ub.getIndiv4() + "</indiv4>\n");
/*  150 */     xml.append("<indiv5>" + ub.getIndiv5() + "</indiv5>\n");
/*  151 */     xml.append("<indiv6>" + ub.getIndiv6() + "</indiv6>\n");
/*  152 */     xml.append("<indiv7>" + ub.getIndiv7() + "</indiv7>\n");
/*  153 */     xml.append("<indiv8>" + ub.getIndiv8() + "</indiv8>\n");
/*  154 */     xml.append("<actinfo>" + ub.getActinfo() + "</actinfo>\n");
/*  155 */     xml.append("<dm1>" + ub.getDm1() + "</dm1>\n");
/*  156 */     xml.append("<dm2>" + ub.getDm2() + "</dm2>\n");
/*  157 */     xml.append("<dm3>" + ub.getDm3() + "</dm3>\n");
/*  158 */     xml.append("<dm4>" + ub.getDm4() + "</dm4>\n");
/*  159 */     xml.append("<brandmsg1>" + ub.getBrandmsg1() + "</brandmsg1>\n");
/*  160 */     xml.append("<brandmsg2>" + ub.getBrandmsg2() + "</brandmsg2>\n");
/*  161 */     xml.append("<brandmsg3>" + ub.getBrandmsg3() + "</brandmsg3>\n");
/*  162 */     xml.append("<brandmsg4>" + ub.getBrandmsg4() + "</brandmsg4>\n");
/*  163 */     xml.append("<brandmsg5>" + ub.getBrandmsg5() + "</brandmsg5>\n");
/*  164 */     xml.append("<brandmsg6>" + ub.getBrandmsg6() + "</brandmsg6>\n");
/*  165 */     xml.append("<brandmsg7>" + ub.getBrandmsg7() + "</brandmsg7>\n");
/*  166 */     xml.append("<convexchmark>" + ub.getConvexchmark() + "</convexchmark>\n");
/*  167 */     xml.append("<vipmsg1>" + ub.getVipmsg1() + "</vipmsg1>\n");
/*  168 */     xml.append("<vipmsg2>" + ub.getVipmsg2() + "</vipmsg2>\n");
/*  169 */     xml.append("<vipmsg3>" + ub.getVipmsg3() + "</vipmsg3>\n");
/*  170 */     xml.append("<vipmsg4>" + ub.getVipmsg4() + "</vipmsg4>\n");
/*  171 */     xml.append("<reprintflag>" + ub.getReprintflag() + "</reprintflag>\n");
/*  172 */     xml.append("<emailflag>" + ub.getEmailflag() + "</emailflag>\n");
/*  173 */     xml.append("<paperflag>" + ub.getPaperflag() + "</paperflag>\n");
/*  174 */     xml.append("<emailaddr>" + ub.getEmailaddr() + "</emailaddr>\n");
/*  175 */     xml.append("<custtype>" + ub.getCusttype() + "</custtype>\n");
/*  176 */     xml.append("<mobilenbr>" + ub.getMobilenbr() + "</mobilenbr>\n");
/*  177 */     xml.append("<ainbr>" + ub.getAinbr() + "</ainbr>\n");
/*  178 */     xml.append("<mobdate>" + ub.getMobdate() + "</mobdate>\n");
/*  179 */     xml.append("<filler>" + ub.getFiller() + "</filler>\n");
/*  180 */     xml.append("<citycode>" + ub.getCity() + "</citycode>\n");
/*      */   }
/*      */ 
/*      */   public String getEnvrule(String wbs, UserBase ub) {
/*  184 */     List list = Cache.getFoldout(wbs, ub.getCardNo(), this.dao);
/*  185 */     String tag = "";
/*  186 */     String temp = "";
/*  187 */     Foldout f = null;
/*  188 */     if (list.size() > 0) {
/*  189 */       for (int i = 0; i < list.size(); i++) {
/*  190 */         f = (Foldout)list.get(i);
/*      */ 
/*  192 */         if ("0".equals(f.getState())) {
/*  193 */           tag = tag + "0";
/*  194 */           temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */         }
/*  196 */         else if ("1".equals(f.getState())) {
/*  197 */           switch (i) {
/*      */           case 0:
/*  199 */             if ("Y".equals(ub.getDm1())) {
/*  200 */               tag = tag + "1";
/*  201 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*      */             } else {
/*  203 */               tag = tag + "0";
/*  204 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */             }
/*  206 */             break;
/*      */           case 1:
/*  208 */             if ("Y".equals(ub.getDm2())) {
/*  209 */               tag = tag + "1";
/*  210 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*      */             } else {
/*  212 */               tag = tag + "0";
/*  213 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */             }
/*  215 */             break;
/*      */           case 2:
/*  217 */             if ("Y".equals(ub.getDm3())) {
/*  218 */               tag = tag + "1";
/*  219 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*      */             } else {
/*  221 */               tag = tag + "0";
/*  222 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */             }
/*  224 */             break;
/*      */           case 3:
/*  226 */             if ("Y".equals(ub.getDm4())) {
/*  227 */               tag = tag + "1";
/*  228 */               temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*      */             } else {
/*  230 */               tag = tag + "0";
/*  231 */               temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */             }
/*  233 */             break;
/*      */           default:
/*  235 */             tag = tag + "0";
/*  236 */             temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*  237 */             break;
/*      */           }
/*      */         }
/*  240 */         else if ("2".equals(f.getState()))
/*      */         {
/*  242 */           Map city = Cache.getFoldoutCity(f.getId(), f.getIdx(), this.dao);
/*  243 */           if (city.containsKey(ub.getCity())) {
/*  244 */             tag = tag + "1";
/*  245 */             temp = temp + "<INPRIORITY" + (i + 1) + ">1</INPRIORITY" + (i + 1) + ">\n";
/*      */           } else {
/*  247 */             tag = tag + "0";
/*  248 */             temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */           }
/*      */         } else {
/*  251 */           tag = tag + "0";
/*  252 */           temp = temp + "<INPRIORITY" + (i + 1) + ">0</INPRIORITY" + (i + 1) + ">\n";
/*      */         }
/*      */       }
/*      */     } else {
/*  256 */       tag = "0000";
/*  257 */       temp = "<INPRIORITY1>0</INPRIORITY1>\n<INPRIORITY2>0</INPRIORITY2>\n<INPRIORITY3>0</INPRIORITY3>\n<INPRIORITY4>0</INPRIORITY4>\n";
/*      */     }
/*  259 */     String str = "<ENVRULE>" + tag + "</ENVRULE>\n" + temp;
/*  260 */     return str;
/*      */   }
/*      */ 
/*      */   public String getAccInfoXml(UserBase ub)
/*      */   {
/*  315 */     this.tab1 = new StringBuffer();
/*  316 */     this.tab2 = new StringBuffer();
/*      */ 
/*  318 */     this.listAccinfo = this.dao.getUserInfo(ub);
/*      */ 
/*  320 */     for (UserAccinfo ua : this.listAccinfo)
/*      */     {
/*  322 */       if ("B001".equals(ua.getRectype())) {
/*  323 */         readAccinfo(this.tab1, ua);
/*      */       }
/*  325 */       else if ("D001".equals(ua.getRectype())) {
/*  326 */         readAccinfo(this.tab2, ua);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  331 */     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
/*  332 */       StringBuilder xml = new StringBuilder();
/*  333 */       xml.append("<accinfo>\n");
/*  334 */       if (this.tab1.length() > 0) {
/*  335 */         xml.append("<tab1>\n");
/*  336 */         xml.append(this.tab1.toString());
/*  337 */         xml.append("</tab1>\n");
/*      */       }
/*  339 */       if (this.tab2.length() > 0) {
/*  340 */         xml.append("<tab2>\n");
/*  341 */         xml.append(this.tab2.toString());
/*  342 */         xml.append("</tab2>\n");
/*      */       }
/*  344 */       xml.append("</accinfo>\n");
/*  345 */       return xml.toString();
/*      */     }
/*  347 */     return null;
/*      */   }
/*      */ 
/*      */   public boolean writeAccinfoXml(UserBase ub, StringBuffer xml)
/*      */   {
/*  357 */     this.tab1 = new StringBuffer();
/*  358 */     this.tab2 = new StringBuffer();
/*      */ 
/*  360 */     this.listAccinfo = this.dao.getUserInfo(ub);
/*      */ 
/*  362 */     for (UserAccinfo ua : this.listAccinfo)
/*      */     {
/*  364 */       if ("B001".equals(ua.getRectype())) {
/*  365 */         readAccinfo(this.tab1, ua);
/*      */       }
/*  367 */       else if ("D001".equals(ua.getRectype())) {
/*  368 */         readAccinfo(this.tab2, ua);
/*      */       }
/*      */     }
/*      */ 
/*  372 */     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
/*  373 */       xml.append("<accinfo>\n");
/*  374 */       if (this.tab1.length() > 0) {
/*  375 */         xml.append("<tab1>\n");
/*  376 */         xml.append(this.tab1.toString());
/*  377 */         xml.append("</tab1>\n");
/*      */       }
/*  379 */       if (this.tab2.length() > 0) {
/*  380 */         xml.append("<tab2>\n");
/*  381 */         xml.append(this.tab2.toString());
/*  382 */         xml.append("</tab2>\n");
/*      */       }
/*  384 */       xml.append("</accinfo>\n");
/*  385 */       return false;
/*      */     }
/*  387 */     return true;
/*      */   }
/*      */ 
/*      */   private void readAccinfo(StringBuffer sb, UserAccinfo ua) {
/*  391 */     sb.append("<acctnbr>" + ua.getAcctnbr() + "</acctnbr>\n");
/*  392 */     sb.append("<rectype>" + ua.getRectype() + "</rectype>\n");
/*  393 */     sb.append("<stmtdate>" + ua.getStmtdate() + "</stmtdate>\n");
/*  394 */     sb.append("<pmtdate>" + ua.getPmtdate() + "</pmtdate>\n");
/*  395 */     sb.append("<totbegbal>" + ua.getTotbegbal() + "</totbegbal>\n");
/*  396 */     sb.append("<plantotpmt>" + ua.getPlantotpmt() + "</plantotpmt>\n");
/*  397 */     sb.append("<plantotnrlamt>" + ua.getPlantotnrlamt() + "</plantotnrlamt>\n");
/*  398 */     sb.append("<plantotadjamt>" + ua.getPlantotadjamt() + "</plantotadjamt>\n");
/*  399 */     sb.append("<intdueamt>" + ua.getIntdueamt() + "</intdueamt>\n");
/*  400 */     sb.append("<currbal>" + ua.getCurrbal() + "</currbal>\n");
/*  401 */     sb.append("<totdueamt>" + ua.getTotdueamt() + "</totdueamt>\n");
/*  402 */     sb.append("<pmtprint>" + ua.getPmtprint() + "</pmtprint>\n");
/*  403 */     sb.append("<crlim>" + ua.getCrlim() + "</crlim>\n");
/*  404 */     sb.append("<cashcrlim>" + ua.getCashcrlim() + "</cashcrlim>\n");
/*  405 */     sb.append("<pmtarn>" + ua.getPmtarn() + "</pmtarn>\n");
/*  406 */     sb.append("<pmtadn>" + ua.getPmtadn() + "</pmtadn>\n");
/*  407 */     sb.append("<projap>" + ua.getProjap() + "</projap>\n");
/*  408 */     sb.append("<pmtaflag>" + ua.getPmtaflag() + "</pmtaflag>\n");
/*  409 */     sb.append("<achflag>" + ua.getAchflag() + "</achflag>\n");
/*  410 */     sb.append("<pmtflag>" + ua.getPmtflag() + "</pmtflag>\n");
/*  411 */     sb.append("<filler>" + ua.getFiller() + "</filler>\n");
/*      */   }
/*      */ 
/*      */   public String getAccinfoDetail(UserBase ub)
/*      */   {
/*  425 */     this.tab1 = new StringBuffer();
/*  426 */     this.tab2 = new StringBuffer();
/*      */ 
/*  428 */     this.type1 = new StringBuffer();
/*  429 */     this.type2 = new StringBuffer();
/*  430 */     this.type3 = new StringBuffer();
/*  431 */     this.type4 = new StringBuffer();
/*      */ 
/*  436 */     this.listAccinfoDetail = this.dao.getAccinfoDetail(ub);
/*      */ 
/*  438 */     String type = "";
/*  439 */     for (UserAccinfoDetail uad : this.listAccinfoDetail)
/*      */     {
/*  442 */       if ("".equals(uad.getMcc()))
/*  443 */         uad.setMcc("00000");
/*  444 */       else if (!Cache.mccmap.containsKey(uad.getMcc())) {
/*  445 */         uad.setMcc("00000");
/*      */       }
/*      */ 
/*  449 */       if ("C001".equals(uad.getRectype())) {
/*  450 */         if ("".equals(type)) {
/*  451 */           type = "C001";
/*      */         }
/*  453 */         readAccinfoDetail1(uad);
/*      */       }
/*  472 */       else if ("E001".equals(uad.getRectype())) {
/*  473 */         if ("C001".equals(type)) {
/*  474 */           if (this.type1.length() > 0) {
/*  475 */             this.tab1.append(this.type1)
/*  476 */               .append("</card>\n</lists>\n</type1>\n");
/*      */           }
/*  478 */           if (this.type2.length() > 0) {
/*  479 */             this.tab1.append(this.type2)
/*  480 */               .append("</card>\n</user>\n</lists>\n</type2>\n");
/*      */           }
/*  482 */           if (this.type3.length() > 0) {
/*  483 */             this.tab1.append(this.type3)
/*  484 */               .append("</lists>\n</type3>\n");
/*      */           }
/*  486 */           if (this.type4.length() > 0) {
/*  487 */             this.tab1.append(this.type4)
/*  488 */               .append("</lists>\n</type4>\n");
/*      */           }
/*      */         }
/*  491 */         if (("".equals(type)) || ("C001".equals(type))) {
/*  492 */           type = "E001";
/*  493 */           this.type1 = new StringBuffer();
/*  494 */           this.type2 = new StringBuffer();
/*  495 */           this.type3 = new StringBuffer();
/*  496 */           this.type4 = new StringBuffer();
/*      */         }
/*      */ 
/*  499 */         readAccinfoDetail1(uad);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  515 */     if ("C001".equals(type)) {
/*  516 */       if (this.type1.length() != 0) {
/*  517 */         this.tab1.append(this.type1)
/*  518 */           .append("</card>\n</lists>\n</type1>\n");
/*      */       }
/*  520 */       if (this.type2.length() != 0) {
/*  521 */         this.tab1.append(this.type2)
/*  522 */           .append("</card>\n</user>\n</lists>\n</type2>\n");
/*      */       }
/*  524 */       if (this.type3.length() != 0) {
/*  525 */         this.tab1.append(this.type3)
/*  526 */           .append("</lists>\n</type3>\n");
/*      */       }
/*  528 */       if (this.type4.length() != 0) {
/*  529 */         this.tab1.append(this.type4)
/*  530 */           .append("</lists>\n</type4>\n");
/*      */       }
/*      */     }
/*  533 */     else if ("E001".equals(type)) {
/*  534 */       if (this.type1.length() != 0) {
/*  535 */         this.tab2.append(this.type1)
/*  536 */           .append("</card>\n</lists>\n</type1>\n");
/*      */       }
/*  538 */       if (this.type2.length() != 0) {
/*  539 */         this.tab2.append(this.type2)
/*  540 */           .append("</card>\n</user>\n</lists>\n</type2>\n");
/*      */       }
/*  542 */       if (this.type3.length() != 0) {
/*  543 */         this.tab2.append(this.type3)
/*  544 */           .append("</lists>\n</type3>\n");
/*      */       }
/*  546 */       if (this.type4.length() != 0) {
/*  547 */         this.tab2.append(this.type4)
/*  548 */           .append("</lists>\n</type4>\n");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  553 */     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
/*  554 */       StringBuilder xml = new StringBuilder();
/*  555 */       xml.append("<transinfo>\n");
/*  556 */       if (this.tab1.length() > 0) {
/*  557 */         xml.append("<tab1>\n");
/*  558 */         xml.append(this.tab1.toString());
/*  559 */         xml.append("</tab1>\n");
/*      */       }
/*  561 */       if (this.tab2.length() > 0) {
/*  562 */         xml.append("<tab2>\n");
/*  563 */         xml.append(this.tab2.toString());
/*  564 */         xml.append("</tab2>\n");
/*      */       }
/*  566 */       xml.append("</transinfo>\n");
/*  567 */       return xml.toString();
/*      */     }
/*  569 */     return "";
/*      */   }
/*      */ 
/*      */   private void readAccinfoDetail1(UserAccinfoDetail uad)
/*      */   {
/*  576 */     if (Cache.fqjyCard.containsKey(uad.getTxnCode())) {
/*  577 */       if (this.type3.length() == 0) {
/*  578 */         this.type3.append("<type3>\n").append("<lists>\n");
/*      */       }
/*  580 */       readAccinfoDetail3(this.type3, uad);
/*      */     }
/*  582 */     else if (("".equals(uad.getCardNbr())) || (uad.getCardNbr().startsWith("000299"))) {
/*  583 */       if (this.type4.length() == 0) {
/*  584 */         this.type4.append("<type4>\n").append("<lists>\n");
/*      */       }
/*  586 */       readAccinfoDetail3(this.type4, uad);
/*      */     }
/*  589 */     else if ("0".equals(uad.getMainAccount()))
/*      */     {
/*  591 */       if (this.type1.length() == 0) {
/*  592 */         this.type1.append("<type1>\n<lists>\n<card>\n<cname>")
/*  593 */           .append(uad.getCardName())
/*  594 */           .append("</cname>\n<last4>")
/*  595 */           .append(uad.getCardnlast4())
/*  596 */           .append("</last4>\n");
/*  597 */         this.cardid = uad.getCardNbr();
/*      */       }
/*  599 */       else if (!this.cardid.equals(uad.getCardNbr())) {
/*  600 */         this.type1.append("</card>\n<card>\n<cname>")
/*  601 */           .append(uad.getCardName())
/*  602 */           .append("</cname>\n<last4>")
/*  603 */           .append(uad.getCardnlast4())
/*  604 */           .append("</last4>\n");
/*  605 */         this.cardid = uad.getCardNbr();
/*      */       }
/*  607 */       readAccinfoDetail2(this.type1, uad);
/*      */     }
/*  609 */     else if ("1".equals(uad.getMainAccount()))
/*      */     {
/*  611 */       if (this.type2.length() == 0) {
/*  612 */         this.type2.append("<type2>\n<lists>\n<user>\n<user>")
/*  613 */           .append(uad.getCnName())
/*  614 */           .append("</user>\n<ename>")
/*  615 */           .append(uad.getPyName())
/*  616 */           .append("</ename>\n<card>\n<cname>")
/*  617 */           .append(uad.getCardName())
/*  618 */           .append("</cname>\n<last4>")
/*  619 */           .append(uad.getCardnlast4())
/*  620 */           .append("</last4>\n");
/*  621 */         this.cardid = uad.getCardNbr();
/*      */       }
/*  623 */       else if (!this.cardid.equals(uad.getCardNbr())) {
/*  624 */         this.type2.append("</card>\n</user>\n<user>\n")
/*  625 */           .append("<user>")
/*  626 */           .append(uad.getCnName())
/*  627 */           .append("</user>\n<ename>")
/*  628 */           .append(uad.getPyName())
/*  629 */           .append("</ename>\n<card>\n<cname>")
/*  630 */           .append(uad.getCardName())
/*  631 */           .append("</cname>\n<last4>")
/*  632 */           .append(uad.getCardnlast4())
/*  633 */           .append("</last4>\n");
/*  634 */         this.cardid = uad.getCardNbr();
/*      */       }
/*  636 */       readAccinfoDetail2(this.type2, uad);
/*      */     } else {
/*  638 */       if (this.type4.length() == 0) {
/*  639 */         this.type4.append("<type4>\n").append("<lists>\n");
/*      */       }
/*  641 */       readAccinfoDetail3(this.type4, uad);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void readAccinfoDetail2(StringBuffer sb, UserAccinfoDetail uad)
/*      */   {
/*  651 */     sb.append("<list>\n");
/*  652 */     sb.append("<acctnbr>" + uad.getAcctnbr() + "</acctnbr>\n");
/*  653 */     sb.append("<rectype>" + uad.getRectype() + "</rectype>\n");
/*  654 */     sb.append("<recseq>" + uad.getRecseq() + "</recseq>\n");
/*  655 */     sb.append("<effdate>" + uad.getEffdate() + "</effdate>\n");
/*  656 */     sb.append("<postdate>" + uad.getPostdate() + "</postdate>\n");
/*      */ 
/*  659 */     sb.append("<desc>" + uad.getDesc() + "</desc>\n");
/*  660 */     sb.append("<txnamt>" + uad.getTxnamt() + "</txnamt>\n");
/*  661 */     sb.append("<srctamt>" + uad.getSrctamt() + "</srctamt>\n");
/*  662 */     sb.append("<srctcurr>" + uad.getSrctcurr() + "</srctcurr>\n");
/*  663 */     sb.append("<purcty>" + uad.getPurcty() + "</purcty>\n");
/*  664 */     sb.append("<filler>" + uad.getFiller() + "</filler>\n");
/*  665 */     sb.append("<mccid>" + uad.getMcc() + "</mccid>\n");
/*      */ 
/*  668 */     sb.append("<mccmname></mccmname>\n");
/*  669 */     sb.append("<mccsname></mccsname>\n");
/*  670 */     sb.append("</list>\n");
/*      */   }
/*      */ 
/*      */   private void readAccinfoDetail3(StringBuffer sb, UserAccinfoDetail uad)
/*      */   {
/*  679 */     sb.append("<list>\n");
/*  680 */     sb.append("<acctnbr>" + uad.getAcctnbr() + "</acctnbr>\n");
/*  681 */     sb.append("<rectype>" + uad.getRectype() + "</rectype>\n");
/*  682 */     sb.append("<recseq>" + uad.getRecseq() + "</recseq>\n");
/*  683 */     sb.append("<effdate>" + uad.getEffdate() + "</effdate>\n");
/*  684 */     sb.append("<postdate>" + uad.getPostdate() + "</postdate>\n");
/*  685 */     sb.append("<desc>" + uad.getDesc() + "</desc>\n");
/*  686 */     sb.append("<txnamt>" + uad.getTxnamt() + "</txnamt>\n");
/*  687 */     sb.append("<srctamt>" + uad.getSrctamt() + "</srctamt>\n");
/*  688 */     sb.append("<srctcurr>" + uad.getSrctcurr() + "</srctcurr>\n");
/*  689 */     sb.append("<purcty>" + uad.getPurcty() + "</purcty>\n");
/*  690 */     sb.append("<filler>" + uad.getFiller() + "</filler>\n");
/*  691 */     sb.append("<cardlast4>").append(uad.getCardnlast4()).append("</cardlast4>\n");
/*  692 */     sb.append("<mccid>" + uad.getMcc() + "</mccid>\n");
/*      */ 
/*  695 */     sb.append("<mccmname></mccmname>\n");
/*  696 */     sb.append("<mccsname></mccsname>\n");
/*  697 */     sb.append("</list>\n");
/*      */   }
/*      */ 
/*      */   public String getBuy(UserBase user)
/*      */   {
/*  706 */     this.ub = this.dao.getUserBuy(user);
/*      */ 
/*  708 */     if (this.ub == null)
/*  709 */       return "";
/*  710 */     StringBuilder xml = new StringBuilder();
/*      */ 
/*  712 */     xml.append("<exchinfo>\n");
/*  713 */     xml.append("<acctnbr>" + this.ub.getAcctnbr() + "</acctnbr>\n");
/*  714 */     xml.append("<rectype>" + this.ub.getRectype() + "</rectype>\n");
/*  715 */     xml.append("<exchusdamt>" + this.ub.getExchusdamt() + "</exchusdamt>\n");
/*  716 */     xml.append("<sellrate>" + this.ub.getSellrate() + "</sellrate>\n");
/*  717 */     xml.append("<exchrmbamt>" + this.ub.getExchrmbamt() + "</exchrmbamt>\n");
/*  718 */     xml.append("<achrtnbr>" + this.ub.getAchrtnbr() + "</achrtnbr>\n");
/*  719 */     xml.append("<achdbnbr>" + this.ub.getAchdbnbr() + "</achdbnbr>\n");
/*  720 */     xml.append("<filler>" + this.ub.getFiller() + "</filler>\n");
/*  721 */     xml.append("</exchinfo>\n");
/*  722 */     return xml.toString();
/*      */   }
/*      */ 
/*      */   public String getDebitInfo(UserBase sb)
/*      */   {
/*  732 */     this.tab1 = new StringBuffer();
/*  733 */     this.tab2 = new StringBuffer();
/*  734 */     this.listDebitinfo = this.dao.getDebitinfo(sb);
/*  735 */     for (Debitinfo di : this.listDebitinfo) {
/*  736 */       if ("C002".equals(di.getRectype()))
/*  737 */         readDebitinfo(this.tab1, di);
/*  738 */       else if ("E002".equals(di.getRectype())) {
/*  739 */         readDebitinfo(this.tab2, di);
/*      */       }
/*      */     }
/*      */ 
/*  743 */     if ((this.tab1.length() != 0) || (this.tab2.length() != 0)) {
/*  744 */       StringBuilder xml = new StringBuilder();
/*  745 */       xml.append("<debitinfo>\n");
/*  746 */       if (this.tab1.length() > 0) {
/*  747 */         xml.append("<tab1>\n<lists>\n");
/*  748 */         xml.append(this.tab1.toString());
/*  749 */         xml.append("</lists>\n</tab1>\n");
/*      */       }
/*  751 */       if (this.tab2.length() > 0) {
/*  752 */         xml.append("<tab2>\n<lists>\n");
/*  753 */         xml.append(this.tab2.toString());
/*  754 */         xml.append("</lists>\n</tab2>\n");
/*      */       }
/*  756 */       xml.append("</debitinfo>\n");
/*  757 */       return xml.toString();
/*      */     }
/*  759 */     return "";
/*      */   }
/*      */ 
/*      */   private void readDebitinfo(StringBuffer temp, Debitinfo di) {
/*  763 */     temp.append("<list>\n");
/*  764 */     temp.append("<acctnbr>" + di.getAcctnbr() + "</acctnbr>\n");
/*  765 */     temp.append("<rectype>" + di.getRectype() + "</rectype>\n");
/*  766 */     temp.append("<custnbr>" + di.getCustnbr() + "</custnbr>\n");
/*  767 */     temp.append("<effdate>" + di.getEffdate() + "</effdate>\n");
/*  768 */     temp.append("<txndesc>" + di.getTxndesc() + "</txndesc>\n");
/*  769 */     temp.append("<txncity>" + di.getTxncity() + "</txncity>\n");
/*  770 */     temp.append("<currcode>" + di.getCurrcode() + "</currcode>\n");
/*  771 */     temp.append("<txnamt>" + di.getTxnamt() + "</txnamt>\n");
/*  772 */     temp.append("<cardl4>" + di.getCardl4() + "</cardl4>\n");
/*  773 */     temp.append("<filler>" + di.getFiller() + "</filler>\n");
/*  774 */     temp.append("</list>\n");
/*      */   }
/*      */ 
/*      */   public String getStageplan(UserBase sb)
/*      */   {
/*  783 */     List list = this.dao.getStageplan(sb);
/*  784 */     if ((list == null) || (list.size() == 0)) {
/*  785 */       return "";
/*      */     }
/*  787 */     StringBuffer tsb = new StringBuffer();
/*  788 */     tsb.append("<stageplan>\n<lists>\n");
/*  789 */     for (Stageplan s : list) {
/*  790 */       tsb.append("<list>\n")
/*  791 */         .append("<stagetype>").append(getStageTypeName(s.getStagetype())).append("</stagetype>\n")
/*  792 */         .append("<totalstage>").append(s.getTotalstage()).append("期</totalstage>\n")
/*  793 */         .append("<accstage>").append(s.getAccstage()).append("期</accstage>\n")
/*  794 */         .append("<totalamt>").append(s.getTotalamt()).append("</totalamt>\n")
/*  795 */         .append("<unaccamt>").append(s.getUnaccamt()).append("</unaccamt>\n")
/*  796 */         .append("<stagefee>").append(s.getStagefee()).append("</stagefee>\n")
/*  797 */         .append("<unaccfee>").append(s.getUnaccfee()).append("</unaccfee>\n")
/*  798 */         .append("</list>\n");
/*      */     }
/*  800 */     tsb.append("</lists>\n</stageplan>\n");
/*  801 */     return tsb.toString();
/*      */   }
/*      */ 
/*      */   private String getStageTypeName(String stageType) {
/*  805 */     if (Cache.stageTypeMap.get(stageType) != null) {
/*  806 */       return (String)Cache.stageTypeMap.get(stageType);
/*      */     }
/*  808 */     return stageType;
/*      */   }
/*      */ 
/*      */   public String getPoint(UserBase ub)
/*      */   {
/*  814 */     this.tab1 = new StringBuffer();
/*  815 */     this.tab2list = new ArrayList();
/*  816 */     this.temp = new StringBuffer();
/*      */ 
/*  819 */     this.listPointInfo = this.dao.getPoint(ub);
/*      */ 
/*  821 */     this.point = this.dao.getPoint2(ub);
/*      */ 
/*  823 */     for (PointInfo pi : this.listPointInfo)
/*      */     {
/*  825 */       if ("3".equals(pi.getPointtype())) {
/*  826 */         readPoint(this.tab1, pi);
/*  827 */       } else if ("2".equals(pi.getPointtype())) {
/*  828 */         this.tab2 = new StringBuffer();
/*  829 */         readPoint(this.tab2, pi);
/*  830 */         this.tab2list.add(this.tab2);
/*  831 */       } else if ("4".equals(pi.getPointtype())) {
/*  832 */         if (this.point == null) {
/*  833 */           this.point = new PointInfo();
/*  834 */           this.point.setBilldate(ub.getStmtdate());
/*  835 */           this.point.setBusinessid(ub.getCusnum().substring(7));
/*  836 */           this.point.setAblepoint("0");
/*  837 */           this.point.setExpirespoint("0");
/*      */         }
/*  839 */         this.point.setAddpoint(pi.getAddpoint());
/*  840 */         this.point.setAdpoints(pi.getAdpoints());
/*      */       }
/*      */     }
/*      */ 
/*  844 */     if (this.point != null) {
/*  845 */       this.temp.append("<tab3>\n");
/*  846 */       this.temp.append("<billdate>").append(this.point.getBilldate()).append("</billdate>\n");
/*  847 */       this.temp.append("<ecifno>").append(this.point.getBusinessid()).append("</ecifno>\n");
/*  848 */       this.temp.append("<curpavalia>").append(this.point.getAblepoint()).append("</curpavalia>\n");
/*  849 */       this.temp.append("<pointavabf>").append(this.point.getLastbalpoint()).append("</pointavabf>\n");
/*  850 */       this.temp.append("<newpoint>").append(this.point.getAddpoint()).append("</newpoint>\n");
/*  851 */       this.temp.append("<pointredee>").append(this.point.getExpoint()).append("</pointredee>\n");
/*  852 */       this.temp.append("<adpoints>").append(this.point.getAdpoints()).append("</adpoints>\n");
/*  853 */       this.temp.append("<invalidpoint>").append(this.point.getEndpoints()).append("</invalidpoint>\n");
/*  854 */       this.temp.append("<expirespoint>").append(this.point.getExpirespoint()).append("</expirespoint>\n");
/*  855 */       this.temp.append("</tab3>\n");
/*      */     }
/*      */ 
/*  858 */     if ((this.tab1.length() > 0) || (this.tab2list.size() > 0) || (this.temp.length() > 0)) {
/*  859 */       StringBuilder xml = new StringBuilder();
/*  860 */       xml.append("<point-info>\n");
/*  861 */       if (this.tab1.length() > 0) {
/*  862 */         xml.append("<tab1>\n");
/*  863 */         xml.append(this.tab1.toString());
/*  864 */         xml.append("</tab1>\n");
/*      */       }
/*  866 */       if (this.tab2list.size() > 0) {
/*  867 */         xml.append("<tab2>\n<lists>\n");
/*  868 */         for (StringBuffer sb : this.tab2list) {
/*  869 */           xml.append("<list>\n").append(sb).append("</list>\n");
/*      */         }
/*  871 */         xml.append("</lists>\n</tab2>\n");
/*      */       }
/*  873 */       if (this.temp.length() > 0) {
/*  874 */         xml.append(this.temp.toString());
/*      */       }
/*  876 */       xml.append("</point-info>\n");
/*  877 */       return xml.toString();
/*      */     }
/*  879 */     return "";
/*      */   }
/*      */ 
/*      */   public void writePoint(UserBase user, StringBuffer xml)
/*      */   {
/*  889 */     this.tab1 = new StringBuffer();
/*  890 */     this.tab2list = new ArrayList();
/*  891 */     this.temp = new StringBuffer();
/*      */ 
/*  894 */     this.listPointInfo = this.dao.getPoint(user);
/*  895 */     for (PointInfo pi : this.listPointInfo)
/*      */     {
/*  897 */       if ("3".equals(pi.getPointtype())) {
/*  898 */         readPoint(this.tab1, pi);
/*  899 */       } else if ("2".equals(pi.getPointtype())) {
/*  900 */         this.tab2 = new StringBuffer();
/*  901 */         readPoint(this.tab2, pi);
/*  902 */         this.tab2list.add(this.tab2);
/*      */       }
/*      */     }
/*      */ 
/*  906 */     this.point = this.dao.getPoint2(user);
/*  907 */     if (this.point != null) {
/*  908 */       this.temp.append("<tab3>\n");
/*  909 */       this.temp.append("<billdate>" + this.point.getBilldate() + "</billdate>\n");
/*  910 */       this.temp.append("<ecifno>" + this.point.getBusinessid() + "</ecifno>\n");
/*  911 */       this.temp.append("<curpavalia>" + this.point.getAblepoint() + "</curpavalia>\n");
/*  912 */       this.temp.append("<pointavabf>" + this.point.getLastbalpoint() + "</pointavabf>\n");
/*  913 */       this.temp.append("<newpoint>" + this.point.getAddpoint() + "</newpoint>\n");
/*  914 */       this.temp.append("<pointredee>" + this.point.getExpoint() + "</pointredee>\n");
/*  915 */       this.temp.append("<adpoints>" + this.point.getAdpoints() + "</adpoints>\n");
/*  916 */       this.temp.append("<invalidpoint>" + this.point.getEndpoints() + "</invalidpoint>\n");
/*  917 */       this.temp.append("<expirespoint>" + this.point.getExpirespoint() + "</expirespoint>\n");
/*  918 */       this.temp.append("</tab3>\n");
/*      */     }
/*      */ 
/*  921 */     if ((this.tab1.length() > 0) || (this.tab2list.size() > 0) || (this.temp.length() > 0)) {
/*  922 */       xml.append("<point-info>\n");
/*  923 */       if (this.tab1.length() > 0) {
/*  924 */         xml.append("<tab1>\n");
/*  925 */         xml.append(this.tab1.toString());
/*  926 */         xml.append("</tab1>\n");
/*      */       }
/*  928 */       if (this.tab2list.size() > 0) {
/*  929 */         xml.append("<tab2>\n<lists>\n");
/*  930 */         for (StringBuffer sb : this.tab2list) {
/*  931 */           xml.append("<list>\n" + sb.toString() + "</list>\n");
/*      */         }
/*  933 */         xml.append("</lists>\n</tab2>\n");
/*      */       }
/*  935 */       if (this.temp.length() > 0) {
/*  936 */         xml.append(this.temp.toString());
/*      */       }
/*  938 */       xml.append("</point-info>\n");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void readPoint(StringBuffer sb, PointInfo pi)
/*      */   {
/*  948 */     if ("1".equals(pi.getCardPointType())) {
/*  949 */       sb.append("<pointtype>A</pointtype>\n");
/*      */     }
/*  951 */     else if ("2".equals(pi.getCardPointType()))
/*  952 */       sb.append("<pointtype>B</pointtype>\n");
/*      */     else {
/*  954 */       sb.append("<pointtype>" + pi.getPointtype() + "</pointtype>\n");
/*      */     }
/*  956 */     sb.append("<cardportid>" + pi.getCardportid() + "</cardportid>\n");
/*  957 */     sb.append("<businessid>" + pi.getBusinessid() + "</businessid>\n");
/*  958 */     sb.append("<ablepoint>" + pi.getAblepoint() + "</ablepoint>\n");
/*  959 */     sb.append("<lastbalpoint>" + pi.getLastbalpoint() + "</lastbalpoint>\n");
/*  960 */     sb.append("<addpoint>" + pi.getAddpoint() + "</addpoint>\n");
/*  961 */     sb.append("<expoint>" + pi.getExpoint() + "</expoint>\n");
/*  962 */     sb.append("<adpoints>" + pi.getAdpoints() + "</adpoints>\n");
/*  963 */     sb.append("<endpoints>" + pi.getEndpoints() + "</endpoints>\n");
/*  964 */     sb.append("<ecifno>" + pi.getEcifno() + "</ecifno>\n");
/*  965 */     sb.append("<startdate>" + pi.getStartdate() + "</startdate>\n");
/*  966 */     sb.append("<enddate>" + pi.getEnddate() + "</enddate>\n");
/*  967 */     sb.append("<wholeconsume>" + pi.getWholeconsume() + "</wholeconsume>\n");
/*  968 */     sb.append("<inconsume>" + pi.getInconsume() + "</inconsume>\n");
/*  969 */     sb.append("<outconsume>" + pi.getOutconsume() + "</outconsume>\n");
/*  970 */     sb.append("<wholemoney>" + pi.getWholemoney() + "</wholemoney>\n");
/*  971 */     sb.append("<inmoney>" + pi.getInmoney() + "</inmoney>\n");
/*  972 */     sb.append("<outmoney>" + pi.getOutmoney() + "</outmoney>\n");
/*  973 */     sb.append("<usedmoney>" + pi.getUsedmoney() + "</usedmoney>\n");
/*  974 */     sb.append("<lavemoney>" + pi.getLavemoney() + "</lavemoney>\n");
/*  975 */     sb.append("<validdate>" + pi.getValiddate() + "</validdate>\n");
/*  976 */     sb.append("<laddermoney>" + pi.getLaddermoney() + "</laddermoney>\n");
/*  977 */     sb.append("<ladderscale>" + pi.getLadderscale() + "</ladderscale>\n");
/*      */ 
/*  979 */     if ("2".equals(pi.getPointtype())) {
/*  980 */       sb.append("<card4>" + pi.getCard4() + "</card4>\n");
/*      */     }
/*  982 */     sb.append("<cardname>" + pi.getCardname() + "</cardname>\n");
/*      */   }
/*      */ 
/*      */   public StringBuffer writeTemplate(UserBase user, String type)
/*      */   {
/*  998 */     this.temp = new StringBuffer();
/*  999 */     this.temp.append("<resourcesinfo>\n<lists>\n");
/* 1000 */     this.ptId = ((String)Cache.templateMap.get(user.getCardNo() + "_" + type));
/*      */ 
/* 1002 */     this.plist = Cache.getTemplateInfo(this.ptId, this.dao);
/*      */ 
/* 1004 */     int idx = 1;
/*      */ 
/* 1006 */     for (TempArea ta : this.plist) {
/* 1007 */       this.isExtis = false;
/* 1008 */       idx = 1;
/*      */ 
/* 1010 */       this.rulelist = Cache.getRuleMap(this.ptId, "1", ta.getArea(), this.dao);
/*      */ 
/* 1012 */       if ((this.rulelist != null) && (this.rulelist.size() > 0)) {
/* 1013 */         ruleXml(this.ptId, ta, type, idx, user, true);
/*      */       }
/*      */ 
/* 1016 */       if (!this.isExtis) {
/* 1017 */         this.rulelist = Cache.getRuleMap(this.ptId, "0", ta.getArea(), this.dao);
/* 1018 */         idx = 1;
/* 1019 */         if ((this.rulelist != null) && (this.rulelist.size() > 0)) {
/* 1020 */           ruleXml(this.ptId, ta, type, idx, user, false);
/*      */         }
/*      */       }
/* 1023 */       this.isExtis = false;
/*      */     }
/* 1025 */     this.temp.append("</lists>\n</resourcesinfo>\n");
/* 1026 */     return this.temp;
/*      */   }
/*      */ 
/*      */   public StringBuffer writeTemplateHtml5(UserBase user) {
/* 1030 */     this.temp = new StringBuffer();
/*      */ 
/* 1032 */     this.ptId = ((String)Cache.templateMap.get((String)Cache.prodIdMapping.get(user.getCardNo()) + "_3"));
/*      */ 
/* 1034 */     this.plist = Cache.getTemplateInfo(this.ptId, this.dao);
/*      */ 
/* 1036 */     int idx = 1;
/* 1037 */     this.temp.append("<html5resources>\n<lists>\n");
/*      */ 
/* 1040 */     for (TempArea ta : this.plist) {
/* 1041 */       this.isExtis = false;
/* 1042 */       idx = 1;
/*      */ 
/* 1044 */       this.rulelist = Cache.getRuleMap(this.ptId, "1", ta.getArea(), this.dao);
/*      */ 
/* 1046 */       if ((this.rulelist != null) && (this.rulelist.size() > 0)) {
/* 1047 */         ruleXml(this.ptId, ta, "3", idx, user, true);
/*      */       }
/*      */ 
/* 1050 */       if (!this.isExtis) {
/* 1051 */         this.rulelist = Cache.getRuleMap(this.ptId, "0", ta.getArea(), this.dao);
/* 1052 */         idx = 1;
/* 1053 */         if ((this.rulelist != null) && (this.rulelist.size() > 0)) {
/* 1054 */           ruleXml(this.ptId, ta, "3", idx, user, false);
/*      */         }
/*      */       }
/* 1057 */       this.isExtis = false;
/*      */     }
/* 1059 */     this.temp.append("</lists>\n</html5resources>\n");
/* 1060 */     return this.temp;
/*      */   }
/*      */ 
/*      */   public int ruleXml(String ptId, TempArea ta, String type, int idx, UserBase user, boolean isCheck)
/*      */   {
/* 1074 */     Fodder f = null;
/*      */ 
/* 1076 */     for (Rule rm : this.rulelist)
/*      */     {
/* 1078 */       if (this.isExtis)
/*      */       {
/*      */         break;
/*      */       }
/* 1082 */       this.rlist = Cache.getRuleFMap(rm.getRuleid(), this.dao);
/*      */ 
/* 1084 */       if (this.rlist != null)
/*      */       {
/* 1086 */         for (RuleF rf : this.rlist)
/*      */         {
/* 1089 */           f = Cache.getFodder(rf.getFodder(), this.dao);
/*      */ 
/* 1091 */           if (f == null) {
/* 1092 */             this.log.debug("素材无效!模板ID=" + ptId + ";区域规则ID=" + rm.getRuleid() + "条件个数=" + this.rlist.size() + ";素材=" + rf.getFodder());
/*      */           }
/* 1095 */           else if (isCheck)
/*      */           {
/* 1097 */             if ("3".equals(ta.getType())) {
/* 1098 */               this.isExtis = true;
/* 1099 */               readRuleXml(this.temp, type, ta.getArea(), Integer.valueOf(idx), f.getUrl(), f.getLinkurl());
/* 1100 */               idx++;
/*      */             }
/*      */             else
/*      */             {
/* 1104 */               this.mlist = Cache.getRuleFFList(rf.getId(), this.dao);
/*      */ 
/* 1108 */               if ((this.mlist == null) || (this.mlist.size() == 0) || (readRule(this.mlist, user))) {
/* 1109 */                 this.isExtis = true;
/*      */ 
/* 1111 */                 if ("4".equals(ta.getType()))
/*      */                 {
/* 1113 */                   readRuleXml(this.temp, type, ta.getArea(), Integer.valueOf(idx), f.getUrl(), f.getLinkurl());
/* 1114 */                   idx++;
/*      */                 }
/*      */                 else {
/* 1117 */                   readRuleXml(this.temp, type, ta.getArea(), rf.getPri(), f.getUrl(), f.getLinkurl());
/*      */ 
/* 1119 */                   break;
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */           else {
/* 1125 */             readRuleXml(this.temp, type, ta.getArea(), Integer.valueOf(idx), f.getUrl(), f.getLinkurl());
/* 1126 */             if ((!"3".equals(ta.getType())) && (!"4".equals(ta.getType()))) {
/*      */               break;
/*      */             }
/* 1129 */             idx++;
/*      */           }
/*      */         }
/*      */       }
/* 1133 */       else this.log.error("没有规则详情!模板ID=" + ptId + ";区域规则ID=" + rm.getRuleid());
/*      */     }
/*      */ 
/* 1136 */     return 0;
/*      */   }
/*      */ 
/*      */   public void readRuleXml(StringBuffer xml, String type, String area, Object pri, String url, String link)
/*      */   {
/* 1150 */     xml.append("<list>\n<billtype>");
/* 1151 */     xml.append(type);
/* 1152 */     xml.append("</billtype>\n<area>");
/* 1153 */     xml.append(area);
/* 1154 */     xml.append("</area>\n<priority>");
/* 1155 */     xml.append(pri);
/* 1156 */     xml.append("</priority>\n<rescontent>");
/* 1157 */     if ("1".equals(type)) {
/* 1158 */       xml.append(url);
/*      */     } else {
/* 1160 */       int i = url.lastIndexOf("/");
/* 1161 */       if (i != -1) {
/* 1162 */         xml.append((String)Cache.configMap.get("MATTERPATH"))
/* 1163 */           .append(url.substring(i + 1));
/*      */       }
/*      */       else {
/* 1166 */         xml.append(url);
/*      */       }
/*      */     }
/* 1169 */     xml.append("</rescontent>\n<resurl>");
/* 1170 */     xml.append(link);
/* 1171 */     xml.append("</resurl>\n</list>\n");
/*      */   }
/*      */ 
/*      */   public boolean readRule(List<RuleM> list, UserBase user)
/*      */   {
/* 1181 */     boolean result = false;
/* 1182 */     boolean oldresult = false;
/* 1183 */     int next_if = 0;
/* 1184 */     String wd = "";
/* 1185 */     for (RuleM rm : list)
/*      */     {
/* 1187 */       wd = rm.getFieldid();
/*      */ 
/* 1190 */       if ("birthday".equals(wd)) {
/* 1191 */         String temp = user.birthday;
/*      */ 
/* 1193 */         if (user.birthday.length() > 4) {
/* 1194 */           temp = user.birthday.substring(4);
/*      */         }
/* 1196 */         oldresult = checkValue(rm, temp);
/*      */       }
/* 1198 */       else if ("sex".equals(wd))
/*      */       {
/* 1200 */         if (rm.getOpr1() != 0) {
/* 1201 */           return false;
/*      */         }
/*      */ 
/* 1204 */         oldresult = rm.getVal1().equals(user.sex);
/*      */       }
/* 1206 */       else if ("city".equals(wd))
/*      */       {
/* 1208 */         if (rm.getOpr1() != 0) {
/* 1209 */           return false;
/*      */         }
/*      */ 
/* 1212 */         oldresult = rm.getVal1().equals(user.city);
/*      */       }
/* 1215 */       else if ("mobilenbr".equals(wd))
/*      */       {
/* 1217 */         if (rm.getOpr1() != 0) {
/* 1218 */           return false;
/*      */         }
/*      */ 
/* 1221 */         if (user.mobilenbr.indexOf(rm.getVal1()) == 0)
/* 1222 */           oldresult = true;
/*      */         else {
/* 1224 */           oldresult = false;
/*      */         }
/*      */       }
/* 1227 */       else if ("ainbr".equals(wd))
/*      */       {
/* 1229 */         if (rm.getOpr1() != 0) {
/* 1230 */           return false;
/*      */         }
/* 1232 */         oldresult = rm.getVal1().equals(user.ainbr);
/*      */       }
/* 1234 */       else if ("mobdate".equals(wd)) {
/* 1235 */         oldresult = checkValue(rm, user.mobdate);
/*      */       }
/* 1237 */       else if ("crlim".equals(wd)) {
/* 1238 */         oldresult = checkValue(rm, user.crlim);
/*      */       }
/* 1240 */       else if ("currbal".equals(wd)) {
/* 1241 */         oldresult = checkValue(rm, user.currbal);
/*      */       }
/* 1243 */       else if ("totdueamt".equals(wd)) {
/* 1244 */         oldresult = checkValue(rm, user.totdueamt);
/*      */       }
/* 1246 */       else if ("cashcrlim".equals(wd)) {
/* 1247 */         oldresult = checkValue(rm, user.cashcrlim);
/*      */       }
/* 1249 */       else if ("indiv1".equals(wd))
/*      */       {
/* 1251 */         if (rm.getOpr1() != 0) {
/* 1252 */           return false;
/*      */         }
/*      */ 
/* 1255 */         oldresult = rm.getVal1().equals(user.indiv1);
/*      */       }
/* 1257 */       else if ("indiv2".equals(wd))
/*      */       {
/* 1259 */         if (rm.getOpr1() != 0) {
/* 1260 */           return false;
/*      */         }
/*      */ 
/* 1263 */         oldresult = rm.getVal1().equals(user.indiv2);
/*      */       }
/* 1265 */       else if ("indiv3".equals(wd))
/*      */       {
/* 1267 */         if (rm.getOpr1() != 0) {
/* 1268 */           return false;
/*      */         }
/*      */ 
/* 1271 */         oldresult = rm.getVal1().equals(user.indiv3);
/*      */       }
/* 1273 */       else if ("indiv4".equals(wd))
/*      */       {
/* 1275 */         if (rm.getOpr1() != 0) {
/* 1276 */           return false;
/*      */         }
/*      */ 
/* 1279 */         oldresult = rm.getVal1().equals(user.indiv4);
/*      */       }
/* 1281 */       else if ("indiv5".equals(wd))
/*      */       {
/* 1283 */         if (rm.getOpr1() != 0) {
/* 1284 */           return false;
/*      */         }
/*      */ 
/* 1287 */         oldresult = rm.getVal1().equals(user.indiv5);
/*      */       }
/* 1289 */       else if ("indiv6".equals(wd))
/*      */       {
/* 1291 */         if (rm.getOpr1() != 0) {
/* 1292 */           return false;
/*      */         }
/*      */ 
/* 1295 */         oldresult = rm.getVal1().equals(user.indiv6);
/*      */       }
/* 1297 */       else if ("indiv7".equals(wd))
/*      */       {
/* 1299 */         if (rm.getOpr1() != 0) {
/* 1300 */           return false;
/*      */         }
/*      */ 
/* 1303 */         oldresult = rm.getVal1().equals(user.indiv7);
/*      */       }
/* 1305 */       else if ("indiv8".equals(wd))
/*      */       {
/* 1307 */         if (rm.getOpr1() != 0) {
/* 1308 */           return false;
/*      */         }
/*      */ 
/* 1311 */         oldresult = rm.getVal1().equals(user.indiv8);
/*      */       }
/*      */ 
/* 1314 */       if (next_if == 0) {
/* 1315 */         result = oldresult;
/*      */       }
/* 1317 */       else if (1 == next_if) {
/* 1318 */         result = (result) && (oldresult);
/*      */       }
/* 1320 */       else if (2 == next_if) {
/* 1321 */         result = (result) || (oldresult);
/*      */       }
/*      */ 
/* 1324 */       next_if = rm.getCif();
/*      */     }
/* 1326 */     return result;
/*      */   }
/*      */ 
/*      */   private boolean checkValue(RuleM rm, Object val)
/*      */   {
/* 1336 */     boolean result = false;
/* 1337 */     boolean result1 = false;
/* 1338 */     boolean result2 = false;
/* 1339 */     float i_val = 0.0F;
/* 1340 */     float i_val1 = 0.0F;
/* 1341 */     float i_val2 = 0.0F;
/*      */     try
/*      */     {
/* 1345 */       if ((val instanceof String))
/* 1346 */         i_val = Float.valueOf(val.toString()).floatValue();
/*      */       else {
/* 1348 */         i_val = ((Float)val).floatValue();
/*      */       }
/* 1350 */       i_val1 = Float.parseFloat(rm.getVal1());
/* 1351 */       if ((rm.getVal2() == null) || ("".equals(rm.getVal2())))
/* 1352 */         i_val2 = -1.0F;
/*      */       else
/* 1354 */         i_val2 = Float.parseFloat(rm.getVal2());
/*      */     }
/*      */     catch (Exception e) {
/* 1357 */       this.log.error("规则条件参数转型失败！参数1=" + rm.getVal1() + ",参数2=" + rm.getVal2());
/* 1358 */       return false;
/*      */     }
/*      */ 
/* 1362 */     if (rm.getOpr1() == 0)
/*      */     {
/* 1364 */       result = rm.getVal1().equals(val);
/*      */     }
/*      */     else
/*      */     {
/* 1369 */       if (1 == rm.getOpr1())
/* 1370 */         result1 = i_val > i_val1;
/* 1371 */       else if (2 == rm.getOpr1())
/* 1372 */         result1 = i_val < i_val1;
/* 1373 */       else if (3 == rm.getOpr1())
/* 1374 */         result1 = i_val >= i_val1;
/* 1375 */       else if (4 == rm.getOpr1()) {
/* 1376 */         result1 = i_val <= i_val1;
/*      */       }
/*      */ 
/* 1380 */       if (-1.0F == i_val2) {
/* 1381 */         result2 = false;
/*      */       }
/* 1383 */       else if (1 == rm.getOpr2())
/* 1384 */         result2 = i_val > i_val2;
/* 1385 */       else if (2 == rm.getOpr2())
/* 1386 */         result2 = i_val < i_val2;
/* 1387 */       else if (3 == rm.getOpr2())
/* 1388 */         result2 = i_val >= i_val2;
/* 1389 */       else if (4 == rm.getOpr2()) {
/* 1390 */         result2 = i_val >= i_val2;
/*      */       }
/*      */ 
/* 1393 */       result = (result1) && (result2);
/*      */     }
/* 1395 */     return result;
/*      */   }
/*      */ 
/*      */   public List<UserBase> getUserBase(String cardid, String city, int page, int size)
/*      */   {
/* 1404 */     return this.dao.getUserBase(cardid, city, page, size);
/*      */   }
/*      */ 
/*      */   public List<UserBase> getUserBase(String cardid, int page, int size)
/*      */   {
/* 1413 */     return this.dao.getUserBase(cardid, page, size);
/*      */   }
/*      */ 
/*      */   public void colse()
/*      */   {
/* 1419 */     this.dao.close();
/*      */   }
/*      */ 
/*      */   public String getHisAmount(UserBase ub)
/*      */   {
/* 1424 */     ArrayList data = this.dao.queryHisAmount(ub.getAccnum(), ub.getStmtdate());
/* 1425 */     String result = "";
/* 1426 */     HisAmountToXml haToXml = new HisAmountToXml(ub.getStmtdate());
/* 1427 */     result = "<historytrend>\n";
/* 1428 */     for (HisAmountBean bean : data) {
/* 1429 */       if ("B001".equals(bean.getType()))
/* 1430 */         result = result + haToXml.getHisAmount(bean, "tab1");
/* 1431 */       else if ("D001".equals(bean.getType())) {
/* 1432 */         result = result + haToXml.getHisAmount(bean, "tab2");
/*      */       }
/*      */     }
/* 1435 */     result = result + "</historytrend>\n";
/* 1436 */     return result;
/*      */   }
/*      */ 
/*      */   public String getClickInfo(UserBase ub)
/*      */   {
/* 1441 */     String imgUrl = BaseParam.PERIOD + "," + ub.acctnbr + "," + ub.cardNo + "," + 1;
/*      */ 
/* 1443 */     String clickUrl = BaseParam.PERIOD + "," + ub.acctnbr + "," + ub.cusnum + "," + ub.cardNo + "," + 1;
/*      */ 
/* 1445 */     StringBuffer res = new StringBuffer();
/*      */     try {
/* 1447 */       res
/* 1448 */         .append("<clickurl>")
/* 1449 */         .append((String)Cache.configMap.get("LINK_URL"))
/* 1450 */         .append("/bill/bcs?parameterStr=")
/* 1451 */         .append(URLEncoder.encode(Cache.des.encryptStr(clickUrl), "gbk"))
/* 1452 */         .append("</clickurl>\n<imgurl>")
/* 1453 */         .append((String)Cache.configMap.get("LINK_URL"))
/* 1454 */         .append("/bill/pic?parameterStr=")
/* 1455 */         .append(URLEncoder.encode(Cache.des.encryptStr(imgUrl), "gbk"))
/* 1456 */         .append("</imgurl>\n");
/*      */     } catch (Exception e) {
/* 1458 */       this.log.error(e);
/*      */     }
/* 1460 */     return res.toString();
/*      */   }
/*      */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.normal.UserXml
 * JD-Core Version:    0.6.2
 */