/*      */ package com.bill.normal;
/*      */ 
/*      */ import com.bill.bean.BaseParam;
/*      */ import com.bill.bean.Busin;
/*      */ import com.bill.bean.Card;
/*      */ import com.bill.bean.Debitinfo;
/*      */ import com.bill.bean.Fodder;
/*      */ import com.bill.bean.Foldout;
/*      */ import com.bill.bean.HisAmountBean;
/*      */ import com.bill.bean.Plog;
/*      */ import com.bill.bean.PointInfo;
/*      */ import com.bill.bean.Rule;
/*      */ import com.bill.bean.RuleF;
/*      */ import com.bill.bean.RuleM;
/*      */ import com.bill.bean.RuleMNew;
/*      */ import com.bill.bean.Stageplan;
/*      */ import com.bill.bean.TempArea;
/*      */ import com.bill.bean.UserAccinfo;
/*      */ import com.bill.bean.UserAccinfoDetail;
/*      */ import com.bill.bean.UserBase;
/*      */ import com.bill.bean.UserBuy;
/*      */ import com.bill.bean.Yyz;
/*      */ import com.bill.bean.mcc;
/*      */ import com.bill.db.DbConnectionForOracle;
/*      */ import com.bill.make.PaperRelatingWrap;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.apache.log4j.Logger;
/*      */ 
/*      */ public class DBDao
/*      */ {
/*      */   public DbConnectionForOracle dbconn;
/*      */   private PreparedStatement statement;
/*      */   private ResultSet result;
/*      */   public Logger log;
/*   49 */   private static String CARD_SQL = "select t.s_buss_prod_id,t.s_buss_prod_name,t.c_buss_type_id from T_S_BUSI_PROD_INFO t where t.c_buss_prod_flag='0' and t.C_BUSS_STATE='1' and t.c_buss_type_id='001'";
/*      */ 
/*   53 */   private static String BFPNT_SQL = "select t.s_id from t_s_befor_print_basic  t where  to_date(?,'yyyyMM')>= to_date(t.c_period_begen,'yyyy-MM') and to_date(?,'yyyyMM')<= to_date(t.c_period_end,'yyyy-MM') and t.c_period_day=?";
/*      */ 
/*   58 */   private static String CPB_CITY_SQL = "select t.s_city_no from t_s_bfpnt_cty_crdtp t where t.s_city_no is not null and t.s_card_no =? and t.s_id=? and t.s_businpnt_no=?";
/*      */ 
/*   63 */   private static String USER_BASE1 = "select * from (select tt.*, rownum RN from (select t.*, rownum from t_b_customer_bill t where C_CUR_PAPER_STMT_FLAG='Y' AND S_CARD_PROD_ID = ? and S_CITY_ID=? and rownum < ?) tt ) where RN >= ?";
/*      */ 
/*   65 */   private static String USER_BASE2 = "select * from (select tt.*, rownum RN from (select t.*, rownum from t_b_customer_bill t where S_CARD_PROD_ID = ? and rownum < ?) tt ) where RN >= ?";
/*      */ 
/*   70 */   private static String TEMPLATE_SQL = "select t.s_stencil_no,t.s_card_prod_id,t.c_type_no from T_S_STENCIL t where t.c_state='1'";
/*      */ 
/*   75 */   private static String RULE_SQL = "select * from t_s_rule_m t where t.s_stencil_no=? and t.c_rule_type=? and t.i_area_no=? and t.c_state='1' and to_date(?,'yyyyMM')>=to_date(t.c_period_begen,'yyyy-MM') and to_date(?,'yyyyMM')<=to_date(t.c_period_end,'yyyy-MM') and t.s_period like '%'||?||'%' order by t.i_pri desc";
/*      */ 
/* 1360 */   private static String CityYyyzWbsByCard_SQL = "select B.s_id,       B.S_BUSINPNT_NO,       A.S_PAPER_NO,       B.s_city_no,       A.i_print_pri,       (select t1.c_buss_type_id          from t_s_busi_prod_info t1         where t1.s_buss_prod_id = B.s_card_no) as c_buss_type_id  from (select t2.s_paper_no, t2.s_id,t2.i_print_pri          from t_s_befor_print_basic t2         where ? between t2.c_period_begen and t2.c_period_end           and t2.c_period_day = ?         order by t2.i_print_pri desc) A,       (select t.s_id, t.s_businpnt_no, t.s_card_no,t.s_city_no          from t_s_bfpnt_cty_crdtp t         where t.s_card_no = ?           AND t.s_id > '0'           and t.s_businpnt_no > '0') B         where A.s_Id = B.S_ID";
/*      */ 
/*      */   public DBDao()
/*      */   {
/*   81 */     this.dbconn = new DbConnectionForOracle(BaseParam.getDBIP(), 
/*   82 */       BaseParam.getDBPort(), BaseParam.getDBName(), BaseParam.getDBUser(), 
/*   83 */       BaseParam.getDBPwd());
/*   84 */     this.log = Logger.getLogger(DBDao.class);
/*      */   }
/*      */ 
/*      */   public static synchronized DBDao getInstance() {
/*   88 */     return new DBDao();
/*      */   }
/*      */ 
/*      */   public void close()
/*      */   {
/*   96 */     this.dbconn.close();
/*      */   }
/*      */ 
/*      */   public List<Busin> getBusin()
/*      */   {
/*  104 */     List list = new ArrayList();
/*      */     try {
/*  106 */       this.statement = this.dbconn
/*  107 */         .getConnection()
/*  108 */         .prepareStatement(
/*  109 */         "select t1.s_businpnt_no,t1.s_businpnt_name from T_S_EPLBOLY_PNT t1");
/*  110 */       this.result = this.statement.executeQuery();
/*      */ 
/*  112 */       while (this.result.next()) {
/*  113 */         Busin e = new Busin();
/*  114 */         e.setId(this.result.getString("s_businpnt_no"));
/*  115 */         e.setName(this.result.getString("s_businpnt_name"));
/*  116 */         list.add(e);
/*      */       }
/*  118 */       this.result.close();
/*  119 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  121 */       e.printStackTrace();
/*      */     }
/*  123 */     return list;
/*      */   }
/*      */ 
/*      */   public List<Card> getCard()
/*      */   {
/*  131 */     List list = new ArrayList();
/*      */     try {
/*  133 */       this.statement = this.dbconn.getConnection().prepareStatement(CARD_SQL);
/*  134 */       this.result = this.statement.executeQuery();
/*      */ 
/*  136 */       while (this.result.next()) {
/*  137 */         Card e = new Card();
/*  138 */         e.setId(this.result.getString("s_buss_prod_id"));
/*  139 */         e.setName(this.result.getString("s_buss_prod_name"));
/*  140 */         e.setType(this.result.getString("c_buss_type_id"));
/*  141 */         list.add(e);
/*      */       }
/*  143 */       this.result.close();
/*  144 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  146 */       e.printStackTrace();
/*      */     }
/*  148 */     return list;
/*      */   }
/*      */ 
/*      */   public Map<String, String> getBfpntMap()
/*      */   {
/*  156 */     Map map = new HashMap();
/*      */ 
/*  158 */     String ym = BaseParam.PERIOD.substring(0, 6);
/*      */ 
/*  160 */     String d = BaseParam.PERIOD.substring(6);
/*      */     try {
/*  162 */       this.statement = this.dbconn.getConnection().prepareStatement(BFPNT_SQL);
/*  163 */       this.statement.setString(1, ym);
/*  164 */       this.statement.setString(2, ym);
/*  165 */       this.statement.setString(3, d);
/*  166 */       this.result = this.statement.executeQuery();
/*      */ 
/*  168 */       String id = "";
/*  169 */       while (this.result.next()) {
/*  170 */         id = this.result.getString(1);
/*  171 */         map.put(id, id);
/*      */       }
/*  173 */       this.result.close();
/*  174 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  176 */       e.printStackTrace();
/*  177 */       return null;
/*      */     }
/*  179 */     return map;
/*      */   }
/*      */ 
/*      */   public Map<String, List<Yyz>> getCardBfpntMap()
/*      */   {
/*  187 */     Map map = new HashMap();
/*  188 */     StringBuffer sb = new StringBuffer();
/*  189 */     sb.append("select ");
/*  190 */     sb.append("t.s_card_no,t.s_id,t2.S_PAPER_NO");
/*  191 */     sb.append(" from t_s_bfpnt_cty_crdtp t,T_S_BEFOR_PRINT_BASIC t2");
/*  192 */     sb.append(" where ");
/*  193 */     sb.append("t.s_id=t2.s_id and t2.c_period_day=? and t2.c_period_begen<=? and t2.c_period_end>=?");
/*  194 */     sb.append(" group by t.s_card_no,t.s_id,t2.S_PAPER_NO");
/*      */     try {
/*  196 */       this.statement = this.dbconn
/*  197 */         .getConnection()
/*  198 */         .prepareStatement(sb.toString());
/*  199 */       this.statement.setString(1, BaseParam.PERIOD_D);
/*  200 */       this.statement.setString(2, BaseParam.PERIOD_Y + "-" + BaseParam.PERIOD_M);
/*  201 */       this.statement.setString(3, BaseParam.PERIOD_Y + "-" + BaseParam.PERIOD_M);
/*  202 */       this.result = this.statement.executeQuery();
/*      */ 
/*  204 */       String id1 = "";
/*      */ 
/*  206 */       while (this.result.next()) {
/*  207 */         Yyz y = new Yyz();
/*  208 */         id1 = this.result.getString("s_card_no");
/*  209 */         y.setId(this.result.getString("s_id"));
/*  210 */         y.setPaperNo(this.result.getString("S_PAPER_NO"));
/*  211 */         if (map.containsKey(id1)) {
/*  212 */           ((List)map.get(id1)).add(y);
/*      */         } else {
/*  214 */           List list = new ArrayList();
/*  215 */           list.add(y);
/*  216 */           map.put(id1, list);
/*      */         }
/*      */       }
/*  219 */       this.result.close();
/*  220 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  222 */       e.printStackTrace();
/*  223 */       return null;
/*      */     }
/*  225 */     return map;
/*      */   }
/*      */ 
/*      */   public List<String> getCityByCPB(String cid, String pid, String bid)
/*      */   {
/*  236 */     List list = new ArrayList();
/*      */     try {
/*  238 */       this.statement = this.dbconn.getConnection().prepareStatement(CPB_CITY_SQL);
/*  239 */       this.statement.setString(1, cid);
/*  240 */       this.statement.setString(2, pid);
/*  241 */       this.statement.setString(3, bid);
/*  242 */       this.result = this.statement.executeQuery();
/*  243 */       while (this.result.next()) {
/*  244 */         list.add(this.result.getString("S_CITY_NO"));
/*      */       }
/*  246 */       this.result.close();
/*  247 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  249 */       e.printStackTrace();
/*      */     }
/*  251 */     return list;
/*      */   }
/*      */ 
/*      */   public List<UserBase> getUserBase(String cardid, String city, int page, int size)
/*      */   {
/*  264 */     List list = new ArrayList();
/*      */     try {
/*  266 */       this.statement = this.dbconn.getConnection().prepareStatement(USER_BASE1);
/*  267 */       this.statement.setString(1, cardid);
/*  268 */       this.statement.setString(2, city);
/*  269 */       this.statement.setInt(3, page * size);
/*  270 */       this.statement.setInt(4, (page - 1) * size);
/*  271 */       this.result = this.statement.executeQuery();
/*      */ 
/*  273 */       while (this.result.next()) {
/*  274 */         UserBase ub = new UserBase();
/*  275 */         ub.setAcctnbr(this.result.getString("S_ACCOUNT"));
/*  276 */         ub.setRectype(this.result.getString("S_CUR_TYPE"));
/*  277 */         ub.setZip(this.result.getString("S_CUR_ZIP"));
/*  278 */         ub.setAddrname3(this.result.getString("S_CUR_ADDR3"));
/*  279 */         ub.setAddrname1(this.result.getString("S_CUR_ADDR1"));
/*  280 */         ub.setAddrname2(this.result.getString("S_CUR_ADDR2"));
/*  281 */         ub.setName(this.result.getString("S_CUR_NAME"));
/*  282 */         ub.setSex(this.result.getString("C_CUR_SEX"));
/*  283 */         ub.setBirthday(this.result.getString("S_CUR_BIRTHDAY"));
/*  284 */         ub.setAccnum(this.result.getString("S_CUR_ACCOUNT"));
/*  285 */         ub.setCusnum(this.result.getString("S_CUR_CUST_NBR"));
/*  286 */         ub.setStfromdate(this.result.getString("S_CUR_START_DATE"));
/*  287 */         ub.setEnddate(this.result.getString("S_CUR_END_DATE"));
/*  288 */         ub.setSpecode(this.result.getString("S_CUR_SPECIAL_CHAR"));
/*  289 */         ub.setPmtduemark(this.result.getString("S_CUR_PMT_CYCLE_DUE"));
/*  290 */         ub.setCashmark(this.result.getString("S_CUR_PRINT"));
/*  291 */         ub.setIndiv1(this.result.getString("C_CUR_MSG_1"));
/*  292 */         ub.setIndiv2(this.result.getString("C_CUR_MSG_2"));
/*  293 */         ub.setIndiv3(this.result.getString("C_CUR_MSG_3"));
/*  294 */         ub.setIndiv4(this.result.getString("C_CUR_MSG_4"));
/*  295 */         ub.setIndiv5(this.result.getString("C_CUR_MSG_5"));
/*  296 */         ub.setIndiv6(this.result.getString("C_CUR_MSG_6"));
/*  297 */         ub.setIndiv7(this.result.getString("C_CUR_MSG_7"));
/*  298 */         ub.setIndiv8(this.result.getString("C_CUR_MSG_8"));
/*  299 */         ub.setActinfo(this.result.getString("C_CUR_ACTIVITY_MSG"));
/*  300 */         ub.setDm1(this.result.getString("C_CUR_DM_MSG_1"));
/*  301 */         ub.setDm2(this.result.getString("C_CUR_DM_MSG_2"));
/*  302 */         ub.setDm3(this.result.getString("C_CUR_DM_MSG_3"));
/*  303 */         ub.setDm4(this.result.getString("C_CUR_DM_MSG_4"));
/*  304 */         ub.setBrandmsg1(this.result.getString("C_CUR_BRAND_MSG_1"));
/*  305 */         ub.setBrandmsg2(this.result.getString("C_CUR_BRAND_MSG_2"));
/*  306 */         ub.setBrandmsg3(this.result.getString("C_CUR_BRAND_MSG_3"));
/*  307 */         ub.setBrandmsg4(this.result.getString("C_CUR_BRAND_MSG_4"));
/*  308 */         ub.setBrandmsg5(this.result.getString("C_CUR_BRAND_MSG_5"));
/*  309 */         ub.setBrandmsg6(this.result.getString("C_CUR_BRAND_MSG_6"));
/*  310 */         ub.setBrandmsg7(this.result.getString("C_CUR_BRAND_MSG_7"));
/*  311 */         ub.setConvexchmark(this.result.getString("C_CUR_CONV_EXCH_FLAG"));
/*  312 */         ub.setVipmsg1(this.result.getString("C_CUR_VIP_MSG_1"));
/*  313 */         ub.setVipmsg2(this.result.getString("C_CUR_VIP_MSG_2"));
/*  314 */         ub.setVipmsg3(this.result.getString("C_CUR_VIP_MSG_3"));
/*  315 */         ub.setVipmsg4(this.result.getString("C_CUR_VIP_MSG_4"));
/*  316 */         ub.setReprintflag(this.result.getString("C_CUR_REPRINT_FLAG"));
/*  317 */         ub.setEmailflag(this.result.getString("C_CUR_EMAIL_STMT_FLAG"));
/*  318 */         ub.setPaperflag(this.result.getString("C_CUR_PAPER_STMT_FLAG"));
/*  319 */         ub.setEmailaddr(this.result.getString("S_CUR_EMAIL_ADDR"));
/*  320 */         ub.setCusttype(this.result.getString("S_CUR_CUSTOMER_TYPE"));
/*  321 */         ub.setMobilenbr(this.result.getString("S_CUR_MOBILE_NBR"));
/*  322 */         ub.setAinbr(this.result.getString("S_CUR_AI_NBR"));
/*  323 */         ub.setMobdate(this.result.getString("C_CUR_MOB"));
/*  324 */         ub.setFiller(this.result.getString("S_CUR_FILLER"));
/*  325 */         ub.setCity(this.result.getString("S_CITY_ID"));
/*  326 */         ub.setCrlim(this.result.getString("I_CUR_CRLIM"));
/*  327 */         ub.setCurrbal(this.result.getString("I_CUR_BAL"));
/*  328 */         ub.setTotdueamt(this.result.getString("I_CUR_TOT_DUE_AMT"));
/*  329 */         ub.setCashcrlim(this.result.getString("I_CUR_CASH_CRLIM"));
/*  330 */         ub.setStmtdate(this.result.getString("C_STMT_DATE"));
/*  331 */         ub.setCardNo(this.result.getString("S_CARD_PROD_ID"));
/*  332 */         list.add(ub);
/*      */       }
/*  334 */       this.result.close();
/*  335 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  337 */       e.printStackTrace();
/*      */     }
/*  339 */     return list;
/*      */   }
/*      */ 
/*      */   public List<UserBase> getUserBase(String cardid, int page, int size)
/*      */   {
/*  350 */     List list = new ArrayList();
/*      */     try {
/*  352 */       this.statement = this.dbconn.getConnection().prepareStatement(USER_BASE2);
/*  353 */       this.statement.setString(1, cardid);
/*      */ 
/*  355 */       this.statement.setInt(2, page * size);
/*      */ 
/*  357 */       this.statement.setInt(3, (page - 1) * size);
/*  358 */       this.result = this.statement.executeQuery();
/*      */ 
/*  360 */       while (this.result.next()) {
/*  361 */         UserBase ub = new UserBase();
/*  362 */         ub.setAcctnbr(this.result.getString("S_ACCOUNT"));
/*  363 */         ub.setRectype(this.result.getString("S_CUR_TYPE"));
/*  364 */         ub.setZip(this.result.getString("S_CUR_ZIP"));
/*  365 */         ub.setAddrname3(this.result.getString("S_CUR_ADDR3"));
/*  366 */         ub.setAddrname1(this.result.getString("S_CUR_ADDR1"));
/*  367 */         ub.setAddrname2(this.result.getString("S_CUR_ADDR2"));
/*  368 */         ub.setName(this.result.getString("S_CUR_NAME"));
/*  369 */         ub.setSex(this.result.getString("C_CUR_SEX"));
/*  370 */         ub.setBirthday(this.result.getString("S_CUR_BIRTHDAY"));
/*  371 */         ub.setAccnum(this.result.getString("S_CUR_ACCOUNT"));
/*  372 */         ub.setCusnum(this.result.getString("S_CUR_CUST_NBR"));
/*  373 */         ub.setStfromdate(this.result.getString("S_CUR_START_DATE"));
/*  374 */         ub.setEnddate(this.result.getString("S_CUR_END_DATE"));
/*  375 */         ub.setSpecode(this.result.getString("S_CUR_SPECIAL_CHAR"));
/*  376 */         ub.setPmtduemark(this.result.getString("S_CUR_PMT_CYCLE_DUE"));
/*  377 */         ub.setCashmark(this.result.getString("S_CUR_PRINT"));
/*  378 */         ub.setIndiv1(this.result.getString("C_CUR_MSG_1"));
/*  379 */         ub.setIndiv2(this.result.getString("C_CUR_MSG_2"));
/*  380 */         ub.setIndiv3(this.result.getString("C_CUR_MSG_3"));
/*  381 */         ub.setIndiv4(this.result.getString("C_CUR_MSG_4"));
/*  382 */         ub.setIndiv5(this.result.getString("C_CUR_MSG_5"));
/*  383 */         ub.setIndiv6(this.result.getString("C_CUR_MSG_6"));
/*  384 */         ub.setIndiv7(this.result.getString("C_CUR_MSG_7"));
/*  385 */         ub.setIndiv8(this.result.getString("C_CUR_MSG_8"));
/*  386 */         ub.setActinfo(this.result.getString("C_CUR_ACTIVITY_MSG"));
/*  387 */         ub.setDm1(this.result.getString("C_CUR_DM_MSG_1"));
/*  388 */         ub.setDm2(this.result.getString("C_CUR_DM_MSG_2"));
/*  389 */         ub.setDm3(this.result.getString("C_CUR_DM_MSG_3"));
/*  390 */         ub.setDm4(this.result.getString("C_CUR_DM_MSG_4"));
/*  391 */         ub.setBrandmsg1(this.result.getString("C_CUR_BRAND_MSG_1"));
/*  392 */         ub.setBrandmsg2(this.result.getString("C_CUR_BRAND_MSG_2"));
/*  393 */         ub.setBrandmsg3(this.result.getString("C_CUR_BRAND_MSG_3"));
/*  394 */         ub.setBrandmsg4(this.result.getString("C_CUR_BRAND_MSG_4"));
/*  395 */         ub.setBrandmsg5(this.result.getString("C_CUR_BRAND_MSG_5"));
/*  396 */         ub.setBrandmsg6(this.result.getString("C_CUR_BRAND_MSG_6"));
/*  397 */         ub.setBrandmsg7(this.result.getString("C_CUR_BRAND_MSG_7"));
/*  398 */         ub.setConvexchmark(this.result.getString("C_CUR_CONV_EXCH_FLAG"));
/*  399 */         ub.setVipmsg1(this.result.getString("C_CUR_VIP_MSG_1"));
/*  400 */         ub.setVipmsg2(this.result.getString("C_CUR_VIP_MSG_2"));
/*  401 */         ub.setVipmsg3(this.result.getString("C_CUR_VIP_MSG_3"));
/*  402 */         ub.setVipmsg4(this.result.getString("C_CUR_VIP_MSG_4"));
/*  403 */         ub.setReprintflag(this.result.getString("C_CUR_REPRINT_FLAG"));
/*  404 */         ub.setEmailflag(this.result.getString("C_CUR_EMAIL_STMT_FLAG"));
/*  405 */         ub.setPaperflag(this.result.getString("C_CUR_PAPER_STMT_FLAG"));
/*  406 */         ub.setEmailaddr(this.result.getString("S_CUR_EMAIL_ADDR"));
/*  407 */         ub.setCusttype(this.result.getString("S_CUR_CUSTOMER_TYPE"));
/*  408 */         ub.setMobilenbr(this.result.getString("S_CUR_MOBILE_NBR"));
/*  409 */         ub.setAinbr(this.result.getString("S_CUR_AI_NBR"));
/*  410 */         ub.setMobdate(this.result.getString("C_CUR_MOB"));
/*  411 */         ub.setFiller(this.result.getString("S_CUR_FILLER"));
/*  412 */         ub.setCity(this.result.getString("S_CITY_ID"));
/*  413 */         ub.setCrlim(this.result.getString("I_CUR_CRLIM"));
/*  414 */         ub.setCurrbal(this.result.getString("I_CUR_BAL"));
/*  415 */         ub.setTotdueamt(this.result.getString("I_CUR_TOT_DUE_AMT"));
/*  416 */         ub.setCashcrlim(this.result.getString("I_CUR_CASH_CRLIM"));
/*  417 */         ub.setStmtdate(this.result.getString("C_STMT_DATE"));
/*  418 */         ub.setCardNo(this.result.getString("S_CARD_PROD_ID"));
/*  419 */         list.add(ub);
/*      */       }
/*  421 */       this.result.close();
/*  422 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  424 */       e.printStackTrace();
/*      */     }
/*  426 */     return list;
/*      */   }
/*      */ 
/*      */   public List<mcc> getMCCInfo()
/*      */   {
/*  434 */     List list = new ArrayList();
/*      */     try {
/*  436 */       this.statement = this.dbconn
/*  437 */         .getConnection()
/*  438 */         .prepareStatement("select * from T_S_MCC_INFO t order by S_TYPE,s_id");
/*  439 */       this.result = this.statement.executeQuery();
/*  440 */       mcc m = null;
/*  441 */       while (this.result.next()) {
/*  442 */         m = new mcc();
/*  443 */         m.setType(this.result.getString("S_TYPE"));
/*  444 */         m.setTypeName(this.result.getString("S_TYPE_NAME"));
/*  445 */         m.setId(this.result.getString("S_ID"));
/*  446 */         m.setName(this.result.getString("S_NAME"));
/*  447 */         list.add(m);
/*      */       }
/*  449 */       this.result.close();
/*  450 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  452 */       e.printStackTrace();
/*      */     }
/*  454 */     return list;
/*      */   }
/*      */ 
/*      */   public Map<String, String> getMCCMap(String type) {
/*  458 */     Map map = new HashMap();
/*      */     try {
/*  460 */       this.statement = this.dbconn
/*  461 */         .getConnection()
/*  462 */         .prepareStatement("select * from T_S_MCC_INFO t order by S_TYPE,s_id");
/*  463 */       this.result = this.statement.executeQuery();
/*      */ 
/*  465 */       while (this.result.next()) {
/*  466 */         map.put(this.result.getString("S_ID"), type == "" ? "" : this.result.getString(type));
/*      */       }
/*  468 */       this.result.close();
/*  469 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  471 */       e.printStackTrace();
/*      */     }
/*  473 */     return map;
/*      */   }
/*      */ 
/*      */   public List<RuleMNew> getNewRuleMap(String period, String ruleType)
/*      */   {
/*  484 */     List list = new ArrayList();
/*      */     try {
/*  486 */       this.statement = this.dbconn
/*  487 */         .getConnection()
/*  488 */         .prepareStatement("SELECT * FROM T_S_RULE_M_E WHERE C_PERIOD = ? AND S_TYPE = ? ");
/*  489 */       this.statement.setString(1, period);
/*  490 */       this.statement.setString(2, ruleType);
/*  491 */       this.result = this.statement.executeQuery();
/*  492 */       RuleMNew bean = null;
/*  493 */       while (this.result.next()) {
/*  494 */         bean = new RuleMNew();
/*  495 */         bean.setRuleNo(this.result.getString("S_RULE_NO"));
/*  496 */         bean.setPeriod(this.result.getString("C_PERIOD"));
/*  497 */         bean.setCardId(this.result.getString("S_CARD_ID"));
/*  498 */         bean.setCityNo(this.result.getString("S_CITY_NO"));
/*  499 */         list.add(bean);
/*      */       }
/*  501 */       this.result.close();
/*  502 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  504 */       e.printStackTrace();
/*      */     }
/*  506 */     return list;
/*      */   }
/*      */ 
/*      */   public Map<String, String> getProdIdMapping()
/*      */   {
/*  514 */     Map map = new HashMap();
/*      */     try {
/*  516 */       this.statement = this.dbconn
/*  517 */         .getConnection()
/*  518 */         .prepareStatement("select * from t_s_dd");
/*  519 */       this.result = this.statement.executeQuery();
/*  520 */       while (this.result.next()) {
/*  521 */         map.put(this.result.getString("s_html_card_prod_id"), this.result.getString("s_html5_card_prod_id"));
/*      */       }
/*  523 */       this.result.close();
/*  524 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  526 */       e.printStackTrace();
/*      */     }
/*  528 */     return map;
/*      */   }
/*      */ 
/*      */   public List<UserAccinfo> getUserInfo(UserBase base)
/*      */   {
/*  538 */     List list = new ArrayList();
/*  539 */     StringBuffer sql = new StringBuffer();
/*  540 */     sql.append("select ");
/*  541 */     sql.append("acctnbr,rectype,stmtdate,pmtdate,to_char(totbegbal,'fm9999999999999999990.00') as totbegbal");
/*  542 */     sql.append(",to_char(plantotpmt,'fm9999999999999999990.00') as plantotpmt");
/*  543 */     sql.append(",to_char(plantotnrlamt,'fm9999999999999999990.00') as plantotnrlamt,to_char(plantotadjamt,'fm9999999999999999990.00') as plantotadjamt");
/*  544 */     sql.append(",to_char(intdueamt,'fm9999999999999999990.00') as intdueamt,to_char(currbal,'fm9999999999999999990.00') as currbal");
/*  545 */     sql.append(",to_char(totdueamt,'fm9999999999999999990.00') as totdueamt,pmtprint,to_char(crlim,'fm9999999999999999990.00') as crlim,to_char(cashcrlim,'fm9999999999999999990.00') as cashcrlim");
/*  546 */     sql.append(",pmtarn,pmtadn,to_char(projap,'fm9999999999999999990.00') as projap,pmtaflag,achflag,pmtflag,filler");
/*  547 */     sql.append(" from view_b_customer_bill t where t.acctnbr=? and t.stmtdate=?");
/*      */     try {
/*  549 */       this.statement = this.dbconn
/*  550 */         .getConnection()
/*  551 */         .prepareStatement(sql.toString());
/*  552 */       this.statement.setString(1, base.getAcctnbr());
/*  553 */       this.statement.setString(2, base.getStmtdate());
/*  554 */       this.result = this.statement.executeQuery();
/*      */ 
/*  556 */       while (this.result.next()) {
/*  557 */         UserAccinfo ub = new UserAccinfo();
/*  558 */         ub.setAcctnbr(this.result.getString("acctnbr"));
/*  559 */         ub.setRectype(this.result.getString("rectype"));
/*  560 */         ub.setStmtdate(this.result.getString("stmtdate"));
/*  561 */         ub.setPmtdate(this.result.getString("pmtdate"));
/*  562 */         ub.setTotbegbal(this.result.getString("totbegbal"));
/*  563 */         ub.setPlantotpmt(this.result.getString("plantotpmt"));
/*  564 */         ub.setPlantotnrlamt(this.result.getString("plantotnrlamt"));
/*  565 */         ub.setPlantotadjamt(this.result.getString("plantotadjamt"));
/*  566 */         ub.setIntdueamt(this.result.getString("intdueamt"));
/*  567 */         ub.setCurrbal(this.result.getString("currbal"));
/*  568 */         ub.setTotdueamt(this.result.getString("totdueamt"));
/*  569 */         ub.setPmtprint(this.result.getString("pmtprint"));
/*  570 */         ub.setCrlim(this.result.getString("crlim"));
/*  571 */         ub.setCashcrlim(this.result.getString("cashcrlim"));
/*  572 */         ub.setPmtarn(this.result.getString("pmtarn"));
/*  573 */         ub.setPmtadn(this.result.getString("pmtadn"));
/*  574 */         ub.setProjap(this.result.getString("projap"));
/*  575 */         ub.setPmtaflag(this.result.getString("pmtaflag"));
/*  576 */         ub.setAchflag(this.result.getString("achflag"));
/*  577 */         ub.setPmtflag(this.result.getString("pmtflag"));
/*  578 */         ub.setFiller(this.result.getString("filler"));
/*  579 */         list.add(ub);
/*      */       }
/*  581 */       this.result.close();
/*  582 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  584 */       e.printStackTrace();
/*      */     }
/*  586 */     return list;
/*      */   }
/*      */ 
/*      */   public List<UserAccinfoDetail> getAccinfoDetail(UserBase user)
/*      */   {
/*  595 */     List list = new ArrayList();
/*  596 */     StringBuffer sb = new StringBuffer();
/*  597 */     sb.append("select ")
/*  598 */       .append("acctnbr,rectype,recseq,effdate,postdate,cardnlast4,curdesc,to_char(txnamt,'fm9999999999999999990.00') as txnamt,")
/*  599 */       .append("to_char(srctamt,'fm9999999999999999990.00') as srctamt,srctcurr,purcty,filler")
/*  600 */       .append(",catcode,cardnbr,accid,txncode,mainacc,cnname,pyname,cardname")
/*  601 */       .append(" from view_b_customer_bill_detail t where t.acctnbr=?")
/*  602 */       .append(" order by t.rectype, t.cardnbr, t.postdate, t.recseq");
/*      */     try
/*      */     {
/*  605 */       this.statement = this.dbconn
/*  606 */         .getConnection()
/*  607 */         .prepareStatement(sb.toString());
/*  608 */       this.statement.setString(1, user.getAcctnbr());
/*  609 */       this.result = this.statement.executeQuery();
/*      */ 
/*  611 */       while (this.result.next()) {
/*  612 */         UserAccinfoDetail ub = new UserAccinfoDetail();
/*  613 */         ub.setAcctnbr(this.result.getString("acctnbr"));
/*  614 */         ub.setRectype(this.result.getString("rectype"));
/*  615 */         ub.setRecseq(this.result.getString("recseq"));
/*  616 */         ub.setEffdate(this.result.getString("effdate"));
/*  617 */         ub.setPostdate(this.result.getString("postdate"));
/*  618 */         ub.setCardnlast4(this.result.getString("cardnlast4"));
/*  619 */         ub.setDesc(this.result.getString("curdesc"));
/*  620 */         ub.setTxnamt(this.result.getString("txnamt"));
/*  621 */         ub.setSrctamt(this.result.getString("srctamt"));
/*  622 */         ub.setSrctcurr(this.result.getString("srctcurr"));
/*  623 */         ub.setPurcty(this.result.getString("purcty"));
/*  624 */         ub.setFiller(this.result.getString("filler"));
/*  625 */         ub.setMcc(this.result.getString("catcode"));
/*  626 */         ub.setCardNbr(this.result.getString("cardnbr"));
/*  627 */         ub.setAcceptorNbr(this.result.getString("accid"));
/*  628 */         ub.setTxnCode(this.result.getString("txncode"));
/*  629 */         ub.setMainAccount(this.result.getString("mainacc"));
/*  630 */         ub.setCnName(this.result.getString("cnname"));
/*  631 */         ub.setPyName(this.result.getString("pyname"));
/*  632 */         ub.setCardName(this.result.getString("cardname"));
/*  633 */         list.add(ub);
/*      */       }
/*  635 */       this.result.close();
/*  636 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  638 */       e.printStackTrace();
/*      */     }
/*  640 */     return list;
/*      */   }
/*      */ 
/*      */   public UserBuy getUserBuy(UserBase user) {
/*  644 */     UserBuy ub = null;
/*      */     try {
/*  646 */       this.statement = this.dbconn
/*  647 */         .getConnection()
/*  648 */         .prepareStatement(
/*  649 */         "select * from T_B_CUSTOMER_PURCHASE t where t.S_ACCOUNT=?");
/*  650 */       this.statement.setString(1, user.getAcctnbr());
/*  651 */       this.result = this.statement.executeQuery();
/*  652 */       while (this.result.next()) {
/*  653 */         ub = new UserBuy();
/*  654 */         ub.setAcctnbr(this.result.getString("S_ACCOUNT"));
/*  655 */         ub.setRectype(this.result.getString("S_CUR_PUR_REC_TYPE"));
/*  656 */         ub.setExchusdamt(this.result.getString("I_CUR_PUR_EXCH_USD_AMT"));
/*  657 */         ub.setSellrate(this.result.getString("I_CUR_PUR_SELL_RATE"));
/*  658 */         ub.setExchrmbamt(this.result.getString("I_CUR_PUR_EXCH_RMB_AMT"));
/*  659 */         ub.setAchrtnbr(this.result.getString("S_CUR_PUR_PMT_ACH_RT_NBR"));
/*  660 */         ub.setAchdbnbr(this.result.getString("S_CUR_PUR_PMT_ACH_DB_NBR"));
/*  661 */         ub.setFiller(this.result.getString("S_CUR_PUR_FILLER"));
/*      */       }
/*  663 */       this.result.close();
/*  664 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  666 */       e.printStackTrace();
/*  667 */       return null;
/*      */     }
/*  669 */     return ub;
/*      */   }
/*      */ 
/*      */   public List<Debitinfo> getDebitinfo(UserBase user)
/*      */   {
/*  678 */     List list = new ArrayList();
/*  679 */     Debitinfo deb = null;
/*  680 */     StringBuffer sb = new StringBuffer();
/*  681 */     sb.append("select ");
/*  682 */     sb.append("acctnbr,rectype,custnbr,effdate,txndesc,txncity,currcode,NVL(to_char(txnamt,'fm9999999999999999999990.00'),' ') as txnamt");
/*  683 */     sb.append(",cardl4,filler");
/*  684 */     sb.append(" from view_b_crad_trade_detail t where t.acctnbr=? order by rectype, effdate, cardl4");
/*      */     try {
/*  686 */       this.statement = this.dbconn
/*  687 */         .getConnection()
/*  688 */         .prepareStatement(sb.toString());
/*  689 */       this.statement.setString(1, user.getAcctnbr());
/*  690 */       this.result = this.statement.executeQuery();
/*  691 */       while (this.result.next()) {
/*  692 */         deb = new Debitinfo();
/*  693 */         deb.setAcctnbr(this.result.getString("acctnbr"));
/*  694 */         deb.setRectype(this.result.getString("rectype"));
/*  695 */         deb.setCustnbr(this.result.getString("custnbr"));
/*  696 */         deb.setEffdate(this.result.getString("effdate"));
/*  697 */         deb.setTxndesc(this.result.getString("txndesc"));
/*  698 */         deb.setTxncity(this.result.getString("txncity"));
/*  699 */         deb.setCurrcode(this.result.getString("currcode"));
/*  700 */         deb.setTxnamt(this.result.getString("txnamt"));
/*  701 */         deb.setCardl4(this.result.getString("cardl4"));
/*  702 */         deb.setFiller(this.result.getString("filler"));
/*  703 */         list.add(deb);
/*      */       }
/*  705 */       this.result.close();
/*  706 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  708 */       e.printStackTrace();
/*  709 */       return null;
/*      */     }
/*  711 */     return list;
/*      */   }
/*      */ 
/*      */   public List<Stageplan> getStageplan(UserBase user)
/*      */   {
/*  720 */     List list = new ArrayList();
/*  721 */     Stageplan sta = null;
/*  722 */     StringBuffer sb = new StringBuffer();
/*  723 */     sb.append("select ")
/*  724 */       .append("s_stagetype")
/*  725 */       .append(",i_totalstage as totalstage")
/*  726 */       .append(",i_accstage as accstage")
/*  727 */       .append(",NVL(to_char(i_totalamt,'fm9999999999999999999990.00'),' ') as totalamt")
/*  728 */       .append(",NVL(to_char(i_unaccamt,'fm9999999999999999999990.00'),' ') as unaccamt")
/*  729 */       .append(",NVL(to_char(i_stagefee,'fm9999999999999999999990.00'),' ') as stagefee")
/*  730 */       .append(",NVL(to_char(i_unaccfee,'fm9999999999999999999990.00'),' ') as unaccfee")
/*  731 */       .append(" from T_B_CUSTOMER_STAGEPLAN where s_account=? and C_STMT_DATE=? ORDER BY S_STAGETYPE, I_TOTALSTAGE, I_ACCSTAGE");
/*      */     try
/*      */     {
/*  734 */       this.statement = this.dbconn
/*  735 */         .getConnection()
/*  736 */         .prepareStatement(sb.toString());
/*  737 */       this.statement.setString(1, user.getAcctnbr());
/*  738 */       this.statement.setString(2, user.getStmtdate());
/*  739 */       this.result = this.statement.executeQuery();
/*  740 */       while (this.result.next()) {
/*  741 */         sta = new Stageplan();
/*  742 */         sta.setStagetype(this.result.getString("s_stagetype"));
/*  743 */         sta.setTotalstage(this.result.getInt("totalstage"));
/*  744 */         sta.setAccstage(this.result.getInt("accstage"));
/*  745 */         sta.setTotalamt(this.result.getString("totalamt"));
/*  746 */         sta.setUnaccamt(this.result.getString("unaccamt"));
/*  747 */         sta.setStagefee(this.result.getString("stagefee"));
/*  748 */         sta.setUnaccfee(this.result.getString("unaccfee"));
/*  749 */         list.add(sta);
/*      */       }
/*  751 */       this.result.close();
/*  752 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  754 */       e.printStackTrace();
/*  755 */       return null;
/*      */     }
/*  757 */     return list;
/*      */   }
/*      */ 
/*      */   public List<PointInfo> getPoint(UserBase user)
/*      */   {
/*  768 */     List list = new ArrayList();
/*  769 */     PointInfo p = null;
/*      */     try {
/*  771 */       this.statement = this.dbconn
/*  772 */         .getConnection()
/*  773 */         .prepareStatement(
/*  774 */         "select S_POINT_TYPE,S_ACCT_PROD_ID,S_BUSINESS_ID,I_ABLE_POINT,I_LASTBAL_POINT,I_ADDPOINT_POINT,I_EXPOINT_POINT,I_ADPOINTS_POINT,I_ENDPOINTS_POINT,S_ECIF_NO,S_START_DATE,S_END_DATE,to_char(I_WHOLE_CONSUME,'fm99999990.00') as I_WHOLE_CONSUME,to_char(I_IN_CONSUME,'fm99999990.00') as I_IN_CONSUME,to_char(I_OUT_CONSUME,'fm99999990.00') as I_OUT_CONSUME,to_char(I_WHOLE_MONEY,'fm99999990.00') as I_WHOLE_MONEY,to_char(I_IN_MONEY,'fm99999990.00') as I_IN_MONEY,to_char(I_OUT_MONEY,'fm99999990.00') as I_OUT_MONEY,to_char(I_USED_MONEY,'fm99999990.00') as I_USED_MONEY,to_char(I_LAVE_MONEY,'fm99999990.00') as I_LAVE_MONEY,S_VALID_DATE,I_LADDER_MONEY,S_LADDER_SCALE,C_CARD_LAST4,C_CARD_POINT_TYPE,S_CARD_POINT_NAME from t_b_point_x where S_BUSINESS_ID=? and C_STMT_DATE=?");
/*      */ 
/*  781 */       this.statement.setString(1, user.getAcctnbr());
/*  782 */       this.statement.setString(2, user.getStmtdate());
/*  783 */       this.result = this.statement.executeQuery();
/*  784 */       while (this.result.next()) {
/*  785 */         p = new PointInfo();
/*  786 */         p.setPointtype(this.result.getString("S_POINT_TYPE"));
/*  787 */         p.setCardportid(this.result.getString("S_ACCT_PROD_ID"));
/*  788 */         p.setBusinessid(this.result.getString("S_BUSINESS_ID"));
/*  789 */         p.setAblepoint(this.result.getString("I_ABLE_POINT"));
/*  790 */         p.setLastbalpoint(this.result.getString("I_LASTBAL_POINT"));
/*  791 */         p.setAddpoint(this.result.getString("I_ADDPOINT_POINT"));
/*  792 */         p.setExpoint(this.result.getString("I_EXPOINT_POINT"));
/*  793 */         p.setAdpoints(this.result.getString("I_ADPOINTS_POINT"));
/*  794 */         p.setEndpoints(this.result.getString("I_ENDPOINTS_POINT"));
/*      */ 
/*  796 */         p.setEcifno(this.result.getString("S_ECIF_NO"));
/*  797 */         p.setStartdate(this.result.getString("S_START_DATE"));
/*  798 */         p.setEnddate(this.result.getString("S_END_DATE"));
/*  799 */         p.setWholeconsume(this.result.getString("I_WHOLE_CONSUME"));
/*  800 */         p.setInconsume(this.result.getString("I_IN_CONSUME"));
/*  801 */         p.setOutconsume(this.result.getString("I_OUT_CONSUME"));
/*  802 */         p.setWholemoney(this.result.getString("I_WHOLE_MONEY"));
/*  803 */         p.setInmoney(this.result.getString("I_IN_MONEY"));
/*  804 */         p.setOutmoney(this.result.getString("I_OUT_MONEY"));
/*  805 */         p.setUsedmoney(this.result.getString("I_USED_MONEY"));
/*  806 */         p.setLavemoney(this.result.getString("I_LAVE_MONEY"));
/*  807 */         p.setValiddate(this.result.getString("S_VALID_DATE"));
/*  808 */         p.setLaddermoney(this.result.getString("I_LADDER_MONEY"));
/*  809 */         p.setLadderscale(this.result.getString("S_LADDER_SCALE"));
/*  810 */         p.setCard4(this.result.getString("C_CARD_LAST4"));
/*  811 */         p.setCardPointType(this.result.getString("C_CARD_POINT_TYPE"));
/*  812 */         p.setCardname(this.result.getString("S_CARD_POINT_NAME"));
/*  813 */         list.add(p);
/*      */       }
/*  815 */       this.result.close();
/*  816 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  818 */       e.printStackTrace();
/*  819 */       return null;
/*      */     }
/*  821 */     return list;
/*      */   }
/*      */ 
/*      */   public PointInfo getPoint2(UserBase user)
/*      */   {
/*  831 */     PointInfo p = null;
/*      */     try {
/*  833 */       this.statement = this.dbconn
/*  834 */         .getConnection()
/*  835 */         .prepareStatement(
/*  836 */         "select * from T_B_POINT_W where S_ECIF_NO=? and C_STMT_DATE=?");
/*  837 */       if (user.getCusnum().length() > 12) {
/*  838 */         this.statement.setString(1, user.getCusnum().substring(7));
/*      */       }
/*      */       else {
/*  841 */         this.statement.setString(1, user.getCusnum());
/*      */       }
/*  843 */       this.statement.setString(2, user.getStmtdate());
/*  844 */       this.result = this.statement.executeQuery();
/*  845 */       while (this.result.next()) {
/*  846 */         p = new PointInfo();
/*  847 */         p.setBilldate(this.result.getString("C_STMT_DATE"));
/*  848 */         p.setBusinessid(this.result.getString("S_ECIF_NO"));
/*  849 */         p.setAblepoint(this.result.getString("I_ENDPOINT"));
/*  850 */         p.setEndpoints(this.result.getString("I_VALIDPOINT_B"));
/*  851 */         p.setLastbalpoint(this.result.getString("I_NEWPOINT"));
/*  852 */         p.setAddpoint(this.result.getString("I_USEDPOINT"));
/*  853 */         p.setExpoint(this.result.getString("I_ADJUSTPOINT"));
/*  854 */         p.setAdpoints(this.result.getString("I_INVAILPOINT"));
/*  855 */         p.setExpirespoint(this.result.getString("I_EXPIRES_POINT"));
/*      */       }
/*  857 */       this.result.close();
/*  858 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  860 */       e.printStackTrace();
/*  861 */       return null;
/*      */     }
/*  863 */     return p;
/*      */   }
/*      */ 
/*      */   public Map<String, String> getTemplateList()
/*      */   {
/*  871 */     Map map = new HashMap();
/*      */     try {
/*  873 */       this.statement = this.dbconn.getConnection().prepareStatement(TEMPLATE_SQL);
/*  874 */       this.result = this.statement.executeQuery();
/*  875 */       while (this.result.next()) {
/*  876 */         map.put(this.result.getString("S_CARD_PROD_ID") + "_" + this.result.getString("C_TYPE_NO"), this.result.getString("S_STENCIL_NO"));
/*      */       }
/*  878 */       this.result.close();
/*  879 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  881 */       e.printStackTrace();
/*  882 */       return map;
/*      */     }
/*  884 */     return map;
/*      */   }
/*      */ 
/*      */   public List<Rule> getRule(String tid, String type, String area, String billdayYM, String billdayD)
/*      */   {
/*  898 */     List list = new ArrayList();
/*      */     try {
/*  900 */       this.statement = this.dbconn.getConnection().prepareStatement(RULE_SQL);
/*  901 */       this.statement.setString(1, tid);
/*  902 */       this.statement.setString(2, type);
/*  903 */       this.statement.setString(3, area);
/*  904 */       this.statement.setString(4, billdayYM);
/*  905 */       this.statement.setString(5, billdayYM);
/*  906 */       this.statement.setString(6, billdayD);
/*  907 */       this.result = this.statement.executeQuery();
/*      */ 
/*  909 */       while (this.result.next()) {
/*  910 */         Rule r = new Rule();
/*  911 */         r.setRuleid(this.result.getString("S_RULE_NO"));
/*  912 */         r.setTid(this.result.getString("S_STENCIL_NO"));
/*  913 */         r.setRuleType(this.result.getString("C_RULE_TYPE"));
/*  914 */         r.setType(this.result.getString("C_TYPENO"));
/*  915 */         r.setPri(this.result.getString("I_PRI"));
/*  916 */         r.setAreaNo(this.result.getString("I_AREA_NO"));
/*  917 */         list.add(r);
/*      */       }
/*  919 */       this.result.close();
/*  920 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  922 */       e.printStackTrace();
/*      */     }
/*  924 */     return list;
/*      */   }
/*      */ 
/*      */   public List<RuleF> getRuleF(String rid)
/*      */   {
/*  932 */     List list = new ArrayList();
/*      */     try {
/*  934 */       this.statement = this.dbconn
/*  935 */         .getConnection()
/*  936 */         .prepareStatement(
/*  937 */         "select * from t_s_rule_f t where t.s_rule_no=? order by t.i_pri desc");
/*  938 */       this.statement.setString(1, rid);
/*  939 */       this.result = this.statement.executeQuery();
/*      */ 
/*  941 */       while (this.result.next()) {
/*  942 */         RuleF r = new RuleF();
/*  943 */         r.setId(this.result.getString("S_SEQUENCE"));
/*  944 */         r.setRid(this.result.getString("S_RULE_NO"));
/*  945 */         r.setFodder(this.result.getString("S_FODDER_NO"));
/*  946 */         r.setPri(this.result.getString("I_PRI"));
/*  947 */         list.add(r);
/*      */       }
/*  949 */       this.result.close();
/*  950 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  952 */       e.printStackTrace();
/*      */     }
/*  954 */     return list;
/*      */   }
/*      */ 
/*      */   public List<RuleM> getRuleFF(String rid)
/*      */   {
/*  962 */     List list = new ArrayList();
/*      */     try {
/*  964 */       this.statement = this.dbconn
/*  965 */         .getConnection()
/*  966 */         .prepareStatement(
/*  967 */         "select * from t_s_rule_ff t where t.s_sequence=? order by t.s_idx");
/*  968 */       this.statement.setString(1, rid);
/*  969 */       this.result = this.statement.executeQuery();
/*      */ 
/*  971 */       while (this.result.next()) {
/*  972 */         RuleM r = new RuleM();
/*  973 */         r.setFieldid(this.result.getString("S_FIELD"));
/*  974 */         r.setOpr1(this.result.getInt("C_OPR_1"));
/*  975 */         r.setVal1(this.result.getString("S_VALIUE_1"));
/*  976 */         r.setOpr2(this.result.getInt("C_OPR_2"));
/*  977 */         r.setVal2(this.result.getString("S_VALIUE_2"));
/*  978 */         r.setCif(this.result.getInt("C_IF"));
/*  979 */         list.add(r);
/*      */       }
/*  981 */       this.result.close();
/*  982 */       this.statement.close();
/*      */     } catch (SQLException e) {
/*  984 */       e.printStackTrace();
/*      */     }
/*  986 */     return list;
/*      */   }
/*      */ 
/*      */   public List<TempArea> getTemplateInfo(String tid)
/*      */   {
/*  993 */     List list = new ArrayList();
/*      */     try {
/*  995 */       this.statement = this.dbconn
/*  996 */         .getConnection()
/*  997 */         .prepareStatement(
/*  998 */         "select t.i_area_no,t.c_type_no from t_s_area t where t.s_stencil_no=?");
/*  999 */       this.statement.setString(1, tid);
/* 1000 */       this.result = this.statement.executeQuery();
/*      */ 
/* 1002 */       while (this.result.next()) {
/* 1003 */         TempArea ta = new TempArea();
/* 1004 */         ta.setArea(this.result.getString("i_area_no"));
/* 1005 */         ta.setType(this.result.getString("c_type_no"));
/* 1006 */         list.add(ta);
/*      */       }
/* 1008 */       this.result.close();
/* 1009 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1011 */       e.printStackTrace();
/*      */     }
/* 1013 */     return list;
/*      */   }
/*      */ 
/*      */   public Fodder getFodder(String fid, String d)
/*      */   {
/* 1023 */     Fodder fodder = null;
/*      */     try {
/* 1025 */       this.statement = this.dbconn
/* 1026 */         .getConnection()
/* 1027 */         .prepareStatement(
/* 1028 */         "select t.s_fodder_no,t.s_fodder_doc_name,t.s_url from T_S_FODDER  t where t.s_fodder_no=? and t.c_state='1' and to_date(?, 'yyyyMM') between to_date(t.c_period_begen, 'yyyy-MM') and to_date(t.c_period_end, 'yyyy-MM')");
/* 1029 */       this.statement.setString(1, fid);
/* 1030 */       this.statement.setString(2, d);
/* 1031 */       this.result = this.statement.executeQuery();
/* 1032 */       while (this.result.next()) {
/* 1033 */         fodder = new Fodder();
/* 1034 */         fodder.setFid(this.result.getString("s_fodder_no"));
/* 1035 */         fodder.setUrl(this.result.getString("s_fodder_doc_name"));
/* 1036 */         fodder.setLinkurl(this.result.getString("s_url"));
/*      */       }
/* 1038 */       this.result.close();
/* 1039 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1041 */       this.log.error("素材查询失败！1=" + fid + ",2=" + d);
/* 1042 */       e.printStackTrace();
/* 1043 */       return null;
/*      */     }
/* 1045 */     return fodder;
/*      */   }
/*      */ 
/*      */   public List<Foldout> getFoldout(String bid, String cid, String billdate)
/*      */   {
/* 1056 */     List list = new ArrayList();
/* 1057 */     Foldout foldout = null;
/*      */     try {
/* 1059 */       String sql = "select I_FOLDOUT_INDEX,S_FOLDOUT_PROD_NAME,I_FOLDOUT_PRI,C_FOLDOUT_STATE,I_ID from T_S_FOLDOUT_PROD t2 where t2.i_id =(select t.i_id from T_S_FOLDOUT_PROD_SUB t where t.s_foldout_businpnt_no = ? and t.s_foldout_prod_bpid = ? and t.c_period = ? and to_date(?,'yyyyMM') between to_date(t.c_period_begen,'yyyy-MM') and to_date(t.c_period_end,'yyyy-MM')) order by t2.i_foldout_index";
/*      */ 
/* 1064 */       this.statement = this.dbconn.getConnection().prepareStatement(sql);
/* 1065 */       this.statement.setString(1, bid);
/* 1066 */       this.statement.setString(2, cid);
/* 1067 */       this.statement.setString(3, billdate.substring(6));
/* 1068 */       this.statement.setString(4, billdate.substring(0, 6));
/* 1069 */       this.result = this.statement.executeQuery();
/* 1070 */       while (this.result.next()) {
/* 1071 */         foldout = new Foldout();
/* 1072 */         foldout.setId(this.result.getString("I_ID"));
/* 1073 */         foldout.setName(this.result.getString("S_FOLDOUT_PROD_NAME"));
/* 1074 */         foldout.setPri(this.result.getInt("I_FOLDOUT_PRI"));
/* 1075 */         foldout.setState(this.result.getString("C_FOLDOUT_STATE"));
/* 1076 */         foldout.setIdx(this.result.getString("I_FOLDOUT_INDEX"));
/* 1077 */         list.add(foldout);
/*      */       }
/* 1079 */       this.result.close();
/* 1080 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1082 */       e.printStackTrace();
/*      */     }
/*      */     finally {
/* 1085 */       return list;
/*      */     }
/*      */   }
/*      */ 
/*      */   public Map<String, String> getFoldoutCity(String id, String idx)
/*      */   {
/* 1098 */     Map map = new HashMap();
/* 1099 */     String city = "";
/*      */     try {
/* 1101 */       String sql = "select t.s_foldout_city from t_s_foldout_city t where t.i_id=? and t.i_foldout_index=?";
/* 1102 */       this.statement = this.dbconn.getConnection().prepareStatement(sql);
/* 1103 */       this.statement.setString(1, id);
/* 1104 */       this.statement.setString(2, idx);
/* 1105 */       this.result = this.statement.executeQuery();
/* 1106 */       while (this.result.next()) {
/* 1107 */         city = this.result.getString("s_foldout_city");
/* 1108 */         map.put(city, city);
/*      */       }
/* 1110 */       this.result.close();
/* 1111 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1113 */       e.printStackTrace();
/*      */     }
/*      */     finally {
/* 1116 */       return map;
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean clearDBLog(String period)
/*      */   {
/* 1125 */     PreparedStatement ps = null;
/*      */     boolean bool;
/*      */     boolean bool;
/*      */     try {
/* 1128 */       ps = this.dbconn.getConnection().prepareStatement(
/* 1129 */         "delete T_B_XML_LOG where S_PERIOD = ? and c_type = ?");
/* 1130 */       ps.setString(1, period);
/* 1131 */       ps.setString(2, "0");
/* 1132 */       ps.executeUpdate();
/* 1133 */       bool = true;
/*      */     }
/*      */     catch (SQLException e)
/*      */     {
/*      */       boolean bool;
/* 1135 */       boolean bool = false;
/* 1136 */       this.log.error("清除生成日志失败, (" + period + "), " + e.getMessage());
/* 1137 */       e.printStackTrace();
/*      */ 
/* 1140 */       if (ps != null)
/*      */         try {
/* 1142 */           ps.close();
/*      */         } catch (SQLException e) {
/* 1144 */           boolean bool = false;
/* 1145 */           this.log.error("清除生成日志后关闭Statement异常, (" + period + "), " + e.getMessage());
/* 1146 */           e.printStackTrace();
/*      */         }
/*      */     }
/*      */     finally
/*      */     {
/* 1140 */       if (ps != null) {
/*      */         try {
/* 1142 */           ps.close();
/*      */         } catch (SQLException e) {
/* 1144 */           boolean bool = false;
/* 1145 */           this.log.error("清除生成日志后关闭Statement异常, (" + period + "), " + e.getMessage());
/* 1146 */           e.printStackTrace();
/*      */         }
/*      */       }
/*      */     }
/* 1150 */     return bool;
/*      */   }
/*      */ 
/*      */   public boolean clearDBLog(String period, List<String> cardId)
/*      */   {
/* 1160 */     PreparedStatement ps = null;
/*      */     boolean bool;
/*      */     boolean bool;
/*      */     try
/*      */     {
/* 1163 */       StringBuilder sb = new StringBuilder("delete T_B_XML_LOG where S_PERIOD = ? and c_type = ? and S_CARD_PROD_ID in (");
/* 1164 */       for (String s : cardId) {
/* 1165 */         sb.append("'").append(s).append("',");
/*      */       }
/* 1167 */       sb.delete(sb.length() - 1, sb.length());
/* 1168 */       sb.append(")");
/*      */ 
/* 1170 */       ps = this.dbconn.getConnection().prepareStatement(sb.toString());
/* 1171 */       ps.setString(1, period);
/* 1172 */       ps.setString(2, "0");
/* 1173 */       ps.executeUpdate();
/* 1174 */       bool = true;
/*      */     }
/*      */     catch (SQLException e)
/*      */     {
/*      */       boolean bool;
/* 1176 */       boolean bool = false;
/* 1177 */       this.log.error("清除生成日志失败, (" + period + ", " + cardId + "), " + e.getMessage());
/* 1178 */       e.printStackTrace();
/*      */ 
/* 1181 */       if (ps != null)
/*      */         try {
/* 1183 */           ps.close();
/*      */         } catch (SQLException e) {
/* 1185 */           boolean bool = false;
/* 1186 */           this.log.error("清除生成日志后关闭Statement异常, (" + period + "), " + e.getMessage());
/* 1187 */           e.printStackTrace();
/*      */         }
/*      */     }
/*      */     finally
/*      */     {
/* 1181 */       if (ps != null) {
/*      */         try {
/* 1183 */           ps.close();
/*      */         } catch (SQLException e) {
/* 1185 */           boolean bool = false;
/* 1186 */           this.log.error("清除生成日志后关闭Statement异常, (" + period + "), " + e.getMessage());
/* 1187 */           e.printStackTrace();
/*      */         }
/*      */       }
/*      */     }
/* 1191 */     return bool;
/*      */   }
/*      */ 
/*      */   public boolean recordDBLog(Plog plog)
/*      */   {
/* 1200 */     PreparedStatement ps = null;
/*      */     boolean bool;
/*      */     boolean bool;
/*      */     try
/*      */     {
/* 1203 */       ps = this.dbconn.getConnection().prepareStatement(
/* 1204 */         "insert into T_B_XML_LOG (S_PERIOD, S_FILENAME, S_BUSINPNT_NO, I_SHARE, C_START_TIME, C_END_TIME, S_CARD_PROD_ID, S_PAPER_NO, C_STATE, I_SHARE_ERROR) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
/*      */ 
/* 1217 */       ps.setString(1, plog.getStmtdate());
/* 1218 */       ps.setString(2, plog.getFilename());
/* 1219 */       ps.setString(3, plog.getBusinpnt_no());
/* 1220 */       ps.setInt(4, plog.getShare());
/* 1221 */       ps.setString(5, plog.getStart_time());
/* 1222 */       ps.setString(6, plog.getEnd_time());
/* 1223 */       ps.setString(7, plog.getCard_id());
/* 1224 */       ps.setString(8, plog.getPaper_no());
/* 1225 */       ps.setString(9, plog.getState());
/* 1226 */       ps.setInt(10, plog.getError());
/* 1227 */       ps.execute();
/* 1228 */       bool = true;
/*      */     }
/*      */     catch (SQLException e)
/*      */     {
/*      */       boolean bool;
/* 1230 */       boolean bool = false;
/* 1231 */       this.log.error("新增生成日志失败, " + plog + ", " + e.getMessage());
/* 1232 */       e.printStackTrace();
/*      */ 
/* 1234 */       if (ps != null)
/*      */         try {
/* 1236 */           ps.close();
/*      */         } catch (SQLException e) {
/* 1238 */           boolean bool = false;
/* 1239 */           this.log.error("新增生成日志后关闭Statement异常, " + plog + ", " + e.getMessage());
/* 1240 */           e.printStackTrace();
/*      */         }
/*      */     }
/*      */     finally
/*      */     {
/* 1234 */       if (ps != null) {
/*      */         try {
/* 1236 */           ps.close();
/*      */         } catch (SQLException e) {
/* 1238 */           boolean bool = false;
/* 1239 */           this.log.error("新增生成日志后关闭Statement异常, " + plog + ", " + e.getMessage());
/* 1240 */           e.printStackTrace();
/*      */         }
/*      */       }
/*      */     }
/* 1244 */     return bool;
/*      */   }
/*      */ 
/*      */   public Map<String, String> getConfig()
/*      */   {
/* 1253 */     Map cmap = new HashMap();
/*      */     try {
/* 1255 */       this.statement = this.dbconn.getConnection().prepareStatement(
/* 1256 */         "select t.s_type,t.s_value from t_s_bill_para t");
/* 1257 */       this.result = this.statement.executeQuery();
/* 1258 */       while (this.result.next())
/* 1259 */         cmap.put(this.result.getString("s_type"), this.result
/* 1260 */           .getString("s_value"));
/*      */     }
/*      */     catch (SQLException e) {
/* 1263 */       e.printStackTrace();
/* 1264 */       return cmap;
/*      */     }
/* 1266 */     return cmap;
/*      */   }
/*      */ 
/*      */   public void cleanWatchState()
/*      */   {
/*      */     try
/*      */     {
/* 1273 */       this.statement = this.dbconn
/* 1274 */         .getConnection()
/* 1275 */         .prepareStatement(
/* 1276 */         "delete T_B_WATCH_STATE where S_PERIOD=?");
/* 1277 */       this.statement.setString(1, BaseParam.PERIOD_Y_M_D);
/* 1278 */       this.statement.executeUpdate();
/* 1279 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1281 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void beginWatchState()
/*      */   {
/* 1288 */     SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 1289 */     String sPrintTime = format1.format(new Date());
/*      */     try {
/* 1291 */       this.statement = this.dbconn
/* 1292 */         .getConnection()
/* 1293 */         .prepareStatement(
/* 1294 */         "insert into T_B_WATCH_STATE(S_PERIOD,C_WATCH_TIME,C_WATCH_TYPE,C_WATCH_STATE) values(?,?,'1','2')");
/* 1295 */       this.statement.setString(1, BaseParam.PERIOD_Y_M_D);
/* 1296 */       this.statement.setString(2, sPrintTime);
/* 1297 */       this.statement.executeUpdate();
/* 1298 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1300 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void endWatchState(String state)
/*      */   {
/* 1309 */     SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 1310 */     String sPrintTime = format1.format(new Date());
/*      */     try {
/* 1312 */       this.statement = this.dbconn
/* 1313 */         .getConnection()
/* 1314 */         .prepareStatement(
/* 1315 */         "update T_B_WATCH_STATE set C_WATCH_STATE=?,C_WATCH_FINISH_TIME=? where S_PERIOD=? and C_WATCH_TYPE='1' and C_WATCH_STATE='2'");
/* 1316 */       this.statement.setString(1, state);
/* 1317 */       this.statement.setString(2, sPrintTime);
/* 1318 */       this.statement.setString(3, BaseParam.PERIOD_Y_M_D);
/* 1319 */       this.statement.executeUpdate();
/* 1320 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1322 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void beginWatch() {
/* 1327 */     SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 1328 */     String sPrintTime = format1.format(new Date());
/*      */     try {
/* 1330 */       this.statement = this.dbconn
/* 1331 */         .getConnection()
/* 1332 */         .prepareStatement(
/* 1333 */         "update T_S_WATCH set C_START_TIME=?,C_STATE='1' WHERE I_ID=2");
/* 1334 */       this.statement.setString(1, sPrintTime);
/* 1335 */       this.statement.executeUpdate();
/* 1336 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1338 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void endWatch() {
/* 1343 */     SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 1344 */     String sPrintTime = format1.format(new Date());
/*      */     try {
/* 1346 */       this.statement = this.dbconn
/* 1347 */         .getConnection()
/* 1348 */         .prepareStatement(
/* 1349 */         "update T_S_WATCH set C_END_TIME=?,C_STATE='2' WHERE I_ID=2");
/* 1350 */       this.statement.setString(1, sPrintTime);
/* 1351 */       this.statement.executeUpdate();
/* 1352 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1354 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public Map<String, PaperRelatingWrap> getCityYyyzWbsByCard(String cardId)
/*      */   {
/* 1381 */     Map map = new HashMap();
/* 1382 */     PaperRelatingWrap prw = null;
/*      */     try {
/* 1384 */       this.statement = this.dbconn.getConnection().prepareStatement(CityYyyzWbsByCard_SQL);
/* 1385 */       this.statement.setString(1, BaseParam.PERIOD_Y + "-" + BaseParam.PERIOD_M);
/* 1386 */       this.statement.setString(2, BaseParam.PERIOD_D);
/* 1387 */       this.statement.setString(3, cardId);
/* 1388 */       this.result = this.statement.executeQuery();
/* 1389 */       String city = "";
/* 1390 */       while (this.result.next()) {
/* 1391 */         city = this.result.getString("S_CITY_NO");
/*      */ 
/* 1393 */         if (!map.containsKey(city))
/*      */         {
/* 1396 */           prw = new PaperRelatingWrap();
/* 1397 */           prw.setBusin(this.result.getString("S_BUSINPNT_NO"));
/* 1398 */           prw.setCity(city);
/* 1399 */           prw.setYyzNo(this.result.getString("S_PAPER_NO"));
/* 1400 */           prw.setYyzId(this.result.getString("S_ID"));
/* 1401 */           map.put(city, prw);
/*      */         }
/*      */       }
/* 1404 */       this.result.close();
/* 1405 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1407 */       e.printStackTrace();
/*      */     }
/* 1409 */     return map;
/*      */   }
/*      */ 
/*      */   public Map<String, String> queryFQJY() {
/* 1413 */     Map map = new HashMap();
/*      */     try {
/* 1415 */       this.statement = this.dbconn.getConnection().prepareStatement("select * from T_S_TRADE_NUMBER t");
/* 1416 */       this.result = this.statement.executeQuery();
/* 1417 */       while (this.result.next()) {
/* 1418 */         map.put(this.result.getString("c_trade_num"), "");
/*      */       }
/* 1420 */       this.result.close();
/* 1421 */       this.statement.close();
/*      */     } catch (SQLException e) {
/* 1423 */       e.printStackTrace();
/*      */     }
/* 1425 */     return map;
/*      */   }
/*      */ 
/*      */   public ArrayList<HisAmountBean> queryHisAmount(String account, String period)
/*      */   {
/* 1435 */     HisAmountBean bean = null;
/* 1436 */     ArrayList data = new ArrayList();
/*      */     try {
/* 1438 */       this.statement = this.dbconn.getConnection().prepareStatement("SELECT * FROM T_B_BILL_HIS_AMOUNT WHERE S_ACCOUNT = ? AND S_PERIOD = ?");
/* 1439 */       this.statement.setString(1, account);
/* 1440 */       this.statement.setString(2, period);
/* 1441 */       this.result = this.statement.executeQuery();
/* 1442 */       while (this.result.next()) {
/* 1443 */         bean = new HisAmountBean();
/* 1444 */         bean.setAccount(this.result.getString("s_account"));
/* 1445 */         bean.setType(this.result.getString("s_type"));
/* 1446 */         bean.setPeriod(this.result.getString("s_period"));
/* 1447 */         for (int i = 1; i < 13; i++) {
/* 1448 */           bean.setAmount(i, this.result.getString("i_amt_" + i));
/*      */         }
/* 1450 */         data.add(bean);
/*      */       }
/*      */     } catch (SQLException e) {
/* 1453 */       e.printStackTrace();
/*      */       try
/*      */       {
/* 1456 */         if (this.result != null) this.result.close();
/* 1457 */         if (this.statement != null) this.statement.close(); 
/*      */       }
/* 1459 */       catch (SQLException e) { e.printStackTrace(); }
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/* 1456 */         if (this.result != null) this.result.close();
/* 1457 */         if (this.statement != null) this.statement.close(); 
/*      */       }
/* 1459 */       catch (SQLException e) { e.printStackTrace(); }
/*      */ 
/*      */     }
/* 1462 */     return data;
/*      */   }
/*      */ 
/*      */   public Map<String, String> queryStageType()
/*      */   {
/* 1471 */     Map map = new HashMap();
/*      */     try {
/* 1473 */       this.statement = this.dbconn.getConnection().prepareStatement("SELECT * FROM t_s_stageplan");
/* 1474 */       this.result = this.statement.executeQuery();
/* 1475 */       while (this.result.next())
/* 1476 */         map.put(this.result.getString("s_stagetype"), this.result.getString("s_stagetype_name"));
/*      */     }
/*      */     catch (SQLException e) {
/* 1479 */       e.printStackTrace();
/*      */       try
/*      */       {
/* 1482 */         if (this.result != null) this.result.close();
/* 1483 */         if (this.statement != null) this.statement.close(); 
/*      */       }
/* 1485 */       catch (SQLException e) { e.printStackTrace(); }
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/* 1482 */         if (this.result != null) this.result.close();
/* 1483 */         if (this.statement != null) this.statement.close(); 
/*      */       }
/* 1485 */       catch (SQLException e) { e.printStackTrace(); }
/*      */ 
/*      */     }
/* 1488 */     return map;
/*      */   }
/*      */ 
/*      */   public String queryAsset(String account)
/*      */   {
/* 1497 */     String returnStr = "";
/*      */     try {
/* 1499 */       this.statement = this.dbconn.getConnection().prepareStatement("select * from t_b_customer_asset WHERE s_account = ? ORDER BY s_rec_type", 
/* 1500 */         1005, 1008);
/* 1501 */       this.statement.setString(1, account);
/* 1502 */       this.result = this.statement.executeQuery();
/*      */ 
/* 1504 */       if (this.result.last()) {
/* 1505 */         this.result.first();
/* 1506 */         returnStr = returnStr + this.result.getString("s_desc").trim();
/*      */       }
/* 1508 */       while (this.result.next()) {
/* 1509 */         returnStr = returnStr + "、" + this.result.getString("s_desc").trim();
/*      */       }
/* 1511 */       if (!"".equals(returnStr))
/* 1512 */         returnStr = returnStr + "。";
/*      */     }
/*      */     catch (SQLException e) {
/* 1515 */       e.printStackTrace();
/*      */       try
/*      */       {
/* 1518 */         if (this.result != null) this.result.close();
/* 1519 */         if (this.statement != null) this.statement.close(); 
/*      */       }
/* 1521 */       catch (SQLException e) { e.printStackTrace(); }
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/* 1518 */         if (this.result != null) this.result.close();
/* 1519 */         if (this.statement != null) this.statement.close(); 
/*      */       }
/* 1521 */       catch (SQLException e) { e.printStackTrace(); }
/*      */ 
/*      */     }
/* 1524 */     return returnStr;
/*      */   }
/*      */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.normal.DBDao
 * JD-Core Version:    0.6.2
 */