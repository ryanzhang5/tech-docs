/*     */ package com.bill.normal;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.bean.Card;
/*     */ import com.bill.bean.Plog;
/*     */ import com.bill.make.Common;
/*     */ import com.bill.make.ResultTask;
/*     */ import com.bill.make.ResultWrite;
/*     */ import com.bill.make.ThreadSleeper;
/*     */ import com.bill.make.XMLWrite;
/*     */ import com.bill.make.XmlFileOutput;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ArrayBlockingQueue;
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class TaskAllot
/*     */   implements Callable<String>
/*     */ {
/*  36 */   private static Logger log = Logger.getLogger(TaskAllot.class);
/*     */   private Card card;
/*     */   private int maxThreedNumber;
/*     */   private int maxBatchNumber;
/*     */   private boolean hasCompleInfo;
/*     */   private boolean hasFileInfo;
/*     */ 
/*     */   public TaskAllot(Card card, int maxThreedNumber, int maxBatchNumber, boolean hasCompleInfo, boolean hasFileInfo)
/*     */   {
/*  52 */     this.card = card;
/*  53 */     this.maxThreedNumber = maxThreedNumber;
/*  54 */     this.maxBatchNumber = maxBatchNumber;
/*  55 */     this.hasCompleInfo = hasCompleInfo;
/*  56 */     this.hasFileInfo = hasFileInfo;
/*     */   }
/*     */ 
/*     */   public String call()
/*     */     throws Exception
/*     */   {
/*  63 */     log.debug(this.card.getName() + "(" + this.card.getId() + ")  任务线程开始执行. 启动线程数:" + 
/*  64 */       this.maxThreedNumber + " 批次数据:" + this.maxBatchNumber);
/*     */ 
/*  68 */     ExecutorService exec = Executors.newFixedThreadPool(this.maxThreedNumber + 1);
/*     */ 
/*  70 */     BlockingQueue queue = new ArrayBlockingQueue(this.maxThreedNumber);
/*     */ 
/*  73 */     TaskData select = new TaskData(this.maxBatchNumber, this.maxThreedNumber, queue, this.card);
/*  74 */     exec.execute(select);
/*     */ 
/*  76 */     DBDao dao = DBDao.getInstance();
/*     */ 
/*  78 */     Map relatMap = dao.getCityYyyzWbsByCard(this.card.getId());
/*     */ 
/*  81 */     XMLWrite write = new XMLWrite(this.card, new FilePathCreate());
/*     */ 
/*  84 */     List tasks = new ArrayList();
/*  85 */     for (int i = 0; i < this.maxThreedNumber; i++) {
/*  86 */       tasks.add(new TaskComplex(this.card, queue, write, relatMap, this.hasCompleInfo));
/*     */     }
/*     */ 
/*  89 */     long t1 = System.currentTimeMillis();
/*  90 */     List resList = null;
/*     */     try
/*     */     {
/*  93 */       resList = exec.invokeAll(tasks);
/*     */     } catch (InterruptedException e) {
/*  95 */       e.printStackTrace();
/*     */     }
/*  97 */     exec.shutdown();
/*     */ 
/* 100 */     ComposeXml.sleeper.resetSleepTime(this.maxThreedNumber);
/*     */ 
/* 102 */     long t2 = System.currentTimeMillis();
/*     */ 
/* 105 */     write.close();
/*     */ 
/* 108 */     writeDBLog(write, dao, resList);
/*     */ 
/* 111 */     dao.close();
/*     */ 
/* 114 */     String str = this.card.getName() + ": " + 
/* 115 */       " 查询:" + select.getQueryNum() + 
/* 116 */       "条, 写入:" + write.getWriteNum() + 
/* 117 */       "条, 耗时:" + Common.timeFormat(t2 - t1);
/*     */ 
/* 119 */     if (this.hasCompleInfo) {
/* 120 */       str = str + getComplexResult(resList);
/*     */     }
/* 122 */     if (this.hasFileInfo) {
/* 123 */       str = str + getWriteResult(write);
/*     */     }
/* 125 */     log.debug(this.card.getName() + "(" + this.card.getId() + ")  任务线程结束执行");
/* 126 */     return str;
/*     */   }
/*     */ 
/*     */   private void writeDBLog(XMLWrite write, DBDao dao, List<Future<ResultTask>> resList)
/*     */   {
/* 134 */     int errorNum = 0;
/* 135 */     for (int i = 0; i < resList.size(); i++) {
/*     */       try {
/* 137 */         ResultTask task = (ResultTask)((Future)resList.get(i)).get();
/* 138 */         errorNum += task.getErrorNum();
/*     */       } catch (Exception e) {
/* 140 */         e.printStackTrace();
/* 141 */         log.error(this.card.getName() + "(" + this.card.getId() + ") 线程" + i + " 无法取得错误条件结果.");
/*     */       }
/*     */     }
/* 144 */     boolean bool = true;
/* 145 */     Plog p = new Plog();
/* 146 */     p.setCard_id(this.card.getId());
/* 147 */     p.setStmtdate(BaseParam.PERIOD);
/* 148 */     p.setPaper_no("");
/* 149 */     p.setState("1");
/*     */ 
/* 152 */     SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 153 */     Date date = new Date();
/*     */ 
/* 155 */     XmlFileOutput eOut = write.getEmailOut();
/*     */ 
/* 157 */     for (ResultWrite rw : eOut.getHistory()) {
/* 158 */       p.setShare(rw.getWriteNum());
/* 159 */       p.setFilename(rw.getFilePath());
/*     */ 
/* 161 */       date.setTime(rw.getCreateTime());
/* 162 */       p.setStart_time(sdf.format(date));
/*     */ 
/* 164 */       date.setTime(rw.getEndTime());
/* 165 */       p.setEnd_time(sdf.format(date));
/*     */ 
/* 167 */       if (bool) {
/* 168 */         p.setError(errorNum);
/* 169 */         bool = false;
/*     */       } else {
/* 171 */         p.setError(0);
/* 172 */       }dao.recordDBLog(p);
/*     */     }
/* 174 */     bool = true;
/* 175 */     Collection list = write.getPaperOut();
/*     */     Iterator localIterator3;
/* 176 */     for (Iterator localIterator2 = list.iterator(); localIterator2.hasNext(); 
/* 182 */       localIterator3.hasNext())
/*     */     {
/* 176 */       XmlFileOutput pOut = (XmlFileOutput)localIterator2.next();
/*     */ 
/* 179 */       p.setBusinpnt_no(pOut.getWbsId());
/* 180 */       p.setPaper_no(pOut.getYyzId());
/*     */ 
/* 182 */       localIterator3 = pOut.getHistory().iterator(); continue; ResultWrite rw = (ResultWrite)localIterator3.next();
/* 183 */       p.setShare(rw.getWriteNum());
/* 184 */       p.setFilename(rw.getFilePath());
/*     */ 
/* 186 */       date.setTime(rw.getCreateTime());
/* 187 */       p.setStart_time(sdf.format(date));
/*     */ 
/* 189 */       date.setTime(rw.getEndTime());
/* 190 */       p.setEnd_time(sdf.format(date));
/*     */ 
/* 192 */       if (bool) {
/* 193 */         p.setError(errorNum);
/* 194 */         bool = false;
/*     */       } else {
/* 196 */         p.setError(0);
/* 197 */       }dao.recordDBLog(p);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getWriteResult(XMLWrite write)
/*     */   {
/* 208 */     StringBuilder sb = new StringBuilder();
/* 209 */     XmlFileOutput eOut = write.getEmailOut();
/* 210 */     if (eOut.getHistory().size() > 0) {
/* 211 */       sb.append("\n   电子xml文件:");
/* 212 */       for (ResultWrite rw : eOut.getHistory()) {
/* 213 */         sb.append("\n   ").append(rw.getFileName()).append("   ").append(rw.getWriteNum());
/*     */       }
/*     */     }
/* 216 */     Collection coll = write.getPaperOut();
/* 217 */     if (coll.size() > 0) {
/* 218 */       String temp = "\n   纸制xml文件:";
/* 219 */       StringBuilder s = new StringBuilder();
/*     */       Iterator localIterator3;
/* 220 */       for (Iterator localIterator2 = coll.iterator(); localIterator2.hasNext(); 
/* 221 */         localIterator3.hasNext())
/*     */       {
/* 220 */         XmlFileOutput pOut = (XmlFileOutput)localIterator2.next();
/* 221 */         localIterator3 = pOut.getHistory().iterator(); continue; ResultWrite rw = (ResultWrite)localIterator3.next();
/* 222 */         s.append("\n   ").append(rw.getFileName()).append("   ").append(rw.getWriteNum());
/*     */       }
/*     */ 
/* 225 */       if (s.length() > 0) {
/* 226 */         sb.append(temp).append(s.toString());
/*     */       }
/*     */     }
/* 229 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private String getComplexResult(List<Future<ResultTask>> resList)
/*     */   {
/* 238 */     StringBuilder sb = new StringBuilder();
/*     */ 
/* 240 */     long html_setup1 = 0L;
/* 241 */     long html_setup2 = 0L;
/* 242 */     long html_setup3 = 0L;
/* 243 */     long html_setup4 = 0L;
/* 244 */     long html_setup5 = 0L;
/* 245 */     long html_setup6 = 0L;
/* 246 */     long html_setup7 = 0L;
/* 247 */     long html_setup8 = 0L;
/* 248 */     long html_write = 0L;
/*     */ 
/* 250 */     long page_setup1 = 0L;
/* 251 */     long page_setup2 = 0L;
/* 252 */     long page_setup3 = 0L;
/* 253 */     long page_setup4 = 0L;
/* 254 */     long page_setup5 = 0L;
/* 255 */     long page_setup6 = 0L;
/* 256 */     long page_setup7 = 0L;
/* 257 */     long page_setup8 = 0L;
/* 258 */     long page_write = 0L;
/*     */ 
/* 262 */     for (int i = 0; i < resList.size(); i++) {
/* 263 */       sb.append("\n   线程").append(i).append("--");
/* 264 */       ResultTask task = null;
/*     */       try {
/* 266 */         task = (ResultTask)((Future)resList.get(i)).get();
/*     */       } catch (InterruptedException e) {
/* 268 */         sb.append("无法取得结果." + e.getMessage());
/* 269 */         e.printStackTrace();
/*     */       } catch (ExecutionException e) {
/* 271 */         sb.append("无法取得结果." + e.getMessage());
/* 272 */         e.printStackTrace();
/*     */       }
/* 274 */       if (task != null) {
/* 275 */         sb.append("接收:").append(task.getReceive())
/* 276 */           .append("条, 合成:").append(task.getComplex())
/* 277 */           .append("条, 耗时:").append(Common.timeFormat(task.getTime()));
/* 278 */         html_setup1 += task.getHtml_setup1();
/* 279 */         html_setup2 += task.getHtml_setup2();
/* 280 */         html_setup3 += task.getHtml_setup3();
/* 281 */         html_setup4 += task.getHtml_setup4();
/* 282 */         html_setup5 += task.getHtml_setup5();
/* 283 */         html_setup6 += task.getHtml_setup6();
/* 284 */         html_setup7 += task.getHtml_setup7();
/* 285 */         html_setup8 += task.getHtml_setup8();
/* 286 */         html_write += task.getHtml_write();
/*     */ 
/* 288 */         page_setup1 += task.getPage_setup1();
/* 289 */         page_setup2 += task.getPage_setup2();
/* 290 */         page_setup3 += task.getPage_setup3();
/* 291 */         page_setup4 += task.getPage_setup4();
/* 292 */         page_setup5 += task.getPage_setup5();
/* 293 */         page_setup6 += task.getPage_setup6();
/* 294 */         page_setup7 += task.getPage_setup7();
/* 295 */         page_setup8 += task.getPage_setup8();
/* 296 */         page_write += task.getPage_write();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 301 */     sb.append("\n-------------------------------------")
/* 302 */       .append("\n电子(基本信息)耗时:").append(Common.timeFormat(html_setup1))
/* 303 */       .append("\n电子(插槽信息)耗时:").append(Common.timeFormat(html_setup2))
/* 304 */       .append("\n电子(汇总信息)耗时:").append(Common.timeFormat(html_setup3))
/* 305 */       .append("\n电子(汇总明细)耗时:").append(Common.timeFormat(html_setup4))
/* 306 */       .append("\n电子(购汇信息)耗时:").append(Common.timeFormat(html_setup5))
/* 307 */       .append("\n电子(交易明细)耗时:").append(Common.timeFormat(html_setup6))
/* 308 */       .append("\n电子(积分数据)耗时:").append(Common.timeFormat(html_setup7))
/* 309 */       .append("\n电子(电子模板)耗时:").append(Common.timeFormat(html_setup8))
/* 310 */       .append("\n电子(数据写入)耗时:").append(Common.timeFormat(html_write))
/* 312 */       .append("\n\n纸质(基本信息)耗时:").append(Common.timeFormat(page_setup1))
/* 313 */       .append("\n纸质(插槽信息)耗时:").append(Common.timeFormat(page_setup2))
/* 314 */       .append("\n纸质(汇总信息)耗时:").append(Common.timeFormat(page_setup3))
/* 315 */       .append("\n纸质(汇总明细)耗时:").append(Common.timeFormat(page_setup4))
/* 316 */       .append("\n纸质(购汇信息)耗时:").append(Common.timeFormat(page_setup5))
/* 317 */       .append("\n纸质(交易明细)耗时:").append(Common.timeFormat(page_setup6))
/* 318 */       .append("\n纸质(积分数据)耗时:").append(Common.timeFormat(page_setup7))
/* 319 */       .append("\n纸质(电子模板)耗时:").append(Common.timeFormat(page_setup8))
/* 320 */       .append("\n纸质(数据写入)耗时:").append(Common.timeFormat(page_write));
/* 321 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.normal.TaskAllot
 * JD-Core Version:    0.6.2
 */