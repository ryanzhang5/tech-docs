/*    */ package com.bill.normal;
/*    */ 
/*    */ import com.bill.bean.BaseParam;
/*    */ import com.bill.bean.Card;
/*    */ import com.bill.make.IFilePathCreate;
/*    */ import java.io.File;
/*    */ 
/*    */ public class FilePathCreate
/*    */   implements IFilePathCreate
/*    */ {
/*    */   public String getEmailFileNamePath(Card card)
/*    */   {
/* 20 */     String periodPath = BaseParam.PERIOD_Y + File.separator + 
/* 21 */       BaseParam.PERIOD_M + File.separator + 
/* 22 */       BaseParam.PERIOD_D;
/*    */ 
/* 24 */     String fileName = BaseParam.PERIOD + "_" + card.getId() + "_$.xml";
/* 25 */     String fileDir = BaseParam.getXMLPATH() + card.getType() + File.separator + 
/* 26 */       "PRODUCT" + File.separator + 
/* 27 */       "XML" + File.separator + 
/* 28 */       periodPath + File.separator + 
/* 29 */       "HTML" + File.separator;
/* 30 */     return fileDir + fileName;
/*    */   }
/*    */ 
/*    */   public String getPaperFileNamePath(Card card, String yyz, String wbs)
/*    */   {
/* 38 */     String periodPath = BaseParam.PERIOD_Y + File.separator + 
/* 39 */       BaseParam.PERIOD_M + File.separator + 
/* 40 */       BaseParam.PERIOD_D;
/*    */ 
/* 42 */     String fileName = BaseParam.PERIOD + "_" + card.getId() + "_" + yyz + "_" + wbs + "_$.xml";
/* 43 */     String fileDir = BaseParam.XML_PATH + card.getType() + File.separator + 
/* 44 */       "PRODUCT" + File.separator + 
/* 45 */       "XML" + File.separator + 
/* 46 */       periodPath + File.separator + 
/* 47 */       "TNO" + File.separator + 
/* 48 */       wbs + File.separator;
/* 49 */     return fileDir + fileName;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.normal.FilePathCreate
 * JD-Core Version:    0.6.2
 */