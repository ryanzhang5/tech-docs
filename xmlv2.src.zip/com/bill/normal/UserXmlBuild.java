/*     */ package com.bill.normal;
/*     */ 
/*     */ import com.bill.bean.UserBase;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class UserXmlBuild
/*     */ {
/*  14 */   private Map<String, String> cache = new HashMap();
/*     */   private UserBase ub;
/*     */   private DBDao dao;
/*     */   private UserXml ux;
/*  20 */   public long xml_setup1 = 0L;
/*  21 */   public long xml_setup2 = 0L;
/*  22 */   public long xml_setup3 = 0L;
/*  23 */   public long xml_setup4 = 0L;
/*  24 */   public long xml_setup5 = 0L;
/*  25 */   public long xml_setup6 = 0L;
/*  26 */   public long xml_setup7 = 0L;
/*  27 */   public long xml_setup8 = 0L;
/*     */ 
/*     */   public UserXmlBuild() {
/*  30 */     this.dao = DBDao.getInstance();
/*  31 */     this.ux = new UserXml(this.dao);
/*     */   }
/*     */ 
/*     */   public void setUser(UserBase ub) {
/*  35 */     this.cache.clear();
/*  36 */     this.ub = ub;
/*     */   }
/*     */ 
/*     */   public String getEmailXml()
/*     */   {
/*  47 */     String temp = getAccInfo();
/*  48 */     if (temp == null) {
/*  49 */       return null;
/*     */     }
/*  51 */     StringBuilder sb = new StringBuilder();
/*  52 */     sb.append("<checksheet>\n");
/*     */ 
/*  55 */     sb.append(getBaseInfo());
/*     */ 
/*  58 */     sb.append("<ENVRULE>0000</ENVRULE>\n")
/*  59 */       .append("<INPRIORITY1>0</INPRIORITY1>\n")
/*  60 */       .append("<INPRIORITY2>0</INPRIORITY2>\n")
/*  61 */       .append("<INPRIORITY3>0</INPRIORITY3>\n")
/*  62 */       .append("<INPRIORITY4>0</INPRIORITY4>\n");
/*     */ 
/*  65 */     sb.append(getClickInfo());
/*     */ 
/*  68 */     sb.append(temp);
/*     */ 
/*  71 */     sb.append(getAccInfoDetail());
/*     */ 
/*  75 */     sb.append("<mccs>\n</mccs>\n<historytrend></historytrend>");
/*     */ 
/*  79 */     sb.append(getBuy());
/*     */ 
/*  82 */     sb.append(getDebitInfo());
/*     */ 
/*  84 */     sb.append(getStageplan());
/*     */ 
/*  87 */     sb.append(getPoint());
/*     */ 
/*  90 */     sb.append(getEmailTemplate());
/*     */ 
/*  93 */     sb.append("<html5resources>\n<lists>\n</lists>\n</html5resources>\n");
/*  94 */     sb.append("</checksheet>\n");
/*  95 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String getPaperXml(String wbs)
/*     */   {
/* 105 */     String temp = getAccInfo();
/* 106 */     if (temp == null) {
/* 107 */       return null;
/*     */     }
/* 109 */     StringBuilder sb = new StringBuilder();
/* 110 */     sb.append("<checksheet>\n");
/*     */ 
/* 113 */     sb.append(getBaseInfo());
/*     */ 
/* 116 */     sb.append(getPaperEnvrule(wbs));
/*     */ 
/* 119 */     sb.append(temp);
/*     */ 
/* 122 */     sb.append(getAccInfoDetail());
/* 123 */     sb.append("<mccs>\n</mccs>\n<historytrend></historytrend>");
/*     */ 
/* 125 */     sb.append(getBuy());
/*     */ 
/* 128 */     sb.append(getDebitInfo());
/*     */ 
/* 130 */     sb.append(getStageplan());
/*     */ 
/* 133 */     sb.append(getPoint());
/*     */ 
/* 136 */     sb.append(getPaperTemplate());
/* 137 */     sb.append("<html5resources>\n<lists>\n</lists>\n</html5resources>\n");
/* 138 */     sb.append("</checksheet>\n");
/* 139 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public void close() {
/* 143 */     this.dao.close();
/*     */   }
/*     */ 
/*     */   protected String getBaseInfo()
/*     */   {
/* 151 */     String value = (String)this.cache.get("base");
/* 152 */     if (value == null) {
/* 153 */       value = this.ux.getBaseXml(this.ub);
/* 154 */       this.cache.put("base", value);
/*     */     }
/* 156 */     return value;
/*     */   }
/*     */ 
/*     */   protected String getAccInfo()
/*     */   {
/* 164 */     String value = (String)this.cache.get("accinfo");
/* 165 */     if (value == null) {
/* 166 */       value = this.ux.getAccInfoXml(this.ub);
/* 167 */       this.cache.put("accinfo", value);
/*     */     }
/* 169 */     return value;
/*     */   }
/*     */ 
/*     */   protected String getAccInfoDetail()
/*     */   {
/* 177 */     if (this.cache.get("accinfodetail") == null) {
/* 178 */       this.cache.put("accinfodetail", this.ux.getAccinfoDetail(this.ub));
/*     */     }
/* 180 */     return (String)this.cache.get("accinfodetail");
/*     */   }
/*     */ 
/*     */   protected String getStageplan()
/*     */   {
/* 188 */     if (this.cache.get("stageplan") == null) {
/* 189 */       this.cache.put("stageplan", this.ux.getStageplan(this.ub));
/*     */     }
/* 191 */     return (String)this.cache.get("stageplan");
/*     */   }
/*     */ 
/*     */   protected String getBuy()
/*     */   {
/* 199 */     if (this.cache.get("buy") == null) {
/* 200 */       this.cache.put("buy", this.ux.getBuy(this.ub));
/*     */     }
/* 202 */     return (String)this.cache.get("buy");
/*     */   }
/*     */ 
/*     */   protected String getDebitInfo()
/*     */   {
/* 210 */     String value = (String)this.cache.get("debitinfo");
/* 211 */     if (value == null) {
/* 212 */       value = this.ux.getDebitInfo(this.ub);
/* 213 */       this.cache.put("debitinfo", value);
/*     */     }
/* 215 */     return value;
/*     */   }
/*     */ 
/*     */   protected String getPoint()
/*     */   {
/* 224 */     String value = (String)this.cache.get("point");
/* 225 */     if (value == null) {
/* 226 */       value = this.ux.getPoint(this.ub);
/* 227 */       this.cache.put("point", value);
/*     */     }
/* 229 */     return value;
/*     */   }
/*     */   protected String getHtml5Template() {
/* 232 */     String temp = this.ux.writeTemplateHtml5(this.ub).toString();
/* 233 */     return temp;
/*     */   }
/*     */ 
/*     */   protected String getEmailTemplate()
/*     */   {
/* 241 */     String temp = this.ux.writeTemplate(this.ub, "2").toString();
/* 242 */     return temp;
/*     */   }
/*     */ 
/*     */   protected String getPaperTemplate()
/*     */   {
/* 250 */     String temp = this.ux.writeTemplate(this.ub, "1").toString();
/* 251 */     return temp;
/*     */   }
/*     */ 
/*     */   protected String getPaperEnvrule(String wbs)
/*     */   {
/* 259 */     String temp = this.ux.getEnvrule(wbs, this.ub);
/* 260 */     return temp;
/*     */   }
/*     */ 
/*     */   protected String getHisAmount()
/*     */   {
/* 279 */     if (this.cache.get("hisAmount") == null) {
/* 280 */       this.cache.put("hisAmount", this.ux.getHisAmount(this.ub));
/*     */     }
/* 282 */     return (String)this.cache.get("hisAmount");
/*     */   }
/*     */ 
/*     */   protected String getClickInfo() {
/* 286 */     return this.ux.getClickInfo(this.ub);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.normal.UserXmlBuild
 * JD-Core Version:    0.6.2
 */