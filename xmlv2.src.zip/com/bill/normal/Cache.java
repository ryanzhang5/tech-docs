/*     */ package com.bill.normal;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.bean.Busin;
/*     */ import com.bill.bean.Card;
/*     */ import com.bill.bean.Fodder;
/*     */ import com.bill.bean.Foldout;
/*     */ import com.bill.bean.Rule;
/*     */ import com.bill.bean.RuleF;
/*     */ import com.bill.bean.RuleM;
/*     */ import com.bill.bean.TempArea;
/*     */ import com.bill.bean.Yyz;
/*     */ import com.bill.bean.mcc;
/*     */ import com.bill.util.DESUtil;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class Cache
/*     */ {
/*     */   public static Map<String, String> configMap;
/*     */   public static List<Busin> businList;
/*     */   public static List<Card> cardList;
/*     */   public static Map<String, String> bfpntMap;
/*     */   public static Map<String, List<Yyz>> cardBfpntMap;
/*     */   public static Map<String, String> templateMap;
/*     */   public static List<mcc> mcclist;
/*     */   public static Map<String, String> mccmap;
/*     */   public static Map<String, String> mccMapMaster;
/*     */   public static Map<String, String> mccMapSub;
/*     */   private static DBDao dao;
/*  56 */   private static String MCC_NAME_E = "";
/*     */ 
/*  58 */   private static String MCC_NAME_M = "S_TYPE_NAME";
/*     */ 
/*  60 */   private static String MCC_NAME_S = "S_NAME";
/*     */   public static Map<String, String> stageTypeMap;
/*  67 */   public static Map<String, String> prodIdMapping = null;
/*     */ 
/*  69 */   public static DESUtil des = null;
/*     */ 
/*  75 */   private static Map<String, List<TempArea>> templateInfo = Collections.synchronizedMap(new HashMap());
/*     */ 
/*  82 */   private static Map<String, List<Rule>> ruleMap = Collections.synchronizedMap(new HashMap());
/*  83 */   private static Map<String, List<RuleF>> ruleFMap = Collections.synchronizedMap(new HashMap());
/*  84 */   private static Map<String, List<RuleM>> ruleMMap = Collections.synchronizedMap(new HashMap());
/*     */ 
/*  94 */   private static Map<String, Fodder> fodderMap = Collections.synchronizedMap(new HashMap());
/*     */ 
/*  99 */   private static Map<String, List<Foldout>> foldoutMap = Collections.synchronizedMap(new HashMap());
/*     */ 
/* 104 */   private static Map<String, Map<String, String>> foldoutCityMap = Collections.synchronizedMap(new HashMap());
/*     */ 
/* 120 */   public static Map<String, String> fqjyCard = new HashMap();
/*     */ 
/*     */   public static List<String> getCityByCPB(String cardid, String printid, String businId, DBDao dbdao)
/*     */   {
/* 115 */     return dbdao.getCityByCPB(cardid, printid, businId);
/*     */   }
/*     */ 
/*     */   public static List<Rule> getRuleMap(String tid, String type, String area, DBDao dbdao)
/*     */   {
/* 132 */     String key = tid + "_" + type + "_" + area;
/* 133 */     List value = (List)ruleMap.get(key);
/* 134 */     if (value == null)
/*     */     {
/* 136 */       value = dbdao.getRule(tid, type, area, BaseParam.PERIOD_YM, BaseParam.PERIOD_D);
/* 137 */       ruleMap.put(key, value);
/*     */     }
/* 139 */     return value;
/*     */   }
/*     */ 
/*     */   public static List<RuleF> getRuleFMap(String rid, DBDao dbdao)
/*     */   {
/* 148 */     List value = (List)ruleFMap.get(rid);
/* 149 */     if (value == null) {
/* 150 */       value = dbdao.getRuleF(rid);
/* 151 */       ruleFMap.put(rid, value);
/*     */     }
/* 153 */     return value;
/*     */   }
/*     */ 
/*     */   public static List<RuleM> getRuleFFList(String rid, DBDao dbdao)
/*     */   {
/* 162 */     List value = (List)ruleMMap.get(rid);
/* 163 */     if (value == null) {
/* 164 */       value = dbdao.getRuleFF(rid);
/* 165 */       ruleMMap.put(rid, value);
/*     */     }
/* 167 */     return value;
/*     */   }
/*     */ 
/*     */   public static List<TempArea> getTemplateInfo(String tid, DBDao dbdao)
/*     */   {
/* 177 */     List value = (List)templateInfo.get(tid);
/* 178 */     if (value == null) {
/* 179 */       value = dbdao.getTemplateInfo(tid);
/* 180 */       templateInfo.put(tid, value);
/*     */     }
/* 182 */     return value;
/*     */   }
/*     */ 
/*     */   public static Fodder getFodder(String fid, DBDao dbdao)
/*     */   {
/* 190 */     Fodder value = null;
/* 191 */     if (fodderMap.containsKey(fid)) {
/* 192 */       value = (Fodder)fodderMap.get(fid);
/*     */     }
/*     */     else {
/* 195 */       value = dbdao.getFodder(fid, BaseParam.PERIOD_YM);
/* 196 */       fodderMap.put(fid, value);
/*     */     }
/* 198 */     return value;
/*     */   }
/*     */ 
/*     */   public static List<Foldout> getFoldout(String bid, String cid, DBDao dbdao)
/*     */   {
/* 208 */     String key = bid + "_" + cid;
/* 209 */     List value = (List)foldoutMap.get(key);
/* 210 */     if (value == null) {
/* 211 */       value = dbdao.getFoldout(bid, cid, BaseParam.PERIOD);
/* 212 */       int i = value.size();
/* 213 */       Foldout f = null;
/* 214 */       for (; i < 4; i++) {
/* 215 */         f = new Foldout();
/* 216 */         f.setPri(1);
/* 217 */         f.setState("0");
/* 218 */         value.add(f);
/*     */       }
/* 220 */       foldoutMap.put(key, value);
/*     */     }
/* 222 */     return value;
/*     */   }
/*     */ 
/*     */   public static Map<String, String> getFoldoutCity(String id, String idx, DBDao dbdao)
/*     */   {
/* 231 */     String key = id + "_" + idx;
/* 232 */     Map value = (Map)foldoutCityMap.get(key);
/* 233 */     if (value == null) {
/* 234 */       value = dbdao.getFoldoutCity(id, idx);
/* 235 */       foldoutCityMap.put(key, value);
/*     */     }
/* 237 */     return value;
/*     */   }
/*     */ 
/*     */   public static synchronized void begin()
/*     */   {
/* 244 */     dao.cleanWatchState();
/* 245 */     dao.beginWatchState();
/* 246 */     dao.beginWatch();
/*     */   }
/*     */ 
/*     */   public static synchronized void end(String state)
/*     */   {
/* 252 */     dao.endWatchState(state);
/* 253 */     dao.endWatch();
/*     */   }
/*     */ 
/*     */   public static void init()
/*     */     throws Exception
/*     */   {
/* 261 */     if (dao == null) {
/* 262 */       dao = new DBDao();
/*     */     }
/* 264 */     if (configMap == null) {
/* 265 */       configMap = dao.getConfig();
/*     */ 
/* 267 */       BaseParam.setPeriod((String)configMap.get("PERIOD"));
/* 268 */       BaseParam.XML_PATH = (String)configMap.get("BASEPATH");
/*     */     }
/* 270 */     if (businList == null)
/*     */     {
/* 272 */       businList = dao.getBusin();
/*     */     }
/* 274 */     if (cardList == null)
/*     */     {
/* 276 */       cardList = dao.getCard();
/*     */     }
/* 278 */     if (bfpntMap == null)
/*     */     {
/* 280 */       bfpntMap = dao.getBfpntMap();
/*     */     }
/* 282 */     if (cardBfpntMap == null)
/*     */     {
/* 284 */       cardBfpntMap = dao.getCardBfpntMap();
/*     */     }
/* 286 */     if (templateMap == null)
/*     */     {
/* 288 */       templateMap = dao.getTemplateList();
/*     */     }
/*     */ 
/* 291 */     fqjyCard = dao.queryFQJY();
/*     */ 
/* 294 */     mccmap = new HashMap();
/* 295 */     mccMapMaster = new HashMap();
/* 296 */     mccMapSub = new HashMap();
/*     */ 
/* 310 */     stageTypeMap = dao.queryStageType();
/*     */ 
/* 312 */     des = new DESUtil("GLPp7Or8".getBytes());
/*     */   }
/*     */ 
/*     */   public static void close()
/*     */   {
/* 319 */     dao.close();
/*     */   }
/*     */ 
/*     */   public static boolean clearLog()
/*     */   {
/* 328 */     return dao.clearDBLog(BaseParam.PERIOD);
/*     */   }
/*     */ 
/*     */   public static boolean clearLog(List<String> arr)
/*     */   {
/* 338 */     return dao.clearDBLog(BaseParam.PERIOD, arr);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.normal.Cache
 * JD-Core Version:    0.6.2
 */