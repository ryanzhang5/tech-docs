/*    */ package com.bill.normal;
/*    */ 
/*    */ import com.bill.bean.Card;
/*    */ import com.bill.bean.UserBase;
/*    */ import com.bill.make.PaperRelatingWrap;
/*    */ import com.bill.make.ResultTask;
/*    */ import com.bill.make.ThreadSleeper;
/*    */ import com.bill.make.XMLWrite;
/*    */ import java.io.IOException;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.BlockingQueue;
/*    */ import java.util.concurrent.Callable;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class TaskComplex
/*    */   implements Callable<ResultTask>
/*    */ {
/* 24 */   private static Logger log = Logger.getLogger(TaskComplex.class);
/*    */   private BlockingQueue<List<UserBase>> queue;
/*    */   private XMLWrite write;
/* 27 */   private ResultTask result = new ResultTask();
/*    */   private UserXmlBuild uxb;
/*    */   private Map<String, PaperRelatingWrap> map;
/* 30 */   private int complexNum = 0;
/* 31 */   private int receiveNum = 0;
/*    */   private Card card;
/*    */   private boolean hasCompleInfo;
/*    */ 
/*    */   public TaskComplex(Card card, BlockingQueue<List<UserBase>> queue, XMLWrite write, Map<String, PaperRelatingWrap> map, boolean hasCompleInfo)
/*    */   {
/* 36 */     this.card = card;
/* 37 */     this.queue = queue;
/* 38 */     this.write = write;
/* 39 */     this.map = map;
/* 40 */     this.hasCompleInfo = hasCompleInfo;
/* 41 */     if (hasCompleInfo)
/* 42 */       this.uxb = new UserXmlBuildProxy();
/*    */     else
/* 44 */       this.uxb = new UserXmlBuild();
/*    */   }
/*    */ 
/*    */   public ResultTask call()
/*    */   {
/* 49 */     long t1 = System.currentTimeMillis();
/* 50 */     log.debug(this.card.getName() + "(" + this.card.getId() + ")  合成线程(" + Thread.currentThread().getName() + ")开始执行");
/*    */     try
/*    */     {
/*    */       List userList;
/* 52 */       while ((userList = (List)this.queue.take()) != Collections.EMPTY_LIST)
/*    */       {
/*    */         List userList;
/* 53 */         this.receiveNum += userList.size();
/* 54 */         process(userList);
/*    */       }
/* 56 */       this.result.setState(true);
/*    */     } catch (InterruptedException e) {
/* 58 */       this.result.setState(false);
/* 59 */       this.result.setErrorMessage(e.getMessage());
/* 60 */       log.error(this.card.getName() + "(" + this.card.getId() + ")  合成线程(" + Thread.currentThread().getName() + ")发生线程异常. " + e.getMessage());
/* 61 */       e.printStackTrace();
/*    */     } catch (IOException e) {
/* 63 */       this.result.setState(false);
/* 64 */       this.result.setErrorMessage(e.getMessage());
/* 65 */       log.error(this.card.getName() + "(" + this.card.getId() + ")  合成线程(" + Thread.currentThread().getName() + ")发生IO异常. " + e.getMessage());
/* 66 */       e.printStackTrace();
/*    */     } catch (Exception e) {
/* 68 */       this.result.setState(false);
/* 69 */       this.result.setErrorMessage(e.getMessage());
/* 70 */       log.error(this.card.getName() + "(" + this.card.getId() + ")  合成线程(" + Thread.currentThread().getName() + ")发生异常. " + e.getMessage());
/* 71 */       e.printStackTrace();
/*    */     }
/* 73 */     long t2 = System.currentTimeMillis();
/* 74 */     this.result.setTime(t2 - t1);
/* 75 */     this.result.setComplex(this.complexNum);
/* 76 */     this.result.setReceive(this.receiveNum);
/* 77 */     this.uxb.close();
/*    */ 
/* 79 */     log.debug(this.card.getName() + "(" + this.card.getId() + ")  合成线程(" + Thread.currentThread().getName() + ")结束执行");
/* 80 */     return this.result;
/*    */   }
/*    */ 
/*    */   private void process(List<UserBase> userList)
/*    */     throws IOException, InterruptedException
/*    */   {
/* 89 */     int i = 0; for (int size = userList.size(); i < size; i++) {
/* 90 */       String email = null;
/* 91 */       String paper = null;
/* 92 */       long temp_time = 0L;
/* 93 */       UserBase ub = (UserBase)userList.get(i);
/* 94 */       this.uxb.setUser((UserBase)userList.get(i));
/* 95 */       if (i % ComposeXml.sleeper.getLoopNum() == 0) {
/* 96 */         Thread.sleep(ComposeXml.sleeper.getSleepTime());
/*    */       }
/*    */ 
/* 99 */       email = this.uxb.getEmailXml();
/*    */ 
/* 101 */       if (email != null) {
/* 102 */         if (this.hasCompleInfo) {
/* 103 */           this.result.setHtml_setup1(this.uxb.xml_setup1);
/* 104 */           this.result.setHtml_setup2(this.uxb.xml_setup2);
/* 105 */           this.result.setHtml_setup3(this.uxb.xml_setup3);
/* 106 */           this.result.setHtml_setup4(this.uxb.xml_setup4);
/* 107 */           this.result.setHtml_setup5(this.uxb.xml_setup5);
/* 108 */           this.result.setHtml_setup6(this.uxb.xml_setup6);
/* 109 */           this.result.setHtml_setup7(this.uxb.xml_setup7);
/* 110 */           this.result.setHtml_setup8(this.uxb.xml_setup8);
/* 111 */           temp_time = System.currentTimeMillis();
/* 112 */           this.write.printlnHtml(email);
/* 113 */           this.result.setHtml_write(System.currentTimeMillis() - temp_time);
/*    */         } else {
/* 115 */           this.write.printlnHtml(email);
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/* 120 */       PaperRelatingWrap wrap = (PaperRelatingWrap)this.map.get(ub.getCity());
/* 121 */       if ((wrap != null) && ("Y".equals(ub.getPaperflag()))) {
/* 122 */         paper = this.uxb.getPaperXml(wrap.getBusin());
/*    */ 
/* 124 */         if (paper != null) {
/* 125 */           if (this.hasCompleInfo) {
/* 126 */             this.result.setPage_setup1(this.uxb.xml_setup1);
/* 127 */             this.result.setPage_setup2(this.uxb.xml_setup2);
/* 128 */             this.result.setPage_setup3(this.uxb.xml_setup3);
/* 129 */             this.result.setPage_setup4(this.uxb.xml_setup4);
/* 130 */             this.result.setPage_setup5(this.uxb.xml_setup5);
/* 131 */             this.result.setPage_setup6(this.uxb.xml_setup6);
/* 132 */             this.result.setPage_setup7(this.uxb.xml_setup7);
/* 133 */             this.result.setPage_setup8(this.uxb.xml_setup8);
/* 134 */             temp_time = System.currentTimeMillis();
/* 135 */             this.write.printlnPage(paper, wrap);
/* 136 */             this.result.setPage_write(System.currentTimeMillis() - temp_time);
/*    */           } else {
/* 138 */             this.write.printlnPage(paper, wrap);
/*    */           }
/*    */ 
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/* 146 */       if ((paper == null) && (email == null)) {
/* 147 */         this.result.addError();
/* 148 */         log.debug(this.card.getName() + "(" + this.card.getId() + ")  没有汇总信息. 账号= " + ub.getAcctnbr());
/*    */       }
/*    */       else {
/* 151 */         this.complexNum += 1;
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.normal.TaskComplex
 * JD-Core Version:    0.6.2
 */