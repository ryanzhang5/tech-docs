/*     */ package com.bill.makeXML.handler;
/*     */ 
/*     */ import com.bill.bean.Busin;
/*     */ import com.bill.bean.Plog;
/*     */ import com.bill.bean.UserBase;
/*     */ import com.bill.bean.Yyz;
/*     */ import com.bill.makeXML.cache.Cache;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class XmlHandler
/*     */ {
/*     */   private EXml ex;
/*     */   private PXml px;
/*     */   private UserXml ux;
/*     */   private StringBuffer xmlbase;
/*     */   private String cardid;
/*     */   private String cardtype;
/*  20 */   private int p_count = 0;
/*     */   private static Logger log;
/*     */   private Plog plog2;
/*     */   private String filename;
/*  32 */   List<UserBase> userlist = null;
/*  33 */   int size = 500;
/*  34 */   int page = 1;
/*     */ 
/*     */   public XmlHandler(String cardid, String cardtype) {
/*  37 */     log = Logger.getLogger(XmlHandler.class);
/*  38 */     if ((cardid == null) || ("".equals(cardid))) {
/*  39 */       return;
/*     */     }
/*  41 */     this.cardid = cardid;
/*  42 */     this.cardtype = cardtype;
/*  43 */     this.ex = new EXml();
/*  44 */     this.px = new PXml();
/*  45 */     this.ux = new UserXml();
/*     */   }
/*     */ 
/*     */   public void handler()
/*     */   {
/*  51 */     handler2();
/*  52 */     log.trace("卡产品ID=" + this.cardid + ",纸质账单开始打印！");
/*     */ 
/*  54 */     List yyzlist = (List)Cache.cardBfpntMap.get(this.cardid);
/*  55 */     if ((yyzlist == null) || (yyzlist.size() == 0)) {
/*  56 */       log.error("不存在有效的卡产品对应的预印纸。卡产品ID=" + this.cardid);
/*  57 */       return;
/*     */     }
/*     */ 
/*  60 */     List wbsList = Cache.businList;
/*  61 */     if ((wbsList == null) || (wbsList.size() == 0)) {
/*  62 */       log.error("不存在外包商。卡产品ID=" + this.cardid);
/*  63 */       return;
/*     */     }
/*     */ 
/*  66 */     List cityList = null;
/*     */     Iterator localIterator2;
/*  68 */     for (Iterator localIterator1 = yyzlist.iterator(); localIterator1.hasNext(); 
/*  70 */       localIterator2.hasNext())
/*     */     {
/*  68 */       Yyz yyz = (Yyz)localIterator1.next();
/*     */ 
/*  70 */       localIterator2 = wbsList.iterator(); continue; Busin b = (Busin)localIterator2.next();
/*  71 */       this.px.c_count_error = 0;
/*     */ 
/*  73 */       cityList = Cache.getCityByCPB(this.cardid, yyz.getId(), b.getId());
/*  74 */       if (cityList.size() == 0) {
/*  75 */         log.error("没有关联的城市。产品ID=" + this.cardid + ",预印纸=" + yyz.getId() + ",外包商=" + b.getId());
/*     */       }
/*     */       else {
/*  78 */         log.debug("产品ID=" + this.cardid + ",预印纸=" + yyz.getId() + ",外包商=" + b.getId() + ",城市个数=" + cityList.size());
/*     */ 
/*  81 */         this.filename = this.px.create(this.cardid, b.getId(), yyz.getPaperNo(), this.cardtype);
/*     */ 
/*  83 */         this.p_count = 0;
/*  84 */         this.plog2 = new Plog();
/*  85 */         this.plog2.setFilename(this.filename);
/*  86 */         this.plog2.setBusinpnt_no(b.getId());
/*  87 */         this.plog2.setCard_id(this.cardid);
/*  88 */         this.plog2.setPaper_no(yyz.getId());
/*  89 */         Cache.savePLogBegin(this.plog2);
/*     */ 
/*  91 */         for (String city : cityList)
/*     */         {
/*  93 */           this.page = 1;
/*     */           while (true)
/*     */           {
/*  97 */             this.userlist = this.ux.getUserBase(this.cardid, city, this.page, this.size);
/*  98 */             log.trace("产品ID=" + this.cardid + ",预印纸=" + yyz.getId() + ",城市ID=" + city + ",外包商=" + b.getId() + ",账户数目=" + this.userlist.size());
/*     */ 
/* 100 */             if (this.userlist.size() == 0) {
/* 101 */               if (1 == this.page) break;
/* 102 */               log.error("没有用户数据！产品ID=" + this.cardid + ",预印纸=" + yyz.getId() + ",城市ID=" + city + ",外包商=" + b.getId() + ",账户数目=" + this.userlist.size());
/*     */ 
/* 104 */               break;
/*     */             }
/*     */ 
/* 107 */             for (UserBase ub : this.userlist)
/* 108 */               if (!"Y".equals(ub.getPaperflag())) {
/* 109 */                 log.trace("不打印纸质账单!账号=" + ub.acctnbr);
/*     */               }
/*     */               else {
/* 112 */                 this.xmlbase = new StringBuffer();
/* 113 */                 this.xmlbase.append("<checksheet>\n");
/*     */ 
/* 115 */                 this.ux.writeBaseXml(ub, this.xmlbase);
/*     */ 
/* 117 */                 this.ux.writeEnvrule(b.getId(), ub, this.xmlbase);
/*     */ 
/* 119 */                 if (this.ux.writeAccinfoXml(ub, this.xmlbase)) {
/* 120 */                   log.error("没有汇总信息!账号=" + ub.getAcctnbr());
/* 121 */                   this.px.c_count_error += 1;
/*     */                 }
/*     */                 else
/*     */                 {
/* 125 */                   this.ux.writeAccinfoDetail(ub, this.xmlbase);
/*     */ 
/* 127 */                   this.ux.writeBuy(ub, this.xmlbase);
/*     */ 
/* 129 */                   this.ux.writeDebitinfo(ub, this.xmlbase);
/*     */ 
/* 131 */                   this.ux.writePoint(ub, this.xmlbase);
/*     */ 
/* 133 */                   this.xmlbase.append(this.ux.writeTemplate(ub, "1").toString());
/* 134 */                   this.xmlbase.append("</checksheet>\n");
/* 135 */                   this.px.write(this.xmlbase.toString());
/* 136 */                   this.p_count += 1;
/*     */                 }
/*     */               }
/* 138 */             this.page += 1;
/*     */           }
/*     */         }
/* 141 */         this.px.over(this.p_count);
/* 142 */         if (this.p_count == 0) {
/* 143 */           log.error("没有记录！filename=" + this.plog2.getFilename());
/* 144 */           Cache.savePLogDel(this.plog2);
/*     */         } else {
/* 146 */           this.plog2.setShare(this.p_count);
/* 147 */           this.plog2.setError(this.px.c_count_error);
/* 148 */           this.plog2.setState("1");
/* 149 */           Cache.savePLogEnd(this.plog2);
/*     */         }
/*     */       }
/*     */     }
/* 153 */     this.ux.colse();
/*     */   }
/*     */ 
/*     */   public void handler2() {
/* 157 */     log.trace("卡产品ID=" + this.cardid + ",电子账单开始打印！");
/*     */ 
/* 160 */     this.ex.create(this.cardid, this.cardtype);
/*     */ 
/* 162 */     this.page = 1;
/*     */     while (true)
/*     */     {
/* 166 */       this.userlist = this.ux.getUserBase(this.cardid, this.page, this.size);
/* 167 */       log.trace("产品ID=" + this.cardid + ",用户数=" + this.userlist.size() + ",page=" + this.page);
/*     */ 
/* 169 */       if (this.userlist.size() == 0) {
/* 170 */         if (1 == this.page) {
/* 171 */           log.error("没有用户数据！产品ID=" + this.cardid);
/*     */         }
/*     */ 
/* 174 */         this.ex.close();
/* 175 */         return;
/*     */       }
/*     */ 
/* 178 */       for (UserBase ub : this.userlist) {
/* 179 */         this.xmlbase = new StringBuffer();
/* 180 */         this.xmlbase.append("<checksheet>\n");
/*     */ 
/* 182 */         this.ux.writeBaseXml(ub, this.xmlbase);
/*     */ 
/* 184 */         this.xmlbase.append("<ENVRULE>0000</ENVRULE>\n");
/* 185 */         this.xmlbase.append("<INPRIORITY1>0</INPRIORITY1>\n<INPRIORITY2>0</INPRIORITY2>\n<INPRIORITY3>0</INPRIORITY3>\n<INPRIORITY4>0</INPRIORITY4>\n");
/*     */ 
/* 187 */         if (this.ux.writeAccinfoXml(ub, this.xmlbase)) {
/* 188 */           log.error("没有汇总信息!账号=" + ub.getAcctnbr());
/* 189 */           this.ex.c_count_error += 1;
/*     */         }
/*     */         else
/*     */         {
/* 193 */           this.ux.writeAccinfoDetail(ub, this.xmlbase);
/*     */ 
/* 195 */           this.ux.writeBuy(ub, this.xmlbase);
/*     */ 
/* 197 */           this.ux.writeDebitinfo(ub, this.xmlbase);
/*     */ 
/* 199 */           this.ux.writePoint(ub, this.xmlbase);
/*     */ 
/* 201 */           this.xmlbase.append(this.ux.writeTemplate(ub, "2").toString());
/*     */ 
/* 203 */           this.xmlbase.append("</checksheet>\n");
/* 204 */           this.ex.write(this.xmlbase.toString());
/*     */         }
/*     */       }
/* 206 */       this.page += 1;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.makeXML.handler.XmlHandler
 * JD-Core Version:    0.6.2
 */