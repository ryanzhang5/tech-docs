package com.bill.makeXML.handler;

public abstract interface WriteXML
{
  public abstract void write(String paramString);

  public abstract void over(int paramInt);

  public abstract String getFileInfo(String paramString1, String paramString2);
}

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.makeXML.handler.WriteXML
 * JD-Core Version:    0.6.2
 */