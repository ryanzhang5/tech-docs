/*     */ package com.bill.makeXML.cache;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.bean.Busin;
/*     */ import com.bill.bean.Card;
/*     */ import com.bill.bean.Fodder;
/*     */ import com.bill.bean.Foldout;
/*     */ import com.bill.bean.Plog;
/*     */ import com.bill.bean.Rule;
/*     */ import com.bill.bean.RuleF;
/*     */ import com.bill.bean.RuleM;
/*     */ import com.bill.bean.TempArea;
/*     */ import com.bill.bean.Template;
/*     */ import com.bill.bean.Yyz;
/*     */ import com.bill.makeXML.dao.DBDao;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class Cache
/*     */ {
/*     */   private static DBDao dao;
/*  13 */   public static Map<String, String> configMap = null;
/*     */ 
/*  18 */   public static List<Busin> businList = null;
/*     */ 
/*  22 */   public static List<Card> cardList = null;
/*     */ 
/*  31 */   public static Map<String, List<Yyz>> cardBfpntMap = null;
/*     */ 
/*  38 */   public static Map<String, String> pointCardNameMap = new HashMap();
/*     */ 
/*  46 */   public static Map<String, List<TempArea>> templateInfo = new HashMap();
/*     */ 
/*  53 */   public static Map<String, List<Rule>> ruleMap = null;
/*  54 */   public static Map<String, List<RuleF>> ruleFMap = new HashMap();
/*  55 */   public static Map<String, List<RuleM>> ruleMMap = new HashMap();
/*     */ 
/*  59 */   public static Map<String, Fodder> fodderMap = new HashMap();
/*     */ 
/*  64 */   public static Map<String, List<Foldout>> foldoutMap = new HashMap();
/*     */ 
/*  68 */   public static Map<String, Map<String, String>> foldoutCityMap = new HashMap();
/*     */ 
/*  72 */   public static Map<String, String> templateMap = null;
/*     */ 
/*     */   public static synchronized List<String> getCityByCPB(String cardid, String printid, String businId)
/*     */   {
/*  82 */     return dao.getCityByCPB(cardid, printid, businId);
/*     */   }
/*     */ 
/*     */   public static synchronized Map<String, String> getTemplateMap()
/*     */   {
/*  91 */     Map map = new HashMap();
/*  92 */     List list = dao.getTemplateList();
/*  93 */     String key = "";
/*  94 */     for (Template t : list) {
/*  95 */       key = t.getCardid() + "_" + t.getType();
/*  96 */       map.put(key, t.getId());
/*     */     }
/*  98 */     return map;
/*     */   }
/*     */ 
/*     */   public static synchronized List<Rule> getRuleMap(String tid, String type, String area)
/*     */   {
/* 108 */     if (ruleMap == null) {
/* 109 */       ruleMap = new HashMap();
/*     */     }
/* 111 */     if (ruleMap.containsKey(tid + "_" + type + "_" + area))
/*     */     {
/* 113 */       return (List)ruleMap.get(tid + "_" + type + "_" + area);
/*     */     }
/* 115 */     List list = dao.getRule(tid, type, area, BaseParam.PERIOD_YM, BaseParam.PERIOD_D);
/* 116 */     ruleMap.put(tid + "_" + type + "_" + area, list);
/* 117 */     return list;
/*     */   }
/*     */ 
/*     */   public static synchronized List<RuleF> getRuleFMap(String rid)
/*     */   {
/* 126 */     if (ruleFMap.containsKey(rid)) {
/* 127 */       return (List)ruleFMap.get(rid);
/*     */     }
/*     */ 
/* 130 */     List list = dao.getRuleF(rid);
/* 131 */     ruleFMap.put(rid, list);
/* 132 */     return list;
/*     */   }
/*     */ 
/*     */   public static synchronized List<RuleM> getRuleFFList(String rid)
/*     */   {
/* 141 */     if (ruleMMap.containsKey(rid)) {
/* 142 */       return (List)ruleMMap.get(rid);
/*     */     }
/*     */ 
/* 145 */     List list = dao.getRuleFF(rid);
/* 146 */     ruleMMap.put(rid, list);
/* 147 */     return list;
/*     */   }
/*     */ 
/*     */   public static synchronized List<TempArea> getTemplateInfo(String tid)
/*     */   {
/* 158 */     if ((templateInfo != null) && (templateInfo.containsKey(tid))) {
/* 159 */       return (List)templateInfo.get(tid);
/*     */     }
/* 161 */     List list = dao.getTemplateInfo(tid);
/* 162 */     templateInfo.put(tid, list);
/* 163 */     return list;
/*     */   }
/*     */ 
/*     */   public static synchronized Fodder getFodder(String fid)
/*     */   {
/* 172 */     if (fodderMap.containsKey(fid)) {
/* 173 */       return (Fodder)fodderMap.get(fid);
/*     */     }
/* 175 */     Fodder f = null;
/* 176 */     f = dao.getFodder(fid, BaseParam.PERIOD_YM);
/* 177 */     fodderMap.put(fid, f);
/* 178 */     return f;
/*     */   }
/*     */ 
/*     */   public static synchronized List<Foldout> getFoldout(String bid, String cid)
/*     */   {
/* 187 */     if (foldoutMap.containsKey(bid + "_" + cid)) {
/* 188 */       return (List)foldoutMap.get(bid + "_" + cid);
/*     */     }
/*     */ 
/* 191 */     List list = dao.getFoldout(bid, cid, BaseParam.getPeriod(""));
/* 192 */     if ((list.size() != 0) && (list.size() < 4)) {
/* 193 */       for (int i = list.size(); 
/* 195 */         i < 4; i++) {
/* 196 */         Foldout f = new Foldout();
/* 197 */         f.setPri(1);
/* 198 */         f.setState("0");
/* 199 */         list.add(f);
/*     */       }
/*     */     }
/* 202 */     foldoutMap.put(bid + "_" + cid, list);
/* 203 */     return list;
/*     */   }
/*     */ 
/*     */   public static synchronized Map<String, String> getFoldoutCity(String id, String idx)
/*     */   {
/* 212 */     if (foldoutCityMap.containsKey(id + "_" + idx)) {
/* 213 */       return (Map)foldoutCityMap.get(id + "_" + idx);
/*     */     }
/*     */ 
/* 216 */     Map cityMap = dao.getFoldoutCity(id, idx);
/* 217 */     foldoutCityMap.put(id + "_" + id, cityMap);
/* 218 */     return cityMap;
/*     */   }
/*     */ 
/*     */   public static synchronized int savePLogBegin(Plog log)
/*     */   {
/* 227 */     log.setStmtdate(BaseParam.PERIOD);
/* 228 */     log.setStart_time(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Long.valueOf(System.currentTimeMillis())));
/* 229 */     return dao.savePLogBegin(log);
/*     */   }
/*     */ 
/*     */   public static synchronized int savePLogEnd(Plog log)
/*     */   {
/* 237 */     log.setEnd_time(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Long.valueOf(System.currentTimeMillis())));
/* 238 */     return dao.savePLogEnd(log);
/*     */   }
/*     */ 
/*     */   public static synchronized int savePLogDel(Plog log) {
/* 242 */     return dao.avePLogDel(log);
/*     */   }
/*     */ 
/*     */   public static void begin()
/*     */   {
/* 248 */     dao.beginWatchState();
/* 249 */     dao.beginWatch();
/*     */   }
/*     */ 
/*     */   public static void end(String state)
/*     */   {
/* 255 */     dao.endWatchState(state);
/* 256 */     dao.endWatch();
/*     */   }
/*     */ 
/*     */   public static void init()
/*     */   {
/* 262 */     if (dao == null) {
/* 263 */       dao = new DBDao();
/*     */     }
/*     */ 
/* 266 */     if (configMap == null) {
/* 267 */       configMap = dao.getConfig();
/*     */ 
/* 269 */       BaseParam.setPeriod((String)configMap.get("PERIOD"));
/* 270 */       BaseParam.XML_PATH = (String)configMap.get("BASEPATH");
/*     */     }
/*     */ 
/* 274 */     dao.delLog(BaseParam.PERIOD);
/*     */ 
/* 276 */     if (businList == null)
/*     */     {
/* 278 */       businList = dao.getBusin();
/*     */     }
/* 280 */     if (cardList == null)
/*     */     {
/* 282 */       cardList = dao.getCard();
/*     */     }
/*     */ 
/* 288 */     if (cardBfpntMap == null)
/*     */     {
/* 290 */       cardBfpntMap = dao.getCardBfpntMap();
/*     */     }
/* 292 */     if (templateMap == null)
/*     */     {
/* 294 */       templateMap = getTemplateMap();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void initPARAData()
/*     */   {
/* 300 */     if (dao == null) {
/* 301 */       dao = new DBDao();
/*     */     }
/*     */ 
/* 304 */     if (configMap == null)
/* 305 */       configMap = dao.getConfig();
/*     */   }
/*     */ 
/*     */   public static void colse()
/*     */   {
/* 314 */     dao.close();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.makeXML.cache.Cache
 * JD-Core Version:    0.6.2
 */