/*     */ package com.bill.makeXML.util;
/*     */ 
/*     */ import com.bill.util.config.ConfigReader;
/*     */ import java.io.InputStream;
/*     */ import java.util.Properties;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.PropertyConfigurator;
/*     */ 
/*     */ public class LogInit
/*     */ {
/*     */   public static void init(String logFileName)
/*     */   {
/*  16 */     Properties properties = null;
/*  17 */     InputStream inputStream = null;
/*     */     try
/*     */     {
/*  20 */       properties = new Properties();
/*  21 */       inputStream = LogInit.class.getClassLoader().getResourceAsStream(ConfigReader.LOG_PATH);
/*     */ 
/*  24 */       properties.load(inputStream);
/*  25 */       String fileName = properties.getProperty("log4j.appender.DailyFile.File");
/*  26 */       properties.setProperty("log4j.appender.DailyFile.File", fileName.replace("<logfilename>", logFileName));
/*     */ 
/*  28 */       PropertyConfigurator.configure(properties);
/*     */     }
/*     */     catch (Exception eLog) {
/*     */       try {
/*  32 */         if (inputStream != null)
/*  33 */           inputStream.close();
/*     */       }
/*     */       catch (Exception eClose) {
/*  36 */         eClose.printStackTrace();
/*     */       }
/*  38 */       eLog.printStackTrace();
/*  39 */       System.exit(-1);
/*     */       try
/*     */       {
/*  43 */         if (inputStream != null)
/*  44 */           inputStream.close();
/*     */       }
/*     */       catch (Exception eClose) {
/*  47 */         eClose.printStackTrace();
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/*  43 */         if (inputStream != null)
/*  44 */           inputStream.close();
/*     */       }
/*     */       catch (Exception eClose) {
/*  47 */         eClose.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void init(String logpath, String logFileName)
/*     */   {
/*  58 */     Properties properties = null;
/*  59 */     InputStream inputStream = null;
/*     */     try
/*     */     {
/*  62 */       properties = new Properties();
/*  63 */       inputStream = LogInit.class.getClassLoader().getResourceAsStream(logpath);
/*     */ 
/*  66 */       properties.load(inputStream);
/*  67 */       String fileName = properties.getProperty("log4j.appender.DailyFile.File");
/*  68 */       properties.setProperty("log4j.appender.DailyFile.File", fileName.replace("<logfilename>", logFileName));
/*     */ 
/*  70 */       PropertyConfigurator.configure(properties);
/*     */     }
/*     */     catch (Exception eLog) {
/*     */       try {
/*  74 */         if (inputStream != null)
/*  75 */           inputStream.close();
/*     */       }
/*     */       catch (Exception eClose) {
/*  78 */         eClose.printStackTrace();
/*     */       }
/*  80 */       eLog.printStackTrace();
/*  81 */       System.exit(-1);
/*     */       try
/*     */       {
/*  85 */         if (inputStream != null)
/*  86 */           inputStream.close();
/*     */       }
/*     */       catch (Exception eClose) {
/*  89 */         eClose.printStackTrace();
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/*  85 */         if (inputStream != null)
/*  86 */           inputStream.close();
/*     */       }
/*     */       catch (Exception eClose) {
/*  89 */         eClose.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  97 */     init("c:\\loginittest.log");
/*     */ 
/*  99 */     Logger log = Logger.getLogger(LogInit.class);
/*     */ 
/* 101 */     log.info("LonInit info");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.makeXML.util.LogInit
 * JD-Core Version:    0.6.2
 */