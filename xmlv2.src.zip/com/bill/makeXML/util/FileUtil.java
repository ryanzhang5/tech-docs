/*     */ package com.bill.makeXML.util;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.commons.codec.binary.Base64;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.dom4j.Document;
/*     */ import org.dom4j.DocumentException;
/*     */ import org.dom4j.Element;
/*     */ import org.dom4j.io.OutputFormat;
/*     */ import org.dom4j.io.SAXReader;
/*     */ import org.dom4j.io.XMLWriter;
/*     */ 
/*     */ public class FileUtil
/*     */ {
/*  34 */   private static Logger log = Logger.getLogger(FileUtil.class);
/*     */ 
/*  37 */   public static final String fileseparator = System.getProperty("file.separator");
/*     */ 
/*  40 */   private static short fileIndex = 0;
/*     */ 
/*     */   public static synchronized short getFileIndex()
/*     */   {
/*  47 */     if (fileIndex == 32767)
/*  48 */       fileIndex = 1;
/*     */     else {
/*  50 */       fileIndex = (short)(fileIndex + 1);
/*     */     }
/*  52 */     return fileIndex;
/*     */   }
/*     */ 
/*     */   public static void writeXmlFile(Document xmlDoc, String fileName)
/*     */     throws Exception
/*     */   {
/*  62 */     XMLWriter writer = null;
/*  63 */     String fileEncoding = System.getProperty("file.encoding");
/*  64 */     if (fileEncoding.equalsIgnoreCase("ISO8859-1")) {
/*  65 */       fileEncoding = "ISO-8859-1";
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  70 */       OutputFormat format = OutputFormat.createPrettyPrint();
/*  71 */       format.setEncoding(fileEncoding);
/*  72 */       format.setLineSeparator(System.getProperty("line.separator"));
/*     */ 
/*  74 */       delFile(fileName);
/*  75 */       writer = new XMLWriter(new FileWriter(fileName), format);
/*  76 */       writer.write(xmlDoc); } finally {
/*     */       try {
/*  78 */         writer.close();
/*     */       }
/*     */       catch (Exception localException)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void writeXmlFileToBase64(Document xmlDoc, String fileName)
/*     */     throws Exception
/*     */   {
/*  90 */     overElementToBase64(xmlDoc.getRootElement());
/*  91 */     writeXmlFile(xmlDoc, fileName);
/*     */   }
/*     */ 
/*     */   public static void overElementToBase64(Element ele) throws UnsupportedEncodingException {
/*  95 */     String eleText = null;
/*  96 */     for (Iterator it = ele.elementIterator(); it.hasNext(); ) {
/*  97 */       Element tmpEle = (Element)it.next();
/*  98 */       eleText = tmpEle.getText().trim();
/*  99 */       if (eleText.length() > 0) {
/* 100 */         tmpEle.setText(new String(Base64.encodeBase64(eleText.getBytes("UTF-8")), "ASCII"));
/*     */       }
/* 102 */       overElementToBase64(tmpEle);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Document readXmlFile(String fileName)
/*     */     throws Exception
/*     */   {
/* 113 */     SAXReader saxReader = new SAXReader();
/* 114 */     Document document = null;
/* 115 */     long beginTime = System.currentTimeMillis();
/*     */     while (true)
/*     */       try {
/* 118 */         return saxReader.read(new File(fileName));
/*     */       }
/*     */       catch (DocumentException e) {
/* 121 */         if (System.currentTimeMillis() - beginTime > 30000L)
/*     */         {
/* 123 */           throw e;
/*     */         }
/*     */ 
/* 126 */         document = null;
/*     */       }
/*     */   }
/*     */ 
/*     */   public static Document readXmlFileFromBase64(String fileName) throws Exception {
/* 131 */     Document doc = readXmlFile(fileName);
/* 132 */     overElementFromBase64(doc.getRootElement());
/* 133 */     return doc;
/*     */   }
/*     */ 
/*     */   public static void overElementFromBase64(Element ele) throws UnsupportedEncodingException {
/* 137 */     String eleText = null;
/* 138 */     for (Iterator it = ele.elementIterator(); it.hasNext(); ) {
/* 139 */       Element tmpEle = (Element)it.next();
/* 140 */       eleText = tmpEle.getText().trim();
/* 141 */       if (eleText.length() > 0) {
/* 142 */         tmpEle.setText(new String(Base64.decodeBase64(eleText.getBytes("ASCII")), "UTF-8"));
/*     */       }
/* 144 */       overElementFromBase64(tmpEle);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String scanFile(String directoryName)
/*     */     throws Exception
/*     */   {
/* 156 */     File file = new File(directoryName);
/*     */ 
/* 159 */     if (!file.exists()) {
/* 160 */       throw new Exception("指定目录不存在：" + directoryName);
/*     */     }
/*     */ 
/* 164 */     if (file.isFile()) {
/* 165 */       throw new Exception("扫描的不是目录：：" + directoryName);
/*     */     }
/*     */ 
/* 169 */     if (file.list().length == 0) {
/* 170 */       return null;
/*     */     }
/*     */ 
/* 174 */     File[] f = file.listFiles();
/*     */ 
/* 177 */     for (int i = 0; i < f.length; i++) {
/* 178 */       String tmpPath = f[i].getAbsolutePath();
/* 179 */       File fileTmp = new File(tmpPath);
/*     */ 
/* 181 */       if (fileTmp.isFile()) {
/* 182 */         return tmpPath;
/*     */       }
/*     */ 
/* 186 */       String sonTmp = scanFile(tmpPath);
/* 187 */       if (sonTmp != null) {
/* 188 */         return sonTmp;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 196 */     return null;
/*     */   }
/*     */ 
/*     */   public static boolean moveFile(String oldFile, String newFile)
/*     */   {
/* 207 */     File f = new File(oldFile);
/* 208 */     File f2 = new File(newFile);
/* 209 */     if (!createDirectory(newFile)) {
/* 210 */       return false;
/*     */     }
/* 212 */     return f.renameTo(f2);
/*     */   }
/*     */ 
/*     */   public static boolean rename(String oldFileName, String newFileName)
/*     */   {
/* 222 */     File f = new File(oldFileName);
/* 223 */     File f2 = new File(newFileName);
/* 224 */     return f.renameTo(f2);
/*     */   }
/*     */ 
/*     */   public static boolean createDirectory(String directory)
/*     */   {
/* 233 */     String path = directory;
/* 234 */     path = path.substring(0, path.lastIndexOf(fileseparator));
/*     */ 
/* 236 */     StringTokenizer st = new StringTokenizer(path, fileseparator);
/* 237 */     String path1 = "";
/* 238 */     if (fileseparator.equals("/")) {
/* 239 */       path1 = path1 + fileseparator;
/*     */     }
/* 241 */     path1 = path1 + st.nextToken() + fileseparator;
/* 242 */     String path2 = path1;
/* 243 */     while (st.hasMoreTokens()) {
/* 244 */       path1 = st.nextToken() + fileseparator;
/* 245 */       path2 = path2 + path1;
/* 246 */       File inbox = new File(path2);
/* 247 */       if (!inbox.exists())
/*     */       {
/* 249 */         if (!inbox.mkdir()) {
/* 250 */           return false;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 255 */     return true;
/*     */   }
/*     */ 
/*     */   public static boolean copyFile(String srcFile, String destFile)
/*     */   {
/* 265 */     File f = new File(srcFile);
/* 266 */     File f2 = new File(destFile);
/*     */ 
/* 270 */     FileInputStream fis = null;
/* 271 */     FileOutputStream fos = null;
/* 272 */     byte[] buff = new byte[1024];
/* 273 */     int readed = -1;
/*     */     try {
/* 275 */       fis = new FileInputStream(f);
/* 276 */       fos = new FileOutputStream(f2);
/* 277 */       while ((readed = fis.read(buff)) > 0) {
/* 278 */         fos.write(buff, 0, readed);
/*     */       }
/* 280 */       return true;
/*     */     } catch (IOException e) {
/* 282 */       log.error("拷贝文件失败", e);
/* 283 */       return false;
/*     */     } finally {
/* 285 */       if (fis != null) {
/*     */         try {
/* 287 */           fis.close();
/*     */         } catch (IOException e) {
/* 289 */           log.error("", e);
/*     */         }
/*     */       }
/* 292 */       if (fos != null)
/*     */         try {
/* 294 */           fos.close();
/*     */         } catch (IOException e) {
/* 296 */           log.error("", e);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void delFile(String fileName)
/*     */     throws Exception
/*     */   {
/* 308 */     File delFile = new File(fileName);
/* 309 */     if ((delFile.exists()) && 
/* 310 */       (!delFile.delete()))
/* 311 */       throw new Exception("删除文件失败!" + fileName);
/*     */   }
/*     */ 
/*     */   public static void delFileList(List fileList, String appendFilePath)
/*     */     throws Exception
/*     */   {
/* 323 */     String fileName = null;
/*     */ 
/* 325 */     for (int i = 0; i < fileList.size(); i++) {
/* 326 */       fileName = appendFilePath + fileList.get(i);
/* 327 */       delFile(fileName);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String changeFileExt(String fileName, String newExtName)
/*     */     throws Exception
/*     */   {
/* 340 */     String newFileName = fileName.substring(0, fileName.length() - 4) + 
/* 341 */       newExtName;
/*     */ 
/* 344 */     delFile(newFileName);
/* 345 */     if (!new File(fileName).renameTo(new File(newFileName))) {
/* 346 */       throw new Exception("更改文件名失败");
/*     */     }
/*     */ 
/* 349 */     return newFileName;
/*     */   }
/*     */ 
/*     */   public static String getFileName(String pathName)
/*     */   {
/* 358 */     int index1 = pathName.lastIndexOf('/');
/* 359 */     int index2 = pathName.lastIndexOf("\\");
/* 360 */     int index = index1 >= index2 ? index1 : index2;
/* 361 */     return pathName.substring(index + 1);
/*     */   }
/*     */ 
/*     */   public static boolean checkFileExists(String fileName)
/*     */   {
/* 370 */     File f = new File(fileName);
/*     */ 
/* 372 */     if (f.exists()) {
/* 373 */       return true;
/*     */     }
/* 375 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean checkListFileExists(List fileList, String filePath)
/*     */   {
/* 386 */     Iterator it = fileList.iterator();
/* 387 */     String fileName = null;
/*     */ 
/* 389 */     while (it.hasNext()) {
/* 390 */       fileName = (String)it.next();
/*     */ 
/* 392 */       if ((fileName != null) && (fileName.length() != 0))
/*     */       {
/* 396 */         if (!checkFileExists(filePath + fileName)) {
/* 397 */           return false;
/*     */         }
/*     */       }
/*     */     }
/* 401 */     return true;
/*     */   }
/*     */ 
/*     */   public static String replacePathChar(String path, String pathChar) {
/* 405 */     return StringUtils.replace(StringUtils.replace(path, "/", pathChar), "\\", pathChar);
/*     */   }
/*     */ 
/*     */   public static String getFileString(String fileName) throws IOException {
/* 409 */     StringBuffer buffer = new StringBuffer();
/*     */ 
/* 411 */     File f = new File(fileName);
/*     */ 
/* 413 */     BufferedReader br = null;
/*     */ 
/* 416 */     String tmp = null;
/* 417 */     br = new BufferedReader(new InputStreamReader(new FileInputStream(f)));
/* 418 */     while ((tmp = br.readLine()) != null) {
/* 419 */       buffer.append(tmp);
/*     */     }
/* 421 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public static String getFileHeadString(String fileName, int readLenNum)
/*     */     throws IOException
/*     */   {
/* 427 */     StringBuffer buffer = new StringBuffer();
/*     */ 
/* 429 */     File f = new File(fileName);
/*     */ 
/* 431 */     BufferedReader br = null;
/*     */ 
/* 434 */     String tmp = null;
/* 435 */     br = new BufferedReader(new InputStreamReader(new FileInputStream(f)));
/* 436 */     while ((tmp = br.readLine()) != null) {
/* 437 */       buffer.append(tmp);
/*     */     }
/* 439 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public static void main(String[] aa)
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.makeXML.util.FileUtil
 * JD-Core Version:    0.6.2
 */