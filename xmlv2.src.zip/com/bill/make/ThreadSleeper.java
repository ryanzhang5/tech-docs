/*    */ package com.bill.make;
/*    */ 
/*    */ import java.util.Random;
/*    */ 
/*    */ public class ThreadSleeper
/*    */ {
/*    */   private int base;
/*    */   private int count;
/*    */   private int activeNum;
/*    */   private int sleepTime;
/*    */   private int loopNum;
/* 15 */   private Random r = new Random(47L);
/*    */   private static ThreadSleeper sleeper;
/*    */ 
/*    */   private ThreadSleeper(int base, int count, int loop)
/*    */   {
/* 20 */     this.base = base;
/* 21 */     this.count = count;
/* 22 */     this.activeNum = count;
/* 23 */     this.loopNum = loop;
/* 24 */     resetSleepTime(0);
/*    */   }
/*    */ 
/*    */   public static ThreadSleeper getInstance(int base, int count, int loop)
/*    */   {
/* 29 */     if (sleeper == null)
/* 30 */       sleeper = new ThreadSleeper(base, count, loop);
/* 31 */     return sleeper;
/*    */   }
/*    */ 
/*    */   public synchronized void resetSleepTime(int i)
/*    */   {
/* 39 */     this.activeNum -= i;
/* 40 */     if (this.activeNum < 0) {
/* 41 */       return;
/*    */     }
/* 43 */     int rate = this.activeNum / this.base;
/* 44 */     if (rate < 2)
/* 45 */       this.sleepTime = 0;
/* 46 */     else if (rate < 3)
/* 47 */       this.sleepTime = Math.round(rate * this.count);
/*    */     else
/* 49 */       this.sleepTime = (Math.round(rate * this.count) * 3);
/*    */   }
/*    */ 
/*    */   public int getSleepTime()
/*    */   {
/* 58 */     if (this.sleepTime > 0) {
/* 59 */       int aa = this.sleepTime + this.r.nextInt(this.sleepTime / 2);
/* 60 */       return aa;
/*    */     }
/* 62 */     return 0;
/*    */   }
/*    */ 
/*    */   public int getLoopNum()
/*    */   {
/* 67 */     return this.loopNum;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.make.ThreadSleeper
 * JD-Core Version:    0.6.2
 */