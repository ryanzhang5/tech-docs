/*    */ package com.bill.make;
/*    */ 
/*    */ public class PaperRelatingWrap
/*    */ {
/*    */   private String city;
/*    */   private String busin;
/*    */   private String yyzNo;
/*    */   private String yyzId;
/*    */ 
/*    */   public String getYyzId()
/*    */   {
/* 15 */     return this.yyzId;
/*    */   }
/*    */   public void setYyzId(String yyzId) {
/* 18 */     this.yyzId = yyzId;
/*    */   }
/*    */   public String getCity() {
/* 21 */     return this.city;
/*    */   }
/*    */   public void setCity(String city) {
/* 24 */     this.city = city;
/*    */   }
/*    */   public String getBusin() {
/* 27 */     return this.busin;
/*    */   }
/*    */   public void setBusin(String busin) {
/* 30 */     this.busin = busin;
/*    */   }
/*    */   public String getYyzNo() {
/* 33 */     return this.yyzNo;
/*    */   }
/*    */   public void setYyzNo(String yyzNo) {
/* 36 */     this.yyzNo = yyzNo;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 40 */     return "city:" + this.city + ", busin:" + this.busin + ", yyzNo:" + this.yyzNo;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.make.PaperRelatingWrap
 * JD-Core Version:    0.6.2
 */