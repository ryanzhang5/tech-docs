/*     */ package com.bill.make;
/*     */ 
/*     */ public class ResultTask
/*     */ {
/*   9 */   private boolean state = true;
/*     */   private String errorMessage;
/*     */   private long time;
/*     */   private int receive;
/*     */   private int complex;
/*     */   private int errorNum;
/*  58 */   private long html_setup1 = 0L;
/*  59 */   private long html_setup2 = 0L;
/*  60 */   private long html_setup3 = 0L;
/*  61 */   private long html_setup4 = 0L;
/*  62 */   private long html_setup5 = 0L;
/*  63 */   private long html_setup6 = 0L;
/*  64 */   private long html_setup7 = 0L;
/*  65 */   private long html_setup8 = 0L;
/*  66 */   private long html_write = 0L;
/*     */ 
/*  68 */   private long page_setup1 = 0L;
/*  69 */   private long page_setup2 = 0L;
/*  70 */   private long page_setup3 = 0L;
/*  71 */   private long page_setup4 = 0L;
/*  72 */   private long page_setup5 = 0L;
/*  73 */   private long page_setup6 = 0L;
/*  74 */   private long page_setup7 = 0L;
/*  75 */   private long page_setup8 = 0L;
/*  76 */   private long page_write = 0L;
/*     */ 
/*     */   public void addError()
/*     */   {
/*  18 */     this.errorNum += 1;
/*     */   }
/*     */ 
/*     */   public int getErrorNum() {
/*  22 */     return this.errorNum;
/*     */   }
/*     */   public boolean isState() {
/*  25 */     return this.state;
/*     */   }
/*     */   public void setState(boolean state) {
/*  28 */     this.state = state;
/*     */   }
/*     */   public String getErrorMessage() {
/*  31 */     return this.errorMessage;
/*     */   }
/*     */   public void setErrorMessage(String errorMessage) {
/*  34 */     this.errorMessage = errorMessage;
/*     */   }
/*     */   public long getTime() {
/*  37 */     return this.time;
/*     */   }
/*     */   public void setTime(long time) {
/*  40 */     this.time = time;
/*     */   }
/*     */   public int getReceive() {
/*  43 */     return this.receive;
/*     */   }
/*     */   public void setReceive(int receive) {
/*  46 */     this.receive = receive;
/*     */   }
/*     */   public int getComplex() {
/*  49 */     return this.complex;
/*     */   }
/*     */   public void setComplex(int complex) {
/*  52 */     this.complex = complex;
/*     */   }
/*     */ 
/*     */   public long getHtml_setup1()
/*     */   {
/*  80 */     return this.html_setup1;
/*     */   }
/*     */   public void setHtml_setup1(long htmlSetup1) {
/*  83 */     this.html_setup1 += htmlSetup1;
/*     */   }
/*     */   public long getHtml_setup2() {
/*  86 */     return this.html_setup2;
/*     */   }
/*     */   public void setHtml_setup2(long htmlSetup2) {
/*  89 */     this.html_setup2 += htmlSetup2;
/*     */   }
/*     */   public long getHtml_setup3() {
/*  92 */     return this.html_setup3;
/*     */   }
/*     */   public void setHtml_setup3(long htmlSetup3) {
/*  95 */     this.html_setup3 += htmlSetup3;
/*     */   }
/*     */   public long getHtml_setup4() {
/*  98 */     return this.html_setup4;
/*     */   }
/*     */   public void setHtml_setup4(long htmlSetup4) {
/* 101 */     this.html_setup4 += htmlSetup4;
/*     */   }
/*     */   public long getHtml_setup5() {
/* 104 */     return this.html_setup5;
/*     */   }
/*     */   public void setHtml_setup5(long htmlSetup5) {
/* 107 */     this.html_setup5 += htmlSetup5;
/*     */   }
/*     */   public long getHtml_setup6() {
/* 110 */     return this.html_setup6;
/*     */   }
/*     */   public void setHtml_setup6(long htmlSetup6) {
/* 113 */     this.html_setup6 += htmlSetup6;
/*     */   }
/*     */   public long getHtml_setup7() {
/* 116 */     return this.html_setup7;
/*     */   }
/*     */   public void setHtml_setup7(long htmlSetup7) {
/* 119 */     this.html_setup7 += htmlSetup7;
/*     */   }
/*     */   public long getHtml_setup8() {
/* 122 */     return this.html_setup8;
/*     */   }
/*     */   public void setHtml_setup8(long htmlSetup8) {
/* 125 */     this.html_setup8 += htmlSetup8;
/*     */   }
/*     */   public long getPage_setup1() {
/* 128 */     return this.page_setup1;
/*     */   }
/*     */   public void setPage_setup1(long pageSetup1) {
/* 131 */     this.page_setup1 += pageSetup1;
/*     */   }
/*     */   public long getPage_setup2() {
/* 134 */     return this.page_setup2;
/*     */   }
/*     */   public void setPage_setup2(long pageSetup2) {
/* 137 */     this.page_setup2 += pageSetup2;
/*     */   }
/*     */   public long getPage_setup3() {
/* 140 */     return this.page_setup3;
/*     */   }
/*     */   public void setPage_setup3(long pageSetup3) {
/* 143 */     this.page_setup3 += pageSetup3;
/*     */   }
/*     */   public long getPage_setup4() {
/* 146 */     return this.page_setup4;
/*     */   }
/*     */   public void setPage_setup4(long pageSetup4) {
/* 149 */     this.page_setup4 += pageSetup4;
/*     */   }
/*     */   public long getPage_setup5() {
/* 152 */     return this.page_setup5;
/*     */   }
/*     */   public void setPage_setup5(long pageSetup5) {
/* 155 */     this.page_setup5 += pageSetup5;
/*     */   }
/*     */   public long getPage_setup6() {
/* 158 */     return this.page_setup6;
/*     */   }
/*     */   public void setPage_setup6(long pageSetup6) {
/* 161 */     this.page_setup6 += pageSetup6;
/*     */   }
/*     */   public long getPage_setup7() {
/* 164 */     return this.page_setup7;
/*     */   }
/*     */   public void setPage_setup7(long pageSetup7) {
/* 167 */     this.page_setup7 += pageSetup7;
/*     */   }
/*     */   public long getPage_setup8() {
/* 170 */     return this.page_setup8;
/*     */   }
/*     */   public void setPage_setup8(long pageSetup8) {
/* 173 */     this.page_setup8 += pageSetup8;
/*     */   }
/*     */   public long getHtml_write() {
/* 176 */     return this.html_write;
/*     */   }
/*     */   public void setHtml_write(long htmlWrite) {
/* 179 */     this.html_write += htmlWrite;
/*     */   }
/*     */   public long getPage_write() {
/* 182 */     return this.page_write;
/*     */   }
/*     */   public void setPage_write(long pageWrite) {
/* 185 */     this.page_write += pageWrite;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.make.ResultTask
 * JD-Core Version:    0.6.2
 */