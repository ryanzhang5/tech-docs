package com.bill.make;

import com.bill.bean.Card;

public abstract interface IFilePathCreate
{
  public abstract String getEmailFileNamePath(Card paramCard);

  public abstract String getPaperFileNamePath(Card paramCard, String paramString1, String paramString2);
}

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.make.IFilePathCreate
 * JD-Core Version:    0.6.2
 */