/*    */ package com.bill.make;
/*    */ 
/*    */ public class ComposeXml
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 10 */     com.bill.normal.ComposeXml.main(args);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.make.ComposeXml
 * JD-Core Version:    0.6.2
 */