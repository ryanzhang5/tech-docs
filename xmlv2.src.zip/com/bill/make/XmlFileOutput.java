/*     */ package com.bill.make;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.normal.ComposeXml;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class XmlFileOutput
/*     */ {
/*  21 */   private static Logger log = Logger.getLogger(XmlFileOutput.class);
/*     */   private File file;
/*     */   private RandomAccessFile out;
/*     */   private int maxNumber;
/*  35 */   private int onceNumber = 1;
/*  36 */   private int onceBatch = 1;
/*  37 */   private int allNumber = 0;
/*     */ 
/*  39 */   private States state = States.NEW;
/*     */ 
/*  42 */   private List<ResultWrite> history = new ArrayList();
/*     */   private String filePathTemplate;
/*     */   private String yyzId;
/*     */   private String wbsId;
/*     */   private long createTime;
/*     */ 
/*     */   public XmlFileOutput(String filePathTemplate)
/*     */   {
/*  49 */     this.filePathTemplate = filePathTemplate;
/*  50 */     if ((ComposeXml.argsMap != null) && (ComposeXml.argsMap.containsKey("-xmlcount")))
/*  51 */       this.maxNumber = ((Integer)ComposeXml.argsMap.get("-xmlcount")).intValue();
/*     */     else
/*  53 */       this.maxNumber = 10000;
/*     */   }
/*     */ 
/*     */   public synchronized void write(String s)
/*     */     throws IOException
/*     */   {
/*  63 */     if (this.state == States.NEW)
/*     */     {
/*  65 */       createNewFile();
/*     */     }
/*     */ 
/*  68 */     if (this.state == States.NORMAL)
/*     */     {
/*  70 */       if (this.onceNumber >= this.maxNumber) {
/*  71 */         createNewFile();
/*     */       }
/*     */       try
/*     */       {
/*  75 */         this.out.write(s.getBytes("utf-8"));
/*  76 */         this.onceNumber += 1;
/*  77 */         this.allNumber += 1;
/*     */       } catch (IOException e) {
/*  79 */         String str = this.file.getName() + "写入第" + (this.onceNumber + 1) + "条时异常.";
/*  80 */         log.error(str + e.getMessage());
/*  81 */         doError();
/*  82 */         IOException ex = new IOException(str);
/*  83 */         ex.initCause(e);
/*  84 */         throw ex;
/*     */       }
/*     */     } else {
/*  87 */       throw new IOException("文件操作已关闭.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void close()
/*     */   {
/*  95 */     if (this.file != null) {
/*     */       try {
/*  97 */         this.out.write(BaseParam.XML_END.getBytes("utf-8"));
/*     */       } catch (IOException e) {
/*  99 */         log.error("写文件尾错误. 路径=" + this.file.getPath() + "  " + e.getMessage());
/* 100 */         doError();
/* 101 */         return;
/*     */       }
/*     */ 
/* 104 */       ResultWrite rw = new ResultWrite();
/* 105 */       rw.setFilePath(this.file.getPath());
/* 106 */       rw.setFileName(this.file.getName());
/* 107 */       rw.setCreateTime(this.createTime);
/* 108 */       rw.setEndTime(System.currentTimeMillis());
/* 109 */       rw.setWriteNum(this.onceNumber);
/* 110 */       this.history.add(rw);
/*     */     }
/* 112 */     this.file = null;
/* 113 */     doClose();
/* 114 */     this.state = States.CLOSE;
/*     */   }
/*     */ 
/*     */   private void doError()
/*     */   {
/* 121 */     doClose();
/* 122 */     if (this.file != null)
/*     */     {
/* 124 */       String name = this.file.getPath() + ".error";
/* 125 */       this.file.renameTo(new File(name));
/* 126 */       this.file = null;
/*     */     }
/* 128 */     this.state = States.ERROR;
/*     */   }
/*     */ 
/*     */   private void doClose()
/*     */   {
/* 135 */     if (this.out != null) {
/*     */       try {
/* 137 */         this.out.close();
/*     */       } catch (IOException e) {
/* 139 */         log.error("关闭文件流时异常. " + e.getMessage());
/* 140 */         e.printStackTrace();
/*     */       }
/*     */     }
/* 143 */     this.out = null;
/*     */   }
/*     */ 
/*     */   private void createNewFile()
/*     */     throws IOException
/*     */   {
/* 154 */     if (this.state == States.NORMAL) {
/*     */       try {
/* 156 */         this.out.write(BaseParam.XML_END.getBytes("utf-8"));
/*     */       } catch (IOException e) {
/* 158 */         log.error("写文件尾错误. 路径=" + this.file.getPath() + "  " + e.getMessage());
/* 159 */         doError();
/* 160 */         throw e;
/*     */       }
/* 162 */       ResultWrite rw = new ResultWrite();
/* 163 */       rw.setFilePath(this.file.getPath());
/* 164 */       rw.setFileName(this.file.getName());
/* 165 */       rw.setCreateTime(this.createTime);
/* 166 */       rw.setEndTime(System.currentTimeMillis());
/* 167 */       rw.setWriteNum(this.onceNumber);
/* 168 */       this.history.add(rw);
/* 169 */       doClose();
/* 170 */       this.file = null;
/*     */     }
/*     */ 
/* 174 */     String pagenum = "001";
/* 175 */     if (this.onceBatch < 10)
/* 176 */       pagenum = "00" + this.onceBatch;
/* 177 */     else if (this.onceBatch < 100)
/* 178 */       pagenum = "0" + this.onceBatch;
/*     */     else {
/* 180 */       pagenum = this.onceBatch;
/*     */     }
/*     */ 
/* 183 */     String path = this.filePathTemplate.replace("$", pagenum);
/*     */ 
/* 185 */     File temp = new File(path);
/*     */ 
/* 188 */     if (temp.exists()) {
/* 189 */       temp.delete();
/* 190 */       log.info("delete file.path=" + path);
/*     */     }
/*     */     else {
/* 193 */       File catalog = temp.getParentFile();
/* 194 */       if (!catalog.exists())
/* 195 */         catalog.mkdirs();
/*     */     }
/*     */     try
/*     */     {
/* 199 */       temp.createNewFile();
/* 200 */       log.debug("create file path=" + temp.getPath());
/*     */     } catch (IOException e) {
/* 202 */       log.error("创建文件错误. 路径=" + path + "  " + e.getMessage());
/* 203 */       this.state = States.ERROR;
/* 204 */       throw e;
/*     */     }
/* 206 */     this.file = temp;
/* 207 */     this.createTime = System.currentTimeMillis();
/* 208 */     log.info("create file. path=" + path);
/*     */     try
/*     */     {
/* 211 */       this.out = new RandomAccessFile(temp, "rw");
/*     */     } catch (FileNotFoundException e) {
/* 213 */       doError();
/* 214 */       log.error("创建文件生成文件操作对象错误. 路径=" + path + "  " + e.getMessage());
/* 215 */       throw e;
/*     */     }
/*     */     try
/*     */     {
/* 219 */       this.out.write(BaseParam.XML_BEGIN.getBytes("utf-8"));
/*     */     } catch (IOException e) {
/* 221 */       log.error("写文件头错误. 路径=" + this.file.getPath() + "  " + e.getMessage());
/* 222 */       doError();
/* 223 */       throw e;
/*     */     }
/* 225 */     this.onceNumber = 0;
/* 226 */     this.onceBatch += 1;
/* 227 */     this.state = States.NORMAL;
/*     */   }
/*     */ 
/*     */   public int getAllNumber()
/*     */   {
/* 235 */     return this.allNumber;
/*     */   }
/*     */ 
/*     */   public List<ResultWrite> getHistory()
/*     */   {
/* 243 */     return this.history;
/*     */   }
/*     */ 
/*     */   public String getYyzId() {
/* 247 */     return this.yyzId;
/*     */   }
/*     */ 
/*     */   public void setYyzId(String yyzId) {
/* 251 */     this.yyzId = yyzId;
/*     */   }
/*     */ 
/*     */   public String getWbsId() {
/* 255 */     return this.wbsId;
/*     */   }
/*     */ 
/*     */   public void setWbsId(String wbsId) {
/* 259 */     this.wbsId = wbsId;
/*     */   }
/*     */ 
/*     */   public static enum States
/*     */   {
/*  25 */     NEW, 
/*  26 */     ERROR, 
/*  27 */     CLOSE, 
/*  28 */     NORMAL;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.make.XmlFileOutput
 * JD-Core Version:    0.6.2
 */