/*    */ package com.bill.yearbill;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.Callable;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class XmlThread
/*    */   implements Callable<String>
/*    */ {
/* 12 */   private static Logger log = Logger.getLogger(XmlThread.class);
/* 13 */   List<Map<String, String>> user_list = null;
/* 14 */   List<Map<String, String>> tmp_list = null;
/* 15 */   XmlDao xdao = null;
/* 16 */   StringBuffer xml_sb = new StringBuffer();
/* 17 */   XmlHandle xhan = null;
/* 18 */   private static int TOTAL_PAGE = 0; private static int size = 1000;
/* 19 */   private int page = 0;
/* 20 */   String point = "";
/*    */ 
/*    */   public XmlThread(Connection conn) {
/* 23 */     this.xdao = new XmlDao(conn);
/* 24 */     this.xhan = new XmlHandle();
/*    */   }
/*    */   public String call() {
/*    */     while (true) {
/* 28 */       this.page = getPage();
/* 29 */       this.user_list = this.xdao.queryUser(this.page, size);
/* 30 */       if (this.user_list.size() == 0) {
/*    */         break;
/*    */       }
/* 33 */       log.debug("handle user " + this.page + "," + this.user_list.size());
/* 34 */       for (Map user_map : this.user_list) {
/* 35 */         this.xml_sb = new StringBuffer();
/* 36 */         this.xhan.user(user_map, this.xml_sb);
/* 37 */         this.tmp_list = this.xdao.queryMonthly((String)user_map.get("AccountNo"));
/* 38 */         this.xhan.monthly(this.tmp_list, this.xml_sb);
/* 39 */         this.tmp_list = this.xdao.queryDetail((String)user_map.get("AccountNo"));
/* 40 */         this.xhan.detail(this.tmp_list, this.xml_sb);
/* 41 */         this.tmp_list = this.xdao.queryTotal((String)user_map.get("AccountNo"));
/* 42 */         this.xhan.total(this.tmp_list, this.xml_sb);
/* 43 */         this.point = this.xdao.queryPoint((String)user_map.get("AccountNo"));
/* 44 */         this.xhan.point(this.point, this.xml_sb);
/* 45 */         XmlHandleMain.xfile.write(this.xml_sb);
/*    */       }
/*    */       try {
/* 48 */         Thread.sleep(200L);
/*    */       } catch (InterruptedException e) {
/* 50 */         e.printStackTrace();
/*    */       }
/*    */     }
/* 53 */     return "end";
/*    */   }
/*    */   public static synchronized int getPage() {
/* 56 */     TOTAL_PAGE += 1;
/* 57 */     return TOTAL_PAGE;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.yearbill.XmlThread
 * JD-Core Version:    0.6.2
 */