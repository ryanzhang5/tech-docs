/*     */ package com.bill.yearbill;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class ImportDao
/*     */ {
/*  12 */   private static Logger log = Logger.getLogger(ImportDao.class);
/*     */ 
/*  14 */   public static String SQL_USER_INFO = "insert into t_year_user_info(s_account,s_data_type,s_zip,s_addr3,s_addr1,s_addr2,s_all_name,s_sex,s_spec_tag,s_year_rmb_cost,s_year_usd_cost,s_year_total_cost) values(?,?,?,?,?,?,?,?,?,?,?,?)";
/*  15 */   public static String SQL_MONTHLY_COST = "insert into t_year_monthly_cost(s_account, s_data_type, s_m01, s_m02, s_m03, s_m04, s_m05, s_m06, s_m07, s_m08, s_m09, s_m10, s_m11, s_m12) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
/*  16 */   public static String SQL_DETAIL_COST = "insert into t_year_detail_cost(s_account, s_data_type, s_cost_type1, s_cost_type2, s_cost_type3, s_cost_type4, s_cost_type5, s_cost_type6, s_cost_type7,s_COST_TYPE8) values(?, ?, ?, ?, ?, ?, ?, ?, ?,?)";
/*  17 */   public static String SQL_TOTAL_COST = "insert into t_year_total_cost(s_account, s_data_type, s_cost_type1, s_cost_type2, s_cost_type3, s_cost_type4) values(?, ?, ?, ?, ?, ?)";
/*  18 */   public static String SQL_POINT = "insert into t_year_point(s_account, s_data_type, s_credit) values(?, ?, ?)";
/*     */ 
/*  22 */   private static int commitNum = 10000;
/*     */ 
/*  26 */   private int userCurrNum = 0;
/*  27 */   private int totalNum = 0;
/*  28 */   private int monthlyCurrNum = 0;
/*  29 */   private int detailCurrNum = 0;
/*  30 */   private int totalCurrNum = 0;
/*  31 */   private int pointCurrNum = 0;
/*     */ 
/*  33 */   private PreparedStatement ps1 = null;
/*  34 */   private PreparedStatement ps2 = null;
/*  35 */   private PreparedStatement ps3 = null;
/*  36 */   private PreparedStatement ps4 = null;
/*  37 */   private PreparedStatement ps5 = null;
/*     */ 
/*     */   public ImportDao(Connection conn) {
/*     */     try {
/*  41 */       this.ps1 = conn.prepareStatement(SQL_USER_INFO);
/*  42 */       this.ps2 = conn.prepareStatement(SQL_MONTHLY_COST);
/*  43 */       this.ps3 = conn.prepareStatement(SQL_DETAIL_COST);
/*  44 */       this.ps4 = conn.prepareStatement(SQL_TOTAL_COST);
/*  45 */       this.ps5 = conn.prepareStatement(SQL_POINT);
/*     */ 
/*  47 */       conn.createStatement().execute("TRUNCATE table t_year_user_info");
/*  48 */       log.debug("clear table t_year_user_info end");
/*  49 */       conn.createStatement().execute("TRUNCATE table t_year_monthly_cost");
/*  50 */       log.debug("clear table t_year_monthly_cost end");
/*  51 */       conn.createStatement().execute("TRUNCATE table t_year_detail_cost");
/*  52 */       log.debug("clear table t_year_detail_cost end");
/*  53 */       conn.createStatement().execute("TRUNCATE table t_year_total_cost");
/*  54 */       log.debug("clear table t_year_total_cost end");
/*  55 */       conn.createStatement().execute("TRUNCATE table t_year_point");
/*  56 */       log.debug("clear table t_year_point end");
/*     */     } catch (SQLException e) {
/*  58 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void commitEnd() {
/*     */     try {
/*  64 */       this.ps1.executeBatch();
/*  65 */       this.totalNum += this.userCurrNum;
/*  66 */       log.debug("total commit:" + this.totalNum);
/*  67 */       this.ps1.close();
/*  68 */       this.ps2.executeBatch();
/*  69 */       this.ps2.close();
/*  70 */       this.ps3.executeBatch();
/*  71 */       this.ps3.close();
/*  72 */       this.ps4.executeBatch();
/*  73 */       this.ps4.close();
/*  74 */       this.ps5.executeBatch();
/*  75 */       this.ps5.close();
/*     */     } catch (SQLException e) {
/*  77 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void importPoint(String type, String dataStr) {
/*  82 */     if (41 > dataStr.length()) {
/*  83 */       log.error("241>" + dataStr.length() + "|" + dataStr);
/*  84 */       return;
/*     */     }
/*     */     try {
/*  87 */       this.ps5.setString(1, dataStr.substring(0, 16));
/*  88 */       this.ps5.setString(2, type);
/*  89 */       this.ps5.setString(3, dataStr.substring(20, 41).replaceAll("[\\s,]", ""));
/*  90 */       this.ps5.addBatch();
/*  91 */       this.pointCurrNum += 1;
/*  92 */       if (commitNum <= this.pointCurrNum) {
/*  93 */         this.ps5.executeBatch();
/*  94 */         this.pointCurrNum = 0;
/*     */       }
/*     */     } catch (Exception e) {
/*  97 */       log.error(dataStr.length() + "|" + dataStr);
/*     */       try {
/*  99 */         this.ps5.executeBatch();
/* 100 */         this.pointCurrNum = 0;
/*     */       } catch (SQLException e1) {
/* 102 */         e1.printStackTrace();
/*     */       }
/* 104 */       this.pointCurrNum = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void importTotal(String type, String dataStr) {
/*     */     try {
/* 110 */       this.ps4.setString(1, dataStr.substring(0, 16));
/* 111 */       this.ps4.setString(2, type);
/* 112 */       this.ps4.setString(3, dataStr.substring(20, 41).replaceAll("[\\s,]", ""));
/* 113 */       this.ps4.setString(4, dataStr.substring(41, 62).replaceAll("[\\s,]", ""));
/* 114 */       this.ps4.setString(5, dataStr.substring(62, 83).replaceAll("[\\s,]", ""));
/* 115 */       this.ps4.setString(6, dataStr.substring(83, 91).replaceAll("[\\s,%]", ""));
/* 116 */       this.ps4.addBatch();
/* 117 */       this.totalCurrNum += 1;
/* 118 */       if (commitNum <= this.totalCurrNum) {
/* 119 */         this.ps4.executeBatch();
/* 120 */         this.totalCurrNum = 0;
/*     */       }
/*     */     } catch (SQLException e) {
/* 123 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void importDetail(String type, String dataStr)
/*     */   {
/* 133 */     String str = "";
/*     */     try {
/* 135 */       this.ps3.setString(1, dataStr.substring(0, 16));
/* 136 */       this.ps3.setString(2, type);
/* 137 */       this.ps3.setString(3, dataStr.substring(20, 41).replaceAll("[\\s,]", ""));
/*     */ 
/* 139 */       if (("C001".equals(type)) || ("C011".equals(type))) {
/* 140 */         str = dataStr.substring(41, 62).replaceAll("[\\s,]", "");
/* 141 */         this.ps3.setString(4, str);
/* 142 */         str = dataStr.substring(62, 83).replaceAll("[\\s,]", "");
/* 143 */         this.ps3.setString(5, str);
/* 144 */         str = dataStr.substring(83, 104).replaceAll("[\\s,]", "");
/* 145 */         this.ps3.setString(6, str);
/* 146 */         str = dataStr.substring(104, 125).replaceAll("[\\s,]", "");
/* 147 */         this.ps3.setString(7, str);
/* 148 */         str = dataStr.substring(125, 146).replaceAll("[\\s,]", "");
/* 149 */         this.ps3.setString(8, str);
/* 150 */         str = dataStr.substring(146, 167).replaceAll("[\\s,]", "");
/* 151 */         this.ps3.setString(9, str);
/* 152 */         this.ps3.setString(10, "");
/*     */       }
/* 154 */       else if (("C002".equals(type)) || ("C003".equals(type)) || 
/* 155 */         ("C012".equals(type)) || ("C013".equals(type))) {
/* 156 */         this.ps3.setString(4, dataStr.substring(41, 62).replaceAll("[\\s,]", ""));
/* 157 */         this.ps3.setString(5, dataStr.substring(62, 83).replaceAll("[\\s,]", ""));
/* 158 */         this.ps3.setString(6, dataStr.substring(83, 104).replaceAll("[\\s,]", ""));
/* 159 */         this.ps3.setString(7, "");
/* 160 */         this.ps3.setString(8, "");
/* 161 */         this.ps3.setString(9, "");
/* 162 */         this.ps3.setString(10, "");
/*     */       }
/* 164 */       else if (("C004".equals(type)) || ("C014".equals(type))) {
/* 165 */         this.ps3.setString(4, dataStr.substring(41, 62).replaceAll("[\\s,]", ""));
/* 166 */         this.ps3.setString(5, dataStr.substring(62, 83).replaceAll("[\\s,]", ""));
/* 167 */         this.ps3.setString(6, dataStr.substring(83, 104).replaceAll("[\\s,]", ""));
/* 168 */         this.ps3.setString(7, dataStr.substring(104, 125).replaceAll("[\\s,]", ""));
/* 169 */         this.ps3.setString(8, dataStr.substring(125, 146).replaceAll("[\\s,]", ""));
/* 170 */         this.ps3.setString(9, "");
/* 171 */         this.ps3.setString(10, "");
/*     */       }
/* 173 */       else if (("C005".equals(type)) || ("C015".equals(type))) {
/* 174 */         this.ps3.setString(4, dataStr.substring(41, 62).replaceAll("[\\s,]", ""));
/* 175 */         this.ps3.setString(5, dataStr.substring(62, 83).replaceAll("[\\s,]", ""));
/* 176 */         this.ps3.setString(6, "");
/* 177 */         this.ps3.setString(7, "");
/* 178 */         this.ps3.setString(8, "");
/* 179 */         this.ps3.setString(9, "");
/* 180 */         this.ps3.setString(10, "");
/*     */       }
/* 182 */       else if (("C006".equals(type)) || ("C016".equals(type))) {
/* 183 */         this.ps3.setString(4, "");
/* 184 */         this.ps3.setString(5, "");
/* 185 */         this.ps3.setString(6, "");
/* 186 */         this.ps3.setString(7, "");
/* 187 */         this.ps3.setString(8, "");
/* 188 */         this.ps3.setString(9, "");
/* 189 */         this.ps3.setString(10, "");
/*     */       }
/* 192 */       else if ("C021".equals(type)) {
/* 193 */         this.ps3.setString(10, dataStr.substring(41, 49).replaceAll("[\\s,%]", ""));
/* 194 */         this.ps3.setString(4, dataStr.substring(49, 70).replaceAll("[\\s,]", ""));
/* 195 */         this.ps3.setString(5, dataStr.substring(70, 91).replaceAll("[\\s,]", ""));
/* 196 */         this.ps3.setString(6, dataStr.substring(91, 112).replaceAll("[\\s,]", ""));
/* 197 */         this.ps3.setString(7, dataStr.substring(112, 133).replaceAll("[\\s,]", ""));
/* 198 */         this.ps3.setString(8, dataStr.substring(133, 154).replaceAll("[\\s,]", ""));
/* 199 */         this.ps3.setString(9, dataStr.substring(154, 175).replaceAll("[\\s,]", ""));
/*     */       }
/* 201 */       else if (("C022".equals(type)) || ("C023".equals(type))) {
/* 202 */         this.ps3.setString(10, dataStr.substring(41, 49).replaceAll("[\\s,%]", ""));
/* 203 */         this.ps3.setString(4, dataStr.substring(49, 70).replaceAll("[\\s,]", ""));
/* 204 */         this.ps3.setString(5, dataStr.substring(70, 91).replaceAll("[\\s,]", ""));
/* 205 */         this.ps3.setString(6, dataStr.substring(91, 112).replaceAll("[\\s,]", ""));
/* 206 */         this.ps3.setString(7, "");
/* 207 */         this.ps3.setString(8, "");
/* 208 */         this.ps3.setString(9, "");
/*     */       }
/* 210 */       else if ("C024".equals(type)) {
/* 211 */         this.ps3.setString(10, dataStr.substring(41, 49).replaceAll("[\\s,%]", ""));
/* 212 */         this.ps3.setString(4, dataStr.substring(49, 70).replaceAll("[\\s,]", ""));
/* 213 */         this.ps3.setString(5, dataStr.substring(70, 91).replaceAll("[\\s,]", ""));
/* 214 */         this.ps3.setString(6, dataStr.substring(91, 112).replaceAll("[\\s,]", ""));
/* 215 */         this.ps3.setString(7, dataStr.substring(112, 133).replaceAll("[\\s,]", ""));
/* 216 */         this.ps3.setString(8, dataStr.substring(133, 154).replaceAll("[\\s,]", ""));
/* 217 */         this.ps3.setString(9, "");
/*     */       }
/* 219 */       else if ("C025".equals(type)) {
/* 220 */         this.ps3.setString(10, dataStr.substring(41, 49).replaceAll("[\\s,%]", ""));
/* 221 */         this.ps3.setString(4, dataStr.substring(49, 70).replaceAll("[\\s,]", ""));
/* 222 */         this.ps3.setString(5, dataStr.substring(70, 91).replaceAll("[\\s,]", ""));
/* 223 */         this.ps3.setString(6, "");
/* 224 */         this.ps3.setString(7, "");
/* 225 */         this.ps3.setString(8, "");
/* 226 */         this.ps3.setString(9, "");
/*     */       }
/* 228 */       else if ("C026".equals(type)) {
/* 229 */         this.ps3.setString(10, dataStr.substring(41, 49).replaceAll("[\\s,%]", ""));
/* 230 */         this.ps3.setString(4, "");
/* 231 */         this.ps3.setString(5, "");
/* 232 */         this.ps3.setString(6, "");
/* 233 */         this.ps3.setString(7, "");
/* 234 */         this.ps3.setString(8, "");
/* 235 */         this.ps3.setString(9, "");
/*     */       }
/* 237 */       this.ps3.addBatch();
/* 238 */       this.detailCurrNum += 1;
/* 239 */       if (commitNum <= this.detailCurrNum) {
/* 240 */         this.ps3.executeBatch();
/* 241 */         this.detailCurrNum = 0;
/*     */       }
/*     */     } catch (SQLException e) {
/* 244 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void importMonthly2(String type, String dataStr)
/*     */   {
/*     */     try
/*     */     {
/* 255 */       this.ps2.setString(1, dataStr.substring(0, 16));
/* 256 */       this.ps2.setString(2, type);
/* 257 */       this.ps2.setString(3, dataStr.substring(20, 28).replaceAll("[\\s,%]", ""));
/* 258 */       this.ps2.setString(4, dataStr.substring(28, 36).replaceAll("[\\s,%]", ""));
/* 259 */       this.ps2.setString(5, dataStr.substring(36, 44).replaceAll("[\\s,%]", ""));
/* 260 */       this.ps2.setString(6, dataStr.substring(44, 52).replaceAll("[\\s,%]", ""));
/* 261 */       this.ps2.setString(7, dataStr.substring(52, 60).replaceAll("[\\s,%]", ""));
/* 262 */       this.ps2.setString(8, dataStr.substring(60, 68).replaceAll("[\\s,%]", ""));
/* 263 */       this.ps2.setString(9, dataStr.substring(68, 76).replaceAll("[\\s,%]", ""));
/* 264 */       this.ps2.setString(10, dataStr.substring(76, 84).replaceAll("[\\s,%]", ""));
/* 265 */       this.ps2.setString(11, dataStr.substring(84, 92).replaceAll("[\\s,%]", ""));
/* 266 */       this.ps2.setString(12, dataStr.substring(92, 100).replaceAll("[\\s,%]", ""));
/* 267 */       this.ps2.setString(13, dataStr.substring(100, 108).replaceAll("[\\s,%]", ""));
/* 268 */       this.ps2.setString(14, dataStr.substring(108).replaceAll("[\\s,%]", ""));
/* 269 */       this.ps2.addBatch();
/* 270 */       this.monthlyCurrNum += 1;
/* 271 */       if (commitNum <= this.monthlyCurrNum) {
/* 272 */         this.ps2.executeBatch();
/* 273 */         this.monthlyCurrNum = 0;
/*     */       }
/*     */     } catch (SQLException e) {
/* 276 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void importMonthly(String type, String dataStr)
/*     */   {
/*     */     try
/*     */     {
/* 287 */       this.ps2.setString(1, dataStr.substring(0, 16));
/* 288 */       this.ps2.setString(2, type);
/* 289 */       this.ps2.setString(3, dataStr.substring(20, 41).replaceAll("[\\s,]", ""));
/* 290 */       this.ps2.setString(4, dataStr.substring(41, 62).replaceAll("[\\s,]", ""));
/* 291 */       this.ps2.setString(5, dataStr.substring(62, 83).replaceAll("[\\s,]", ""));
/* 292 */       this.ps2.setString(6, dataStr.substring(83, 104).replaceAll("[\\s,]", ""));
/* 293 */       this.ps2.setString(7, dataStr.substring(104, 125).replaceAll("[\\s,]", ""));
/* 294 */       this.ps2.setString(8, dataStr.substring(125, 146).replaceAll("[\\s,]", ""));
/* 295 */       this.ps2.setString(9, dataStr.substring(146, 167).replaceAll("[\\s,]", ""));
/* 296 */       this.ps2.setString(10, dataStr.substring(167, 188).replaceAll("[\\s,]", ""));
/* 297 */       this.ps2.setString(11, dataStr.substring(188, 209).replaceAll("[\\s,]", ""));
/* 298 */       this.ps2.setString(12, dataStr.substring(209, 230).replaceAll("[\\s,]", ""));
/* 299 */       this.ps2.setString(13, dataStr.substring(230, 251).replaceAll("[\\s,]", ""));
/* 300 */       this.ps2.setString(14, dataStr.substring(251, 272).replaceAll("[\\s,]", ""));
/* 301 */       this.ps2.addBatch();
/* 302 */       this.monthlyCurrNum += 1;
/* 303 */       if (commitNum <= this.monthlyCurrNum) {
/* 304 */         this.ps2.executeBatch();
/* 305 */         this.monthlyCurrNum = 0;
/*     */       }
/*     */     } catch (SQLException e) {
/* 308 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void importUser(String dataStr)
/*     */   {
/* 318 */     byte[] b = new byte[1024];
/* 319 */     byte[] tmp = new byte[1024];
/* 320 */     String str = "";
/*     */     try {
/* 322 */       b = dataStr.getBytes("GBK");
/* 323 */       if (241 > b.length) {
/* 324 */         log.error("241>" + b.length + "|" + dataStr.length() + "|" + dataStr);
/* 325 */         return;
/*     */       }
/*     */ 
/* 328 */       str = dataStr.substring(0, 16);
/* 329 */       this.ps1.setString(1, str);
/*     */ 
/* 331 */       str = dataStr.substring(16, 20);
/* 332 */       this.ps1.setString(2, str);
/*     */ 
/* 334 */       str = dataStr.substring(20, 26);
/* 335 */       this.ps1.setString(3, str);
/*     */ 
/* 337 */       tmp = new byte[30];
/* 338 */       System.arraycopy(b, 26, tmp, 0, 30);
/* 339 */       str = new String(tmp, "GBK");
/* 340 */       this.ps1.setString(4, str.replaceAll("[\\s<>]", ""));
/*     */ 
/* 342 */       tmp = new byte[40];
/* 343 */       System.arraycopy(b, 56, tmp, 0, 40);
/* 344 */       str = new String(tmp, "GBK");
/* 345 */       this.ps1.setString(5, str.replaceAll("[\\s<>]", ""));
/*     */ 
/* 347 */       System.arraycopy(b, 96, tmp, 0, 40);
/* 348 */       str = new String(tmp, "GBK");
/* 349 */       this.ps1.setString(6, str.replaceAll("[\\s<>]", ""));
/*     */ 
/* 351 */       System.arraycopy(b, 136, tmp, 0, 40);
/* 352 */       str = new String(tmp, "GBK");
/* 353 */       this.ps1.setString(7, str.trim());
/*     */ 
/* 355 */       tmp = new byte[1];
/* 356 */       System.arraycopy(b, 176, tmp, 0, 1);
/* 357 */       str = new String(tmp);
/* 358 */       this.ps1.setString(8, str.trim());
/*     */ 
/* 360 */       System.arraycopy(b, 177, tmp, 0, 1);
/* 361 */       str = new String(tmp);
/* 362 */       this.ps1.setString(9, str.trim());
/*     */ 
/* 364 */       tmp = new byte[21];
/* 365 */       System.arraycopy(b, 178, tmp, 0, 21);
/* 366 */       str = new String(tmp).replaceAll("[\\s,]", "");
/* 367 */       this.ps1.setString(10, str);
/*     */ 
/* 369 */       System.arraycopy(b, 199, tmp, 0, 21);
/* 370 */       str = new String(tmp).replaceAll("[\\s,]", "");
/* 371 */       this.ps1.setString(11, str);
/*     */ 
/* 373 */       System.arraycopy(b, 220, tmp, 0, 21);
/* 374 */       str = new String(tmp).replaceAll("[\\s,]", "");
/* 375 */       this.ps1.setString(12, str);
/* 376 */       this.ps1.addBatch();
/* 377 */       this.userCurrNum += 1;
/* 378 */       if (commitNum <= this.userCurrNum) {
/* 379 */         this.ps1.executeBatch();
/* 380 */         this.totalNum += this.userCurrNum;
/* 381 */         log.debug("total commit:" + this.totalNum);
/* 382 */         this.userCurrNum = 0;
/*     */       }
/*     */     } catch (SQLException e) {
/* 385 */       e.printStackTrace();
/*     */     } catch (UnsupportedEncodingException e) {
/* 387 */       e.printStackTrace();
/*     */     } catch (Exception e) {
/* 389 */       log.error(b.length + "|" + dataStr.length() + "|" + dataStr);
/*     */       try {
/* 391 */         this.ps1.executeBatch();
/* 392 */         this.totalNum += this.userCurrNum;
/* 393 */         log.debug("total commit:" + this.totalNum);
/* 394 */         this.userCurrNum = 0;
/*     */       } catch (SQLException e1) {
/* 396 */         e1.printStackTrace();
/*     */       }
/* 398 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.yearbill.ImportDao
 * JD-Core Version:    0.6.2
 */