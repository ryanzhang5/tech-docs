/*    */ package com.bill.yearbill;
/*    */ 
/*    */ import com.bill.bean.BaseParam;
/*    */ import com.bill.db.DbConnectionForOracle;
/*    */ import com.bill.util.DaoBase;
/*    */ import com.bill.util.LogInit;
/*    */ import com.bill.util.config.ConfigReader;
/*    */ import java.io.PrintStream;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.ExecutorService;
/*    */ import java.util.concurrent.Executors;
/*    */ import java.util.concurrent.ThreadFactory;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class XmlHandleMain
/*    */ {
/* 24 */   private static Map<String, String> config = null;
/* 25 */   private static Logger log = null;
/* 26 */   public static XmlFile xfile = null;
/* 27 */   public static int stauts = 1;
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 32 */     System.out.println("##### Year_bill xml handler start");
/*    */     try
/*    */     {
/* 35 */       ConfigReader.init();
/*    */     } catch (Exception e) {
/* 37 */       System.out.println("##### read properties file error, file path:" + ConfigReader.class.getClassLoader().getResource(ConfigReader.CONFIG_PATH));
/* 38 */       e.printStackTrace();
/* 39 */       return;
/*    */     }
/* 41 */     BaseParam.DB_IP = ConfigReader.read("db.ip");
/* 42 */     BaseParam.DB_PORT = ConfigReader.read("db.port");
/* 43 */     BaseParam.DB_NAME = ConfigReader.read("db.name");
/* 44 */     BaseParam.DB_USER = ConfigReader.read("db.user");
/* 45 */     BaseParam.DB_PWD = ConfigReader.read("db.pwd");
/*    */ 
/* 48 */     DbConnectionForOracle db = new DbConnectionForOracle(
/* 49 */       BaseParam.DB_IP, 
/* 50 */       BaseParam.DB_PORT, 
/* 51 */       BaseParam.DB_NAME, 
/* 52 */       BaseParam.DB_USER, 
/* 53 */       BaseParam.DB_PWD);
/*    */ 
/* 56 */     config = DaoBase.getConfig(db);
/*    */ 
/* 58 */     LogInit.init((String)config.get("LOG4J_COFIG_PATH"), 
/* 59 */       (String)config.get("LOG4J_FILENAME") + "yearbill_xml.log");
/*    */ 
/* 63 */     log = Logger.getLogger(XmlHandleMain.class);
/*    */ 
/* 66 */     xfile = new XmlFile((String)config.get("BASEPATH"));
/*    */ 
/* 68 */     System.out.println("XmlThread run");
/* 69 */     List callList = new ArrayList();
/* 70 */     callList.add(new XmlThread(db.getConnection()));
/* 71 */     callList.add(new XmlThread(db.getConnection()));
/* 72 */     callList.add(new XmlThread(db.getConnection()));
/* 73 */     callList.add(new XmlThread(db.getConnection()));
/* 74 */     callList.add(new XmlThread(db.getConnection()));
/* 75 */     callList.add(new XmlThread(db.getConnection()));
/* 76 */     callList.add(new XmlThread(db.getConnection()));
/* 77 */     callList.add(new XmlThread(db.getConnection()));
/* 78 */     callList.add(new XmlThread(db.getConnection()));
/* 79 */     callList.add(new XmlThread(db.getConnection()));
/*    */ 
/* 81 */     ExecutorService exec = 
/* 82 */       Executors.newCachedThreadPool(new ThreadFactory() {
/*    */       public Thread newThread(Runnable r) {
/* 84 */         Thread thread = new Thread(r);
/* 85 */         thread.setDaemon(true);
/* 86 */         return thread;
/*    */       }
/*    */     });
/* 90 */     List resultList = null;
/*    */     try {
/* 92 */       resultList = exec.invokeAll(callList);
/*    */     } catch (InterruptedException e) {
/* 94 */       e.printStackTrace();
/*    */     }
/* 96 */     exec.shutdown();
/* 97 */     db.close();
/* 98 */     xfile.colse();
/* 99 */     System.exit(0);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.yearbill.XmlHandleMain
 * JD-Core Version:    0.6.2
 */