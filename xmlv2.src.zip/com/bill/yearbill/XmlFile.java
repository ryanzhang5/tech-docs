/*    */ package com.bill.yearbill;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.io.RandomAccessFile;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ 
/*    */ public class XmlFile
/*    */ {
/* 10 */   private int maxNumber = 5000;
/* 11 */   private int currNumber = 0;
/* 12 */   private int fileNumber = 1;
/* 13 */   private String allPath = "";
/*    */ 
/* 15 */   private File f = null;
/*    */   private RandomAccessFile out;
/*    */ 
/*    */   public XmlFile(String inputStr)
/*    */   {
/* 19 */     this.allPath = (inputStr + "/001/PRODUCT/XML/YEAR/");
/*    */   }
/*    */ 
/*    */   public void create()
/*    */   {
/* 24 */     this.f = new File(this.allPath);
/* 25 */     if (!this.f.exists()) {
/* 26 */       this.f.mkdirs();
/*    */     }
/* 28 */     String filename = "YEAR_BILL_";
/* 29 */     if (this.fileNumber < 10)
/* 30 */       filename = filename + "00" + this.fileNumber;
/* 31 */     else if (this.fileNumber < 100)
/* 32 */       filename = filename + "0" + this.fileNumber;
/*    */     else {
/* 34 */       filename = filename + this.fileNumber;
/*    */     }
/* 36 */     filename = filename + ".xml";
/* 37 */     this.f = new File(this.allPath + filename);
/* 38 */     if (this.f.exists())
/* 39 */       this.f.delete();
/*    */     try
/*    */     {
/* 42 */       this.f.createNewFile();
/* 43 */       System.out.println("create file:" + filename);
/* 44 */       this.out = new RandomAccessFile(this.f, "rw");
/* 45 */       this.fileNumber += 1;
/*    */     } catch (IOException e) {
/* 47 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public void colse() {
/*    */     try {
/* 53 */       this.out.write("</checksheets>\n".getBytes("utf-8"));
/* 54 */       this.out.write("</bjnd>\n".getBytes("utf-8"));
/* 55 */       if (this.out != null) {
/* 56 */         this.out.close();
/*    */       }
/* 58 */       this.f = null;
/*    */     } catch (IOException e) {
/* 60 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public synchronized void write(StringBuffer input_xml_sb) {
/*    */     try {
/* 66 */       if (this.f == null) {
/* 67 */         create();
/* 68 */         this.out.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n".getBytes("utf-8"));
/* 69 */         this.out.write("<bjnd>\n".getBytes("utf-8"));
/* 70 */         this.out.write("<checksheets>\n".getBytes("utf-8"));
/*    */       }
/* 72 */       this.out.write(input_xml_sb.toString().getBytes("utf-8"));
/* 73 */       this.currNumber += 1;
/* 74 */       if (this.maxNumber <= this.currNumber) {
/* 75 */         colse();
/* 76 */         this.currNumber = 0;
/*    */       }
/*    */     } catch (UnsupportedEncodingException e) {
/* 79 */       e.printStackTrace();
/*    */     } catch (IOException e) {
/* 81 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.yearbill.XmlFile
 * JD-Core Version:    0.6.2
 */