/*     */ package com.bill.yearbill;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.db.DbConnectionForOracle;
/*     */ import com.bill.util.DaoBase;
/*     */ import com.bill.util.LogInit;
/*     */ import com.bill.util.config.ConfigReader;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class DataImportMain
/*     */ {
/*  23 */   private static Map<String, String> config = null;
/*  24 */   private static Logger log = null;
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  31 */     System.out.println("##### Year_bill Import start");
/*     */     try
/*     */     {
/*  34 */       ConfigReader.init();
/*     */     } catch (Exception e) {
/*  36 */       System.out.println("##### read properties file error, file path:" + ConfigReader.class.getClassLoader().getResource(ConfigReader.CONFIG_PATH));
/*  37 */       e.printStackTrace();
/*  38 */       return;
/*     */     }
/*  40 */     BaseParam.DB_IP = ConfigReader.read("db.ip");
/*  41 */     BaseParam.DB_PORT = ConfigReader.read("db.port");
/*  42 */     BaseParam.DB_NAME = ConfigReader.read("db.name");
/*  43 */     BaseParam.DB_USER = ConfigReader.read("db.user");
/*  44 */     BaseParam.DB_PWD = ConfigReader.read("db.pwd");
/*     */ 
/*  47 */     DbConnectionForOracle db = new DbConnectionForOracle(
/*  48 */       BaseParam.DB_IP, 
/*  49 */       BaseParam.DB_PORT, 
/*  50 */       BaseParam.DB_NAME, 
/*  51 */       BaseParam.DB_USER, 
/*  52 */       BaseParam.DB_PWD);
/*     */ 
/*  55 */     config = DaoBase.getConfig(db);
/*     */ 
/*  57 */     LogInit.init((String)config.get("LOG4J_COFIG_PATH"), 
/*  58 */       (String)config.get("LOG4J_FILENAME") + "yearbill_data_import.log");
/*     */ 
/*  60 */     log = Logger.getLogger(DataImportMain.class);
/*     */ 
/*  62 */     BufferedReader reader = null;
/*  63 */     String str = "";
/*  64 */     String type = "";
/*  65 */     ImportDao idao = new ImportDao(db.getConnection());
/*  66 */     if ((args == null) || (args.length <= 0)) {
/*  67 */       log.error("param not found!");
/*  68 */       System.exit(-1);
/*  69 */       return;
/*     */     }
/*     */ 
/*  72 */     File file = new File(args[0]);
/*  73 */     if (file.exists()) {
/*     */       try {
/*  75 */         reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "GBK"));
/*  76 */         while ((str = reader.readLine()) != null) {
/*  77 */           type = str.substring(16, 20);
/*  78 */           if (type.startsWith("A"))
/*  79 */             idao.importUser(str);
/*  80 */           else if (type.startsWith("B004"))
/*  81 */             idao.importMonthly2(type, str);
/*  82 */           else if (type.startsWith("B"))
/*  83 */             idao.importMonthly(type, str);
/*  84 */           else if (type.startsWith("C"))
/*  85 */             idao.importDetail(type, str);
/*  86 */           else if (type.startsWith("D"))
/*  87 */             idao.importTotal(type, str);
/*  88 */           else if (type.startsWith("F")) {
/*  89 */             idao.importPoint(type, str);
/*     */           }
/*     */         }
/*     */ 
/*  93 */         reader.close();
/*     */       } catch (FileNotFoundException e) {
/*  95 */         e.printStackTrace();
/*  96 */         System.exit(-1);
/*     */       } catch (IOException e) {
/*  98 */         e.printStackTrace();
/*  99 */         System.exit(-1);
/*     */       }
/*     */     }
/*     */     else {
/* 103 */       log.error("file not found");
/*     */ 
/* 105 */       idao.commitEnd();
/*     */ 
/* 107 */       db.close();
/* 108 */       System.exit(-1);
/*     */     }
/*     */ 
/* 111 */     idao.commitEnd();
/*     */ 
/* 113 */     db.close();
/* 114 */     System.exit(0);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.yearbill.DataImportMain
 * JD-Core Version:    0.6.2
 */