/*     */ package com.bill.yearbill;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class XmlDao
/*     */ {
/*  10 */   private static String SQL_QUERY_USER = "select * from (select tt.*, rownum RN from (select t.*, rownum from t_year_user_info t where rownum < ?) tt ) where RN > ?";
/*  11 */   private static String SQL_QUERY_MONTHLY = "select * from t_year_monthly_cost t where t.s_account=? order by t.s_data_type";
/*  12 */   private static String SQL_QUERY_DETAIL = "select * from t_year_detail_cost t where t.s_account=? order by t.s_data_type";
/*  13 */   private static String SQL_QUERY_TOTAL = "select * from t_year_total_cost t where t.s_account=? order by t.s_data_type";
/*  14 */   private static String SQL_QUERY_POINT = "select * from t_year_point t where t.s_account=?";
/*     */ 
/*  16 */   private Connection conn = null;
/*  17 */   private PreparedStatement ps1 = null;
/*  18 */   private ResultSet result = null;
/*     */ 
/*     */   public XmlDao(Connection inpuit_conn) {
/*  21 */     this.conn = inpuit_conn;
/*     */   }
/*     */ 
/*     */   public String queryPoint(String account) {
/*  25 */     String str = "";
/*     */     try {
/*  27 */       this.ps1 = this.conn.prepareStatement(SQL_QUERY_POINT);
/*  28 */       this.ps1.setString(1, account);
/*  29 */       this.result = this.ps1.executeQuery();
/*  30 */       while (this.result.next()) {
/*  31 */         str = this.result.getString("S_CREDIT");
/*     */       }
/*  33 */       this.result.close();
/*  34 */       this.ps1.close();
/*     */     } catch (SQLException e) {
/*  36 */       e.printStackTrace();
/*     */     }
/*  38 */     return str;
/*     */   }
/*     */ 
/*     */   public List<Map<String, String>> queryTotal(String account) {
/*  42 */     List list = new ArrayList();
/*  43 */     Map map = null;
/*     */     try {
/*  45 */       this.ps1 = this.conn.prepareStatement(SQL_QUERY_TOTAL);
/*  46 */       this.ps1.setString(1, account);
/*  47 */       this.result = this.ps1.executeQuery();
/*  48 */       while (this.result.next()) {
/*  49 */         map = new HashMap();
/*  50 */         map.put("type", this.result.getString("S_DATA_TYPE"));
/*  51 */         map.put("cost1", this.result.getString("S_COST_TYPE1"));
/*  52 */         map.put("cost2", this.result.getString("S_COST_TYPE2"));
/*  53 */         map.put("cost3", this.result.getString("S_COST_TYPE3"));
/*  54 */         map.put("cost4", this.result.getString("S_COST_TYPE4"));
/*  55 */         list.add(map);
/*     */       }
/*  57 */       this.result.close();
/*  58 */       this.ps1.close();
/*     */     } catch (SQLException e) {
/*  60 */       e.printStackTrace();
/*     */     }
/*  62 */     return list;
/*     */   }
/*     */ 
/*     */   public List<Map<String, String>> queryDetail(String account)
/*     */   {
/*  67 */     List list = new ArrayList();
/*  68 */     Map map = null;
/*     */     try {
/*  70 */       this.ps1 = this.conn.prepareStatement(SQL_QUERY_DETAIL);
/*  71 */       this.ps1.setString(1, account);
/*  72 */       this.result = this.ps1.executeQuery();
/*  73 */       while (this.result.next()) {
/*  74 */         map = new HashMap();
/*  75 */         map.put("type", this.result.getString("S_DATA_TYPE"));
/*  76 */         map.put("cost1", this.result.getString("S_COST_TYPE1"));
/*  77 */         map.put("cost2", this.result.getString("S_COST_TYPE2"));
/*  78 */         map.put("cost3", this.result.getString("S_COST_TYPE3"));
/*  79 */         map.put("cost4", this.result.getString("S_COST_TYPE4"));
/*  80 */         map.put("cost5", this.result.getString("S_COST_TYPE5"));
/*  81 */         map.put("cost6", this.result.getString("S_COST_TYPE6"));
/*  82 */         map.put("cost7", this.result.getString("S_COST_TYPE7"));
/*  83 */         map.put("cost8", this.result.getString("S_COST_TYPE8"));
/*  84 */         list.add(map);
/*     */       }
/*  86 */       this.result.close();
/*  87 */       this.ps1.close();
/*     */     } catch (SQLException e) {
/*  89 */       e.printStackTrace();
/*     */     }
/*  91 */     return list;
/*     */   }
/*     */ 
/*     */   public List<Map<String, String>> queryMonthly(String account) {
/*  95 */     List list = new ArrayList();
/*  96 */     Map map = null;
/*     */     try {
/*  98 */       this.ps1 = this.conn.prepareStatement(SQL_QUERY_MONTHLY);
/*  99 */       this.ps1.setString(1, account);
/* 100 */       this.result = this.ps1.executeQuery();
/* 101 */       while (this.result.next()) {
/* 102 */         map = new HashMap();
/* 103 */         map.put("type", this.result.getString("S_DATA_TYPE"));
/* 104 */         map.put("Jan", this.result.getString("S_M01"));
/* 105 */         map.put("Feb", this.result.getString("S_M02"));
/* 106 */         map.put("Mar", this.result.getString("S_M03"));
/* 107 */         map.put("Apr", this.result.getString("S_M04"));
/* 108 */         map.put("May", this.result.getString("S_M05"));
/* 109 */         map.put("Jun", this.result.getString("S_M06"));
/* 110 */         map.put("Jul", this.result.getString("S_M07"));
/* 111 */         map.put("Aug", this.result.getString("S_M08"));
/* 112 */         map.put("Sep", this.result.getString("S_M09"));
/* 113 */         map.put("Oct", this.result.getString("S_M10"));
/* 114 */         map.put("Nov", this.result.getString("S_M11"));
/* 115 */         map.put("Dec", this.result.getString("S_M12"));
/* 116 */         list.add(map);
/*     */       }
/* 118 */       this.result.close();
/* 119 */       this.ps1.close();
/*     */     } catch (SQLException e) {
/* 121 */       e.printStackTrace();
/*     */     }
/* 123 */     return list;
/*     */   }
/*     */ 
/*     */   public List<Map<String, String>> queryUser(int page, int size)
/*     */   {
/* 128 */     List list = new ArrayList();
/* 129 */     Map map = null;
/* 130 */     String tmp = "";
/*     */     try {
/* 132 */       this.ps1 = this.conn.prepareStatement(SQL_QUERY_USER);
/* 133 */       this.ps1.setInt(1, page * size + 1);
/* 134 */       this.ps1.setInt(2, (page - 1) * size);
/* 135 */       this.result = this.ps1.executeQuery();
/* 136 */       while (this.result.next()) {
/* 137 */         map = new HashMap();
/* 138 */         map.put("AccountNo", this.result.getString("S_ACCOUNT"));
/* 139 */         map.put("Zip", this.result.getString("S_ZIP"));
/* 140 */         tmp = this.result.getString("s_addr1");
/* 141 */         if (tmp == null) {
/* 142 */           tmp = "";
/*     */         }
/* 144 */         map.put("address1", tmp);
/* 145 */         tmp = this.result.getString("s_addr2");
/* 146 */         if (tmp == null) {
/* 147 */           tmp = "";
/*     */         }
/* 149 */         map.put("address2", tmp);
/* 150 */         tmp = this.result.getString("S_ADDR3");
/* 151 */         if (tmp == null) {
/* 152 */           tmp = "";
/*     */         }
/* 154 */         map.put("address3", tmp);
/* 155 */         map.put("Name", this.result.getString("S_ALL_NAME"));
/* 156 */         map.put("Sex", this.result.getString("S_SEX"));
/* 157 */         map.put("Special", this.result.getString("S_SPEC_TAG"));
/* 158 */         map.put("Rmbforyear", this.result.getString("S_YEAR_RMB_COST"));
/* 159 */         map.put("Usdforyear", this.result.getString("S_YEAR_USD_COST"));
/* 160 */         map.put("totalforyear", this.result.getString("S_YEAR_TOTAL_COST"));
/* 161 */         list.add(map);
/*     */       }
/* 163 */       this.result.close();
/* 164 */       this.ps1.close();
/*     */     } catch (SQLException e) {
/* 166 */       e.printStackTrace();
/*     */     }
/* 168 */     return list;
/*     */   }
/*     */ 
/*     */   public void colse() {
/*     */     try {
/* 173 */       this.conn.close();
/*     */     } catch (SQLException e) {
/* 175 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.yearbill.XmlDao
 * JD-Core Version:    0.6.2
 */