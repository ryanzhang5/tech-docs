/*     */ package com.bill.yearbill;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.db.DbConnectionForOracle;
/*     */ import com.bill.util.DaoBase;
/*     */ import com.bill.util.LogInit;
/*     */ import com.bill.util.config.ConfigReader;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class DataImportMain3
/*     */ {
/*  23 */   private static Map<String, String> config = null;
/*  24 */   private static Logger log = null;
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  31 */     System.out.println("##### Year_bill Import start");
/*     */     try
/*     */     {
/*  34 */       ConfigReader.init();
/*     */     } catch (Exception e) {
/*  36 */       System.out.println("##### read properties file error, file path:" + ConfigReader.class.getClassLoader().getResource(ConfigReader.CONFIG_PATH));
/*  37 */       e.printStackTrace();
/*  38 */       return;
/*     */     }
/*  40 */     BaseParam.DB_IP = ConfigReader.read("db.ip");
/*  41 */     BaseParam.DB_PORT = ConfigReader.read("db.port");
/*  42 */     BaseParam.DB_NAME = ConfigReader.read("db.name");
/*  43 */     BaseParam.DB_USER = ConfigReader.read("db.user");
/*  44 */     BaseParam.DB_PWD = ConfigReader.read("db.pwd");
/*     */ 
/*  47 */     DbConnectionForOracle db = new DbConnectionForOracle(
/*  48 */       BaseParam.DB_IP, 
/*  49 */       BaseParam.DB_PORT, 
/*  50 */       BaseParam.DB_NAME, 
/*  51 */       BaseParam.DB_USER, 
/*  52 */       BaseParam.DB_PWD);
/*     */ 
/*  55 */     config = DaoBase.getConfig(db);
/*     */ 
/*  57 */     LogInit.init((String)config.get("LOG4J_COFIG_PATH"), 
/*  58 */       (String)config.get("LOG4J_FILENAME") + "yearbill_data_import.log");
/*     */ 
/*  60 */     log = Logger.getLogger(DataImportMain.class);
/*     */ 
/*  62 */     BufferedReader reader = null;
/*  63 */     String str = "";
/*  64 */     String type = "";
/*  65 */     ImportDao idao = new ImportDao(db.getConnection());
/*  66 */     if ((args == null) || (args.length <= 0)) {
/*  67 */       log.error("param not found!");
/*  68 */       System.exit(-1);
/*  69 */       return;
/*     */     }
/*     */ 
/*  72 */     File file = new File(args[0]);
/*  73 */     File[] files = (File[])null;
/*  74 */     if (file.isDirectory()) {
/*  75 */       files = file.listFiles();
/*     */     }
/*  77 */     String f_name = "";
/*  78 */     for (File tmp_file : files) {
/*  79 */       f_name = tmp_file.getName();
/*  80 */       log.debug("Import filename:" + f_name);
/*     */       try {
/*  82 */         reader = new BufferedReader(new InputStreamReader(new FileInputStream(tmp_file), "GB2312"));
/*  83 */         if (f_name.startsWith("A")) {
/*  84 */           while ((str = reader.readLine()) != null) {
/*  85 */             idao.importUser(str);
/*     */           }
/*     */         }
/*  88 */         else if (f_name.startsWith("B004")) {
/*  89 */           while ((str = reader.readLine()) != null) {
/*  90 */             idao.importMonthly2("B004", str);
/*     */           }
/*     */         }
/*  93 */         else if (f_name.startsWith("B")) {
/*  94 */           while ((str = reader.readLine()) != null) {
/*  95 */             idao.importMonthly("B", str);
/*     */           }
/*     */         }
/*  98 */         else if (f_name.startsWith("C")) {
/*  99 */           while ((str = reader.readLine()) != null) {
/* 100 */             idao.importDetail("C", str);
/*     */           }
/*     */         }
/* 103 */         else if (f_name.startsWith("D")) {
/* 104 */           while ((str = reader.readLine()) != null) {
/* 105 */             idao.importTotal("D", str);
/*     */           }
/*     */         }
/* 108 */         else if (f_name.startsWith("F")) {
/* 109 */           while ((str = reader.readLine()) != null) {
/* 110 */             idao.importPoint("F", str);
/*     */           }
/*     */         }
/*     */ 
/* 114 */         reader.close();
/*     */       } catch (FileNotFoundException e) {
/* 116 */         e.printStackTrace();
/* 117 */         System.out.println(tmp_file.getName());
/* 118 */         System.exit(-1);
/*     */       } catch (IOException e) {
/* 120 */         e.printStackTrace();
/* 121 */         System.out.println(tmp_file.getName());
/* 122 */         System.exit(-1);
/*     */       }
/*     */     }
/*     */ 
/* 126 */     idao.commitEnd();
/*     */ 
/* 128 */     db.close();
/* 129 */     System.exit(0);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.yearbill.DataImportMain3
 * JD-Core Version:    0.6.2
 */