/*     */ package com.bill.util;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.dom4j.Document;
/*     */ import org.dom4j.DocumentException;
/*     */ import org.dom4j.io.OutputFormat;
/*     */ import org.dom4j.io.SAXReader;
/*     */ import org.dom4j.io.XMLWriter;
/*     */ 
/*     */ public class FileUtil
/*     */ {
/*  29 */   private static Logger log = Logger.getLogger(FileUtil.class);
/*     */ 
/*  32 */   public static final String fileseparator = System.getProperty("file.separator");
/*     */ 
/*  35 */   private static short fileIndex = 0;
/*     */ 
/*     */   public static synchronized short getFileIndex()
/*     */   {
/*  42 */     if (fileIndex == 32767)
/*  43 */       fileIndex = 1;
/*     */     else {
/*  45 */       fileIndex = (short)(fileIndex + 1);
/*     */     }
/*  47 */     return fileIndex;
/*     */   }
/*     */ 
/*     */   public static void writeXmlFile(Document xmlDoc, String fileName)
/*     */     throws Exception
/*     */   {
/*  57 */     XMLWriter writer = null;
/*  58 */     String fileEncoding = System.getProperty("file.encoding");
/*  59 */     if (fileEncoding.equalsIgnoreCase("ISO8859-1")) {
/*  60 */       fileEncoding = "ISO-8859-1";
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  65 */       OutputFormat format = OutputFormat.createPrettyPrint();
/*  66 */       format.setEncoding(fileEncoding);
/*  67 */       format.setLineSeparator(System.getProperty("line.separator"));
/*     */ 
/*  69 */       delFile(fileName);
/*  70 */       writer = new XMLWriter(new FileWriter(fileName), format);
/*  71 */       writer.write(xmlDoc); } finally {
/*     */       try {
/*  73 */         writer.close();
/*     */       }
/*     */       catch (Exception localException)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Document readXmlFile(String fileName)
/*     */     throws Exception
/*     */   {
/*  85 */     SAXReader saxReader = new SAXReader();
/*  86 */     Document document = null;
/*  87 */     long beginTime = System.currentTimeMillis();
/*     */     while (true)
/*     */       try {
/*  90 */         return saxReader.read(new File(fileName));
/*     */       }
/*     */       catch (DocumentException e) {
/*  93 */         if (System.currentTimeMillis() - beginTime > 30000L)
/*     */         {
/*  95 */           throw e;
/*     */         }
/*     */ 
/*  98 */         document = null;
/*     */       }
/*     */   }
/*     */ 
/*     */   public static String scanFile(String directoryName)
/*     */     throws Exception
/*     */   {
/* 109 */     File file = new File(directoryName);
/*     */ 
/* 112 */     if (!file.exists()) {
/* 113 */       throw new Exception("指定目录不存在：" + directoryName);
/*     */     }
/*     */ 
/* 117 */     if (file.isFile()) {
/* 118 */       throw new Exception("扫描的不是目录：：" + directoryName);
/*     */     }
/*     */ 
/* 122 */     if (file.list().length == 0) {
/* 123 */       return null;
/*     */     }
/*     */ 
/* 127 */     File[] f = file.listFiles();
/*     */ 
/* 130 */     for (int i = 0; i < f.length; i++) {
/* 131 */       String tmpPath = f[i].getAbsolutePath();
/* 132 */       File fileTmp = new File(tmpPath);
/*     */ 
/* 134 */       if (fileTmp.isFile()) {
/* 135 */         return tmpPath;
/*     */       }
/*     */ 
/* 139 */       String sonTmp = scanFile(tmpPath);
/* 140 */       if (sonTmp != null) {
/* 141 */         return sonTmp;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 149 */     return null;
/*     */   }
/*     */ 
/*     */   public static boolean moveFile(String oldFile, String newFile)
/*     */   {
/* 160 */     File f = new File(oldFile);
/* 161 */     File f2 = new File(newFile);
/* 162 */     if (!createDirectory(newFile)) {
/* 163 */       return false;
/*     */     }
/* 165 */     return f.renameTo(f2);
/*     */   }
/*     */ 
/*     */   public static boolean rename(String oldFileName, String newFileName)
/*     */   {
/* 175 */     File f = new File(oldFileName);
/* 176 */     File f2 = new File(newFileName);
/* 177 */     return f.renameTo(f2);
/*     */   }
/*     */ 
/*     */   public static boolean createDirectory(String directory)
/*     */   {
/* 186 */     String path = directory;
/* 187 */     path = path.substring(0, path.lastIndexOf(fileseparator));
/*     */ 
/* 189 */     StringTokenizer st = new StringTokenizer(path, fileseparator);
/* 190 */     String path1 = "";
/* 191 */     if (fileseparator.equals("/")) {
/* 192 */       path1 = path1 + fileseparator;
/*     */     }
/* 194 */     path1 = path1 + st.nextToken() + fileseparator;
/* 195 */     String path2 = path1;
/* 196 */     while (st.hasMoreTokens()) {
/* 197 */       path1 = st.nextToken() + fileseparator;
/* 198 */       path2 = path2 + path1;
/* 199 */       File inbox = new File(path2);
/* 200 */       if (!inbox.exists())
/*     */       {
/* 202 */         if (!inbox.mkdir()) {
/* 203 */           return false;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 208 */     return true;
/*     */   }
/*     */ 
/*     */   public static boolean copyFile(String srcFile, String destFile)
/*     */   {
/* 218 */     File f = new File(srcFile);
/* 219 */     File f2 = new File(destFile);
/*     */ 
/* 223 */     FileInputStream fis = null;
/* 224 */     FileOutputStream fos = null;
/* 225 */     byte[] buff = new byte[1024];
/* 226 */     int readed = -1;
/*     */     try {
/* 228 */       fis = new FileInputStream(f);
/* 229 */       fos = new FileOutputStream(f2);
/* 230 */       while ((readed = fis.read(buff)) > 0) {
/* 231 */         fos.write(buff, 0, readed);
/*     */       }
/* 233 */       return true;
/*     */     } catch (IOException e) {
/* 235 */       log.error("拷贝文件失败", e);
/* 236 */       return false;
/*     */     } finally {
/* 238 */       if (fis != null) {
/*     */         try {
/* 240 */           fis.close();
/*     */         } catch (IOException e) {
/* 242 */           log.error("", e);
/*     */         }
/*     */       }
/* 245 */       if (fos != null)
/*     */         try {
/* 247 */           fos.close();
/*     */         } catch (IOException e) {
/* 249 */           log.error("", e);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void delFile(String fileName)
/*     */     throws Exception
/*     */   {
/* 261 */     File delFile = new File(fileName);
/* 262 */     if ((delFile.exists()) && 
/* 263 */       (!delFile.delete()))
/* 264 */       throw new Exception("删除文件失败!" + fileName);
/*     */   }
/*     */ 
/*     */   public static String changeFileExt(String fileName, String newExtName)
/*     */     throws Exception
/*     */   {
/* 278 */     String newFileName = fileName.substring(0, fileName.length() - 4) + 
/* 279 */       newExtName;
/*     */ 
/* 282 */     delFile(newFileName);
/* 283 */     if (!new File(fileName).renameTo(new File(newFileName))) {
/* 284 */       throw new Exception("更改文件名失败");
/*     */     }
/*     */ 
/* 287 */     return newFileName;
/*     */   }
/*     */ 
/*     */   public static String getFileName(String pathName)
/*     */   {
/* 296 */     int index1 = pathName.lastIndexOf('/');
/* 297 */     int index2 = pathName.lastIndexOf("\\");
/* 298 */     int index = index1 >= index2 ? index1 : index2;
/* 299 */     return pathName.substring(index + 1);
/*     */   }
/*     */ 
/*     */   public static boolean checkFileExists(String fileName)
/*     */   {
/* 308 */     File f = new File(fileName);
/*     */ 
/* 310 */     if (f.exists()) {
/* 311 */       return true;
/*     */     }
/* 313 */     return false;
/*     */   }
/*     */ 
/*     */   public static String replacePathChar(String path, String pathChar)
/*     */   {
/* 318 */     return StringUtils.replace(StringUtils.replace(path, "/", pathChar), "\\", pathChar);
/*     */   }
/*     */ 
/*     */   public static String getFileString(String fileName) throws IOException {
/* 322 */     StringBuffer buffer = new StringBuffer();
/*     */ 
/* 324 */     File f = new File(fileName);
/*     */ 
/* 326 */     BufferedReader br = null;
/*     */ 
/* 329 */     String tmp = null;
/* 330 */     br = new BufferedReader(new InputStreamReader(new FileInputStream(f)));
/* 331 */     while ((tmp = br.readLine()) != null) {
/* 332 */       buffer.append(tmp);
/*     */     }
/* 334 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public static String getFileHeadString(String fileName, int readLenNum)
/*     */     throws IOException
/*     */   {
/* 340 */     StringBuffer buffer = new StringBuffer();
/*     */ 
/* 342 */     File f = new File(fileName);
/*     */ 
/* 344 */     BufferedReader br = null;
/*     */ 
/* 347 */     String tmp = null;
/* 348 */     br = new BufferedReader(new InputStreamReader(new FileInputStream(f)));
/* 349 */     while ((tmp = br.readLine()) != null) {
/* 350 */       buffer.append(tmp);
/*     */     }
/* 352 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public static void delFolderFile(String folderPath)
/*     */   {
/* 360 */     File file = new File(folderPath);
/*     */ 
/* 362 */     if (file.exists()) {
/* 363 */       File[] files = (File[])null;
/*     */ 
/* 365 */       files = file.listFiles();
/*     */ 
/* 367 */       if ((files != null) && (files.length > 0))
/*     */       {
/* 369 */         for (File f : files)
/*     */         {
/* 371 */           if (f != null)
/*     */           {
/* 373 */             if (f.isFile()) {
/* 374 */               f.delete();
/*     */             }
/*     */             else
/*     */             {
/* 378 */               delFolderFile(f.getPath());
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void delFolderFile(String folderPath, String filename) {
/* 387 */     File file = new File(folderPath);
/*     */ 
/* 389 */     if (file.exists()) {
/* 390 */       File[] files = (File[])null;
/*     */ 
/* 392 */       files = file.listFiles();
/*     */ 
/* 394 */       if ((files != null) && (files.length > 0))
/*     */       {
/* 396 */         for (File f : files)
/*     */         {
/* 398 */           if ((f != null) && (f.getName().indexOf(filename) > -1))
/*     */           {
/* 400 */             if (f.isFile()) {
/* 401 */               f.delete();
/*     */             }
/*     */             else
/*     */             {
/* 405 */               delFolderFile(f.getPath(), filename);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] aa)
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.util.FileUtil
 * JD-Core Version:    0.6.2
 */