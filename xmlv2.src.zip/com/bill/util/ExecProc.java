/*    */ package com.bill.util;
/*    */ 
/*    */ import com.bill.db.DbConnectionForOracle;
/*    */ import com.bill.main.runProc;
/*    */ import com.bill.util.config.ConfigReader;
/*    */ import java.io.PrintStream;
/*    */ import java.sql.CallableStatement;
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import java.util.Map;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class ExecProc
/*    */ {
/* 16 */   private static Map<String, String> config = null;
/* 17 */   private static Logger log = null;
/*    */ 
/*    */   public static void main(String[] args) {
/* 20 */     System.out.println("##### start run procedures!");
/*    */     try {
/* 22 */       ConfigReader.init();
/*    */     } catch (Exception e) {
/* 24 */       System.out.println("##### read properties file error, file path:" + 
/* 25 */         ConfigReader.class.getClassLoader().getResource(ConfigReader.CONFIG_PATH));
/* 26 */       e.printStackTrace();
/* 27 */       return;
/*    */     }
/*    */ 
/* 30 */     DbConnectionForOracle db = new DbConnectionForOracle(
/* 31 */       ConfigReader.read("db.ip"), ConfigReader.read("db.port"), 
/* 32 */       ConfigReader.read("db.name"), ConfigReader.read("db.user"), 
/* 33 */       ConfigReader.read("db.pwd"));
/*    */ 
/* 35 */     config = DaoBase.getConfig(db);
/* 36 */     LogInit.init((String)config.get("LOG4J_COFIG_PATH"), 
/* 37 */       (String)config.get("LOG4J_FILENAME") + "runProc.log");
/* 38 */     log = Logger.getLogger(runProc.class);
/* 39 */     if ((args == null) || (args.length == 0)) {
/* 40 */       log.error("procedures name is null!");
/* 41 */       System.exit(-1);
/*    */     }
/* 43 */     CallableStatement call = null;
/*    */     try {
/* 45 */       log.debug("procedures name:" + 
/* 46 */         args[0] + 
/* 47 */         ",begin time:" + 
/* 48 */         new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
/* 49 */         .format(new Date()));
/* 50 */       call = db.getConnection().prepareCall("{call " + args[0] + "()}");
/* 51 */       call.execute();
/* 52 */       call.close();
/* 53 */       db.close();
/*    */     } catch (SQLException e) {
/* 55 */       e.printStackTrace();
/* 56 */       log.error("run procedures error!");
/* 57 */       log.error(e.getMessage());
/*    */       try {
/* 59 */         if ((call != null) && (!call.isClosed())) {
/* 60 */           call.close();
/*    */         }
/* 62 */         db.close();
/*    */       } catch (SQLException e1) {
/* 64 */         e1.printStackTrace();
/*    */       }
/* 66 */       System.exit(-1);
/*    */     }
/* 68 */     log.debug("procedures name:" + 
/* 69 */       args[0] + 
/* 70 */       ",end time:" + 
/* 71 */       new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
/* 72 */     System.exit(0);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.util.ExecProc
 * JD-Core Version:    0.6.2
 */