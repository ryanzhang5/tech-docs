/*     */ package com.bill.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.security.Key;
/*     */ import java.security.spec.KeySpec;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.SecretKeyFactory;
/*     */ import javax.crypto.spec.DESKeySpec;
/*     */ import org.apache.log4j.Logger;
/*     */ import sun.misc.BASE64Decoder;
/*     */ import sun.misc.BASE64Encoder;
/*     */ 
/*     */ public class DESUtil
/*     */ {
/*  23 */   private static Logger log = Logger.getLogger(DESUtil.class);
/*     */ 
/*  26 */   private Key key = null;
/*     */ 
/*     */   public DESUtil(byte[] str) throws Exception
/*     */   {
/*  30 */     KeySpec dks = new DESKeySpec(str);
/*  31 */     SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
/*  32 */     this.key = keyFactory.generateSecret(dks);
/*     */   }
/*     */ 
/*     */   public String encryptStr(String strMing)
/*     */     throws Exception
/*     */   {
/*  41 */     byte[] byteMi = (byte[])null;
/*  42 */     byte[] byteMing = (byte[])null;
/*  43 */     String strMi = "";
/*  44 */     BASE64Encoder base64en = new BASE64Encoder();
/*     */     try {
/*  46 */       byteMing = strMing.getBytes("UTF-8");
/*  47 */       byteMi = encryptByte(byteMing);
/*     */ 
/*  49 */       strMi = base64en.encode(byteMi);
/*     */     } catch (Exception e) {
/*  51 */       log.error(e);
/*  52 */       throw e;
/*     */     } finally {
/*  54 */       base64en = null;
/*  55 */       byteMing = (byte[])null;
/*  56 */       byteMi = (byte[])null;
/*     */     }
/*  58 */     return strMi;
/*     */   }
/*     */ 
/*     */   public String decryptStr(String strMi)
/*     */     throws Exception
/*     */   {
/*  69 */     BASE64Decoder base64De = new BASE64Decoder();
/*  70 */     byte[] byteMing = (byte[])null;
/*  71 */     byte[] byteMi = (byte[])null;
/*  72 */     String strMing = "";
/*     */     try {
/*  74 */       byteMi = base64De.decodeBuffer(strMi);
/*  75 */       byteMing = decryptByte(byteMi);
/*  76 */       strMing = new String(byteMing, "UTF-8");
/*     */     } catch (Exception e) {
/*  78 */       log.error(e);
/*  79 */       throw e;
/*     */     } finally {
/*  81 */       base64De = null;
/*  82 */       byteMing = (byte[])null;
/*  83 */       byteMi = (byte[])null;
/*     */     }
/*  85 */     return strMing;
/*     */   }
/*     */ 
/*     */   private byte[] encryptByte(byte[] byteS)
/*     */     throws Exception
/*     */   {
/*  96 */     byte[] byteFina = (byte[])null;
/*     */     Cipher cipher;
/*     */     try
/*     */     {
/*  99 */       Cipher cipher = Cipher.getInstance("DES");
/* 100 */       cipher.init(1, this.key);
/* 101 */       byteFina = cipher.doFinal(byteS);
/*     */     } catch (Exception e) {
/* 103 */       log.error(e);
/* 104 */       throw e;
/*     */     } finally {
/* 106 */       cipher = null;
/*     */     }
/* 108 */     return byteFina;
/*     */   }
/*     */ 
/*     */   private byte[] decryptByte(byte[] byteD)
/*     */     throws Exception
/*     */   {
/* 120 */     byte[] byteFina = (byte[])null;
/*     */     Cipher cipher;
/*     */     try
/*     */     {
/* 122 */       Cipher cipher = Cipher.getInstance("DES");
/* 123 */       cipher.init(2, this.key);
/* 124 */       byteFina = cipher.doFinal(byteD);
/*     */     } catch (Exception e) {
/* 126 */       log.error(e);
/* 127 */       throw e;
/*     */     } finally {
/* 129 */       cipher = null;
/*     */     }
/* 131 */     return byteFina;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception {
/* 135 */     DESUtil des = new DESUtil("012345678".getBytes());
/* 136 */     String str1 = "2998000001475888,20350909,1370472328270.jpg";
/* 137 */     System.out.println(" 加密前： " + str1);
/*     */ 
/* 139 */     String str2 = des.encryptStr(str1);
/* 140 */     System.out.println(" 加密后： " + str2);
/*     */ 
/* 142 */     String deStr = des.decryptStr(str2);
/* 143 */     System.out.println(" 解密后： " + deStr);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.util.DESUtil
 * JD-Core Version:    0.6.2
 */