/*    */ package com.bill.util;
/*    */ 
/*    */ import com.bill.bean.PointInfo;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class DBUtil
/*    */ {
/*    */   public List<PointInfo> getPointXResult(ResultSet result)
/*    */     throws SQLException
/*    */   {
/* 11 */     List list = new ArrayList();
/* 12 */     PointInfo p = new PointInfo();
/* 13 */     while (result.next()) {
/* 14 */       p = new PointInfo();
/* 15 */       p.setPointtype(result.getString("S_POINT_TYPE"));
/* 16 */       p.setCardportid(result.getString("S_ACCT_PROD_ID"));
/* 17 */       p.setBusinessid(result.getString("S_BUSINESS_ID"));
/* 18 */       p.setAblepoint("0.00".equals(result.getString("I_ABLE_POINT")) ? "0" : result.getString("I_ABLE_POINT"));
/* 19 */       p.setLastbalpoint("0.00".equals(result.getString("I_LASTBAL_POINT")) ? "0" : result.getString("I_LASTBAL_POINT"));
/* 20 */       p.setAddpoint("0.00".equals(result.getString("I_ADDPOINT_POINT")) ? "0" : result.getString("I_ADDPOINT_POINT"));
/* 21 */       p.setExpoint("0.00".equals(result.getString("I_EXPOINT_POINT")) ? "0" : result.getString("I_EXPOINT_POINT"));
/* 22 */       p.setAdpoints("0.00".equals(result.getString("I_ADPOINTS_POINT")) ? "0" : result.getString("I_ADPOINTS_POINT"));
/* 23 */       p.setEndpoints("0.00".equals(result.getString("I_ENDPOINTS_POINT")) ? "0" : result.getString("I_ENDPOINTS_POINT"));
/* 24 */       p.setEcifno(result.getString("S_ECIF_NO"));
/* 25 */       p.setStartdate(result.getString("S_START_DATE"));
/* 26 */       p.setEnddate(result.getString("S_END_DATE"));
/* 27 */       p.setWholeconsume(result.getString("I_WHOLE_CONSUME"));
/* 28 */       p.setInconsume(result.getString("I_IN_CONSUME"));
/* 29 */       p.setOutconsume(result.getString("I_OUT_CONSUME"));
/* 30 */       p.setWholemoney(result.getString("I_WHOLE_MONEY"));
/* 31 */       p.setInmoney(result.getString("I_IN_MONEY"));
/* 32 */       p.setOutmoney(result.getString("I_OUT_MONEY"));
/* 33 */       p.setUsedmoney(result.getString("I_USED_MONEY"));
/* 34 */       p.setLavemoney(result.getString("I_LAVE_MONEY"));
/* 35 */       p.setValiddate(result.getString("S_VALID_DATE"));
/* 36 */       p.setLaddermoney(result.getString("I_LADDER_MONEY"));
/* 37 */       p.setLadderscale(result.getString("S_LADDER_SCALE"));
/* 38 */       p.setCard4(result.getString("C_CARD_LAST4"));
/* 39 */       p.setCardPointType(result.getString("C_CARD_POINT_TYPE"));
/* 40 */       p.setCardname(result.getString("S_CARD_POINT_NAME"));
/* 41 */       list.add(p);
/*    */     }
/* 43 */     return list;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.util.DBUtil
 * JD-Core Version:    0.6.2
 */