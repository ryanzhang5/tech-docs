/*     */ package com.bill.util;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import org.apache.commons.net.ftp.FTPClient;
/*     */ import org.apache.commons.net.ftp.FTPFile;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class FtpUtil
/*     */ {
/*  25 */   private static Logger log = Logger.getLogger(FtpUtil.class);
/*     */ 
/*  27 */   private FTPClient client = null;
/*  28 */   private String ip = null;
/*  29 */   private int port = 21;
/*  30 */   private String userName = null;
/*  31 */   private String password = null;
/*     */ 
/*     */   public FtpUtil(String ip, int port, String userName, String password) {
/*  34 */     this.ip = ip;
/*  35 */     this.port = port;
/*  36 */     this.userName = userName;
/*  37 */     this.password = password;
/*     */   }
/*     */ 
/*     */   public boolean connection(String flag)
/*     */   {
/*  44 */     boolean result = false;
/*     */     try {
/*  46 */       this.client = new FTPClient();
/*  47 */       this.client.connect(this.ip, this.port);
/*  48 */       result = this.client.login(this.userName, this.password);
/*     */ 
/*  50 */       if (result)
/*  51 */         if ("1".equals(flag))
/*  52 */           this.client.enterLocalActiveMode();
/*     */         else
/*  54 */           this.client.enterLocalPassiveMode();
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/*     */       try {
/*  59 */         if (this.client != null)
/*  60 */           this.client.disconnect();
/*     */       }
/*     */       catch (Throwable tClose) {
/*  63 */         log.error("ftp connect error", tClose);
/*     */       }
/*     */     }
/*  66 */     return result;
/*     */   }
/*     */ 
/*     */   public void closeConn()
/*     */   {
/*     */     try
/*     */     {
/*  75 */       if ((this.client != null) && (this.client.isConnected())) {
/*  76 */         this.client.disconnect();
/*  77 */         this.client = null;
/*  78 */         log.debug("ftp disconnect success.");
/*     */       }
/*     */     } catch (Throwable t) {
/*  81 */       log.error("ftp close error", t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean upload(String ftpFilePath, String newFileName, String path)
/*     */     throws Exception
/*     */   {
/*  94 */     log.debug("file upload start, " + ftpFilePath);
/*     */ 
/*  96 */     boolean result = true;
/*  97 */     InputStream input = null;
/*     */     try {
/*  99 */       String name = "";
/* 100 */       if ((newFileName != null) && (newFileName.length() > 0))
/* 101 */         name = getFileName(newFileName);
/*     */       else {
/* 103 */         name = getFileName(ftpFilePath);
/*     */       }
/* 105 */       if (name == null) {
/* 106 */         log.error("�ϴ��ļ����Ϊ��");
/* 107 */         throw new Exception("�ϴ��ļ����Ϊ��");
/*     */       }
/*     */ 
/* 110 */       log.debug("file from " + 
/* 111 */         ftpFilePath + 
/* 112 */         ", upload to " + 
/* 113 */         path);
/*     */ 
/* 115 */       if (path != null) {
/* 116 */         this.client.changeWorkingDirectory(path);
/*     */       }
/* 118 */       this.client.setFileType(2);
/* 119 */       this.client.enterLocalPassiveMode();
/* 120 */       this.client.setFileTransferMode(10);
/* 121 */       input = new FileInputStream(new File(ftpFilePath));
/* 122 */       result = this.client.storeFile(name, input);
/*     */ 
/* 124 */       log.info(result + ", <==result, file upload finish, " + ftpFilePath);
/* 125 */       return result;
/*     */     }
/*     */     catch (Throwable t) {
/* 128 */       throw new Exception(t);
/*     */     } finally {
/*     */       try {
/* 131 */         if (input != null)
/* 132 */           input.close();
/*     */       }
/*     */       catch (Exception eClose) {
/* 135 */         log.error("ftp input stream close error", eClose);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean downloadFile(String downloadDir, String fileName, String path)
/*     */     throws Exception
/*     */   {
/* 150 */     log.debug("ftp download start");
/* 151 */     log.debug("downloadDir=" + downloadDir + ", fileName=" + fileName + ", path=" + path);
/*     */ 
/* 153 */     boolean result = false;
/* 154 */     BufferedOutputStream bos = null;
/* 155 */     FileOutputStream fos = null;
/* 156 */     File file = null;
/*     */     try
/*     */     {
/* 159 */       if (fileName == null) {
/* 160 */         log.error("fileName is null!");
/* 161 */         throw new Exception("fileName is null!");
/*     */       }
/*     */ 
/* 164 */       file = new File(downloadDir + fileName);
/* 165 */       if (!file.exists()) {
/* 166 */         file.getParentFile().mkdirs();
/*     */       }
/* 168 */       fos = new FileOutputStream(file);
/* 169 */       bos = new BufferedOutputStream(fos);
/*     */ 
/* 171 */       log.debug("ftp get file:" + path + fileName + "  to  " + downloadDir + fileName + "  begin......");
/* 172 */       result = this.client.retrieveFile(path + fileName, bos);
/*     */ 
/* 174 */       log.debug("ftp download finish");
/* 175 */       return result;
/*     */     }
/*     */     catch (Throwable t) {
/*     */       try {
/* 179 */         File fileTemp = new File(downloadDir + fileName);
/* 180 */         if (fileTemp.exists())
/* 181 */           fileTemp.delete();
/*     */       }
/*     */       catch (Exception eDelFile) {
/* 184 */         log.error("download error, del file fail", eDelFile);
/*     */       }
/* 186 */       throw new Exception(t);
/*     */     }
/*     */     finally {
/*     */       try {
/* 190 */         if (bos != null)
/* 191 */           bos.close();
/*     */       }
/*     */       catch (IOException eClose) {
/* 194 */         log.error("ftp output stream close error", eClose);
/*     */       }
/*     */       try {
/* 197 */         if (fos != null)
/* 198 */           fos.close();
/*     */       }
/*     */       catch (IOException eClose) {
/* 201 */         log.error("ftp output stream close error", eClose);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean deleteFile(String fileName, String path)
/*     */     throws Exception
/*     */   {
/* 213 */     boolean result = false;
/*     */     try {
/* 215 */       return this.client.deleteFile(path + fileName);
/*     */     }
/*     */     catch (Throwable t) {
/* 218 */       throw new Exception(t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean deleteDirectory(String dirName, String path)
/*     */     throws Exception
/*     */   {
/* 232 */     boolean result = false;
/*     */     try {
/* 234 */       return this.client.removeDirectory(path + dirName);
/*     */     }
/*     */     catch (Throwable t) {
/* 237 */       log.error(t);
/* 238 */       throw new Exception(t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ArrayList<String> getFileList(String path, String extName)
/*     */     throws Exception
/*     */   {
/* 251 */     FTPFile[] ftpFiles = (FTPFile[])null;
/* 252 */     ArrayList retList = null;
/*     */     try
/*     */     {
/* 255 */       ftpFiles = this.client.listFiles(path);
/* 256 */       retList = new ArrayList();
/* 257 */       if ((ftpFiles == null) || (ftpFiles.length == 0)) {
/* 258 */         return retList;
/*     */       }
/*     */ 
/* 261 */       for (int i = 0; i < ftpFiles.length; i++) {
/* 262 */         FTPFile ftpFile = ftpFiles[i];
/* 263 */         if (ftpFile.isFile()) {
/* 264 */           String ext = getFileExtName(ftpFile.getName());
/* 265 */           if (extName.equals(ext)) {
/* 266 */             retList.add(ftpFile.getName());
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 271 */       return retList;
/*     */     }
/*     */     catch (Throwable t) {
/* 274 */       log.error(t);
/* 275 */       throw new Exception(t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ArrayList<String> getFileList(String path, String prefixName, String postfixName)
/*     */     throws Throwable
/*     */   {
/* 289 */     log.debug("scan ftp file, path is: " + path + ", " + "prefix name is: " + prefixName + ", postfix name is: " + postfixName);
/* 290 */     FTPFile[] ftpFiles = (FTPFile[])null;
/* 291 */     ArrayList retList = null;
/*     */     try
/*     */     {
/* 294 */       ftpFiles = this.client.listFiles(path);
/* 295 */       log.debug("files length:" + ftpFiles.length);
/* 296 */       retList = new ArrayList();
/* 297 */       if ((ftpFiles == null) || (ftpFiles.length == 0)) {
/* 298 */         return retList;
/*     */       }
/* 300 */       String fileName = null;
/* 301 */       FTPFile ftpFile = null;
/*     */ 
/* 303 */       for (int i = 0; i < ftpFiles.length; i++) {
/* 304 */         ftpFile = ftpFiles[i];
/* 305 */         if ((ftpFile != null) && (ftpFile.isFile())) {
/* 306 */           fileName = ftpFile.getName();
/* 307 */           if ((fileName.startsWith(prefixName)) && (fileName.endsWith(postfixName))) {
/* 308 */             log.debug("fileName:" + fileName);
/* 309 */             log.debug(i + ", get list " + path + fileName);
/* 310 */             retList.add(fileName);
/* 311 */             break;
/*     */           }
/*     */         }
/*     */       }
/* 315 */       return retList;
/*     */     } catch (Throwable t) {
/* 317 */       log.error(t);
/* 318 */       throw t;
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getFile(String path, String prefixName, String postfixName)
/*     */     throws Throwable
/*     */   {
/* 332 */     log.debug("scan ftp file, path is: " + path + ", " + "prefix name is: " + prefixName + ", postfix name is: " + postfixName);
/* 333 */     FTPFile[] ftpFiles = (FTPFile[])null;
/*     */     try
/*     */     {
/* 336 */       ftpFiles = this.client.listFiles(path);
/* 337 */       log.debug("files length:" + ftpFiles.length);
/* 338 */       if ((ftpFiles == null) || (ftpFiles.length == 0)) {
/* 339 */         return "";
/*     */       }
/* 341 */       String fileName = null;
/* 342 */       FTPFile ftpFile = null;
/*     */ 
/* 344 */       for (int i = 0; i < ftpFiles.length; i++) {
/* 345 */         ftpFile = ftpFiles[i];
/* 346 */         if ((ftpFile != null) && (ftpFile.isFile())) {
/* 347 */           fileName = ftpFile.getName();
/* 348 */           if ((fileName.startsWith(prefixName)) && (fileName.endsWith(postfixName))) {
/* 349 */             log.debug("fileName:" + fileName);
/* 350 */             log.debug(i + ", get list " + path + fileName);
/* 351 */             return fileName;
/*     */           }
/*     */         }
/*     */       }
/* 355 */       return "";
/*     */     } catch (Throwable t) {
/* 357 */       log.error(t);
/* 358 */       throw t;
/*     */     }
/*     */   }
/*     */ 
/*     */   public ArrayList<String> getFileListByName(String path, String fileName)
/*     */     throws Exception
/*     */   {
/* 370 */     FTPFile[] ftpFiles = (FTPFile[])null;
/* 371 */     ArrayList retList = null;
/*     */     try
/*     */     {
/* 374 */       ftpFiles = this.client.listFiles(path);
/* 375 */       retList = new ArrayList();
/* 376 */       if ((ftpFiles == null) || (ftpFiles.length == 0)) {
/* 377 */         return retList;
/*     */       }
/*     */ 
/* 380 */       FTPFile ftpFile = null;
/* 381 */       String name = null;
/* 382 */       for (int i = 0; i < ftpFiles.length; i++) {
/* 383 */         ftpFile = ftpFiles[i];
/* 384 */         if (ftpFile.isFile()) {
/* 385 */           name = ftpFile.getName();
/* 386 */           if (fileName.equals(name)) {
/* 387 */             retList.add(name);
/*     */           }
/*     */         }
/*     */       }
/* 391 */       return retList;
/*     */     } catch (Throwable t) {
/* 393 */       log.error(t);
/* 394 */       throw new Exception(t);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static String getFileExtName(String filePath)
/*     */   {
/* 404 */     return filePath.substring(filePath.lastIndexOf(".") + 1);
/*     */   }
/*     */ 
/*     */   public static String getFileName(String pathName)
/*     */   {
/* 423 */     int index1 = pathName.lastIndexOf('/');
/* 424 */     int index2 = pathName.lastIndexOf("\\");
/* 425 */     int index = index1 >= index2 ? index1 : index2;
/* 426 */     return pathName.substring(index + 1);
/*     */   }
/*     */ 
/*     */   public static String getExtName(String pathName)
/*     */   {
/* 435 */     int index1 = pathName.lastIndexOf('/');
/* 436 */     int index2 = pathName.lastIndexOf("\\");
/* 437 */     int index = index1 >= index2 ? index1 : index2;
/* 438 */     return pathName.substring(index - 3);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.util.FtpUtil
 * JD-Core Version:    0.6.2
 */