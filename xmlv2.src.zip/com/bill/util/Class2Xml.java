/*    */ package com.bill.util;
/*    */ 
/*    */ import java.lang.reflect.Field;
/*    */ 
/*    */ public class Class2Xml
/*    */ {
/*    */   public static String exec(Class<?> c)
/*    */   {
/*  7 */     Field[] fields = c.getDeclaredFields();
/*  8 */     StringBuffer sb = new StringBuffer();
/*    */ 
/* 10 */     for (Field f : fields) {
/* 11 */       String fieldName = f.getName();
/* 12 */       sb.append("<" + fieldName + ">");
/*    */ 
/* 30 */       sb.append("</" + fieldName + ">");
/*    */     }
/* 32 */     return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.util.Class2Xml
 * JD-Core Version:    0.6.2
 */