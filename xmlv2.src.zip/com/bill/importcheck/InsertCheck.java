/*     */ package com.bill.importcheck;
/*     */ 
/*     */ import com.bill.db.DbConnectionForOracle;
/*     */ import com.bill.makeXML.util.LogInit;
/*     */ import com.bill.util.config.ConfigReader;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class InsertCheck
/*     */ {
/*  22 */   private static Logger log = Logger.getLogger(InsertCheck.class);
/*  23 */   private static DbConnectionForOracle db = null;
/*     */ 
/*     */   public static void init()
/*     */   {
/*     */     try {
/*  28 */       ConfigReader.init();
/*     */     } catch (Exception e) {
/*  30 */       System.out.println("##### read properties file error, file path:" + ConfigReader.class.getClassLoader().getResource(ConfigReader.CONFIG_PATH));
/*  31 */       return;
/*     */     }
/*     */ 
/*  35 */     db = new DbConnectionForOracle(
/*  36 */       ConfigReader.read("db.ip"), 
/*  37 */       ConfigReader.read("db.port"), 
/*  38 */       ConfigReader.read("db.name"), 
/*  39 */       ConfigReader.read("db.user"), 
/*  40 */       ConfigReader.read("db.pwd"));
/*     */     try
/*     */     {
/*  44 */       config = initConfig(db);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       Map config;
/*  46 */       System.out.println("##### load db config error");
/*  47 */       db.close();
/*     */       return;
/*     */     }
/*     */     Map config;
/*  50 */     LogInit.init((String)config.get("LOG4J_COFIG_PATH"), (String)config.get("FTP_PATH") + "LOG/InsertCheck.log");
/*     */   }
/*     */ 
/*     */   public static void delData()
/*     */   {
/*  58 */     if (db == null)
/*     */     {
/*  60 */       init();
/*     */     }
/*     */ 
/*  63 */     String sql = "delete from TMP_CHECK_DATA";
/*     */     try
/*     */     {
/*  66 */       PreparedStatement statement = db.getConnection().prepareStatement(sql);
/*  67 */       statement.execute();
/*     */     }
/*     */     catch (SQLException e) {
/*  70 */       log.debug("delete from  TMP_CHECK_DATA SQLException.....");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void insertData(InsertBean bean)
/*     */   {
/*  79 */     if (db == null)
/*     */     {
/*  81 */       init();
/*     */     }
/*     */ 
/*  84 */     String sql = "insert into TMP_CHECK_DATA(S_NAME,S_DES_COUNT1,S_COUNT1,S_DES_COUNT2,S_COUNT2,S_DESC,S_TYPE) values (?,?,?,?,?,?,?)";
/*     */     try
/*     */     {
/*  88 */       PreparedStatement statement = db.getConnection().prepareStatement(sql);
/*  89 */       statement.setString(1, bean.getS_name());
/*  90 */       statement.setString(2, bean.getS_des_count1());
/*  91 */       statement.setLong(3, bean.getS_count1());
/*  92 */       statement.setString(4, bean.getS_des_count2());
/*  93 */       statement.setLong(5, bean.getS_count2());
/*  94 */       statement.setString(6, bean.getS_desc());
/*  95 */       statement.setString(7, bean.getS_type());
/*     */ 
/*  97 */       statement.execute();
/*     */     }
/*     */     catch (SQLException e) {
/* 100 */       log.debug("insertData  TMP_CHECK_DATA SQLException....." + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   private static Map<String, String> initConfig(DbConnectionForOracle db)
/*     */     throws SQLException
/*     */   {
/* 111 */     Connection conn = db.getConnection();
/* 112 */     Map map = new HashMap();
/* 113 */     PreparedStatement statement = conn.prepareStatement("select * from t_s_bill_para t");
/* 114 */     ResultSet result = statement.executeQuery();
/* 115 */     while (result.next()) {
/* 116 */       map.put(result.getString("s_type"), result.getString("s_value"));
/*     */     }
/* 118 */     result.close();
/* 119 */     statement.close();
/* 120 */     return map;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.importcheck.InsertCheck
 * JD-Core Version:    0.6.2
 */