/*     */ package com.bill.importcheck;
/*     */ 
/*     */ import com.bill.db.DbConnectionForOracle;
/*     */ import com.bill.makeXML.util.LogInit;
/*     */ import com.bill.util.config.ConfigReader;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class XMLDataCheck
/*     */ {
/*  23 */   private static Logger log = Logger.getLogger(XMLDataCheck.class);
/*  24 */   private static String period = "";
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  29 */     System.out.println("##### XMLDataCheck program start");
/*     */     try
/*     */     {
/*  32 */       ConfigReader.init();
/*     */     } catch (Exception e) {
/*  34 */       System.out.println("##### read properties file error, file path:" + ConfigReader.class.getClassLoader().getResource(ConfigReader.CONFIG_PATH));
/*  35 */       return;
/*     */     }
/*     */ 
/*  39 */     DbConnectionForOracle db = new DbConnectionForOracle(
/*  40 */       ConfigReader.read("db.ip"), 
/*  41 */       ConfigReader.read("db.port"), 
/*  42 */       ConfigReader.read("db.name"), 
/*  43 */       ConfigReader.read("db.user"), 
/*  44 */       ConfigReader.read("db.pwd"));
/*     */     try
/*     */     {
/*  48 */       Map config = initConfig(db);
/*  49 */       period = (String)config.get("PERIOD");
/*     */     } catch (Exception e) {
/*  51 */       System.out.println("##### load db config error");
/*  52 */       db.close();
/*     */       return;
/*     */     }
/*     */     Map config;
/*  55 */     LogInit.init((String)config.get("LOG4J_COFIG_PATH"), (String)config.get("LOG4J_FILENAME") + "XMLDataCheck.log");
/*  56 */     boolean status = check(db.getConnection());
/*  57 */     if (status)
/*  58 */       System.exit(-1);
/*     */     else
/*  60 */       System.exit(0);
/*     */   }
/*     */ 
/*     */   public static boolean check(Connection conn)
/*     */   {
/*  73 */     boolean status = false;
/*     */     try
/*     */     {
/*  76 */       int count1 = checkEle(conn);
/*  77 */       if (count1 != 0)
/*     */       {
/*  79 */         status = true;
/*  80 */         log.debug("xml合成(电子)总数不一致!");
/*     */       }
/*     */       else {
/*  83 */         log.debug("xml合成(电子)总数一致!");
/*     */       }
/*     */ 
/*  86 */       int count2 = checkPaper(conn);
/*  87 */       if (count2 != 0)
/*     */       {
/*  89 */         status = true;
/*  90 */         log.debug("xml合成(纸质)总数不一致!");
/*     */       }
/*     */       else
/*     */       {
/*  94 */         log.debug("xml合成(纸质)总数一致!");
/*     */       }
/*     */     }
/*     */     catch (SQLException e) {
/*  98 */       log.debug("FileNotFoundException......");
/*  99 */       status = true;
/*     */     }
/*     */ 
/* 102 */     return status;
/*     */   }
/*     */ 
/*     */   public static int checkEle(Connection conn)
/*     */     throws SQLException
/*     */   {
/* 112 */     PreparedStatement statement = null;
/* 113 */     XMLDataBean bean = null;
/* 114 */     InsertBean bean2 = null;
/* 115 */     int count = 0;
/*     */ 
/* 117 */     String sql = getEleSQL(conn);
/* 118 */     if (sql == null) {
/* 119 */       return -1;
/*     */     }
/* 121 */     statement = conn.prepareStatement(sql);
/* 122 */     statement.setString(1, period);
/* 123 */     statement.setString(2, "0");
/* 124 */     ResultSet result = statement.executeQuery();
/* 125 */     while (result.next()) {
/* 126 */       bean = new XMLDataBean();
/*     */ 
/* 128 */       bean.setCard1(result.getString("card1"));
/* 129 */       if ((result.getString("count1") != null) && (!"".equals(result.getString("count1").trim())))
/* 130 */         bean.setCount1(Long.valueOf(result.getString("count1")).longValue());
/*     */       else {
/* 132 */         bean.setCount1(0L);
/*     */       }
/* 134 */       bean.setCard2(result.getString("card2"));
/* 135 */       if ((result.getString("count2") != null) && (!"".equals(result.getString("count2").trim())))
/* 136 */         bean.setCount2(Long.valueOf(result.getString("count2")).longValue());
/*     */       else {
/* 138 */         bean.setCount2(0L);
/*     */       }
/* 140 */       if (bean.getCount1() != bean.getCount2())
/*     */       {
/* 142 */         count++;
/*     */ 
/* 144 */         bean2 = new InsertBean();
/* 145 */         bean2.setS_name("XML合成(电子)");
/*     */ 
/* 147 */         bean2.setS_type(bean.getCard1());
/* 148 */         bean2.setS_des_count1("数据库数量");
/* 149 */         bean2.setS_count1(bean.getCount1());
/* 150 */         bean2.setS_des_count2("XML数量");
/* 151 */         bean2.setS_count2(bean.getCount2());
/* 152 */         bean2.setS_desc("XML合成 check");
/* 153 */         InsertCheck.insertData(bean2);
/*     */       }
/*     */     }
/*     */ 
/* 157 */     return count;
/*     */   }
/*     */ 
/*     */   public static String getEleSQL(Connection conn)
/*     */   {
/* 166 */     String sql = "select t4.count1 as count2,t4.s_card_prod_id as card1,t3.count2 as count1,t3.s_card_prod_id as card2 from  (select sum(t1.i_share) as count2,t1.s_card_prod_id from T_B_XML_LOG t1 where t1.s_period = ? and t1.s_paper_no is null and c_type=? group by t1.s_card_prod_id) t3  left join  (select count(t2.s_card_prod_id) as count1,t2.s_card_prod_id from T_B_CUSTOMER_BILL t2 group by t2.s_card_prod_id) t4  on t3.s_card_prod_id = t4.s_card_prod_id";
/*     */     try
/*     */     {
/* 172 */       if (getEleXMLCount(conn) < getEleCustomerBillCount(conn)) {
/* 173 */         sql = "select t4.count1 as count1,t4.s_card_prod_id as card1,t3.count2 as count2,t3.s_card_prod_id as card2 from  (select count(t2.s_card_prod_id) as count1,t2.s_card_prod_id from T_B_CUSTOMER_BILL t2 group by t2.s_card_prod_id) t4  left join  (select sum(t1.i_share) as count2,t1.s_card_prod_id from T_B_XML_LOG t1 where t1.s_period = ? and t1.s_paper_no is null and c_type=? group by t1.s_card_prod_id) t3  on t3.s_card_prod_id = t4.s_card_prod_id";
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/* 179 */       log.debug("getSQL SQLException ...............");
/* 180 */       sql = null;
/*     */     }
/* 182 */     log.debug(sql);
/* 183 */     return sql;
/*     */   }
/*     */ 
/*     */   public static int getEleXMLCount(Connection conn)
/*     */     throws SQLException
/*     */   {
/* 192 */     PreparedStatement statement = null;
/* 193 */     String sql = "select count(s_card_prod_id) from (select s_card_prod_id from T_B_XML_LOG t1 where t1.s_period = ? and t1.s_paper_no is null and c_type = ? group by t1.s_card_prod_id)";
/* 194 */     int count = 0;
/*     */     try
/*     */     {
/* 197 */       statement = conn.prepareStatement(sql);
/* 198 */       statement.setString(1, period);
/* 199 */       statement.setString(2, "0");
/* 200 */       log.debug("para: " + period + ", 0");
/* 201 */       ResultSet result = statement.executeQuery();
/* 202 */       result.next();
/*     */ 
/* 204 */       count = result.getInt(1);
/* 205 */       return count;
/*     */     }
/*     */     finally {
/* 208 */       if (statement != null)
/* 209 */         statement.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int getEleCustomerBillCount(Connection conn)
/*     */     throws SQLException
/*     */   {
/* 221 */     PreparedStatement statement = null;
/* 222 */     String sql = "select count(s_card_prod_id) from (select t1.s_card_prod_id from T_B_CUSTOMER_BILL t1 group by t1.s_card_prod_id)";
/* 223 */     int count = 0;
/*     */     try {
/* 225 */       statement = conn.prepareStatement(sql);
/* 226 */       ResultSet result = statement.executeQuery();
/* 227 */       result.next();
/* 228 */       count = result.getInt(1);
/*     */ 
/* 230 */       return count;
/*     */     }
/*     */     finally {
/* 233 */       if (statement != null)
/* 234 */         statement.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int checkPaper(Connection conn)
/*     */     throws SQLException
/*     */   {
/* 247 */     PreparedStatement statement = null;
/* 248 */     XMLDataBean bean = null;
/* 249 */     InsertBean bean2 = null;
/* 250 */     int count = 0;
/*     */ 
/* 252 */     String sql = getPaperSQL(conn);
/* 253 */     if (sql == null) {
/* 254 */       return -1;
/*     */     }
/* 256 */     statement = conn.prepareStatement(sql);
/* 257 */     statement.setString(1, period);
/* 258 */     ResultSet result = statement.executeQuery();
/* 259 */     while (result.next()) {
/* 260 */       bean = new XMLDataBean();
/*     */ 
/* 262 */       bean.setCard1(result.getString("card1"));
/* 263 */       if ((result.getString("count1") != null) && (!"".equals(result.getString("count1").trim())))
/* 264 */         bean.setCount1(Integer.valueOf(result.getString("count1")).intValue());
/*     */       else {
/* 266 */         bean.setCount1(0L);
/*     */       }
/* 268 */       bean.setCard2(result.getString("card2"));
/* 269 */       if ((result.getString("count2") != null) && (!"".equals(result.getString("count2").trim())))
/* 270 */         bean.setCount2(Integer.valueOf(result.getString("count2")).intValue());
/*     */       else {
/* 272 */         bean.setCount2(0L);
/*     */       }
/* 274 */       if (bean.getCount1() != bean.getCount2())
/*     */       {
/* 276 */         count++;
/*     */ 
/* 278 */         bean2 = new InsertBean();
/* 279 */         bean2.setS_name("XML合成(纸质)");
/*     */ 
/* 281 */         bean2.setS_type(bean.getCard1());
/* 282 */         bean2.setS_des_count1("数据库数量");
/* 283 */         bean2.setS_count1(bean.getCount1());
/* 284 */         bean2.setS_des_count2("XML数量");
/* 285 */         bean2.setS_count2(bean.getCount2());
/* 286 */         bean2.setS_desc("XML合成 check");
/* 287 */         InsertCheck.insertData(bean2);
/*     */       }
/*     */     }
/*     */ 
/* 291 */     return count;
/*     */   }
/*     */ 
/*     */   public static String getPaperSQL(Connection conn)
/*     */   {
/* 297 */     String sql = "select t4.count1 as count1,t4.s_card_prod_id as card1,t3.count2 as count2,t3.s_card_prod_id as card2 from  (select sum(t1.i_share) as count2,t1.s_card_prod_id from T_B_XML_LOG t1 where t1.s_period = ? and t1.s_paper_no is not null group by t1.s_card_prod_id) t3  left join  (select count(t2.s_card_prod_id) as count1,t2.s_card_prod_id from T_B_CUSTOMER_BILL t2 where t2.C_CUR_PAPER_STMT_FLAG = 'Y' group by t2.s_card_prod_id) t4  on t3.s_card_prod_id = t4.s_card_prod_id";
/*     */     try
/*     */     {
/* 303 */       if (getPaperXMLCount(conn) < getPaperCustomerBillCount(conn)) {
/* 304 */         sql = "select t4.count1 as count1,t4.s_card_prod_id as card1,t3.count2 as count2,t3.s_card_prod_id as card2 from  (select count(t2.s_card_prod_id) as count1,t2.s_card_prod_id from T_B_CUSTOMER_BILL t2 where t2.C_CUR_PAPER_STMT_FLAG = 'Y' group by t2.s_card_prod_id) t4  left join  (select sum(t1.i_share) as count2,t1.s_card_prod_id from T_B_XML_LOG t1 where t1.s_period = ? and t1.s_paper_no is not null group by t1.s_card_prod_id) t3  on t3.s_card_prod_id = t4.s_card_prod_id";
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/* 310 */       log.debug("getSQL SQLException ...............");
/* 311 */       sql = null;
/*     */     }
/* 313 */     log.debug(sql);
/* 314 */     return sql;
/*     */   }
/*     */ 
/*     */   public static int getPaperXMLCount(Connection conn)
/*     */     throws SQLException
/*     */   {
/* 325 */     PreparedStatement statement = null;
/* 326 */     String sql = "select count(s_card_prod_id) from (select s_card_prod_id from T_B_XML_LOG t1 where t1.s_period = ? and t1.s_paper_no is not null group by t1.s_card_prod_id)";
/* 327 */     int count = 0;
/*     */     try
/*     */     {
/* 330 */       statement = conn.prepareStatement(sql);
/* 331 */       statement.setString(1, period);
/* 332 */       ResultSet result = statement.executeQuery();
/* 333 */       result.next();
/* 334 */       count = result.getInt(1);
/* 335 */       return count;
/*     */     }
/*     */     finally {
/* 338 */       if (statement != null)
/* 339 */         statement.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int getPaperCustomerBillCount(Connection conn)
/*     */     throws SQLException
/*     */   {
/* 352 */     PreparedStatement statement = null;
/* 353 */     String sql = "select count(s_card_prod_id) from (select t1.s_card_prod_id from T_B_CUSTOMER_BILL t1 where t1.C_CUR_PAPER_STMT_FLAG = 'Y' group by t1.s_card_prod_id)";
/* 354 */     int count = 0;
/*     */     try {
/* 356 */       statement = conn.prepareStatement(sql);
/* 357 */       ResultSet result = statement.executeQuery();
/* 358 */       result.next();
/* 359 */       count = result.getInt(1);
/*     */ 
/* 361 */       return count;
/*     */     }
/*     */     finally {
/* 364 */       if (statement != null)
/* 365 */         statement.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static Map<String, String> initConfig(DbConnectionForOracle db)
/*     */     throws SQLException
/*     */   {
/* 377 */     Connection conn = db.getConnection();
/* 378 */     Map map = new HashMap();
/* 379 */     PreparedStatement statement = conn.prepareStatement("select * from t_s_bill_para t");
/* 380 */     ResultSet result = statement.executeQuery();
/* 381 */     while (result.next()) {
/* 382 */       map.put(result.getString("s_type"), result.getString("s_value"));
/*     */     }
/* 384 */     result.close();
/* 385 */     statement.close();
/* 386 */     return map;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.importcheck.XMLDataCheck
 * JD-Core Version:    0.6.2
 */