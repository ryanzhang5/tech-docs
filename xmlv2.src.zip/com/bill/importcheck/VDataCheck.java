/*     */ package com.bill.importcheck;
/*     */ 
/*     */ import com.bill.db.DbConnectionForOracle;
/*     */ import com.bill.makeXML.dao.DBDao;
/*     */ import com.bill.util.LogInit;
/*     */ import com.bill.util.StringUtil;
/*     */ import com.bill.util.config.ConfigReader;
/*     */ import com.bill.util.config.DeployConfigReader;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.SocketException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.net.ftp.FTPClient;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class VDataCheck
/*     */ {
/*  36 */   private static Logger log = Logger.getLogger(VDataCheck.class);
/*  37 */   private static DbConnectionForOracle db = null;
/*  38 */   private static Map<String, Integer> dataMap = new HashMap();
/*  39 */   private static Map<String, String> inputdDtaMap = new HashMap();
/*  40 */   private static Map<String, String> config = null;
/*  41 */   private static String filename = "";
/*  42 */   private static String to_path = "";
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  47 */     System.out.println("##### V+DataCheck program start");
/*     */     try
/*     */     {
/*  50 */       ConfigReader.init();
/*  51 */       DeployConfigReader.init();
/*     */     } catch (Exception e) {
/*  53 */       System.out.println("##### read properties file error, file path:" + ConfigReader.class.getClassLoader().getResource(ConfigReader.CONFIG_PATH));
/*  54 */       return;
/*     */     }
/*     */ 
/*  57 */     if ((args != null) && (args.length > 0))
/*     */     {
/*  59 */       String[] arrayOfString1 = args; int j = args.length; for (int i = 0; i < j; i++) { String s = arrayOfString1[i];
/*  60 */         String[] ss = s.split(":");
/*  61 */         inputdDtaMap.put(ss[0], ss[1]);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  68 */     db = new DbConnectionForOracle(
/*  69 */       ConfigReader.read("db.ip"), 
/*  70 */       ConfigReader.read("db.port"), 
/*  71 */       ConfigReader.read("db.name"), 
/*  72 */       ConfigReader.read("db.user"), 
/*  73 */       ConfigReader.read("db.pwd"));
/*     */ 
/*  75 */     DBDao dao = new DBDao(db);
/*  76 */     config = dao.getConfig();
/*     */ 
/*  79 */     LogInit.init((String)config.get("LOG4J_COFIG_PATH"), 
/*  80 */       (String)config.get("LOG4J_FILENAME") + "VDataCheck.log");
/*     */ 
/*  84 */     to_path = (String)inputdDtaMap.get("datapath");
/*  85 */     filename = (String)inputdDtaMap.get("filename");
/*  86 */     filename = filename.replaceAll("yyyyMMdd", (String)config.get("PERIOD"));
/*     */ 
/*  92 */     if (!readCheckFile()) {
/*  93 */       System.exit(-1);
/*     */     }
/*     */ 
/*  96 */     if (checkData())
/*  97 */       System.exit(0);
/*     */     else
/*  99 */       System.exit(-1);
/*     */   }
/*     */ 
/*     */   public static boolean downloadCheckFile()
/*     */   {
/* 107 */     FTPClient client = new FTPClient();
/* 108 */     boolean result = false;
/* 109 */     String ip = DeployConfigReader.read("v.ftp.ip");
/* 110 */     int port = Integer.parseInt(DeployConfigReader.read("v.ftp.port"));
/* 111 */     String userName = DeployConfigReader.read("v.ftp.username");
/* 112 */     String password = DeployConfigReader.read("v.ftp.userpass");
/* 113 */     String from_path = DeployConfigReader.read("v.ftp.from.path");
/*     */ 
/* 115 */     BufferedOutputStream bos = null;
/* 116 */     FileOutputStream fos = null;
/*     */ 
/* 118 */     log.debug("ftp connect:ip=" + ip + ",port=" + port + ",name=" + userName + ",pass=" + password);
/*     */     try {
/* 120 */       client.connect(ip, port);
/* 121 */       result = client.login(userName, password);
/*     */ 
/* 123 */       if (result) {
/* 124 */         if ("1".equals(config))
/* 125 */           client.enterLocalActiveMode();
/*     */         else {
/* 127 */           client.enterLocalPassiveMode();
/*     */         }
/*     */       }
/* 130 */       log.debug("ftp dowoload to:" + to_path + filename);
/* 131 */       File file = new File(to_path + filename);
/* 132 */       if (file.exists()) {
/* 133 */         file.delete();
/*     */       }
/*     */ 
/* 136 */       fos = new FileOutputStream(file);
/* 137 */       bos = new BufferedOutputStream(fos);
/* 138 */       log.debug("ftp dowoload from:" + from_path + filename);
/* 139 */       result = false;
/* 140 */       result = client.retrieveFile(from_path + filename, bos);
/*     */     }
/*     */     catch (SocketException e) {
/* 143 */       e.printStackTrace();
/* 144 */       result = false;
/*     */       try
/*     */       {
/* 150 */         bos.close();
/* 151 */         fos.close();
/*     */       } catch (IOException e) {
/* 153 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 146 */       e.printStackTrace();
/* 147 */       result = false;
/*     */       try
/*     */       {
/* 150 */         bos.close();
/* 151 */         fos.close();
/*     */       } catch (IOException e) {
/* 153 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 150 */         bos.close();
/* 151 */         fos.close();
/*     */       } catch (IOException e) {
/* 153 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */ 
/* 157 */     return result;
/*     */   }
/*     */ 
/*     */   public static boolean readCheckFile()
/*     */   {
/* 169 */     log.debug("v+ data check:readCheckFile");
/*     */ 
/* 171 */     boolean result = true;
/* 172 */     BufferedReader reader = null;
/* 173 */     List list = null;
/* 174 */     String str = "";
/*     */     try {
/* 176 */       File file = new File(to_path + filename);
/* 177 */       reader = new BufferedReader(new FileReader(file));
/* 178 */       while ((str = reader.readLine()) != null)
/*     */       {
/* 180 */         list = StringUtil.SplieASCII(str);
/* 181 */         log.debug((String)list.get(0) + ";" + (String)list.get(1));
/*     */ 
/* 183 */         if ((list.get(0) != "C002") && (list.get(0) != "E002") && (list.get(0) != "I001"))
/*     */         {
/* 185 */           dataMap.put((String)list.get(0), Integer.valueOf(Integer.parseInt((String)list.get(1))));
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (FileNotFoundException e) {
/* 190 */       e.printStackTrace();
/* 191 */       result = false;
/*     */       try
/*     */       {
/* 198 */         reader.close();
/*     */       } catch (IOException e) {
/* 200 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 193 */       e.printStackTrace();
/* 194 */       result = false;
/*     */       try
/*     */       {
/* 198 */         reader.close();
/*     */       } catch (IOException e) {
/* 200 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 198 */         reader.close();
/*     */       } catch (IOException e) {
/* 200 */         e.printStackTrace();
/*     */       }
/*     */     }
/* 203 */     if (!dataMap.containsKey("A001")) {
/* 204 */       log.error("缺少A001数据");
/* 205 */       result = false;
/*     */     }
/* 207 */     if (!dataMap.containsKey("B001")) {
/* 208 */       log.error("缺少B001数据");
/* 209 */       result = false;
/*     */     }
/* 211 */     if (!dataMap.containsKey("C001")) {
/* 212 */       log.error("缺少C001数据");
/* 213 */       result = false;
/*     */     }
/*     */ 
/* 219 */     if (!dataMap.containsKey("D001")) {
/* 220 */       log.error("缺少D001数据");
/* 221 */       result = false;
/*     */     }
/* 223 */     if (!dataMap.containsKey("E001")) {
/* 224 */       log.error("缺少E001数据");
/* 225 */       result = false;
/*     */     }
/*     */ 
/* 231 */     if (!dataMap.containsKey("F001")) {
/* 232 */       log.error("缺少F001数据");
/* 233 */       result = false;
/*     */     }
/* 235 */     if (!dataMap.containsKey("H001")) {
/* 236 */       log.error("缺少H001数据");
/* 237 */       result = false;
/*     */     }
/*     */ 
/* 243 */     return result;
/*     */   }
/*     */ 
/*     */   public static boolean checkData()
/*     */   {
/* 248 */     boolean result = true;
/* 249 */     String sql = "select (select count(1) from T_B_CUSTOMER_BILL) as A001,(select count(1) from T_B_CUSTOMER_BILL_RMB) as B001,(select count(1) from T_B_CUSTOMER_BILL_DETAIL_RMB) as C001,(select count(1) from T_B_CUSTOMER_DOLLAR) as D001,(select count(1) from T_B_CUSTOMER_DOLLAR_DETAIL) as E001,(select count(1) from t_b_customer_stageplan) as H001,(select count(1) from T_B_CUSTOMER_PURCHASE) as F001 from dual";
/*     */ 
/* 261 */     log.debug(sql);
/* 262 */     Connection conn = db.getConnection();
/* 263 */     PreparedStatement statement = null;
/* 264 */     ResultSet res = null;
/*     */     try {
/* 266 */       statement = conn.prepareStatement(sql);
/* 267 */       res = statement.executeQuery();
/* 268 */       while (res.next()) {
/* 269 */         if (((Integer)dataMap.get("A001")).intValue() != res.getInt("A001"))
/* 270 */           result = false;
/* 271 */         if (((Integer)dataMap.get("B001")).intValue() != res.getInt("B001"))
/* 272 */           result = false;
/* 273 */         if (((Integer)dataMap.get("C001")).intValue() != res.getInt("C001")) {
/* 274 */           result = false;
/*     */         }
/*     */ 
/* 277 */         if (((Integer)dataMap.get("D001")).intValue() != res.getInt("D001"))
/* 278 */           result = false;
/* 279 */         if (((Integer)dataMap.get("E001")).intValue() != res.getInt("E001")) {
/* 280 */           result = false;
/*     */         }
/*     */ 
/* 283 */         if (((Integer)dataMap.get("F001")).intValue() != res.getInt("F001"))
/* 284 */           result = false;
/* 285 */         if (((Integer)dataMap.get("H001")).intValue() != res.getInt("H001")) {
/* 286 */           result = false;
/*     */         }
/*     */ 
/* 289 */         log.debug("A001 check=" + dataMap.get("A001") + ",db=" + res.getInt("A001") + 
/* 290 */           "\nB001 check=" + dataMap.get("B001") + ",db=" + res.getInt("B001") + 
/* 291 */           "\nC001 check=" + dataMap.get("C001") + ",db=" + res.getInt("C001") + 
/* 293 */           "\nD001 check=" + dataMap.get("D001") + ",db=" + res.getInt("D001") + 
/* 294 */           "\nE001 check=" + dataMap.get("E001") + ",db=" + res.getInt("E001") + 
/* 296 */           "\nF001 check=" + dataMap.get("F001") + ",db=" + res.getInt("F001") + 
/* 298 */           "\nH001 check=" + dataMap.get("H001") + ",db=" + res.getInt("H001"));
/*     */       }
/*     */     } catch (SQLException e) {
/* 301 */       e.printStackTrace();
/* 302 */       result = false;
/*     */       try
/*     */       {
/* 305 */         res.close();
/* 306 */         statement.close();
/* 307 */         conn.close();
/* 308 */         db.close();
/*     */       } catch (SQLException e) {
/* 310 */         e.printStackTrace();
/* 311 */         result = false;
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 305 */         res.close();
/* 306 */         statement.close();
/* 307 */         conn.close();
/* 308 */         db.close();
/*     */       } catch (SQLException e) {
/* 310 */         e.printStackTrace();
/* 311 */         result = false;
/*     */       }
/*     */     }
/*     */ 
/* 315 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.importcheck.VDataCheck
 * JD-Core Version:    0.6.2
 */