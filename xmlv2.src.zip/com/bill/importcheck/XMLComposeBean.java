/*     */ package com.bill.importcheck;
/*     */ 
/*     */ public class XMLComposeBean
/*     */ {
/*     */   private String period;
/*     */   private String type;
/*     */   private String filename;
/*     */   private long sharenum;
/*     */   private String paperno;
/*     */   private String businpntno;
/*     */   private String cardprodid;
/*     */   private String period2;
/*     */   private String type2;
/*     */   private String filename2;
/*     */   private long sharenum2;
/*     */   private String paperno2;
/*     */   private String businpntno2;
/*     */   private String cardprodid2;
/*     */ 
/*     */   public String getPeriod()
/*     */   {
/*  24 */     return this.period;
/*     */   }
/*     */   public void setPeriod(String period) {
/*  27 */     this.period = period;
/*     */   }
/*     */   public String getType() {
/*  30 */     return this.type;
/*     */   }
/*     */   public void setType(String type) {
/*  33 */     this.type = type;
/*     */   }
/*     */   public String getFilename() {
/*  36 */     return this.filename;
/*     */   }
/*     */   public void setFilename(String filename) {
/*  39 */     this.filename = filename;
/*     */   }
/*     */   public long getSharenum() {
/*  42 */     return this.sharenum;
/*     */   }
/*     */   public void setSharenum(long sharenum) {
/*  45 */     this.sharenum = sharenum;
/*     */   }
/*     */ 
/*     */   public String getPaperno() {
/*  49 */     return this.paperno;
/*     */   }
/*     */   public void setPaperno(String paperno) {
/*  52 */     this.paperno = paperno;
/*     */   }
/*     */   public String getBusinpntno() {
/*  55 */     return this.businpntno;
/*     */   }
/*     */   public void setBusinpntno(String businpntno) {
/*  58 */     this.businpntno = businpntno;
/*     */   }
/*     */   public String getCardprodid() {
/*  61 */     return this.cardprodid;
/*     */   }
/*     */   public void setCardprodid(String cardprodid) {
/*  64 */     this.cardprodid = cardprodid;
/*     */   }
/*     */ 
/*     */   public String getPeriod2() {
/*  68 */     return this.period2;
/*     */   }
/*     */   public void setPeriod2(String period2) {
/*  71 */     this.period2 = period2;
/*     */   }
/*     */   public String getType2() {
/*  74 */     return this.type2;
/*     */   }
/*     */   public void setType2(String type2) {
/*  77 */     this.type2 = type2;
/*     */   }
/*     */   public String getFilename2() {
/*  80 */     return this.filename2;
/*     */   }
/*     */   public void setFilename2(String filename2) {
/*  83 */     this.filename2 = filename2;
/*     */   }
/*     */   public long getSharenum2() {
/*  86 */     return this.sharenum2;
/*     */   }
/*     */   public void setSharenum2(long sharenum2) {
/*  89 */     this.sharenum2 = sharenum2;
/*     */   }
/*     */   public String getPaperno2() {
/*  92 */     return this.paperno2;
/*     */   }
/*     */   public void setPaperno2(String paperno2) {
/*  95 */     this.paperno2 = paperno2;
/*     */   }
/*     */   public String getBusinpntno2() {
/*  98 */     return this.businpntno2;
/*     */   }
/*     */   public void setBusinpntno2(String businpntno2) {
/* 101 */     this.businpntno2 = businpntno2;
/*     */   }
/*     */   public String getCardprodid2() {
/* 104 */     return this.cardprodid2;
/*     */   }
/*     */   public void setCardprodid2(String cardprodid2) {
/* 107 */     this.cardprodid2 = cardprodid2;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 112 */     int prime = 31;
/* 113 */     int result = 1;
/* 114 */     result = 31 * result + (
/* 115 */       this.period == null ? 0 : this.period.hashCode());
/* 116 */     result = 31 * result + (
/* 117 */       this.businpntno == null ? 0 : this.businpntno.hashCode());
/* 118 */     result = 31 * result + (
/* 119 */       this.cardprodid == null ? 0 : this.cardprodid.hashCode());
/* 120 */     result = 31 * result + (
/* 121 */       this.paperno == null ? 0 : this.paperno.hashCode());
/*     */ 
/* 124 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 130 */     if ((obj == null) || (!(obj instanceof XMLComposeBean))) {
/* 131 */       return false;
/*     */     }
/* 133 */     if (this == obj) {
/* 134 */       return true;
/*     */     }
/* 136 */     XMLComposeBean other = (XMLComposeBean)obj;
/* 137 */     if (this.period == null)
/*     */     {
/* 139 */       if (other.period != null)
/* 140 */         return false;
/*     */     }
/* 142 */     else if (!this.period.equals(other.period)) {
/* 143 */       return false;
/*     */     }
/* 145 */     if (this.businpntno == null)
/*     */     {
/* 147 */       if (other.businpntno != null)
/* 148 */         return false;
/*     */     }
/* 150 */     else if (!this.businpntno.equals(other.businpntno)) {
/* 151 */       return false;
/*     */     }
/* 153 */     if (this.cardprodid == null)
/*     */     {
/* 155 */       if (other.cardprodid != null)
/* 156 */         return false;
/*     */     }
/* 158 */     else if (!this.cardprodid.equals(other.cardprodid)) {
/* 159 */       return false;
/*     */     }
/* 161 */     if (this.paperno == null)
/*     */     {
/* 163 */       if (other.paperno != null)
/* 164 */         return false;
/*     */     }
/* 166 */     else if (!this.paperno.equals(other.paperno)) {
/* 167 */       return false;
/*     */     }
/* 169 */     return true;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 174 */     return "T_B_COMPOSE_LOG:type=" + this.type2 + 
/* 175 */       ", period=" + this.period2 + 
/* 176 */       ", businpntno=" + this.businpntno2 + 
/* 177 */       ", cardprodid=" + this.cardprodid2 + 
/* 178 */       ", paperno=" + this.paperno2 + 
/* 179 */       ", sharenum=" + this.sharenum2 + 
/* 180 */       "\n   " + 
/* 181 */       "T_B_XML_LOG:period=" + this.period + 
/* 182 */       ", businpntno=" + this.businpntno + 
/* 183 */       ", cardprodid=" + this.cardprodid + 
/* 184 */       ", paperno=" + this.paperno + 
/* 185 */       ", sharenum=" + this.sharenum;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.importcheck.XMLComposeBean
 * JD-Core Version:    0.6.2
 */