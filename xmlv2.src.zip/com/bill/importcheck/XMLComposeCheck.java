/*     */ package com.bill.importcheck;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.db.DbConnectionForOracle;
/*     */ import com.bill.util.LogInit;
/*     */ import com.bill.util.config.ConfigReader;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class XMLComposeCheck
/*     */ {
/*  24 */   private static Logger log = Logger.getLogger(XMLComposeCheck.class);
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  30 */     log.info("##### XMLComposeCheck program start");
/*     */     try
/*     */     {
/*  33 */       ConfigReader.init();
/*     */     } catch (Exception e) {
/*  35 */       log.info("##### read properties file error, file path:" + 
/*  36 */         ConfigReader.class.getClassLoader().getResource(
/*  37 */         ConfigReader.CONFIG_PATH));
/*  38 */       return;
/*     */     }
/*     */ 
/*  42 */     DbConnectionForOracle db = new DbConnectionForOracle(
/*  43 */       ConfigReader.read("db.ip"), ConfigReader.read("db.port"), 
/*  44 */       ConfigReader.read("db.name"), ConfigReader.read("db.user"), 
/*  45 */       ConfigReader.read("db.pwd"));
/*     */     try
/*     */     {
/*  49 */       Map config = initConfig(db);
/*     */ 
/*  51 */       BaseParam.setPeriod((String)config.get("PERIOD"));
/*     */     } catch (Exception e) {
/*  53 */       log.error("##### load db config error");
/*  54 */       db.close();
/*     */       return;
/*     */     }
/*     */     Map config;
/*  57 */     LogInit.init((String)config.get("LOG4J_COFIG_PATH"), 
/*  58 */       (String)config.get("LOG4J_FILENAME") + "XMLComposeCheck.log");
/*     */ 
/*  60 */     int count = 0;
/*     */     try {
/*  62 */       clear(db.getConnection());
/*  63 */       read(db.getConnection());
/*  64 */       count = check(db.getConnection());
/*     */     } catch (SQLException e) {
/*  66 */       log.debug("SQLException ..................");
/*  67 */       count = -1;
/*     */     }
/*     */     finally {
/*  70 */       db.close();
/*     */     }
/*     */ 
/*  73 */     log.debug("总共有 " + count + " 条记录不相符!");
/*     */ 
/*  75 */     if (count != 0)
/*  76 */       System.exit(-1);
/*     */     else
/*  78 */       System.exit(0);
/*     */   }
/*     */ 
/*     */   public static int check(Connection conn)
/*     */     throws SQLException
/*     */   {
/*  89 */     PreparedStatement statement = null;
/*  90 */     int count = 0;
/*     */     try {
/*  92 */       statement = conn
/*  93 */         .prepareStatement("select * from TMP_CHECK_DATA t where t.i_no=3 and t.s_count1<>t.s_count2");
/*  94 */       ResultSet result = statement.executeQuery();
/*  95 */       while (result.next()) {
/*  96 */         log.debug(
/*  97 */           result
/*  98 */           .getString("S_TYPE") + "数据验证错误！");
/*  99 */         count++;
/*     */       }
/* 101 */       return count;
/*     */     }
/*     */     finally {
/* 104 */       if (statement != null) statement.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void read(Connection conn)
/*     */   {
/* 112 */     PreparedStatement statement = null;
/* 113 */     String sql = "insert into tmp_check_data (S_NAME,S_TYPE,S_COUNT1,S_COUNT2,S_DESC,S_DES_COUNT1,S_DES_COUNT2,I_NO)(select CASE WHEN t.c_compose_type = '1' THEN           '账单合成(纸制)'\t\t   WHEN T.C_COMPOSE_TYPE = '2' THEN +\t\t\t'账单合成(电子)'\t\t   END as s_name,         t.s_card_prod_id as s_type,         t.i_compose_share_unit as s_count1,\t\t    t1.i_share as s_count2,\t\t   '账单合成 check' as s_desc,\t \t   'XML数量' as S_DES_COUNT1,\t\t   '账单数量' as S_DES_COUNT2,\t\t   3 as i_no\t from T_B_COMPOSE_LOG t, T_B_XML_LOG t1  where t.s_period = ?    and t1.s_period = ?   AND T.C_COMPOSE_TYPE <> 3    AND T1.C_TYPE = '0'     and t.s_compose_filename=replace(substr(t1.s_filename, instr(t1.s_filename, '/', -1) + 1),'.xml',''))";
/*     */     try
/*     */     {
/* 134 */       log.debug(sql + ", " + BaseParam.PERIOD_Y_M_D + ", " + BaseParam.PERIOD);
/* 135 */       statement = conn.prepareStatement(sql);
/* 136 */       statement.setString(1, BaseParam.PERIOD_Y_M_D);
/* 137 */       statement.setString(2, BaseParam.PERIOD);
/* 138 */       statement.executeUpdate();
/*     */     } catch (SQLException e) {
/* 140 */       e.printStackTrace();
/*     */       try
/*     */       {
/* 144 */         if (statement != null)
/* 145 */           statement.close();
/*     */       } catch (SQLException e) {
/* 147 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 144 */         if (statement != null)
/* 145 */           statement.close();
/*     */       } catch (SQLException e) {
/* 147 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void clear(Connection conn)
/*     */   {
/* 156 */     PreparedStatement statement = null;
/*     */     try {
/* 158 */       statement = conn.prepareStatement("delete from TMP_CHECK_DATA t where t.i_no=3");
/* 159 */       statement.executeUpdate();
/*     */     } catch (SQLException e) {
/* 161 */       e.printStackTrace();
/*     */       try
/*     */       {
/* 165 */         if (statement != null)
/* 166 */           statement.close();
/*     */       } catch (SQLException e) {
/* 168 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 165 */         if (statement != null)
/* 166 */           statement.close();
/*     */       } catch (SQLException e) {
/* 168 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static Map<String, String> initConfig(DbConnectionForOracle db)
/*     */     throws SQLException
/*     */   {
/* 182 */     Connection conn = db.getConnection();
/* 183 */     Map map = new HashMap();
/* 184 */     PreparedStatement statement = conn
/* 185 */       .prepareStatement("select * from t_s_bill_para t");
/* 186 */     ResultSet result = statement.executeQuery();
/* 187 */     while (result.next()) {
/* 188 */       map.put(result.getString("s_type"), result.getString("s_value"));
/*     */     }
/* 190 */     result.close();
/* 191 */     statement.close();
/* 192 */     return map;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.importcheck.XMLComposeCheck
 * JD-Core Version:    0.6.2
 */