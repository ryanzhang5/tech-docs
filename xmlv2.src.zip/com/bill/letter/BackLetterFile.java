/*     */ package com.bill.letter;
/*     */ 
/*     */ import com.bill.db.DbConnectionForOracle;
/*     */ import com.bill.util.LogInit;
/*     */ import com.bill.util.config.ConfigReader;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class BackLetterFile
/*     */ {
/*  27 */   private static Logger log = Logger.getLogger(BackLetterFile.class);
/*     */ 
/*  29 */   private static int number = 100000;
/*     */ 
/*  31 */   private static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
/*     */   private static Map<String, String> param1;
/*     */   private static Map<String, String> param2;
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  37 */     System.out.println("##### BackLetter create program start");
/*     */     try
/*     */     {
/*  40 */       ConfigReader.init();
/*     */     } catch (Exception e) {
/*  42 */       System.out.println("##### read properties file error, file path:" + ConfigReader.class.getClassLoader().getResource(ConfigReader.CONFIG_PATH));
/*  43 */       e.printStackTrace();
/*  44 */       return;
/*     */     }
/*     */ 
/*  48 */     DbConnectionForOracle db = new DbConnectionForOracle(
/*  49 */       ConfigReader.read("db.ip"), 
/*  50 */       ConfigReader.read("db.port"), 
/*  51 */       ConfigReader.read("db.name"), 
/*  52 */       ConfigReader.read("db.user"), 
/*  53 */       ConfigReader.read("db.pwd"));
/*     */     try
/*     */     {
/*  57 */       config = initConfig(db);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */       Map config;
/*  59 */       e.printStackTrace();
/*  60 */       System.out.println("##### load db config error");
/*  61 */       db.close();
/*     */       return;
/*     */     }
/*     */     Map config;
/*  65 */     LogInit.init((String)config.get("LOG4J_COFIG_PATH"), 
/*  66 */       (String)config.get("LOG4J_FILENAME") + "letter.log");
/*     */ 
/*  68 */     param1 = checkParam((String)config.get("SMS_MODEL1"));
/*  69 */     param2 = checkParam((String)config.get("SMS_MODEL2"));
/*     */ 
/*  71 */     SMSWrite smsWriter1 = null;
/*  72 */     SMSWrite smsWriter2 = null;
/*     */     try
/*     */     {
/*  75 */       log.trace("创建文件开始.......");
/*  76 */       smsWriter1 = new SMSWrite(createFilePath((String)config.get("FTP_PATH"), (String)param1.get("filename")), 
/*  77 */         createFileName((String)config.get("FTP_PATH"), (String)param1.get("filename")));
/*  78 */       smsWriter2 = new SMSWrite(createFilePath((String)config.get("FTP_PATH"), (String)param2.get("filename")), 
/*  79 */         createFileName((String)config.get("FTP_PATH"), (String)param2.get("filename")));
/*  80 */       log.trace("读取数据开始......");
/*  81 */       process(db.getConnection(), smsWriter1, smsWriter2);
/*  82 */       log.trace("读取数据结束......");
/*     */ 
/*  84 */       if (smsWriter1.getIndex() > 0) {
/*  85 */         smsWriter1.createBackLetterFile(
/*  86 */           (String)param1.get("template"), 
/*  87 */           (String)param1.get("creator"), 
/*  88 */           "", 
/*  89 */           "", 
/*  90 */           sdf.format(Long.valueOf(System.currentTimeMillis())));
/*     */       }
/*     */ 
/*  93 */       if (smsWriter2.getIndex() > 0) {
/*  94 */         smsWriter2.createBackLetterFile(
/*  95 */           (String)param2.get("template"), 
/*  96 */           (String)param2.get("creator"), 
/*  97 */           "", 
/*  98 */           "", 
/*  99 */           sdf.format(Long.valueOf(System.currentTimeMillis())));
/*     */       }
/*     */ 
/* 102 */       log.trace("创建文件结束.....");
/*     */     } catch (Exception e) {
/* 104 */       e.printStackTrace();
/*     */ 
/* 106 */       db.close();
/*     */       try
/*     */       {
/* 109 */         smsWriter1.clearTempFile();
/* 110 */         smsWriter2.clearTempFile();
/*     */       } catch (Exception e) {
/* 112 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 106 */       db.close();
/*     */       try
/*     */       {
/* 109 */         smsWriter1.clearTempFile();
/* 110 */         smsWriter2.clearTempFile();
/*     */       } catch (Exception e) {
/* 112 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */ 
/* 116 */     System.out.println("##### program finish");
/* 117 */     System.exit(0);
/*     */   }
/*     */ 
/*     */   private static void process(Connection conn, SMSWrite smsWriter1, SMSWrite smsWriter2)
/*     */   {
/*     */     try
/*     */     {
/* 124 */       conn.setAutoCommit(false);
/*     */     } catch (SQLException e) {
/* 126 */       e.printStackTrace();
/* 127 */       log.error("设置数据库事务提交方法错误");
/* 128 */       return;
/*     */     }
/*     */ 
/* 131 */     List list = null;
/* 132 */     List updateList = null;
/*     */     try
/*     */     {
/* 135 */       int count = getDataCount(conn);
/* 136 */       int page = 0;
/* 137 */       if (count % number != 0)
/* 138 */         page = count / number + 1;
/*     */       else {
/* 140 */         page = count / number;
/*     */       }
/* 142 */       log.trace("总数:" + count + ",总页数:" + page);
/* 143 */       log.trace("写入数据开始......");
/*     */ 
/* 145 */       Record record = null;
/* 146 */       Iterator iter = null;
/* 147 */       int type = 0;
/* 148 */       String record_type = "";
/* 149 */       for (int i = 1; i <= page; i++)
/*     */       {
/* 151 */         updateList = new ArrayList();
/* 152 */         list = getDataForPage(conn, i);
/* 153 */         iter = list.iterator();
/* 154 */         while (iter.hasNext())
/*     */         {
/* 156 */           record = (Record)iter.next();
/* 157 */           record_type = record.getType();
/* 158 */           if ((record_type != null) && (!"".equals(record_type)))
/*     */           {
/* 161 */             type = Integer.parseInt(record_type);
/*     */ 
/* 163 */             if (((44 >= type) && (type >= 40)) || (type == 25))
/*     */             {
/* 165 */               log.trace("写入数据1:" + record.toString());
/* 166 */               smsWriter1.println(record, param1);
/* 167 */               updateList.add(record);
/*     */             }
/* 170 */             else if ((39 >= type) && (type >= 30)) {
/* 171 */               log.trace("用户编号:" + record.getAccount() + "  S_CUSTOMER_TYPE=30 to 39");
/*     */             }
/*     */             else {
/* 174 */               log.trace("写入数据2:" + record.toString());
/* 175 */               smsWriter2.println(record, null);
/* 176 */               updateList.add(record);
/*     */             }
/*     */           }
/*     */         }
/* 180 */         updateLetterState(conn, updateList);
/*     */       }
/* 182 */       log.trace("写入数据结束.....");
/*     */     } catch (SQLException e) {
/* 184 */       e.printStackTrace();
/*     */       try
/*     */       {
/* 189 */         if (updateList != null)
/* 190 */           updateLetterState(conn, updateList);
/*     */       } catch (SQLException e) {
/* 192 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 186 */       e.printStackTrace();
/*     */       try
/*     */       {
/* 189 */         if (updateList != null)
/* 190 */           updateLetterState(conn, updateList);
/*     */       } catch (SQLException e) {
/* 192 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 189 */         if (updateList != null)
/* 190 */           updateLetterState(conn, updateList);
/*     */       } catch (SQLException e) {
/* 192 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static int getDataCount(Connection conn)
/*     */     throws SQLException
/*     */   {
/* 204 */     Statement statement = null;
/*     */     try {
/* 206 */       statement = conn.createStatement();
/* 207 */       ResultSet result = statement.executeQuery("select count(1) from t_b_back_letter t1 where t1.c_state='0' and t1.s_code='0'");
/* 208 */       result.next();
/* 209 */       return result.getInt(1);
/*     */     } finally {
/* 211 */       if (statement != null)
/* 212 */         statement.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static List<Record> getDataForPage(Connection conn, int page)
/*     */     throws SQLException
/*     */   {
/* 219 */     String sql = "select *  from (select tt.*, rownum RN from (select t.*, rownum,ROWID as id from t_b_back_letter t where t.c_state='0' and t.s_code='0'  and rownum < ?) tt) where RN >= ?";
/*     */ 
/* 224 */     PreparedStatement statement = conn.prepareStatement(sql);
/* 225 */     statement.setInt(1, page * number);
/* 226 */     statement.setInt(2, (page - 1) * number);
/* 227 */     ResultSet result = statement.executeQuery();
/* 228 */     List list = new ArrayList();
/*     */ 
/* 230 */     while (result.next()) {
/* 231 */       String type = result.getString("S_CUSTOMER_TYPE");
/* 232 */       if (type != null) {
/* 233 */         Record record = new Record();
/* 234 */         record.setAccount(result.getString("S_ACCT"));
/* 235 */         record.setCustomer(result.getString("S_CUST_NBR"));
/* 236 */         record.setMobile(result.getString("S_MOBILE_NBR"));
/* 237 */         record.setName(result.getString("S_NAME"));
/* 238 */         record.setSex(result.getString("C_SEX"));
/* 239 */         record.setTelephone("");
/* 240 */         record.setRowId(result.getString("id"));
/* 241 */         record.setType(type);
/* 242 */         record.setStmt_date(result.getString("C_STMT_DATE"));
/* 243 */         list.add(record);
/*     */       } else {
/* 245 */         log.info("用户编号:" + result.getString("S_ACCT") + "  没有S_CUSTOMER_TYPE");
/*     */       }
/*     */     }
/* 248 */     return list;
/*     */   }
/*     */ 
/*     */   private static void updateLetterState(Connection conn, List<Record> list)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 263 */       statement = conn.prepareStatement("update t_b_back_letter t set t.C_STATE= 1 where ROWID = ?");
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/*     */       PreparedStatement statement;
/* 265 */       log.error("创建statement对象错误.");
/* 266 */       throw e;
/*     */     }
/*     */     PreparedStatement statement;
/* 269 */     if (log.isDebugEnabled())
/* 270 */       log.debug("待更新数据" + list.size() + "条");
/*     */     try {
/* 272 */       for (Record bl : list) {
/* 273 */         statement.setString(1, bl.getRowId());
/* 274 */         statement.addBatch();
/*     */       }
/* 276 */       statement.executeBatch();
/* 277 */       conn.commit();
/*     */ 
/* 279 */       if (log.isDebugEnabled())
/* 280 */         log.debug("更新完成，提交");
/*     */     } catch (SQLException e) {
/* 282 */       conn.rollback();
/* 283 */       log.error("更新错误，回滚");
/* 284 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static Map<String, String> initConfig(DbConnectionForOracle db)
/*     */     throws SQLException
/*     */   {
/* 321 */     Connection conn = db.getConnection();
/* 322 */     Map map = new HashMap();
/* 323 */     PreparedStatement statement = conn.prepareStatement("select * from t_s_bill_para t");
/* 324 */     ResultSet result = statement.executeQuery();
/* 325 */     while (result.next()) {
/* 326 */       map.put(result.getString("s_type"), result.getString("s_value"));
/*     */     }
/* 328 */     result.close();
/* 329 */     statement.close();
/* 330 */     return map;
/*     */   }
/*     */ 
/*     */   private static Map<String, String> checkParam(String param)
/*     */   {
/* 339 */     if (param == null) {
/* 340 */       return null;
/*     */     }
/* 342 */     String[] str = param.split("\\|");
/* 343 */     if (str.length < 4) {
/* 344 */       return null;
/*     */     }
/* 346 */     String model = str[0];
/* 347 */     String creator = str[1];
/* 348 */     String telephone = str[2];
/* 349 */     String filename = str[3];
/*     */ 
/* 352 */     if (model.length() != 5) {
/* 353 */       return null;
/*     */     }
/*     */ 
/* 356 */     if (creator.length() > 50) {
/* 357 */       return null;
/*     */     }
/*     */ 
/* 364 */     if (filename.length() == 0) {
/* 365 */       return null;
/*     */     }
/* 367 */     Map map = new HashMap();
/* 368 */     map.put("template", model);
/* 369 */     map.put("creator", creator);
/* 370 */     map.put("telephone", telephone);
/* 371 */     map.put("filename", filename);
/* 372 */     if (str.length > 4) {
/* 373 */       map.put("param5", str[4]);
/*     */     }
/* 375 */     if (str.length > 5) {
/* 376 */       map.put("param6", str[5]);
/*     */     }
/* 378 */     if (str.length > 6) {
/* 379 */       map.put("param7", str[6]);
/*     */     }
/* 381 */     if (str.length > 7) {
/* 382 */       map.put("param8", str[7]);
/*     */     }
/* 384 */     return map;
/*     */   }
/*     */ 
/*     */   private static String createFileName(String path, String nameTemplet)
/*     */   {
/* 394 */     nameTemplet = nameTemplet.replace("{date}", sdf.format(Long.valueOf(System.currentTimeMillis())));
/* 395 */     File file = new File(path + File.separator + File.separator + nameTemplet);
/* 396 */     if (!file.exists()) {
/* 397 */       file.getParentFile().mkdirs();
/*     */     }
/* 399 */     nameTemplet = file.getName();
/*     */ 
/* 401 */     int index = nameTemplet.indexOf("{sequence}");
/* 402 */     if (index != -1) {
/* 403 */       String temp = nameTemplet.substring(0, index);
/* 404 */       String[] arr = file.getParentFile().list();
/* 405 */       int seq = 1;
/* 406 */       for (int i = 0; i < arr.length; i++) {
/* 407 */         if ((arr[i].indexOf(temp) != -1) && (!arr[i].contains("_CK"))) {
/* 408 */           seq++;
/*     */         }
/*     */       }
/* 411 */       nameTemplet = nameTemplet.replace("{sequence}", "%03d");
/* 412 */       nameTemplet = String.format(nameTemplet, new Object[] { Integer.valueOf(seq) });
/*     */     }
/* 414 */     return nameTemplet;
/*     */   }
/*     */ 
/*     */   private static String createFilePath(String path, String nameTemplet)
/*     */   {
/* 424 */     nameTemplet = nameTemplet.replace("{date}", sdf.format(Long.valueOf(System.currentTimeMillis())));
/* 425 */     File file = new File(path + File.separator + File.separator + nameTemplet);
/* 426 */     if (!file.exists()) {
/* 427 */       file.getParentFile().mkdirs();
/*     */     }
/* 429 */     return file.getParentFile().getPath();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     com.bill.letter.BackLetterFile
 * JD-Core Version:    0.6.2
 */