/*     */ package test;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.db.DbConnectionForOracle;
/*     */ import com.bill.util.LogInit;
/*     */ import com.bill.util.config.ConfigReader;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class CheckTimer
/*     */ {
/*     */   private static Logger log;
/*  18 */   private static String period = "";
/*     */   private static DbConnectionForOracle dbconn;
/*     */   private static PreparedStatement statement;
/*     */   private static ResultSet result;
/*  22 */   private static String sql = "";
/*  23 */   private static boolean check_pass = false;
/*     */ 
/*  25 */   public static void main(String[] args) { String checkTime = "";
/*     */     try {
/*  27 */       ConfigReader.init();
/*  28 */       BaseParam.DB_IP = ConfigReader.read("db.ip");
/*  29 */       BaseParam.DB_PORT = ConfigReader.read("db.port");
/*  30 */       BaseParam.DB_NAME = ConfigReader.read("db.name");
/*  31 */       BaseParam.DB_USER = ConfigReader.read("db.user");
/*  32 */       BaseParam.DB_PWD = ConfigReader.read("db.pwd");
/*     */ 
/*  34 */       dbconn = new DbConnectionForOracle(BaseParam.DB_IP, BaseParam.DB_PORT, BaseParam.DB_NAME, BaseParam.DB_USER, BaseParam.DB_PWD);
/*     */ 
/*  36 */       statement = dbconn.getConnection().prepareStatement("select t.s_value,t.s_type from t_s_bill_para t");
/*  37 */       result = statement.executeQuery();
/*  38 */       String temp = "";
/*  39 */       String logcofing = "";
/*  40 */       String logfile = "";
/*  41 */       while (result.next()) {
/*  42 */         temp = result.getString("s_type");
/*  43 */         if ("CHECK_TIME".equals(temp))
/*  44 */           checkTime = result.getString("s_value");
/*  45 */         else if ("PERIOD".equals(temp))
/*  46 */           period = result.getString("s_value");
/*  47 */         else if ("LOG4J_COFIG_PATH".equals(temp)) {
/*  48 */           logcofing = result.getString("s_value");
/*     */         }
/*  50 */         else if ("LOG4J_FILENAME".equals(temp)) {
/*  51 */           logfile = result.getString("s_value");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*  56 */       LogInit.init(logcofing, logfile + "check.log");
/*  57 */       log = Logger.getLogger(CheckTimer.class);
/*  58 */       result.close();
/*  59 */       statement.close();
/*     */ 
/*  61 */       setup_check_watch_begin();
/*     */ 
/*  63 */       check_templet();
/*  64 */       log.debug("验证模版:" + check_pass);
/*     */ 
/*  66 */       if (check_pass) {
/*  67 */         check_rule();
/*  68 */         log.debug("规则验证:" + check_pass);
/*     */       }
/*     */ 
/*  71 */       if (check_pass) {
/*  72 */         check_paper();
/*  73 */         log.debug("预印纸验证:" + check_pass);
/*     */       }
/*     */ 
/*  76 */       if (check_pass) {
/*  77 */         check_vdata();
/*  78 */         log.debug("V+数据验证:" + check_pass);
/*     */       }
/*     */ 
/*  81 */       if (check_pass) {
/*  82 */         check_point();
/*  83 */         log.debug("积分数据验证:" + check_pass);
/*     */       }
/*  85 */       if (check_pass) {
/*  86 */         setup_check_pass();
/*  87 */         log.debug("设置验证通过标志！");
/*     */ 
/*  89 */         setup_city();
/*  90 */         log.debug("一键设置城市完毕！");
/*     */       }
/*  92 */       log.debug("设置自动验证结束标志！");
/*     */ 
/*  94 */       setup_check_watch_end();
/*     */     }
/*     */     catch (Exception e) {
/*  97 */       e.printStackTrace();
/*  98 */       System.exit(-1);
/*     */     }
/*     */ 
/* 101 */     int i_time = 0;
/* 102 */     if ((checkTime != null) && (!"".equals(checkTime))) {
/* 103 */       i_time = Integer.parseInt(checkTime);
/*     */     } else {
/* 105 */       log.error("查询数据检查扫描时间失败！");
/* 106 */       return;
/*     */     }
/* 108 */     log.debug("开始数据检查扫描！扫描间隔=" + i_time);
/* 109 */     Timer timer = new Timer();
/* 110 */     timer.schedule(new MyTask(), 1000L, i_time);
/*     */   }
/*     */ 
/*     */   public static void check_templet()
/*     */     throws SQLException
/*     */   {
/* 143 */     log.debug("模版验证开始，不验证动态账单！");
/* 144 */     sql = "SELECT t.s_buss_prod_id AS cardid, t.s_buss_prod_name AS cardname,'2' as type  FROM t_s_busi_prod_info t WHERE t.c_buss_state = '1'   AND t.c_buss_prod_flag = '0'   AND t.c_buss_type_id='001'   AND t.s_buss_prod_id NOT IN       (SELECT s_card_prod_id                  FROM t_s_stencil                 WHERE c_state = '1'               AND (C_TYPE_NO = '2'  OR C_TYPE_NO = '3')                 GROUP BY s_card_prod_id) union all SELECT t.s_buss_prod_id AS cardid, t.s_buss_prod_name AS cardname,'1' as type  FROM t_s_busi_prod_info t WHERE t.c_buss_state = '1'   AND t.c_buss_prod_flag = '0'   AND t.c_buss_type_id='001'   AND t.s_buss_prod_id NOT IN       (SELECT s_card_prod_id                  FROM t_s_stencil                 WHERE c_state = '1'               AND (C_TYPE_NO = '1'  OR C_TYPE_NO = '3')                 GROUP BY s_card_prod_id)";
/*     */ 
/* 167 */     log.debug(sql);
/* 168 */     statement = dbconn.getConnection().prepareStatement(sql);
/* 169 */     result = statement.executeQuery();
/*     */ 
/* 171 */     check_pass = true;
/* 172 */     while (result.next()) {
/* 173 */       check_pass = false;
/* 174 */       log.debug("模版验证错误！");
/*     */     }
/* 176 */     if (check_pass) {
/* 177 */       log.debug("模版验证通过，不验证动态账单！");
/*     */     }
/* 179 */     result.close();
/* 180 */     statement.close();
/*     */   }
/*     */ 
/*     */   public static void check_rule() throws SQLException {
/* 184 */     log.debug("规则开始！");
/* 185 */     sql = "SELECT *  FROM (SELECT p.s_buss_prod_name,               t.s_stencil_no,               t.s_stencil_name,               r.i_area_no,               r.s_area_name          FROM T_S_AREA r, T_S_STENCIL t, T_S_BUSI_PROD_INFO p         WHERE p.C_BUSS_PROD_FLAG = '0'           AND p.C_BUSS_STATE = '1'           AND p.C_BUSS_TYPE_ID = '001'           AND t.c_state = '1'           AND R.S_STENCIL_NO = t.s_stencil_no           AND t.s_card_prod_id = p.s_buss_prod_id) pp WHERE (SELECT count(1)          FROM T_S_RULE_M         WHERE I_AREA_NO = pp.I_AREA_NO           AND C_STATE = '1'           AND C_RULE_TYPE = '0'           AND S_STENCIL_NO = pp.S_STENCIL_NO           AND substr(get_current_date,0,7) BETWEEN C_PERIOD_BEGEN AND C_PERIOD_END           AND S_PERIOD LIKE '%' || substr(get_current_date,9) || '%') = 0";
/*     */ 
/* 207 */     log.debug(sql);
/*     */ 
/* 209 */     statement = dbconn.getConnection().prepareStatement(sql);
/* 210 */     result = statement.executeQuery();
/* 211 */     check_pass = true;
/* 212 */     if (result.next()) {
/* 213 */       check_pass = false;
/* 214 */       log.debug("规则验证错误！");
/*     */     }
/*     */ 
/* 217 */     if (check_pass) {
/* 218 */       check_pass = true;
/* 219 */       log.debug("规则验证通过！");
/*     */     }
/* 221 */     result.close();
/* 222 */     statement.close();
/*     */   }
/*     */ 
/*     */   public static void check_paper() throws SQLException {
/* 226 */     log.debug("预印纸开始！");
/*     */ 
/* 228 */     sql = "select count(1)     From t_s_befor_print_basic t    where t.c_period_day = substr(get_current_date,9)      and substr(get_current_date,0,7) between t.c_period_begen and t.c_period_end";
/*     */ 
/* 232 */     statement = dbconn.getConnection().prepareStatement(sql);
/* 233 */     result = statement.executeQuery();
/* 234 */     while (result.next()) {
/* 235 */       if (result.getInt(1) == 0) {
/* 236 */         check_pass = false;
/* 237 */         log.debug("预印纸验证错误！没有设置预印纸！");
/*     */       }
/*     */     }
/* 240 */     result.close();
/* 241 */     statement.close();
/* 242 */     if (!check_pass) {
/* 243 */       return;
/*     */     }
/*     */ 
/* 247 */     sql = "select count(1) from ((select a.s_city_no, a.s_card_no  From t_s_bfpnt_cty_crdtp a where a.s_id = '0'   and a.s_card_no in(            select card.s_buss_prod_id from t_s_busi_prod_info card             where card.c_buss_type_id='001'               and card.c_buss_state = '1'               and card.c_buss_prod_flag = '0')   and a.s_businpnt_no <> '0') minus   (select r.s_city_no, r.s_card_no      From t_s_bfpnt_cty_crdtp r     where r.s_id in (select t.s_id                        From t_s_befor_print_basic t                       where t.c_period_day = substr(get_current_date, 9)                         and substr(get_current_date,0,7)    between t.c_period_begen and t.c_period_end)        and r.s_card_no in(select card.s_buss_prod_id from t_s_busi_prod_info card                            where card.c_buss_type_id='001'                              and card.c_buss_state = '1'                              and card.c_buss_prod_flag = '0'))) S,       t_s_city city,       t_s_busi_prod_info card where S.s_city_no = city.s_city_no   and S.s_card_no = card.s_buss_prod_id";
/*     */ 
/* 271 */     log.debug(sql);
/* 272 */     statement = dbconn.getConnection().prepareStatement(sql);
/* 273 */     result = statement.executeQuery();
/* 274 */     while (result.next()) {
/* 275 */       if (result.getInt(1) == 0) {
/* 276 */         check_pass = true;
/* 277 */         log.debug("预印纸验证通过！");
/*     */       } else {
/* 279 */         check_pass = false;
/* 280 */         log.debug("预印纸验证错误！");
/*     */       }
/*     */     }
/* 283 */     result.close();
/* 284 */     statement.close();
/*     */   }
/*     */ 
/*     */   public static void check_vdata() throws SQLException {
/* 288 */     log.debug("V+数据验证开始！");
/* 289 */     sql = "SELECT COUNT(1) FROM T_S_CHECK_V_DATA t";
/* 290 */     statement = dbconn.getConnection().prepareStatement(sql);
/* 291 */     result = statement.executeQuery();
/* 292 */     while (result.next()) {
/* 293 */       if (result.getInt(1) == 0) {
/* 294 */         check_pass = true;
/* 295 */         log.debug("V+数据验证通过！");
/*     */       } else {
/* 297 */         check_pass = false;
/* 298 */         log.debug("V+数据验证错误！");
/*     */       }
/*     */     }
/* 301 */     result.close();
/* 302 */     statement.close();
/*     */   }
/*     */ 
/*     */   public static void check_point() throws SQLException {
/* 306 */     log.debug("积分数据验证开始！");
/* 307 */     sql = "SELECT COUNT(1) FROM T_S_CHECK_POINT t";
/* 308 */     statement = dbconn.getConnection().prepareStatement(sql);
/* 309 */     result = statement.executeQuery();
/* 310 */     while (result.next()) {
/* 311 */       if (result.getInt(1) == 0) {
/* 312 */         check_pass = true;
/* 313 */         log.debug("积分数据验证通过！");
/*     */       } else {
/* 315 */         check_pass = false;
/* 316 */         log.debug("积分数据验证错误！");
/*     */       }
/*     */     }
/* 319 */     result.close();
/* 320 */     statement.close();
/*     */   }
/*     */ 
/*     */   public static void setup_check_pass() throws SQLException {
/* 324 */     sql = "delete T_S_CHECK t where t.S_TYPE='ALLREADY' and t.S_PERIOD=(select S_VALUE from t_s_bill_para where s_type='PERIOD')";
/* 325 */     statement = dbconn.getConnection().prepareStatement(sql);
/* 326 */     statement.executeUpdate();
/* 327 */     statement.close();
/*     */ 
/* 329 */     log.debug("设置所有验证通过！");
/* 330 */     sql = "insert into T_S_CHECK(S_TYPE,C_STATE,S_PERIOD) values('ALLREADY','1',(select S_VALUE from t_s_bill_para where s_type='PERIOD'))";
/* 331 */     statement = dbconn.getConnection().prepareStatement(sql);
/* 332 */     int i = statement.executeUpdate();
/* 333 */     if (i > 0) {
/* 334 */       log.debug("设置所有验证通过成功！");
/*     */     }
/* 336 */     result.close();
/* 337 */     statement.close();
/*     */   }
/*     */ 
/*     */   public static void setup_check_watch_begin() throws SQLException {
/* 341 */     log.debug("设置监听开始！");
/* 342 */     sql = "update T_S_WATCH t set  t.C_STATE='1',t.c_start_time=to_char(sysdate,'yyyy-MM-dd hh24:mi:ss')  where t.i_id=9";
/* 343 */     statement = dbconn.getConnection().prepareStatement(sql);
/* 344 */     int i = statement.executeUpdate();
/* 345 */     if (i > 0) {
/* 346 */       log.debug("设置监听开始成功！");
/*     */     }
/* 348 */     result.close();
/* 349 */     statement.close();
/*     */   }
/*     */ 
/*     */   public static void setup_check_watch_end() throws SQLException {
/* 353 */     log.debug("设置监听结束！");
/* 354 */     sql = "update T_S_WATCH t set  t.C_STATE=?,t.c_end_time=to_char(sysdate,'yyyy-MM-dd hh24:mi:ss')  where t.i_id=9";
/* 355 */     statement = dbconn.getConnection().prepareStatement(sql);
/* 356 */     if (check_pass)
/* 357 */       statement.setString(1, "2");
/*     */     else {
/* 359 */       statement.setString(1, "3");
/*     */     }
/* 361 */     int i = statement.executeUpdate();
/* 362 */     if (i > 0) {
/* 363 */       log.debug("设置监听结束成功！");
/*     */     }
/* 365 */     result.close();
/* 366 */     statement.close();
/*     */   }
/*     */ 
/*     */   public static void setup_city() throws SQLException
/*     */   {
/* 371 */     log.debug("一键设置城市开始！");
/* 372 */     sql = "update T_B_CUSTOMER_BILL b\tset b.S_CITY_ID = '9999', b.S_CITY_NAME = '其他城市' WHERE (select count(1)          from T_S_BFPNT_CTY_CRDTP c         where c.s_city_no = b.s_city_id           and c.s_card_no = b.s_card_prod_id           and c.s_businpnt_no > '0'           and c.s_id = '0') = 0";
/*     */ 
/* 380 */     statement = dbconn.getConnection().prepareStatement(sql);
/* 381 */     int i = statement.executeUpdate();
/* 382 */     log.debug("共设置" + i + "条数据！");
/* 383 */     result.close();
/* 384 */     statement.close();
/*     */   }
/*     */ 
/*     */   static class MyTask extends TimerTask
/*     */   {
/*     */     public void run()
/*     */     {
/* 115 */       String state = "";
/*     */       try
/*     */       {
/* 118 */         CheckTimer.dbconn = new DbConnectionForOracle(BaseParam.DB_IP, BaseParam.DB_PORT, BaseParam.DB_NAME, BaseParam.DB_USER, BaseParam.DB_PWD);
/*     */ 
/* 120 */         CheckTimer.statement = CheckTimer.dbconn.getConnection().prepareStatement("select t.c_state from t_s_check t where t.s_type='ALLREADY' and t.S_PERIOD=?");
/* 121 */         CheckTimer.statement.setString(1, CheckTimer.period);
/* 122 */         CheckTimer.result = CheckTimer.statement.executeQuery();
/* 123 */         while (CheckTimer.result.next()) {
/* 124 */           state = CheckTimer.result.getString("c_state");
/*     */         }
/* 126 */         CheckTimer.result.close();
/* 127 */         CheckTimer.statement.close();
/* 128 */         CheckTimer.dbconn.close();
/* 129 */         if ("1".equals(state)) {
/* 130 */           CheckTimer.log.debug("数据检查扫描！检查完毕！扫描时间=" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Long.valueOf(System.currentTimeMillis())));
/* 131 */           System.exit(0);
/*     */         } else {
/* 133 */           CheckTimer.log.debug("数据检查扫描！检查未完毕！扫描时间=" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Long.valueOf(System.currentTimeMillis())));
/*     */         }
/*     */       } catch (Exception e) {
/* 136 */         e.printStackTrace();
/* 137 */         System.exit(-1);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     test.CheckTimer
 * JD-Core Version:    0.6.2
 */