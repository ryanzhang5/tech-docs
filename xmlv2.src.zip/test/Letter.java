/*     */ package test;
/*     */ 
/*     */ import com.bill.bean.BaseParam;
/*     */ import com.bill.db.DbConnectionForOracle;
/*     */ import com.bill.makeXML.util.LogInit;
/*     */ import com.bill.util.config.ConfigReader;
/*     */ import java.io.File;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class Letter
/*     */ {
/*     */   private static Logger log;
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  26 */     List letterList = new ArrayList();
/*     */     try
/*     */     {
/*  32 */       ConfigReader.init();
/*  33 */       BaseParam.DB_IP = ConfigReader.read("db.ip");
/*  34 */       BaseParam.DB_PORT = ConfigReader.read("db.port");
/*  35 */       BaseParam.DB_NAME = ConfigReader.read("db.name");
/*  36 */       BaseParam.DB_USER = ConfigReader.read("db.user");
/*  37 */       BaseParam.DB_PWD = ConfigReader.read("db.pwd");
/*     */ 
/*  39 */       DbConnectionForOracle dbconn = new DbConnectionForOracle(BaseParam.DB_IP, BaseParam.DB_PORT, BaseParam.DB_NAME, BaseParam.DB_USER, BaseParam.DB_PWD);
/*     */ 
/*  41 */       PreparedStatement statement = dbconn.getConnection().prepareStatement("select t.s_value,t.s_type from t_s_bill_para t");
/*  42 */       ResultSet result = statement.executeQuery();
/*  43 */       String temp = "";
/*  44 */       String logcofing = "";
/*  45 */       String logfile = "";
/*  46 */       while (result.next())
/*     */       {
/*  48 */         if ("LOG4J_COFIG_PATH".equals(temp)) {
/*  49 */           logcofing = result.getString("s_value");
/*     */         }
/*  51 */         else if ("LOG4J_FILENAME".equals(temp)) {
/*  52 */           logfile = result.getString("s_value");
/*     */         }
/*     */       }
/*     */ 
/*  56 */       LogInit.init(logcofing, logfile + "letter.log");
/*  57 */       log = Logger.getLogger(CheckTimer.class);
/*     */ 
/*  59 */       statement = dbconn.getConnection().prepareStatement("select * from t_b_back_letter t1 where t1.c_state='0'");
/*  60 */       result = statement.executeQuery();
/*  61 */       while (result.next()) {
/*  62 */         Map letterMap = new HashMap();
/*  63 */         letterMap.put("MOBILE", result.getString("S_MOBILE_NBR"));
/*  64 */         letterMap.put("CTYPE", result.getString("S_CUSTOMER_TYPE"));
/*  65 */         letterMap.put("STMTDATE", result.getString("C_STMT_DATE"));
/*  66 */         letterList.add(letterMap);
/*     */       }
/*  68 */       statement.close();
/*  69 */       result.close();
/*     */ 
/*  71 */       statement = dbconn.getConnection().prepareStatement("select * from t_s_bill_para t");
/*  72 */       result = statement.executeQuery();
/*  73 */       Map configMap = new HashMap();
/*  74 */       while (result.next()) {
/*  75 */         configMap.put(result.getString("s_type"), result.getString("s_value"));
/*     */       }
/*  77 */       statement.close();
/*  78 */       result.close();
/*     */ 
/*  85 */       String path = (String)configMap.get("BASEPATH");
/*  86 */       File file = new File(path + "LETTER");
/*     */ 
/*  88 */       if (!file.exists()) {
/*  89 */         file.mkdirs();
/*     */       }
/*     */ 
/*  92 */       file = new File(path + "LETTER/letter_" + System.currentTimeMillis() + ".txt");
/*  93 */       file.createNewFile();
/*     */ 
/*  95 */       RandomAccessFile filew = new RandomAccessFile(file.getPath(), "rw");
/*  96 */       String notsend = (String)configMap.get("LETTER_NOT_SEND");
/*  97 */       String sendyzt = (String)configMap.get("LETTER_YZT_SEND");
/*  98 */       String sms = "";
/*  99 */       for (Map map : letterList)
/*     */       {
/* 101 */         if (notsend.indexOf((String)map.get("CTYPE")) == -1)
/*     */         {
/* 105 */           if (sendyzt.indexOf((String)map.get("CTYPE")) >= 0)
/*     */           {
/* 107 */             sms = (String)configMap.get("LETTER_YZT_MSG");
/*     */           }
/*     */           else {
/* 110 */             sms = (String)configMap.get("LETTER_XYK_MSG");
/*     */           }
/*     */ 
/* 113 */           sms = (String)map.get("S_MOBILE_NBR") + "|$|" + sms.replace("[$1$]", ((String)map.get("STMTDATE")).substring(4, 6)) + "\n";
/*     */ 
/* 115 */           filew.write(sms.getBytes("gbk"));
/*     */         }
/*     */       }
/* 117 */       filew.close();
/* 118 */       dbconn.close();
/*     */     } catch (Exception e) {
/* 120 */       e.printStackTrace();
/*     */     }
/* 122 */     System.exit(0);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     test.Letter
 * JD-Core Version:    0.6.2
 */