/*    */ package test;
/*    */ 
/*    */ import com.bill.bean.Card;
/*    */ import com.bill.makeXML.util.LogInit;
/*    */ import com.bill.teshuXML.Cache;
/*    */ import com.bill.teshuXML.TeshuHandler;
/*    */ import com.bill.util.config.ConfigReader;
/*    */ 
/*    */ public class teshu
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/*    */     try
/*    */     {
/* 17 */       ConfigReader.init();
/* 18 */       LogInit.init(ConfigReader.read("log.path") + "teshu.log");
/* 19 */       com.bill.bean.BaseParam.PERIOD = ConfigReader.read("make.xml.stmtdate");
/* 20 */       com.bill.bean.BaseParam.XML_PATH = ConfigReader.read("make.xml.basestorpath");
/* 21 */       com.bill.bean.BaseParam.DB_IP = ConfigReader.read("db.ip");
/* 22 */       com.bill.bean.BaseParam.DB_PORT = ConfigReader.read("db.port");
/* 23 */       com.bill.bean.BaseParam.DB_NAME = ConfigReader.read("db.name");
/* 24 */       com.bill.bean.BaseParam.DB_USER = ConfigReader.read("db.user");
/* 25 */       com.bill.bean.BaseParam.DB_PWD = ConfigReader.read("db.pwd");
/*    */     } catch (Exception e) {
/* 27 */       e.printStackTrace();
/*    */     }
/* 29 */     Cache.init();
/*    */ 
/* 31 */     for (Card c : Cache.cardList) {
/* 32 */       TeshuHandler ub = new TeshuHandler(c.getId(), c.getType(), c.getName());
/* 33 */       ub.handler();
/*    */     }
/* 35 */     Cache.colse();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     test.teshu
 * JD-Core Version:    0.6.2
 */