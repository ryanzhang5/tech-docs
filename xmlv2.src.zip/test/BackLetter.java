/*    */ package test;
/*    */ 
/*    */ import com.bill.letter.BackLetterFile;
/*    */ 
/*    */ public class BackLetter
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 12 */     BackLetterFile.main(args);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     test.BackLetter
 * JD-Core Version:    0.6.2
 */