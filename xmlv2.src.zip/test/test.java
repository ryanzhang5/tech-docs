/*   */ package test;
/*   */ 
/*   */ import java.io.PrintStream;
/*   */ 
/*   */ public class test
/*   */ {
/*   */   public static void main(String[] args)
/*   */   {
/* 9 */     System.out.println("2029-01-05".substring(8, 10));
/*   */   }
/*   */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     test.test
 * JD-Core Version:    0.6.2
 */