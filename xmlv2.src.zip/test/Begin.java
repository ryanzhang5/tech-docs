/*    */ package test;
/*    */ 
/*    */ import com.bill.bean.Card;
/*    */ import com.bill.makeXML.cache.Cache;
/*    */ import com.bill.makeXML.handler.XmlHandler;
/*    */ import com.bill.makeXML.util.LogInit;
/*    */ import com.bill.util.config.ConfigReader;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class Begin
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/*    */     try
/*    */     {
/* 18 */       ConfigReader.init();
/* 19 */       com.bill.bean.BaseParam.DB_IP = ConfigReader.read("db.ip");
/* 20 */       com.bill.bean.BaseParam.DB_PORT = ConfigReader.read("db.port");
/* 21 */       com.bill.bean.BaseParam.DB_NAME = ConfigReader.read("db.name");
/* 22 */       com.bill.bean.BaseParam.DB_USER = ConfigReader.read("db.user");
/* 23 */       com.bill.bean.BaseParam.DB_PWD = ConfigReader.read("db.pwd");
/*    */     } catch (Exception e) {
/* 25 */       e.printStackTrace();
/*    */     }
/* 27 */     Cache.init();
/* 28 */     Cache.begin();
/*    */ 
/* 30 */     LogInit.init((String)Cache.configMap.get("LOG4J_FILENAME") + "make.log");
/* 31 */     for (Card c : Cache.cardList) {
/* 32 */       new XmlHandler(c.getId(), c.getType()).handler();
/*    */     }
/* 34 */     Cache.end("1");
/* 35 */     Cache.colse();
/* 36 */     System.exit(0);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     test.Begin
 * JD-Core Version:    0.6.2
 */