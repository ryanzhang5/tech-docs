/*    */ package test;
/*    */ 
/*    */ import com.bill.make.LogInit;
/*    */ import com.bill.reprintXML.Cache;
/*    */ import com.bill.reprintXML.ReprintHandler;
/*    */ import com.bill.util.config.ConfigReader;
/*    */ import java.io.PrintStream;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class reprint
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 13 */     String sb = 
/* 14 */       "select S_POINT_TYPE,S_ACCT_PROD_ID,S_BUSINESS_ID,I_ABLE_POINT,I_LASTBAL_POINT,I_ADDPOINT_POINT,I_EXPOINT_POINT,I_ADPOINTS_POINT,I_ENDPOINTS_POINT,S_ECIF_NO,S_START_DATE,S_END_DATE,to_char(I_WHOLE_CONSUME,'fm99999990.00') as I_WHOLE_CONSUME,to_char(I_IN_CONSUME,'fm99999990.00') as I_IN_CONSUME,to_char(I_OUT_CONSUME,'fm99999990.00') as I_OUT_CONSUME,to_char(I_WHOLE_MONEY,'fm99999990.00') as I_WHOLE_MONEY,to_char(I_IN_MONEY,'fm99999990.00') as I_IN_MONEY,to_char(I_OUT_MONEY,'fm99999990.00') as I_OUT_MONEY,to_char(I_USED_MONEY,'fm99999990.00') as I_USED_MONEY,to_char(I_LAVE_MONEY,'fm99999990.00') as I_LAVE_MONEY,S_VALID_DATE,I_LADDER_MONEY,S_LADDER_SCALE,C_CARD_LAST4,C_CARD_POINT_TYPE,S_CARD_POINT_NAME from t_b_point_x where S_BUSINESS_ID=? and C_STMT_DATE=?";
/*    */ 
/* 22 */     System.out.println(sb);
/*    */     try
/*    */     {
/* 25 */       ConfigReader.init();
/*    */     } catch (Exception e) {
/* 27 */       System.out.println("##### read properties file error, file path:" + ConfigReader.class.getClassLoader().getResource(ConfigReader.CONFIG_PATH));
/* 28 */       e.printStackTrace();
/* 29 */       return;
/*    */     }
/*    */ 
/* 32 */     com.bill.bean.BaseParam.DB_IP = ConfigReader.read("db.ip");
/* 33 */     com.bill.bean.BaseParam.DB_PORT = ConfigReader.read("db.port");
/* 34 */     com.bill.bean.BaseParam.DB_NAME = ConfigReader.read("db.name");
/* 35 */     com.bill.bean.BaseParam.DB_USER = ConfigReader.read("db.user");
/* 36 */     com.bill.bean.BaseParam.DB_PWD = ConfigReader.read("db.pwd");
/*    */ 
/* 38 */     System.out.println("##### load config cache data");
/*    */ 
/* 41 */     Cache.init();
/*    */ 
/* 44 */     LogInit.init((String)Cache.configMap.get("LOG4J_COFIG_PATH"), (String)Cache.configMap.get("LOG4J_FILENAME") + "reprintxml.log");
/*    */ 
/* 47 */     ReprintHandler rh = new ReprintHandler();
/* 48 */     rh.handler();
/* 49 */     Cache.colse();
/* 50 */     System.out.println("##### program finish");
/* 51 */     System.exit(0);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\tttt\xmlv2.jar
 * Qualified Name:     test.reprint
 * JD-Core Version:    0.6.2
 */