#! /bin/sh

CORELIB_MAJOR=2
CORELIB_MINOR=5
CORELIB_PATCHREV=0

usage() {
    echo
    echo "Usage: $0 <OPTION>"
    echo "OPTION can be one of '--full-version', '--major', '--minor' or '--patchrev'"
    echo
    echo "To suppress the trailing newline (for src/configure.ac), you can also use"
    echo "the --noeol option"
    echo
}

if test "$#" -eq 0; then
    usage
    exit 1
fi

# By default print out a newline, override this
eol="\n"

# Loop through our args
while test "$#" -gt 0; do

    option="$1"
    shift

    case "${option}" in

        --full-version)
            printf ${CORELIB_MAJOR}.${CORELIB_MINOR}.${CORELIB_PATCHREV}
            ;;

        --major)
            printf ${CORELIB_MAJOR}
            ;;

        --minor)
            printf ${CORELIB_MINOR}
            ;;

        --patchrev)
            printf ${CORELIB_PATCHREV}
            ;;

        --noeol)
            eol=""
            ;;

        --help)
            usage
            ;;

        *)
            echo
            echo "Unknown option[${option}]"
            usage
            exit 1
            ;;
    esac
done

printf "${eol}"
