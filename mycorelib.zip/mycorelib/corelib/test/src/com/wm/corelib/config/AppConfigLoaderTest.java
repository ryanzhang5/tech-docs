/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.config;

import junit.framework.TestCase;

import java.util.List;
import java.util.ArrayList;

import com.wm.corelib.io.Resource;
import com.wm.corelib.io.ClassPathResource;

/**
 * AppConfigLoaderTest
 *
 * @author mkishore
 * @since 2.5.2
 */
public class AppConfigLoaderTest extends TestCase {

    private Resource newCPR(String path) {
        ClassPathResource resource = new ClassPathResource();
        resource.setPath(path);
        return resource;
    }

    public void testSingleLoader() {
        List<PropertiesLoader> list = new ArrayList<PropertiesLoader>();
        SimpleLoader sl = new SimpleLoader();
        sl.setFile(newCPR("com/wm/corelib/config/app.conf"));
        list.add(sl);

        AppConfigLoader loader = new AppConfigLoader();
        loader.setPropertiesLoaders(list);
        AppConfig appConfig = loader.load();

        assertEquals("pass", appConfig.get("simple.loader"));
        assertEquals("fail", appConfig.get("hierarchical.loader"));

        // check that we do not update the singleton instance by default
        assertEquals("missing", AppConfig.getInstance().getProperty("simple.loader", "missing"));
    }

    public void testSingletonInitialization() {
        List<PropertiesLoader> list = new ArrayList<PropertiesLoader>();
        SimpleLoader sl = new SimpleLoader();
        sl.setFile(newCPR("com/wm/corelib/config/app.conf"));
        list.add(sl);

        AppConfigLoader loader = new AppConfigLoader();
        loader.setPropertiesLoaders(list);
        loader.setInitializeSingleton(true);
        AppConfig appConfig = loader.load();

        assertEquals("pass", appConfig.get("simple.loader"));
        assertEquals("fail", appConfig.get("hierarchical.loader"));

        // check that we do update the singleton instance - if asked to
        assertEquals("pass", AppConfig.getInstance().getProperty("simple.loader", "missing"));
    }

    public void testMultipleLoaders() {
        List<PropertiesLoader> list = new ArrayList<PropertiesLoader>();
        SimpleLoader sl = new SimpleLoader();
        sl.setFile(newCPR("com/wm/corelib/config/app.conf"));
        list.add(sl);
        sl = new SimpleLoader();
        sl.setFile(newCPR("com/wm/corelib/config/hierarchical/app.conf"));
        list.add(sl);

        AppConfigLoader loader = new AppConfigLoader();
        loader.setPropertiesLoaders(list);
        AppConfig appConfig = loader.load();

        assertEquals("pass", appConfig.get("simple.loader"));
        assertEquals("pass", appConfig.get("hierarchical.loader"));
    }

}
