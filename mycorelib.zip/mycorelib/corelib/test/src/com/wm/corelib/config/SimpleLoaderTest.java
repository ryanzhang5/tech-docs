/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.config;

import junit.framework.TestCase;

import java.util.Properties;

import com.wm.corelib.io.Resource;
import com.wm.corelib.io.ClassPathResource;

/**
 * SimpleLoaderTest
 *
 * @author mkishore
 * @since 2.5.2
 */
public class SimpleLoaderTest extends TestCase {

    private Resource newCPR(String path) {
        ClassPathResource resource = new ClassPathResource();
        resource.setPath(path);
        return resource;
    }

    public void testBasicLoad() {
        SimpleLoader loader = new SimpleLoader();
        loader.setFile(newCPR("com/wm/corelib/config/app.conf"));
        Properties props = loader.load();
        assertEquals("pass", props.getProperty("simple.loader"));
    }

    public void testIncorrectPath() {
        SimpleLoader loader = new SimpleLoader();
        loader.setFile(newCPR("com/wm/corelib/config/missing-file"));
        Properties props = loader.load();
        // should just log it and return an empty properties object 
        assertTrue(props.isEmpty());
    }

    /*
    Not sure how to make the filesystem path portable!!
    
    public void testLoadFromFileSystem() {
        SimpleLoader loader = new SimpleLoader();
        loader.setFile("/home/mkishore/corelib/build/classes/com/wm/corelib/config/app.conf");
        Properties props = loader.load();
        assertEquals("pass", props.getProperty("simple.loader"));
    }
    */
}

