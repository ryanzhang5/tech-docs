package com.wm.corelib.jmxadmin;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.framework.TestCase;
import java.util.logging.Logger;
import java.util.logging.Level;

import com.wm.corelib.security.Role;

import javax.security.auth.Subject;

/**
 * WMJMXAuthenticator Tester.
 *
 * @author Igor.Dralyuk@walmart.com
 * @version $Id: WMJMXAuthenticatorTest.java,v 1.2 2009/04/08 05:14:07 mkishore Exp $
 */
public class WMJMXAuthenticatorTest extends TestCase {

    private static final Logger _log = Logger.getLogger(WMJMXAuthenticatorTest.class.getName());

    static {
        _log.getParent().setLevel(Level.ALL);
    }

    public WMJMXAuthenticatorTest(String name) {
        super(name);
    }

    public void setUp() throws Exception {
        super.setUp();
    }

    public void tearDown() throws Exception {
        super.tearDown();
    }

    public void testRoleComparison() {
        _log.log(Level.INFO, "Comparing Role.ADMIN to Role.OPERATOR = " +
                WMJMXPrincipal.Role.ADMIN.compareTo(WMJMXPrincipal.Role.OPERATOR));

        _log.log(Level.INFO, "Comparing Role.ADMIN to Role.MONITOR = " +
                WMJMXPrincipal.Role.ADMIN.compareTo(WMJMXPrincipal.Role.MONITOR));

        _log.log(Level.INFO, "Comparing Role.MONITOR to Role.OPERATOR = " +
                WMJMXPrincipal.Role.MONITOR.compareTo(WMJMXPrincipal.Role.OPERATOR));

        _log.log(Level.INFO, "Comparing Role.MONITOR to Role.MONITOR = " +
                WMJMXPrincipal.Role.MONITOR.compareTo(WMJMXPrincipal.Role.MONITOR));
    }

    public void testPrincipal() throws Exception {
        Role r = new Role();
        r.setRoleName(WMJMXPrincipal.Role.MONITOR.toString());
        WMJMXAuthenticator.getPrincipal(r);

        r.setRoleName("cocoaBean." + WMJMXPrincipal.Role.ADMIN);
        WMJMXAuthenticator.getPrincipal(r);
    }
    
    public void testAuthenticate() throws Exception {
        String[] c = { "user", "pass" };
        WMJMXAuthenticator a = new WMJMXAuthenticator();
        Subject s = a.authenticate(c);
    }

    public static Test suite() {
        return new TestSuite(WMJMXAuthenticatorTest.class);
    }
}
