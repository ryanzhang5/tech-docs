package com.wm.corelib.metric;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.concurrent.CountDownLatch;

import org.junit.Test;

public class CounterTest
{
    private final static long s_initVal = 200;
    private final Counter m_metric = new Counter("RequestCount", s_initVal);

    @Test
    public void reset()
    {
        m_metric.increment();
        assertEquals(s_initVal + 1, m_metric.getValue());
        assertTrue(m_metric.isUpdated());
        m_metric.reset();
        assertEquals(s_initVal, m_metric.getValue());
        assertFalse(m_metric.isUpdated());
    }

    @Test
    public void cumulativeCounter()
    {
        Counter cumCnt = new Counter("TotalReqCount", true);
        assertEquals(10, cumCnt.increment(10));
        cumCnt.initialize();
        assertEquals(10, cumCnt.getValue());
        cumCnt.reset();
        assertEquals(0, cumCnt.getValue());
    }

    @Test
    public void increment()
    {
        long delta = 10;
        assertEquals(s_initVal + delta, m_metric.increment(delta));
        assertEquals(m_metric.getValue() + 1, m_metric.increment());
    }

    @Test
    public void decrement()
    {
        long delta = 10;
        assertEquals(s_initVal - delta, m_metric.decrement(delta));
        assertEquals(m_metric.getValue() - 1, m_metric.decrement());
    }

    @Test
    public void getValue()
    {
        assertEquals(s_initVal, m_metric.getValue());
        m_metric.increment();
        assertEquals(s_initVal + 1, m_metric.getValue());
    }

    @Test
    public void snapshotTest()
    {
        m_metric.decrement(50);
        CounterSnapshot cs = m_metric.takeSnapshot(false);
        assertEquals(m_metric.getValue(), cs.getValue());
        long csv = cs.getValue();
        m_metric.increment(10);
        assertEquals(csv, cs.getValue());
        cs = m_metric.takeSnapshot(true);
        assertEquals(s_initVal, m_metric.getValue());
    }

    @Test
    public void concurrencyTest() throws InterruptedException
    {
        int nThreads = 100;
        final CountDownLatch startSignal = new CountDownLatch(1);
        final CountDownLatch doneSignal = new CountDownLatch(nThreads);

        for (int i = 0; i < nThreads; ++i)
        {
            // create and start threads
            final int n = i;
            new Thread(new Runnable()
            {
                @Override
                public void run()
                {
                    try
                    {
                        startSignal.await();
                    } catch (InterruptedException ex)
                    {
                        fail(ex.getMessage());
                    }
                    if (n % 2 == 0) m_metric.decrement(n);
                    else m_metric.increment(n);
                    doneSignal.countDown();
                }
            }).start();
        }
        assertEquals(s_initVal, m_metric.getValue());
        startSignal.countDown();
        doneSignal.await();
        assertEquals(s_initVal + nThreads / 2, m_metric.getValue());
    }
}
