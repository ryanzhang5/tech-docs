/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.io;

import junit.framework.TestCase;

/**
 * ClassPathResourceTest
 *
 * @author mkishore
 * @since 2.5.2
 */
public class ClassPathResourceTest extends TestCase {

    public void testBaseCase() {
        ClassPathResource resource = new ClassPathResource();
        resource.setPath("com/wm/corelib/io/ClassPathResource.class");
        assertNotNull(resource.getInputStream());
        assertNotNull(resource.getURL());
        assertNotNull(resource.getDescription());
    }

    public void testFailureCase() {
        ClassPathResource resource = new ClassPathResource();
        resource.setPath("com/wm/corelib/io/NoSuchFile");
        try {
            resource.getInputStream();
            fail("Calling getInputStream on a missing resource should throw an exception");
        } catch (Exception e) {
            // ignore
        }
        try {
            resource.getURL();
            fail("Calling getURL on a missing resource should throw an exception");
        } catch (Exception e) {
            // ignore
        }
        assertNotNull(resource.getDescription());
    }

}
