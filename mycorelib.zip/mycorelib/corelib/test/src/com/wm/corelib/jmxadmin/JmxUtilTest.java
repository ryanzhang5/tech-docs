package com.wm.corelib.jmxadmin;

import javax.management.Attribute;
import javax.management.NotCompliantMBeanException;

/**
 * No easy way to test the singleton class with static initializers and all..
 * Just launch two processes for this class to test the multiple JVM behavior:
 * - once without any system property, and
 * - the next one with -Dcom.wm.management.disabled=true
 */
public class JmxUtilTest {
    public static void main(String[] args) throws Exception {
        JmxUtil instance = JmxUtil.getInstance();
        System.out.println("resource value: " + instance.getStringValue("test"));
        Sample mbean = new Sample();
        JmxUtil.registerMBean("Sample:name=sample", mbean, null);
        mbean.setAttribute(new Attribute("MyProp", "value"));
        System.out.println("attribute value: " + mbean.getAttribute("MyProp"));
    }

    public static interface SampleMBean extends WmtMBean {
        String getMyProp();

        void setMyProp(String myProp);
    }

    public static class Sample extends WmtMBeanImpl implements SampleMBean {
        private String myProp;

        public String getMyProp() {
            return myProp;
        }

        public void setMyProp(String myProp) {
            this.myProp = myProp;
        }

        public Sample() throws NotCompliantMBeanException {
            super(SampleMBean.class);
        }

    }

}
