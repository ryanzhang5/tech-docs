package com.wm.corelib.concurrent;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;
import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * WMThreadPoolExecutor Tester.
 *
 * @since November 2005
 * @version $Id: WMThreadPoolExecutorTest.java,v 1.3 2009/04/08 05:14:03 mkishore Exp $
 * @author Igor.Dralyuk@walmart.com
 */
public class WMThreadPoolExecutorTest extends TestCase {

    private static final Logger _log = Logger.getLogger(WMThreadPoolExecutorTest.class.getName());

    static {
        _log.getParent().setLevel(Level.ALL);
    }

    public WMThreadPoolExecutorTest(String name) {
        super(name);
    }

    public void setUp() throws Exception {
        super.setUp();

    }

    public void tearDown() throws Exception {
        super.tearDown();
    }

    public class NamePrinter implements Runnable {
        private final String name;
        private final int delay;
        public NamePrinter(String name, int delay) {
            this.name = name;
            this.delay = delay;
        }
        public void run() {
            System.out.println("Starting: " + name);
            try {
                Thread.sleep(delay);
            } catch (InterruptedException ignored) {
            }
            System.out.println("Done with: " + name);
        }
    }

    public void testZeroCore() throws Exception {
        Random random = new Random();
        ThreadPoolExecutor executor =  new ThreadPoolExecutor(0, 10, 0, TimeUnit.SECONDS, new ArrayBlockingQueue<Runnable>(300));

        // Sum up wait times to know when to shutdown
        int waitTime = 500;
        for (int i=1; i<=100; i++) {
            String name = "NamePrinter " + i;
            int time = random.nextInt(1000);
            waitTime += time;
            Runnable runner = new NamePrinter(name, time);
            System.out.println("Adding: " + name + " / " + time);
            executor.execute(runner);
            System.out.println("queue size = " + executor.getQueue().size() + "    total threads = " + executor.getActiveCount());
        }

        Thread.sleep(5000);
        System.out.print("queue size = " + executor.getQueue().size());
        System.out.println("    total threads = " + executor.getActiveCount());
        Thread.sleep(5000);

        for (int i=1; i<=10; i++) {
            String name = "NamePrinter " + i;
            int time = random.nextInt(1000);
            waitTime += time;
            Runnable runner = new NamePrinter(name, time);
            System.out.println("Adding: " + name + " / " + time);
            executor.execute(runner);
            System.out.print(" new queue size = " + executor.getQueue().size());
            System.out.println("    total threads = " + executor.getActiveCount());
        }

        try {
            Thread.sleep(waitTime);
            executor.shutdown();
            executor.awaitTermination(waitTime, TimeUnit.MILLISECONDS);
        } catch (InterruptedException ignored) {}
    }

    public static void testRecycled() throws Exception {
        final int nTasks = 1000;
        final AtomicInteger nRun = new AtomicInteger(0);
        final Runnable recycledTask = new Runnable() {
            public void run() {
                nRun.getAndIncrement();
            } };
        final ThreadPoolExecutor p = new ThreadPoolExecutor(1, 30, 60, TimeUnit.SECONDS, new ArrayBlockingQueue(30));
        try {
            for (int i = 0; i < nTasks; ++i) {
                for (;;) {
                    try {
                        p.execute(recycledTask);
                        break;
                    }
                    catch (RejectedExecutionException ignore) {
                    }
                }
            }
            Thread.sleep(5000); // enough time to run all tasks
            if (nRun.get() < nTasks) throw new Error("Started " + nTasks + " Ran " + nRun.get());
        } catch(Exception ex) {
            ex.printStackTrace();
        } finally {
            p.shutdown();
        }
    }

    public static void testFresh() throws Exception {
        final int nTasks = 2000;
        final AtomicInteger nRun = new AtomicInteger(0);
        final AtomicInteger nRejected = new AtomicInteger(0);
        final ThreadPoolExecutor p = new ThreadPoolExecutor(100, 100, 60, TimeUnit.SECONDS, new ArrayBlockingQueue(3000));
        try {
            for (int i = 0; i < nTasks; ++i) {
                while (true) {
                    try {
                        p.execute(new Runnable() {
                            public void run() {
                                nRun.getAndIncrement();
                            } });
                        break;
                    }
                    catch (RejectedExecutionException ignore) {
                        nRejected.getAndIncrement();
                    }
                }
            }
            System.out.println("nRejected = " + nRejected);
            Thread.sleep(5000); // enough time to run all tasks
            if (nRun.get() < nTasks) throw new Error("Started " + nTasks + " Ran " + nRun.get());
        } catch(Exception ex) {
            ex.printStackTrace();
        } finally {
            p.shutdown();
        }
    }

    public void testShutdown() throws Exception {
        new WMThreadPoolExecutor(WMThreadPoolExecutor.PoolType.IO_BOUND, 1, 1, 60, 1).shutdown();
    }

    public void testPauseResume() throws Exception {
        WMThreadPoolExecutor p = new WMThreadPoolExecutor(WMThreadPoolExecutor.PoolType.IO_BOUND, 1, 10, 60, 100);
        for (int i = 0; i < 5; i++) p.execute(new Runnable() { public void run() { try { Thread.sleep(100); } catch(Exception e) {}}});
        p.pause();
        Thread.sleep(100);
        _log.info("Pool Paused " + p.getStats().toString());

        for (int i = 0; i < 5; i++) p.execute(new Runnable() { public void run() {}});

        p.resume();
        _log.info("Pool Resumed " + p.getStats().toString());

        Thread.sleep(2000);
        _log.info("Pool Finished " + p.getStats().toString());
    }

    public void testGetStats() throws Exception {

        int TASKS = 100;
        WMThreadPoolExecutor.PoolType type = WMThreadPoolExecutor.PoolType.IO_BOUND;

        WMThreadPoolExecutor p = new WMThreadPoolExecutor(type, 1, 1, 60, 10);

        for (int i = 0; i < TASKS; i++) {
            try {
                p.execute(new Runnable() { public void run() {
                    if (System.currentTimeMillis() % 3 == 0) throw new RuntimeException("Foo");
                    else Thread.yield();
                }});
            } catch (Exception e) {
                _log.info("Caught exception: " + e.toString());
            }
        }
        _log.info(p.getStats().toString());

        int totalQueuedReuests = p.getQueueSize();
        long totalAcceptedRequests = p.getTotalAcceptedRequests();
        long totalCompletedRequests = p.getTotalCompletedRequests();
        long totalUncaughtExceptions = p.getTotalUncaughtExceptions();
        long totalRejectedRequests = p.getTotalRejectedRequests();

        _log.info("totalQueuedRequests = " + totalQueuedReuests);
        _log.info("totalAcceptedRequests = " + totalAcceptedRequests);
        _log.info("totalCompletedRequests = " + totalCompletedRequests);
        _log.info("totalUncaughtExceptions = " + totalUncaughtExceptions);
        _log.info("totalRejectedRequests = " + totalRejectedRequests);

        long totalTasks = totalQueuedReuests + totalAcceptedRequests + totalRejectedRequests;
        _log.info("totalTasks = " + totalTasks);

        if (TASKS != totalTasks) throw new RuntimeException("Task count mismatch!");
    }

    public void testResetStats() throws Exception {

        WMThreadPoolExecutor.PoolType type = WMThreadPoolExecutor.PoolType.CPU_BOUND;
        WMThreadPoolExecutor p = new WMThreadPoolExecutor(type, 1, 1, 60, 10);

        List<FutureTask<String>> l = new ArrayList<FutureTask<String>>(10);

        for (int i = 0; i < 10; i++) {
            FutureTask<String> t = new FutureTask<String>(new Callable <String>() { public String call() { return "h i "; }});
            l.add(t);
            p.execute(t);
        }

        Thread.sleep(100);

        StringBuffer sb = new StringBuffer();
        for (FutureTask<String> t : l) sb.append(t.get());

        _log.info("Future task result: " + sb.toString());

        WMThreadPoolExecutor.PoolStats oldStats = p.resetStats();

        _log.info("Old stats: " + oldStats.toString());
        _log.info("New stats: " + p.getStats().toString());
    }

    public void testMultiplePools() throws Exception {
        WMThreadPoolExecutor poolOne = new WMThreadPoolExecutor(WMThreadPoolExecutor.PoolType.IO_BOUND, 1, 1, 60, 1);
        WMThreadPoolExecutor poolTwo = new WMThreadPoolExecutor(WMThreadPoolExecutor.PoolType.IO_BOUND, 1, 1, 60, 1);
        WMThreadPoolExecutor poolThree = new WMThreadPoolExecutor(WMThreadPoolExecutor.PoolType.CPU_BOUND, 1, 1, 60, 1);
        WMThreadPoolExecutor poolFour = new WMThreadPoolExecutor(WMThreadPoolExecutor.PoolType.CPU_BOUND, 1, 1, 60, 1);
        poolOne.shutdownNow();
        poolTwo.shutdownNow();
        poolThree.shutdownNow();
        poolFour.shutdownNow();
    }

    public void testRejectedExecutionOnBusy() throws Exception {
        WMThreadPoolExecutor pool = new WMThreadPoolExecutor(WMThreadPoolExecutor.PoolType.IO_BOUND, 1, 1, 60, 1);

        for (int i = 0; i < 10; i++) {
            pool.execute(new Runnable() { public void run() {}});
        }

        try { Thread.sleep(2000); } catch (InterruptedException ie) {}

        _log.info(pool.getStats().toString());

        WMThreadPoolExecutor.PoolStats stats = pool.getStats();
        if (stats.getTotalRejectedRequests() <= 0) {
            throw new RuntimeException("There should be at least one rejected request");
        }
    }

    public void testRejectedExecutionOnShutdown() throws Exception {
        WMThreadPoolExecutor pool = new WMThreadPoolExecutor(WMThreadPoolExecutor.PoolType.IO_BOUND, 1, 1, 60, 1);
        pool.shutdownNow();

        for (int i = 0; i < 10; i++) {
            pool.execute(new Runnable() { public void run() {}});
        }

        try { Thread.sleep(2000); } catch (InterruptedException ie) {}

        _log.info(pool.getStats().toString());

        WMThreadPoolExecutor.PoolStats stats = pool.getStats();
    }

    public void testUncaughtException() throws Exception {
        WMThreadPoolExecutor pool = new WMThreadPoolExecutor(WMThreadPoolExecutor.PoolType.IO_BOUND, 10, 10, 60, 100);
        for (int i = 0; i < 10; i++) {
            pool.execute(new Runnable() {
                public void run() {
                    throw new RuntimeException("testUncaughtException");
                }});
        }

        try { Thread.sleep(2000); } catch (InterruptedException ie) {}

        _log.fine(pool.getStats().toString());
    }

    public static Test suite() {
        return new TestSuite(WMThreadPoolExecutorTest.class);
    }
}

