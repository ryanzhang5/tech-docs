package com.wm.corelib.metric;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public final class MetricContainerTest
{
    private final MetricContainer m_cont = new MetricContainer(getClass(), null);

    @Test
    public void takeSnapshot() throws InterruptedException
    {
        Thread.sleep(500);
        Snapshot s = m_cont.takeSnapshot(false); // do not reset
        assertEquals(m_cont.getName(), s.getName());
        assertTrue(s.getPeriodEndTime() - s.getPeriodBeginTime() >= 500);

        Snapshot s1 = m_cont.takeSnapshot(true);
        assertEquals(s.getPeriodBeginTime(), s1.getPeriodBeginTime());

        Thread.sleep(200);
        Snapshot s2 = m_cont.takeSnapshot(true);
        assertEquals(s1.getPeriodEndTime(), s2.getPeriodBeginTime());

        s2.aggregate(s1);
        assertEquals(s1.getPeriodBeginTime(), s2.getPeriodBeginTime());
    }

    @Test
    public void shortcutApis()
    {
        String gaugeId = "HeapUsage";

        Gauge g = m_cont.getGauge(gaugeId);
        assertFalse(g.isCumulative());
        g.increment(20000);

        // Try and mix cumulative and non-cumulative gauges of same name
        // in same container
        m_cont.incrementGauge(gaugeId, 10000, true);
        assertEquals(20000, g.getValue());

        Gauge g1 = m_cont.getGauge(gaugeId, true);
        assertTrue(g1.isCumulative());
        assertEquals(10000, g1.getValue());

        g.set(75000);
        g1.set(40000);
        assertEquals(75000, g.getValue());
        assertEquals(40000, g1.getValue());

        m_cont.resetMetrics();
        assertFalse(g.isUpdated());
        assertEquals(75000, g.getMinValue());
        assertTrue(g1.isUpdated());
        assertEquals(10000, m_cont.getGauge(gaugeId, true).getMinValue());
    }
}
