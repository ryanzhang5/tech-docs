/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.config;

import junit.framework.TestCase;

import java.util.Properties;

/**
 * AppConfigTest
 *
 * @author mkishore
 * @since 2.5.2
 */
public class AppConfigTest extends TestCase {

    public void testDefaultsToSystemProperties() {
        System.setProperty("AppConfig.defaultsToSystem", "true");
        assertEquals("true", AppConfig.getInstance().getProperty("AppConfig.defaultsToSystem"));
    }

    public void testDefaultValues() {
        assertEquals("default-value", AppConfig.getInstance().getProperty("missing-key", "default-value"));
    }

    public void testAllowsMultipleInstances() {
        Properties p1 = new Properties();
        p1.setProperty("name", "1");
        AppConfig a1 = new AppConfig();
        a1.setProperties(p1);

        Properties p2 = new Properties();
        p2.setProperty("name", "2");
        AppConfig a2 = new AppConfig();
        a2.setProperties(p2);

        assertEquals("1", a1.get("name"));
        assertEquals("2", a2.get("name"));

        a1.setProperties(a2.getProperties());
        assertEquals("2", a1.get("name"));
    }

    public void testDerivedPath() {
        AppConfig a1 = new AppConfig();
        assertEquals("", a1.getDerivedPath());

        a1.setContextPath("/test");
        assertEquals("test", a1.getDerivedPath());

        a1.setContextPath("/test/nested");
        assertEquals("test#nested", a1.getDerivedPath());
    }
}
