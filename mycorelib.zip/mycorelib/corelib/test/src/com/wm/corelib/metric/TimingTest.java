package com.wm.corelib.metric;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.concurrent.CountDownLatch;

import org.junit.Test;

public class TimingTest
{
    private final Timing m_metric = new Timing("Latency");

    @Test
    public void reset()
    {
        m_metric.add(14);
        m_metric.add(10);
        m_metric.add(5);

        assertEquals(3, m_metric.getCount());
        assertEquals(29, m_metric.getTotal());
        assertEquals(5, m_metric.getLastValue());
        assertEquals(14, m_metric.getMaxValue());
        assertEquals(5, m_metric.getMinValue());
        assertTrue(m_metric.isUpdated());

        m_metric.reset();

        assertEquals(0, m_metric.getCount());
        assertEquals(0, m_metric.getTotal());
        assertFalse(m_metric.isUpdated());
    }

    @Test
    public void isUpdated()
    {
        assertFalse(m_metric.isUpdated());
    }

    @Test
    public void snapshotTest()
    {
        for (int i = 10; i <= 100; i += 10)
            m_metric.add(i);
        TimingSnapshot ts = m_metric.takeSnapshot(false);
        assertEquals(m_metric.getCount(), ts.getCount());
        assertEquals(m_metric.getTotal(), ts.getTotal());
        assertEquals(m_metric.getMaxValue(), ts.getMax());
        assertEquals(m_metric.getMinValue(), ts.getMin());
        assertTrue(m_metric.isUpdated());

        for (int i = 50; i < 150; i += 5)
            m_metric.add(i);
        assertEquals(10, ts.getCount());
        assertEquals(30, m_metric.getCount());

        ts = m_metric.takeSnapshot(true);
        assertFalse(m_metric.isUpdated());
    }

    @Test
    public void getMinValue()
    {
        m_metric.add(490);
        assertEquals(490, m_metric.getMinValue());
        m_metric.add(80);
        assertEquals(80, m_metric.getMinValue());
        m_metric.add(3100);
        assertEquals(80, m_metric.getMinValue());
    }

    @Test
    public void getMaxValue()
    {
        m_metric.add(490);
        assertEquals(490, m_metric.getMaxValue());
        m_metric.add(80);
        assertEquals(490, m_metric.getMaxValue());
        m_metric.add(3100);
        assertEquals(3100, m_metric.getMaxValue());

    }

    @Test
    public void getAvgValue()
    {
        assertEquals(0, m_metric.getAvgValue(), 0);
        m_metric.add(22);
        m_metric.add(18);
        m_metric.add(35);

        assertEquals(75, m_metric.getTotal());
        assertEquals(25, m_metric.getAvgValue(), 1E-10);
        m_metric.reset();
        assertEquals(0, m_metric.getAvgValue(), 0);
    }

    @Test
    public void contextTest() throws InterruptedException
    {
        m_metric.eventStart();
        Thread.sleep(200);
        m_metric.eventEnd();

        assertEquals(1, m_metric.getCount());
        assertTrue(200 <= m_metric.getLastValue());

        m_metric.eventStart();
        Thread.sleep(50);
        new Thread(new Runnable()
        {
            @Override
            public void run()
            {
                m_metric.eventEnd();
            }
        }).start();
        Thread.sleep(100);

        // No measurement taken since the ending event was reported in
        // another thread
        assertEquals(1, m_metric.getCount());
    }

    @Test
    public void concurrencyTest() throws InterruptedException
    {
        int nThreads = 100;
        final CountDownLatch startSignal = new CountDownLatch(1);
        final CountDownLatch doneSignal = new CountDownLatch(nThreads);

        for (int i = 0; i < nThreads; ++i)
            // create and start threads
            new Thread(new Runnable()
            {

                @Override
                public void run()
                {
                    m_metric.eventStart();
                    try
                    {
                        startSignal.await();
                    } catch (InterruptedException ex)
                    {
                        fail(ex.getMessage());
                    }
                    m_metric.eventEnd();
                    doneSignal.countDown();
                }
            }).start();

        assertFalse(m_metric.isUpdated());
        assertEquals(0, m_metric.getCount());
        Thread.sleep(100);

        startSignal.countDown(); // let all threads proceed
        doneSignal.await(); // wait for all to finish
        assertEquals(nThreads, m_metric.getCount());
        assertTrue(String.valueOf(m_metric.getMinValue()), 100 < m_metric.getMinValue());
    }
}
