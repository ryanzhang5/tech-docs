/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.config;

import junit.framework.TestCase;

import java.util.Map;
import java.util.HashMap;
import java.util.Properties;

/**
 * HierarchicalLoaderTest
 *
 * @author mkishore
 * @since 2.5.2
 */
public class HierarchicalLoaderTest extends TestCase {

    public void testSingleLevelLoad() {
        HierarchicalLoader loader = new HierarchicalLoader();
        loader.setPathKey("DEV");
        Map<String,String> pathMap = new HashMap<String, String>();
        pathMap.put("DEV", "com/wm/corelib/config");
        loader.setPathMap(pathMap);
        Properties props = loader.load();
        assertEquals("pass", props.getProperty("simple.loader"));
        assertEquals("fail", props.getProperty("hierarchical.loader"));
    }
    
    public void testMultiLevelLoad() {
        HierarchicalLoader loader = new HierarchicalLoader();
        loader.setPathKey("DEV");
        Map<String,String> pathMap = new HashMap<String, String>();
        pathMap.put("DEV", "com/wm/corelib/config/hierarchical");
        loader.setPathMap(pathMap);
        Properties props = loader.load();
        assertEquals("pass", props.getProperty("simple.loader"));
        assertEquals("pass", props.getProperty("hierarchical.loader"));
    }

    public void testMissingSystemProperty() {
        HierarchicalLoader loader = new HierarchicalLoader();
        Map<String,String> pathMap = new HashMap<String, String>();
        pathMap.put("DEV", "com/wm/corelib/config");
        loader.setPathMap(pathMap);
        Properties props = loader.load();
        assertTrue(props.isEmpty());
    }

    public void testMissingPathMapping() {
        HierarchicalLoader loader = new HierarchicalLoader();
        loader.setPathKey("QA");
        Map<String,String> pathMap = new HashMap<String, String>();
        pathMap.put("DEV", "com/wm/corelib/config");
        loader.setPathMap(pathMap);
        Properties props = loader.load();
        assertTrue(props.isEmpty());
    }

    public void testMissingPropertyFiles() {
        HierarchicalLoader loader = new HierarchicalLoader();
        loader.setPathKey("DEV");
        Map<String,String> pathMap = new HashMap<String, String>();
        pathMap.put("DEV", "com/wm/corelib");
        loader.setPathMap(pathMap);
        Properties props = loader.load();
        assertTrue(props.isEmpty());
    }

}
