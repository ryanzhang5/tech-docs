package com.wm.corelib.concurrent;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.List;
import java.util.ArrayList;

/**
 * WMThreadPoolManager Tester.
 *
 * @since November 2005
 * @version $Id: WMThreadPoolManagerTest.java,v 1.3 2009/04/08 20:08:51 mkishore Exp $
 * @author Igor.Dralyuk@walmart.com
 */
public class WMThreadPoolManagerTest extends TestCase {

    private static final Logger _logger = Logger.getLogger(WMThreadPoolManagerTest.class.getName());

    static {
        _logger.getParent().setLevel(Level.ALL);
    }

    public WMThreadPoolManagerTest(String name) {
        super(name);
    }

    public void setUp() throws Exception {
        super.setUp();
    }

    public void tearDown() throws Exception {
        super.tearDown();
    }

    public void testLoadParams() throws Exception {

        System.setProperty("com.wm.corelib.concurrent.threadpool.count", "2");
        System.setProperty("com.wm.corelib.concurrent.threadpool.1.type", "IO_BOUND");
        System.setProperty("com.wm.corelib.concurrent.threadpool.1.coresize", "100");
        System.setProperty("com.wm.corelib.concurrent.threadpool.1.maxsize", "100");
        System.setProperty("com.wm.corelib.concurrent.threadpool.1.keepalive", "300");
        System.setProperty("com.wm.corelib.concurrent.threadpool.1.queuesize", "10000");

        System.setProperty("com.wm.corelib.concurrent.threadpool.2.type", "CPU_BOUND");
        System.setProperty("com.wm.corelib.concurrent.threadpool.2.coresize", "2");
        System.setProperty("com.wm.corelib.concurrent.threadpool.2.maxsize", "2");
        System.setProperty("com.wm.corelib.concurrent.threadpool.2.keepalive", "300");
        System.setProperty("com.wm.corelib.concurrent.threadpool.2.queuesize", "1000");

        WMThreadPoolManager.loadParams();
    }

    public void testInitPool() throws Exception {
        WMThreadPoolManager.initPool(WMThreadPoolExecutor.PoolType.CPU_BOUND);
    }

    public void testGetPool() throws Exception {
        WMThreadPoolManager.init();

        WMThreadPoolExecutor cpuBoundPool = WMThreadPoolManager.getPool(WMThreadPoolExecutor.PoolType.CPU_BOUND);
        WMThreadPoolExecutor ioBoundPool = WMThreadPoolManager.getPool();

        for (int i = 0; i < 10; i++) {
            ioBoundPool.execute(new Runnable() {
                public void run() {
                    _logger.entering(this.getClass().getName(), "run");
                    Thread.yield();
                }
            });
        }

        List<FutureTask<String>> ft = new ArrayList<FutureTask<String>>(10);

        for (int i = 0; i < 10; i++) {
            ft.add(i, new FutureTask<String>(new Callable<String>() {
                public String call() {
                    _logger.entering(this.getClass().getName(), "call");
                    long r = 1;
                    for (int j = 0; j < 1000000; j++) {
                        r *= j % 31415;
                    }
                    return r + "foo";
                }
            }));
        }

        for (int i = 0; i < 10; i++) {
            cpuBoundPool.execute(ft.get(i));
        }

        try { Thread.sleep(2000); } catch (InterruptedException ie) {}

        _logger.info(cpuBoundPool.getStats().toString());
        _logger.info(ioBoundPool.getStats().toString());
    }

    public void testShutdownAll() throws Exception {
        WMThreadPoolManager.shutdownAll();
    }

    public static Test suite() {
        return new TestSuite(WMThreadPoolManagerTest.class);
    }
}
