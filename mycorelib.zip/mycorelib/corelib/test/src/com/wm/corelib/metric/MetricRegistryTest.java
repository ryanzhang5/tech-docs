package com.wm.corelib.metric;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.util.Set;

import org.junit.Test;

import com.google.common.collect.Sets;

public final class MetricRegistryTest
{
    private final IMetricRegistry m_reg = MetricRegistryFactory.get();

    @Test
    public void addContainer()
    {
        MetricMetaDataListener lsnr = new MetricMetaDataListener()
        {
            @Override
            public void metricRemoved(MetricMetaData md)
            {
                assert false;
            }

            @Override
            public void metricAdded(MetricMetaData md)
            {
                assert false;
            }

            @Override
            public void containerRemoved(MetricContainer mc)
            {
                assert false;
            }

            @Override
            public void containerAdded(MetricContainer mc)
            {
                assertEquals("MetricGroup1", mc.getName());
                assertNull(mc.getInstanceId());
            }
        };
        m_reg.addMetaDataListener(lsnr);
        MetricContainer mc = m_reg.get(null, "MetricGroup1");
        assertSame(mc, m_reg.get(null, "MetricGroup1", null, false));
        m_reg.removeMetaDataListener(lsnr);
        m_reg.remove(mc);
    }

    @Test
    public void getNonExistentContainer()
    {
        assertNull(m_reg.get(getClass(), null, "Test1", false));
    }

    @Test
    public void removeContainer()
    {
        final MetricContainer mc = m_reg.get(getClass(), null);
        m_reg.addMetaDataListener(new MetricMetaDataListener()
        {
            @Override
            public void metricRemoved(MetricMetaData md)
            {
                assert false;
            }

            @Override
            public void metricAdded(MetricMetaData md)
            {
                assert false;
            }

            @Override
            public void containerRemoved(MetricContainer cont)
            {
                assertSame(mc, cont);
            }

            @Override
            public void containerAdded(MetricContainer mc)
            {
                assert false;
            }
        });
        m_reg.remove(mc);
    }

    @Test
    public void getAllContInstances()
    {
        Set<String> cInst = Sets.newHashSet("A1", "A2", "B1", "B2");
        for (String inst : cInst)
        {
            MetricContainer mc = m_reg.get(getClass(), null, inst, true);
            assertEquals(inst, mc.getInstanceId());
        }
        for (MetricContainer child : m_reg.getContainers(getClass(), null))
        {
            assertTrue(cInst.contains(child.getInstanceId()));
        }
    }

    @Test
    public void metricAdd()
    {
        MetricContainer mc = m_reg.get(null, "San Mateo", "Brisbane", true);
        final String cName = "Population";
        m_reg.addMetaDataListener(new MetricMetaDataListener()
        {
            @Override
            public void metricRemoved(MetricMetaData md)
            {
                assert false;
            }

            @Override
            public void metricAdded(MetricMetaData md)
            {
                assertEquals("San Mateo", md.getContainerId());
                assertEquals("Brisbane", md.getInstanceId());
                assertEquals(Counter.class, md.getType());
                assertEquals(cName, md.getMetricId());
            }

            @Override
            public void containerRemoved(MetricContainer mc)
            {
                assert false;
            }

            @Override
            public void containerAdded(MetricContainer mc)
            {
                assert false;
            }
        });
        mc.getCounter(cName);
    }
}
