package com.wm.corelib.metric;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.concurrent.CountDownLatch;

import org.junit.Test;

public class GaugeTest
{
    private final Gauge m_metric = new Gauge("HeapUsage");

    @Test
    public void reset()
    {
        long initVal = 500;
        m_metric.set(initVal);
        m_metric.increment(50);
        assertEquals(500, m_metric.getMinValue());

        m_metric.reset();
        assertEquals(550, m_metric.getMinValue());
        assertEquals(550, m_metric.getMaxValue());
        assertEquals(0, m_metric.getChangeCount());
    }

    @Test
    public void isUpdated()
    {
        assertFalse(m_metric.isUpdated());
        m_metric.increment();
        assertTrue(m_metric.isUpdated());
    }

    @Test
    public void snapshotTest()
    {
        GaugeSnapshot gs = m_metric.takeSnapshot(false);
        assertFalse(gs.hasBeenSet());

        m_metric.set(2000);
        m_metric.increment(500);
        m_metric.decrement(1000);
        m_metric.set(1991);

        gs = m_metric.takeSnapshot(false);
        assertTrue(gs.hasBeenSet());
        assertEquals(1991, m_metric.getValue());
        assertEquals(1500, m_metric.getMinValue());
        assertEquals(2500, m_metric.getMaxValue());
        assertEquals(4, m_metric.getChangeCount());
        assertEquals(gs.getChangeCount(), m_metric.getChangeCount());
        assertEquals(gs.getMin(), m_metric.getMinValue());
        assertEquals(gs.getMax(), m_metric.getMaxValue());
        assertEquals(gs.getValue(), m_metric.getValue());

        m_metric.set(0);
        GaugeSnapshot gs1 = m_metric.takeSnapshot(true);
        assertTrue(gs1.hasBeenSet());

        assertFalse(m_metric.isUpdated()); // after reset
        assertEquals(0, m_metric.getValue());
        assertEquals(m_metric.getValue(), m_metric.getMinValue());
        assertEquals(m_metric.getValue(), m_metric.getMaxValue());
        assertEquals(0, m_metric.getChangeCount());

        gs.aggregate(gs1);
        assertEquals(gs1.getMin(), gs.getMin());
        assertEquals(gs1.getMax(), gs.getMax());
        assertEquals(gs1.getValue(), gs.getValue());

        m_metric.increment(350);
        m_metric.decrement(500);
        m_metric.set(1000);

        // Test snapshot immutability
        assertEquals(0, gs1.getMin());
        assertEquals(-150, m_metric.getMinValue());
        assertEquals(2500, gs1.getMax());
        assertEquals(1000, m_metric.getMaxValue());
        assertEquals(0, gs1.getValue());
        assertEquals(3, m_metric.getChangeCount());
        assertEquals(5, gs1.getChangeCount());
    }

    @Test
    public void getValue()
    {
        assertEquals(0, m_metric.getValue());
        m_metric.decrement(100);
        assertEquals(-100, m_metric.getValue());
        m_metric.set(420);
        assertEquals(420, m_metric.getValue());
    }

    @Test
    public void getMinValue()
    {
        m_metric.set(10);
        assertEquals(10, m_metric.getMinValue());
        m_metric.decrement(8);
        assertEquals(2, m_metric.getMinValue());
        m_metric.increment(125);
        assertEquals(2, m_metric.getMinValue());
        m_metric.set(50);
        m_metric.increment(-100);
        assertEquals(-50, m_metric.getMinValue());
    }

    @Test
    public void getMaxValue()
    {
        m_metric.set(10);
        assertEquals(10, m_metric.getMaxValue());
        m_metric.increment(20);
        assertEquals(30, m_metric.getMaxValue());
        m_metric.decrement(125);
        assertEquals(30, m_metric.getMaxValue());
        m_metric.set(50);
        m_metric.decrement(-100);
        assertEquals(150, m_metric.getMaxValue());
    }

    @Test
    public void getChangeCount()
    {
        assertEquals(0, m_metric.getChangeCount());
        for (int i = 0; i < 100;)
        {
            m_metric.set(++i);
        }
        assertEquals(100, m_metric.getChangeCount());
        m_metric.reset();
        assertEquals(0, m_metric.getChangeCount());
        m_metric.increment(0);
        assertEquals(0, m_metric.getChangeCount());
    }

    @Test
    public void increment()
    {
        long delta = 100;
        assertEquals(m_metric.getValue() + delta, m_metric.increment(delta));
        assertEquals(m_metric.getValue() + 1, m_metric.increment());
        assertEquals(m_metric.getValue(), m_metric.increment(0));

        long curValue = m_metric.getValue();
        long down = m_metric.increment(-delta);
        m_metric.set(curValue);
        assertEquals(down, m_metric.decrement(delta));
    }

    @Test
    public void decrement()
    {
        long delta = 100;
        assertEquals(m_metric.getValue() - delta, m_metric.decrement(delta));
        assertEquals(m_metric.getValue() - 1, m_metric.decrement());
        assertEquals(m_metric.getValue(), m_metric.decrement(0));
    }

    @Test
    public void setConcurrently() throws InterruptedException
    {
        int nThreads = 100;
        final CountDownLatch startSignal = new CountDownLatch(1);
        final CountDownLatch doneSignal = new CountDownLatch(nThreads);

        for (int i = 1; i <= nThreads; ++i)
        {
            // create and start threads
            final int n = i;
            new Thread(new Runnable()
            {
                @Override
                public void run()
                {
                    try
                    {
                        startSignal.await();
                    } catch (InterruptedException ex)
                    {
                        fail(ex.getMessage());
                    }
                    m_metric.set(n);
                    doneSignal.countDown();
                }
            }).start();
        }
        assertEquals(0, m_metric.getValue());
        assertEquals(0, m_metric.getChangeCount());
        startSignal.countDown();
        doneSignal.await();
        assertEquals(1, m_metric.getMinValue());
        assertEquals(nThreads, m_metric.getMaxValue());
        assertEquals(nThreads, m_metric.getChangeCount());
    }

    @Test
    public void incrConcurrently() throws InterruptedException
    {
        int nThreads = 100;
        final CountDownLatch startSignal = new CountDownLatch(1);
        final CountDownLatch doneSignal = new CountDownLatch(nThreads);

        for (int i = 1; i <= nThreads; ++i)
        {
            // create and start threads
            final int n = i;
            new Thread(new Runnable()
            {
                @Override
                public void run()
                {
                    try
                    {
                        startSignal.await();
                    } catch (InterruptedException ex)
                    {
                        fail(ex.getMessage());
                    }
                    if (n % 2 > 0) m_metric.decrement(n);
                    else m_metric.increment(n);
                    doneSignal.countDown();
                }
            }).start();
        }
        assertEquals(0, m_metric.getValue());
        assertEquals(0, m_metric.getChangeCount());
        startSignal.countDown();
        doneSignal.await();
        assertEquals(nThreads / 2, m_metric.getValue());
        assertEquals(nThreads, m_metric.getChangeCount());
    }

}
