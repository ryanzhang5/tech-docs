package com.wm.corelib.jmxadmin;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.framework.TestCase;

import javax.management.MBeanServer;
import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.Attribute;
import javax.management.MBeanServerInvocationHandler;
import javax.management.Notification;
import javax.management.NotificationListener;
import javax.management.remote.MBeanServerForwarder;
import javax.management.remote.JMXConnectorServer;
import javax.management.remote.JMXServiceURL;
import javax.management.remote.JMXConnectorServerFactory;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXConnector;
import javax.management.remote.rmi.RMIConnectorServer;
import javax.rmi.ssl.SslRMIClientSocketFactory;
import javax.rmi.ssl.SslRMIServerSocketFactory;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.util.logging.Handler;
import java.util.HashMap;
import java.lang.management.ManagementFactory;
import java.rmi.registry.LocateRegistry;

/**
 * WMMBeanServerForwarderInvocationHandler Tester.
 *
 * @author Igor.Dralyuk@walmart.com
 * @version $Id: WMMBeanServerForwarderInvocationHandlerTest.java,v 1.2 2009/04/08 05:14:07 mkishore Exp $
 */
public class WMMBeanServerForwarderInvocationHandlerTest extends TestCase {

    private static final Logger _log = Logger.getLogger(WMMBeanServerForwarderInvocationHandlerTest.class.getName());

    static {
        Logger.getLogger(WMMBeanServerForwarderInvocationHandler.class.getName()).setLevel(Level.ALL);
        Logger.getLogger(WMJMXAuthenticator.class.getName()).setLevel(Level.ALL);
    }

    public WMMBeanServerForwarderInvocationHandlerTest(String name) {
        super(name);
    }

    public void setUp() throws Exception {
        super.setUp();
    }

    public void tearDown() throws Exception {
        super.tearDown();
    }

    public void testRunServer() throws Exception {

        // Start rmi registry
        //
        LocateRegistry.createRegistry(9999);

        // Retrieve the platform MBean server
        //
        MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();

        // Environment map
        //
        _log.info("\nInitialize the environment map");
        HashMap env = new HashMap();

        // Provide the JMXAuthenticator
        //
        env.put(JMXConnectorServer.AUTHENTICATOR, new WMJMXAuthenticator());

        // Create an RMI connector server
        //
        _log.info("\nCreate an RMI connector server");
        JMXServiceURL url = new JMXServiceURL("service:jmx:rmi:///jndi/rmi://:9999/jmxrmi");
        JMXConnectorServer cs = JMXConnectorServerFactory.newJMXConnectorServer(url, env, mbs);

        // Supply your custom MBeanServerForwarder if you want to intercept
        // the remote MBeanServer invocations and perform your own access
        // checks (usually used when authorization is not based on an
        // installed security manager).
        //
        // On every method you can retrieve the authenticated principals
        // and perform access checks based on them.
        //
        // AccessControlContext acc = AccessController.getContext();
        // Set<Principal> principals = Subject.getSubject(acc).getPrincipals();
        //
        // cs.setMBeanServerForwarder(new CustomMBeanServerForwarder());
        //
        MBeanServerForwarder mbsf = WMMBeanServerForwarderInvocationHandler.newProxyInstance();
        cs.setMBeanServerForwarder(mbsf);

        // Start the RMI connector server
        //
        _log.info("\nStart the RMI connector server");
        cs.start();
        _log.info("\nRMI connector server successfully started");
        _log.info("\nAddress: " + cs.getAddress());
        _log.info("\nWaiting for incoming connections...");

    }

    public void testInvoke() throws Exception {

        // Environment map
        //
        _log.info("\nInitialize the environment map");
        HashMap env = new HashMap();

        // Provide the credentials required by the server to successfully
        // perform user authentication
        //
        String[] credentials = new String[] { "username" , "password" };
        env.put("jmx.remote.credentials", credentials);

        // Create an RMI connector client and
        // connect it to the RMI connector server
        //
        _log.info("\nCreate an RMI connector client and connect it to the RMI connector server");
        JMXServiceURL url = new JMXServiceURL("service:jmx:rmi:///jndi/rmi://:9999/jmxrmi");
        JMXConnector jmxc = JMXConnectorFactory.connect(url, env);

        // Get an MBeanServerConnection
        //
        _log.info("\nGet an MBeanServerConnection");
        MBeanServerConnection mbsc = jmxc.getMBeanServerConnection();

        // Get domains from MBeanServer
        //
        _log.info("\nDomains:");
        String domains[] = mbsc.getDomains();
        for (int i = 0; i < domains.length; i++) {
            _log.info("\tDomain[" + i + "] = " + domains[i]);
        }

        // Create SimpleStandard MBean
        //
        ObjectName mbeanName = new ObjectName("MBeans:type=SimpleStandard");
        _log.info("\nCreate SimpleStandard MBean...");
        mbsc.createMBean("SimpleStandard", mbeanName, null, null);

        // Get MBean count
        //
        _log.info("\nMBean count = " + mbsc.getMBeanCount());

        // Get State attribute
        //
        _log.info("\nState = " +
                mbsc.getAttribute(mbeanName, "State"));

        // Set State attribute
        //
        mbsc.setAttribute(mbeanName,
                new Attribute("State", "changed state"));

        // Get State attribute
        //
        // Another way of interacting with a given MBean is through a
        // dedicated proxy instead of going directly through the MBean
        // server connection
        //
        /*
        SimpleStandardMBean proxy = (SimpleStandardMBean)
                MBeanServerInvocationHandler.newProxyInstance(
                        mbsc,
                        mbeanName,
                        SimpleStandardMBean.class,
                        false);
        _log.info("\nState = " + proxy.getState());
        */
        // Add notification listener on SimpleStandard MBean
        //
        ClientListener listener = new ClientListener();
        _log.info("\nAdd notification listener...");
        mbsc.addNotificationListener(mbeanName, listener, null, null);

        // Invoke "reset" in SimpleStandard MBean
        //
        // Calling "reset" makes the SimpleStandard MBean emit a
        // notification that will be received by the registered
        // ClientListener.
        //
        _log.info("\nInvoke reset() in SimpleStandard MBean...");
        mbsc.invoke(mbeanName, "reset", null, null);

        // Sleep for 2 seconds in order to have time to receive the
        // notification before removing the notification listener.
        //
        _log.info("\nWaiting for notification...");
        Thread.sleep(2000);

        // Remove notification listener on SimpleStandard MBean
        //
        _log.info("\nRemove notification listener...");
        mbsc.removeNotificationListener(mbeanName, listener);

        // Unregister SimpleStandard MBean
        //
        _log.info("\nUnregister SimpleStandard MBean...");
        mbsc.unregisterMBean(mbeanName);

        // Close MBeanServer connection
        //
        _log.info("\nClose the connection to the server");
        jmxc.close();
        _log.info("\nBye! Bye!");
    }

    public static Test suite() {
        return new TestSuite(WMMBeanServerForwarderInvocationHandlerTest.class);
    }


    public class ClientListener implements NotificationListener {
        public void handleNotification(Notification notification, Object handback) {
            _log.info("\nReceived notification: " + notification);
        }
    }
}
