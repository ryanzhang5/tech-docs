
#include <cstdio>

#include "String/Util.hpp"

#ifdef _CORELIB_USE_NAMESPACE
_CORELIB_NAMESPACE_BEGIN
#endif

/**
 * An empty string.
 */
const std::string StringUtil::EMPTY_STRING;

/**
 * Does nothing.
 */
StringUtil::~StringUtil()
{
}

/**
 * Strips leading whitespace characters from a string.
 */
void StringUtil::stripLeadingWhitespace( std::string& data )
{
    if ( data.size() > 0 ) {
        while ( data.length() > 0 && isspace( data.at(0) ) ) {
            data.erase( 0, 1 );
        }
    }
}

/**
 * Strips trailing whitespace characters from a string.
 */
void StringUtil::stripTrailingWhitespace( std::string& data )
{
    if ( data.size() > 0 ) {
        while ( data.length() > 0 && isspace( data.at( data.size() - 1 ) ) ) {
            data.erase( data.size() - 1 );
        }
    }
}

/**
 * Splits a std::string into tokens.
 *
 * @param line the data to parse/split
 * @param delim if specified this any character from it will be used to
 *              delimit the break between tokens, default is the string
 *              " \t\r\n="
 * @param stripWhitespace if set to true then the tokens returned
 *                        will have leading/trailing whitespace removed,
 *                        default is false
 */
std::vector< std::string > StringUtil::split( const std::string& line,
        const std::string& delim,
        bool stripWhitespace )
{
    std::vector< std:: string > tokens;
    if ( line.size() > 0 ) {
        std::string token;
        for ( std::string::const_iterator pos = line.begin(); pos != line.end(); ++pos ) {
            if ( delim.find(*pos) == std::string::npos ) {
                token += *pos;
            } else {
                if ( stripWhitespace ) {
                    _CORELIB_NAMESPACE::StringUtil::stripWhitespace( token );
                }
                tokens.push_back( token );
                token.erase();
            }
        }
        // We reached the end of the string, push whatever is left
        if ( stripWhitespace ) {
            _CORELIB_NAMESPACE::StringUtil::stripWhitespace( token );
        }
        tokens.push_back( token );
        token.erase();
    }
    return tokens;
}

/**
 * Returns the raw bytes as a hex-ified string.
 *
 * @param bytes a pointer to the raw byte sequence to encode
 * @param length the length of the data in bytes
 */
std::string StringUtil::bytesToHexString( const void* const bytes, size_t length )
{
    std::string rv;
    const char* const data = (const char*) bytes;
    unsigned char theByte;
    char hexByte[2];
    for ( size_t pos = 0; pos < length; ++pos ) {
        theByte = data[pos];
        std::sprintf( hexByte, "%x", (unsigned int) theByte );
        rv.append( hexByte );
    }
    return rv;
}

/**
 * Writes the given hex string as a sequence of bytes, the length written
 * is half that of the hex string, a null byte is NOT appended when finished.
 * It is the callers responsibility to make sure that @code bytes @endcode
 * has @code hexString.size() / 2 @endcode bytes available in its storage.
 *
 * @param hexString the hex string of a byte sequence
 * @param bytes a pointer
 * @return true if there were no problems, false if the input string is not
 *              a multiple of 2 characters or if there is a non-hex digit in
 *              the string
 */
bool StringUtil::hexStringToBytes( const std::string& hexString, char* bytes )
{
    // Do some basic checks to make sure we have a good hex string
    if ( hexString.size() % 2 != 0 ) {
        return false;
    }
    for ( int pos = 0; pos < hexString.size(); ++pos ) {
        if ( std::isxdigit( hexString.at( pos ) ) == 0 ) {
            return false;
        }
    }
    unsigned int theByte;
    for ( int pos = 0; pos < hexString.size(); pos +=2 ) {
        std::sscanf( hexString.substr( pos, 2 ).c_str(), "%x", &theByte );
        bytes[ pos / 2 ] = (char) theByte;
    }
    return true;
}

/**
 * Should not be used until instance methods are added to this class.
 * Does nothing.
 */
StringUtil::StringUtil()
{
}

/**
 * Should not be used until instance methods are added to this class.
 * Does nothing.
 */
StringUtil::StringUtil( const StringUtil& copy )
{
}

#ifdef _CORELIB_USE_NAMESPACE
_CORELIB_NAMESPACE_END
#endif
