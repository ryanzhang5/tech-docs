
#ifndef __CORELIB_STRING_HPP__
#define __CORELIB_STRING_HPP__

#include <vector>
#include <string>

#include "Corelib.hpp"

#ifdef _CORELIB_USE_NAMESPACE
_CORELIB_NAMESPACE_BEGIN
#endif

/**
 * Provides some helper methods for dealing with strings.
 */
class StringUtil
{
    public:

        /**
         * An empty string.
         */
        static const std::string EMPTY_STRING;

        /**
         * Does nothing.
         */
        virtual ~StringUtil();

        /**
         * Strips leading whitespace characters from a string.
         */
        static void stripLeadingWhitespace( std::string& data );

        /**
         * Strips trailing whitespace characters from a string.
         */
        static void stripTrailingWhitespace( std::string& data );

        /**
         * Strips as much whitespace from a std::string object as possible (starting at
         * "start" and maxing out at "end"), starting from the given iterator position.
         * To remove trailing whitespace you can do something like this:
         * stripLeadingWhitespace( string.rbegin(), string.rend() ).
         */
        static inline void stripWhitespace( std::string& data )
        {
            stripLeadingWhitespace( data );
            stripTrailingWhitespace( data );
        }

        /**
         * Splits a std::string into tokens.
         *
         * @param line the data to parse/split
         * @param delim if specified this any character from it will be used to
         *              delimit the break between tokens, default is the string
         *              " \t\r\n="
         * @param stripWhitespace if set to true then the tokens returned
         *                        will have leading/trailing whitespace removed,
         *                        default is false
         */
        static std::vector< std::string > split( const std::string& line,
                const std::string& delim = " \t\r\n=",
                bool stripWhitespace = false );

        /**
         * Returns the raw bytes as a hex-ified string.
         *
         * @param bytes a pointer to the raw byte sequence to encode
         * @param length the length of the data in bytes
         */
        static std::string bytesToHexString( const void* const bytes, size_t length );

        /**
         * Writes the given hex string as a sequence of bytes, the length written
         * is half that of the hex string, a null byte is NOT appended when finished.
         * It is the callers responsibility to make sure that @code bytes @endcode
         * has @code hexString.size() / 2 @endcode bytes available in its storage.
         *
         * @param hexString the hex string of a byte sequence
         * @param bytes a pointer
         * @return true if there were no problems, false if the input string is not
         *              a multiple of 2 characters or if there is a non-hex digit in
         *              the string
         */
        static bool StringUtil::hexStringToBytes( const std::string& hexString, char* bytes );

    private:

        /**
         * Should not be used until instance methods are added to this class.
         * Does nothing.
         */
        StringUtil();

        /**
         * Should not be used until instance methods are added to this class.
         * Does nothing.
         */
        StringUtil( const StringUtil& copy );

};

#ifdef _CORELIB_USE_NAMESPACE
_CORELIB_NAMESPACE_END
#endif

#endif // __CORELIB_STRING_HPP__
