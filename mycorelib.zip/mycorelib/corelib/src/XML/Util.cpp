
#include "Util.hpp"

// We use libxml++ for XML parsing/generation
#include <libxml++/libxml++.h>

// Constants for XML element names, note that since they are static
// and can't be seen by anyone anyway, they are OUTSIDE the corelib
// namespace so that they don't need a "corelib::" prefix
static const std::string XML_ENCODING     ( "UTF-8" );
static const std::string DOCUMENT_ELEMENT ( "nvpair" );
static const std::string NAME_ELEMENT     ( "name" );
static const std::string VALUE_ELEMENT    ( "value" );

#ifdef _CORELIB_USE_NAMESPACE
    _CORELIB_NAMESPACE_BEGIN
#endif

class XMLNameValueParser
    : public virtual xmlpp::SaxParser
{

    public:

        // Creates a new parser, name/value pairs that are parsed will be
        // stored in
        XMLNameValueParser( std::vector< std::pair< std::string, std::string > >& pairsContainer );

        // Copy constructor, creates an empty parser with the same
        // reference to the vector of name/value pairs to store values
        // into
        XMLNameValueParser( const XMLNameValueParser& copy );

        // Virtual destructor
        virtual ~XMLNameValueParser();

        // SAX API, overrides xmlpp::SaxParser [null] implementation
        virtual void parse_stream ( std::istream &in ); // libxml++'s implementation is broken
        virtual void on_start_element ( const std::string &name,
                const xmlpp::SaxParser::AttributeList &attributes );
        virtual void on_end_element ( const std::string &name );
        virtual void on_characters ( const std::string &characters );

    protected:

        // reference to supplied name/value container
        std::vector< std::pair< std::string, std::string > >* pairs;

    private:

        // Default constructor
        XMLNameValueParser();

        std::string currentElement;
        std::string currentName;
        std::string currentValue;

};

XMLNameValueParser::XMLNameValueParser()
    : pairs( 0 )
{
    // This should never be called
}

XMLNameValueParser::XMLNameValueParser( std::vector< std::pair< std::string, std::string > >& pairsContainer )
    : xmlpp::SaxParser( false ), pairs( &pairsContainer )
{
}

XMLNameValueParser::XMLNameValueParser( const XMLNameValueParser& copy )
    : xmlpp::SaxParser( false ), pairs( copy.pairs )
{
}

// Virtual destructor
XMLNameValueParser::~XMLNameValueParser()
{
    // Release our pointer but do not destroy the contents:
    // this was passed to use by the creator of the parser
    // so they are responsible for its cleanup
    pairs = 0;
}

// We override xmlpp::SaxParser::parse_stream(std::istream&) because their
// implementation is broken, and for our purposes a workaround is pretty easy
void XMLNameValueParser::parse_stream( std::istream &in )
{
    char buffer[2*1024];
    int bytesRead;
    std::string* chunk(0);
    do {
        in.read( buffer, 2*1024 );
        bytesRead = in.gcount();
        chunk = new std::string( buffer, bytesRead );
        parse_chunk( *chunk );
        delete chunk;
        chunk = 0;
    } while ( in );
    finish_chunk_parsing();
}

// Clear out our state data for the appropriate element
void XMLNameValueParser::on_start_element( const std::string &name,
        const xmlpp::SaxParser::AttributeList &attributes )
{
    currentElement = name;
    if ( currentElement == NAME_ELEMENT ) {
        currentName.erase();
    } else if ( currentElement == VALUE_ELEMENT ) {
        currentValue.erase();
    }
}

// If we are at the end of a <value> tag, add the name/value
// pair to the container
void XMLNameValueParser::on_end_element( const std::string &name )
{
    if ( name == VALUE_ELEMENT ) {
        pairs->push_back( std::make_pair< std::string, std::string > ( currentName, currentValue ) );
    }
    currentElement.erase();
}

// Append the characters to the appropriate state data variable
void XMLNameValueParser::on_characters ( const std::string &characters )
{
    if ( currentElement == NAME_ELEMENT ) {
        currentName += characters;
    } else if ( currentElement == VALUE_ELEMENT ) {
        currentValue += characters;
    }
}

/**
 * Does nothing, should be kept private until instance methods
 * are added to this class.
 */
XMLUtil::XMLUtil()
{
}

/**
 * Does nothing, should be kept private until instance methods
 * are added to this class.
 */
XMLUtil::XMLUtil( const XMLUtil& copy )
{
}

/**
 * Does nothing.
 */
XMLUtil::~XMLUtil()
{
}

/**
 * Loads a std::vector of name/value pairs from an XML stream,
 * it is very much assumed that the stream contains data generated
 * from the store( std::ostream& ) method.
 */
std::vector< std::pair< std::string,std::string > > XMLUtil::load( std::istream& in )
{
    std::vector< std::pair< std::string,std::string > > pairs;
    _CORELIB_NAMESPACE::XMLNameValueParser parser( pairs );
    parser.parse_stream( in );
}

/**
 * Stores the name/value pairs as XML, writing to the output stream.
 */
void XMLUtil::store( std::ostream& out, std::vector< std::pair< std::string,std::string > >& pairs )
{
    xmlpp::Document xmlDocument;
    xmlpp::Element* rootElement = xmlDocument.create_root_node( DOCUMENT_ELEMENT );
    xmlpp::Element* nodePtr = 0;
    for ( std::vector< std::pair< std::string, std::string > >::const_iterator pos = pairs.begin();
            pos != pairs.end(); ++pos ) {
        nodePtr = rootElement->add_child( NAME_ELEMENT );
        nodePtr->set_child_text( (*pos).first );
        nodePtr = rootElement->add_child( VALUE_ELEMENT );
        nodePtr->set_child_text( (*pos).second );
    }
    rootElement = nodePtr = 0;
    xmlDocument.write_to_stream_formatted( out, XML_ENCODING );
}

#ifdef _CORELIB_USE_NAMESPACE
    _CORELIB_NAMESPACE_END
#endif
