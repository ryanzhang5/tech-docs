
////////////////////////////////////////////////////////////////////////////////
//
// XML utility classes/functions
//
////////////////////////////////////////////////////////////////////////////////

#ifndef __CORELIB_XML_HPP__
#define __CORELIB_XML_HPP__

#include <fstream>
#include <istream>
#include <ostream>
#include <vector>
#include <string>

#include "Corelib.hpp"

#ifdef _CORELIB_USE_NAMESPACE
_CORELIB_NAMESPACE_BEGIN
#endif

/**
 * XML utility class.
 */
class XMLUtil
{
    public:

        /**
         * Does nothing.
         */
        virtual ~XMLUtil();

        /**
         * Loads a std::vector of name/value pairs from an XML stream,
         * it is very much assumed that the stream contains data generated
         * from the store( std::ostream& ) method.
         */
        static std::vector< std::pair< std::string,std::string > > load( std::istream& in );

        /**
         * Loads a std::vector of name/value pairs from an XML file,
         * it is very much assumed that the file contains data generated
         * from the store( std::ostream& ) method.
         */
        static inline std::vector< std::pair< std::string,std::string > > load( std::string& filename )
        {
            std::ifstream in( filename.c_str() );
            return load( in );
        }

        /**
         * Stores the name/value pairs as XML, writing to the output stream.
         */
        static void store( std::ostream& out, std::vector< std::pair< std::string,std::string > >& pairs );

        /**
         * Stores the name/value pairs as XML, writing to the output file.
         */
        static inline void store( std::string& filename, std::vector< std::pair< std::string,std::string > >& pairs )
        {
            std::ofstream out( filename.c_str() );
            store( out, pairs );
        }

    private:

        /**
         * Does nothing, should be kept private until instance methods
         * are added to this class.
         */
        XMLUtil();

        /**
         * Does nothing, should be kept private until instance methods
         * are added to this class.
         */
        XMLUtil( const XMLUtil& copy );
};

#ifdef _CORELIB_USE_NAMESPACE
_CORELIB_NAMESPACE_END
#endif

#endif // __CORELIB_XML_HPP__
