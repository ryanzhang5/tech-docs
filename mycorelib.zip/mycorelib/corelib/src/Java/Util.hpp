
#ifndef __CORELIB_JAVA_HPP__
#define __CORELIB_JAVA_HPP__

////////////////////////////////////////////////////////////////////////////////
//
// Java utility classes/functions
//
////////////////////////////////////////////////////////////////////////////////

#include <fstream>
#include <istream>
#include <ostream>
#include <vector>
#include <string>

#include "Corelib.hpp"

#ifdef _CORELIB_USE_NAMESPACE
_CORELIB_NAMESPACE_BEGIN
#endif

/**
 * Utility class for dealing with java from c++.
 */
class JavaUtil
{
    public:

        /**
         * Virtual destructor, does nothing.
         */
        virtual ~JavaUtil();

        /**
         * Loads/parses a java properties file from the given stream.
         * The stream is read and is expected to contain data in the
         * format of a java properties file.
         *
         * @return a std::vector of name/value pair strings
         */
        static std::vector< std::pair< std::string, std::string > > load( std::istream& in );

        /**
         * Loads/parses a java properties file from the given filename.
         * The java properties file denoted by filename is read and is
         * expected to contain data in the format of a java properties
         * file.
         *
         * @return a std::vector of name/value pair strings
         */
        static inline std::vector< std::pair< std::string, std::string > > load( const std::string& filename )
        {
            std::ifstream in( filename.c_str() );
            return load( in );
        }

        /**
         * Writes the list of properties in java properties format to the stream.
         *
         * @param out the stream to write the properties to
         * @param props the list of properties to write
         */
        static void store( std::ostream& out,
                std::vector< std::pair< std::string, std::string > >& props );

        /**
         * Writes the list of properties in java properties format to the
         * given file.
         *
         * @param filename the file to create/append the properties to
         * @param props the list of properties to write
         */
        static inline void store( const std::string& filename,
                std::vector< std::pair< std::string, std::string > >& props )
        {
            std::ofstream out( filename.c_str() );
            store( out, props );
        }

    private:

        /**
         * Private, should never be called unless instance methods are added
         * to this class. Does nothing.
         */
        JavaUtil();

        /**
         * Private, should never be called unless instance methods are added
         * to this class. Does nothing.
         */
        JavaUtil( const JavaUtil& copy );
};

#ifdef _CORELIB_USE_NAMESPACE
_CORELIB_NAMESPACE_END
#endif

#endif // __CORELIB_JAVA_HPP__
