
#include <fstream>

#include "Java/Util.hpp"
#include "String/Util.hpp"

#ifdef _CORELIB_USE_NAMESPACE
_CORELIB_NAMESPACE_BEGIN
#endif

/**
 * Private, should never be called unless instance methods are added
 * to this class. Does nothing.
 */
JavaUtil::JavaUtil()
{
}

/**
 * Private, should never be called unless instance methods are added
 * to this class. Does nothing.
 */
JavaUtil::JavaUtil( const JavaUtil& copy )
{
}

/**
 * Virtual destructor, does nothing.
 */
JavaUtil::~JavaUtil()
{
}

/**
 * Loads/parses a java properties file from the given stream.
 * The stream is read and is expected to contain data in the
 * format of a java properties file.
 *
 * @return a std::vector of name/value pair strings
 */
std::vector< std::pair< std::string, std::string > > JavaUtil::load( std::istream& in )
{
    // This is the list of valid separators for a key/value combination inside
    // a java properties file -- taken directly from the 1.4.2_03 JDK source code,
    // the STRICT_SEPARATORS is a subset of non-whitespace separators.
    //
    // The documentation for the java properties file format is given in detail
    // in the API JavaDocs for the java.util.Properties.load() method.
    static const std::string SEPARATORS( "=: \t\r\n\f" );
    static const std::string STRICT_SEPARATORS( "=:" );

    std::vector< std::pair< std::string, std::string > > pairs;
    std::string line;
    int numBackslashes( 0 );
    for ( ; getline( in, line ); ) {
        _CORELIB_NAMESPACE::StringUtil::stripWhitespace( line );
        if ( line.size() == 0 || line.at( 0 ) == '!' || line.at( 0 ) == '#' ) {
            // We ignore empty or all-whitespace lines as well as comment lines
            continue;
        }

        // See if we need to continue reading lines, if so the line will end with
        // an odd number of backslash characters
        numBackslashes = 0;
        for ( int pos = line.size() - 1; pos >= 0; --pos ) {
            if ( line.at( pos ) == '\\' ) {
                ++numBackslashes;
            } else {
                break;
            }
        }

        // As long as we have an odd number of backslashes at the end of the
        // line, we need to read the next line of input and append it
        while ( numBackslashes % 2 == 1 ) {
            // Strip the last backslash off of the current line
            line.erase( line.size() - 1 );

            // Grab the next line of input and strip any leading whitespace
            std::string continuationLine;
            getline( in, continuationLine );
            _CORELIB_NAMESPACE::StringUtil::stripWhitespace( continuationLine );

            // Append the continuation line to the current one
            line += continuationLine;

            // Reset our backslash count to see if we need to continue again
            numBackslashes = 0;
            for ( int pos = line.size() - 1; pos >= 0; --pos ) {
                if ( line.at( pos ) == '\\' ) {
                    ++numBackslashes;
                } else {
                    break;
                }
            }
        }

        // At this point we actually have our entire line of input, now
        // we just need to find the index of the separator character and
        // can make a new pair based on the data on either side
        int separatorIdx( 0 );
        for ( separatorIdx = 0; separatorIdx < line.size(); ++separatorIdx ) {
            if ( line.at( separatorIdx ) == '\\' ) {
                // Skip the next character as this one is escaped
                ++separatorIdx;
            } else if ( SEPARATORS.find( line.at( separatorIdx ) ) != std::string::npos ) {
                break;
            }
        }
        std::string key( line.substr( 0, separatorIdx ) );
        // We may not have a value: make sure we have some length left after our
        // separator character before trying to get a substring from it
        std::string value( line.size() > (separatorIdx+1) ?
                line.substr( separatorIdx + 1 ) : _CORELIB_NAMESPACE::StringUtil::EMPTY_STRING );

        // It is possible that if the initial separator was whitespace then the
        // first (non-whitespace) character of the value could be a
        // STRICT_SEPARATOR character, as would be the case with the following
        // example:
        //
        //    my_key    =    my_value
        //          |   |    |
        //          |   |    |
        //          |   |    +-> the real start of the value
        //          |   |
        //          |   +------> the STRICT_SEPARATOR that needs to be removed
        //          |
        //          +----------> current value of separatorIdx
        //
        // No matter what we first get rid of any value whitespace, the if the
        // separator character is whitespace AND the first character of the
        // value is a STRICT_SEPARATOR, then we need to remove the first
        // character, and then again strip any leading whitespace
        _CORELIB_NAMESPACE::StringUtil::stripLeadingWhitespace( value );
        if ( separatorIdx < line.size()
                && std::isspace( line.at( separatorIdx ) )
                && value.size() > 0
                && STRICT_SEPARATORS.find( value.at( 0 ) ) != std::string::npos ) {
            // Remove the first character of the value and strip any remaining leading
            // whitespace after that
            value.erase( 0, 1 );
            _CORELIB_NAMESPACE::StringUtil::stripLeadingWhitespace( value );
        }
        pairs.push_back( std::make_pair< std::string, std::string >( key, value ) );
    }

    return pairs;
}

/**
 * Writes the list of properties in java properties format to the stream.
 *
 * @param out the stream to write the properties to
 * @param props the list of properties to write
 */
void JavaUtil::store( std::ostream& out,
        std::vector< std::pair< std::string, std::string > >& props )
{
    static const std::string SEPARATOR( " = " );
    for ( std::vector< std::pair< std::string, std::string > >::const_iterator pos = props.begin();
            pos != props.end(); ++pos ) {
        out << pos->first << SEPARATOR << pos->second << std::endl;
    }
}

#ifdef _CORELIB_USE_NAMESPACE
_CORELIB_NAMESPACE_END
#endif
