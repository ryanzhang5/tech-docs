
////////////////////////////////////////////////////////////////////////////////
//
// Common definitions/declarations for corelib components
//
////////////////////////////////////////////////////////////////////////////////

#include "corelib-config.h"

// The corelib namespace
#ifdef _CORELIB_USE_NAMESPACE
#   define _CORELIB_NAMESPACE corelib
#   define _CORELIB_NAMESPACE_BEGIN namespace _CORELIB_NAMESPACE {
#   define _CORELIB_NAMESPACE_END   }
#else
#   define _CORELIB_NAMESPACE
#   define _CORELIB_NAMESPACE_BEGIN
#   define _CORELIB_NAMESPACE_END
#endif

