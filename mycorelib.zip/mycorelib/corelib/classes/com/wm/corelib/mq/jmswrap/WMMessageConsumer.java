package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMMessageConsumer implements MessageConsumer {

  public String toString() {
    return getNativeMessageConsumerImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public String getMessageSelector() throws JMSException {
    String rv = getNativeMessageConsumerImpl().getMessageSelector();
    if (rv == null) { return null; }
    return rv;
  }

  public MessageListener getMessageListener() throws JMSException {
    MessageListener rv = getNativeMessageConsumerImpl().getMessageListener();
    if (rv == null) { return null; }
    rv = (MessageListener)WMMessageListener.newInstance((MessageListener)rv);
    return rv;
  }

  public void setMessageListener(MessageListener listener) throws JMSException {
    MessageListener arg0 = (listener instanceof WMMessageListener) ? ((WMMessageListener)listener).getNativeMessageListenerImpl() : listener;
    getNativeMessageConsumerImpl().setMessageListener(arg0);
  }

  public Message receive() throws JMSException {
    Message rv = getNativeMessageConsumerImpl().receive();
    if (rv == null) { return null; }
    else if (rv instanceof TextMessage) {
      rv = (Message)WMTextMessage.newInstance((TextMessage)rv);
    }
    else if (rv instanceof StreamMessage) {
      rv = (Message)WMStreamMessage.newInstance((StreamMessage)rv);
    }
    else if (rv instanceof ObjectMessage) {
      rv = (Message)WMObjectMessage.newInstance((ObjectMessage)rv);
    }
    else if (rv instanceof MapMessage) {
      rv = (Message)WMMapMessage.newInstance((MapMessage)rv);
    }
    else if (rv instanceof BytesMessage) {
      rv = (Message)WMBytesMessage.newInstance((BytesMessage)rv);
    }
    else {
      rv = (Message)WMMessage.newInstance((Message)rv);
    }
    return rv;
  }

  public Message receive(long timeout) throws JMSException {
    long arg0 = timeout;
    Message rv = getNativeMessageConsumerImpl().receive(arg0);
    if (rv == null) { return null; }
    else if (rv instanceof TextMessage) {
      rv = (Message)WMTextMessage.newInstance((TextMessage)rv);
    }
    else if (rv instanceof StreamMessage) {
      rv = (Message)WMStreamMessage.newInstance((StreamMessage)rv);
    }
    else if (rv instanceof ObjectMessage) {
      rv = (Message)WMObjectMessage.newInstance((ObjectMessage)rv);
    }
    else if (rv instanceof MapMessage) {
      rv = (Message)WMMapMessage.newInstance((MapMessage)rv);
    }
    else if (rv instanceof BytesMessage) {
      rv = (Message)WMBytesMessage.newInstance((BytesMessage)rv);
    }
    else {
      rv = (Message)WMMessage.newInstance((Message)rv);
    }
    return rv;
  }

  public Message receiveNoWait() throws JMSException {
    Message rv = getNativeMessageConsumerImpl().receiveNoWait();
    if (rv == null) { return null; }
    else if (rv instanceof TextMessage) {
      rv = (Message)WMTextMessage.newInstance((TextMessage)rv);
    }
    else if (rv instanceof StreamMessage) {
      rv = (Message)WMStreamMessage.newInstance((StreamMessage)rv);
    }
    else if (rv instanceof ObjectMessage) {
      rv = (Message)WMObjectMessage.newInstance((ObjectMessage)rv);
    }
    else if (rv instanceof MapMessage) {
      rv = (Message)WMMapMessage.newInstance((MapMessage)rv);
    }
    else if (rv instanceof BytesMessage) {
      rv = (Message)WMBytesMessage.newInstance((BytesMessage)rv);
    }
    else {
      rv = (Message)WMMessage.newInstance((Message)rv);
    }
    return rv;
  }

  public void close() throws JMSException {
    getNativeMessageConsumerImpl().close();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMMessageConsumer newInstance(MessageConsumer nativeImpl) {
    try {
      WMMessageConsumer newObj = (WMMessageConsumer)_clazz.newInstance();
      newObj.setNativeMessageConsumerImpl(nativeImpl);
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected MessageConsumer getNativeMessageConsumerImpl() {
    return _messageConsumerImpl;
  }

  protected void setNativeMessageConsumerImpl(MessageConsumer nativeImpl) {
    _messageConsumerImpl = nativeImpl;
  }

  protected WMMessageConsumer() { }
  private MessageConsumer _messageConsumerImpl = null;
  private static Class _clazz = WMMessageConsumer.class;
}
