package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMExceptionListener implements ExceptionListener {

  public String toString() {
    return getNativeExceptionListenerImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public void onException(JMSException exception)  {
    JMSException arg0 = exception;
    getNativeExceptionListenerImpl().onException(arg0);
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMExceptionListener newInstance(ExceptionListener nativeImpl) {
    try {
      WMExceptionListener newObj = (WMExceptionListener)_clazz.newInstance();
      newObj.setNativeExceptionListenerImpl(nativeImpl);
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected ExceptionListener getNativeExceptionListenerImpl() {
    return _exceptionListenerImpl;
  }

  protected void setNativeExceptionListenerImpl(ExceptionListener nativeImpl) {
    _exceptionListenerImpl = nativeImpl;
  }

  protected WMExceptionListener() { }
  private ExceptionListener _exceptionListenerImpl = null;
  private static Class _clazz = WMExceptionListener.class;
}
