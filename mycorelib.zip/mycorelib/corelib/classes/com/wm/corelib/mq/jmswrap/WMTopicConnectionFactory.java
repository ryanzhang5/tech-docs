package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMTopicConnectionFactory extends WMConnectionFactory implements TopicConnectionFactory {

  public String toString() {
    return getNativeTopicConnectionFactoryImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public TopicConnection createTopicConnection() throws JMSException {
    TopicConnection rv = getNativeTopicConnectionFactoryImpl().createTopicConnection();
    if (rv == null) { return null; }
    else if (rv instanceof XATopicConnection) {
      rv = (TopicConnection)WMXATopicConnection.newInstance((XATopicConnection)rv);
    }
    else {
      rv = (TopicConnection)WMTopicConnection.newInstance((TopicConnection)rv);
    }
    return rv;
  }

  public TopicConnection createTopicConnection(String userName, String password) throws JMSException {
    String arg0 = userName;
    String arg1 = password;
    TopicConnection rv = getNativeTopicConnectionFactoryImpl().createTopicConnection(arg0, arg1);
    if (rv == null) { return null; }
    else if (rv instanceof XATopicConnection) {
      rv = (TopicConnection)WMXATopicConnection.newInstance((XATopicConnection)rv);
    }
    else {
      rv = (TopicConnection)WMTopicConnection.newInstance((TopicConnection)rv);
    }
    return rv;
  }



  //////////////////
  // inherited methods from class ConnectionFactory (proxy to custom WM objects)
  //////////////////


  public static void setClass(Class c) { _clazz = c; }

  public static WMTopicConnectionFactory newInstance(TopicConnectionFactory nativeImpl) {
    try {
      WMTopicConnectionFactory newObj = (WMTopicConnectionFactory)_clazz.newInstance();
      newObj.setNativeTopicConnectionFactoryImpl(nativeImpl);
      newObj.setNativeConnectionFactoryImpl((ConnectionFactory)nativeImpl);
      newObj.setInternalConnectionFactoryImpl(WMConnectionFactory.newInstance((ConnectionFactory)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected TopicConnectionFactory getNativeTopicConnectionFactoryImpl() {
    return _topicConnectionFactoryImpl;
  }

  protected void setNativeTopicConnectionFactoryImpl(TopicConnectionFactory nativeImpl) {
    _topicConnectionFactoryImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe ConnectionFactory
  //////////////////
  private WMConnectionFactory _internalConnectionFactoryImpl = null;
  private WMConnectionFactory getInternalConnectionFactoryImpl() {
    return _internalConnectionFactoryImpl;
  }

  private void setInternalConnectionFactoryImpl(WMConnectionFactory nativeImpl) {
    _internalConnectionFactoryImpl = nativeImpl;
  }

  protected WMTopicConnectionFactory() { }
  private TopicConnectionFactory _topicConnectionFactoryImpl = null;
  private static Class _clazz = WMTopicConnectionFactory.class;
}
