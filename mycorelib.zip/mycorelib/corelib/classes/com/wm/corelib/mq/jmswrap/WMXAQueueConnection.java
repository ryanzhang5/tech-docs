package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMXAQueueConnection extends WMQueueConnection implements XAConnection, XAQueueConnection {

  public String toString() {
    return getNativeXAQueueConnectionImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public XAQueueSession createXAQueueSession() throws JMSException {
    XAQueueSession rv = getNativeXAQueueConnectionImpl().createXAQueueSession();
    if (rv == null) { return null; }
    rv = (XAQueueSession)WMXAQueueSession.newInstance((XAQueueSession)rv);
    return rv;
  }

  public QueueSession createQueueSession(boolean transacted, int acknowledgeMode) throws JMSException {
    boolean arg0 = transacted;
    int arg1 = acknowledgeMode;
    QueueSession rv = getNativeXAQueueConnectionImpl().createQueueSession(arg0, arg1);
    if (rv == null) { return null; }
    rv = (QueueSession)WMQueueSession.newInstance((QueueSession)rv);
    return rv;
  }



  //////////////////
  // inherited methods from class Connection (proxy to custom WM objects)
  //////////////////
  public String getClientID() throws JMSException {
    return getInternalConnectionImpl().getClientID();
  }

  public void setClientID(String clientID) throws JMSException {
    getInternalConnectionImpl().setClientID(clientID);
  }

  public ConnectionMetaData getMetaData() throws JMSException {
    return getInternalConnectionImpl().getMetaData();
  }

  public ExceptionListener getExceptionListener() throws JMSException {
    return getInternalConnectionImpl().getExceptionListener();
  }

  public void setExceptionListener(ExceptionListener listener) throws JMSException {
    getInternalConnectionImpl().setExceptionListener(listener);
  }

  public void start() throws JMSException {
    getInternalConnectionImpl().start();
  }

  public void stop() throws JMSException {
    getInternalConnectionImpl().stop();
  }

  public void close() throws JMSException {
    getInternalConnectionImpl().close();
  }



  //////////////////
  // inherited methods from class QueueConnection (proxy to custom WM objects)
  //////////////////
  public ConnectionConsumer createConnectionConsumer(Queue queue, String messageSelector, ServerSessionPool sessionPool, int maxMessages) throws JMSException {
    return getInternalQueueConnectionImpl().createConnectionConsumer(queue, messageSelector, sessionPool, maxMessages);
  }



  //////////////////
  // inherited methods from class XAConnection (proxy to custom WM objects)
  //////////////////


  public static void setClass(Class c) { _clazz = c; }

  public static WMXAQueueConnection newInstance(XAQueueConnection nativeImpl) {
    try {
      WMXAQueueConnection newObj = (WMXAQueueConnection)_clazz.newInstance();
      newObj.setNativeXAQueueConnectionImpl(nativeImpl);
      newObj.setNativeConnectionImpl((Connection)nativeImpl);
      newObj.setInternalConnectionImpl(WMConnection.newInstance((Connection)nativeImpl));
      newObj.setNativeQueueConnectionImpl((QueueConnection)nativeImpl);
      newObj.setInternalQueueConnectionImpl(WMQueueConnection.newInstance((QueueConnection)nativeImpl));
      newObj.setInternalXAConnectionImpl(WMXAConnection.newInstance((XAConnection)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected XAQueueConnection getNativeXAQueueConnectionImpl() {
    return _xAQueueConnectionImpl;
  }

  protected void setNativeXAQueueConnectionImpl(XAQueueConnection nativeImpl) {
    _xAQueueConnectionImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe Connection
  //////////////////
  private WMConnection _internalConnectionImpl = null;
  private WMConnection getInternalConnectionImpl() {
    return _internalConnectionImpl;
  }

  private void setInternalConnectionImpl(WMConnection nativeImpl) {
    _internalConnectionImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe QueueConnection
  //////////////////
  private WMQueueConnection _internalQueueConnectionImpl = null;
  private WMQueueConnection getInternalQueueConnectionImpl() {
    return _internalQueueConnectionImpl;
  }

  private void setInternalQueueConnectionImpl(WMQueueConnection nativeImpl) {
    _internalQueueConnectionImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe XAConnection
  //////////////////
  private WMXAConnection _internalXAConnectionImpl = null;
  private WMXAConnection getInternalXAConnectionImpl() {
    return _internalXAConnectionImpl;
  }

  private void setInternalXAConnectionImpl(WMXAConnection nativeImpl) {
    _internalXAConnectionImpl = nativeImpl;
  }

  protected WMXAQueueConnection() { }
  private XAQueueConnection _xAQueueConnectionImpl = null;
  private static Class _clazz = WMXAQueueConnection.class;
}
