package com.wm.corelib.mq;

import javax.jms.*;

public class WMDeliveryMode extends com.wm.corelib.mq.jmswrap.WMDeliveryMode {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.DeliveryMode interface
  ////////////////////////////////

}
