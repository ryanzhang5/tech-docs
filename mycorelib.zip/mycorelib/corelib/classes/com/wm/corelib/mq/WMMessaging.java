package com.wm.corelib.mq;

import javax.jms.*;
import java.net.URI;
import com.ibm.mq.jms.JMSC;

public final class WMMessaging
{
  /**
   * Default TCP port to use when connecting to an MQSeries server.
   */
  public static final int MQSERIES_DEFAULT_PORT = 1414;
  
  /**
   * Encoding to use when URLEncoding/URLDecoding string MQ message
   * headers; IBM MQSeries has a bug exposed in JMS where setting a String
   * header with a leading forward slash corrupts the queue the message
   * gets placed into.  So, all String headers are URLEncoded for safety.
   * Note: this bug is only present in the version 5.2 JMS libraries
   * from IBM. Upgrading your client libraries will rid you of the 
   * bug (your server can still be version 5.2)
   */
  public static final String MQSERIES_STRING_HEADER_ENCODING = "UTF-8";
  
  public static QueueConnectionFactory createQueueConnectionFactory(String hostName, String qMgr,
                                                                    String channel) throws JMSException
  { 
    return createQueueConnectionFactory(qMgr, hostName, channel, MQSERIES_DEFAULT_PORT);
  }
  
  public static QueueConnectionFactory createQueueConnectionFactory(String hostName, String qMgr,
                                                                    String channel, int port) throws JMSException 
  {
    return createQueueConnectionFactory(qMgr, hostName, channel, port, JMSC.MQJMS_TP_CLIENT_MQ_TCPIP);
  }
  
  
  public static QueueConnectionFactory createQueueConnectionFactory(String hostName, String qMgr,
                                                                    String channel, int port,
                                                                    int transportType) throws JMSException
  {
    return getInstance()._createQueueConnectionFactory(qMgr, hostName, channel, port, transportType);
  }
  
  // XXX: need static methods for TopicCxnFactory's too  

  /**
   * Creates an MQSeries-backed javax.jms.QueueConnectionFactory object
   * with the specified URI, it is expected that the URI is in the following
   * format:
   * <code>mqseries://[username:password@]hostname[:port]/queueManager/channel/queue</code>.
   * If not in this form then no information is parsed from the URI which may
   * cause the MQSeries library to throw a JMSException.
   * <p>
   * <font color="red">NOTE to application developers</font>: Currently the
   * username and password are not used.
   */
  private static QueueConnectionFactory createQueueConnectionFactory(URI uri) throws JMSException {
    String hostname     = null;
    String queueManager = null;
    String channel      = null;
    int    port         = MQSERIES_DEFAULT_PORT;
    if ( uri != null && "mqseries".toLowerCase().equals(uri.getScheme())) {
      hostname = uri.getHost();
      queueManager = getQueueManagerName(uri);
      channel = getChannelName(uri);
      if (uri.getPort() != -1) {
        port = uri.getPort();
      }
    } // uri != null
    return createQueueConnectionFactory( hostname, queueManager, channel, port );
  }
  
  /**
   * Utility method to parse the queue manager name from an mqseries:// URI.
   */
  public static String getQueueManagerName(URI uri) {
    return getURIPart(uri, 0);
  }
  
  /**
   * Utility method to parse the channel name from an mqseries:// URI.
   */
  public static String getChannelName(URI uri) {
    return getURIPart(uri, 1);
  }

  /**
   * Utility method to parse the queue name from an mqseries:// URI.
   */
  public static String getQueueName(URI uri) {
    return getURIPart(uri, 2);
  }

  
  /**
   * Utility method to parse out the username from a URI object.
   */
  public static String getUsername(URI uri) {
    return getUsernamePasswordPart(uri, 0);
  }
  
  /**
   * Utility method to parse out the password from a URI object.
   */
  public static String getPassword(URI uri) {
    return getUsernamePasswordPart(uri, 1);
  }
  
  
  private static String getUsernamePasswordPart(URI uri, int partNumber) {
    String rv = null;
    if ( uri != null ) {
      String userinfo = uri.getUserInfo();
      String[] userPass = ( userinfo == null ? null : userinfo.split( ":" ) );
      if ( userPass != null && userPass.length > partNumber ) {
        rv = userPass[partNumber];
      }
    }
    return rv;
  }
 
  private static String getURIPart(URI uri, int partNumber) {
    String rv = null;
    if ( uri != null ) {
      String fullRelativePath = uri.getPath().replaceFirst( "^/", "" );
      String[] pathParts = fullRelativePath.split( "/" );
      if ( pathParts != null && pathParts.length > partNumber ) {
        rv = pathParts[partNumber];
      }
    }
    return rv;
  }
  
  private WMMessaging() { 
    // nothing yet
  }
  
  private static synchronized WMMessaging getInstance() {
    if (_theInstance == null) {
      _theInstance = new WMMessaging();
    }  
    
    return _theInstance;
  }
  
  private QueueConnectionFactory _createQueueConnectionFactory(String qMgr, String hostName, 
                                                               String channel, int port, int transportType) throws JMSException
  {
    // XXX: should we cache connection factory instances?
    
    // Plug in JNDI support here if we ever decide that is something we want to do
    // XXX: actually this would probably be a different signature
    
    com.ibm.mq.jms.MQQueueConnectionFactory factory = new com.ibm.mq.jms.MQQueueConnectionFactory();
    factory.setTransportType(transportType);
    factory.setQueueManager(qMgr);
    factory.setHostName(hostName);
    factory.setPort(port);
    factory.setChannel(channel);
    //return (QueueConnectionFactory)factory;
    return (QueueConnectionFactory)WMQueueConnectionFactory.newInstance(factory);
  }
  
  private static WMMessaging _theInstance = null;

  static {
    com.wm.corelib.mq.jmswrap.WMBytesMessage.setClass(WMBytesMessage.class);
    com.wm.corelib.mq.jmswrap.WMConnection.setClass(WMConnection.class);
    com.wm.corelib.mq.jmswrap.WMConnectionConsumer.setClass(WMConnectionConsumer.class);
    com.wm.corelib.mq.jmswrap.WMConnectionFactory.setClass(WMConnectionFactory.class);
    com.wm.corelib.mq.jmswrap.WMConnectionMetaData.setClass(WMConnectionMetaData.class);
    com.wm.corelib.mq.jmswrap.WMDeliveryMode.setClass(WMDeliveryMode.class);
    com.wm.corelib.mq.jmswrap.WMDestination.setClass(WMDestination.class);
    com.wm.corelib.mq.jmswrap.WMExceptionListener.setClass(WMExceptionListener.class);
    com.wm.corelib.mq.jmswrap.WMMapMessage.setClass(WMMapMessage.class);
    com.wm.corelib.mq.jmswrap.WMMessage.setClass(WMMessage.class);
    com.wm.corelib.mq.jmswrap.WMMessageConsumer.setClass(WMMessageConsumer.class);
    com.wm.corelib.mq.jmswrap.WMMessageListener.setClass(WMMessageListener.class);
    com.wm.corelib.mq.jmswrap.WMMessageProducer.setClass(WMMessageProducer.class);
    com.wm.corelib.mq.jmswrap.WMObjectMessage.setClass(WMObjectMessage.class);
    com.wm.corelib.mq.jmswrap.WMQueue.setClass(WMQueue.class);
    com.wm.corelib.mq.jmswrap.WMQueueBrowser.setClass(WMQueueBrowser.class);
    com.wm.corelib.mq.jmswrap.WMQueueConnection.setClass(WMQueueConnection.class);
    com.wm.corelib.mq.jmswrap.WMQueueConnectionFactory.setClass(WMQueueConnectionFactory.class);
    com.wm.corelib.mq.jmswrap.WMQueueReceiver.setClass(WMQueueReceiver.class);
    com.wm.corelib.mq.jmswrap.WMQueueSender.setClass(WMQueueSender.class);
    com.wm.corelib.mq.jmswrap.WMQueueSession.setClass(WMQueueSession.class);
    com.wm.corelib.mq.jmswrap.WMServerSession.setClass(WMServerSession.class);
    com.wm.corelib.mq.jmswrap.WMServerSessionPool.setClass(WMServerSessionPool.class);
    com.wm.corelib.mq.jmswrap.WMSession.setClass(WMSession.class);
    com.wm.corelib.mq.jmswrap.WMStreamMessage.setClass(WMStreamMessage.class);
    com.wm.corelib.mq.jmswrap.WMTemporaryQueue.setClass(WMTemporaryQueue.class);
    com.wm.corelib.mq.jmswrap.WMTemporaryTopic.setClass(WMTemporaryTopic.class);
    com.wm.corelib.mq.jmswrap.WMTextMessage.setClass(WMTextMessage.class);
    com.wm.corelib.mq.jmswrap.WMTopic.setClass(WMTopic.class);
    com.wm.corelib.mq.jmswrap.WMTopicConnection.setClass(WMTopicConnection.class);
    com.wm.corelib.mq.jmswrap.WMTopicConnectionFactory.setClass(WMTopicConnectionFactory.class);
    com.wm.corelib.mq.jmswrap.WMTopicPublisher.setClass(WMTopicPublisher.class);
    com.wm.corelib.mq.jmswrap.WMTopicSession.setClass(WMTopicSession.class);
    com.wm.corelib.mq.jmswrap.WMTopicSubscriber.setClass(WMTopicSubscriber.class);
    com.wm.corelib.mq.jmswrap.WMXAConnection.setClass(WMXAConnection.class);
    com.wm.corelib.mq.jmswrap.WMXAConnectionFactory.setClass(WMXAConnectionFactory.class);
    com.wm.corelib.mq.jmswrap.WMXAQueueConnection.setClass(WMXAQueueConnection.class);
    com.wm.corelib.mq.jmswrap.WMXAQueueConnectionFactory.setClass(WMXAQueueConnectionFactory.class);
    com.wm.corelib.mq.jmswrap.WMXAQueueSession.setClass(WMXAQueueSession.class);
    com.wm.corelib.mq.jmswrap.WMXASession.setClass(WMXASession.class);
    com.wm.corelib.mq.jmswrap.WMXATopicConnection.setClass(WMXATopicConnection.class);
    com.wm.corelib.mq.jmswrap.WMXATopicConnectionFactory.setClass(WMXATopicConnectionFactory.class);
    com.wm.corelib.mq.jmswrap.WMXATopicSession.setClass(WMXATopicSession.class);
  }

  public static void main(String args[]) throws Throwable {
    QueueReceiver       _theQueueReceiver    = null;
    QueueSender         _theQueueSender      = null;
    Queue               _theIOQueue          = null;
    QueueSession        _theSession          = null;
    QueueConnection     _theConnection       = null;
    QueueConnectionFactory _theFactory       = null;

    if (args.length != 4) {
      System.err.println("usage: WMMessaging <host> <qmgrName> <channel> <queue>");
      System.exit(1);
    }
 
    String host = args[0];
    String qmgr = args[1];
    String channel = args[2];
    String queue = args[3];
    
    try {     
      System.out.println("Creating a QueueConnectionFactory");
      _theFactory = WMMessaging.createQueueConnectionFactory(host,
                                                             qmgr,
                                                             channel);
      
      System.out.println("Creating a Connection");
      _theConnection = _theFactory.createQueueConnection();
      
      System.out.println("Starting the Connection");
      _theConnection.start();
      
      System.out.println("Creating a Session");
      boolean transacted = false;
      _theSession = _theConnection.createQueueSession( transacted, Session.AUTO_ACKNOWLEDGE);
      
      _theIOQueue = _theSession.createQueue( queue );
      //((MQDestination)_theIOQueue).setTargetClient(JMSC.MQJMS_CLIENT_NONJMS_MQ);
      
      System.out.println("Creating a QueueSender");
      _theQueueSender = _theSession.createSender(_theIOQueue);
      
      System.out.println("Creating a QueueReceiver");
      _theQueueReceiver = _theSession.createReceiver(_theIOQueue);    
    }  
    catch (JMSException jmse) {
      jmse.printStackTrace();
      Exception le = jmse.getLinkedException();
      if (le != null) System.out.println("Linked exception: " + le);
      System.exit(1);
    }
    catch (Exception e) {
      e.printStackTrace();
      System.exit(1);
    }          
  
    // text message
    _theQueueSender.send(_theSession.createTextMessage("timmy teck"));
    
    // map message
    MapMessage mm = _theSession.createMapMessage();
    
    mm.setString("yo", "yer mother was a snowblower");
    mm.setInt("int", 4);
    mm.setByte("int", (byte)5);
    mm.setStringProperty("MQ52bugTest", "/yo, this property starts with a leading slash!");
    _theQueueSender.send(mm, 1, 5, 100000);
    
    // object message
    ObjectMessage om = _theSession.createObjectMessage();
    om.setObject(new Integer(3));
    _theQueueSender.send(om);
    
    // Bytes Message
    BytesMessage bm = _theSession.createBytesMessage();
    bm.writeByte((byte)84);
    bm.writeByte((byte)105);
    bm.writeByte((byte)109);
    bm.writeByte((byte)33);
    bm.writeByte((byte)0);
    
    _theQueueSender.send(bm);
    
    
    System.out.println("Getting message(s)....");  
    Message m = null;
    
    do {
      try {
      m = _theQueueReceiver.receive(250);
      
      if (m != null) {      
        System.out.println("");
        System.out.println("******************************");
        System.out.println(m);
        
        if (m.propertyExists("MQ52bugTest")) {
          System.out.println("#####: MQ52bugTest = " + m.getStringProperty("MQ52bugTest"));
        }               
        
        if (m instanceof BytesMessage) {
          BytesMessage b = (BytesMessage)m;
          
          java.io.FileOutputStream fos = new java.io.FileOutputStream("/tmp/bytes.out");
          
          try {
            while(true) {
              byte bite = b.readByte();
              fos.write(bite);
            }
          }
          catch (MessageEOFException eof) { }
          
          
          System.out.println("wrote message to /tmp/bytes.out");
          fos.close();
        }
        
        System.out.println("******************************");
      }      
      }
      catch (JMSException e) {
        System.out.println("");
        System.out.println(e.getMessage());
        e.getLinkedException().printStackTrace();
      }
      catch (Throwable t) {
        System.out.println("");
        System.out.println(t.getMessage());
        t.printStackTrace();
      }    
    } while (m != null);

  }// main()

}
