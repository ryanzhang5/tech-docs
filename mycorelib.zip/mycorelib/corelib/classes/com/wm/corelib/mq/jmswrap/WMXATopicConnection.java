package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMXATopicConnection extends WMTopicConnection implements XAConnection, XATopicConnection {

  public String toString() {
    return getNativeXATopicConnectionImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public XATopicSession createXATopicSession() throws JMSException {
    XATopicSession rv = getNativeXATopicConnectionImpl().createXATopicSession();
    if (rv == null) { return null; }
    rv = (XATopicSession)WMXATopicSession.newInstance((XATopicSession)rv);
    return rv;
  }

  public TopicSession createTopicSession(boolean transacted, int acknowledgeMode) throws JMSException {
    boolean arg0 = transacted;
    int arg1 = acknowledgeMode;
    TopicSession rv = getNativeXATopicConnectionImpl().createTopicSession(arg0, arg1);
    if (rv == null) { return null; }
    rv = (TopicSession)WMTopicSession.newInstance((TopicSession)rv);
    return rv;
  }



  //////////////////
  // inherited methods from class Connection (proxy to custom WM objects)
  //////////////////
  public String getClientID() throws JMSException {
    return getInternalConnectionImpl().getClientID();
  }

  public void setClientID(String clientID) throws JMSException {
    getInternalConnectionImpl().setClientID(clientID);
  }

  public ConnectionMetaData getMetaData() throws JMSException {
    return getInternalConnectionImpl().getMetaData();
  }

  public ExceptionListener getExceptionListener() throws JMSException {
    return getInternalConnectionImpl().getExceptionListener();
  }

  public void setExceptionListener(ExceptionListener listener) throws JMSException {
    getInternalConnectionImpl().setExceptionListener(listener);
  }

  public void start() throws JMSException {
    getInternalConnectionImpl().start();
  }

  public void stop() throws JMSException {
    getInternalConnectionImpl().stop();
  }

  public void close() throws JMSException {
    getInternalConnectionImpl().close();
  }



  //////////////////
  // inherited methods from class XAConnection (proxy to custom WM objects)
  //////////////////


  //////////////////
  // inherited methods from class TopicConnection (proxy to custom WM objects)
  //////////////////
  public ConnectionConsumer createConnectionConsumer(Topic topic, String messageSelector, ServerSessionPool sessionPool, int maxMessages) throws JMSException {
    return getInternalTopicConnectionImpl().createConnectionConsumer(topic, messageSelector, sessionPool, maxMessages);
  }

  public ConnectionConsumer createDurableConnectionConsumer(Topic topic, String subscriptionName, String messageSelector, ServerSessionPool sessionPool, int maxMessages) throws JMSException {
    return getInternalTopicConnectionImpl().createDurableConnectionConsumer(topic, subscriptionName, messageSelector, sessionPool, maxMessages);
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMXATopicConnection newInstance(XATopicConnection nativeImpl) {
    try {
      WMXATopicConnection newObj = (WMXATopicConnection)_clazz.newInstance();
      newObj.setNativeXATopicConnectionImpl(nativeImpl);
      newObj.setNativeConnectionImpl((Connection)nativeImpl);
      newObj.setInternalConnectionImpl(WMConnection.newInstance((Connection)nativeImpl));
      newObj.setInternalXAConnectionImpl(WMXAConnection.newInstance((XAConnection)nativeImpl));
      newObj.setNativeTopicConnectionImpl((TopicConnection)nativeImpl);
      newObj.setInternalTopicConnectionImpl(WMTopicConnection.newInstance((TopicConnection)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected XATopicConnection getNativeXATopicConnectionImpl() {
    return _xATopicConnectionImpl;
  }

  protected void setNativeXATopicConnectionImpl(XATopicConnection nativeImpl) {
    _xATopicConnectionImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe Connection
  //////////////////
  private WMConnection _internalConnectionImpl = null;
  private WMConnection getInternalConnectionImpl() {
    return _internalConnectionImpl;
  }

  private void setInternalConnectionImpl(WMConnection nativeImpl) {
    _internalConnectionImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe XAConnection
  //////////////////
  private WMXAConnection _internalXAConnectionImpl = null;
  private WMXAConnection getInternalXAConnectionImpl() {
    return _internalXAConnectionImpl;
  }

  private void setInternalXAConnectionImpl(WMXAConnection nativeImpl) {
    _internalXAConnectionImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe TopicConnection
  //////////////////
  private WMTopicConnection _internalTopicConnectionImpl = null;
  private WMTopicConnection getInternalTopicConnectionImpl() {
    return _internalTopicConnectionImpl;
  }

  private void setInternalTopicConnectionImpl(WMTopicConnection nativeImpl) {
    _internalTopicConnectionImpl = nativeImpl;
  }

  protected WMXATopicConnection() { }
  private XATopicConnection _xATopicConnectionImpl = null;
  private static Class _clazz = WMXATopicConnection.class;
}
