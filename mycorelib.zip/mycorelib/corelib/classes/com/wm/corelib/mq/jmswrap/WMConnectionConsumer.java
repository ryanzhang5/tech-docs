package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMConnectionConsumer implements ConnectionConsumer {

  public String toString() {
    return getNativeConnectionConsumerImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public ServerSessionPool getServerSessionPool() throws JMSException {
    ServerSessionPool rv = getNativeConnectionConsumerImpl().getServerSessionPool();
    if (rv == null) { return null; }
    rv = (ServerSessionPool)WMServerSessionPool.newInstance((ServerSessionPool)rv);
    return rv;
  }

  public void close() throws JMSException {
    getNativeConnectionConsumerImpl().close();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMConnectionConsumer newInstance(ConnectionConsumer nativeImpl) {
    try {
      WMConnectionConsumer newObj = (WMConnectionConsumer)_clazz.newInstance();
      newObj.setNativeConnectionConsumerImpl(nativeImpl);
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected ConnectionConsumer getNativeConnectionConsumerImpl() {
    return _connectionConsumerImpl;
  }

  protected void setNativeConnectionConsumerImpl(ConnectionConsumer nativeImpl) {
    _connectionConsumerImpl = nativeImpl;
  }

  protected WMConnectionConsumer() { }
  private ConnectionConsumer _connectionConsumerImpl = null;
  private static Class _clazz = WMConnectionConsumer.class;
}
