package com.wm.corelib.mq;

import javax.jms.*;

public class WMQueueSession extends com.wm.corelib.mq.jmswrap.WMQueueSession {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.QueueSession interface
  ////////////////////////////////

}
