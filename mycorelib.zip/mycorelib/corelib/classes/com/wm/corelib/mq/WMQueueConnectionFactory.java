package com.wm.corelib.mq;

import javax.jms.*;

public class WMQueueConnectionFactory extends com.wm.corelib.mq.jmswrap.WMQueueConnectionFactory {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.QueueConnectionFactory interface
  ////////////////////////////////

}
