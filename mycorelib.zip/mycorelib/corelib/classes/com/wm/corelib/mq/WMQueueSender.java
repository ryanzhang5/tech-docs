package com.wm.corelib.mq;

import javax.jms.*;

public class WMQueueSender extends com.wm.corelib.mq.jmswrap.WMQueueSender {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.QueueSender interface
  ////////////////////////////////

}
