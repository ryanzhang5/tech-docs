package com.wm.corelib.mq;

import javax.jms.*;

public class WMQueueBrowser extends com.wm.corelib.mq.jmswrap.WMQueueBrowser {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.QueueBrowser interface
  ////////////////////////////////

}
