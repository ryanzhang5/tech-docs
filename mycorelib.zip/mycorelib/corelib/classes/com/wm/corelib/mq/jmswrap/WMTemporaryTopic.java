package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMTemporaryTopic extends WMTopic implements TemporaryTopic {

  public String toString() {
    return getNativeTemporaryTopicImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public void delete() throws JMSException {
    getNativeTemporaryTopicImpl().delete();
  }



  //////////////////
  // inherited methods from class Topic (proxy to custom WM objects)
  //////////////////
  public String getTopicName() throws JMSException {
    return getInternalTopicImpl().getTopicName();
  }



  //////////////////
  // inherited methods from class Destination (proxy to custom WM objects)
  //////////////////


  public static void setClass(Class c) { _clazz = c; }

  public static WMTemporaryTopic newInstance(TemporaryTopic nativeImpl) {
    try {
      WMTemporaryTopic newObj = (WMTemporaryTopic)_clazz.newInstance();
      newObj.setNativeTemporaryTopicImpl(nativeImpl);
      newObj.setNativeTopicImpl((Topic)nativeImpl);
      newObj.setInternalTopicImpl(WMTopic.newInstance((Topic)nativeImpl));
      newObj.setNativeDestinationImpl((Destination)nativeImpl);
      newObj.setInternalDestinationImpl(WMDestination.newInstance((Destination)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected TemporaryTopic getNativeTemporaryTopicImpl() {
    return _temporaryTopicImpl;
  }

  protected void setNativeTemporaryTopicImpl(TemporaryTopic nativeImpl) {
    _temporaryTopicImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe Topic
  //////////////////
  private WMTopic _internalTopicImpl = null;
  private WMTopic getInternalTopicImpl() {
    return _internalTopicImpl;
  }

  private void setInternalTopicImpl(WMTopic nativeImpl) {
    _internalTopicImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe Destination
  //////////////////
  private WMDestination _internalDestinationImpl = null;
  private WMDestination getInternalDestinationImpl() {
    return _internalDestinationImpl;
  }

  private void setInternalDestinationImpl(WMDestination nativeImpl) {
    _internalDestinationImpl = nativeImpl;
  }

  protected WMTemporaryTopic() { }
  private TemporaryTopic _temporaryTopicImpl = null;
  private static Class _clazz = WMTemporaryTopic.class;
}
