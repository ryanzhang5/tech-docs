package com.wm.corelib.mq;

import javax.jms.*;

public class WMConnection extends com.wm.corelib.mq.jmswrap.WMConnection {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.Connection interface
  ////////////////////////////////

}
