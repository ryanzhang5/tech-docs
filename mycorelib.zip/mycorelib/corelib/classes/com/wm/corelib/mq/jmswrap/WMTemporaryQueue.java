package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMTemporaryQueue extends WMQueue implements TemporaryQueue {

  public String toString() {
    return getNativeTemporaryQueueImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public void delete() throws JMSException {
    getNativeTemporaryQueueImpl().delete();
  }



  //////////////////
  // inherited methods from class Destination (proxy to custom WM objects)
  //////////////////


  //////////////////
  // inherited methods from class Queue (proxy to custom WM objects)
  //////////////////
  public String getQueueName() throws JMSException {
    return getInternalQueueImpl().getQueueName();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMTemporaryQueue newInstance(TemporaryQueue nativeImpl) {
    try {
      WMTemporaryQueue newObj = (WMTemporaryQueue)_clazz.newInstance();
      newObj.setNativeTemporaryQueueImpl(nativeImpl);
      newObj.setNativeDestinationImpl((Destination)nativeImpl);
      newObj.setInternalDestinationImpl(WMDestination.newInstance((Destination)nativeImpl));
      newObj.setNativeQueueImpl((Queue)nativeImpl);
      newObj.setInternalQueueImpl(WMQueue.newInstance((Queue)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected TemporaryQueue getNativeTemporaryQueueImpl() {
    return _temporaryQueueImpl;
  }

  protected void setNativeTemporaryQueueImpl(TemporaryQueue nativeImpl) {
    _temporaryQueueImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe Destination
  //////////////////
  private WMDestination _internalDestinationImpl = null;
  private WMDestination getInternalDestinationImpl() {
    return _internalDestinationImpl;
  }

  private void setInternalDestinationImpl(WMDestination nativeImpl) {
    _internalDestinationImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe Queue
  //////////////////
  private WMQueue _internalQueueImpl = null;
  private WMQueue getInternalQueueImpl() {
    return _internalQueueImpl;
  }

  private void setInternalQueueImpl(WMQueue nativeImpl) {
    _internalQueueImpl = nativeImpl;
  }

  protected WMTemporaryQueue() { }
  private TemporaryQueue _temporaryQueueImpl = null;
  private static Class _clazz = WMTemporaryQueue.class;
}
