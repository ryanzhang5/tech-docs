package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMDeliveryMode implements DeliveryMode {

  public String toString() {
    return getNativeDeliveryModeImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////


  public static void setClass(Class c) { _clazz = c; }

  public static WMDeliveryMode newInstance(DeliveryMode nativeImpl) {
    try {
      WMDeliveryMode newObj = (WMDeliveryMode)_clazz.newInstance();
      newObj.setNativeDeliveryModeImpl(nativeImpl);
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected DeliveryMode getNativeDeliveryModeImpl() {
    return _deliveryModeImpl;
  }

  protected void setNativeDeliveryModeImpl(DeliveryMode nativeImpl) {
    _deliveryModeImpl = nativeImpl;
  }

  protected WMDeliveryMode() { }
  private DeliveryMode _deliveryModeImpl = null;
  private static Class _clazz = WMDeliveryMode.class;
}
