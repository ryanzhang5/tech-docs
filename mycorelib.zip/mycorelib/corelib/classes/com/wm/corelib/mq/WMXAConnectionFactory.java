package com.wm.corelib.mq;

import javax.jms.*;

public class WMXAConnectionFactory extends com.wm.corelib.mq.jmswrap.WMXAConnectionFactory {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.XAConnectionFactory interface
  ////////////////////////////////

}
