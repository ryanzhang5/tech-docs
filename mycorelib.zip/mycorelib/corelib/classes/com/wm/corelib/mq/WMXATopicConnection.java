package com.wm.corelib.mq;

import javax.jms.*;

public class WMXATopicConnection extends com.wm.corelib.mq.jmswrap.WMXATopicConnection {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.XATopicConnection interface
  ////////////////////////////////

}
