package com.wm.corelib.mq;

import javax.jms.*;

public class WMMapMessage extends com.wm.corelib.mq.jmswrap.WMMapMessage {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.MapMessage interface
  ////////////////////////////////

}
