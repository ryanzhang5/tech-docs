package com.wm.corelib.mq;

import javax.jms.*;

public class WMXAQueueConnection extends com.wm.corelib.mq.jmswrap.WMXAQueueConnection {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.XAQueueConnection interface
  ////////////////////////////////

}
