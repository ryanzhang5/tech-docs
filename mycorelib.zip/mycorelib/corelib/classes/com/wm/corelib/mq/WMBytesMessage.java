package com.wm.corelib.mq;

import javax.jms.*;

public class WMBytesMessage extends com.wm.corelib.mq.jmswrap.WMBytesMessage {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.BytesMessage interface
  ////////////////////////////////

}
