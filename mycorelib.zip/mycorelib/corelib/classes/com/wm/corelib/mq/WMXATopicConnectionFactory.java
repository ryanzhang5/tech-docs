package com.wm.corelib.mq;

import javax.jms.*;

public class WMXATopicConnectionFactory extends com.wm.corelib.mq.jmswrap.WMXATopicConnectionFactory {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.XATopicConnectionFactory interface
  ////////////////////////////////

}
