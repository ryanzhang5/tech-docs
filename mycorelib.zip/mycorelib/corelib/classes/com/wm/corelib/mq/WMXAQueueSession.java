package com.wm.corelib.mq;

import javax.jms.*;

public class WMXAQueueSession extends com.wm.corelib.mq.jmswrap.WMXAQueueSession {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.XAQueueSession interface
  ////////////////////////////////

}
