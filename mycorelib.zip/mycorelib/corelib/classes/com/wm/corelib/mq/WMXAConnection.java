package com.wm.corelib.mq;

import javax.jms.*;

public class WMXAConnection extends com.wm.corelib.mq.jmswrap.WMXAConnection {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.XAConnection interface
  ////////////////////////////////

}
