package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMTopicSession extends WMSession implements TopicSession {

  public String toString() {
    return getNativeTopicSessionImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public Topic createTopic(String topicName) throws JMSException {
    String arg0 = topicName;
    Topic rv = getNativeTopicSessionImpl().createTopic(arg0);
    if (rv == null) { return null; }
    else if (rv instanceof TemporaryTopic) {
      rv = (Topic)WMTemporaryTopic.newInstance((TemporaryTopic)rv);
    }
    else {
      rv = (Topic)WMTopic.newInstance((Topic)rv);
    }
    return rv;
  }

  public TopicSubscriber createSubscriber(Topic topic) throws JMSException {
    Topic arg0 = (topic instanceof WMTopic) ? ((WMTopic)topic).getNativeTopicImpl() : topic;
    TopicSubscriber rv = getNativeTopicSessionImpl().createSubscriber(arg0);
    if (rv == null) { return null; }
    rv = (TopicSubscriber)WMTopicSubscriber.newInstance((TopicSubscriber)rv);
    return rv;
  }

  public TopicSubscriber createSubscriber(Topic topic, String messageSelector, boolean noLocal) throws JMSException {
    Topic arg0 = (topic instanceof WMTopic) ? ((WMTopic)topic).getNativeTopicImpl() : topic;
    String arg1 = messageSelector;
    boolean arg2 = noLocal;
    TopicSubscriber rv = getNativeTopicSessionImpl().createSubscriber(arg0, arg1, arg2);
    if (rv == null) { return null; }
    rv = (TopicSubscriber)WMTopicSubscriber.newInstance((TopicSubscriber)rv);
    return rv;
  }

  public TopicSubscriber createDurableSubscriber(Topic topic, String name) throws JMSException {
    Topic arg0 = (topic instanceof WMTopic) ? ((WMTopic)topic).getNativeTopicImpl() : topic;
    String arg1 = name;
    TopicSubscriber rv = getNativeTopicSessionImpl().createDurableSubscriber(arg0, arg1);
    if (rv == null) { return null; }
    rv = (TopicSubscriber)WMTopicSubscriber.newInstance((TopicSubscriber)rv);
    return rv;
  }

  public TopicSubscriber createDurableSubscriber(Topic topic, String name, String messageSelector, boolean noLocal) throws JMSException {
    Topic arg0 = (topic instanceof WMTopic) ? ((WMTopic)topic).getNativeTopicImpl() : topic;
    String arg1 = name;
    String arg2 = messageSelector;
    boolean arg3 = noLocal;
    TopicSubscriber rv = getNativeTopicSessionImpl().createDurableSubscriber(arg0, arg1, arg2, arg3);
    if (rv == null) { return null; }
    rv = (TopicSubscriber)WMTopicSubscriber.newInstance((TopicSubscriber)rv);
    return rv;
  }

  public TopicPublisher createPublisher(Topic topic) throws JMSException {
    Topic arg0 = (topic instanceof WMTopic) ? ((WMTopic)topic).getNativeTopicImpl() : topic;
    TopicPublisher rv = getNativeTopicSessionImpl().createPublisher(arg0);
    if (rv == null) { return null; }
    rv = (TopicPublisher)WMTopicPublisher.newInstance((TopicPublisher)rv);
    return rv;
  }

  public TemporaryTopic createTemporaryTopic() throws JMSException {
    TemporaryTopic rv = getNativeTopicSessionImpl().createTemporaryTopic();
    if (rv == null) { return null; }
    rv = (TemporaryTopic)WMTemporaryTopic.newInstance((TemporaryTopic)rv);
    return rv;
  }

  public void unsubscribe(String name) throws JMSException {
    String arg0 = name;
    getNativeTopicSessionImpl().unsubscribe(arg0);
  }



  //////////////////
  // inherited methods from class Session (proxy to custom WM objects)
  //////////////////
  public BytesMessage createBytesMessage() throws JMSException {
    return getInternalSessionImpl().createBytesMessage();
  }

  public MapMessage createMapMessage() throws JMSException {
    return getInternalSessionImpl().createMapMessage();
  }

  public Message createMessage() throws JMSException {
    return getInternalSessionImpl().createMessage();
  }

  public ObjectMessage createObjectMessage() throws JMSException {
    return getInternalSessionImpl().createObjectMessage();
  }

  public ObjectMessage createObjectMessage(java.io.Serializable object) throws JMSException {
    return getInternalSessionImpl().createObjectMessage(object);
  }

  public StreamMessage createStreamMessage() throws JMSException {
    return getInternalSessionImpl().createStreamMessage();
  }

  public TextMessage createTextMessage() throws JMSException {
    return getInternalSessionImpl().createTextMessage();
  }

  public TextMessage createTextMessage(String text) throws JMSException {
    return getInternalSessionImpl().createTextMessage(text);
  }

  public boolean getTransacted() throws JMSException {
    return getInternalSessionImpl().getTransacted();
  }

  public void commit() throws JMSException {
    getInternalSessionImpl().commit();
  }

  public void rollback() throws JMSException {
    getInternalSessionImpl().rollback();
  }

  public void close() throws JMSException {
    getInternalSessionImpl().close();
  }

  public void recover() throws JMSException {
    getInternalSessionImpl().recover();
  }

  public MessageListener getMessageListener() throws JMSException {
    return getInternalSessionImpl().getMessageListener();
  }

  public void setMessageListener(MessageListener listener) throws JMSException {
    getInternalSessionImpl().setMessageListener(listener);
  }

  public void run()  {
    getInternalSessionImpl().run();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMTopicSession newInstance(TopicSession nativeImpl) {
    try {
      WMTopicSession newObj = (WMTopicSession)_clazz.newInstance();
      newObj.setNativeTopicSessionImpl(nativeImpl);
      newObj.setNativeSessionImpl((Session)nativeImpl);
      newObj.setInternalSessionImpl(WMSession.newInstance((Session)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected TopicSession getNativeTopicSessionImpl() {
    return _topicSessionImpl;
  }

  protected void setNativeTopicSessionImpl(TopicSession nativeImpl) {
    _topicSessionImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe Session
  //////////////////
  private WMSession _internalSessionImpl = null;
  private WMSession getInternalSessionImpl() {
    return _internalSessionImpl;
  }

  private void setInternalSessionImpl(WMSession nativeImpl) {
    _internalSessionImpl = nativeImpl;
  }

  protected WMTopicSession() { }
  private TopicSession _topicSessionImpl = null;
  private static Class _clazz = WMTopicSession.class;
}
