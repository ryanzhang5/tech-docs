package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMTopicConnection extends WMConnection implements TopicConnection {

  public String toString() {
    return getNativeTopicConnectionImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public TopicSession createTopicSession(boolean transacted, int acknowledgeMode) throws JMSException {
    boolean arg0 = transacted;
    int arg1 = acknowledgeMode;
    TopicSession rv = getNativeTopicConnectionImpl().createTopicSession(arg0, arg1);
    if (rv == null) { return null; }
    rv = (TopicSession)WMTopicSession.newInstance((TopicSession)rv);
    return rv;
  }

  public ConnectionConsumer createConnectionConsumer(Topic topic, String messageSelector, ServerSessionPool sessionPool, int maxMessages) throws JMSException {
    Topic arg0 = (topic instanceof WMTopic) ? ((WMTopic)topic).getNativeTopicImpl() : topic;
    String arg1 = messageSelector;
    ServerSessionPool arg2 = (sessionPool instanceof WMServerSessionPool) ? ((WMServerSessionPool)sessionPool).getNativeServerSessionPoolImpl() : sessionPool;
    int arg3 = maxMessages;
    ConnectionConsumer rv = getNativeTopicConnectionImpl().createConnectionConsumer(arg0, arg1, arg2, arg3);
    if (rv == null) { return null; }
    rv = (ConnectionConsumer)WMConnectionConsumer.newInstance((ConnectionConsumer)rv);
    return rv;
  }

  public ConnectionConsumer createDurableConnectionConsumer(Topic topic, String subscriptionName, String messageSelector, ServerSessionPool sessionPool, int maxMessages) throws JMSException {
    Topic arg0 = (topic instanceof WMTopic) ? ((WMTopic)topic).getNativeTopicImpl() : topic;
    String arg1 = subscriptionName;
    String arg2 = messageSelector;
    ServerSessionPool arg3 = (sessionPool instanceof WMServerSessionPool) ? ((WMServerSessionPool)sessionPool).getNativeServerSessionPoolImpl() : sessionPool;
    int arg4 = maxMessages;
    ConnectionConsumer rv = getNativeTopicConnectionImpl().createDurableConnectionConsumer(arg0, arg1, arg2, arg3, arg4);
    if (rv == null) { return null; }
    rv = (ConnectionConsumer)WMConnectionConsumer.newInstance((ConnectionConsumer)rv);
    return rv;
  }



  //////////////////
  // inherited methods from class Connection (proxy to custom WM objects)
  //////////////////
  public String getClientID() throws JMSException {
    return getInternalConnectionImpl().getClientID();
  }

  public void setClientID(String clientID) throws JMSException {
    getInternalConnectionImpl().setClientID(clientID);
  }

  public ConnectionMetaData getMetaData() throws JMSException {
    return getInternalConnectionImpl().getMetaData();
  }

  public ExceptionListener getExceptionListener() throws JMSException {
    return getInternalConnectionImpl().getExceptionListener();
  }

  public void setExceptionListener(ExceptionListener listener) throws JMSException {
    getInternalConnectionImpl().setExceptionListener(listener);
  }

  public void start() throws JMSException {
    getInternalConnectionImpl().start();
  }

  public void stop() throws JMSException {
    getInternalConnectionImpl().stop();
  }

  public void close() throws JMSException {
    getInternalConnectionImpl().close();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMTopicConnection newInstance(TopicConnection nativeImpl) {
    try {
      WMTopicConnection newObj = (WMTopicConnection)_clazz.newInstance();
      newObj.setNativeTopicConnectionImpl(nativeImpl);
      newObj.setNativeConnectionImpl((Connection)nativeImpl);
      newObj.setInternalConnectionImpl(WMConnection.newInstance((Connection)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected TopicConnection getNativeTopicConnectionImpl() {
    return _topicConnectionImpl;
  }

  protected void setNativeTopicConnectionImpl(TopicConnection nativeImpl) {
    _topicConnectionImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe Connection
  //////////////////
  private WMConnection _internalConnectionImpl = null;
  private WMConnection getInternalConnectionImpl() {
    return _internalConnectionImpl;
  }

  private void setInternalConnectionImpl(WMConnection nativeImpl) {
    _internalConnectionImpl = nativeImpl;
  }

  protected WMTopicConnection() { }
  private TopicConnection _topicConnectionImpl = null;
  private static Class _clazz = WMTopicConnection.class;
}
