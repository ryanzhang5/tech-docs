package com.wm.corelib.mq;

import javax.jms.*;

public class WMXAQueueConnectionFactory extends com.wm.corelib.mq.jmswrap.WMXAQueueConnectionFactory {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.XAQueueConnectionFactory interface
  ////////////////////////////////

}
