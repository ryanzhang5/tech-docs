package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMServerSessionPool implements ServerSessionPool {

  public String toString() {
    return getNativeServerSessionPoolImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public ServerSession getServerSession() throws JMSException {
    ServerSession rv = getNativeServerSessionPoolImpl().getServerSession();
    if (rv == null) { return null; }
    rv = (ServerSession)WMServerSession.newInstance((ServerSession)rv);
    return rv;
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMServerSessionPool newInstance(ServerSessionPool nativeImpl) {
    try {
      WMServerSessionPool newObj = (WMServerSessionPool)_clazz.newInstance();
      newObj.setNativeServerSessionPoolImpl(nativeImpl);
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected ServerSessionPool getNativeServerSessionPoolImpl() {
    return _serverSessionPoolImpl;
  }

  protected void setNativeServerSessionPoolImpl(ServerSessionPool nativeImpl) {
    _serverSessionPoolImpl = nativeImpl;
  }

  protected WMServerSessionPool() { }
  private ServerSessionPool _serverSessionPoolImpl = null;
  private static Class _clazz = WMServerSessionPool.class;
}
