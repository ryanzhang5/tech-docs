package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMTopicPublisher extends WMMessageProducer implements TopicPublisher {

  public String toString() {
    return getNativeTopicPublisherImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public Topic getTopic() throws JMSException {
    Topic rv = getNativeTopicPublisherImpl().getTopic();
    if (rv == null) { return null; }
    else if (rv instanceof TemporaryTopic) {
      rv = (Topic)WMTemporaryTopic.newInstance((TemporaryTopic)rv);
    }
    else {
      rv = (Topic)WMTopic.newInstance((Topic)rv);
    }
    return rv;
  }

  public void publish(Message message) throws JMSException {
    Message arg0 = (message instanceof WMMessage) ? ((WMMessage)message).getNativeMessageImpl() : message;
    getNativeTopicPublisherImpl().publish(arg0);
  }

  public void publish(Message message, int deliveryMode, int priority, long timeToLive) throws JMSException {
    Message arg0 = (message instanceof WMMessage) ? ((WMMessage)message).getNativeMessageImpl() : message;
    int arg1 = deliveryMode;
    int arg2 = priority;
    long arg3 = timeToLive;
    getNativeTopicPublisherImpl().publish(arg0, arg1, arg2, arg3);
  }

  public void publish(Topic topic, Message message) throws JMSException {
    Topic arg0 = (topic instanceof WMTopic) ? ((WMTopic)topic).getNativeTopicImpl() : topic;
    Message arg1 = (message instanceof WMMessage) ? ((WMMessage)message).getNativeMessageImpl() : message;
    getNativeTopicPublisherImpl().publish(arg0, arg1);
  }

  public void publish(Topic topic, Message message, int deliveryMode, int priority, long timeToLive) throws JMSException {
    Topic arg0 = (topic instanceof WMTopic) ? ((WMTopic)topic).getNativeTopicImpl() : topic;
    Message arg1 = (message instanceof WMMessage) ? ((WMMessage)message).getNativeMessageImpl() : message;
    int arg2 = deliveryMode;
    int arg3 = priority;
    long arg4 = timeToLive;
    getNativeTopicPublisherImpl().publish(arg0, arg1, arg2, arg3, arg4);
  }



  //////////////////
  // inherited methods from class MessageProducer (proxy to custom WM objects)
  //////////////////
  public void setDisableMessageID(boolean value) throws JMSException {
    getInternalMessageProducerImpl().setDisableMessageID(value);
  }

  public boolean getDisableMessageID() throws JMSException {
    return getInternalMessageProducerImpl().getDisableMessageID();
  }

  public void setDisableMessageTimestamp(boolean value) throws JMSException {
    getInternalMessageProducerImpl().setDisableMessageTimestamp(value);
  }

  public boolean getDisableMessageTimestamp() throws JMSException {
    return getInternalMessageProducerImpl().getDisableMessageTimestamp();
  }

  public void setDeliveryMode(int deliveryMode) throws JMSException {
    getInternalMessageProducerImpl().setDeliveryMode(deliveryMode);
  }

  public int getDeliveryMode() throws JMSException {
    return getInternalMessageProducerImpl().getDeliveryMode();
  }

  public void setPriority(int defaultPriority) throws JMSException {
    getInternalMessageProducerImpl().setPriority(defaultPriority);
  }

  public int getPriority() throws JMSException {
    return getInternalMessageProducerImpl().getPriority();
  }

  public void setTimeToLive(long timeToLive) throws JMSException {
    getInternalMessageProducerImpl().setTimeToLive(timeToLive);
  }

  public long getTimeToLive() throws JMSException {
    return getInternalMessageProducerImpl().getTimeToLive();
  }

  public void close() throws JMSException {
    getInternalMessageProducerImpl().close();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMTopicPublisher newInstance(TopicPublisher nativeImpl) {
    try {
      WMTopicPublisher newObj = (WMTopicPublisher)_clazz.newInstance();
      newObj.setNativeTopicPublisherImpl(nativeImpl);
      newObj.setNativeMessageProducerImpl((MessageProducer)nativeImpl);
      newObj.setInternalMessageProducerImpl(WMMessageProducer.newInstance((MessageProducer)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected TopicPublisher getNativeTopicPublisherImpl() {
    return _topicPublisherImpl;
  }

  protected void setNativeTopicPublisherImpl(TopicPublisher nativeImpl) {
    _topicPublisherImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe MessageProducer
  //////////////////
  private WMMessageProducer _internalMessageProducerImpl = null;
  private WMMessageProducer getInternalMessageProducerImpl() {
    return _internalMessageProducerImpl;
  }

  private void setInternalMessageProducerImpl(WMMessageProducer nativeImpl) {
    _internalMessageProducerImpl = nativeImpl;
  }

  protected WMTopicPublisher() { }
  private TopicPublisher _topicPublisherImpl = null;
  private static Class _clazz = WMTopicPublisher.class;
}
