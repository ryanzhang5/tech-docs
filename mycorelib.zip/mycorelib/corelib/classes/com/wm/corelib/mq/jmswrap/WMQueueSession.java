package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMQueueSession extends WMSession implements QueueSession {

  public String toString() {
    return getNativeQueueSessionImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public Queue createQueue(String queueName) throws JMSException {
    String arg0 = queueName;
    Queue rv = getNativeQueueSessionImpl().createQueue(arg0);
    if (rv == null) { return null; }
    else if (rv instanceof TemporaryQueue) {
      rv = (Queue)WMTemporaryQueue.newInstance((TemporaryQueue)rv);
    }
    else {
      rv = (Queue)WMQueue.newInstance((Queue)rv);
    }
    return rv;
  }

  public QueueReceiver createReceiver(Queue queue) throws JMSException {
    Queue arg0 = (queue instanceof WMQueue) ? ((WMQueue)queue).getNativeQueueImpl() : queue;
    QueueReceiver rv = getNativeQueueSessionImpl().createReceiver(arg0);
    if (rv == null) { return null; }
    rv = (QueueReceiver)WMQueueReceiver.newInstance((QueueReceiver)rv);
    return rv;
  }

  public QueueReceiver createReceiver(Queue queue, String messageSelector) throws JMSException {
    Queue arg0 = (queue instanceof WMQueue) ? ((WMQueue)queue).getNativeQueueImpl() : queue;
    String arg1 = messageSelector;
    QueueReceiver rv = getNativeQueueSessionImpl().createReceiver(arg0, arg1);
    if (rv == null) { return null; }
    rv = (QueueReceiver)WMQueueReceiver.newInstance((QueueReceiver)rv);
    return rv;
  }

  public QueueSender createSender(Queue queue) throws JMSException {
    Queue arg0 = (queue instanceof WMQueue) ? ((WMQueue)queue).getNativeQueueImpl() : queue;
    QueueSender rv = getNativeQueueSessionImpl().createSender(arg0);
    if (rv == null) { return null; }
    rv = (QueueSender)WMQueueSender.newInstance((QueueSender)rv);
    return rv;
  }

  public QueueBrowser createBrowser(Queue queue) throws JMSException {
    Queue arg0 = (queue instanceof WMQueue) ? ((WMQueue)queue).getNativeQueueImpl() : queue;
    QueueBrowser rv = getNativeQueueSessionImpl().createBrowser(arg0);
    if (rv == null) { return null; }
    rv = (QueueBrowser)WMQueueBrowser.newInstance((QueueBrowser)rv);
    return rv;
  }

  public QueueBrowser createBrowser(Queue queue, String messageSelector) throws JMSException {
    Queue arg0 = (queue instanceof WMQueue) ? ((WMQueue)queue).getNativeQueueImpl() : queue;
    String arg1 = messageSelector;
    QueueBrowser rv = getNativeQueueSessionImpl().createBrowser(arg0, arg1);
    if (rv == null) { return null; }
    rv = (QueueBrowser)WMQueueBrowser.newInstance((QueueBrowser)rv);
    return rv;
  }

  public TemporaryQueue createTemporaryQueue() throws JMSException {
    TemporaryQueue rv = getNativeQueueSessionImpl().createTemporaryQueue();
    if (rv == null) { return null; }
    rv = (TemporaryQueue)WMTemporaryQueue.newInstance((TemporaryQueue)rv);
    return rv;
  }



  //////////////////
  // inherited methods from class Session (proxy to custom WM objects)
  //////////////////
  public BytesMessage createBytesMessage() throws JMSException {
    return getInternalSessionImpl().createBytesMessage();
  }

  public MapMessage createMapMessage() throws JMSException {
    return getInternalSessionImpl().createMapMessage();
  }

  public Message createMessage() throws JMSException {
    return getInternalSessionImpl().createMessage();
  }

  public ObjectMessage createObjectMessage() throws JMSException {
    return getInternalSessionImpl().createObjectMessage();
  }

  public ObjectMessage createObjectMessage(java.io.Serializable object) throws JMSException {
    return getInternalSessionImpl().createObjectMessage(object);
  }

  public StreamMessage createStreamMessage() throws JMSException {
    return getInternalSessionImpl().createStreamMessage();
  }

  public TextMessage createTextMessage() throws JMSException {
    return getInternalSessionImpl().createTextMessage();
  }

  public TextMessage createTextMessage(String text) throws JMSException {
    return getInternalSessionImpl().createTextMessage(text);
  }

  public boolean getTransacted() throws JMSException {
    return getInternalSessionImpl().getTransacted();
  }

  public void commit() throws JMSException {
    getInternalSessionImpl().commit();
  }

  public void rollback() throws JMSException {
    getInternalSessionImpl().rollback();
  }

  public void close() throws JMSException {
    getInternalSessionImpl().close();
  }

  public void recover() throws JMSException {
    getInternalSessionImpl().recover();
  }

  public MessageListener getMessageListener() throws JMSException {
    return getInternalSessionImpl().getMessageListener();
  }

  public void setMessageListener(MessageListener listener) throws JMSException {
    getInternalSessionImpl().setMessageListener(listener);
  }

  public void run()  {
    getInternalSessionImpl().run();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMQueueSession newInstance(QueueSession nativeImpl) {
    try {
      WMQueueSession newObj = (WMQueueSession)_clazz.newInstance();
      newObj.setNativeQueueSessionImpl(nativeImpl);
      newObj.setNativeSessionImpl((Session)nativeImpl);
      newObj.setInternalSessionImpl(WMSession.newInstance((Session)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected QueueSession getNativeQueueSessionImpl() {
    return _queueSessionImpl;
  }

  protected void setNativeQueueSessionImpl(QueueSession nativeImpl) {
    _queueSessionImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe Session
  //////////////////
  private WMSession _internalSessionImpl = null;
  private WMSession getInternalSessionImpl() {
    return _internalSessionImpl;
  }

  private void setInternalSessionImpl(WMSession nativeImpl) {
    _internalSessionImpl = nativeImpl;
  }

  protected WMQueueSession() { }
  private QueueSession _queueSessionImpl = null;
  private static Class _clazz = WMQueueSession.class;
}
