package com.wm.corelib.mq;

import javax.jms.*;

public class WMSession extends com.wm.corelib.mq.jmswrap.WMSession {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.Session interface
  ////////////////////////////////

}
