package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMStreamMessage extends WMMessage implements StreamMessage {

  public String toString() {
    return getNativeStreamMessageImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public boolean readBoolean() throws JMSException {
    boolean rv = getNativeStreamMessageImpl().readBoolean();
    return rv;
  }

  public byte readByte() throws JMSException {
    byte rv = getNativeStreamMessageImpl().readByte();
    return rv;
  }

  public short readShort() throws JMSException {
    short rv = getNativeStreamMessageImpl().readShort();
    return rv;
  }

  public char readChar() throws JMSException {
    char rv = getNativeStreamMessageImpl().readChar();
    return rv;
  }

  public int readInt() throws JMSException {
    int rv = getNativeStreamMessageImpl().readInt();
    return rv;
  }

  public long readLong() throws JMSException {
    long rv = getNativeStreamMessageImpl().readLong();
    return rv;
  }

  public float readFloat() throws JMSException {
    float rv = getNativeStreamMessageImpl().readFloat();
    return rv;
  }

  public double readDouble() throws JMSException {
    double rv = getNativeStreamMessageImpl().readDouble();
    return rv;
  }

  public String readString() throws JMSException {
    String rv = getNativeStreamMessageImpl().readString();
    if (rv == null) { return null; }
    return rv;
  }

  public int readBytes(byte[] value) throws JMSException {
    byte[] arg0 = value;
    int rv = getNativeStreamMessageImpl().readBytes(arg0);
    return rv;
  }

  public Object readObject() throws JMSException {
    Object rv = getNativeStreamMessageImpl().readObject();
    if (rv == null) { return null; }
    return rv;
  }

  public void writeBoolean(boolean value) throws JMSException {
    boolean arg0 = value;
    getNativeStreamMessageImpl().writeBoolean(arg0);
  }

  public void writeByte(byte value) throws JMSException {
    byte arg0 = value;
    getNativeStreamMessageImpl().writeByte(arg0);
  }

  public void writeShort(short value) throws JMSException {
    short arg0 = value;
    getNativeStreamMessageImpl().writeShort(arg0);
  }

  public void writeChar(char value) throws JMSException {
    char arg0 = value;
    getNativeStreamMessageImpl().writeChar(arg0);
  }

  public void writeInt(int value) throws JMSException {
    int arg0 = value;
    getNativeStreamMessageImpl().writeInt(arg0);
  }

  public void writeLong(long value) throws JMSException {
    long arg0 = value;
    getNativeStreamMessageImpl().writeLong(arg0);
  }

  public void writeFloat(float value) throws JMSException {
    float arg0 = value;
    getNativeStreamMessageImpl().writeFloat(arg0);
  }

  public void writeDouble(double value) throws JMSException {
    double arg0 = value;
    getNativeStreamMessageImpl().writeDouble(arg0);
  }

  public void writeString(String value) throws JMSException {
    String arg0 = value;
    getNativeStreamMessageImpl().writeString(arg0);
  }

  public void writeBytes(byte[] value) throws JMSException {
    byte[] arg0 = value;
    getNativeStreamMessageImpl().writeBytes(arg0);
  }

  public void writeBytes(byte[] value, int offset, int length) throws JMSException {
    byte[] arg0 = value;
    int arg1 = offset;
    int arg2 = length;
    getNativeStreamMessageImpl().writeBytes(arg0, arg1, arg2);
  }

  public void writeObject(Object value) throws JMSException {
    Object arg0 = value;
    getNativeStreamMessageImpl().writeObject(arg0);
  }

  public void reset() throws JMSException {
    getNativeStreamMessageImpl().reset();
  }



  //////////////////
  // inherited methods from class Message (proxy to custom WM objects)
  //////////////////
  public String getJMSMessageID() throws JMSException {
    return getInternalMessageImpl().getJMSMessageID();
  }

  public void setJMSMessageID(String id) throws JMSException {
    getInternalMessageImpl().setJMSMessageID(id);
  }

  public long getJMSTimestamp() throws JMSException {
    return getInternalMessageImpl().getJMSTimestamp();
  }

  public void setJMSTimestamp(long timestamp) throws JMSException {
    getInternalMessageImpl().setJMSTimestamp(timestamp);
  }

  public byte[] getJMSCorrelationIDAsBytes() throws JMSException {
    return getInternalMessageImpl().getJMSCorrelationIDAsBytes();
  }

  public void setJMSCorrelationIDAsBytes(byte[] correlationID) throws JMSException {
    getInternalMessageImpl().setJMSCorrelationIDAsBytes(correlationID);
  }

  public void setJMSCorrelationID(String correlationID) throws JMSException {
    getInternalMessageImpl().setJMSCorrelationID(correlationID);
  }

  public String getJMSCorrelationID() throws JMSException {
    return getInternalMessageImpl().getJMSCorrelationID();
  }

  public Destination getJMSReplyTo() throws JMSException {
    return getInternalMessageImpl().getJMSReplyTo();
  }

  public void setJMSReplyTo(Destination replyTo) throws JMSException {
    getInternalMessageImpl().setJMSReplyTo(replyTo);
  }

  public Destination getJMSDestination() throws JMSException {
    return getInternalMessageImpl().getJMSDestination();
  }

  public void setJMSDestination(Destination destination) throws JMSException {
    getInternalMessageImpl().setJMSDestination(destination);
  }

  public int getJMSDeliveryMode() throws JMSException {
    return getInternalMessageImpl().getJMSDeliveryMode();
  }

  public void setJMSDeliveryMode(int deliveryMode) throws JMSException {
    getInternalMessageImpl().setJMSDeliveryMode(deliveryMode);
  }

  public boolean getJMSRedelivered() throws JMSException {
    return getInternalMessageImpl().getJMSRedelivered();
  }

  public void setJMSRedelivered(boolean redelivered) throws JMSException {
    getInternalMessageImpl().setJMSRedelivered(redelivered);
  }

  public String getJMSType() throws JMSException {
    return getInternalMessageImpl().getJMSType();
  }

  public void setJMSType(String type) throws JMSException {
    getInternalMessageImpl().setJMSType(type);
  }

  public long getJMSExpiration() throws JMSException {
    return getInternalMessageImpl().getJMSExpiration();
  }

  public void setJMSExpiration(long expiration) throws JMSException {
    getInternalMessageImpl().setJMSExpiration(expiration);
  }

  public int getJMSPriority() throws JMSException {
    return getInternalMessageImpl().getJMSPriority();
  }

  public void setJMSPriority(int priority) throws JMSException {
    getInternalMessageImpl().setJMSPriority(priority);
  }

  public void clearProperties() throws JMSException {
    getInternalMessageImpl().clearProperties();
  }

  public boolean propertyExists(String name) throws JMSException {
    return getInternalMessageImpl().propertyExists(name);
  }

  public boolean getBooleanProperty(String name) throws JMSException {
    return getInternalMessageImpl().getBooleanProperty(name);
  }

  public byte getByteProperty(String name) throws JMSException {
    return getInternalMessageImpl().getByteProperty(name);
  }

  public short getShortProperty(String name) throws JMSException {
    return getInternalMessageImpl().getShortProperty(name);
  }

  public int getIntProperty(String name) throws JMSException {
    return getInternalMessageImpl().getIntProperty(name);
  }

  public long getLongProperty(String name) throws JMSException {
    return getInternalMessageImpl().getLongProperty(name);
  }

  public float getFloatProperty(String name) throws JMSException {
    return getInternalMessageImpl().getFloatProperty(name);
  }

  public double getDoubleProperty(String name) throws JMSException {
    return getInternalMessageImpl().getDoubleProperty(name);
  }

  public String getStringProperty(String name) throws JMSException {
    return getInternalMessageImpl().getStringProperty(name);
  }

  public Object getObjectProperty(String name) throws JMSException {
    return getInternalMessageImpl().getObjectProperty(name);
  }

  public java.util.Enumeration getPropertyNames() throws JMSException {
    return getInternalMessageImpl().getPropertyNames();
  }

  public void setBooleanProperty(String name, boolean value) throws JMSException {
    getInternalMessageImpl().setBooleanProperty(name, value);
  }

  public void setByteProperty(String name, byte value) throws JMSException {
    getInternalMessageImpl().setByteProperty(name, value);
  }

  public void setShortProperty(String name, short value) throws JMSException {
    getInternalMessageImpl().setShortProperty(name, value);
  }

  public void setIntProperty(String name, int value) throws JMSException {
    getInternalMessageImpl().setIntProperty(name, value);
  }

  public void setLongProperty(String name, long value) throws JMSException {
    getInternalMessageImpl().setLongProperty(name, value);
  }

  public void setFloatProperty(String name, float value) throws JMSException {
    getInternalMessageImpl().setFloatProperty(name, value);
  }

  public void setDoubleProperty(String name, double value) throws JMSException {
    getInternalMessageImpl().setDoubleProperty(name, value);
  }

  public void setStringProperty(String name, String value) throws JMSException {
    getInternalMessageImpl().setStringProperty(name, value);
  }

  public void setObjectProperty(String name, Object value) throws JMSException {
    getInternalMessageImpl().setObjectProperty(name, value);
  }

  public void acknowledge() throws JMSException {
    getInternalMessageImpl().acknowledge();
  }

  public void clearBody() throws JMSException {
    getInternalMessageImpl().clearBody();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMStreamMessage newInstance(StreamMessage nativeImpl) {
    try {
      WMStreamMessage newObj = (WMStreamMessage)_clazz.newInstance();
      newObj.setNativeStreamMessageImpl(nativeImpl);
      newObj.setNativeMessageImpl((Message)nativeImpl);
      newObj.setInternalMessageImpl(WMMessage.newInstance((Message)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected StreamMessage getNativeStreamMessageImpl() {
    return _streamMessageImpl;
  }

  protected void setNativeStreamMessageImpl(StreamMessage nativeImpl) {
    _streamMessageImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe Message
  //////////////////
  private WMMessage _internalMessageImpl = null;
  private WMMessage getInternalMessageImpl() {
    return _internalMessageImpl;
  }

  private void setInternalMessageImpl(WMMessage nativeImpl) {
    _internalMessageImpl = nativeImpl;
  }

  protected WMStreamMessage() { }
  private StreamMessage _streamMessageImpl = null;
  private static Class _clazz = WMStreamMessage.class;
}
