package com.wm.corelib.mq;

import javax.jms.*;

public class WMServerSession extends com.wm.corelib.mq.jmswrap.WMServerSession {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.ServerSession interface
  ////////////////////////////////

}
