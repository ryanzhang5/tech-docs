package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMQueueSender extends WMMessageProducer implements QueueSender {

  public String toString() {
    return getNativeQueueSenderImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public Queue getQueue() throws JMSException {
    Queue rv = getNativeQueueSenderImpl().getQueue();
    if (rv == null) { return null; }
    else if (rv instanceof TemporaryQueue) {
      rv = (Queue)WMTemporaryQueue.newInstance((TemporaryQueue)rv);
    }
    else {
      rv = (Queue)WMQueue.newInstance((Queue)rv);
    }
    return rv;
  }

  public void send(Message message) throws JMSException {
    Message arg0 = (message instanceof WMMessage) ? ((WMMessage)message).getNativeMessageImpl() : message;
    getNativeQueueSenderImpl().send(arg0);
  }

  public void send(Message message, int deliveryMode, int priority, long timeToLive) throws JMSException {
    Message arg0 = (message instanceof WMMessage) ? ((WMMessage)message).getNativeMessageImpl() : message;
    int arg1 = deliveryMode;
    int arg2 = priority;
    long arg3 = timeToLive;
    getNativeQueueSenderImpl().send(arg0, arg1, arg2, arg3);
  }

  public void send(Queue queue, Message message) throws JMSException {
    Queue arg0 = (queue instanceof WMQueue) ? ((WMQueue)queue).getNativeQueueImpl() : queue;
    Message arg1 = (message instanceof WMMessage) ? ((WMMessage)message).getNativeMessageImpl() : message;
    getNativeQueueSenderImpl().send(arg0, arg1);
  }

  public void send(Queue queue, Message message, int deliveryMode, int priority, long timeToLive) throws JMSException {
    Queue arg0 = (queue instanceof WMQueue) ? ((WMQueue)queue).getNativeQueueImpl() : queue;
    Message arg1 = (message instanceof WMMessage) ? ((WMMessage)message).getNativeMessageImpl() : message;
    int arg2 = deliveryMode;
    int arg3 = priority;
    long arg4 = timeToLive;
    getNativeQueueSenderImpl().send(arg0, arg1, arg2, arg3, arg4);
  }



  //////////////////
  // inherited methods from class MessageProducer (proxy to custom WM objects)
  //////////////////
  public void setDisableMessageID(boolean value) throws JMSException {
    getInternalMessageProducerImpl().setDisableMessageID(value);
  }

  public boolean getDisableMessageID() throws JMSException {
    return getInternalMessageProducerImpl().getDisableMessageID();
  }

  public void setDisableMessageTimestamp(boolean value) throws JMSException {
    getInternalMessageProducerImpl().setDisableMessageTimestamp(value);
  }

  public boolean getDisableMessageTimestamp() throws JMSException {
    return getInternalMessageProducerImpl().getDisableMessageTimestamp();
  }

  public void setDeliveryMode(int deliveryMode) throws JMSException {
    getInternalMessageProducerImpl().setDeliveryMode(deliveryMode);
  }

  public int getDeliveryMode() throws JMSException {
    return getInternalMessageProducerImpl().getDeliveryMode();
  }

  public void setPriority(int defaultPriority) throws JMSException {
    getInternalMessageProducerImpl().setPriority(defaultPriority);
  }

  public int getPriority() throws JMSException {
    return getInternalMessageProducerImpl().getPriority();
  }

  public void setTimeToLive(long timeToLive) throws JMSException {
    getInternalMessageProducerImpl().setTimeToLive(timeToLive);
  }

  public long getTimeToLive() throws JMSException {
    return getInternalMessageProducerImpl().getTimeToLive();
  }

  public void close() throws JMSException {
    getInternalMessageProducerImpl().close();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMQueueSender newInstance(QueueSender nativeImpl) {
    try {
      WMQueueSender newObj = (WMQueueSender)_clazz.newInstance();
      newObj.setNativeQueueSenderImpl(nativeImpl);
      newObj.setNativeMessageProducerImpl((MessageProducer)nativeImpl);
      newObj.setInternalMessageProducerImpl(WMMessageProducer.newInstance((MessageProducer)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected QueueSender getNativeQueueSenderImpl() {
    return _queueSenderImpl;
  }

  protected void setNativeQueueSenderImpl(QueueSender nativeImpl) {
    _queueSenderImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe MessageProducer
  //////////////////
  private WMMessageProducer _internalMessageProducerImpl = null;
  private WMMessageProducer getInternalMessageProducerImpl() {
    return _internalMessageProducerImpl;
  }

  private void setInternalMessageProducerImpl(WMMessageProducer nativeImpl) {
    _internalMessageProducerImpl = nativeImpl;
  }

  protected WMQueueSender() { }
  private QueueSender _queueSenderImpl = null;
  private static Class _clazz = WMQueueSender.class;
}
