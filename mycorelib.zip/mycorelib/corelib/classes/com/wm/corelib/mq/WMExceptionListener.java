package com.wm.corelib.mq;

import javax.jms.*;

public class WMExceptionListener extends com.wm.corelib.mq.jmswrap.WMExceptionListener {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.ExceptionListener interface
  ////////////////////////////////

}
