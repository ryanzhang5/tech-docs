package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMXAQueueSession extends WMXASession implements XAQueueSession {

  public String toString() {
    return getNativeXAQueueSessionImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public QueueSession getQueueSession() throws JMSException {
    QueueSession rv = getNativeXAQueueSessionImpl().getQueueSession();
    if (rv == null) { return null; }
    rv = (QueueSession)WMQueueSession.newInstance((QueueSession)rv);
    return rv;
  }



  //////////////////
  // inherited methods from class Session (proxy to custom WM objects)
  //////////////////
  public BytesMessage createBytesMessage() throws JMSException {
    return getInternalSessionImpl().createBytesMessage();
  }

  public MapMessage createMapMessage() throws JMSException {
    return getInternalSessionImpl().createMapMessage();
  }

  public Message createMessage() throws JMSException {
    return getInternalSessionImpl().createMessage();
  }

  public ObjectMessage createObjectMessage() throws JMSException {
    return getInternalSessionImpl().createObjectMessage();
  }

  public ObjectMessage createObjectMessage(java.io.Serializable object) throws JMSException {
    return getInternalSessionImpl().createObjectMessage(object);
  }

  public StreamMessage createStreamMessage() throws JMSException {
    return getInternalSessionImpl().createStreamMessage();
  }

  public TextMessage createTextMessage() throws JMSException {
    return getInternalSessionImpl().createTextMessage();
  }

  public TextMessage createTextMessage(String text) throws JMSException {
    return getInternalSessionImpl().createTextMessage(text);
  }

  public boolean getTransacted() throws JMSException {
    return getInternalSessionImpl().getTransacted();
  }

  public void commit() throws JMSException {
    getInternalSessionImpl().commit();
  }

  public void rollback() throws JMSException {
    getInternalSessionImpl().rollback();
  }

  public void close() throws JMSException {
    getInternalSessionImpl().close();
  }

  public void recover() throws JMSException {
    getInternalSessionImpl().recover();
  }

  public MessageListener getMessageListener() throws JMSException {
    return getInternalSessionImpl().getMessageListener();
  }

  public void setMessageListener(MessageListener listener) throws JMSException {
    getInternalSessionImpl().setMessageListener(listener);
  }

  public void run()  {
    getInternalSessionImpl().run();
  }



  //////////////////
  // inherited methods from class XASession (proxy to custom WM objects)
  //////////////////
  public javax.transaction.xa.XAResource getXAResource()  {
    return getInternalXASessionImpl().getXAResource();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMXAQueueSession newInstance(XAQueueSession nativeImpl) {
    try {
      WMXAQueueSession newObj = (WMXAQueueSession)_clazz.newInstance();
      newObj.setNativeXAQueueSessionImpl(nativeImpl);
      newObj.setNativeSessionImpl((Session)nativeImpl);
      newObj.setInternalSessionImpl(WMSession.newInstance((Session)nativeImpl));
      newObj.setNativeXASessionImpl((XASession)nativeImpl);
      newObj.setInternalXASessionImpl(WMXASession.newInstance((XASession)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected XAQueueSession getNativeXAQueueSessionImpl() {
    return _xAQueueSessionImpl;
  }

  protected void setNativeXAQueueSessionImpl(XAQueueSession nativeImpl) {
    _xAQueueSessionImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe Session
  //////////////////
  private WMSession _internalSessionImpl = null;
  private WMSession getInternalSessionImpl() {
    return _internalSessionImpl;
  }

  private void setInternalSessionImpl(WMSession nativeImpl) {
    _internalSessionImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe XASession
  //////////////////
  private WMXASession _internalXASessionImpl = null;
  private WMXASession getInternalXASessionImpl() {
    return _internalXASessionImpl;
  }

  private void setInternalXASessionImpl(WMXASession nativeImpl) {
    _internalXASessionImpl = nativeImpl;
  }

  protected WMXAQueueSession() { }
  private XAQueueSession _xAQueueSessionImpl = null;
  private static Class _clazz = WMXAQueueSession.class;
}
