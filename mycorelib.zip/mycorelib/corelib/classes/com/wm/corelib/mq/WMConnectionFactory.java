package com.wm.corelib.mq;

import javax.jms.*;

public class WMConnectionFactory extends com.wm.corelib.mq.jmswrap.WMConnectionFactory {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.ConnectionFactory interface
  ////////////////////////////////

}
