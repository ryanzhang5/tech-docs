package com.wm.corelib.mq;

import javax.jms.*;

public class WMMessage extends com.wm.corelib.mq.jmswrap.WMMessage {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.Message interface
  ////////////////////////////////

}
