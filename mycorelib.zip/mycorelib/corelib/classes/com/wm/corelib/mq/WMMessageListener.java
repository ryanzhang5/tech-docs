package com.wm.corelib.mq;

import javax.jms.*;

public class WMMessageListener extends com.wm.corelib.mq.jmswrap.WMMessageListener {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.MessageListener interface
  ////////////////////////////////

}
