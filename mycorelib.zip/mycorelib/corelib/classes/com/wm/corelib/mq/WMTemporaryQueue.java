package com.wm.corelib.mq;

import javax.jms.*;

public class WMTemporaryQueue extends com.wm.corelib.mq.jmswrap.WMTemporaryQueue {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.TemporaryQueue interface
  ////////////////////////////////

}
