package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMMessageProducer implements MessageProducer {

  public String toString() {
    return getNativeMessageProducerImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public void setDisableMessageID(boolean value) throws JMSException {
    boolean arg0 = value;
    getNativeMessageProducerImpl().setDisableMessageID(arg0);
  }

  public boolean getDisableMessageID() throws JMSException {
    boolean rv = getNativeMessageProducerImpl().getDisableMessageID();
    return rv;
  }

  public void setDisableMessageTimestamp(boolean value) throws JMSException {
    boolean arg0 = value;
    getNativeMessageProducerImpl().setDisableMessageTimestamp(arg0);
  }

  public boolean getDisableMessageTimestamp() throws JMSException {
    boolean rv = getNativeMessageProducerImpl().getDisableMessageTimestamp();
    return rv;
  }

  public void setDeliveryMode(int deliveryMode) throws JMSException {
    int arg0 = deliveryMode;
    getNativeMessageProducerImpl().setDeliveryMode(arg0);
  }

  public int getDeliveryMode() throws JMSException {
    int rv = getNativeMessageProducerImpl().getDeliveryMode();
    return rv;
  }

  public void setPriority(int defaultPriority) throws JMSException {
    int arg0 = defaultPriority;
    getNativeMessageProducerImpl().setPriority(arg0);
  }

  public int getPriority() throws JMSException {
    int rv = getNativeMessageProducerImpl().getPriority();
    return rv;
  }

  public void setTimeToLive(long timeToLive) throws JMSException {
    long arg0 = timeToLive;
    getNativeMessageProducerImpl().setTimeToLive(arg0);
  }

  public long getTimeToLive() throws JMSException {
    long rv = getNativeMessageProducerImpl().getTimeToLive();
    return rv;
  }

  public void close() throws JMSException {
    getNativeMessageProducerImpl().close();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMMessageProducer newInstance(MessageProducer nativeImpl) {
    try {
      WMMessageProducer newObj = (WMMessageProducer)_clazz.newInstance();
      newObj.setNativeMessageProducerImpl(nativeImpl);
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected MessageProducer getNativeMessageProducerImpl() {
    return _messageProducerImpl;
  }

  protected void setNativeMessageProducerImpl(MessageProducer nativeImpl) {
    _messageProducerImpl = nativeImpl;
  }

  protected WMMessageProducer() { }
  private MessageProducer _messageProducerImpl = null;
  private static Class _clazz = WMMessageProducer.class;
}
