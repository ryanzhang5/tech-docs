package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMConnectionMetaData implements ConnectionMetaData {

  public String toString() {
    return getNativeConnectionMetaDataImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public String getJMSVersion() throws JMSException {
    String rv = getNativeConnectionMetaDataImpl().getJMSVersion();
    if (rv == null) { return null; }
    return rv;
  }

  public int getJMSMajorVersion() throws JMSException {
    int rv = getNativeConnectionMetaDataImpl().getJMSMajorVersion();
    return rv;
  }

  public int getJMSMinorVersion() throws JMSException {
    int rv = getNativeConnectionMetaDataImpl().getJMSMinorVersion();
    return rv;
  }

  public String getJMSProviderName() throws JMSException {
    String rv = getNativeConnectionMetaDataImpl().getJMSProviderName();
    if (rv == null) { return null; }
    return rv;
  }

  public String getProviderVersion() throws JMSException {
    String rv = getNativeConnectionMetaDataImpl().getProviderVersion();
    if (rv == null) { return null; }
    return rv;
  }

  public int getProviderMajorVersion() throws JMSException {
    int rv = getNativeConnectionMetaDataImpl().getProviderMajorVersion();
    return rv;
  }

  public int getProviderMinorVersion() throws JMSException {
    int rv = getNativeConnectionMetaDataImpl().getProviderMinorVersion();
    return rv;
  }

  public java.util.Enumeration getJMSXPropertyNames() throws JMSException {
    java.util.Enumeration rv = getNativeConnectionMetaDataImpl().getJMSXPropertyNames();
    return rv;
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMConnectionMetaData newInstance(ConnectionMetaData nativeImpl) {
    try {
      WMConnectionMetaData newObj = (WMConnectionMetaData)_clazz.newInstance();
      newObj.setNativeConnectionMetaDataImpl(nativeImpl);
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected ConnectionMetaData getNativeConnectionMetaDataImpl() {
    return _connectionMetaDataImpl;
  }

  protected void setNativeConnectionMetaDataImpl(ConnectionMetaData nativeImpl) {
    _connectionMetaDataImpl = nativeImpl;
  }

  protected WMConnectionMetaData() { }
  private ConnectionMetaData _connectionMetaDataImpl = null;
  private static Class _clazz = WMConnectionMetaData.class;
}
