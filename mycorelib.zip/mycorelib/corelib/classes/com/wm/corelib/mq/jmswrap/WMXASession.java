package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMXASession extends WMSession implements XASession {

  public String toString() {
    return getNativeXASessionImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public javax.transaction.xa.XAResource getXAResource()  {
    javax.transaction.xa.XAResource rv = getNativeXASessionImpl().getXAResource();
    return rv;
  }

  public boolean getTransacted() throws JMSException {
    boolean rv = getNativeXASessionImpl().getTransacted();
    return rv;
  }

  public void commit() throws JMSException {
    getNativeXASessionImpl().commit();
  }

  public void rollback() throws JMSException {
    getNativeXASessionImpl().rollback();
  }



  //////////////////
  // inherited methods from class Session (proxy to custom WM objects)
  //////////////////
  public BytesMessage createBytesMessage() throws JMSException {
    return getInternalSessionImpl().createBytesMessage();
  }

  public MapMessage createMapMessage() throws JMSException {
    return getInternalSessionImpl().createMapMessage();
  }

  public Message createMessage() throws JMSException {
    return getInternalSessionImpl().createMessage();
  }

  public ObjectMessage createObjectMessage() throws JMSException {
    return getInternalSessionImpl().createObjectMessage();
  }

  public ObjectMessage createObjectMessage(java.io.Serializable object) throws JMSException {
    return getInternalSessionImpl().createObjectMessage(object);
  }

  public StreamMessage createStreamMessage() throws JMSException {
    return getInternalSessionImpl().createStreamMessage();
  }

  public TextMessage createTextMessage() throws JMSException {
    return getInternalSessionImpl().createTextMessage();
  }

  public TextMessage createTextMessage(String text) throws JMSException {
    return getInternalSessionImpl().createTextMessage(text);
  }

  public void close() throws JMSException {
    getInternalSessionImpl().close();
  }

  public void recover() throws JMSException {
    getInternalSessionImpl().recover();
  }

  public MessageListener getMessageListener() throws JMSException {
    return getInternalSessionImpl().getMessageListener();
  }

  public void setMessageListener(MessageListener listener) throws JMSException {
    getInternalSessionImpl().setMessageListener(listener);
  }

  public void run()  {
    getInternalSessionImpl().run();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMXASession newInstance(XASession nativeImpl) {
    try {
      WMXASession newObj = (WMXASession)_clazz.newInstance();
      newObj.setNativeXASessionImpl(nativeImpl);
      newObj.setNativeSessionImpl((Session)nativeImpl);
      newObj.setInternalSessionImpl(WMSession.newInstance((Session)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected XASession getNativeXASessionImpl() {
    return _xASessionImpl;
  }

  protected void setNativeXASessionImpl(XASession nativeImpl) {
    _xASessionImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe Session
  //////////////////
  private WMSession _internalSessionImpl = null;
  private WMSession getInternalSessionImpl() {
    return _internalSessionImpl;
  }

  private void setInternalSessionImpl(WMSession nativeImpl) {
    _internalSessionImpl = nativeImpl;
  }

  protected WMXASession() { }
  private XASession _xASessionImpl = null;
  private static Class _clazz = WMXASession.class;
}
