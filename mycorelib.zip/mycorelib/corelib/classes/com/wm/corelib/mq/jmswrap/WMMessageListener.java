package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMMessageListener implements MessageListener {

  public String toString() {
    return getNativeMessageListenerImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public void onMessage(Message message)  {
    Message arg0 = (message instanceof WMMessage) ? ((WMMessage)message).getNativeMessageImpl() : message;
    getNativeMessageListenerImpl().onMessage(arg0);
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMMessageListener newInstance(MessageListener nativeImpl) {
    try {
      WMMessageListener newObj = (WMMessageListener)_clazz.newInstance();
      newObj.setNativeMessageListenerImpl(nativeImpl);
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected MessageListener getNativeMessageListenerImpl() {
    return _messageListenerImpl;
  }

  protected void setNativeMessageListenerImpl(MessageListener nativeImpl) {
    _messageListenerImpl = nativeImpl;
  }

  protected WMMessageListener() { }
  private MessageListener _messageListenerImpl = null;
  private static Class _clazz = WMMessageListener.class;
}
