package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMConnection implements Connection {

  public String toString() {
    return getNativeConnectionImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public String getClientID() throws JMSException {
    String rv = getNativeConnectionImpl().getClientID();
    if (rv == null) { return null; }
    return rv;
  }

  public void setClientID(String clientID) throws JMSException {
    String arg0 = clientID;
    getNativeConnectionImpl().setClientID(arg0);
  }

  public ConnectionMetaData getMetaData() throws JMSException {
    ConnectionMetaData rv = getNativeConnectionImpl().getMetaData();
    if (rv == null) { return null; }
    rv = (ConnectionMetaData)WMConnectionMetaData.newInstance((ConnectionMetaData)rv);
    return rv;
  }

  public ExceptionListener getExceptionListener() throws JMSException {
    ExceptionListener rv = getNativeConnectionImpl().getExceptionListener();
    if (rv == null) { return null; }
    rv = (ExceptionListener)WMExceptionListener.newInstance((ExceptionListener)rv);
    return rv;
  }

  public void setExceptionListener(ExceptionListener listener) throws JMSException {
    ExceptionListener arg0 = (listener instanceof WMExceptionListener) ? ((WMExceptionListener)listener).getNativeExceptionListenerImpl() : listener;
    getNativeConnectionImpl().setExceptionListener(arg0);
  }

  public void start() throws JMSException {
    getNativeConnectionImpl().start();
  }

  public void stop() throws JMSException {
    getNativeConnectionImpl().stop();
  }

  public void close() throws JMSException {
    getNativeConnectionImpl().close();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMConnection newInstance(Connection nativeImpl) {
    try {
      WMConnection newObj = (WMConnection)_clazz.newInstance();
      newObj.setNativeConnectionImpl(nativeImpl);
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected Connection getNativeConnectionImpl() {
    return _connectionImpl;
  }

  protected void setNativeConnectionImpl(Connection nativeImpl) {
    _connectionImpl = nativeImpl;
  }

  protected WMConnection() { }
  private Connection _connectionImpl = null;
  private static Class _clazz = WMConnection.class;
}
