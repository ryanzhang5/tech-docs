package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMXAConnection implements XAConnection {

  public String toString() {
    return getNativeXAConnectionImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////


  public static void setClass(Class c) { _clazz = c; }

  public static WMXAConnection newInstance(XAConnection nativeImpl) {
    try {
      WMXAConnection newObj = (WMXAConnection)_clazz.newInstance();
      newObj.setNativeXAConnectionImpl(nativeImpl);
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected XAConnection getNativeXAConnectionImpl() {
    return _xAConnectionImpl;
  }

  protected void setNativeXAConnectionImpl(XAConnection nativeImpl) {
    _xAConnectionImpl = nativeImpl;
  }

  protected WMXAConnection() { }
  private XAConnection _xAConnectionImpl = null;
  private static Class _clazz = WMXAConnection.class;
}
