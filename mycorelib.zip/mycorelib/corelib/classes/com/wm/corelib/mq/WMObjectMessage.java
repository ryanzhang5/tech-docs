package com.wm.corelib.mq;

import javax.jms.*;

public class WMObjectMessage extends com.wm.corelib.mq.jmswrap.WMObjectMessage {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.ObjectMessage interface
  ////////////////////////////////

}
