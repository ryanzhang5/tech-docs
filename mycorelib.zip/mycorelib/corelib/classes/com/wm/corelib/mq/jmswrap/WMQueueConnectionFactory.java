package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMQueueConnectionFactory extends WMConnectionFactory implements QueueConnectionFactory {

  public String toString() {
    return getNativeQueueConnectionFactoryImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public QueueConnection createQueueConnection() throws JMSException {
    QueueConnection rv = getNativeQueueConnectionFactoryImpl().createQueueConnection();
    if (rv == null) { return null; }
    else if (rv instanceof XAQueueConnection) {
      rv = (QueueConnection)WMXAQueueConnection.newInstance((XAQueueConnection)rv);
    }
    else {
      rv = (QueueConnection)WMQueueConnection.newInstance((QueueConnection)rv);
    }
    return rv;
  }

  public QueueConnection createQueueConnection(String userName, String password) throws JMSException {
    String arg0 = userName;
    String arg1 = password;
    QueueConnection rv = getNativeQueueConnectionFactoryImpl().createQueueConnection(arg0, arg1);
    if (rv == null) { return null; }
    else if (rv instanceof XAQueueConnection) {
      rv = (QueueConnection)WMXAQueueConnection.newInstance((XAQueueConnection)rv);
    }
    else {
      rv = (QueueConnection)WMQueueConnection.newInstance((QueueConnection)rv);
    }
    return rv;
  }



  //////////////////
  // inherited methods from class ConnectionFactory (proxy to custom WM objects)
  //////////////////


  public static void setClass(Class c) { _clazz = c; }

  public static WMQueueConnectionFactory newInstance(QueueConnectionFactory nativeImpl) {
    try {
      WMQueueConnectionFactory newObj = (WMQueueConnectionFactory)_clazz.newInstance();
      newObj.setNativeQueueConnectionFactoryImpl(nativeImpl);
      newObj.setNativeConnectionFactoryImpl((ConnectionFactory)nativeImpl);
      newObj.setInternalConnectionFactoryImpl(WMConnectionFactory.newInstance((ConnectionFactory)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected QueueConnectionFactory getNativeQueueConnectionFactoryImpl() {
    return _queueConnectionFactoryImpl;
  }

  protected void setNativeQueueConnectionFactoryImpl(QueueConnectionFactory nativeImpl) {
    _queueConnectionFactoryImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe ConnectionFactory
  //////////////////
  private WMConnectionFactory _internalConnectionFactoryImpl = null;
  private WMConnectionFactory getInternalConnectionFactoryImpl() {
    return _internalConnectionFactoryImpl;
  }

  private void setInternalConnectionFactoryImpl(WMConnectionFactory nativeImpl) {
    _internalConnectionFactoryImpl = nativeImpl;
  }

  protected WMQueueConnectionFactory() { }
  private QueueConnectionFactory _queueConnectionFactoryImpl = null;
  private static Class _clazz = WMQueueConnectionFactory.class;
}
