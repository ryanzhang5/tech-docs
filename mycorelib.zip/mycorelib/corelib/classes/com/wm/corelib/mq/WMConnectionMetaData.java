package com.wm.corelib.mq;

import javax.jms.*;

public class WMConnectionMetaData extends com.wm.corelib.mq.jmswrap.WMConnectionMetaData {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.ConnectionMetaData interface
  ////////////////////////////////

}
