package com.wm.corelib.mq;

import javax.jms.*;

public class WMTopicConnection extends com.wm.corelib.mq.jmswrap.WMTopicConnection {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.TopicConnection interface
  ////////////////////////////////

}
