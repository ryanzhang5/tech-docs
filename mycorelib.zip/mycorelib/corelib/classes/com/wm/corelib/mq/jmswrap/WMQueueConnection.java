package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMQueueConnection extends WMConnection implements QueueConnection {

  public String toString() {
    return getNativeQueueConnectionImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public QueueSession createQueueSession(boolean transacted, int acknowledgeMode) throws JMSException {
    boolean arg0 = transacted;
    int arg1 = acknowledgeMode;
    QueueSession rv = getNativeQueueConnectionImpl().createQueueSession(arg0, arg1);
    if (rv == null) { return null; }
    rv = (QueueSession)WMQueueSession.newInstance((QueueSession)rv);
    return rv;
  }

  public ConnectionConsumer createConnectionConsumer(Queue queue, String messageSelector, ServerSessionPool sessionPool, int maxMessages) throws JMSException {
    Queue arg0 = (queue instanceof WMQueue) ? ((WMQueue)queue).getNativeQueueImpl() : queue;
    String arg1 = messageSelector;
    ServerSessionPool arg2 = (sessionPool instanceof WMServerSessionPool) ? ((WMServerSessionPool)sessionPool).getNativeServerSessionPoolImpl() : sessionPool;
    int arg3 = maxMessages;
    ConnectionConsumer rv = getNativeQueueConnectionImpl().createConnectionConsumer(arg0, arg1, arg2, arg3);
    if (rv == null) { return null; }
    rv = (ConnectionConsumer)WMConnectionConsumer.newInstance((ConnectionConsumer)rv);
    return rv;
  }



  //////////////////
  // inherited methods from class Connection (proxy to custom WM objects)
  //////////////////
  public String getClientID() throws JMSException {
    return getInternalConnectionImpl().getClientID();
  }

  public void setClientID(String clientID) throws JMSException {
    getInternalConnectionImpl().setClientID(clientID);
  }

  public ConnectionMetaData getMetaData() throws JMSException {
    return getInternalConnectionImpl().getMetaData();
  }

  public ExceptionListener getExceptionListener() throws JMSException {
    return getInternalConnectionImpl().getExceptionListener();
  }

  public void setExceptionListener(ExceptionListener listener) throws JMSException {
    getInternalConnectionImpl().setExceptionListener(listener);
  }

  public void start() throws JMSException {
    getInternalConnectionImpl().start();
  }

  public void stop() throws JMSException {
    getInternalConnectionImpl().stop();
  }

  public void close() throws JMSException {
    getInternalConnectionImpl().close();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMQueueConnection newInstance(QueueConnection nativeImpl) {
    try {
      WMQueueConnection newObj = (WMQueueConnection)_clazz.newInstance();
      newObj.setNativeQueueConnectionImpl(nativeImpl);
      newObj.setNativeConnectionImpl((Connection)nativeImpl);
      newObj.setInternalConnectionImpl(WMConnection.newInstance((Connection)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected QueueConnection getNativeQueueConnectionImpl() {
    return _queueConnectionImpl;
  }

  protected void setNativeQueueConnectionImpl(QueueConnection nativeImpl) {
    _queueConnectionImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe Connection
  //////////////////
  private WMConnection _internalConnectionImpl = null;
  private WMConnection getInternalConnectionImpl() {
    return _internalConnectionImpl;
  }

  private void setInternalConnectionImpl(WMConnection nativeImpl) {
    _internalConnectionImpl = nativeImpl;
  }

  protected WMQueueConnection() { }
  private QueueConnection _queueConnectionImpl = null;
  private static Class _clazz = WMQueueConnection.class;
}
