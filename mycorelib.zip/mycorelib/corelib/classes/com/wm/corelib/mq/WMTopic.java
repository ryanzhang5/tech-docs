package com.wm.corelib.mq;

import javax.jms.*;

public class WMTopic extends com.wm.corelib.mq.jmswrap.WMTopic {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.Topic interface
  ////////////////////////////////

}
