package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMQueueBrowser implements QueueBrowser {

  public String toString() {
    return getNativeQueueBrowserImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public Queue getQueue() throws JMSException {
    Queue rv = getNativeQueueBrowserImpl().getQueue();
    if (rv == null) { return null; }
    else if (rv instanceof TemporaryQueue) {
      rv = (Queue)WMTemporaryQueue.newInstance((TemporaryQueue)rv);
    }
    else {
      rv = (Queue)WMQueue.newInstance((Queue)rv);
    }
    return rv;
  }

  public String getMessageSelector() throws JMSException {
    String rv = getNativeQueueBrowserImpl().getMessageSelector();
    if (rv == null) { return null; }
    return rv;
  }

  public java.util.Enumeration getEnumeration() throws JMSException {
    java.util.Enumeration rv = getNativeQueueBrowserImpl().getEnumeration();
    return rv;
  }

  public void close() throws JMSException {
    getNativeQueueBrowserImpl().close();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMQueueBrowser newInstance(QueueBrowser nativeImpl) {
    try {
      WMQueueBrowser newObj = (WMQueueBrowser)_clazz.newInstance();
      newObj.setNativeQueueBrowserImpl(nativeImpl);
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected QueueBrowser getNativeQueueBrowserImpl() {
    return _queueBrowserImpl;
  }

  protected void setNativeQueueBrowserImpl(QueueBrowser nativeImpl) {
    _queueBrowserImpl = nativeImpl;
  }

  protected WMQueueBrowser() { }
  private QueueBrowser _queueBrowserImpl = null;
  private static Class _clazz = WMQueueBrowser.class;
}
