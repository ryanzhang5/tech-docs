package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMSession implements Runnable, Session {

  public String toString() {
    return getNativeSessionImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public BytesMessage createBytesMessage() throws JMSException {
    BytesMessage rv = getNativeSessionImpl().createBytesMessage();
    if (rv == null) { return null; }
    rv = (BytesMessage)WMBytesMessage.newInstance((BytesMessage)rv);
    return rv;
  }

  public MapMessage createMapMessage() throws JMSException {
    MapMessage rv = getNativeSessionImpl().createMapMessage();
    if (rv == null) { return null; }
    rv = (MapMessage)WMMapMessage.newInstance((MapMessage)rv);
    return rv;
  }

  public Message createMessage() throws JMSException {
    Message rv = getNativeSessionImpl().createMessage();
    if (rv == null) { return null; }
    else if (rv instanceof TextMessage) {
      rv = (Message)WMTextMessage.newInstance((TextMessage)rv);
    }
    else if (rv instanceof StreamMessage) {
      rv = (Message)WMStreamMessage.newInstance((StreamMessage)rv);
    }
    else if (rv instanceof ObjectMessage) {
      rv = (Message)WMObjectMessage.newInstance((ObjectMessage)rv);
    }
    else if (rv instanceof MapMessage) {
      rv = (Message)WMMapMessage.newInstance((MapMessage)rv);
    }
    else if (rv instanceof BytesMessage) {
      rv = (Message)WMBytesMessage.newInstance((BytesMessage)rv);
    }
    else {
      rv = (Message)WMMessage.newInstance((Message)rv);
    }
    return rv;
  }

  public ObjectMessage createObjectMessage() throws JMSException {
    ObjectMessage rv = getNativeSessionImpl().createObjectMessage();
    if (rv == null) { return null; }
    rv = (ObjectMessage)WMObjectMessage.newInstance((ObjectMessage)rv);
    return rv;
  }

  public ObjectMessage createObjectMessage(java.io.Serializable object) throws JMSException {
    java.io.Serializable arg0 = object;
    ObjectMessage rv = getNativeSessionImpl().createObjectMessage(arg0);
    if (rv == null) { return null; }
    rv = (ObjectMessage)WMObjectMessage.newInstance((ObjectMessage)rv);
    return rv;
  }

  public StreamMessage createStreamMessage() throws JMSException {
    StreamMessage rv = getNativeSessionImpl().createStreamMessage();
    if (rv == null) { return null; }
    rv = (StreamMessage)WMStreamMessage.newInstance((StreamMessage)rv);
    return rv;
  }

  public TextMessage createTextMessage() throws JMSException {
    TextMessage rv = getNativeSessionImpl().createTextMessage();
    if (rv == null) { return null; }
    rv = (TextMessage)WMTextMessage.newInstance((TextMessage)rv);
    return rv;
  }

  public TextMessage createTextMessage(String text) throws JMSException {
    String arg0 = text;
    TextMessage rv = getNativeSessionImpl().createTextMessage(arg0);
    if (rv == null) { return null; }
    rv = (TextMessage)WMTextMessage.newInstance((TextMessage)rv);
    return rv;
  }

  public boolean getTransacted() throws JMSException {
    boolean rv = getNativeSessionImpl().getTransacted();
    return rv;
  }

  public void commit() throws JMSException {
    getNativeSessionImpl().commit();
  }

  public void rollback() throws JMSException {
    getNativeSessionImpl().rollback();
  }

  public void close() throws JMSException {
    getNativeSessionImpl().close();
  }

  public void recover() throws JMSException {
    getNativeSessionImpl().recover();
  }

  public MessageListener getMessageListener() throws JMSException {
    MessageListener rv = getNativeSessionImpl().getMessageListener();
    if (rv == null) { return null; }
    rv = (MessageListener)WMMessageListener.newInstance((MessageListener)rv);
    return rv;
  }

  public void setMessageListener(MessageListener listener) throws JMSException {
    MessageListener arg0 = (listener instanceof WMMessageListener) ? ((WMMessageListener)listener).getNativeMessageListenerImpl() : listener;
    getNativeSessionImpl().setMessageListener(arg0);
  }

  public void run()  {
    getNativeSessionImpl().run();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMSession newInstance(Session nativeImpl) {
    try {
      WMSession newObj = (WMSession)_clazz.newInstance();
      newObj.setNativeSessionImpl(nativeImpl);
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected Session getNativeSessionImpl() {
    return _sessionImpl;
  }

  protected void setNativeSessionImpl(Session nativeImpl) {
    _sessionImpl = nativeImpl;
  }

  protected WMSession() { }
  private Session _sessionImpl = null;
  private static Class _clazz = WMSession.class;
}
