package com.wm.corelib.mq;

import javax.jms.*;

public class WMXASession extends com.wm.corelib.mq.jmswrap.WMXASession {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.XASession interface
  ////////////////////////////////

}
