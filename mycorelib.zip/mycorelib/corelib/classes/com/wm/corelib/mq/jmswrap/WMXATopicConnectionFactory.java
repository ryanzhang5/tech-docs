package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMXATopicConnectionFactory extends WMTopicConnectionFactory implements XAConnectionFactory, XATopicConnectionFactory {

  public String toString() {
    return getNativeXATopicConnectionFactoryImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public XATopicConnection createXATopicConnection() throws JMSException {
    XATopicConnection rv = getNativeXATopicConnectionFactoryImpl().createXATopicConnection();
    if (rv == null) { return null; }
    rv = (XATopicConnection)WMXATopicConnection.newInstance((XATopicConnection)rv);
    return rv;
  }

  public XATopicConnection createXATopicConnection(String userName, String password) throws JMSException {
    String arg0 = userName;
    String arg1 = password;
    XATopicConnection rv = getNativeXATopicConnectionFactoryImpl().createXATopicConnection(arg0, arg1);
    if (rv == null) { return null; }
    rv = (XATopicConnection)WMXATopicConnection.newInstance((XATopicConnection)rv);
    return rv;
  }



  //////////////////
  // inherited methods from class ConnectionFactory (proxy to custom WM objects)
  //////////////////


  //////////////////
  // inherited methods from class XAConnectionFactory (proxy to custom WM objects)
  //////////////////


  //////////////////
  // inherited methods from class TopicConnectionFactory (proxy to custom WM objects)
  //////////////////
  public TopicConnection createTopicConnection() throws JMSException {
    return getInternalTopicConnectionFactoryImpl().createTopicConnection();
  }

  public TopicConnection createTopicConnection(String userName, String password) throws JMSException {
    return getInternalTopicConnectionFactoryImpl().createTopicConnection(userName, password);
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMXATopicConnectionFactory newInstance(XATopicConnectionFactory nativeImpl) {
    try {
      WMXATopicConnectionFactory newObj = (WMXATopicConnectionFactory)_clazz.newInstance();
      newObj.setNativeXATopicConnectionFactoryImpl(nativeImpl);
      newObj.setNativeConnectionFactoryImpl((ConnectionFactory)nativeImpl);
      newObj.setInternalConnectionFactoryImpl(WMConnectionFactory.newInstance((ConnectionFactory)nativeImpl));
      newObj.setInternalXAConnectionFactoryImpl(WMXAConnectionFactory.newInstance((XAConnectionFactory)nativeImpl));
      newObj.setNativeTopicConnectionFactoryImpl((TopicConnectionFactory)nativeImpl);
      newObj.setInternalTopicConnectionFactoryImpl(WMTopicConnectionFactory.newInstance((TopicConnectionFactory)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected XATopicConnectionFactory getNativeXATopicConnectionFactoryImpl() {
    return _xATopicConnectionFactoryImpl;
  }

  protected void setNativeXATopicConnectionFactoryImpl(XATopicConnectionFactory nativeImpl) {
    _xATopicConnectionFactoryImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe ConnectionFactory
  //////////////////
  private WMConnectionFactory _internalConnectionFactoryImpl = null;
  private WMConnectionFactory getInternalConnectionFactoryImpl() {
    return _internalConnectionFactoryImpl;
  }

  private void setInternalConnectionFactoryImpl(WMConnectionFactory nativeImpl) {
    _internalConnectionFactoryImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe XAConnectionFactory
  //////////////////
  private WMXAConnectionFactory _internalXAConnectionFactoryImpl = null;
  private WMXAConnectionFactory getInternalXAConnectionFactoryImpl() {
    return _internalXAConnectionFactoryImpl;
  }

  private void setInternalXAConnectionFactoryImpl(WMXAConnectionFactory nativeImpl) {
    _internalXAConnectionFactoryImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe TopicConnectionFactory
  //////////////////
  private WMTopicConnectionFactory _internalTopicConnectionFactoryImpl = null;
  private WMTopicConnectionFactory getInternalTopicConnectionFactoryImpl() {
    return _internalTopicConnectionFactoryImpl;
  }

  private void setInternalTopicConnectionFactoryImpl(WMTopicConnectionFactory nativeImpl) {
    _internalTopicConnectionFactoryImpl = nativeImpl;
  }

  protected WMXATopicConnectionFactory() { }
  private XATopicConnectionFactory _xATopicConnectionFactoryImpl = null;
  private static Class _clazz = WMXATopicConnectionFactory.class;
}
