package com.wm.corelib.mq;

import javax.jms.*;

public class WMStreamMessage extends com.wm.corelib.mq.jmswrap.WMStreamMessage {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.StreamMessage interface
  ////////////////////////////////

}
