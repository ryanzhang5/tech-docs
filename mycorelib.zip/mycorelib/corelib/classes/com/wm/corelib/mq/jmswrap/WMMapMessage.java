package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMMapMessage extends WMMessage implements MapMessage {

  public String toString() {
    return getNativeMapMessageImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public boolean getBoolean(String name) throws JMSException {
    String arg0 = name;
    boolean rv = getNativeMapMessageImpl().getBoolean(arg0);
    return rv;
  }

  public byte getByte(String name) throws JMSException {
    String arg0 = name;
    byte rv = getNativeMapMessageImpl().getByte(arg0);
    return rv;
  }

  public short getShort(String name) throws JMSException {
    String arg0 = name;
    short rv = getNativeMapMessageImpl().getShort(arg0);
    return rv;
  }

  public char getChar(String name) throws JMSException {
    String arg0 = name;
    char rv = getNativeMapMessageImpl().getChar(arg0);
    return rv;
  }

  public int getInt(String name) throws JMSException {
    String arg0 = name;
    int rv = getNativeMapMessageImpl().getInt(arg0);
    return rv;
  }

  public long getLong(String name) throws JMSException {
    String arg0 = name;
    long rv = getNativeMapMessageImpl().getLong(arg0);
    return rv;
  }

  public float getFloat(String name) throws JMSException {
    String arg0 = name;
    float rv = getNativeMapMessageImpl().getFloat(arg0);
    return rv;
  }

  public double getDouble(String name) throws JMSException {
    String arg0 = name;
    double rv = getNativeMapMessageImpl().getDouble(arg0);
    return rv;
  }

  public String getString(String name) throws JMSException {
    String arg0 = name;
    String rv = getNativeMapMessageImpl().getString(arg0);
    if (rv == null) { return null; }
    return rv;
  }

  public byte[] getBytes(String name) throws JMSException {
    String arg0 = name;
    byte[] rv = getNativeMapMessageImpl().getBytes(arg0);
    return rv;
  }

  public Object getObject(String name) throws JMSException {
    String arg0 = name;
    Object rv = getNativeMapMessageImpl().getObject(arg0);
    if (rv == null) { return null; }
    return rv;
  }

  public java.util.Enumeration getMapNames() throws JMSException {
    java.util.Enumeration rv = getNativeMapMessageImpl().getMapNames();
    return rv;
  }

  public void setBoolean(String name, boolean value) throws JMSException {
    String arg0 = name;
    boolean arg1 = value;
    getNativeMapMessageImpl().setBoolean(arg0, arg1);
  }

  public void setByte(String name, byte value) throws JMSException {
    String arg0 = name;
    byte arg1 = value;
    getNativeMapMessageImpl().setByte(arg0, arg1);
  }

  public void setShort(String name, short value) throws JMSException {
    String arg0 = name;
    short arg1 = value;
    getNativeMapMessageImpl().setShort(arg0, arg1);
  }

  public void setChar(String name, char value) throws JMSException {
    String arg0 = name;
    char arg1 = value;
    getNativeMapMessageImpl().setChar(arg0, arg1);
  }

  public void setInt(String name, int value) throws JMSException {
    String arg0 = name;
    int arg1 = value;
    getNativeMapMessageImpl().setInt(arg0, arg1);
  }

  public void setLong(String name, long value) throws JMSException {
    String arg0 = name;
    long arg1 = value;
    getNativeMapMessageImpl().setLong(arg0, arg1);
  }

  public void setFloat(String name, float value) throws JMSException {
    String arg0 = name;
    float arg1 = value;
    getNativeMapMessageImpl().setFloat(arg0, arg1);
  }

  public void setDouble(String name, double value) throws JMSException {
    String arg0 = name;
    double arg1 = value;
    getNativeMapMessageImpl().setDouble(arg0, arg1);
  }

  public void setString(String name, String value) throws JMSException {
    String arg0 = name;
    String arg1 = value;
    getNativeMapMessageImpl().setString(arg0, arg1);
  }

  public void setBytes(String name, byte[] value) throws JMSException {
    String arg0 = name;
    byte[] arg1 = value;
    getNativeMapMessageImpl().setBytes(arg0, arg1);
  }

  public void setBytes(String name, byte[] value, int offset, int length) throws JMSException {
    String arg0 = name;
    byte[] arg1 = value;
    int arg2 = offset;
    int arg3 = length;
    getNativeMapMessageImpl().setBytes(arg0, arg1, arg2, arg3);
  }

  public void setObject(String name, Object value) throws JMSException {
    String arg0 = name;
    Object arg1 = value;
    getNativeMapMessageImpl().setObject(arg0, arg1);
  }

  public boolean itemExists(String name) throws JMSException {
    String arg0 = name;
    boolean rv = getNativeMapMessageImpl().itemExists(arg0);
    return rv;
  }



  //////////////////
  // inherited methods from class Message (proxy to custom WM objects)
  //////////////////
  public String getJMSMessageID() throws JMSException {
    return getInternalMessageImpl().getJMSMessageID();
  }

  public void setJMSMessageID(String id) throws JMSException {
    getInternalMessageImpl().setJMSMessageID(id);
  }

  public long getJMSTimestamp() throws JMSException {
    return getInternalMessageImpl().getJMSTimestamp();
  }

  public void setJMSTimestamp(long timestamp) throws JMSException {
    getInternalMessageImpl().setJMSTimestamp(timestamp);
  }

  public byte[] getJMSCorrelationIDAsBytes() throws JMSException {
    return getInternalMessageImpl().getJMSCorrelationIDAsBytes();
  }

  public void setJMSCorrelationIDAsBytes(byte[] correlationID) throws JMSException {
    getInternalMessageImpl().setJMSCorrelationIDAsBytes(correlationID);
  }

  public void setJMSCorrelationID(String correlationID) throws JMSException {
    getInternalMessageImpl().setJMSCorrelationID(correlationID);
  }

  public String getJMSCorrelationID() throws JMSException {
    return getInternalMessageImpl().getJMSCorrelationID();
  }

  public Destination getJMSReplyTo() throws JMSException {
    return getInternalMessageImpl().getJMSReplyTo();
  }

  public void setJMSReplyTo(Destination replyTo) throws JMSException {
    getInternalMessageImpl().setJMSReplyTo(replyTo);
  }

  public Destination getJMSDestination() throws JMSException {
    return getInternalMessageImpl().getJMSDestination();
  }

  public void setJMSDestination(Destination destination) throws JMSException {
    getInternalMessageImpl().setJMSDestination(destination);
  }

  public int getJMSDeliveryMode() throws JMSException {
    return getInternalMessageImpl().getJMSDeliveryMode();
  }

  public void setJMSDeliveryMode(int deliveryMode) throws JMSException {
    getInternalMessageImpl().setJMSDeliveryMode(deliveryMode);
  }

  public boolean getJMSRedelivered() throws JMSException {
    return getInternalMessageImpl().getJMSRedelivered();
  }

  public void setJMSRedelivered(boolean redelivered) throws JMSException {
    getInternalMessageImpl().setJMSRedelivered(redelivered);
  }

  public String getJMSType() throws JMSException {
    return getInternalMessageImpl().getJMSType();
  }

  public void setJMSType(String type) throws JMSException {
    getInternalMessageImpl().setJMSType(type);
  }

  public long getJMSExpiration() throws JMSException {
    return getInternalMessageImpl().getJMSExpiration();
  }

  public void setJMSExpiration(long expiration) throws JMSException {
    getInternalMessageImpl().setJMSExpiration(expiration);
  }

  public int getJMSPriority() throws JMSException {
    return getInternalMessageImpl().getJMSPriority();
  }

  public void setJMSPriority(int priority) throws JMSException {
    getInternalMessageImpl().setJMSPriority(priority);
  }

  public void clearProperties() throws JMSException {
    getInternalMessageImpl().clearProperties();
  }

  public boolean propertyExists(String name) throws JMSException {
    return getInternalMessageImpl().propertyExists(name);
  }

  public boolean getBooleanProperty(String name) throws JMSException {
    return getInternalMessageImpl().getBooleanProperty(name);
  }

  public byte getByteProperty(String name) throws JMSException {
    return getInternalMessageImpl().getByteProperty(name);
  }

  public short getShortProperty(String name) throws JMSException {
    return getInternalMessageImpl().getShortProperty(name);
  }

  public int getIntProperty(String name) throws JMSException {
    return getInternalMessageImpl().getIntProperty(name);
  }

  public long getLongProperty(String name) throws JMSException {
    return getInternalMessageImpl().getLongProperty(name);
  }

  public float getFloatProperty(String name) throws JMSException {
    return getInternalMessageImpl().getFloatProperty(name);
  }

  public double getDoubleProperty(String name) throws JMSException {
    return getInternalMessageImpl().getDoubleProperty(name);
  }

  public String getStringProperty(String name) throws JMSException {
    return getInternalMessageImpl().getStringProperty(name);
  }

  public Object getObjectProperty(String name) throws JMSException {
    return getInternalMessageImpl().getObjectProperty(name);
  }

  public java.util.Enumeration getPropertyNames() throws JMSException {
    return getInternalMessageImpl().getPropertyNames();
  }

  public void setBooleanProperty(String name, boolean value) throws JMSException {
    getInternalMessageImpl().setBooleanProperty(name, value);
  }

  public void setByteProperty(String name, byte value) throws JMSException {
    getInternalMessageImpl().setByteProperty(name, value);
  }

  public void setShortProperty(String name, short value) throws JMSException {
    getInternalMessageImpl().setShortProperty(name, value);
  }

  public void setIntProperty(String name, int value) throws JMSException {
    getInternalMessageImpl().setIntProperty(name, value);
  }

  public void setLongProperty(String name, long value) throws JMSException {
    getInternalMessageImpl().setLongProperty(name, value);
  }

  public void setFloatProperty(String name, float value) throws JMSException {
    getInternalMessageImpl().setFloatProperty(name, value);
  }

  public void setDoubleProperty(String name, double value) throws JMSException {
    getInternalMessageImpl().setDoubleProperty(name, value);
  }

  public void setStringProperty(String name, String value) throws JMSException {
    getInternalMessageImpl().setStringProperty(name, value);
  }

  public void setObjectProperty(String name, Object value) throws JMSException {
    getInternalMessageImpl().setObjectProperty(name, value);
  }

  public void acknowledge() throws JMSException {
    getInternalMessageImpl().acknowledge();
  }

  public void clearBody() throws JMSException {
    getInternalMessageImpl().clearBody();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMMapMessage newInstance(MapMessage nativeImpl) {
    try {
      WMMapMessage newObj = (WMMapMessage)_clazz.newInstance();
      newObj.setNativeMapMessageImpl(nativeImpl);
      newObj.setNativeMessageImpl((Message)nativeImpl);
      newObj.setInternalMessageImpl(WMMessage.newInstance((Message)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected MapMessage getNativeMapMessageImpl() {
    return _mapMessageImpl;
  }

  protected void setNativeMapMessageImpl(MapMessage nativeImpl) {
    _mapMessageImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe Message
  //////////////////
  private WMMessage _internalMessageImpl = null;
  private WMMessage getInternalMessageImpl() {
    return _internalMessageImpl;
  }

  private void setInternalMessageImpl(WMMessage nativeImpl) {
    _internalMessageImpl = nativeImpl;
  }

  protected WMMapMessage() { }
  private MapMessage _mapMessageImpl = null;
  private static Class _clazz = WMMapMessage.class;
}
