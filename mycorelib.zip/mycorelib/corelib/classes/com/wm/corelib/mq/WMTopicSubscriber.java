package com.wm.corelib.mq;

import javax.jms.*;

public class WMTopicSubscriber extends com.wm.corelib.mq.jmswrap.WMTopicSubscriber {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.TopicSubscriber interface
  ////////////////////////////////

}
