package com.wm.corelib.mq;

import javax.jms.*;

public class WMMessageConsumer extends com.wm.corelib.mq.jmswrap.WMMessageConsumer {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.MessageConsumer interface
  ////////////////////////////////

}
