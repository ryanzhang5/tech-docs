package com.wm.corelib.mq;

import javax.jms.*;

public class WMQueue extends com.wm.corelib.mq.jmswrap.WMQueue {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.Queue interface
  ////////////////////////////////

}
