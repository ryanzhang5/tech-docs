package com.wm.corelib.mq;

import javax.jms.*;

public class WMDestination extends com.wm.corelib.mq.jmswrap.WMDestination {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.Destination interface
  ////////////////////////////////

}
