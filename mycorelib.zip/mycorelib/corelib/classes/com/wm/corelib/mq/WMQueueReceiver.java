package com.wm.corelib.mq;

import javax.jms.*;

public class WMQueueReceiver extends com.wm.corelib.mq.jmswrap.WMQueueReceiver {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.QueueReceiver interface
  ////////////////////////////////

}
