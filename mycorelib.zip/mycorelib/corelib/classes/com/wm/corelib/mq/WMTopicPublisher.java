package com.wm.corelib.mq;

import javax.jms.*;

public class WMTopicPublisher extends com.wm.corelib.mq.jmswrap.WMTopicPublisher {

  ////////////////////////////////
  // Use me to customize any portion of the javax.jms.TopicPublisher interface
  ////////////////////////////////

}
