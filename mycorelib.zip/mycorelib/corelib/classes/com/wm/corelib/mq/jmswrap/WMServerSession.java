package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMServerSession implements ServerSession {

  public String toString() {
    return getNativeServerSessionImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public Session getSession() throws JMSException {
    Session rv = getNativeServerSessionImpl().getSession();
    if (rv == null) { return null; }
    else if (rv instanceof QueueSession) {
      rv = (Session)WMQueueSession.newInstance((QueueSession)rv);
    }
    else if (rv instanceof TopicSession) {
      rv = (Session)WMTopicSession.newInstance((TopicSession)rv);
    }
    else if (rv instanceof XASession) {
      rv = (Session)WMXASession.newInstance((XASession)rv);
    }
    else if (rv instanceof XATopicSession) {
      rv = (Session)WMXATopicSession.newInstance((XATopicSession)rv);
    }
    else if (rv instanceof XAQueueSession) {
      rv = (Session)WMXAQueueSession.newInstance((XAQueueSession)rv);
    }
    else {
      rv = (Session)WMSession.newInstance((Session)rv);
    }
    return rv;
  }

  public void start() throws JMSException {
    getNativeServerSessionImpl().start();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMServerSession newInstance(ServerSession nativeImpl) {
    try {
      WMServerSession newObj = (WMServerSession)_clazz.newInstance();
      newObj.setNativeServerSessionImpl(nativeImpl);
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected ServerSession getNativeServerSessionImpl() {
    return _serverSessionImpl;
  }

  protected void setNativeServerSessionImpl(ServerSession nativeImpl) {
    _serverSessionImpl = nativeImpl;
  }

  protected WMServerSession() { }
  private ServerSession _serverSessionImpl = null;
  private static Class _clazz = WMServerSession.class;
}
