package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMTopicSubscriber extends WMMessageConsumer implements TopicSubscriber {

  public String toString() {
    return getNativeTopicSubscriberImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public Topic getTopic() throws JMSException {
    Topic rv = getNativeTopicSubscriberImpl().getTopic();
    if (rv == null) { return null; }
    else if (rv instanceof TemporaryTopic) {
      rv = (Topic)WMTemporaryTopic.newInstance((TemporaryTopic)rv);
    }
    else {
      rv = (Topic)WMTopic.newInstance((Topic)rv);
    }
    return rv;
  }

  public boolean getNoLocal() throws JMSException {
    boolean rv = getNativeTopicSubscriberImpl().getNoLocal();
    return rv;
  }



  //////////////////
  // inherited methods from class MessageConsumer (proxy to custom WM objects)
  //////////////////
  public String getMessageSelector() throws JMSException {
    return getInternalMessageConsumerImpl().getMessageSelector();
  }

  public MessageListener getMessageListener() throws JMSException {
    return getInternalMessageConsumerImpl().getMessageListener();
  }

  public void setMessageListener(MessageListener listener) throws JMSException {
    getInternalMessageConsumerImpl().setMessageListener(listener);
  }

  public Message receive() throws JMSException {
    return getInternalMessageConsumerImpl().receive();
  }

  public Message receive(long timeout) throws JMSException {
    return getInternalMessageConsumerImpl().receive(timeout);
  }

  public Message receiveNoWait() throws JMSException {
    return getInternalMessageConsumerImpl().receiveNoWait();
  }

  public void close() throws JMSException {
    getInternalMessageConsumerImpl().close();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMTopicSubscriber newInstance(TopicSubscriber nativeImpl) {
    try {
      WMTopicSubscriber newObj = (WMTopicSubscriber)_clazz.newInstance();
      newObj.setNativeTopicSubscriberImpl(nativeImpl);
      newObj.setNativeMessageConsumerImpl((MessageConsumer)nativeImpl);
      newObj.setInternalMessageConsumerImpl(WMMessageConsumer.newInstance((MessageConsumer)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected TopicSubscriber getNativeTopicSubscriberImpl() {
    return _topicSubscriberImpl;
  }

  protected void setNativeTopicSubscriberImpl(TopicSubscriber nativeImpl) {
    _topicSubscriberImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe MessageConsumer
  //////////////////
  private WMMessageConsumer _internalMessageConsumerImpl = null;
  private WMMessageConsumer getInternalMessageConsumerImpl() {
    return _internalMessageConsumerImpl;
  }

  private void setInternalMessageConsumerImpl(WMMessageConsumer nativeImpl) {
    _internalMessageConsumerImpl = nativeImpl;
  }

  protected WMTopicSubscriber() { }
  private TopicSubscriber _topicSubscriberImpl = null;
  private static Class _clazz = WMTopicSubscriber.class;
}
