package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMDestination implements Destination {

  public String toString() {
    return getNativeDestinationImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////


  public static void setClass(Class c) { _clazz = c; }

  public static WMDestination newInstance(Destination nativeImpl) {
    try {
      WMDestination newObj = (WMDestination)_clazz.newInstance();
      newObj.setNativeDestinationImpl(nativeImpl);
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected Destination getNativeDestinationImpl() {
    return _destinationImpl;
  }

  protected void setNativeDestinationImpl(Destination nativeImpl) {
    _destinationImpl = nativeImpl;
  }

  protected WMDestination() { }
  private Destination _destinationImpl = null;
  private static Class _clazz = WMDestination.class;
}
