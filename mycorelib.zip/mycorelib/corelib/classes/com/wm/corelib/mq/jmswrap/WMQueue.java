package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMQueue extends WMDestination implements Queue {

  public String toString() {
    return getNativeQueueImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public String getQueueName() throws JMSException {
    String rv = getNativeQueueImpl().getQueueName();
    if (rv == null) { return null; }
    return rv;
  }



  //////////////////
  // inherited methods from class Destination (proxy to custom WM objects)
  //////////////////


  public static void setClass(Class c) { _clazz = c; }

  public static WMQueue newInstance(Queue nativeImpl) {
    try {
      WMQueue newObj = (WMQueue)_clazz.newInstance();
      newObj.setNativeQueueImpl(nativeImpl);
      newObj.setNativeDestinationImpl((Destination)nativeImpl);
      newObj.setInternalDestinationImpl(WMDestination.newInstance((Destination)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected Queue getNativeQueueImpl() {
    return _queueImpl;
  }

  protected void setNativeQueueImpl(Queue nativeImpl) {
    _queueImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe Destination
  //////////////////
  private WMDestination _internalDestinationImpl = null;
  private WMDestination getInternalDestinationImpl() {
    return _internalDestinationImpl;
  }

  private void setInternalDestinationImpl(WMDestination nativeImpl) {
    _internalDestinationImpl = nativeImpl;
  }

  protected WMQueue() { }
  private Queue _queueImpl = null;
  private static Class _clazz = WMQueue.class;
}
