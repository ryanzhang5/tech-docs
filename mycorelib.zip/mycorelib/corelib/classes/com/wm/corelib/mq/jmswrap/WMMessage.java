package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMMessage implements Message {

  public String toString() {
    return getNativeMessageImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public String getJMSMessageID() throws JMSException {
    String rv = getNativeMessageImpl().getJMSMessageID();
    if (rv == null) { return null; }
    return rv;
  }

  public void setJMSMessageID(String id) throws JMSException {
    String arg0 = id;
    getNativeMessageImpl().setJMSMessageID(arg0);
  }

  public long getJMSTimestamp() throws JMSException {
    long rv = getNativeMessageImpl().getJMSTimestamp();
    return rv;
  }

  public void setJMSTimestamp(long timestamp) throws JMSException {
    long arg0 = timestamp;
    getNativeMessageImpl().setJMSTimestamp(arg0);
  }

  public byte[] getJMSCorrelationIDAsBytes() throws JMSException {
    byte[] rv = getNativeMessageImpl().getJMSCorrelationIDAsBytes();
    return rv;
  }

  public void setJMSCorrelationIDAsBytes(byte[] correlationID) throws JMSException {
    byte[] arg0 = correlationID;
    getNativeMessageImpl().setJMSCorrelationIDAsBytes(arg0);
  }

  public void setJMSCorrelationID(String correlationID) throws JMSException {
    String arg0 = correlationID;
    getNativeMessageImpl().setJMSCorrelationID(arg0);
  }

  public String getJMSCorrelationID() throws JMSException {
    String rv = getNativeMessageImpl().getJMSCorrelationID();
    if (rv == null) { return null; }
    return rv;
  }

  public Destination getJMSReplyTo() throws JMSException {
    Destination rv = getNativeMessageImpl().getJMSReplyTo();
    if (rv == null) { return null; }
    else if (rv instanceof Topic) {
      rv = (Destination)WMTopic.newInstance((Topic)rv);
    }
    else if (rv instanceof TemporaryTopic) {
      rv = (Destination)WMTemporaryTopic.newInstance((TemporaryTopic)rv);
    }
    else if (rv instanceof Queue) {
      rv = (Destination)WMQueue.newInstance((Queue)rv);
    }
    else if (rv instanceof TemporaryQueue) {
      rv = (Destination)WMTemporaryQueue.newInstance((TemporaryQueue)rv);
    }
    else {
      rv = (Destination)WMDestination.newInstance((Destination)rv);
    }
    return rv;
  }

  public void setJMSReplyTo(Destination replyTo) throws JMSException {
    Destination arg0 = (replyTo instanceof WMDestination) ? ((WMDestination)replyTo).getNativeDestinationImpl() : replyTo;
    getNativeMessageImpl().setJMSReplyTo(arg0);
  }

  public Destination getJMSDestination() throws JMSException {
    Destination rv = getNativeMessageImpl().getJMSDestination();
    if (rv == null) { return null; }
    else if (rv instanceof Topic) {
      rv = (Destination)WMTopic.newInstance((Topic)rv);
    }
    else if (rv instanceof TemporaryTopic) {
      rv = (Destination)WMTemporaryTopic.newInstance((TemporaryTopic)rv);
    }
    else if (rv instanceof Queue) {
      rv = (Destination)WMQueue.newInstance((Queue)rv);
    }
    else if (rv instanceof TemporaryQueue) {
      rv = (Destination)WMTemporaryQueue.newInstance((TemporaryQueue)rv);
    }
    else {
      rv = (Destination)WMDestination.newInstance((Destination)rv);
    }
    return rv;
  }

  public void setJMSDestination(Destination destination) throws JMSException {
    Destination arg0 = (destination instanceof WMDestination) ? ((WMDestination)destination).getNativeDestinationImpl() : destination;
    getNativeMessageImpl().setJMSDestination(arg0);
  }

  public int getJMSDeliveryMode() throws JMSException {
    int rv = getNativeMessageImpl().getJMSDeliveryMode();
    return rv;
  }

  public void setJMSDeliveryMode(int deliveryMode) throws JMSException {
    int arg0 = deliveryMode;
    getNativeMessageImpl().setJMSDeliveryMode(arg0);
  }

  public boolean getJMSRedelivered() throws JMSException {
    boolean rv = getNativeMessageImpl().getJMSRedelivered();
    return rv;
  }

  public void setJMSRedelivered(boolean redelivered) throws JMSException {
    boolean arg0 = redelivered;
    getNativeMessageImpl().setJMSRedelivered(arg0);
  }

  public String getJMSType() throws JMSException {
    String rv = getNativeMessageImpl().getJMSType();
    if (rv == null) { return null; }
    return rv;
  }

  public void setJMSType(String type) throws JMSException {
    String arg0 = type;
    getNativeMessageImpl().setJMSType(arg0);
  }

  public long getJMSExpiration() throws JMSException {
    long rv = getNativeMessageImpl().getJMSExpiration();
    return rv;
  }

  public void setJMSExpiration(long expiration) throws JMSException {
    long arg0 = expiration;
    getNativeMessageImpl().setJMSExpiration(arg0);
  }

  public int getJMSPriority() throws JMSException {
    int rv = getNativeMessageImpl().getJMSPriority();
    return rv;
  }

  public void setJMSPriority(int priority) throws JMSException {
    int arg0 = priority;
    getNativeMessageImpl().setJMSPriority(arg0);
  }

  public void clearProperties() throws JMSException {
    getNativeMessageImpl().clearProperties();
  }

  public boolean propertyExists(String name) throws JMSException {
    String arg0 = name;
    boolean rv = getNativeMessageImpl().propertyExists(arg0);
    return rv;
  }

  public boolean getBooleanProperty(String name) throws JMSException {
    String arg0 = name;
    boolean rv = getNativeMessageImpl().getBooleanProperty(arg0);
    return rv;
  }

  public byte getByteProperty(String name) throws JMSException {
    String arg0 = name;
    byte rv = getNativeMessageImpl().getByteProperty(arg0);
    return rv;
  }

  public short getShortProperty(String name) throws JMSException {
    String arg0 = name;
    short rv = getNativeMessageImpl().getShortProperty(arg0);
    return rv;
  }

  public int getIntProperty(String name) throws JMSException {
    String arg0 = name;
    int rv = getNativeMessageImpl().getIntProperty(arg0);
    return rv;
  }

  public long getLongProperty(String name) throws JMSException {
    String arg0 = name;
    long rv = getNativeMessageImpl().getLongProperty(arg0);
    return rv;
  }

  public float getFloatProperty(String name) throws JMSException {
    String arg0 = name;
    float rv = getNativeMessageImpl().getFloatProperty(arg0);
    return rv;
  }

  public double getDoubleProperty(String name) throws JMSException {
    String arg0 = name;
    double rv = getNativeMessageImpl().getDoubleProperty(arg0);
    return rv;
  }

  public String getStringProperty(String name) throws JMSException {
    String arg0 = name;
    String rv = getNativeMessageImpl().getStringProperty(arg0);
    if (rv == null) { return null; }
    return rv;
  }

  public Object getObjectProperty(String name) throws JMSException {
    String arg0 = name;
    Object rv = getNativeMessageImpl().getObjectProperty(arg0);
    if (rv == null) { return null; }
    return rv;
  }

  public java.util.Enumeration getPropertyNames() throws JMSException {
    java.util.Enumeration rv = getNativeMessageImpl().getPropertyNames();
    return rv;
  }

  public void setBooleanProperty(String name, boolean value) throws JMSException {
    String arg0 = name;
    boolean arg1 = value;
    getNativeMessageImpl().setBooleanProperty(arg0, arg1);
  }

  public void setByteProperty(String name, byte value) throws JMSException {
    String arg0 = name;
    byte arg1 = value;
    getNativeMessageImpl().setByteProperty(arg0, arg1);
  }

  public void setShortProperty(String name, short value) throws JMSException {
    String arg0 = name;
    short arg1 = value;
    getNativeMessageImpl().setShortProperty(arg0, arg1);
  }

  public void setIntProperty(String name, int value) throws JMSException {
    String arg0 = name;
    int arg1 = value;
    getNativeMessageImpl().setIntProperty(arg0, arg1);
  }

  public void setLongProperty(String name, long value) throws JMSException {
    String arg0 = name;
    long arg1 = value;
    getNativeMessageImpl().setLongProperty(arg0, arg1);
  }

  public void setFloatProperty(String name, float value) throws JMSException {
    String arg0 = name;
    float arg1 = value;
    getNativeMessageImpl().setFloatProperty(arg0, arg1);
  }

  public void setDoubleProperty(String name, double value) throws JMSException {
    String arg0 = name;
    double arg1 = value;
    getNativeMessageImpl().setDoubleProperty(arg0, arg1);
  }

  public void setStringProperty(String name, String value) throws JMSException {
    String arg0 = name;
    String arg1 = value;
    getNativeMessageImpl().setStringProperty(arg0, arg1);
  }

  public void setObjectProperty(String name, Object value) throws JMSException {
    String arg0 = name;
    Object arg1 = value;
    getNativeMessageImpl().setObjectProperty(arg0, arg1);
  }

  public void acknowledge() throws JMSException {
    getNativeMessageImpl().acknowledge();
  }

  public void clearBody() throws JMSException {
    getNativeMessageImpl().clearBody();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMMessage newInstance(Message nativeImpl) {
    try {
      WMMessage newObj = (WMMessage)_clazz.newInstance();
      newObj.setNativeMessageImpl(nativeImpl);
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected Message getNativeMessageImpl() {
    return _messageImpl;
  }

  protected void setNativeMessageImpl(Message nativeImpl) {
    _messageImpl = nativeImpl;
  }

  protected WMMessage() { }
  private Message _messageImpl = null;
  private static Class _clazz = WMMessage.class;
}
