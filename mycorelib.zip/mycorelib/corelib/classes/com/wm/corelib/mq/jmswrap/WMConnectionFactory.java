package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMConnectionFactory implements ConnectionFactory {

  public String toString() {
    return getNativeConnectionFactoryImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////


  public static void setClass(Class c) { _clazz = c; }

  public static WMConnectionFactory newInstance(ConnectionFactory nativeImpl) {
    try {
      WMConnectionFactory newObj = (WMConnectionFactory)_clazz.newInstance();
      newObj.setNativeConnectionFactoryImpl(nativeImpl);
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected ConnectionFactory getNativeConnectionFactoryImpl() {
    return _connectionFactoryImpl;
  }

  protected void setNativeConnectionFactoryImpl(ConnectionFactory nativeImpl) {
    _connectionFactoryImpl = nativeImpl;
  }

  protected WMConnectionFactory() { }
  private ConnectionFactory _connectionFactoryImpl = null;
  private static Class _clazz = WMConnectionFactory.class;
}
