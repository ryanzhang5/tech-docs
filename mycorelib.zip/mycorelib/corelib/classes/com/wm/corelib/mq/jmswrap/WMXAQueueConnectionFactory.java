package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMXAQueueConnectionFactory extends WMQueueConnectionFactory implements XAConnectionFactory, XAQueueConnectionFactory {

  public String toString() {
    return getNativeXAQueueConnectionFactoryImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public XAQueueConnection createXAQueueConnection() throws JMSException {
    XAQueueConnection rv = getNativeXAQueueConnectionFactoryImpl().createXAQueueConnection();
    if (rv == null) { return null; }
    rv = (XAQueueConnection)WMXAQueueConnection.newInstance((XAQueueConnection)rv);
    return rv;
  }

  public XAQueueConnection createXAQueueConnection(String userName, String password) throws JMSException {
    String arg0 = userName;
    String arg1 = password;
    XAQueueConnection rv = getNativeXAQueueConnectionFactoryImpl().createXAQueueConnection(arg0, arg1);
    if (rv == null) { return null; }
    rv = (XAQueueConnection)WMXAQueueConnection.newInstance((XAQueueConnection)rv);
    return rv;
  }



  //////////////////
  // inherited methods from class ConnectionFactory (proxy to custom WM objects)
  //////////////////


  //////////////////
  // inherited methods from class QueueConnectionFactory (proxy to custom WM objects)
  //////////////////
  public QueueConnection createQueueConnection() throws JMSException {
    return getInternalQueueConnectionFactoryImpl().createQueueConnection();
  }

  public QueueConnection createQueueConnection(String userName, String password) throws JMSException {
    return getInternalQueueConnectionFactoryImpl().createQueueConnection(userName, password);
  }



  //////////////////
  // inherited methods from class XAConnectionFactory (proxy to custom WM objects)
  //////////////////


  public static void setClass(Class c) { _clazz = c; }

  public static WMXAQueueConnectionFactory newInstance(XAQueueConnectionFactory nativeImpl) {
    try {
      WMXAQueueConnectionFactory newObj = (WMXAQueueConnectionFactory)_clazz.newInstance();
      newObj.setNativeXAQueueConnectionFactoryImpl(nativeImpl);
      newObj.setNativeConnectionFactoryImpl((ConnectionFactory)nativeImpl);
      newObj.setInternalConnectionFactoryImpl(WMConnectionFactory.newInstance((ConnectionFactory)nativeImpl));
      newObj.setNativeQueueConnectionFactoryImpl((QueueConnectionFactory)nativeImpl);
      newObj.setInternalQueueConnectionFactoryImpl(WMQueueConnectionFactory.newInstance((QueueConnectionFactory)nativeImpl));
      newObj.setInternalXAConnectionFactoryImpl(WMXAConnectionFactory.newInstance((XAConnectionFactory)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected XAQueueConnectionFactory getNativeXAQueueConnectionFactoryImpl() {
    return _xAQueueConnectionFactoryImpl;
  }

  protected void setNativeXAQueueConnectionFactoryImpl(XAQueueConnectionFactory nativeImpl) {
    _xAQueueConnectionFactoryImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe ConnectionFactory
  //////////////////
  private WMConnectionFactory _internalConnectionFactoryImpl = null;
  private WMConnectionFactory getInternalConnectionFactoryImpl() {
    return _internalConnectionFactoryImpl;
  }

  private void setInternalConnectionFactoryImpl(WMConnectionFactory nativeImpl) {
    _internalConnectionFactoryImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe QueueConnectionFactory
  //////////////////
  private WMQueueConnectionFactory _internalQueueConnectionFactoryImpl = null;
  private WMQueueConnectionFactory getInternalQueueConnectionFactoryImpl() {
    return _internalQueueConnectionFactoryImpl;
  }

  private void setInternalQueueConnectionFactoryImpl(WMQueueConnectionFactory nativeImpl) {
    _internalQueueConnectionFactoryImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe XAConnectionFactory
  //////////////////
  private WMXAConnectionFactory _internalXAConnectionFactoryImpl = null;
  private WMXAConnectionFactory getInternalXAConnectionFactoryImpl() {
    return _internalXAConnectionFactoryImpl;
  }

  private void setInternalXAConnectionFactoryImpl(WMXAConnectionFactory nativeImpl) {
    _internalXAConnectionFactoryImpl = nativeImpl;
  }

  protected WMXAQueueConnectionFactory() { }
  private XAQueueConnectionFactory _xAQueueConnectionFactoryImpl = null;
  private static Class _clazz = WMXAQueueConnectionFactory.class;
}
