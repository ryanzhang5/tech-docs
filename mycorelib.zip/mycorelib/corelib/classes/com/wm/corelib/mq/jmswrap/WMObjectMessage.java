package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMObjectMessage extends WMMessage implements ObjectMessage {

  public String toString() {
    return getNativeObjectMessageImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public void setObject(java.io.Serializable object) throws JMSException {
    java.io.Serializable arg0 = object;
    getNativeObjectMessageImpl().setObject(arg0);
  }

  public java.io.Serializable getObject() throws JMSException {
    java.io.Serializable rv = getNativeObjectMessageImpl().getObject();
    return rv;
  }



  //////////////////
  // inherited methods from class Message (proxy to custom WM objects)
  //////////////////
  public String getJMSMessageID() throws JMSException {
    return getInternalMessageImpl().getJMSMessageID();
  }

  public void setJMSMessageID(String id) throws JMSException {
    getInternalMessageImpl().setJMSMessageID(id);
  }

  public long getJMSTimestamp() throws JMSException {
    return getInternalMessageImpl().getJMSTimestamp();
  }

  public void setJMSTimestamp(long timestamp) throws JMSException {
    getInternalMessageImpl().setJMSTimestamp(timestamp);
  }

  public byte[] getJMSCorrelationIDAsBytes() throws JMSException {
    return getInternalMessageImpl().getJMSCorrelationIDAsBytes();
  }

  public void setJMSCorrelationIDAsBytes(byte[] correlationID) throws JMSException {
    getInternalMessageImpl().setJMSCorrelationIDAsBytes(correlationID);
  }

  public void setJMSCorrelationID(String correlationID) throws JMSException {
    getInternalMessageImpl().setJMSCorrelationID(correlationID);
  }

  public String getJMSCorrelationID() throws JMSException {
    return getInternalMessageImpl().getJMSCorrelationID();
  }

  public Destination getJMSReplyTo() throws JMSException {
    return getInternalMessageImpl().getJMSReplyTo();
  }

  public void setJMSReplyTo(Destination replyTo) throws JMSException {
    getInternalMessageImpl().setJMSReplyTo(replyTo);
  }

  public Destination getJMSDestination() throws JMSException {
    return getInternalMessageImpl().getJMSDestination();
  }

  public void setJMSDestination(Destination destination) throws JMSException {
    getInternalMessageImpl().setJMSDestination(destination);
  }

  public int getJMSDeliveryMode() throws JMSException {
    return getInternalMessageImpl().getJMSDeliveryMode();
  }

  public void setJMSDeliveryMode(int deliveryMode) throws JMSException {
    getInternalMessageImpl().setJMSDeliveryMode(deliveryMode);
  }

  public boolean getJMSRedelivered() throws JMSException {
    return getInternalMessageImpl().getJMSRedelivered();
  }

  public void setJMSRedelivered(boolean redelivered) throws JMSException {
    getInternalMessageImpl().setJMSRedelivered(redelivered);
  }

  public String getJMSType() throws JMSException {
    return getInternalMessageImpl().getJMSType();
  }

  public void setJMSType(String type) throws JMSException {
    getInternalMessageImpl().setJMSType(type);
  }

  public long getJMSExpiration() throws JMSException {
    return getInternalMessageImpl().getJMSExpiration();
  }

  public void setJMSExpiration(long expiration) throws JMSException {
    getInternalMessageImpl().setJMSExpiration(expiration);
  }

  public int getJMSPriority() throws JMSException {
    return getInternalMessageImpl().getJMSPriority();
  }

  public void setJMSPriority(int priority) throws JMSException {
    getInternalMessageImpl().setJMSPriority(priority);
  }

  public void clearProperties() throws JMSException {
    getInternalMessageImpl().clearProperties();
  }

  public boolean propertyExists(String name) throws JMSException {
    return getInternalMessageImpl().propertyExists(name);
  }

  public boolean getBooleanProperty(String name) throws JMSException {
    return getInternalMessageImpl().getBooleanProperty(name);
  }

  public byte getByteProperty(String name) throws JMSException {
    return getInternalMessageImpl().getByteProperty(name);
  }

  public short getShortProperty(String name) throws JMSException {
    return getInternalMessageImpl().getShortProperty(name);
  }

  public int getIntProperty(String name) throws JMSException {
    return getInternalMessageImpl().getIntProperty(name);
  }

  public long getLongProperty(String name) throws JMSException {
    return getInternalMessageImpl().getLongProperty(name);
  }

  public float getFloatProperty(String name) throws JMSException {
    return getInternalMessageImpl().getFloatProperty(name);
  }

  public double getDoubleProperty(String name) throws JMSException {
    return getInternalMessageImpl().getDoubleProperty(name);
  }

  public String getStringProperty(String name) throws JMSException {
    return getInternalMessageImpl().getStringProperty(name);
  }

  public Object getObjectProperty(String name) throws JMSException {
    return getInternalMessageImpl().getObjectProperty(name);
  }

  public java.util.Enumeration getPropertyNames() throws JMSException {
    return getInternalMessageImpl().getPropertyNames();
  }

  public void setBooleanProperty(String name, boolean value) throws JMSException {
    getInternalMessageImpl().setBooleanProperty(name, value);
  }

  public void setByteProperty(String name, byte value) throws JMSException {
    getInternalMessageImpl().setByteProperty(name, value);
  }

  public void setShortProperty(String name, short value) throws JMSException {
    getInternalMessageImpl().setShortProperty(name, value);
  }

  public void setIntProperty(String name, int value) throws JMSException {
    getInternalMessageImpl().setIntProperty(name, value);
  }

  public void setLongProperty(String name, long value) throws JMSException {
    getInternalMessageImpl().setLongProperty(name, value);
  }

  public void setFloatProperty(String name, float value) throws JMSException {
    getInternalMessageImpl().setFloatProperty(name, value);
  }

  public void setDoubleProperty(String name, double value) throws JMSException {
    getInternalMessageImpl().setDoubleProperty(name, value);
  }

  public void setStringProperty(String name, String value) throws JMSException {
    getInternalMessageImpl().setStringProperty(name, value);
  }

  public void setObjectProperty(String name, Object value) throws JMSException {
    getInternalMessageImpl().setObjectProperty(name, value);
  }

  public void acknowledge() throws JMSException {
    getInternalMessageImpl().acknowledge();
  }

  public void clearBody() throws JMSException {
    getInternalMessageImpl().clearBody();
  }



  public static void setClass(Class c) { _clazz = c; }

  public static WMObjectMessage newInstance(ObjectMessage nativeImpl) {
    try {
      WMObjectMessage newObj = (WMObjectMessage)_clazz.newInstance();
      newObj.setNativeObjectMessageImpl(nativeImpl);
      newObj.setNativeMessageImpl((Message)nativeImpl);
      newObj.setInternalMessageImpl(WMMessage.newInstance((Message)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected ObjectMessage getNativeObjectMessageImpl() {
    return _objectMessageImpl;
  }

  protected void setNativeObjectMessageImpl(ObjectMessage nativeImpl) {
    _objectMessageImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe Message
  //////////////////
  private WMMessage _internalMessageImpl = null;
  private WMMessage getInternalMessageImpl() {
    return _internalMessageImpl;
  }

  private void setInternalMessageImpl(WMMessage nativeImpl) {
    _internalMessageImpl = nativeImpl;
  }

  protected WMObjectMessage() { }
  private ObjectMessage _objectMessageImpl = null;
  private static Class _clazz = WMObjectMessage.class;
}
