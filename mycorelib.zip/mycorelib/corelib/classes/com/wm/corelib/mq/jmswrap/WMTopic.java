package com.wm.corelib.mq.jmswrap;

import javax.jms.*;

public class WMTopic extends WMDestination implements Topic {

  public String toString() {
    return getNativeTopicImpl().toString();
  }

  //////////////////
  // declared interface methods
  //////////////////
  public String getTopicName() throws JMSException {
    String rv = getNativeTopicImpl().getTopicName();
    if (rv == null) { return null; }
    return rv;
  }



  //////////////////
  // inherited methods from class Destination (proxy to custom WM objects)
  //////////////////


  public static void setClass(Class c) { _clazz = c; }

  public static WMTopic newInstance(Topic nativeImpl) {
    try {
      WMTopic newObj = (WMTopic)_clazz.newInstance();
      newObj.setNativeTopicImpl(nativeImpl);
      newObj.setNativeDestinationImpl((Destination)nativeImpl);
      newObj.setInternalDestinationImpl(WMDestination.newInstance((Destination)nativeImpl));
      return newObj;
    }
    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }
    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }
    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }

    /* UNREACHABLE */
  }

  //////////////////
  // native implementation access methods
  //////////////////
  protected Topic getNativeTopicImpl() {
    return _topicImpl;
  }

  protected void setNativeTopicImpl(Topic nativeImpl) {
    _topicImpl = nativeImpl;
  }

  //////////////////
  // internal proxy implementations for parent classe Destination
  //////////////////
  private WMDestination _internalDestinationImpl = null;
  private WMDestination getInternalDestinationImpl() {
    return _internalDestinationImpl;
  }

  private void setInternalDestinationImpl(WMDestination nativeImpl) {
    _internalDestinationImpl = nativeImpl;
  }

  protected WMTopic() { }
  private Topic _topicImpl = null;
  private static Class _clazz = WMTopic.class;
}
