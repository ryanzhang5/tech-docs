package com.wm.corelib.jmxadmin;

import javax.management.StandardMBean;
import javax.management.NotCompliantMBeanException;
import javax.management.MBeanOperationInfo;
import javax.management.MBeanParameterInfo;
import java.util.Map;
import java.util.HashMap;
import java.lang.reflect.Method;
import java.lang.annotation.Annotation;
import com.wm.corelib.annotation.Description;
import com.wm.corelib.annotation.PName;

/**
 * AnnotatedStandardMBean
 *
 * Wrapper around standard MBeans that provides support for descriptions of methods and parameters
 *
 * Acknowledgement: Eamonn McManus
 *                  http://weblogs.java.net/blog/emcmanus/archive/2005/07/adding_informat.html
 *
 * @author Igor.Dralyuk@walmart.com
 * @version $Id: AnnotatedStandardMBean.java,v 1.2 2009/04/08 05:14:00 mkishore Exp $
 * @since October 2005
 */

public class AnnotatedStandardMBean extends StandardMBean {

    /** Instance where the MBean interface is implemented by another object. */
    public <T> AnnotatedStandardMBean(T impl, Class<T> mbeanInterface) throws NotCompliantMBeanException {
        super(impl, mbeanInterface);
    }

    /** Instance where the MBean interface is implemented by this object. */
    protected AnnotatedStandardMBean(Class<?> mbeanInterface) throws NotCompliantMBeanException {
        super(mbeanInterface);
    }

    // Array of primitive types, used to populate the Map below
    private static Class<?>[] prims = {
            byte.class, short.class, int.class, long.class,
            float.class, double.class, char.class, boolean.class
    };

    // Map of primitive classes, used by classForName below
    private static final Map<String, Class<?>> primitiveClasses;

    static {
        primitiveClasses =  new HashMap<String, Class<?>>(prims.length);
        for (Class<?> c : prims) primitiveClasses.put(c.getName(), c);
    }

    /**
     * Helper method to get primitive classes
     *
     * Finding the method corresponding to an MBeanOperationInfo is not completely straightforward
     * because the parameter types in the contained MBeanParameterInfo[] are expressed as String
     * rather than Class. (This is because Class is not serializable.) Each String is the result of
     * Class.getName() on the corresponding Class. We need the original Class objects so that we
     * can call Class.getMethod to find the Method object and access its annotations.
     *
     * Unfortunately, there is no standard method to convert back from Class.getName() to the
     * original Class. Class.forName comes close, but it doesn't do the right thing for primitive
     * types like int.class (also known as Integer.TYPE). int.class.getName() returns "int", but if
     * we give that to Class.forName it will look for a class called int, which it is unlikely to
     * find.
     *
     * @param name
     * @param loader
     * @return Class
     * @throws ClassNotFoundException
     */
    static Class<?> classForName(String name, ClassLoader loader) throws ClassNotFoundException {
        Class<?> c = primitiveClasses.get(name);
        if (c == null)
            c = Class.forName(name, false, loader);
        return c;
    }

    /**
     * Helper method that delegates to findMethod below
     *
     * @param mbeanInterface
     * @param op
     * @return Method
     */
    private static Method methodFor(Class<?> mbeanInterface, MBeanOperationInfo op) {
        final MBeanParameterInfo[] params = op.getSignature();
        final String[] paramTypes = new String[params.length];
        for (int i = 0; i < params.length; i++)
            paramTypes[i] = params[i].getType();

        return findMethod(mbeanInterface, op.getName(), paramTypes);
    }

    /**
     * Finds the Method object for an MBeanOperationInfo that comes from a given MBean interface.
     *
     * @param mbeanInterface
     * @param name
     * @param paramTypes
     * @return Method
     */
    private static Method findMethod(Class<?> mbeanInterface, String name, String... paramTypes) {
        try {
            final ClassLoader loader = mbeanInterface.getClassLoader();
            final Class<?>[] paramClasses = new Class<?>[paramTypes.length];
            for (int i = 0; i < paramTypes.length; i++)
                paramClasses[i] = classForName(paramTypes[i], loader);
            return mbeanInterface.getMethod(name, paramClasses);
        } catch (RuntimeException e) {
            // avoid accidentally catching unexpected runtime exceptions
            throw e;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Retrieves the description from annotation.
     *
     * Find the method corresponding to this operation, and if it has a @Description annotation,
     * return the value of the annotation as the description.
     * Otherwise just return the default value of op.getDescription().
     *
     * @param op
     * @return Description
     */
    @Override
    protected String getDescription(MBeanOperationInfo op) {
        String descr = op.getDescription();
        Method m = methodFor(getMBeanInterface(), op);
        if (m != null) {
            Description d = m.getAnnotation(Description.class);
            if (d != null)
                descr = d.value();
        }
        return descr;
    }

    /**
     * Get the value of a particular annotation for a particular method parameter.
     *
     * @param m
     * @param paramNo
     * @param annot
     * @return Annotation
     */
    static <A extends Annotation> A getParameterAnnotation(Method m, int paramNo, Class<A> annot) {
        for (Annotation a : m.getParameterAnnotations()[paramNo]) {
            if (annot.isInstance(a))
                return annot.cast(a);
        }
        return null;
    }

    /**
     * Retrieves the parameter name from annotation.
     *
     * Same idea as in getDescription above.
     *
     * @param op
     * @param param
     * @param paramNo
     * @return Parameter Name (Description)
     */
    @Override
    protected String getParameterName(MBeanOperationInfo op, MBeanParameterInfo param, int paramNo) {
        String name = param.getName();
        Method m = methodFor(getMBeanInterface(), op);
        if (m != null) {
            PName pname = getParameterAnnotation(m, paramNo, PName.class);
            if (pname != null)
                name = pname.value();
        }
        return name;
    }
}
