package com.wm.corelib.jmxadmin;

import javax.management.ListenerNotFoundException;
import javax.management.MBeanNotificationInfo;
import javax.management.NotCompliantMBeanException;
import javax.management.Notification;
import javax.management.NotificationBroadcasterSupport;
import javax.management.NotificationEmitter;
import javax.management.NotificationFilter;
import javax.management.NotificationListener;

/**
 * AnnotatedStandardEmitterMBean
 *
 * Extension of AnnotatedStandardMBean that implements the NotificationEmitter interface.
 *
 * Acknowledgement: Eamonn McManus
 *                  http://weblogs.java.net/blog/emcmanus/archive/2005/07/good_advice_for.html
 *
 * @author Igor.Dralyuk@walmart.com
 * @version $Id: AnnotatedStandardEmitterMBean.java,v 1.2 2009/04/08 05:14:00 mkishore Exp $
 * @since November 2005
 */

public class AnnotatedStandardEmitterMBean extends AnnotatedStandardMBean implements NotificationEmitter {

    final NotificationBroadcasterSupport nbs = new NotificationBroadcasterSupport();

    public <T> AnnotatedStandardEmitterMBean(T impl, Class<T> mbeanInterface) throws NotCompliantMBeanException {
        super(impl, mbeanInterface);
    }

    public AnnotatedStandardEmitterMBean(Class<?> c) throws NotCompliantMBeanException {
        super(c);
    }

    public void addNotificationListener(NotificationListener nl, NotificationFilter nf, Object handback) {
        nbs.addNotificationListener(nl, nf, handback);
    }

    public void sendNotification(Notification n) {
        nbs.sendNotification(n);
    }

    public MBeanNotificationInfo[] getNotificationInfo() {
        return new MBeanNotificationInfo[0];
    }

    public void removeNotificationListener(NotificationListener nl, NotificationFilter nf, Object handback) throws ListenerNotFoundException {
        nbs.removeNotificationListener(nl, nf, handback);
    }

    public void removeNotificationListener(NotificationListener nl) throws ListenerNotFoundException {
        nbs.removeNotificationListener(nl);
    }
}
