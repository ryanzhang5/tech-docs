package com.wm.corelib.jmxadmin;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.util.logging.Level;
import java.util.logging.Logger;
  
import com.wm.corelib.config.AppConfig;

/**
 * WMSslUtil - Creates a custom SSL context for JMX.
 *             Used by WMSslRMIClientSocketFactory and WMSslRMIServerSocketFactory.
 *
 * @since January 2006
 * @version $Id: SslUtil.java,v 1.3 2011/05/05 01:50:29 alu Exp $
 * @author Igor.Dralyuk@walmart.com
 */

public class SslUtil {

    public static final String KEYSTORE        = "com.wm.management.keystore";
    public static final String KEYSTORE_PASS   = "com.wm.management.keystorepass";
    public static final String TRUSTSTORE      = "com.wm.management.truststore";
    public static final String TRUSTSTORE_PASS = "com.wm.management.truststorepass";

    private static final Logger _log = Logger.getLogger(SslUtil.class.getName());

    public static SSLContext getJMXSslContext() {

        SSLContext jmxSslContext = null;

        String keyStoreFile = AppConfig.getInstance().getProperty(KEYSTORE);
        String keyStorePass = AppConfig.getInstance().getProperty(KEYSTORE_PASS);
        String trustStoreFile = AppConfig.getInstance().getProperty(TRUSTSTORE);
        String trustStorePass = AppConfig.getInstance().getProperty(TRUSTSTORE_PASS);

        KeyManagerFactory keyMF = null;
        TrustManager[] trustManagers = null;

        if (keyStoreFile != null) {
            try {
                KeyStore keyStore = KeyStore.getInstance("JKS");
                keyStore.load(new FileInputStream(keyStoreFile), keyStorePass.toCharArray());
                keyMF = KeyManagerFactory.getInstance("SunX509");
                keyMF.init(keyStore, keyStorePass.toCharArray());
            } catch (Throwable t) {
                _log.log(Level.SEVERE, "Cannot initialize keystore from " + keyStoreFile, t);
            }
        }

        if (trustStoreFile != null) {
            try {
                KeyStore trustStore = KeyStore.getInstance("JKS");
                trustStore.load(new FileInputStream(trustStoreFile), trustStorePass.toCharArray());
                TrustManagerFactory trustMF = TrustManagerFactory.getInstance("SunX509");
                trustMF.init(trustStore);
                trustManagers = trustMF.getTrustManagers();
            } catch (Throwable t) {
                _log.log(Level.SEVERE, "Cannot initialize truststore from " + trustStoreFile, t);
            }
        }

        if (keyMF != null || trustManagers != null) {
            try {
                jmxSslContext = SSLContext.getInstance("SSL");
                jmxSslContext.init(keyMF.getKeyManagers(), trustManagers, null);
            } catch (Throwable t) {
                _log.log(Level.SEVERE, "Cannot initialize JMX SSL Context, will use default", t);
            }
        }

        return jmxSslContext;
    }

}
