package com.wm.corelib.jmxadmin;

import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.lang.reflect.Method;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.management.Attribute;
import javax.management.AttributeList;
import javax.management.Descriptor;
import javax.management.IntrospectionException;
import javax.management.MBeanServer;
import javax.management.NotificationListener;
import javax.management.ObjectName;
import javax.management.modelmbean.DescriptorSupport;
import javax.management.modelmbean.ModelMBean;
import javax.management.modelmbean.ModelMBeanAttributeInfo;
import javax.management.modelmbean.ModelMBeanInfo;
import javax.management.modelmbean.ModelMBeanInfoSupport;
import javax.management.modelmbean.ModelMBeanOperationInfo;
import javax.management.modelmbean.RequiredModelMBean;
import javax.management.remote.JMXConnectorServer;
import javax.management.remote.JMXConnectorServerFactory;
import javax.management.remote.JMXServiceURL;
import javax.management.remote.MBeanServerForwarder;
import javax.management.remote.rmi.RMIConnectorServer;

import com.wm.corelib.config.AppConfig;

/**
 * Class is used to Register Management Bean, There are two ways to Register
 * Management Bean 1) Through Property Files, when you can specify Bean Name,
 * Class Name, Listener Name 2) Create an instance of Management Bean and then
 * register it through registerMBean Method
 */
public class JmxUtil
{
    private static final Logger _log = Logger.getLogger(JmxUtil.class.getName());

    // initialize this before creating the singleton instance
    private static MBeanServer _platformMBeanServer = ManagementFactory.getPlatformMBeanServer();

    private static final JmxUtil _theJmxUtil;
    private static JMXConnectorServer _connectorServer = null;
    private static Registry _registry = null;

    private static ResourceBundle _resourceBundle = null;

    /** DISABLED */
    public static boolean DISABLED;

    /** RMI Registry Port */
    public static int REGISTRY_PORT;

    /** Secondary RMI Registry Port */
    public static int SECONDARY_REGISTRY_PORT;

    /** RMI Service URI */
    public static String SERVICE_URI;

    private static final String SYSPROP_REGISTRY_PORT = "rmiregistry.port";
    private static final String DEFAULT_REGISTRY_PORT = "9099";

    private static final String SYSPROP_SECONDARY_REGISTRY_PORT = "rmiregistry.secondary.port";

    private static final String SYSPROP_REGISTRY_ID = "com.wm.management.registry.id";
    private static final String DEFAULT_REGISTRY_ID = "default";

    private static final String SYSPROP_MGMT_DISABLED = "com.wm.management.disabled";
    private static final String DEFAULT_MGMT_DISABLED = "false";

    static
    {
        init();
        _theJmxUtil = new JmxUtil();
    }

    private static void init()
    {
        try
        {
            DISABLED = Boolean.valueOf(AppConfig.getInstance().getProperty(SYSPROP_MGMT_DISABLED,
                    DEFAULT_MGMT_DISABLED));
            if (DISABLED)
            {
                _log.info("JmxUtil management disabled by system property");
                return;
            }

            SERVICE_URI = "jmxrmi-"
                    + AppConfig.getInstance().getProperty(SYSPROP_REGISTRY_ID, DEFAULT_REGISTRY_ID);
            REGISTRY_PORT = Integer.parseInt(AppConfig.getInstance().getProperty(
                    SYSPROP_REGISTRY_PORT, DEFAULT_REGISTRY_PORT));
            SECONDARY_REGISTRY_PORT = Integer.parseInt(AppConfig.getInstance().getProperty(
                    SYSPROP_SECONDARY_REGISTRY_PORT, "1" + Integer.toString(REGISTRY_PORT)));

            try
            {
                // Start the RMI registry
                _registry = LocateRegistry.createRegistry(REGISTRY_PORT);
            } catch (Exception e)
            { // must be running already
                _log.warning("Cannot create the RMI Registry on port " + REGISTRY_PORT
                        + " -- is it running already?");
            }

            // We setup the JMXConnectorServer only if we own the RMIRegistry
            if (_registry != null)
            {
                // Retrieve the platform MBean server
                MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();

                // Environment map
                HashMap<String, Object> env = new HashMap<String, Object>();

                // Provide SSL/TLS-based RMI socket factories.
                env.put(RMIConnectorServer.RMI_CLIENT_SOCKET_FACTORY_ATTRIBUTE,
                        new WMSslRMIClientSocketFactory());
                env.put(RMIConnectorServer.RMI_SERVER_SOCKET_FACTORY_ATTRIBUTE,
                        new WMSslRMIServerSocketFactory());

                // Provide the WMJMXAuthenticator
                env.put(JMXConnectorServer.AUTHENTICATOR, new WMJMXAuthenticator());

                // Create an RMI connector server
                // JMXServiceURL url = new
                // JMXServiceURL("service:jmx:rmi:///jndi/rmi://:" +
                // REGISTRY_PORT + "/" + SERVICE_URI);
                JMXServiceURL url = new JMXServiceURL("service:jmx:rmi://localhost:"
                        + SECONDARY_REGISTRY_PORT + "/jndi/rmi://localhost:" + REGISTRY_PORT + "/"
                        + SERVICE_URI);
                _log.info(" JMXServiceURL is " + url);
                _connectorServer = JMXConnectorServerFactory.newJMXConnectorServer(url, env, mbs);

                // Supply our custom MBeanServerForwarder to intercept the
                // remote MBeanServer invocations
                // and perform our own access checks.
                MBeanServerForwarder mbsf = WMMBeanServerForwarderInvocationHandler
                        .newProxyInstance();
                _connectorServer.setMBeanServerForwarder(mbsf);

                // Start the RMI connector server
                _connectorServer.start();
                _log.info("\n\nRMI connector server for JMX started successfully\n" + "Address: "
                        + _connectorServer.getAddress() + "\nWaiting for incoming connections...");
            }
        } catch (Exception e)
        {
            _log.log(Level.SEVERE, "Unable to initialize JmxUtil", e);
        }

    }

    /**
     * Shuts down the JMXConnectorServer (on a separate daemon thread), and
     * unbind everything from the RMI Registry.
     */
    public static void shutdown()
    {
        _log.info("Shutting down jmxUtil");
        if (_connectorServer != null)
        {
            Thread t = new Thread()
            {
                @Override
                public void run()
                {
                    try
                    {
                        _log.info("Attempting to shutdown RMI connector server for JMX");
                        _connectorServer.stop();
                        _log.info("Successfully shutdown RMI connector server for JMX");
                    } catch (IOException e)
                    {
                        _log.log(Level.SEVERE, "Unable to shutdown JmxUtil", e);
                    }
                }
            };
            t.setDaemon(true);
            t.start();
        }

        if (_registry != null)
        {
            try
            {
                _log.info("Attempting to shutdown RMI registry");
                for (String name : _registry.list())
                {
                    try
                    {
                        _registry.unbind(name);
                    } catch (Exception x)
                    {
                        throw new RuntimeException("Error while unbinding: " + name, x);
                    }
                }
                _log.info("Successfully shutdown RMI registry");
            } catch (Exception e)
            {
                _log.log(Level.SEVERE, "Unable to shutdown RMI registry", e);
            }
        }
    }

    /**
     * Static getInstance Method
     * 
     * @return -- JmxUtil Object
     */
    public static JmxUtil getInstance()
    {
        return _theJmxUtil;
    }

    /**
     * Method is used to return MBeanServer
     * 
     * @return -- MBeanServer
     */
    public static MBeanServer getMBeanServer()
    {
        return _platformMBeanServer;
    }

    /**
     * Private Constructor
     */
    private JmxUtil()
    {
        jmxAdminSetup();
    }

    /**
     * Method is used to register Management Bean at the time of Initialization.
     */
    public void jmxAdminSetup()
    {
        if (DISABLED) return;
        try
        {
            _resourceBundle = ResourceBundle.getBundle("MBeanResources");
            Enumeration eKeys = _resourceBundle.getKeys();

            MBeanServer _server = getMBeanServer();
            String sBeanClass = null;
            while (eKeys.hasMoreElements())
            {
                try
                {
                    String sKey = eKeys.nextElement().toString();

                    if (sKey != null && sKey.endsWith("Bean"))
                    {
                        String sBeanName = _resourceBundle.getString(sKey + "Name");
                        sBeanClass = _resourceBundle.getString(sKey + "Class");
                        String sBeanListenerClass = _resourceBundle.getString(sKey + "Listener");

                        printMessage("Property Read--> Key=>" + sKey + ",BeanName=>" + sBeanName
                                + ",Class=>" + sBeanClass + ",Listener=>" + sBeanListenerClass);
                        ObjectName _objectName = new ObjectName(getNamingPrefix() + sBeanName);

                        if (!_server.isRegistered(_objectName))
                        {

                            Object mBeanObject;
                            mBeanObject = Class.forName(sBeanClass).newInstance();

                            Object notificationListenerObject = null;
                            try
                            {
                                if (sBeanListenerClass != null && sBeanListenerClass.length() > 0)
                                {
                                    notificationListenerObject = Class.forName(sBeanListenerClass)
                                            .newInstance();
                                }
                            } catch (Exception exp)
                            {
                                notificationListenerObject = null;
                            }

                            registerMBean(sBeanName, mBeanObject, notificationListenerObject);

                        }// if registered
                    }// if bean
                } catch (ClassNotFoundException cnfe)
                {
                    printMessage("Class " + sBeanClass
                            + " not found!!!, Property ignored, not registering Bean.");
                } catch (Exception e)
                {
                    printException(e);
                }
            }// while
        } catch (MissingResourceException me)
        {
            printMessage("Not able to Find Resource Bundle File....Waiting for manually registered Management Bean....");
            // printException(me);
        } catch (Exception exp)
        { // catch
            printException(exp);
        }
    }

    /**
     * Returns a "prefix" that can be used to separate out the namespace for
     * beans from different web-applications.
     * 
     * @return a "prefix" that can be used to separate out the bean namespace
     */
    public static String getNamingPrefix()
    {
        String prefix = AppConfig.getInstance().getDerivedPath();
        if (prefix == null || prefix.equals(""))
        {
            prefix = "";
        }
        else
        {
            prefix += "-";
        }
        return prefix;
    }

    /**
     * Method is used to register Management Bean
     * 
     * @param sMBeanName
     *            -- String Bean Name
     * @param oMBeanObject
     *            -- Object Management Bean Class Object
     * @param nListener
     *            -- Listener must be instanceof NotificationListener
     */
    public static void registerMBean(String sMBeanName, Object oMBeanObject, Object nListener)
    {
        if (DISABLED) return;
        try
        {
            if (sMBeanName == null || sMBeanName.length() == 0 || oMBeanObject == null)
            {
                printMessage("Management Bean Name and Class must not null....");
                return;
            }

            MBeanServer _server = getMBeanServer();
            ObjectName _objectName = new ObjectName(getNamingPrefix() + sMBeanName);

            if (_server.isRegistered(_objectName))
            {
                printMessage(sMBeanName + " is already Registered....");
                return;
            }

            if (!(oMBeanObject instanceof WmtMBean))
            {
                printMessage(sMBeanName + " has not implemented WmtMBean Interface....");
                return;
            }

            _server.registerMBean(oMBeanObject, _objectName);

            if (nListener != null && nListener instanceof NotificationListener)
            {
                _server.addNotificationListener(_objectName, (NotificationListener)nListener, null,
                        new Object());
            }

            setupMonitoredAttributes(oMBeanObject, _objectName);

            printMessage(sMBeanName + " JMX Bean Successfully Registered...");
            setupMonitors(_server, _objectName);

        } catch (Exception e)
        {
            _log.log(Level.SEVERE, "Unable to register mbean " + sMBeanName, e);
        }
    }

    public static void unRegisterMBean(String name)
    {
        if (DISABLED) return;
        try
        {
            ObjectName _objectName = new ObjectName(getNamingPrefix() + name);
            getMBeanServer().unregisterMBean(_objectName);
        } catch (Exception e)
        {
            _log.log(Level.WARNING, "Unable to unregister mbean " + name, e);
        }
    }

    /**
     * Method is used to set Attribute Value
     * 
     * @param sMBeanName
     *            -- Bean Name
     * @param theAtt
     *            -- Attribute Value
     */
    public void setAttribute(String sMBeanName, Attribute theAtt)
    {
        if (DISABLED) return;
        try
        {
            ObjectName beanObjectName = new ObjectName(getNamingPrefix() + sMBeanName);
            if (getMBeanServer().isRegistered(beanObjectName))
            {
                getMBeanServer().setAttribute(beanObjectName, theAtt);
            }
        } catch (Exception e)
        {
            printException(e);
        }
    }

    public static boolean isRegistered(String sMBeanName)
    {
        if (DISABLED) return false;
        try
        {
            ObjectName beanObjectName = new ObjectName(getNamingPrefix() + sMBeanName);
            if (getMBeanServer().isRegistered(beanObjectName)) { return true; }
        } catch (Exception e)
        {
            printException(e);
        }
        return false;
    }

    /**
     * Method is used to set Gauge Threshold
     * 
     * @param beanName
     *            -- String
     * @param newThreshold
     *            -- float
     * @param sObjName
     *            -- String
     */
    public void setGaugeThreshold(String beanName, float newThreshold, String sObjName)
    {
        if (DISABLED) return;
        try
        {

            ObjectName objName = new ObjectName(getNamingPrefix() + sObjName);
            Float hi = new java.lang.Float(newThreshold);
            Float lo = new java.lang.Float(.9 * newThreshold);
            getMBeanServer().invoke(objName, "setThresholds", new Object[] { hi, lo },
                    new String[] { "java.lang.Number", "java.lang.Number" });

            // Update GMD for consistency.
            Vector vGaugeMonitors = new Vector();
            try
            {
                vGaugeMonitors = (Vector)getMBeanServer().getAttribute(
                        new ObjectName(getNamingPrefix() + beanName), "GaugeMonitors");
            } catch (Exception e)
            {
                printException(e);
            }

            for (int i = 0; i < vGaugeMonitors.size(); i++)
            {
                GaugeMonitorDefinition gmd = (GaugeMonitorDefinition)vGaugeMonitors.get(i);
                if ((gmd.getMonitorName()).equals(sObjName))
                {
                    gmd.setHi(hi);
                    gmd.setLo(lo);
                    printMessage("*** updated gmd with threshold");
                    break;
                }
            }
        } catch (Exception e)
        {
            printException(e);
        }
    }

    /**
     * Method is used to setup Monitors
     * 
     * @param mbs
     *            -- MBeanServer
     * @param oName
     *            -- ObjectName
     */
    private static void setupMonitors(MBeanServer mbs, ObjectName oName)
    {
        Vector vGaugeMonitors = new Vector();
        try
        {
            vGaugeMonitors = (Vector)mbs.getAttribute(oName, "GaugeMonitors");
            // } catch (javax.management.AttributeNotFoundException anfe) {

        } catch (Exception e)
        {
            printException(e);
        }

        for (int i = 0; i < vGaugeMonitors.size(); i++)
        {
            if (vGaugeMonitors.get(i) instanceof GaugeMonitorDefinition)
            {
                setupGaugeMonitor((GaugeMonitorDefinition)vGaugeMonitors.get(i), oName, mbs);
            }// if
        }// for
    }

    /**
     * Method is used to set up Gauge Monitor
     * 
     * @param gmd
     *            -- GaugeMiontirDefinition
     * @param obsObjectName
     *            -- Object Name
     * @param mbs
     *            -- MBeanServer
     */
    private static void setupGaugeMonitor(GaugeMonitorDefinition gmd, ObjectName obsObjectName,
            MBeanServer mbs)
    {
        try
        {
            ObjectName gaugeObjName = new ObjectName(getNamingPrefix() + gmd.getMonitorName());
            mbs.createMBean("javax.management.monitor.GaugeMonitor", gaugeObjName);
            AttributeList al = new AttributeList();
            al.add(new Attribute("ObservedObject", obsObjectName));
            al.add(new Attribute("ObservedAttribute", gmd.getAttrName()));
            al.add(new Attribute("GranularityPeriod", gmd.getGranularity()));
            al.add(new Attribute("NotifyHigh", gmd.getNotifyHi()));
            al.add(new Attribute("NotifyLow", gmd.getNotifyLo()));
            mbs.setAttributes(gaugeObjName, al);
            mbs.invoke(gaugeObjName, "setThresholds", new Object[] { gmd.getHi(), gmd.getLo() },
                    new String[] { "java.lang.Number", "java.lang.Number" });
            mbs.invoke(gaugeObjName, "start", new Object[] {}, new String[] {});
        } catch (Exception e)
        {
            printException(e);
        }
    }

    private static void setupMonitoredAttributes(Object beanObj, ObjectName name)
    {
        if (name == null
                || (name.getKeyProperty("name") == null && name.getKeyProperty("type") == null))
            throw new IllegalArgumentException("invalid ObjectName: " + name);
        String beanName = name.getKeyProperty("name");
        String attrs;
        try
        {
            attrs = beanName == null ? null : _resourceBundle.getString(beanName
                    + "MonitoredMetrics");
        } catch (MissingResourceException mre)
        {
            attrs = null;
        }
        if (attrs == null || (attrs = attrs.trim()).isEmpty())
        {
            printMessage("No exported attribute config found for bean " + name);
            return;
        }

        Collection<Method> accessors = new ArrayList<Method>();

        for (String attrName : attrs.split("[,;]"))
        {
            try
            {
                Method getter = beanObj.getClass().getMethod("get" + attrName.trim());

                accessors.add(getter);
            } catch (NoSuchMethodException ex)
            {
                printException(ex);
                continue;
            }
        }

        Collection<ModelMBeanAttributeInfo> attrInfo = new ArrayList<ModelMBeanAttributeInfo>(
                accessors.size() + 1);
        Collection<ModelMBeanOperationInfo> opInfo = new ArrayList<ModelMBeanOperationInfo>(
                accessors.size() + 1);
        try
        {
            // Create availability attribute - required for Hyperic
            attrInfo.add(new ModelMBeanAttributeInfo("Availability", "int", "Availability", true,
                    false, false, new DescriptorSupport(new String[] { "name", "descriptorType",
                            "value" }, new Object[] { "Availability", "attribute", 1 })));

            for (Method m : accessors)
            {
                attrInfo.add(makeAttrInfo(m, null));
                opInfo.add(new ModelMBeanOperationInfo(m.getName(), m));
            }

            ModelMBeanInfo mmbi = new ModelMBeanInfoSupport(
                    beanObj.getClass().getName(),
                    beanName,
                    attrInfo.toArray(new ModelMBeanAttributeInfo[attrInfo.size()]),
                    null, // constructors
                    opInfo.toArray(new ModelMBeanOperationInfo[opInfo.size()]),
                    null, // notifications
                    new DescriptorSupport("name=" + beanName, "descriptorType=mbean", "export=true"));
            ModelMBean mbean = new RequiredModelMBean(mmbi);
            mbean.setManagedResource(beanObj, "ObjectReference");
            JmxUtil.getMBeanServer().registerMBean(
                    mbean,
                    new ObjectName("spring.application:type=" + beanObj.getClass().getSimpleName()
                            + ",name=" + beanName));

        } catch (Exception e)
        {
            printException(e);
        }
    }

    private static ModelMBeanAttributeInfo makeAttrInfo(Method getter, Method setter)
            throws IntrospectionException
    {
        String attrName = getter != null ? getter.getName().substring(3) : setter.getName()
                .substring(3);

        Collection<String> descriptors = new ArrayList<String>();
        descriptors.add("name=" + attrName);
        descriptors.add("descriptorType=attribute");
        descriptors.add("metricType=gauge");
        /*
         * descriptors.add("category=" + (obj instanceof Timing ? "PERFORMANCE"
         * : (obj instanceof Counter ? "THROUGHPUT" : "UTILIZATION")));
         */if (getter != null)
        {
            descriptors.add("getMethod=" + getter.getName());
        }
        if (setter != null)
        {
            descriptors.add("setMethod=" + setter.getName());
        }

        Descriptor attrD = new DescriptorSupport(
                descriptors.toArray(new String[descriptors.size()]));

        return new ModelMBeanAttributeInfo(attrName, attrName, getter, setter, attrD);
    }

    /**
     * Method is used to get String Value for the Given Key
     * 
     * @param key
     *            -- String
     * @return -- String
     */
    public String getStringValue(String key)
    {
        if (DISABLED || _resourceBundle == null) return null;
        return _resourceBundle.getString(key);
    }

    /**
     * Method is used to return Object for the given Key
     * 
     * @param key
     *            -- String
     * @return -- Object
     */
    public Object getObjectValue(String key)
    {
        if (DISABLED || _resourceBundle == null) return null;
        return _resourceBundle.getObject(key);
    }

    /**
     * Method is used to print Error Message
     * 
     * @param s
     *            -- String
     */
    private static void printMessage(String s)
    {
        _log.log(Level.INFO, s);
    }

    /**
     * Method is used to print Exception
     * 
     * @param e
     *            -- Exception
     */
    private static void printException(Exception e)
    {
        _log.log(Level.SEVERE, e.getMessage(), e);
    }

}
