package com.wm.corelib.jmxadmin;

import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.Vector;

import javax.management.NotCompliantMBeanException;

public abstract class WmtMBeanImpl extends AnnotatedStandardEmitterMBean
{

    private String _message;
    private String _lastInitialization;

    private long _resetInterval = 60 * 60 * 1000; // Every Hour
    private final long _broadcaseInterval = 60 * 1000; // Every Minute

    private Timer resetMetricsTimer;
    private Timer heartBeatBroadcaster;

    private final HeartBeatBroadcastTask _heartBeatBroadcastTask;
    private ResetMetricsTask _resetMetricsTask;

    /**
     * Constructor
     */
    public WmtMBeanImpl(Class<?> c) throws NotCompliantMBeanException
    {
        super(c);
        _heartBeatBroadcastTask = new HeartBeatBroadcastTask(this);
        _resetMetricsTask = new ResetMetricsTask(this);
        _message = this.getClass().getName();
        setInitializationTime();
        initializeNonStaticMetrics();
        if (JmxUtil.DISABLED)
        {
            cancelTimedTasks();
        }
        else
        {
            setupTimedTasks();
        }
    }

    /**
     * Method is used to cancel Timer Tasks.
     */
    public void cancelTimedTasks()
    {
        cancelHeartBeatBroadcaster();
        cancelResetMetrics();
    }

    private void cancelHeartBeatBroadcaster()
    {
        if (heartBeatBroadcaster != null)
        {
            heartBeatBroadcaster.cancel();
            heartBeatBroadcaster = null;
        }
    }

    private void cancelResetMetrics()
    {
        if (resetMetricsTimer != null)
        {
            resetMetricsTimer.cancel();
            resetMetricsTimer = null;
        }
    }

    /**
     * Method is used to set Timer Tasks.
     */
    public void setupTimedTasks()
    {
        broadcastHeartBeat();
        resetMetrics();
    }

    /**
     * Method will schedule broad cast heart beat timer.
     */
    private void broadcastHeartBeat()
    {
        cancelHeartBeatBroadcaster();
        heartBeatBroadcaster = new Timer("HeartBeatBroadcaster", true);
        heartBeatBroadcaster.schedule(_heartBeatBroadcastTask, 0,
                this.getHeartBeatBroadcastInterval());
    }

    /**
     * Method is used to schedule reset metrics task.
     */
    private void resetMetrics()
    {
        cancelResetMetrics();
        resetMetricsTimer = new Timer("ResetMetrics", true);
        _resetMetricsTask = new ResetMetricsTask(this);
        resetMetricsTimer.schedule(_resetMetricsTask, getConfResetInterval(),
                getConfResetInterval());
    }

    /**
     * Method is used to set interval seconds
     * 
     * @param resetInterval
     *            -- long
     */
    public void setInterval(long resetInterval)
    {
        _resetInterval = resetInterval;
        resetMetrics();
    }

    /**
     * Method is used to get Gauge Monitors
     * 
     * @return -- Vector
     */
    public Vector<?> getGaugeMonitors()
    {
        return new Vector();
    }

    /**
     * Method is used to set Message
     * 
     * @param message
     *            -- String
     */
    public void setMessage(String message)
    {
        _message = message;
    }

    /**
     * Method is used to get Message
     * 
     * @return -- Message
     */
    public String getMessage()
    {
        return _message;
    }

    // we need the metrics initialized on a regular basis to provide more
    // pertinent monitoring.
    /**
     * Method is used to set last initialization time
     * 
     * @param message
     *            -- String
     */
    public void setLastInitialization(String message)
    {
        _lastInitialization = message;
    }

    /**
     * Method is used to get Last Initialization Time
     * 
     * @return -- String
     */
    public String getLastInitialization()
    {
        return _lastInitialization;
    }

    /**
     * Method is used to get Next Hour
     * 
     * @param incrementBy
     *            -- Hour (int)
     * @return -- Date
     */
    public Date getNextHour(int incrementBy)
    {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.HOUR, incrementBy);
        return cal.getTime();
    }

    /**
     * Method is used to get Conf Reset Interval Time
     * 
     * @return -- long
     */
    public long getConfResetInterval()
    {
        return _resetInterval;
    }

    /**
     * Method is used to get Heart Beat Broad Cast Interval
     * 
     * @return --long
     */
    public long getHeartBeatBroadcastInterval()
    {
        return _broadcaseInterval;
    }

    /**
     * Method is used to initialize Non Static Metrics, should be override by
     * child class
     */
    public void initializeNonStaticMetrics()
    {
    }

    /**
     * Method is used to set initialization time.
     */
    protected void setInitializationTime()
    {
        setLastInitialization((new Date(System.currentTimeMillis())).toString());
    }
}
