package com.wm.corelib.jmxadmin;

import javax.management.MBeanServer;
import javax.management.ObjectName;
import javax.management.remote.MBeanServerForwarder;
import javax.security.auth.Subject;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.security.AccessController;
import java.security.Principal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Performs access checks before allowing clients to invoke methods on the MBean server.
 *
 * @since November 2005
 * @version $Id: WMMBeanServerForwarderInvocationHandler.java,v 1.2 2009/04/08 05:14:00 mkishore Exp $
 * @author Igor.Dralyuk@walmart.com
 */

public class WMMBeanServerForwarderInvocationHandler implements InvocationHandler {

    public static final String JMX_GET_METHOD             = "get";
    public static final String JMX_SET_METHOD             = "set";
    public static final String JMX_GET_MBEANSERVER_METHOD = "getMBeanServer";
    public static final String JMX_SET_MBEANSERVER_METHOD = "setMBeanServer";
    public static final String JMX_QUERYNAMES_METHOD      = "queryNames";
    public static final String JMX_ISINSTANCEOF_METHOD    = "isInstanceOf";
    public static final String JMX_HASHCODE_METHOD        = "hashCode";

    public static final String WM_PREFIX_ALL              = "all";
    public static final String WM_UNKNOWN                 = "unknown";

    private MBeanServer _mbs;

    /** Our logger instance */
    private static final Logger _log = Logger.getLogger(WMMBeanServerForwarderInvocationHandler.class.getName());

    /** Set of allowed methods */
    private static final HashSet<String> allowedMethods = new HashSet<String>();

    static {
        allowedMethods.add(JMX_QUERYNAMES_METHOD);
        allowedMethods.add(JMX_ISINSTANCEOF_METHOD);
        allowedMethods.add(JMX_HASHCODE_METHOD);
    }

    public static MBeanServerForwarder newProxyInstance() {

        final InvocationHandler handler = new WMMBeanServerForwarderInvocationHandler();

        final Class[] interfaces = new Class[] {MBeanServerForwarder.class};

        Object proxy = Proxy.newProxyInstance(MBeanServerForwarder.class.getClassLoader(), interfaces, handler);

        return MBeanServerForwarder.class.cast(proxy);
    }

    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {

        Level logLevel = Level.FINE;
        boolean debug = _log.isLoggable(logLevel);

        long securityTimer = 0, methodTimer = 0; // timers
        if (debug) securityTimer = System.currentTimeMillis();

        final String methodName = method.getName();

        if (methodName.equals(JMX_GET_MBEANSERVER_METHOD)) {
            return _mbs;
        }

        if (methodName.equals(JMX_SET_MBEANSERVER_METHOD)) {
            if (args[0] == null) throw new IllegalArgumentException("Null MBeanServer");
            if (_mbs != null) throw new IllegalArgumentException("MBeanServer object already initialized");
            _mbs = (MBeanServer) args[0];
            return null;
        }

        Subject s = Subject.getSubject(AccessController.getContext());

        boolean isInternal = false;
        HashMap<String, WMJMXPrincipal.Role> m = null;
        Set<Principal> principals = null;

        if (s == null) { // Internal calls do not use a subject
            isInternal = true;
        } else {
             principals = s.getPrincipals();

            m = new HashMap<String, WMJMXPrincipal.Role>();

            for (Principal p : principals) {
                if (p instanceof WMJMXPrincipal)
                    m.put(((WMJMXPrincipal)p).getMBeanNameOrDomain(), ((WMJMXPrincipal)p).getRole());
            }
            if (debug) {
                _log.log(logLevel, "Method = " + methodName);
            }
        }

        // Figure out the MBean name:
        String mbean = WM_UNKNOWN;

        if (args != null &&  args.length > 0) {
            if (args[0] instanceof ObjectName) {
                ObjectName om = (ObjectName) args[0];
                mbean = om.getDomain();
                if (debug) _log.log(logLevel, "ObjectName = " + om.getCanonicalName());
            }
        }

        // currently we support three (3) roles
        // 1. monitor  -- read attributes only
        // 2. operator -- read/write attributes, but not execute arbitrary operations
        // 3. admin    -- access to everything

        // Don't restrict internal calls (with null Subject) and those that are in the allowed set,
        // otherwise if the method doesn't start with set or get, it's an operation and requires ADMIN role

        Object result = null;
        boolean hasPermission = false;

        if (isInternal || allowedMethods.contains(methodName)) {
            hasPermission = true;
            result = method.invoke(_mbs, args);

        } else if ( ! (methodName.startsWith(JMX_SET_METHOD) || (methodName.startsWith(JMX_GET_METHOD)))) {
            if (hasPermission(principals, mbean, WMJMXPrincipal.Role.ADMIN)) {
                if (debug) {
                    methodTimer = System.currentTimeMillis();
                    securityTimer = methodTimer - securityTimer;
                }
                hasPermission = true;
                result = method.invoke(_mbs, args);

                if (debug) methodTimer = System.currentTimeMillis() - methodTimer;
            }

        } else if (methodName.startsWith(JMX_SET_METHOD)) {
            if (hasPermission(principals, mbean, WMJMXPrincipal.Role.OPERATOR)) {
                if (debug) {
                    methodTimer = System.currentTimeMillis();
                    securityTimer = methodTimer - securityTimer;
                }
                hasPermission = true;
                result = method.invoke(_mbs, args);

                if (debug) methodTimer = System.currentTimeMillis() - methodTimer;
            }

        } else if (methodName.startsWith(JMX_GET_METHOD)) {
            if (hasPermission(principals, mbean, WMJMXPrincipal.Role.MONITOR)) {
                if (debug) {
                    methodTimer = System.currentTimeMillis();
                    securityTimer = methodTimer - securityTimer;
                }
                hasPermission = true;
                result = method.invoke(_mbs, args);

                if (debug) methodTimer = System.currentTimeMillis() - methodTimer;
            }
        }

        if (!hasPermission) {
            _log.log(Level.WARNING, "Subject " + ((principals == null) ? WM_UNKNOWN : principals) +
                    " doesn't have permission to execute request \'" + methodName + "\'" +
                    (args == null ? "" : " args = " + Arrays.asList(args)) + " on bean \'" + mbean + "\'");
            throw new SecurityException("User doesn't have permission to execute the request");
        }

        if (!isInternal && _log.isLoggable(Level.FINE)) {
            _log.log(Level.FINE, "Subject " + ((principals == null) ? WM_UNKNOWN : principals) + " executed request \'" +
                    methodName + "\'" + (args == null ? "" : " args = " + Arrays.asList(args)) + " on bean \'" + mbean + "\' " +
                    "Security check took " + securityTimer + " ms " +
                    "Method call took " + methodTimer + " ms");
        }

        return result;
    }

    /**
     * MBean specific permission always overrides <em>all</em> permission.
     */
    private boolean hasPermission(Set<Principal> set, String mbeanName, WMJMXPrincipal.Role neededRole) {
        // The easiest way to think about comparisons is the following:
        // Role is an Enum and basically maps to numbers, i.e.
        // Monitor = 1, Operator = 2, Admin = 3.
        // When we are doing the comparison, we are asking:
        // how does the needed role, e.g. Monitor compare to the assigned role, e.g. Operator:
        // Monitor - Operator = 1 - 2 = -1    That's the reasoning behind <= 0
    	
        for (Principal p : set) {
            if (p instanceof WMJMXPrincipal){
            	if( mbeanName.equals( ((WMJMXPrincipal)p).getMBeanNameOrDomain()) )
            		return neededRole.compareTo( ((WMJMXPrincipal) p).getRole()) <= 0;
            	
            	if( mbeanName.startsWith( ((WMJMXPrincipal)p).getMBeanNameOrDomain()) )
            		return neededRole.compareTo( ((WMJMXPrincipal) p).getRole()) <= 0;            	
            }
        }
    	
        for (Principal p : set) {
            if (p instanceof WMJMXPrincipal){
            	if( WM_PREFIX_ALL.equals( ((WMJMXPrincipal)p).getMBeanNameOrDomain() ) )
            		if( neededRole.compareTo( ((WMJMXPrincipal) p).getRole()) <= 0 )
            			return true;
            }
        }       

        return false;
    }  
}
