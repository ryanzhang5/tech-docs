package com.wm.corelib.jmxadmin;

import com.wm.corelib.security.Role;
import com.wm.corelib.security.User;

import javax.management.remote.JMXAuthenticator;
import javax.management.remote.JMXPrincipal;
import javax.security.auth.Subject;
import java.security.Principal;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Authenticate users against Walmart.com database.
 *
 * @since November 2005
 * @version $Id: WMJMXAuthenticator.java,v 1.2 2009/04/08 05:14:00 mkishore Exp $
 * @author Igor.Dralyuk@walmart.com
 */
public class WMJMXAuthenticator implements JMXAuthenticator {

    /** JMX Application ID in the database */
    public static final int APP_ID = 7;

    /** String that is used to signify all mbeans */
    public static final String WM_PREFIX_ALL = "all";

    /** Our logger instance */
    private static final Logger _log = Logger.getLogger(WMJMXAuthenticator.class.getName());

    /**
     * <p>Authenticates the <code>MBeanServerConnection</code> client
     * with the given client credentials.</p>
     *
     * @param credentials the user-defined credentials to be passed
     * into the server in order to authenticate the user before
     * creating the <code>MBeanServerConnection</code>.  The actual
     * type of this parameter, and whether it can be null, depends on
     * the connector.
     *
     * @return the authenticated subject containing its associated principals.
     *
     * @exception SecurityException if the server cannot authenticate the user
     * with the provided credentials.
     */
    public Subject authenticate(Object credentials) {
        Level logLevel = Level.FINE;
        boolean debug = _log.isLoggable(logLevel);

        if (credentials == null) throw new SecurityException("Cannot authenticate null credentials");

        User u = null;
        boolean authSucceeded = false;
        String creds[] = (String[]) credentials;

        try {
            u = User.loadByLoginPass(creds[0], creds[1], APP_ID);
            if (u != null) authSucceeded = true;
        } catch (Exception e) {
            if (_log.isLoggable(Level.WARNING)) _log.log(Level.WARNING, "Error while trying to login user '" + creds[0] + "'", e);
        }

        if (!authSucceeded) {
            if (debug) _log.log(logLevel, "Unable to login user '" + creds[0] + "'");
            throw new SecurityException("Invalid login/password");
        }

        try {
            Role[] roles = u.getRoles();
            Set<Principal> principals = new HashSet<Principal>();

            principals.add(new JMXPrincipal(creds[0])); // Add the user name as the first principal

            for (Role r : roles) { // now add each role as a principal
                WMJMXPrincipal p = getPrincipal(r);
                if (p != null) {
                    principals.add(p);
                    if (debug) _log.log(logLevel, "Added principal \'" + p.getName() + "\' for user \'" + creds[0] + "\'");
                }
            }
            Subject s =  new Subject(true, principals, Collections.EMPTY_SET, Collections.EMPTY_SET);
            if (debug) _log.log(logLevel, "Returning subject: " + s);
            return s;
        } catch (Exception e) {
            throw new SecurityException(e.getMessage());
        }
    }

    protected static WMJMXPrincipal getPrincipal(Role role) {
        String r;

        // Make sure that the role we get is not null and that getRoleName() result is not null
        if (role == null || (r = role.getRoleName()) == null) return null;

        String[] jmxRole = r.split("\\" + WMJMXPrincipal.WM_ROLE_SEPARATOR);

        WMJMXPrincipal p;

        switch (jmxRole.length) {
            case 1:
                p = new WMJMXPrincipal(WM_PREFIX_ALL, WMJMXPrincipal.Role.parse(jmxRole[0]));
                break;
            case 2:
                p = new WMJMXPrincipal(jmxRole[0], WMJMXPrincipal.Role.parse(jmxRole[1]));
                break;
            default:
                throw new RuntimeException("Unable to determine role from " + Arrays.asList(jmxRole));
        }
        return p;
    }
}
