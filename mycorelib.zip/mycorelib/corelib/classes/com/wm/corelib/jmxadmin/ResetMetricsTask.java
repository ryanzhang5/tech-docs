package com.wm.corelib.jmxadmin;

import java.util.TimerTask;
import javax.management.Notification;

public class ResetMetricsTask extends TimerTask {
    long _resetMetricSeqNo = Long.MIN_VALUE;
    WmtMBeanImpl _mBeanObject;

    public ResetMetricsTask(WmtMBeanImpl BeanObject) {
      _mBeanObject = BeanObject;
    }

    public void run() {
    _mBeanObject.setInitializationTime();
		_mBeanObject.initializeNonStaticMetrics();
		try {
		    Notification n = new Notification("BeanReset",  _mBeanObject, _resetMetricSeqNo++);
		    _mBeanObject.sendNotification (n);
		} catch (Exception e) {
		    e.printStackTrace();
		}
	}//run
  
 }

