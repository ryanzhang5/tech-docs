package com.wm.corelib.jmxadmin;

import java.io.Serializable;
import java.security.Principal;

/**
 * WMJMXPrincipal
 *
 * @since November 2005
 * @version $Id: WMJMXPrincipal.java,v 1.2 2009/04/08 05:14:00 mkishore Exp $
 * @author Igor.Dralyuk@walmart.com
 */
public class WMJMXPrincipal implements Principal, Serializable {

    /**
     *  String that separates MBean name or domain from the role in the database.<br />
     *  This is how role expressions are stored in the database:
     *  <pre>
     *     ThreadPool|MONITOR
     *     java|ADMIN
     *     com.wm.corelib|OPERATOR
     * </pre>
     */
    public static final String WM_ROLE_SEPARATOR = "|";

    /**
     * Role used to determine user privileges<br /><br />
     *
     * Monitor has the least number of privileges (read attributes only).<br />
     * Operator has more privileges (can read and write attributes).<br />
     * Admin has the most privileges (can read and write attributes as well as execute any operations).<br />
     */
    public enum Role {
        MONITOR, OPERATOR, ADMIN;

        public static Role parse(String s) {
            Role role = null;
            for (Role r: Role.values()) {
                if (r.toString().equals(s)) {
                    role = r;
                    break;
                }
            }
            if (role == null) {
                throw new RuntimeException("Role \"" + s + "\" doesn't exist");
            }
            return role;
        }
    }

    /** The that is assigned to this principal. */
    private Role role;

    /** The name of the MBean or Domain that this principal is associated with. */
    private String mbeanNameOrDomain;

    /** Hashcode of this principal. */
    private int hashcode;

    /**
     * Creates a new principal with the given MBean name and Role
     */
    public WMJMXPrincipal(String mbeanNameOrDomain, Role role) {
        this.role = role;
        this.mbeanNameOrDomain = mbeanNameOrDomain;
        this.hashcode = (mbeanNameOrDomain + role).hashCode();
    }

    /**
     * Returns the name of this principal. It is a concatenation of MBean name, the '.' character
     * and the <tt>WMJMXPrincipal.Role</tt>.<br /><br />
     *
     * For example, it may look like the following: <tt>CocoaMBean.MONITOR</tt>
     */
    public String getName() {
        return mbeanNameOrDomain + WM_ROLE_SEPARATOR + role;
    }

    /**
     * Retrieves the name of the MBean (if any) that is associated with this principal.<br />
     * If MBean name is not defined, the <tt>WMJMXPrincipal.Role</tt> applies to all MBeans.
     */
    public String getMBeanNameOrDomain() {
        return mbeanNameOrDomain;
    }

    /**
     * Retrieves the <tt>WMJMXPrincipal.Role</tt> for this principal.
     */
    public Role getRole() {
        return role;
    }

    /**
     * Compares the specified Object with this <code>WMJMXPrincipal</code>
     * for equality.  Returns true if the given object is also a
     * <code>WMJMXPrincipal</code> and the two WMJMXPrincipals are for the same MBean
     * and have the same role.
     *
     * @param o Object to be compared for equality with this <code>WMJMXPrincipal</code>.
     * @return true if the specified Object is equal to this <code>WMJMXPrincipal</code>.
     */
    public boolean equals(Object o) {
        if (!(o instanceof WMJMXPrincipal)) return false;
        if (this == o) return true;
        WMJMXPrincipal that = (WMJMXPrincipal) o;
        return (this.mbeanNameOrDomain.equals(that.mbeanNameOrDomain) && this.role.equals(that.role));
    }

    /**
     * Returns a string representation of this <code>JMXPrincipal</code>.
     */
    public String toString() {
        return("WMJMXPrincipal:  " + getName());
    }

    /**
     * Returns a hash code for this <code>WMJMXPrincipal</code>.
     */
    public int hashCode() {
        return hashcode;
    }
}
