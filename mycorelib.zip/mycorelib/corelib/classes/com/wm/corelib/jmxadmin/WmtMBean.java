package com.wm.corelib.jmxadmin;

import java.util.Vector;
import com.wm.corelib.annotation.Description;
import com.wm.corelib.annotation.PName;

/**
 * WmtMBean
 *
 * Public interface of Walmart Management Beans
 *
 * @version $Id: WmtMBean.java,v 1.2 2009/04/08 05:14:00 mkishore Exp $
 */

public interface WmtMBean  {

    @Description("Retrieves gauge monitors")
    public Vector getGaugeMonitors();

    @Description("Returns reset interval")
    public long getConfResetInterval();

    // generic message
    @Description("Specify the messge")
    public void setMessage(@PName("The message") String message);

    @Description("Retrieve the messge")
    public String  getMessage();

    // we need the metrics initialized on a regular basis to provide more pertinent monitoring.
    @Description("Set last initialization")
    public void setLastInitialization(@PName("The message") String message);

    @Description("Retrieve last initialization")
    public String getLastInitialization();

}
