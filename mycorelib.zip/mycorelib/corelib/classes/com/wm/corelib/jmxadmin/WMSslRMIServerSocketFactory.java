package com.wm.corelib.jmxadmin;

import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLContext;
import javax.rmi.ssl.SslRMIServerSocketFactory;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;

/**
 * WMSslRMIServerSocketFactory
 *
 * @since January 2006
 * @version $Id: WMSslRMIServerSocketFactory.java,v 1.2 2009/04/08 05:14:00 mkishore Exp $
 * @author Igor.Dralyuk@walmart.com
 */
public class WMSslRMIServerSocketFactory extends SslRMIServerSocketFactory {

    private static final Logger _log = Logger.getLogger(WMSslRMIServerSocketFactory.class.getName());

    private static SSLSocketFactory sslSocketFactory = null;

    static {
        try {
            SSLContext _SSLContext =SslUtil.getJMXSslContext();
            if ( _SSLContext != null) {
                sslSocketFactory = _SSLContext.getSocketFactory();
            } else {
                _log.log(Level.SEVERE, "Cannot initialize custom SSL Socket Factory, will use default");
                sslSocketFactory = (SSLSocketFactory)SSLSocketFactory.getDefault();
                }
        } catch (Throwable t) {
            _log.log(Level.SEVERE, "Cannot initialize custom SSL Socket Factory, will use default", t);
            sslSocketFactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
        }
    }

    private static synchronized SSLSocketFactory getDefaultSSLSocketFactory() {
        _log.fine("getDefaultSSLSocketFactory() returning " + sslSocketFactory);
        return sslSocketFactory;
    }

    /**
     * <p>Creates a server socket that accepts SSL connections
     * configured according to this factory's SSL socket configuration
     * parameters.</p>
     */
    public ServerSocket createServerSocket(int port) throws IOException {
        final SSLSocketFactory sslSocketFactory = getDefaultSSLSocketFactory();
        return new ServerSocket(port) {
            public Socket accept() throws IOException {
                Socket socket = super.accept();
                SSLSocket sslSocket = (SSLSocket)
                    sslSocketFactory.createSocket(
                        socket, socket.getInetAddress().getHostName(),
                        socket.getPort(), true);
                sslSocket.setUseClientMode(false);
                if (getEnabledCipherSuites() != null) {
                    sslSocket.setEnabledCipherSuites(getEnabledCipherSuites());
                }
                if (getEnabledProtocols() != null) {
                    sslSocket.setEnabledProtocols(getEnabledProtocols());
                }
                sslSocket.setNeedClientAuth(getNeedClientAuth());
                return sslSocket;
            }
        };
    }
}
