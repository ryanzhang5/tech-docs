package com.wm.corelib.jmxadmin;

import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLContext;
import javax.net.SocketFactory;
import javax.rmi.ssl.SslRMIClientSocketFactory;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.StringTokenizer;
import java.net.Socket;
import java.io.IOException;
  
import com.wm.corelib.config.AppConfig;

/**
 * WMSslRMIClientSocketFactory
 *
 * @since January 2006
 * @version $Id: WMSslRMIClientSocketFactory.java,v 1.3 2011/05/05 01:50:29 alu Exp $
 * @author Igor.Dralyuk@walmart.com
 */
public class WMSslRMIClientSocketFactory extends SslRMIClientSocketFactory {

    private static final Logger _log = Logger.getLogger(WMSslRMIClientSocketFactory.class.getName());

    private static SocketFactory sslSocketFactory = null;

    static {
        try {
            SSLContext _SSLContext =SslUtil.getJMXSslContext();
            if ( _SSLContext != null) {
                sslSocketFactory = _SSLContext.getSocketFactory();
            } else {
                _log.log(Level.SEVERE, "Cannot initialize custom SSL Socket Factory, will use default");
                sslSocketFactory = SSLSocketFactory.getDefault();
                }
        } catch (Throwable t) {
            _log.log(Level.SEVERE, "Cannot initialize custom SSL Socket Factory, will use default", t);
            sslSocketFactory = SSLSocketFactory.getDefault();
        }
    }

    private static synchronized SocketFactory getDefaultClientSocketFactory() {
        _log.fine("getDefaultSSLSocketFactory() returning " + sslSocketFactory);
        return sslSocketFactory;
    }

    /**
     * <p>Creates an SSL socket.</p>
     *
     * <p>If the system property
     * <code>javax.rmi.ssl.client.enabledCipherSuites</code> is
     * specified, this method will call {@link
     * SSLSocket#setEnabledCipherSuites(String[])} before returning
     * the socket. The value of this system property is a string that
     * is a comma-separated list of SSL/TLS cipher suites to
     * enable.</p>
     *
     * <p>If the system property
     * <code>javax.rmi.ssl.client.enabledProtocols</code> is
     * specified, this method will call {@link
     * SSLSocket#setEnabledProtocols(String[])} before returning the
     * socket. The value of this system property is a string that is a
     * comma-separated list of SSL/TLS protocol versions to
     * enable.</p>
     */
    public Socket createSocket(String host, int port) throws IOException {
        // Retrieve the SSLSocketFactory
        //
        final SocketFactory sslSocketFactory = getDefaultClientSocketFactory();
        // Create the SSLSocket
        //
        final SSLSocket sslSocket = (SSLSocket)
            sslSocketFactory.createSocket(host, port);
        // Set the SSLSocket Enabled Cipher Suites
        //
        final String enabledCipherSuites = (String)
            AppConfig.getInstance().getProperty("javax.rmi.ssl.client.enabledCipherSuites");
        if (enabledCipherSuites != null) {
            StringTokenizer st = new StringTokenizer(enabledCipherSuites, ",");
            int tokens = st.countTokens();
            String enabledCipherSuitesList[] = new String[tokens];
            for (int i = 0 ; i < tokens; i++) {
                enabledCipherSuitesList[i] = st.nextToken();
            }
        try {
        sslSocket.setEnabledCipherSuites(enabledCipherSuitesList);
        } catch (IllegalArgumentException e) {
        throw (IOException)
            new IOException(e.getMessage()).initCause(e);
        }
        }
        // Set the SSLSocket Enabled Protocols
        //
        final String enabledProtocols = (String)
            AppConfig.getInstance().getProperty("javax.rmi.ssl.client.enabledProtocols");
        if (enabledProtocols != null) {
            StringTokenizer st = new StringTokenizer(enabledProtocols, ",");
            int tokens = st.countTokens();
            String enabledProtocolsList[] = new String[tokens];
            for (int i = 0 ; i < tokens; i++) {
                enabledProtocolsList[i] = st.nextToken();
            }
        try {
        sslSocket.setEnabledProtocols(enabledProtocolsList);
        } catch (IllegalArgumentException e) {
        throw (IOException)
            new IOException(e.getMessage()).initCause(e);
        }
        }
        // Return the preconfigured SSLSocket
        //
        return sslSocket;
    }
}
