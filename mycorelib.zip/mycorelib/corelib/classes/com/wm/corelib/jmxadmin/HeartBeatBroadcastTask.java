package com.wm.corelib.jmxadmin;
import java.util.TimerTask;
import javax.management.Notification;

public class HeartBeatBroadcastTask extends TimerTask {
    long _heartBeatSeqNo = Long.MIN_VALUE;
    WmtMBeanImpl _mBeanObject;

    public HeartBeatBroadcastTask(WmtMBeanImpl BeanObject) {
	    _mBeanObject = BeanObject;
    }
    
    public void run() {
	    Notification n = new Notification("HeartBeat",  _mBeanObject,_heartBeatSeqNo++);
	    _mBeanObject.sendNotification (n);
    }//run
    
}
