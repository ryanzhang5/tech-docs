package com.wm.corelib.jmxadmin;

/**
 * Gauge Monitor Definition class is used to set monitor on various attributes. 
 */
public class GaugeMonitorDefinition implements java.io.Serializable {
    private String _monitorName;
    private String _attrName;
    private Long   _granularity;
    private Boolean _notifyHi;
    private Boolean _notifyLo;
    private float   _hi;
    private float   _lo;

  /**
   * Constructor
   * @param monitorName -- String
   * @param attrName -- String
   * @param granularity -- Long
   * @param notifyHi  -- Boolean
   * @param notifyLo -- Boolean
   * @param hi -- Float
   * @param lo -- Float
   */
    public GaugeMonitorDefinition (String monitorName, String attrName, Long granularity, Boolean notifyHi, Boolean notifyLo, Float hi, Float lo) {
  	_monitorName = monitorName;
	  _attrName = attrName;
	  _granularity = granularity;
	  _notifyHi = notifyHi;
	  _notifyLo = notifyLo;
	  _hi = hi;
	  _lo = lo;
    }

  /**
   * Get Monitor Name method 
   * @return -- String
   */
    public String getMonitorName() { return _monitorName;}

   /**
   * Get Attribute Name
   * @return -- String
   */
    public String getAttrName() { return _attrName;}
 
   /**
   * Get Granularity Method
   * @return -- Long
   */
    public Long getGranularity() { return _granularity; }
   
   /**
   * Get Notify High Method
   * @return -- Boolean
   */
    public Boolean getNotifyHi() { return _notifyHi; }
  
  /**
   * Get Notify Low Method
   * @return -- Boolean
   */
    public Boolean getNotifyLo() { return _notifyLo; }

  /**
   * Get High Method
   * @return -- Float
   */
    public Float getHi() { return _hi;}
  
  /**
   * Get Low Method
   * @return -- Float
   */
  public Float getLo() { return _lo;}

  /**
   * Set High Method
   * @param hi -- Float
   */
  public void  setHi(Float hi) { _hi = hi;}
  
  /**
   * Set Low Method
   * @param lo -- Float
   */
  public void  setLo(Float lo) { _lo = lo;}
}
