/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.io;

import java.io.InputStream;
import java.net.URL;

/**
 * Resource - inspired by Spring Resource framework
 *
 * @author mkishore
 * @since 2.5.2
 */
public interface Resource {
    /**
     * Returns the inputstream to read the data from this resource
     *
     * @return the inputstream to read the data from this resource
     */
    public InputStream getInputStream();

    /**
     * Returns the URL for this resource
     *
     * @return thr URL for this resource
     */
    public URL getURL();

    /**
     * Returns a description of this resource - typically for exception scenarios.
     *
     * @return a description of this resource - typically for exception scenarios
     */
    public String getDescription();
}
