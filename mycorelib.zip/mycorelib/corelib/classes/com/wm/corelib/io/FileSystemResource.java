/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.File;
import java.net.URL;
import java.net.MalformedURLException;

/**
 * FileSystemResource - provides an abstraction over the contents of a file on a file-system 
 *
 * @author mkishore
 * @since 2.5.2
 */
public class FileSystemResource implements Resource {
    private String path;

    public InputStream getInputStream() {
        try {
            return new FileInputStream(path);
        } catch (FileNotFoundException e) {
            throw new RuntimeException("Error reading the file on the file-system at: " + path, e);
        }
    }

    public URL getURL() {
        try {
            return new File(path).toURI().toURL();
        } catch (MalformedURLException e) {
            throw new RuntimeException("Error getting the URL for the file on the file-system at: " + path);
        }
    }

    public String getDescription() {
        return "file://" + path;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
