/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.io;

import java.io.InputStream;
import java.net.URL;

/**
 * ClassPathResource - provides an abstraction over the contents of a file on the class-path
 *
 * @author mkishore
 * @since 2.5.2
 */
public class ClassPathResource implements Resource {
    private String path;

    public InputStream getInputStream() {
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        InputStream is = loader.getResourceAsStream(path);
        if (is == null) {
            throw new RuntimeException("Error reading the file on the class-path at: " + path);
        }
        return is;
    }

    public URL getURL() {
        ClassLoader loader = Thread.currentThread().getContextClassLoader();
        URL url = loader.getResource(path);
        if (url == null) {
            throw new RuntimeException("Error getting the URL for the file on the class-path at: " + path);
        }
        return url;
    }

    public String getDescription() {
        return "classpath://" + path;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        if (path.startsWith("/")) path = path.substring(1);
        this.path = path;
    }
}
