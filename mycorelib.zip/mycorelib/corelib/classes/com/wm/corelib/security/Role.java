package com.wm.corelib.security;

import com.wm.sql.DataAccess;
import com.wm.sql.XRuntimeSQL;
import com.wm.corelib.core.XRuntime;

import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class Role implements Serializable {

    public interface IRoleRec {
        public String GET_ROLE_BY_APPLICATION_USER = "{ call wcs_security_pkg.get_role_by_app_and_user(?, ?, ?) }";
        public int ROLE_ID = 1;
        public int ROLE_NAME = 2;
        public int ROLE_DESCRIPTION = 3;
    }

    private int _roleId;
    private String _roleName;
    private String _roleDescription;

    public int getRoleId() {
        return _roleId;
    }

    public void setRoleId(int roleId) {
        _roleId = roleId;
    }

    public String getRoleName() {
        return _roleName;
    }

    public void setRoleName(String roleName) {
        _roleName = roleName;
    }

    public String getRoleDescription() {
        return _roleDescription;
    }

    public void setRoleDescription(String roleDescription) {
        _roleDescription = roleDescription;
    }

    public void populateRole(ResultSet rs) throws SQLException {
        _roleId = rs.getInt(IRoleRec.ROLE_ID);
        _roleName = rs.getString(IRoleRec.ROLE_NAME);
        _roleDescription = rs.getString(IRoleRec.ROLE_DESCRIPTION);
    }

    public static Role newInstance() throws java.lang.InstantiationException, java.lang.IllegalAccessException {
        return (Role) Role.class.newInstance();
    }

    public static Role newInstance(Class c) throws java.lang.InstantiationException, java.lang.IllegalAccessException {
        return (Role) c.newInstance();
    }

    public static Role[] newArray(Class c, int size) {
        return (Role[]) java.lang.reflect.Array.newInstance(c, size);
    }

    /**
     * Load all Roles - they are constrained by applicationId, userId.
     * To remove constraints, set applicationId/userId = -1.
     *
     * @return Role[]
     */
    public static Role[] loadAllRoles() throws XRuntimeSQL {
        return loadRolesByApplicationAndUser(-1, -1);
    }

    public static Role[] loadRolesByApplication(int applicationId) throws XRuntimeSQL {
        return loadRolesByApplicationAndUser(applicationId, -1);
    }

    public static Role[] loadRolesByUser(int userId) throws XRuntimeSQL {
        return loadRolesByApplicationAndUser(-1, userId);
    }

    public static Role[] loadRolesByApplicationAndUser(int applicationId, long userId) throws XRuntimeSQL {
        return loadRolesByApplicationAndUser(applicationId, userId, Role.class);
    }

    public static Role[] loadRolesByApplicationAndUser(int applicationId, long userId, Class c) throws XRuntimeSQL, XRuntime {
        Connection con = null;
        CallableStatement stmt = null;
        ResultSet rs = null;
        Role rv[] = null;
        Vector v = new Vector();
        try {
            con = DataAccess.getInstance().getConnection(SecurityConfig.getInstance().getDBAlias());
            stmt = con.prepareCall(IRoleRec.GET_ROLE_BY_APPLICATION_USER);
            stmt.setInt(1, applicationId);
            stmt.setLong(2, userId);
            stmt.registerOutParameter(3, oracle.jdbc.driver.OracleTypes.CURSOR);
            stmt.execute();
            rs = (ResultSet) stmt.getObject(3);
            while (rs.next()) {
                Role tmp = Role.newInstance(c);
                tmp.populateRole(rs);
                v.addElement(tmp);
            }
        }
        catch (SQLException e) {
            throw new XRuntimeSQL(e);
        }
        catch (IllegalAccessException e) {
            throw new XRuntime(e);
        } catch (InstantiationException e) {
            throw new XRuntime(e);
        } finally {
            DataAccess.close(rs, stmt, con);
        }

        rv = newArray(c, v.size());
        v.copyInto(rv);
        return rv;
    }

    public String toString() {
        StringBuffer out = new StringBuffer(getClass().getName() + ": {\n");
        out.append("RoleId: ").append(getRoleId()).append(",\n");
        out.append("RoleName: ").append(getRoleName()).append(",\n");
        out.append("RoleDescription: ").append(getRoleDescription()).append(",\n");
        out.append("}\n");
        return out.toString();
    }

}
