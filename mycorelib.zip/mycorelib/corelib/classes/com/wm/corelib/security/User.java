package com.wm.corelib.security;

import com.wm.corelib.core.XRuntime;
import com.wm.sql.DataAccess;
import com.wm.sql.XRuntimeSQL;

import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.Vector;

public class User implements Serializable {

    public interface IUserRec {
        public static final String GET_USER = "{ call wcs_security_pkg.get_user_role(?,?,?,?,?,?,?,?) }";
        public static final String USER_LOGIN = "{ call wcs_security_pkg.user_login(?, ?, ?, ?, ?)}";
        public static final String UPDATE_USER_SQL = "{ call wcs_security_pkg.update_cs_user(?,?,?,?,?,?,?,?,?,?,?)}";
        public static final String ADD_USER_SQL = "{ call wcs_security_pkg.add_user(?,?,?,?,?,?,?,?,?,?)}";

        // parameter binding for GET_USER
        public int USER_ID_IN           = 1;
        public int APP_ID_IN            = 2;
        public int USER_INFO_OUT        = 3;
        public int ACTIVE_QUALIFIER_IN  = 4;
        public int LOGIN_NAME_IN        = 5;
        public int ROLE_ID_IN           = 6;
        public int LOCATION_ID_IN       = 7;
        public int SORT_COLUMN_IN       = 8;
        public int SORT_ORDER_IN        = 9;
        public int EDITOR_ID_IN         = 10;

        // UserCursor output fields
        public int USER_ID              = 1;
        public int LOGIN                = 2;
        public int LAST_NAME            = 3;
        public int FIRST_NAME           = 4;
        public int LOCATION_ID          = 5;
        public int LOC_SHORT_DESC       = 6;
        public int LAST_LOGIN_DATE      = 7;
        public int CREATED_BY           = 8;
        public int CREATED_DTM          = 9;
        public int IS_ACTIVE            = 10;
        public int DISTRIBUTOR_ID       = 11;
        public int IS_DISTRIBUTOR_ONLY  = 12;
        public int MODIFIED_BY          = 13;
        public int MODIFIED_DTM         = 14;
        public int EMAIL                = 15;
        public int Expiration_Date		= 16;
    }

    private int _userId;
    private String _login;
    private String _password;
    private String _firstName;
    private String _lastName;
    private int _locationId;
    private String _locShortDesc;
    private Date _lastLoginDate;
    private int _createdById;
    private String _createdByName;
    private Date _createdDtm;
    private String _isActive;
    private long _distributorId;
    private String _isDistributorOnly;
    private String _isUserUpdateable;
    private int _modifiedBy;
    private Date _modifiedDtm;
    private Role[] _roles;
    private String _email;
    private Date _expirationDate; //password expiration date
    

    public int getCreatedById() {
        return _createdById;
    }

    public void setCreatedById(int createdById) {
        _createdById = createdById;
    }

    public String getCreatedByName() {
        return _createdByName;
    }

    public void setCreatedByName(String createdByName) {
        _createdByName = createdByName;
    }

    public void setLastLoginDate(Date lastLoginDate) {
        _lastLoginDate = lastLoginDate;
    }

    public void setCreatedDtm(Date createdDtm) {
        _createdDtm = createdDtm;
    }

    public String getActive() {
        return _isActive;
    }

    public void setActive(String active) {
        _isActive = active;
    }

    public long getDistributorId() {
        return _distributorId;
    }

    public void setDistributorId(long distributorId) {
        _distributorId = distributorId;
    }

    public void setDistributorId(String distributorId) {
        try {
            _distributorId = Long.parseLong(distributorId);
        } catch (NumberFormatException e) {
            _distributorId = -1;
        }
    }

    public String getDistributorOnly() {
        return _isDistributorOnly;
    }

    public void setDistributorOnly(String distributorOnly) {
        _isDistributorOnly = distributorOnly;
    }

    public String getUserUpdateable() {
        return _isUserUpdateable;
    }

    public void setUserUpdateable(String userUpdateable) {
        _isUserUpdateable = userUpdateable;
    }

    public User() {
        super();
        setUserId(-1);
        setFirstName("");
        setLastName("");
        setLogin("");
        setPassword("");
        setIsActive("Y");
        setIsUserUpdateable("Y");
    }

    public static User newInstance() throws java.lang.InstantiationException, java.lang.IllegalAccessException {
        return (User) User.class.newInstance();
    }

    public static User newInstance(Class c) throws java.lang.InstantiationException, java.lang.IllegalAccessException {
        return (User) c.newInstance();
    }

    public static User[] newArray(Class c, int size) {
        return (User[]) java.lang.reflect.Array.newInstance(c, size);
    }

    public int getUserId() {
        return _userId;
    }

    public void setUserId(int v) {
        _userId = v;
    }

    public String getLogin() {
        return _login;
    }

    public void setLogin(String v) {
        _login = v;
    }

    public String getPassword() {
        return _password;
    }

    public void setPassword(String v) {
        _password = v;
    }


    public String getFirstName() {
        return _firstName;
    }

    public void setFirstName(String v) {
        _firstName = v;
    }

    public String getLastName() {
        return _lastName;
    }

    public void setLastName(String v) {
        _lastName = v;
    }

    public int getLocationId() {
        return _locationId;
    }

    public void setLocationId(int v) {
        _locationId = v;
    }

    public String getLocShortDesc() {
        return (_locShortDesc == null ? "" : _locShortDesc);
    }

    public void setLocShortDesc(String v) {
        _locShortDesc = v;
    }

    public Date getLastLoginDate() {
        return _lastLoginDate;
    }

    public Date getCreatedDtm() {
        return _createdDtm;
    }

    public boolean isActive() {
        return "y".equalsIgnoreCase(getIsActive());
    }

    public String getIsActive() {
        return _isActive;
    }

    public void setIsActive(String v) {
        _isActive = v;
    }

    public long getIntDistributorId() {
        return _distributorId;
    }

    public void setIntDistributorId(int v) {
        _distributorId = v;
    }

    public boolean isDistributorOnly() {
        return "y".equalsIgnoreCase(getIsDistributorOnly());
    }

    public String getIsDistributorOnly() {
        return _isDistributorOnly;
    }

    public void setIsDistributorOnly(String v) {
        _isDistributorOnly = v;
    }

    public boolean isUserUpdateable() {
        return "y".equalsIgnoreCase(getIsUserUpdateable());
    }

    public String getIsUserUpdateable() {
        return _isUserUpdateable;
    }

    public void setIsUserUpdateable(String v) {
        _isUserUpdateable = v;
    }

    public int getModifiedBy() {
        return _modifiedBy;
    }

    public void setModifiedBy(int v) {
        _modifiedBy = v;
    }

    public Date getModifiedDtm() {
        return _modifiedDtm;
    }

    public void setModifiedDtm(Date modifiedDtm) {
        _modifiedDtm = modifiedDtm;
    }

    public Role [] getRoles() {
        return _roles;
    }

    public void setRoles(Role[] r) {
        _roles = r;
    }

    public String getEmail() {
        return _email;
    }

    public void setEmail(String _email) {
        this._email = _email;
    }

    //returns true if user has specified role
    public boolean hasRole(int roleId) {
        if (_roles != null) {
            for (int i = 0; i < _roles.length; i++) {
                if (_roles[i].getRoleId() == roleId) {
                    return true;
                }
            }
        }
        return false;
    }

    public void addRole(Role r) {
        addRole(Role.class, r);
    }

    public void addRole(Class c, Role r) {
        int length = (_roles != null ? _roles.length : 0);
        Role[] tmp = Role.newArray(c, length + 1);
        if (_roles != null) {
            System.arraycopy(_roles, 0, tmp, 0, _roles.length);
        }
        tmp[length] = r;
        _roles = (Role[]) tmp.clone();
    }

    public void setCommaDelimitedRoles(String [] roles) {
        if (roles != null) {
            _roles = Role.newArray(Role.class, roles.length);
            for (int i = 0; i < roles.length; i++) {
                Role tmp = new Role();
                try {
                    tmp.setRoleId(Integer.parseInt(roles[i]));
                }
                catch (NumberFormatException nfe) {
                    /* this shouldn't really happen, but in case there
                    * something wrong will just skip the wrong one
                    */
                }
                addRole(tmp);
            }
        }
    }

    public String getRoleString() {
        String str = "";
        if (_roles != null) {
            for (int i = 0; i < _roles.length; i++) {
                if (i > 0) {
                    str += ", ";
                }
                str += _roles[i].getRoleName();
            }
        }
        return str;
    }


    public boolean getIsNew() {
        return getUserId() == -1;
    }

    public boolean isValid() {
        return this.getUserId() > 0;
    }

    private void _populate(ResultSet rs) throws SQLException {
        _userId = rs.getInt(IUserRec.USER_ID);
        _login = rs.getString(IUserRec.LOGIN);
        _lastName = rs.getString(IUserRec.LAST_NAME);
        _firstName = rs.getString(IUserRec.FIRST_NAME);
        _locationId = rs.getInt(IUserRec.LOCATION_ID);
        _locShortDesc = rs.getString(IUserRec.LOC_SHORT_DESC);
        _lastLoginDate = rs.getDate(IUserRec.LAST_LOGIN_DATE);
        _createdByName = rs.getString(IUserRec.CREATED_BY);
        _createdDtm = rs.getDate(IUserRec.CREATED_DTM);
        _isActive = rs.getString(IUserRec.IS_ACTIVE);
        _distributorId = rs.getInt(IUserRec.DISTRIBUTOR_ID);
        _isDistributorOnly = rs.getString(IUserRec.IS_DISTRIBUTOR_ONLY);
        _modifiedBy = rs.getInt(IUserRec.MODIFIED_BY);
        _modifiedDtm = rs.getDate(IUserRec.MODIFIED_DTM);
        _email = rs.getString(IUserRec.EMAIL);
        _expirationDate = rs.getDate(IUserRec.Expiration_Date);
    }

    private void _populateUsers(ResultSet rs) throws SQLException {
        _userId = rs.getInt(1);
        _login = rs.getString(2);
        _lastName = rs.getString(3);
        _firstName = rs.getString(4);
        _locationId = rs.getInt(5);
        _locShortDesc = rs.getString(6);
        _lastLoginDate = rs.getDate(7);
        _createdByName = rs.getString(8);
        _createdDtm = rs.getDate(9);
        _isActive = rs.getString(10);
        _distributorId = rs.getInt(11);
        _isDistributorOnly = rs.getString(12);
        _isUserUpdateable = rs.getString(13);
        _email = rs.getString(16);
    }

    private void _populateRole(ResultSet rs, Class c) throws SQLException, IllegalAccessException, InstantiationException {
        Role role = Role.newInstance(c);
        role.populateRole(rs);
        addRole(c, role);
    }

    public static User[] loadAllUsers(int applicationId) throws XRuntimeSQL, XRuntime {
        return loadUsers("ALL", null, -1, -1, -1, -1, applicationId);
    }

    public static User[] loadUsersByStatus(String userStatus, int applicationId)
            throws XRuntimeSQL, XRuntime {
        return loadUsers(userStatus, null, -1, -1, -1, -1, applicationId);
    }

    public static User[] loadUsersByRole(int roleId, int applicationId)
            throws XRuntimeSQL, XRuntime {
        return loadUsers("ALL", null, roleId, -1, -1, -1, applicationId);
    }

    public static User[] loadUsersByLocation(int locationId, int applicationId)
            throws XRuntimeSQL, XRuntime {
        return loadUsers("ALL", null, -1, locationId, -1, -1, applicationId);
    }

    public static User[] loadUsersByLoginName(String loginName, int applicationId)
            throws XRuntimeSQL, XRuntime {
        return loadUsers("ALL", loginName, -1, -1, -1, -1, applicationId);
    }

    public static User loadUsersByEditorId(int editorId, int applicationId)
            throws XRuntimeSQL, XRuntime {
        User [] users = loadUsers("ALL", null, -1, -1, -1, editorId, applicationId);
        return (users.length > 0) ? users[0] : new User();
    }

    public static User loadUserById(int userId)
            throws XRuntimeSQL, XRuntime {

        return loadUsersByUserId(userId, -1);
    }

    public static User loadUsersByUserId(int userId, int applicationId)
            throws XRuntimeSQL, XRuntime {
        User [] users = loadUsers("ALL", null, -1, -1, userId, -1, applicationId);
        return (users.length > 0) ? users[0] : new User();
    }

    public static User[] loadUsers(String userStatus, String loginName,
                                   int roleId, int locationId,
                                   int userId, int editorUserId, int applicationId)
            throws XRuntimeSQL, XRuntime {
        return loadUsers(userStatus, loginName, roleId, locationId,
                userId, editorUserId, applicationId, User.class, Role.class);

    }

    public static User[] loadUsers(String userStatus, String loginName,
                                   int roleId, int locationId,
                                   int userId, int editorUserId, int applicationId, Class userClass, Class roleClass)
            throws XRuntimeSQL, XRuntime {
        Connection con = null;
        CallableStatement stmt = null;
        ResultSet rs = null;
        User rv[];
        Vector v = new Vector();

        try {
            con = DataAccess.getInstance().getConnection(SecurityConfig.getInstance().getDBAlias());
            stmt = con.prepareCall(IUserRec.GET_USER);

            if (userId != -1) {
                stmt.setInt(1, userId);
            } else {
                stmt.setNull(1, Types.NUMERIC);
            }

            if (applicationId != -1) {
                stmt.setInt(2, applicationId);
            } else {
                stmt.setNull(2, Types.NUMERIC);
            }

            stmt.setString(3, userStatus);
            stmt.setString(4, loginName);

            if (roleId != -1) {
                stmt.setInt(5, roleId);
            } else {
                stmt.setNull(5, Types.NUMERIC);
            }

            if (locationId != -1) {
                stmt.setInt(6, locationId);
            } else {
                stmt.setNull(6, Types.NUMERIC);
            }

            if (editorUserId != -1) {
                stmt.setInt(7, editorUserId);
            } else {
                stmt.setNull(7, Types.NUMERIC);
            }

            stmt.registerOutParameter(8, oracle.jdbc.driver.OracleTypes.CURSOR);

            stmt.execute();

            rs = (ResultSet) stmt.getObject(8);
            int curId = 0;
            User tmp = User.newInstance(userClass);
            while (rs.next()) {
                if (curId != rs.getInt(IUserRec.USER_ID)) {
                    tmp = User.newInstance(userClass);
                    tmp._populateUsers(rs);
                    curId = tmp.getUserId();
                    v.addElement(tmp);
                }
                Role role = Role.newInstance(roleClass);
                role.setRoleId(rs.getInt(14));
                role.setRoleName(rs.getString(15));
                tmp.addRole(roleClass, role);

            }
        }
        catch (SQLException e) {
            throw new XRuntimeSQL(e);
        }
        catch (IllegalAccessException e) {
            throw new XRuntime(e);
        } catch (InstantiationException e) {
            throw new XRuntime(e);
        } finally {
            DataAccess.close(rs, stmt, con);
        }

        rv = newArray(userClass, v.size());
        v.copyInto(rv);
        return rv;
    }

    /**
     * Load a user by the login name and password. Returns null
     * if there is no such user.
     */
    public static User loadByLoginPass(String logid, String passwd, int applicationId) throws XRuntimeSQL {
        return loadByLoginPass(logid, passwd, applicationId, User.class);
    }

    public static User loadByLoginPass(String logid, String passwd, int applicationId, Class c) throws XRuntimeSQL {
        Connection con = null;
        CallableStatement stmt = null;
        ResultSet rs = null;
        ResultSet rsRole = null;
        User user = null;

        try {
            con = DataAccess.getInstance().getConnection(SecurityConfig.getInstance().getDBAlias());
            stmt = con.prepareCall(IUserRec.USER_LOGIN);
            stmt.setString(1, logid);
            stmt.setString(2, passwd);
            stmt.setInt(3, applicationId);
            stmt.registerOutParameter(4, oracle.jdbc.driver.OracleTypes.CURSOR);
            stmt.registerOutParameter(5, oracle.jdbc.driver.OracleTypes.CURSOR);
            stmt.execute();

            rs = (ResultSet) stmt.getObject(4);
            rsRole = (ResultSet) stmt.getObject(5);

            if (rs.next()) {
                user = User.newInstance(c);
                user._populate(rs);
                while (rsRole.next()) {
                    user._populateRole(rsRole, Role.class);
                }
            }
        }
        catch (SQLException e) {
            // Invalid password or login does not exist, just return null
            if ((e.getErrorCode() == 20006) || (e.getErrorCode() == 20007)) {
                return null;
            }

            throw new XRuntimeSQL(e);
        } catch (InstantiationException e) {
            throw new XRuntime(e);
        } catch (IllegalAccessException e) {
            throw new XRuntime(e);
        }
        finally {
            DataAccess.close(rsRole);
            DataAccess.close(rs, stmt, con);
        }

        return user;
    }

    public void update(long editorId) throws XRuntimeSQL {
        CallableStatement stmt = null;
        Connection con = null;

        try {
            con = DataAccess.getInstance().getConnection(SecurityConfig.getInstance().getDBAlias());
            stmt = con.prepareCall(IUserRec.UPDATE_USER_SQL);
            stmt.setLong    (1, this.getUserId());
            stmt.setString  (2, this.getLogin());
            stmt.setString  (3, this.getPassword());
            stmt.setString  (4, this.getLastName());
            stmt.setString  (5, this.getFirstName());
            stmt.setString  (6, this.getIsActive());
            stmt.setLong    (7, editorId);
            stmt.setLong    (8, this.getLocationId());
            if (this.getDistributorId() > 0) {
                stmt.setLong(9, this.getDistributorId());
            } else {
                stmt.setNull(9, Types.NUMERIC);
            }
            stmt.setString(10, this.getEmail());
            stmt.setDate(11, this.getExpirationDate() == null ? null : new java.sql.Date(this.getExpirationDate().getTime())); //set expiration date.
            stmt.execute();
        } catch (SQLException sqle) {
            throw new XRuntimeSQL(sqle);
        } finally {
            DataAccess.close(stmt, con);
        }
    }

    public int addNew(long editorId) throws XRuntimeSQL {
        CallableStatement stmt = null;
        Connection con = null;
        int newRepId = -1;

        try {
            con = DataAccess.getInstance().getConnection(SecurityConfig.getInstance().getDBAlias());
            stmt = con.prepareCall(IUserRec.ADD_USER_SQL);

            stmt.setString(1, this.getLogin());
            stmt.setString(2, this.getPassword());
            stmt.setString(3, this.getFirstName());
            stmt.setString(4, this.getLastName());
            stmt.setString(5, this.getIsActive());
            stmt.setLong(6, editorId);
            stmt.setLong(7, this.getLocationId());
            if (this.getDistributorId() > 0) {
                stmt.setLong(8, this.getDistributorId());
            } else {
                stmt.setNull(8, Types.NUMERIC);
            }
            stmt.registerOutParameter(9, java.sql.Types.BIGINT);
            stmt.setString(10, this.getEmail());
            stmt.execute();

            newRepId = stmt.getInt(9);
            this.setUserId(newRepId);
        } catch (SQLException sqle) {
            throw new XRuntimeSQL(sqle);
        } finally {
            DataAccess.close(stmt, con);
        }

        return newRepId;
    }

    public String toString() {
        StringBuffer out = new StringBuffer(getClass().getName() + ": {\n");
        out.append("userId: ").append(getUserId()).append(",\n");
        out.append("login: ").append(getLogin()).append(",\n");
        out.append("firstName: ").append(getFirstName()).append(",\n");
        out.append("lastName: ").append(getLastName()).append(",\n");
        out.append("password: ").append(getPassword()).append(",\n");
        out.append("locationId: ").append(getLocationId()).append(",\n");
        out.append("locShortDesc: ").append(getLocShortDesc()).append(",\n");
        out.append("lastLoginDate: ").append(getLastLoginDate()).append(",\n");
        out.append("createdDtm: ").append(getCreatedDtm()).append(",\n");
        out.append("modifiedBy: ").append(getModifiedBy()).append(",\n");
        out.append("modifiedDtm: ").append(getModifiedDtm()).append(",\n");
        out.append("isActive: ").append(getIsActive()).append(",\n");
        out.append("distributorId: ").append(getIntDistributorId()).append(",\n");
        out.append("isDistributorOnly: ").append(isDistributorOnly()).append(",\n");
        out.append("isUserUpdateable: ").append(isUserUpdateable()).append(",\n");
        out.append("Roles: ").append(getRoleString()).append("\n");
        out.append("}\n");
        return out.toString();
    }

	public Date getExpirationDate() {
		return _expirationDate;
	}

	public void setExpirationDate(Date date) {
		_expirationDate = date;
	}
}


