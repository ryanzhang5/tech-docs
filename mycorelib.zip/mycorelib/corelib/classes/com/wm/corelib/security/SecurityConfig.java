package com.wm.corelib.security;

import com.wm.corelib.dbc.Assert;
import com.wm.sql.DataAccess;

import java.sql.Connection;

public class SecurityConfig {
    public static final String SECURITY_POOL = "jdbcpool_security";
    public static final String DAL_SECURITY_POOL = "dalpool_security";
    
    private SecurityConfig() {
    }

    public synchronized static SecurityConfig getInstance() {
        if (_instance == null) {
            _instance = new SecurityConfig();
            _instance.setDBAlias(SECURITY_POOL);
            _instance.setSecondaryDBAlias(DAL_SECURITY_POOL);
        }
        return _instance;
    }

    public String getDBAlias() {
        Assert.pre(_poolAliasName != null);
        String poolName = null;
        Connection con = null;
        try {
            con = DataAccess.getInstance().getConnection(_poolAliasName);
            if (con != null) {
                poolName = _poolAliasName;
            } else {
                    con = DataAccess.getInstance().getConnection(_secondaryPoolAliasName);
                    if (con != null) {
                        poolName = _secondaryPoolAliasName;
                    }
            }
        } catch (Exception exp) {
                exp.printStackTrace();
        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (Exception e) {}
            }
        }
        return poolName;
    }

    private void setDBAlias(String alias) {
        _poolAliasName = alias;
    }

    private void setSecondaryDBAlias(String alias) {
        _secondaryPoolAliasName = alias;
    }

    private static SecurityConfig _instance = null;
    private static String _poolAliasName = null;
    private static String _secondaryPoolAliasName = null;
}
