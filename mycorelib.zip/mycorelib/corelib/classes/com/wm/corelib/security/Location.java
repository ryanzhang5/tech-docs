package com.wm.corelib.security;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.CallableStatement;
import java.util.Vector;

import com.wm.sql.XRuntimeSQL;
import com.wm.sql.DataAccess;
import com.wm.corelib.core.XRuntime;


public class Location {

    public interface ILocationRec {
        public String GET_LOCATIONS = "{ call wcs_security_pkg.get_locations(?) }";
        public int LOCATION_ID = 1;
        public int LOCATION_NAME = 2;
        public int DESCRIPTION = 3;
    }

    private int _locationId;
    private String _locationName;
    private String _description;

    public int getLocationId() {
        return _locationId;
    }

    public String getLocationName() {
        return _locationName;
    }

    public String getDescription() {
        return _description;
    }


    private void _populate(ResultSet rs) throws SQLException {
        _locationId = rs.getInt(ILocationRec.LOCATION_ID);
        _locationName = rs.getString(ILocationRec.LOCATION_NAME);
        _description = rs.getString(ILocationRec.DESCRIPTION);
    }

    public static Location[] loadAllLocations() throws XRuntimeSQL {
        return loadLocations();
    }

    public static Location newInstance() throws java.lang.InstantiationException, java.lang.IllegalAccessException {
        return (Location) Location.class.newInstance();
    }

    public static Location newInstance(Class c) throws java.lang.InstantiationException, java.lang.IllegalAccessException {
        return (Location) c.newInstance();
    }

    public static Location[] newArray(Class c, int size) {
        return (Location[]) java.lang.reflect.Array.newInstance(c, size);
    }

    public static Location[] loadLocations() throws XRuntimeSQL {
        return loadLocations(Location.class);
    }

    public static Location[] loadLocations(Class c) throws XRuntimeSQL {
        Connection con = null;
        CallableStatement stmt = null;
        ResultSet rs = null;
        Location rv[];
        Vector v = new Vector();

        try {
            con = DataAccess.getInstance().getConnection(SecurityConfig.getInstance().getDBAlias());
            stmt = con.prepareCall(ILocationRec.GET_LOCATIONS);
            stmt.registerOutParameter(1, oracle.jdbc.driver.OracleTypes.CURSOR);
            stmt.execute();
            rs = (ResultSet) stmt.getObject(1);
            while (rs.next()) {
                Location tmp = Location.newInstance(c);
                tmp._populate(rs);
                v.addElement(tmp);
            }
        }
        catch (SQLException e) {
            throw new XRuntimeSQL(e);
        } catch (IllegalAccessException e) {
            throw new XRuntime(e);
        } catch (InstantiationException e) {
            throw new XRuntime(e);
        } finally {
            DataAccess.close(rs, stmt, con);
        }
        rv = newArray(c, v.size());
        v.copyInto(rv);
        return rv;
    }

    public String toString() {
        StringBuffer out = new StringBuffer(getClass().getName() + ": {\n");
        out.append("LocationId: ").append(getLocationId()).append(",\n");
        out.append("ShortDesc: ").append(getLocationName()).append(",\n");
        out.append("Description: ").append(getDescription()).append(",\n");
        out.append("}\n");
        return out.toString();
    }
}


