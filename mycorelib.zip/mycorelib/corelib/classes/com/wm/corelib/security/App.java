package com.wm.corelib.security;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.CallableStatement;
import java.util.Vector;

import com.wm.sql.XRuntimeSQL;
import com.wm.sql.DataAccess;

public class App {
    public static final int SECURITY    = 0;
    public static final int TOOL        = 1;
    public static final int AVOCADO     = 2;
    public static final int WMS_DVD     = 3;
    public static final int RTS         = 4;
    public static final int MTS         = 5;
    public static final int SCMT        = 6;
    public static final int JMX         = 7;
    public static final int FMS         = 8;

    public interface IAppRec {
        public String GET_APPS = "{ call wcs_security_pkg.get_all_applications(?) }";
        public int APP_ID = 1;
        public int APP_NAME = 2;
        public int DESCRIPTION = 3;
    }

    private int _appId;
    private String _appName;
    private String _description;

    public int getAppId() {
        return _appId;
    }

    public String getAppName() {
        return _appName;
    }

    public String getDescription() {
        return _description;
    }

    private void _populate(ResultSet rs) throws SQLException {
        _appId = rs.getInt(IAppRec.APP_ID);
        _appName = rs.getString(IAppRec.APP_NAME);
        _description = rs.getString(IAppRec.DESCRIPTION);
    }

    public static App[] loadAllApps() throws XRuntimeSQL {
        Connection con = null;
        CallableStatement stmt = null;
        ResultSet rs = null;
        App rv[];
        Vector v = new Vector();

        try {
            con = DataAccess.getInstance().getConnection(SecurityConfig.getInstance().getDBAlias());
            stmt = con.prepareCall(IAppRec.GET_APPS);
            stmt.registerOutParameter(1, oracle.jdbc.driver.OracleTypes.CURSOR);
            stmt.execute();
            rs = (ResultSet) stmt.getObject(1);
            while (rs.next()) {
                App tmp = new App();
                tmp._populate(rs);
                v.addElement(tmp);
            }
        }
        catch (SQLException e) {
            throw new XRuntimeSQL(e);
        }
        finally {
            DataAccess.close(rs, stmt, con);
        }
        rv = new App[v.size()];
        v.copyInto(rv);
        return rv;
    }


    public String toString() {
        StringBuffer out = new StringBuffer(getClass().getName() + ": {\n");
        out.append("AppId: ").append(getAppId()).append(",\n");
        out.append("ShortDesc: ").append(getAppName()).append(",\n");
        out.append("Description: ").append(getDescription()).append(",\n");
        out.append("}\n");
        return out.toString();
    }
}


