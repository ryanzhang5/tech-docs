package com.wm.corelib.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Properties;
  
import com.wm.corelib.config.AppConfig;

/**
 * Class to pre-load and merge any properties files to System.properties
 * and to load any specified classes (by calling Class.forName()) before
 * running a program.
 * <p>
 * The following system properties determine what properties files are
 * merges to System.properties and what classes are loaded (by name):<br>
 * &nbsp;&nbsp; corelib.bootstrap.propfiles<br>
 * &nbsp;&nbsp; corelib.bootstrap.propfile.list<br>
 * &nbsp;&nbsp; corelib.bootstrap.classes
 * <p>
 * Each property is assumed to be a comma separated list of values, either
 * filenames for bootstrap.propfiles or full class names (wildcards will not
 * work) for corelib.bootstrap.classes.  corelib.bootstrap.propfile.list is
 * the sole exception: it take a single value which is a filename containing
 * a list of property files, one per line.  Each file that is listed is merged
 * to System.properties.
 * <p>
 * On any errors this class will exit with a code of 1; it is also assumed
 * that since you are bootstrapping and that all propfiles and classes
 * specified need to load correctly before calling the main program, that any
 * errors here will be errors down the line.  You can override this behaviour
 * by assigning the value "true" to the system property
 * corelib.bootstrap.continueOnErr.
 * <p>
 * Sample usage: java -Dcorelib.bootstrap.propfiles=/home/web/www/conf/homewarehouse.conf,/home/web/www/conf/logging.props
 *                    -Dcorelib.bootstrap.classes=com.wm.sys.Main com.wm.test.TomcatRunner arg1 arg2 arg3<p>
 * This would merge the specified properties files to System.properties, run any
 * anonymous static blocks in com.wm.sys.Main, and then invoke the public static
 * main(String[]) method of com.wm.test.TomcatRunner with the arguments arg1, arg2
 * and arg3.
 */
public class Bootstrap
{

    /** System property containing a comma separated list of java properties files */
    public static final String SYSTEM_PROP_BOOTSTRAP_PROPFILES = "corelib.bootstrap.propfiles";

    /** System property containing filenames of java properties files */
    public static final String SYSTEM_PROP_BOOTSTRAP_PROPFILE_LIST = "corelib.bootstrap.propfile.list";

    /** System property containing a comma separated list of java classes */
    public static final String SYSTEM_PROP_BOOTSTRAP_CLASSES = "corelib.bootstrap.classes";

    /** If this system property is set to "true" then errors are ignored when bootstrapping */
    public static final String SYSTEM_PROP_BOOTSTRAP_CONTINUE_ON_ERROR = "corelib.bootstrap.continueOnErr";

    /**
     * @return true if bootstrapping should continue as far as possible when
     *         encountering errors.
     */
    private static boolean shouldContinueOnError()
    {
        String contOnErr = AppConfig.getInstance().getProperty( SYSTEM_PROP_BOOTSTRAP_CONTINUE_ON_ERROR );
        return contOnErr != null && "true".equals( contOnErr );
    }

    /**
     * Adds all properties in the file <code>propsFile</code>
     * to System properties.
     */
    private static void mergeToSystemProperties( String propsFile )
    throws FileNotFoundException, IOException
    {
        Properties sysProps = AppConfig.getInstance().getProperties();
        sysProps.load( new FileInputStream( propsFile ) );
    }

    /**
     * Main processing method, does the high level work as described in the
     * class documentation.
     */
    public static void main( String[] args )
    {
        // Make sure we have at least one argument
        if ( args.length < 1 ) {
            System.err.println( "You must specify a main class to run as an argument" );
            System.exit( 1 );
        }

        // See if we should continue on errors
        boolean contOnErr = shouldContinueOnError();

        // Try to load individual properties first
        String sysPropFiles = AppConfig.getInstance().getProperty( SYSTEM_PROP_BOOTSTRAP_PROPFILES );
        if ( sysPropFiles != null ) {
            String[] userPropFiles = sysPropFiles.split( "," );
            for ( int pos = 0; pos < userPropFiles.length; ++pos ) {
                try {
                    mergeToSystemProperties( userPropFiles[pos] );
                } catch ( Throwable t ) {
                    if ( ! contOnErr ) {
                        System.err.println( "Unable to load properties file " + userPropFiles[pos]
                                + ": " + t.getMessage() );
                        t.printStackTrace( System.err );
                        System.exit( 1 );
                    }
                }
            }
        }

        // Try to load each file specified in the propfile list next
        String sysPropFileList = AppConfig.getInstance().getProperty( SYSTEM_PROP_BOOTSTRAP_PROPFILE_LIST );
        if ( sysPropFileList != null ) {
            try {
                BufferedReader br = new BufferedReader( new FileReader( sysPropFileList ) );
                String userPropFile = br.readLine();
                while ( userPropFile != null ) {
                    if ( ! "".equals( userPropFile.trim() ) ) {
                        try {
                            mergeToSystemProperties( userPropFile );
                        } catch ( Throwable t ) {
                            if ( ! contOnErr ) {
                                System.err.println( "Unable to load properties file " + userPropFile
                                        + ": " + t.getMessage() );
                                t.printStackTrace( System.err );
                                System.exit( 1 );
                            }
                        }
                    }
                    userPropFile = br.readLine();
                }
                br = null;
            } catch ( Throwable t2 ) {
                if ( ! contOnErr ) {
                    System.err.println( "Unable to load property list file " + sysPropFileList
                            + ": " + t2.getMessage() );
                    t2.printStackTrace( System.err );
                    System.exit( 1 );
                }
            }
        }

        // Try to bootstrap user defined classes
        String sysClasses = AppConfig.getInstance().getProperty( SYSTEM_PROP_BOOTSTRAP_CLASSES );
        if ( sysClasses != null ) {
            String[] bootClasses = sysClasses.split( "," );
            for ( int pos = 0; pos < bootClasses.length; ++pos ) {
                try {
                    Class.forName( bootClasses[pos] );
                } catch ( Throwable t ) {
                    if ( ! contOnErr ) {
                        System.err.println( "Unable to bootstrap class " + bootClasses[pos]
                                            + ": " + t.getMessage() );
                        t.printStackTrace( System.err );
                        System.exit( 1 );
                    }
                }
            }
        }

        // Bootstrapping complete, try to invoke the real main program
        try {
            Class mainClass = Class.forName( args[0] );
            if ( mainClass == null ) {
                throw new Exception( "Could not find main class[" + args[0] + "]" );
            }
            Method mainMethod = mainClass.getMethod( "main", new Class[] { String[].class } );
            if ( mainMethod == null ) {
                throw new Exception( "Could not find main(String[]) method[" + args[0] + "]" );
            }
            // Figure out the command line params for the main program
            String[] mainArgs = new String[ args.length - 1 ];
            for ( int pos = 0; pos < mainArgs.length; ++pos ) {
                mainArgs[pos] = args[pos+1];
            }

            // Invoke the main program
            mainMethod.invoke( null, new Object[] { mainArgs } );
        } catch ( Throwable t ) {
            System.err.println( "Error invoking main program " + args[0] + ": " + t.getMessage() );
            t.printStackTrace( System.err );
            System.exit( 1 );
        }
    }
}
