
package com.wm.corelib.core;

public interface IState
{
}
