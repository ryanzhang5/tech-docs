package com.wm.corelib.core;

public class XRuntime extends RuntimeException
{
  public XRuntime( Exception e )
  {
    super();
    initCause(e);
  }

  public XRuntime( String msg )
  {
    super( msg );
  }

  public XRuntime(String msg,Exception e)
  {
    super(msg);
    initCause(e);
  }
}
