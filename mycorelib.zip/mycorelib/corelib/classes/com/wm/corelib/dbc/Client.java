
package com.wm.corelib.dbc;

public class Client
{
  public void foo( String s )
  {
    Assert.pre( s != null, "s != null" );
    System.out.println( s );
  }

  public static void main( String args[] )
  {
    Client c = new Client();
    c.foo( null );
  }
}
