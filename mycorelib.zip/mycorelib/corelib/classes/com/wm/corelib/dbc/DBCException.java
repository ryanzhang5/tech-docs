
package com.wm.corelib.dbc;

import java.io.PrintWriter;
import java.io.PrintStream;
import java.io.StringWriter;

/**
 Parent class for all DBC exceptions.
 This class overrides default stack tracing mechanism to remove
 traces of com.wm.corelib.dbc classes (which is of no concern to users).
**/
class DBCException extends RuntimeException
{
  DBCException( String msg )
  {
    _msg = msg; 
    setStackTrace( modifyStackTrace( getStackTrace() ) );
  }

  public String getMessage()
  {
    String rv = getCType();
    if ( _msg != null )
      rv = rv + ": " + _msg;
    return rv;
  }

  public String getCType()
  {
    return "DBCEception";
  }

  /**
   removes second line from the buff argument
   @return buff argument with second line removed
  **/
  private StackTraceElement[] modifyStackTrace( StackTraceElement ste[] )
  {
    StackTraceElement rv[] = new StackTraceElement[ste.length - 1];
    for ( int i = 1; i < ste.length; i++ )
    {
      rv[i-1] = ste[i];
    }
    return rv;
  }
  
  private String _msg = null;
}
