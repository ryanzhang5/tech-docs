
package com.wm.corelib.dbc;

class PostconditionException extends DBCException
{
  PostconditionException( String msg )
  {
    super( msg );
  }
  public String getCType() { return MSG; }
  private static final String MSG = "POSTCONDITION FAILED!";
}
