
package com.wm.corelib.dbc;


class PreconditionException extends DBCException
{
  PreconditionException( String msg )
  {
    super( msg );
  }

  public String getCType() { return MSG; }
  private static final String MSG = "PRECONDITION FAILED!";
}
