
package com.wm.corelib.dbc;

class InvariantException extends DBCException
{
  InvariantException( String msg )
  {
    super( msg );
  }
  public String getCType() { return MSG; }
  private static final String MSG = "INVARIANT FAILED!";
}
