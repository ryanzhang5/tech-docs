
package com.wm.corelib.dbc;

public class Assert
{
  /**
   Checks precondition.
   Failed precondition means error in the client code.
   if v == false throws PreconditionException
  **/
  public static void pre( boolean v )
  {
    pre( v, null );
  }

  public static void pre( boolean v, String msg )
  {
    if ( _isOn && !v )
    {
      throw new PreconditionException( msg );
    }
  }

  /**
   Checks postcondition.
   Failed postcondition means error in the class implementation.
   if v == false throws PostconditionException
  **/
  public static void post( boolean v )
  {
    post( v, null );
  }

  public static void post( boolean v, String msg )
  {
    if ( _isOn && !v )
    {
      throw new PostconditionException( msg );
    }
  }

  /**
   Checks invariant.
   Failed invariant means error in the class implementation.
   if v == false throws InvariantException
  **/
  public static void inv( boolean v )
  {
    inv( v, null );
  }

  public static void inv( boolean v, String msg )
  {
    if ( _isOn && !v )
    {
      throw new InvariantException( msg );
    }
  }

  /**
   specifies if Assert enforcment is on
   if this is false, no checks will be performed
  **/
  private static final boolean _isOn = true;

  public static void main( String args[] )
  {
    Assert.pre( false );
  }
}
