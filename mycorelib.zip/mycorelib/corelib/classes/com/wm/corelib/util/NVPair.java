package com.wm.corelib.util;

/**
 * Struct for handling name/value pairs.  The constructors
 * mirror the static String.valueOf() methods.
 */
public class NVPair
  implements java.io.Serializable 
{
  public String name;
  public String value;

  public NVPair() { name = StringUtil.BLANK_STRING; value = StringUtil.BLANK_STRING; }

  public NVPair(String name, boolean value) {
    this(name, String.valueOf(value));
  }
  public NVPair(String name, char value) {
    this(name, String.valueOf(value));
  }
  public NVPair(String name, char[] value) {
    this(name, String.valueOf(value));
  }
  public NVPair(String name, char[] value, int i, int j) {
    this(name, String.valueOf(value, i, j));
  }
  public NVPair(String name, double value) {
    this(name, String.valueOf(value));
  }
  public NVPair(String name, float value) {
    this(name, String.valueOf(value));
  }
  public NVPair(String name, int value) {
    this(name, String.valueOf(value));
  }
  public NVPair(String name, long value) {
    this(name, String.valueOf(value));
  }

  /**
   * This does NOT trim whitespace before name comparison, whitespace
   * counts here.
   *
   * @return the NVPair object in the array with the matching name, or
   *         null if bad parameters are given or no match is found.
   */
  public static NVPair findByName( NVPair[] pairs, String name )
  {
      NVPair rv = null;
      if ( pairs != null && pairs.length > 0 && name != null ) {
          for ( int pos = 0; pos < pairs.length; ++pos )
          {
              if ( pairs[pos].name != null && name.equals( pairs[pos].name ) ) {
                  rv = pairs[pos];
                  break;
              }
          }
      }
      return rv;
  }

  /**
   * This does NOT trim whitespace before value comparison, whitespace
   * counts here.
   *
   * @return the NVPair object in the array with the matching value, or
   *         null if bad parameters are given or no match is found.
   */
  public static NVPair findByValue( NVPair[] pairs, String value )
  {
      NVPair rv = null;
      if ( pairs != null && pairs.length > 0 && value != null ) {
          for ( int pos = 0; pos < pairs.length; ++pos )
          {
              if ( pairs[pos].value != null && value.equals( pairs[pos].value ) ) {
                  rv = pairs[pos];
                  break;
              }
          }
      }
      return rv;
  }

  /**
   * You'll only want to use this if you're sure the 
   * object in question evaluates reasonably to a string.
   */
  public NVPair(String name, Object value) {
    this(name, value.toString());
  }
  public NVPair(String name, String value) {
    this.name = name;
    this.value = value;
  }

  /**
   * Parses the input string into two pieces based on the delimiter,
   * the split is based on the first occurrence of any character found
   * in the delim string.  If the delim is not found in the input, then
   * the name portion of the NVPair is the input string and the value
   * is a blank string.
   */
  public static NVPair parse( String input, String delim ) {
    NVPair retVal = new NVPair();

    if (    input != null
         && delim != null
         && input.length() > 0
         && delim.length() > 0 ) {
      // Find the first occurence of any delimiter and copy the strings
      // on either side to make a new NVPair
      int splitIx = -1;
      int tmpIx   = -1;
      for ( int ix = 0; ix < delim.length(); ++ix ) {
        tmpIx   = input.indexOf( delim.charAt( ix ) );
        // If the smaller of both indices is -1 then we want the greater one,
        // otherwise we want the smallest one
        splitIx = Math.min(splitIx, tmpIx) < 0 ? Math.max( splitIx, tmpIx ) :
                                                 Math.min( splitIx, tmpIx );
      }
      // See if we have a match
      if ( splitIx >= 0 ) {
        // Check for fringe cases where the split is at the beginning or the end
        if ( splitIx == 0 ) {
          // Just a value
          retVal.value = input.substring( 1, input.length() );
        } else if ( splitIx == input.length() - 1 ) {
          // Just a name
          retVal.name  = input.substring( 0, input.length() - 1 );
        } else {
          // We have a normal split
          retVal.name  = input.substring( 0, splitIx );
          retVal.value = input.substring( splitIx + 1, input.length() );
        }
      } else {
        // We didn't have a match, just copy the whole string for the name
        retVal.name = StringUtil.getNonNullTrimmed( input );
      }
    }
    return ( retVal );
  }
  public String toString() {
    return super.toString()+"{"+name+","+value+"}";
  }
  /**
   * Evaluates a NVPair array to a string with the option to specify pre/post-fixes
   * to names and values, plus the field seperator and record seperator.  This
   * should allow enough flexibility to use NVPair in HTML lists.
   *
   * Any NVPairs whose names *or* values are blank will be skipped.
   * Ideally, this behavior should be optional, and there should
   * be a boolean parameter to configure it (or simply a different method).
   * However, currently everybody who uses this method wants
   * the skip behavior, so for now I won't implement the alternative.
   */
  public static String toString( NVPair[] nvpArr,
                                 String   namePrefix,
                                 String   namePostfix,
                                 String   nvSeperator,
                                 String   valuePrefix,
                                 String   valuePostfix,
                                 String   recordSeperator ) {
    // Make sure we have something to print out
    if ( nvpArr == null || nvpArr.length == 0 ) {
      return ( StringUtil.BLANK_STRING );
    }

    StringBuffer  rv = new StringBuffer();
    NVPair       nvp = null;
    boolean first=true;
    
    for ( int pos = 0; pos < nvpArr.length; ++pos ) {
      nvp = nvpArr[ pos ];
      
      if (nvp.name!=null && nvp.name.length()>0 && nvp.value!=null && nvp.value.length()>0)
      {
        if ( !first ) {
          rv.append( recordSeperator != null
                               ? recordSeperator : StringUtil.BLANK_STRING );
        }
        first=false;
        
        if (namePrefix!=null) rv.append(namePrefix);
        rv.append(nvp.name);
        if (namePostfix!=null) rv.append(namePostfix);
        if (nvSeperator!=null) rv.append(nvSeperator);
        if (valuePrefix!=null) rv.append(valuePrefix);
        rv.append(nvp.value);
        if (valuePostfix!=null) rv.append(valuePostfix);
      }
    }

    return ( rv.toString() );
  }
}
