package com.wm.corelib.util;

public class ClassLineage {

    public static void whence( Class c ) {

        System.out.println("\n*********>>>>>>>>>>>\nClass: "+c.getName());
        ClassLoader sysloader = ClassLoader.getSystemClassLoader();
        try {
            ClassLoader parent = c.getClassLoader();
            do {
                    System.out.println("  Parent Loader: "+parent.toString());
                    parent = parent.getParent();
            } while (parent!=null && parent!=sysloader);
        } catch (Exception e) {
            System.out.println("  Parent Loader: SECURITY BLOCK");
        }
        System.out.println("  SYSTEM Loader: "+sysloader.toString());
    }
}
