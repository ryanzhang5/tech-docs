package com.wm.corelib.util;

import java.io.* ;
  

/***************************
 *
 * Some handy ways to get your process ID w/o JNI
 *
 **************************/

public class UnixProcess
{  

  public static long getPID() throws Exception
  {
    String os = System.getProperty("os.name");
    if (os == null) os = "unknown";

    if (os.equals("Linux")) {
      return linuxPID();
    }

    if (os.equals("SunOS")) {
      return solarisPID();
    }

    throw new Exception("Your platform [" + os + "] is not supported");
  }  


  private static long linuxPID () throws Exception {
    byte[] buf = new byte[10];
    BufferedInputStream bis;

    bis = new BufferedInputStream(new FileInputStream("/proc/self/stat"));

    int bytesRead = bis.read(buf) ;

    String pidString = "";

    for (int i=0; i < buf.length; i++) {
      if (Character.isDigit((char)buf[i])) {
        pidString = pidString + new Character((char)buf[i]).toString();
      }
      else {
        break;
      }        
    }

    long pid = new Long(pidString).longValue();
    return pid;
  } 


  private static long solarisPID () throws Exception {
    byte[] buf = new byte[12];
    BufferedInputStream bis;

    bis = new BufferedInputStream(new FileInputStream("/proc/self/psinfo"));

    int bytesRead = bis.read(buf) ;

    int pidHi = buf[10];
    int pidLo = buf[11];
    if(pidHi < 0) pidHi += 256;
    if(pidLo < 0) pidLo += 256;

    long pid = pidHi * 256 + pidLo;
    return pid;
  } 


  public static void main(String args[]) {
    try {
      System.out.println("My process ID is " + UnixProcess.getPID());
      Thread.sleep(10000);      // give the tester time to double check the output with ps
    }
    catch (Throwable t) {
      t.printStackTrace();
    }
  }

}
