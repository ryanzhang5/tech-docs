package com.wm.corelib.util;

import com.wm.corelib.dbc.Assert;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.Collection;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;
import java.util.Hashtable;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
  

public class StringUtil 
{
  public static final String NL = System.getProperty( "line.separator" );
  public static final String BLANK_STRING = "";
  public static final String[] EMPTY_STRING_ARRAY = new String[0];

  /** 
   * If s != null returns s.trim(); otherwise returns BLANK_STRING 
   **/
  public static String getNonNull(String s) 
  {
    return (s == null) ? BLANK_STRING : s.trim();
  }

  /**
    returns non-null substring of s no longer than maxLength
   **/
  public static String getNonNull( String s, int maxLength )
  {
    String rv = getNonNull( s );
    if ( rv.length() > maxLength )
      rv = rv.substring( 0, maxLength );
    return rv;
  }

  /** If s != null returns s otherwise returns BLANK_STRING */
  public static String getNonNullTrimmed(String s) 
  {
    return (s == null) ? "" : s.trim();
  }

  public static String getNonBlank(String input)
  {
    return getNonBlank( input, BLANK_STRING );
  }

  /** If input is not null and is not empty string returns input, otherwise returns def. */
  public static String getNonBlank(String input, String def) {
    String t = getNonNull(input).trim();
    return (t.length() == 0) ? def : input;
  }

  /**
   * @return true if s is null or whitespace only.
   */
  public static boolean isBlank( String s )
  {
    return s == null || BLANK_STRING.equals( s.trim() );
  }

  /**
   * @return true if s is non-null and contains something other than whitespace.
   */
  public static boolean isNonBlank( String s )
  {
    return ! isBlank( s );
  }

  /**
   * Removes a char from a string.
   */
  public static String stripChar(String in, char strip)
  {
    if(in == null) return "";

    StringBuffer out = new StringBuffer();
    for( int i=0; i < in.length(); i++ )
    {
      char c = in.charAt( i );
      if ( c == strip )
        continue;
      out.append( c );
    }
    return out.toString();
  }

  /**
   * returns String contaning all digits (0-9) in s in the same order Never returns null.
   * E.g. s = "123-456.78" returns "12345678"
   */
  public static String parseDigits(String s) 
  {
    String       in = getNonNull(s);
    StringBuffer rv = new StringBuffer(BLANK_STRING);
    for (int i = 0; i < in.length(); i++) 
    {
      char c = in.charAt(i);
      if ( Character.isDigit( c ) )
        rv.append(c);
    }
    return rv.toString();
  }
  
  /*
   ** Is the input string made only of digits.
   */
  public static boolean isPureDigit(String s) 
  {
    if ( s == null || s.length() == 0) return false;
    for ( int i = 0; i < s.length(); i++ )
    {
      char c = s.charAt(i);
      if ( !Character.isDigit(c) )
        return false;
    }
    return true;
  }
  
  /*
   ** Is the input string Hexadecimal.
   */
  public static boolean isHex(String s) 
  {
    if (s == null || s.length() == 0) return false; 
    for (int i = 0; i < s.length(); i++ )
    {
      if ( ! isHexChar( s.charAt( i ) ) )
        return false;
    }
    return true;
  }

  public static boolean isHexChar( char c )
  {
    return Character.isDigit( c )   || 
           ( c >= 'A' && c <= 'F' ) || 
           ( c >= 'a' && c <= 'f' );
  }
  
  /**
   * Strips ALL whitespace out of a string.
   */
  public static String stripWhitespace(String s) 
  {
    String in = getNonNull(s);
    StringBuffer rv = new StringBuffer(BLANK_STRING);
    for (int i = 0; i < in.length(); i++) {
      char c = in.charAt(i);
      if (! Character.isWhitespace(c))
        rv.append(c);
    }
    return rv.toString();
  }

  /**
    returns true if at least one element of vals array equals to v.
    returns false otherwise.
    All null references are converted to empty strings.
   **/
  public static boolean contains( String vals[], String v )
  {
    if ( vals == null ) return false;
  
    String tmp = StringUtil.getNonNull( v );
    for ( int i = 0; i < vals.length; i++)
    {
      if ( StringUtil.getNonNull( vals[i] ).equals( tmp ) )
        return true;
    }
    return false;
  }
  
  /**
   * Splits out a string into tokens, convenience wrapper for
   * java.util.StringTokenizer.  To use the default delimiter set,
   * set delimiter to <code>null</code> or an emtpy string.
   *
   * @see java.util.StringTokenizer
   */
  public static String[] getTokens( String val, String delimiter ) 
  {
    ArrayList tokenList = new ArrayList();
  
    if ( val != null && val.length() > 0 ) {
      StringTokenizer st = null;
      if ( StringUtil.getNonNull( delimiter ).length() > 0 ) {
        st = new StringTokenizer( val, delimiter );
      } else {
        st = new StringTokenizer( val );
      }
      while ( st.hasMoreTokens() ) {
        tokenList.add( st.nextToken() );
      }
    }
  
    String[] tokens = new String[ tokenList.size() ];
    tokenList.toArray( tokens );
  
    return ( tokens );
  }
  
  /**
   *   Splits out a string into *unique*, nonempty, trimmed 
   *   tokens.  Preserves the order of distinct tokens from
   *   the original string.  If delimiter is null or empty,
   *   uses the default StringTokenizer delimiters.  Never
   *   returns null, but may return a zero-length array.
   */
  public static String[] getUniqueNonemptyTrimmedTokens(String val, String delimiter)
  {
    ArrayList tokenList = new ArrayList();
  
    if ( val != null && val.length() > 0 ) 
    {
      StringTokenizer st = null;
      Hashtable parsedSet = new Hashtable();
      if ( StringUtil.getNonNull( delimiter ).length() > 0 ) 
      {
        st = new StringTokenizer( val, delimiter );
      } 
      else 
      {
        st = new StringTokenizer( val );
      }
      while ( st.hasMoreTokens() ) 
      {
        String t = st.nextToken();
        if (!t.equals("") && (null==parsedSet.put(t,t)))
        {
          tokenList.add( t );
        }
      }
    }
    String[] tokens = new String[ tokenList.size() ];
    tokenList.toArray( tokens );
    return ( tokens );
  }
  
  /**
   * Prints out an array of strings with <code>delimiter</code>
   * as a delimiter, or a comma if <code>delimiter</code> is null.
   * <p>
   * Postcondition: never returns null.
   */
  public static String toString( String[] arr, String delimiter ) 
  {
    StringBuffer rv = new StringBuffer();
    if ( arr != null && arr.length > 0 ) {
      String dlm = delimiter == null ? "," : delimiter;
      for ( int pos = 0; pos < arr.length; ++pos ) {
        // Append the delimiter if we are appending to something
        if ( rv.length() > 0 ) rv.append( dlm );
        rv.append( arr[ pos ] );
      }
    }
    Assert.post( rv != null );
    return( rv.toString() );
  }
  

  //////////////////////////////////////////////////////////
  // Begin pattern matching stuff
  //////////////////////////////////////////////////////////

  //////////////////////////////////////////////////////////
  // End pattern matching stuff
  //////////////////////////////////////////////////////////

  //////////////////////////////////////////////////////////
  // Begin compression stuff
  //////////////////////////////////////////////////////////

  /**
   * Compresses a string, returns null if given null as input,
   * otherwise returns non-null.  This is only good for LONG
   * strings, since it has to hex encode the output (thus
   * making the resulting string twice as long as the number
   * of compressed bytes) to avoid annoying java
   * too-many-string-encodings problems when trying to deal
   * with bytes and strings.
   */
// public static String compress( String input ) {
//   if ( input == null ) {
//     return ( null );
//   }
//   byte[] inBytes = input.getBytes();
//   byte[] outBytes = new byte[1024];
//   StringBuffer rv = new StringBuffer();
//
//   // Use the java.util.zip.Deflater class to compress our data
//   Deflater def = new Deflater( java.util.zip.Deflater.BEST_COMPRESSION );
//   def.setInput( inBytes );
//
//   int bytesCompressed = 0;
//   while ( ! def.finished() ) {
//     bytesCompressed = def.deflate( outBytes );
//     rv.append( bytesToHexString( outBytes, 0, bytesCompressed ) );
//     if ( def.needsInput() ) {
//       def.finish();
//     }
//   }
//
//   Assert.post( rv != null && rv.toString() != null );
//   return ( rv.toString() );
// }
//
  /**
   * Uncompresses a string, returns null if given null as input,
   * otherwise returns non-null.  This assumes that they input
   * came from the compress() method, if not you are on your own.
   */
// public static String uncompress( String input )
//   throws DataFormatException
//   {
//     if ( input == null ) {
//       return ( null );
//     }
//     byte[] inBytes = hexStringToBytes( input );
//     byte[] outBytes = new byte[1024];
//     StringBuffer rv = new StringBuffer();
//
//     // Use the java.util.zip.Inflater class to uncompress our data
//     Inflater inf = new Inflater();
//     inf.setInput( inBytes );
//
//     int bytesUnCompressed = 0;
//     while ( ! inf.finished() ) {
//       bytesUnCompressed = inf.inflate( outBytes );
//       rv.append( new String( outBytes, 0, bytesUnCompressed ) );
//     }
//
//     Assert.post( rv != null && rv.toString() != null );
//     return ( rv.toString() );
//   }
//
  //////////////////////////////////////////////////////////
  // End compression stuff
  //////////////////////////////////////////////////////////

  //////////////////////////////////////////////////////////
  // Begin byte/String conversion stuff
  //////////////////////////////////////////////////////////

  /**
   * Wrapper for bytesToHexString( byte[], int, int).
   * <p>
   * Precondition: input is non-null.
   */
  public static String bytesToHexString( byte[] in ) 
  {
    Assert.pre( in != null );
    return ( bytesToHexString( in, 0, in.length ) );
  }
  
  /**
   * Converts raw bytes into a printable string.
   * <p>
   * Precondition: input is non-null.<br>
   * Precondition: index is greater than or equal to zero.<br>
   * Precondition: (index + length) is less than or equal to input.length.<br>
   * Postcondition: return value is non-null.
   */
  public static String bytesToHexString( byte[] in, int index, int length ) 
  {
    Assert.pre( in != null );
    Assert.pre( index >= 0 );
    Assert.pre( (index + length) <= in.length );
    StringBuffer sb = new StringBuffer();
    for( int i = index; i < index + length; ++i ) {
        sb.append( byteToHex( in[i] ) );
    }
    Assert.post( sb.toString() != null );
    return ( sb.toString() );
  }

  /**
   * Converts a byte into a printable string.
   */
  public static String byteToHex( byte in )
  {
      StringBuffer buf = new StringBuffer();
      byte leading  = (byte) ((in>>>4) & 0x0f);
      byte trailing = (byte) (in & 0x0f);
      buf.append( (0 <= leading) && (leading <= 9) ? (char)('0' + leading) : (char)('a' + (leading - 10) ) );
      buf.append( (0 <= trailing) && (trailing <= 9) ? (char)('0' + trailing) : (char)('a' + (trailing - 10) ) );
      return buf.toString();
  }

  /**
   * Converts a hex string (presumably from bytesToHexString())
   * to a raw byte array.
   * <p>
   * Precondition: input string is non-null.<br>
   * Postcondition: return value is non-null (but may be zero length).
   */
  public static byte[] hexStringToBytes( String in ) 
  {
    Assert.pre( in != null );
    int  len   = in.length();
    byte out[] = new byte[len/2];
    int i,y;
    for(i = 0, y = 0; i < len; i+=2, ++y ) {
      out[y] = Byte.parseByte( in.substring( i, i + 2 ), 16 );
    }
    Assert.post( out != null );
    return ( out );
  }
  
  public static String addPadding( String in, int maxLen, String padStr, boolean addPrefix )
  {
    Assert.pre( in != null );
    Assert.pre( maxLen >= 0 );
    Assert.pre( padStr != null );

    if ( in.length() >= maxLen )
      return in;

    while ( in.length() < maxLen ) {
      if ( addPrefix ) {
        in = padStr + in;
      }
      else {
        in = in + padStr;
      }
    }
    return in;
  }


  public static String toString( Object sos[] )
  {
    if ( sos == null ) return "null";
    String rv = sos.getClass().getName() + ".length=" + sos.length + "\n{\n";
    for ( int i = 0; i < sos.length; i++ )
      rv += "" + i + " ->\n{" + sos[i] + "\n}\n";
    rv += "}\n";
    return rv;
  }
  
  public static String toString( Collection coll )
  {
    return toString( coll.toArray() );
  }
  
  //////////////////////////////////////////////////////////
  // End byte/String conversion stuff
  //////////////////////////////////////////////////////////

  //////////////////////////////////////////////////////////
  // Begin pattern matching stuff
  //////////////////////////////////////////////////////////

  /**
   * Searches <code>input</code>, and replaces all occurences of the Perl5 regular
   * expression <code>pattern</code> with the Perl5 regular expression
   * <code>substitution</code>.
   * <p>
   * Precondition: <code>input</code>, <code>pattern</code> and <code>substitution</code>
   *               are all non-null.
   *
   * @return String with substitutions, or <code>null</code> if error (bad pattern, for
   *         example).
   */
  public static String replace( String input, String pattern, String substitution ) {
    Assert.pre( input        != null );
    Assert.pre( pattern      != null );
    Assert.pre( substitution != null );
    String rv = null;
    try 
    {
      Pattern p = Pattern.compile( pattern );
      Matcher m = p.matcher( input );
      rv = m.replaceAll( substitution );
    } 
    catch ( Exception e ) 
    {
      rv = null;
    }
    return rv;
  }
  //////////////////////////////////////////////////////////
  // End pattern matching stuff
  //////////////////////////////////////////////////////////
  //
  public static void main( String args[] )
  {
    String input   = "ababababab";
    String token   = "acacacacac";
    String pattern = "b";
    String sub     = "c";
    String out     = StringUtil.replace( input, pattern, sub );
    System.out.println( "input  = " + input );
    System.out.println( "output = " + out   );
    System.out.println( "pass = " + (token.equals( out ) ) );
  }

}
