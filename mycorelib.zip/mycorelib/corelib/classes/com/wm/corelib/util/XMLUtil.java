package com.wm.corelib.util;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.xml.serialize.Method;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;
  
/**
 * XML utility class -- right now it provides java support for
 * passing name/value pairs (intended for use in IPC) as XML
 * data in the "standard" corelib format, defined in nvpair.dtd.
 *
 * There are corresponding XML utility classes/methods in the
 * c++ corelib source code for doing the same thing -- so if you
 * make DTD changes (which you really shouldn't without good reason)
 * make sure you update the c++ source as well.  This is needed for
 * wm.com programs written in different languages to communicate
 * with XML (initially used in bedrock for c++ and java programs
 * to communicate easily through IBM MQSeries).
 */
public class XMLUtil
{
    static String DOCUMENT_ELEMENT = "nvpair";
    static String NAME_ELEMENT     = "name";
    static String VALUE_ELEMENT    = "value";
    static OutputFormat XML_FORMAT = new OutputFormat( Method.XML, "UTF-8", false );
    static DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();

    // In case a SAX driver (which is required for this class to work) is
    // not present in the calling application, we try to use xerces as a default
    static String SAX_DRIVER_KEY = "org.xml.sax.driver";
    static String DEFAULT_SAX_DRIVER = "org.apache.xerces.parsers.SAXParser";
    static {
        String driver = System.getProperty( SAX_DRIVER_KEY );
        if ( driver == null ) {
            System.setProperty( SAX_DRIVER_KEY, DEFAULT_SAX_DRIVER );
        }
    }

    /**
     * Should not be instantiated.
     */
    private XMLUtil()
    {
    }

    /**
     * Parses XML data (assume to be name/value pairs)
     * from the given input source.
     */
    public static NVPair[] load( InputSource xmlSource )
    throws SAXException, IOException
    {
        XMLReader xmlReader = XMLReaderFactory.createXMLReader();
        XMLNameValueParser xmlParser = new XMLNameValueParser();
        xmlReader.setContentHandler( xmlParser );
        xmlReader.setDTDHandler( xmlParser );
        xmlReader.setEntityResolver( xmlParser );
        xmlReader.setErrorHandler( xmlParser );
        xmlReader.parse( xmlSource );
        return xmlParser.getNVPairs();
    }

    /**
     * Parses the given string as XML data containing
     * name/value pairs.
     */
    public static NVPair[] load( String xmlData, boolean throwExceptionOnError )
    throws SAXException, IOException
    {
        return load( new InputSource( new ByteArrayInputStream( xmlData.getBytes() ) ) );
    }

    /**
     * Parses the given string as XML data containing
     * name/value pairs, on exception returns an empty array.
     */
    public static NVPair[] load( String xmlData )
    {
        NVPair[] rv = null;
        try {
            rv = load( xmlData, true );
        } catch ( Throwable t ) {
            rv = new NVPair[0];
        }
        return rv;
    }

    /**
     * Parses the given file as XML name/value pair data.
     */
    public static NVPair[] load( File xmlFile, boolean throwExceptionOnError )
    throws FileNotFoundException, SAXException, IOException
    {
        return load( new InputSource( new FileInputStream( xmlFile ) ) );
    }

    /**
     * Parses the given file as XML name/value pair data, on exception
     * returns an empty array.
     */
    public static NVPair[] load( File xmlFile )
    {
        NVPair[] rv = null;
        try {
            rv = load( xmlFile, true );
        } catch ( Throwable t ) {
            rv = new NVPair[0];
        }
        return rv;
    }

    /**
     * Parses the given InputStream as XML name/value pair data.
     */
    public static NVPair[] load( InputStream stream, boolean throwExceptionOnError )
    throws SAXException, IOException
    {
        return load( new InputSource( stream ) );
    }

    /**
     * Parses the given InputStream as XML name/value pair data, on exception
     * returns an empty array.
     */
    public static NVPair[] load( InputStream stream )
    {
        NVPair[] rv = null;
        try {
            rv = load( stream, true );
        } catch ( Throwable t ) {
            rv = new NVPair[0];
        }
        return rv;
    }

    /**
     * Writes the NVPair array as an XML stream to the give writer.
     */
    public static void store( NVPair[] pairs, OutputStream oStream )
    throws IOException
    {
        if ( pairs == null || oStream == null ) {
            return;
        }
        PrintWriter pw = new PrintWriter( oStream );
        store( pairs, pw );
        pw.close();
    }

    /**
     * Writes the NVPair array as an XML stream to the give writer.
     */
    public static void store( NVPair[] pairs, Writer writer )
    throws IOException
    {
        if ( pairs == null || writer == null ) {
            return;
        }
        DocumentBuilder docBuilder = null;
        try {
            docBuilder = docBuilderFactory.newDocumentBuilder();
        } catch ( ParserConfigurationException pcf ) {
            IOException parserExc = new IOException( "Could not create DOM document builder" );
            parserExc.initCause( pcf );
            throw parserExc;
        }
        Document document = docBuilder.newDocument();
        Element rootElement = document.createElement( DOCUMENT_ELEMENT );
        Element tmpElem = null;
        for ( int pos = 0; pos < pairs.length; ++pos ) {
            // Name
            tmpElem = document.createElement( NAME_ELEMENT );
            tmpElem.appendChild( document.createTextNode(
                        pairs[pos].name != null ? pairs[pos].name : StringUtil.BLANK_STRING ) );
            rootElement.appendChild( tmpElem );

            // Value
            tmpElem = document.createElement( VALUE_ELEMENT );
            tmpElem.appendChild( document.createTextNode(
                        pairs[pos].value != null ? pairs[pos].value : StringUtil.BLANK_STRING ) );
            rootElement.appendChild( tmpElem );
            tmpElem = null;
        }
        document.appendChild( rootElement );
        XMLSerializer xmlSerializer = new XMLSerializer( writer, XML_FORMAT );
        xmlSerializer.asDOMSerializer();
        xmlSerializer.serialize( document.getDocumentElement() );
        writer.flush();
    }

    /**
     * Unit test, parses stdin and prints out the name/value pairs.
     */
    public static void main( String[] args )
    throws Exception
    {
        NVPair[] pairs = load( System.in, true );
        System.out.println();
        System.out.println( "Pairs:" );
        System.out.println( NVPair.toString( pairs, "\t[", "", "/", "", "]", "\n" ) );
        System.out.println();
        System.out.println( "Pairs as XML:" );
        store( pairs, System.out );
    }
}

/**
 * SAX2 name/value XML parser.
 */
class XMLNameValueParser
extends DefaultHandler
{
    private String currentElement;
    private StringBuffer currentName;
    private StringBuffer currentValue;
    private ArrayList pairs;

    public XMLNameValueParser()
    {
        super();
        currentElement = StringUtil.BLANK_STRING;
        currentName = new StringBuffer();
        currentValue = new StringBuffer();
        pairs = new ArrayList();
    }

    /**
     * @return any name/value pairs that were parsed, never returns null.
     */
    public NVPair[] getNVPairs()
    {
        NVPair[] rv = new NVPair[ pairs.size() ];
        pairs.toArray( rv );
        return rv;
    }

    public void startDocument()
    {
        pairs = new ArrayList();
    }

    public void startElement( String uri, String localName,
            String qName, Attributes attributes )
    {
        currentElement = qName;
        if ( currentElement != null && XMLUtil.NAME_ELEMENT.equals( currentElement ) ) {
            currentName.delete( 0, currentName.length() );
        } else if ( currentElement != null && XMLUtil.VALUE_ELEMENT.equals( currentElement ) ) {
            currentValue.delete( 0, currentValue.length() );
        }
    }

    /**
     * If we are at the end of a &lt;value&gt; tag, add the name/value
     * pair to the container.
     */
    public void endElement( String uri, String localName, String qName )
    {
        if ( qName != null && XMLUtil.VALUE_ELEMENT.equals( qName ) ) {
            pairs.add( new NVPair( currentName.toString(),
                        currentValue.toString() ) );
        }
        currentElement = StringUtil.BLANK_STRING;
    }

    /**
     * Append the characters to the appropriate state data variable.
     */
    public void characters( char[] ch, int start, int length )
    {
        if ( currentElement != null && XMLUtil.NAME_ELEMENT.equals( currentElement ) ) {
            currentName.append( ch, start, length );
        } else if ( currentElement != null &&
                XMLUtil.VALUE_ELEMENT.equals( currentElement ) ) {
            currentValue.append( ch, start, length );
        }
    }
}
