
package com.wm.corelib.util;

import java.util.*;
import java.io.*;


/**
*  Class to support functionality similar to the Java
*  compiler's:  if you have a list of "import" statements
*    <blockquote>
*        import java.util.*;
*        import java.io.IOException;
*        import com.myCompany.junk.*;
*    </blockquote>
*  then, given a class name, you wish to resolve it into
*  a real class.  
*  <p>
*  To use this class, feed it the strings "java.util.*" etc.,
*  and then use one of "resolve" methods to look up your class.
*  <p>
*  Note that the list of imports is not ordered; none of the
*  imports have priority over the others.  When resolving a class,
*  the *entire* list of imports is tested against the input string;
*  this is to make sure that ambiguous references are caught.
*  <p>
*  The default classloader is used.  The input names are cached
*  so that successive lookups are faster.
*  <p> 
*  This class is not synchronized for multithreading.
**/

public class ImportList 
{
  private HashMap cache = new HashMap();
  private HashSet imports = new HashSet();
  
  public void addImports(String imp)
  {
    cache.clear();
    if (imp==null) return;
    StringTokenizer st = new StringTokenizer(imp,",");
    while (st.hasMoreTokens())
    {
      imports.add(st.nextToken().trim());
    }
  }
  
  /**
  *   Return the class defined by the abbreviated class name
  *   and the list of imports.  
  *   @return Class object, or null if the class can't be found.
  *   @throws ResolveException if more than one class was
  *   found.
  */
  public Class resolveClass(String abbreviatedClassName) throws ResolveException
  { 
    if (!cache.containsKey(abbreviatedClassName)) computeAndCache(abbreviatedClassName);
    Object result = cache.get(abbreviatedClassName);
    if (result instanceof ResolveException) throw (ResolveException)result;
    return (Class)result;
  }
  
  /**
  *   Return the name of the class defined by the abbreviated class name
  *   and the list of imports.  
  *   @return full name of the class, or null if the class can't be found.
  *   @throws ResolveException if more than one class was
  *   found.
  */
  public String resolveClassName(String abbreviatedClassName)
  throws ResolveException
  {
    Class c = resolveClass(abbreviatedClassName);
    return (c==null ? null : c.getName());
  }
  
  /**
  *   Return an instance of the class defined by the abbreviated class name
  *   and the list of imports.  
  *   @return full name of the class, or null if the class can't be found.
  *   @throws ResolveException if more than one class was
  *   found, or an error occurred during instantiation.
  *   @throws 
  */
  public Object resolveNewInstance(String abbreviatedClassName)
  throws ResolveException
  {
    Class c = resolveClass(abbreviatedClassName);
    try { return (c==null ? null : c.newInstance()); }
    catch (Exception e) {throw new ResolveException(e);}
  }
  
  /**
  *   To make the ImportList class easier to use, it only
  *   throws one kind of exception, no matter what the
  *   problem was (ambiguous reference, instantiation exception, 
  *   various runtime exceptions, etc.)
  *
  *   If you really care what the original exception was
  *   (for debugging purposes) you can use getCause().
  */
  public class ResolveException extends Exception
  {
    public ResolveException( Exception cause ) 
    {
      super();
      initCause(cause);
    }
    public ResolveException (String message)
    {
      super(message);
    }
    
    /* ***************************************
    **  ALL OF THE FOLLOWING CODE CAN BE DELETED when we migrate
    **  to Java 1.4, since 1.4 has support for chained 
    **  exceptions, including the new initCause()/getCause() methods.  See
    **  http://java.sun.com/j2se/1.4/docs/guide/lang/chained-exceptions.html
    **  http://java.sun.com/j2se/1.4/docs/api/java/lang/Throwable.html#initCause(java.lang.Throwable)
    ******************************************/
          public Throwable initCause(Throwable cause)
          {
            _cause = cause;
            return this;
          }
          public Throwable getCause()
          {
            return _cause;
          }
          public void printStackTrace() 
          {
            printStackTrace(System.err);
          }
          public void printStackTrace(PrintStream s) 
          {
            super.printStackTrace(s);
            if (_cause!=null)
            {
              s.print("Initial cause: "+_cause);
              _cause.printStackTrace( s );
            }
          }
          public void printStackTrace(PrintWriter s) 
          {
            super.printStackTrace(s);
            if (_cause!=null)
            {
              s.print("Initial cause: "+_cause);
              _cause.printStackTrace( s );
            }
          }
          public String toString() 
          {
            return super.toString() + 
              (_cause==null ? "" : _cause.toString());
          }
          private Throwable _cause;
    /** *****************************************
    **  END code which can be deleted when Java 1.4 is here
    *********************************************/

  }



  

  private void computeAndCache(String abbreviatedClassName)
  {
    HashSet results = new HashSet();

    if (abbreviatedClassName.indexOf(".")>=0)
    {
      possibleResult(abbreviatedClassName,results);
    }
    else
    {
      for (Iterator i = imports.iterator(); i.hasNext();) {
        String imp = (String)i.next();
        if (imp.endsWith(".*")) imp = imp.substring(0,imp.length()-1)+abbreviatedClassName;
        if (imp.endsWith(abbreviatedClassName)) possibleResult(imp,results);
      }
    }
    Object result;
    if (results.size()==0)     result = null;
    else if (results.size()>1) result = new ResolveException("Ambiguous name: "+abbreviatedClassName);
    else                       result = results.iterator().next();

    cache.put(abbreviatedClassName,result);
  }

  private void possibleResult(String name, Set v)
  {
    Class c;
    try {c = Class.forName(name);}
    catch (Exception e) {return;}
    if (c!=null) v.add(c);
  }





}












