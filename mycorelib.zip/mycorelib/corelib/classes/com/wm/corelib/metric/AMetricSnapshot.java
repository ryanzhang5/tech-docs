package com.wm.corelib.metric;

import java.io.Serializable;

/**
 * A momentary view of current values of a metric to support those metrics with
 * composite states. In effect this encapsulates the data from a metric frozen
 * in time.
 * 
 * <p>
 * Snapshots also support aggregation with data from another snapshot of the
 * same type, such as overlaying data from overlapping time intervals.
 */
public abstract class AMetricSnapshot implements Serializable, Cloneable
{
    private final String m_id;

    AMetricSnapshot(String id)
    {
        this.m_id = id;
    }

    public final String getId()
    {
        return this.m_id;
    }

    public abstract void aggregate(AMetricSnapshot other);

    public abstract String fieldsToString();

    @Override
    public final String toString()
    {
        return "<" + getClass().getSimpleName() + ": id=" + m_id + " " + fieldsToString() + ">";
    }
}
