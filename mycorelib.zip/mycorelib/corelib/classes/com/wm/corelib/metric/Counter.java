package com.wm.corelib.metric;

import java.util.concurrent.atomic.AtomicLong;

/**
 * Simple counter implementation. Each successive value change is based on
 * previous value of counter, though typical usage is to monotonously increase
 * the value.
 */
public class Counter extends AMetric
{
    private final long m_initialValue;
    private final AtomicLong m_value;

    public Counter(String id)
    {
        this(id, 0L, false);
    }

    public Counter(String id, boolean isCumulative)
    {
        this(id, 0L, isCumulative);
    }

    public Counter(String id, long initialValue)
    {
        this(id, initialValue, false);
    }

    public Counter(String id, long initialValue, boolean isCumulative)
    {
        super(id, isCumulative);
        m_initialValue = initialValue;
        m_value = new AtomicLong(initialValue);
    }

    public long increment()
    {
        return m_value.incrementAndGet();
    }

    public long increment(long value)
    {
        return m_value.addAndGet(value);
    }

    public long decrement()
    {
        return m_value.decrementAndGet();
    }

    public long decrement(long value)
    {
        return m_value.addAndGet(-value);
    }

    public long getValue()
    {
        return m_value.get();
    }

    @Override
    protected void reset()
    {
        m_value.set(m_initialValue);
    }

    @Override
    public boolean isUpdated()
    {
        return m_value.get() != m_initialValue;
    }

    @Override
    public String fieldsToString()
    {
        return "value=" + m_value.get();
    }

    @Override
    public CounterSnapshot takeSnapshot(boolean reset)
    {
        CounterSnapshot css = new CounterSnapshot(getId(), m_value.get());
        if (reset) initialize();
        return css;
    }
}
