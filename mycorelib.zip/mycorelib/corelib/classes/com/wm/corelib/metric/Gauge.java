package com.wm.corelib.metric;

/**
 * Gauges are metrics whose values can fluctuate, e.g. car speedometer. It keeps
 * track of min/max values since last reset, current measurement, and total
 * count of all value changes.
 */
public class Gauge extends AMetric
{
    private long m_value;
    private long m_max;
    private long m_min;
    private long m_changeCt;

    public Gauge(String id)
    {
        this(id, false);
    }

    public Gauge(String id, long value)
    {
        this(id, value, false);
    }

    public Gauge(String id, boolean isCumulative)
    {
        super(id, isCumulative);
        m_value = 0;
        m_changeCt = 0;
        m_max = Long.MIN_VALUE;
        m_min = Long.MAX_VALUE;
    }

    public Gauge(String id, long value, boolean isCumulative)
    {
        super(id, isCumulative);
        m_value = m_min = m_max = value;
        m_changeCt = 0;
    }

    @Override
    public synchronized GaugeSnapshot takeSnapshot(boolean reset)
    {
        GaugeSnapshot gss = new GaugeSnapshot(getId(), m_min, m_max, m_value, m_changeCt);
        if (reset) initialize();
        return gss;
    }

    /**
     * Resets min, max and change count values to that of the current gauge
     * value. This can be thought of as resetting the range of recorded values
     * for the gauge.
     */
    @Override
    protected synchronized void reset()
    {
        if (m_min > m_max) return;
        m_min = m_max = m_value;
        m_changeCt = 0;
    }

    @Override
    public synchronized boolean isUpdated()
    {
        return m_changeCt > 0;
    }

    @Override
    public synchronized String fieldsToString()
    {
        return "value=" + m_value + " min=" + m_min + " max=" + m_max + " changes=" + m_changeCt;
    }

    /**
     * @return current value of gauge
     */
    public synchronized long getValue()
    {
        return m_value;
    }

    public synchronized long getMinValue()
    {
        return m_min;
    }

    public synchronized long getMaxValue()
    {
        return m_max;
    }

    public synchronized long getChangeCount()
    {
        return m_changeCt;
    }

    public long increment()
    {
        return increment(1);
    }

    public long increment(long value)
    {
        if (value < 0) return decrement(-value);
        synchronized (this)
        {
            if (value == 0) return m_value;
            m_value += value;
            if (m_min == Long.MAX_VALUE) m_min = m_value;
            if (m_value > m_max) m_max = m_value;
            m_changeCt++;
        }
        return m_value;
    }

    public long decrement()
    {
        return decrement(1);
    }

    public long decrement(long value)
    {
        // do this b/c otherwise max may not be set,
        // i.e. if we start with m_value = 0, then call
        // decrement(-10), decrement(-5) should result in:
        // m_value = 15, m_max = 15, m_min = 10
        if (value < 0) return increment(-value);
        synchronized (this)
        {
            if (value == 0L) return m_value;
            m_value -= value;
            if (m_max == Long.MIN_VALUE) m_max = m_value;
            if (m_value < m_min) m_min = m_value;
            m_changeCt++;
        }
        return m_value;
    }

    /**
     * Set current value to specified.
     * 
     * @param newVal
     * @return previous value of gauge, or newVal if they are equal
     */
    public synchronized long set(long newVal)
    {
        if (newVal == m_value) return newVal;
        long oldValue = m_value;
        if (newVal > m_max) m_max = newVal;
        if (newVal < m_min) m_min = newVal;
        m_value = newVal;
        m_changeCt++;
        return oldValue;
    }

}
