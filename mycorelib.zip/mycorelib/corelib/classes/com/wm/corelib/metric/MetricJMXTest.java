package com.wm.corelib.metric;

import java.util.Calendar;
import java.util.Locale;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import com.wm.corelib.metric.jmx.MetricMBeanAdaptor;

public final class MetricJMXTest
{
    private final static IMetricRegistry s_reg = MetricRegistryFactory.get();
    private final static String ASC_COUNTER_NAME = "AscCounter";
    private final static String DESC_COUNTER_NAME = "DescCounter";
    private final static String TIMING_NAME = "ElapsedTime";

    private final static String s_CounterNames[] = { ASC_COUNTER_NAME, DESC_COUNTER_NAME };

    private final static String s_TimingNames[] = { TIMING_NAME };

    private final static String s_GaugeNames[] = {};

    private final static Random s_rand = new Random();

    private final MetricContainer m_myStats;
    private final Counter m_ascCt, m_descCt;
    private final Timing m_timeMetric;

    private MetricJMXTest(String instId)
    {
        m_myStats = s_reg.get(MetricJMXTest.class, null, instId, true);
        m_ascCt = m_myStats.getCounter(ASC_COUNTER_NAME);
        m_descCt = m_myStats.getCounter(DESC_COUNTER_NAME);
        m_timeMetric = m_myStats.getTime(TIMING_NAME);

        Timer metricTimer = new Timer("MetricUpdater", true);
        metricTimer.scheduleAtFixedRate(new TimerTask()
        {
            @Override
            public void run()
            {
                m_ascCt.increment();
                m_descCt.decrement();
            }
        }, 10, 10000);

        metricTimer.scheduleAtFixedRate(new TimerTask()
        {
            @Override
            public void run()
            {
                m_timeMetric.add(s_rand.nextInt(100));
            }
        }, 5, 5000);

        metricTimer.scheduleAtFixedRate(new TimerTask()
        {
            @Override
            public void run()
            {
                m_ascCt.reset();
                m_descCt.reset();
                m_timeMetric.reset();
            }
        }, 60000, 60000);
    }

    /**
     * @param args
     */
    public static void main(String[] args) throws Exception
    {
        MetricJMXTest obj = new MetricJMXTest(Calendar.getInstance().getDisplayName(
                Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.US));
        MetricMBeanAdaptor.createModelMBean(obj.m_myStats);
        System.out.println("Connect now with JConsole.");
        synchronized (obj)
        {
            try
            {
                obj.wait();
            } catch (InterruptedException e)
            {
                e.printStackTrace();
            }
        }
    }

}
