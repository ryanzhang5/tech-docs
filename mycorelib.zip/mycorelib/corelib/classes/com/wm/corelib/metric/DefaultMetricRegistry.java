package com.wm.corelib.metric;

import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.google.common.base.Strings;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

final class DefaultMetricRegistry implements IMetricRegistry
{
    private static final Logger s_log;
    private static final DefaultMetricRegistry s_inst;
    private final ConcurrentMap<String, InstanceGroup> m_groups;
    private final Set<MetricMetaDataListener> m_metaDataListeners;
    private final MetricMetaDataListener m_statLsnr;

    public static DefaultMetricRegistry getDefault()
    {
        return s_inst;
    }

    DefaultMetricRegistry(Properties props)
    {
        m_groups = Maps.newConcurrentMap();
        m_metaDataListeners = new CopyOnWriteArraySet<MetricMetaDataListener>();
        m_statLsnr = new MetricMetaDataListener()
        {
            @Override
            public void metricAdded(MetricMetaData md)
            {
                for (MetricMetaDataListener lsnr : m_metaDataListeners)
                    lsnr.metricAdded(md);
            }

            @Override
            public void metricRemoved(MetricMetaData md)
            {
                for (MetricMetaDataListener lsnr : m_metaDataListeners)
                    lsnr.metricRemoved(md);
            }

            @Override
            public void containerAdded(MetricContainer cont)
            {
                for (MetricMetaDataListener lsnr : m_metaDataListeners)
                    lsnr.containerAdded(cont);
            }

            @Override
            public void containerRemoved(MetricContainer cont)
            {
                for (MetricMetaDataListener lsnr : m_metaDataListeners)
                    lsnr.containerRemoved(cont);
            }

        };
    }

    @Override
    public void addMetaDataListener(MetricMetaDataListener listener)
    {
        if (m_metaDataListeners.add(listener)) return;
        s_log.log(Level.WARNING, "metadata listener already added: " + listener,
                new IllegalStateException());
    }

    @Override
    public void removeMetaDataListener(MetricMetaDataListener listener)
    {
        if (m_metaDataListeners.remove(listener)) return;
        s_log.log(Level.WARNING, "metadata listener to remove not found: " + listener,
                new IllegalStateException());
    }

    @Override
    public MetricContainer get(Class<?> parentClass)
    {
        return get(parentClass, null);
    }

    @Override
    public MetricContainer get(Class<?> parentClass, String name)
    {
        return get(parentClass, name, null, true);
    }

    @Override
    public MetricContainer get(Class<?> parentClass, String subName, String instanceId,
            boolean createIfNotFound)
    {
        assert ((parentClass != null) || (!(Strings.isNullOrEmpty(subName))));
        InstanceGroup group = getGroup(parentClass, subName, createIfNotFound);
        return ((group != null) ? group.getInstance(instanceId, createIfNotFound) : null);
    }

    @Override
    public ImmutableList<MetricContainer> getContainers(Class<?> parent, String name)
    {
        InstanceGroup group = getGroup(parent, name, false);
        return ((group != null) ? group.getInstances() : null);
    }

    @Override
    public void remove(MetricContainer cont)
    {
        InstanceGroup group = getGroup(cont.getName(), false);
        if (group == null) return;
        group.removeInstance(cont);
    }

    public List<Snapshot> takeSnapshots(boolean reset, String rootName)
    {
        return takeSnapshots(reset, rootName, true);
    }

    public List<Snapshot> takeSnapshots(boolean reset, String rootName, boolean aggregateInstances)
    {
        return takeSnapshots(reset, rootName, aggregateInstances, true);
    }

    public List<Snapshot> takeSnapshots(boolean reset, String rootName, boolean aggregateInstances,
            boolean includeUnchanged)
    {
        List<Snapshot> sss = Lists.<Snapshot> newLinkedList();
        for (InstanceGroup group : m_groups.values())
        {
            if ((rootName == null) || (group.name().startsWith(rootName)))
                group.addAllSnapshots(sss, reset, aggregateInstances, includeUnchanged);
        }

        return sss;
    }

    private InstanceGroup getGroup(String name, boolean createIfNotFound)
    {
        return getGroup(null, name, createIfNotFound);
    }

    private InstanceGroup getGroup(Class<?> parentClass, String subName, boolean createIfNotFound)
    {
        String name = MetricContainer.nameOf(parentClass, subName);
        InstanceGroup group = m_groups.get(name);
        if (group == null && createIfNotFound)
        {
            group = new InstanceGroup(parentClass, subName);
            InstanceGroup tmp = m_groups.putIfAbsent(name, group);
            if (tmp != null) return tmp;
        }
        return group;
    }

    static
    {
        s_log = Logger.getLogger(DefaultMetricRegistry.class.getName());

        s_inst = new DefaultMetricRegistry(System.getProperties());
    }

    private final class InstanceGroup
    {
        private final Class<?> m_parentClass;
        private final String m_subName;
        private final ConcurrentMap<String, MetricContainer> m_instances = Maps.newConcurrentMap();
        private Snapshot m_instanceHistory = null;

        InstanceGroup(Class<?> parent, String subName)
        {
            m_parentClass = parent;
            m_subName = subName;
        }

        String name()
        {
            return MetricContainer.nameOf(m_parentClass, m_subName);
        }

        MetricContainer getInstance(String instanceId, boolean createIfNotFound)
        {
            MetricContainer instance = m_instances.get(Strings.nullToEmpty(instanceId));
            if (instance == null && createIfNotFound)
            {
                instance = new MetricContainer(m_parentClass, m_subName, instanceId, m_statLsnr);
                MetricContainer tmp = m_instances.putIfAbsent(Strings.nullToEmpty(instanceId),
                        instance);
                if (tmp != null) instance = tmp;
                m_statLsnr.containerAdded(instance);
            }
            return instance;
        }

        void removeInstance(MetricContainer cont)
        {
            MetricContainer old = m_instances.remove(Strings.nullToEmpty(cont.getInstanceId()));
            if (old != null)
            {
                cont.setListener(null);
                m_statLsnr.containerRemoved(old);
            }
            synchronized (this)
            {
                if (m_instanceHistory == null)
                    m_instanceHistory = new Snapshot(name(), "<history>");
                m_instanceHistory.aggregate(cont.takeSnapshot(false));
            }
        }

        private ImmutableList<MetricContainer> getInstances()
        {
            return ImmutableList.copyOf(m_instances.values());
        }

        private void addAllSnapshots(List<Snapshot> sss, boolean reset, boolean aggregateInstances,
                boolean filterUnmodifiedStats)
        {
            List<MetricContainer> instances = getInstances();
            /*
             * if ((aggregateInstances) && (instances.size() > 1)) { Snapshot
             * aggregateSS = new Snapshot(name(), "<aggregated>"); for
             * (MetricContainer instance : instances) {
             * aggregateSS.aggregate(instance.takeSnapshot(reset,
             * filterUnmodifiedStats)); } sss.add(aggregateSS); } else { for
             * (MetricContainer instance : instances) {
             * sss.add(instance.takeSnapshot(reset, filterUnmodifiedStats)); } }
             * synchronized (this) { if (m_instanceHistory != null)
             * sss.add(m_instanceHistory.clone()); }
             */}
    }
}
