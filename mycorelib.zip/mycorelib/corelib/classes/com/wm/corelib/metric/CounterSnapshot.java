package com.wm.corelib.metric;

import java.util.concurrent.atomic.AtomicLong;

public final class CounterSnapshot extends AMetricSnapshot
{

    private final AtomicLong m_value;
    private final String m_id;

    public CounterSnapshot(String id)
    {
        this(id, 0);
    }

    public CounterSnapshot(String id, long value)
    {
        super(id);
        m_id = id;
        m_value = new AtomicLong(value);
    }

    @Override
    public void aggregate(AMetricSnapshot other)
    {
        if (!(other instanceof CounterSnapshot)) { throw new IllegalArgumentException(
                "wrong type, " + other); }
        CounterSnapshot css = (CounterSnapshot)other;
        m_value.addAndGet(css.m_value.get());
    }

    @Override
    public String fieldsToString()
    {
        return "value=" + m_value.get();
    }

    public long getValue()
    {
        return m_value.get();
    }
}
