package com.wm.corelib.metric;

/**
 * Base class for various metrics that can be collected and recorded. Subclasses
 * are encouraged but not required to be thread-safe.
 */
public abstract class AMetric
{
    /**
     * Id of the metric
     */
    private final String m_id;
    private final boolean m_isCum;

    protected AMetric(String id)
    {
        this(id, false);
    }

    /**
     * @param id
     * @param isCumulative
     *            true if metric is intended to be cumulative, i.e. never have
     *            its state affected by calls to {@link #reset()}
     */
    protected AMetric(String id, boolean isCumulative)
    {
        m_id = id;
        m_isCum = isCumulative;
    }

    public String getId()
    {
        return m_id;
    }

    public boolean isCumulative()
    {
        return m_isCum;
    }

    /**
     * Take snapshot of this metric, optionally resetting the underlying
     * value(s), as appropriate
     * 
     * @param reset
     * @return
     */
    public abstract <T extends AMetricSnapshot> T takeSnapshot(boolean reset);

    /**
     * Revert to initial state unless it is a cumulative metric
     */
    public void initialize()
    {
        if (!isCumulative()) reset();
    }

    /**
     * Unconditionally resets underlying data to initial state; exact semantics
     * specified by subclasses
     */
    protected abstract void reset();

    /**
     * @return false if this metric is in the initial state, true otherwise
     */
    public abstract boolean isUpdated();

    /**
     * @return string representation of internal data contained by this metric
     */
    public abstract String fieldsToString();

    @Override
    public final String toString()
    {
        return "<" + getClass().getSimpleName() + ": id=" + m_id + " " + fieldsToString() + ">";
    }
}
