package com.wm.corelib.metric;

import java.util.Properties;

/**
 * This API is the entry point to the metrics collection framework. Example
 * usage:
 * <p>
 * <code>
 * IMetricRegistry reg = MetricRegistryFactory.get();<br>
 * MetricContainer metrics = reg.get("MyMetrics", this.toString());<br>
 * <p>
 * metrics.incrementCounter("accessCount");
 * </code>
 */
public final class MetricRegistryFactory
{
    private static IMetricRegistry s_inst;

    /**
     * Returns instance of metric registry implementation based on system
     * properties, creating one as necessary.
     * 
     * @return
     */
    public static IMetricRegistry get()
    {
        return get(System.getProperties());
    }

    /**
     * Returns instance of metric registry implementation based on supplied
     * properties, creating one as necessary.
     * 
     * @param config
     * @return
     */
    public synchronized static IMetricRegistry get(Properties config)
    {
        if (s_inst == null)
        {
            s_inst = new DefaultMetricRegistry(config);
            initListeners(config);
        }
        return s_inst;
    }

    private static void initListeners(Properties config)
    {
        // TODO
    }
}
