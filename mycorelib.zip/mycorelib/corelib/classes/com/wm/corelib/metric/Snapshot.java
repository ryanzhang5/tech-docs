package com.wm.corelib.metric;

import java.io.Serializable;
import java.util.Map;

import com.google.common.base.Preconditions;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * Represents total of all the metric snapshots within a metric container
 */
public final class Snapshot implements Serializable, Cloneable
{
    private final String m_name;

    private final String m_instanceId;
    private long m_periodBeginTime;
    private long m_periodEndTime;
    private final Map<String, CounterSnapshot> m_counters;
    private final Map<String, GaugeSnapshot> m_gauges;
    private final Map<String, TimingSnapshot> m_times;

    public Snapshot(String name, String instanceId)

    {
        this(name, instanceId, Long.MAX_VALUE, Long.MIN_VALUE, Lists
                .<CounterSnapshot> newArrayList(), Lists.<GaugeSnapshot> newArrayList(), Lists
                .<TimingSnapshot> newArrayList());
    }

    public Snapshot(String name, String instanceId, long periodBeginTime, long periodEndTime,
            Iterable<CounterSnapshot> counters, Iterable<GaugeSnapshot> gauges,
            Iterable<TimingSnapshot> times)

    {
        Preconditions.checkNotNull(counters);
        Preconditions.checkNotNull(gauges);
        Preconditions.checkNotNull(times);
        m_name = name;
        m_instanceId = instanceId;
        m_periodBeginTime = periodBeginTime;
        m_periodEndTime = periodEndTime;
        m_counters = getMapById(counters);
        m_gauges = getMapById(gauges);
        m_times = getMapById(times);
    }

    private <T extends AMetricSnapshot> Map<String, T> getMapById(Iterable<T> snapshots)
    {
        Map<String, T> m = Maps.newTreeMap();
        for (T ms : snapshots)
        {
            m.put(ms.getId(), ms);
        }
        return m;
    }

    void aggregate(Snapshot other)
    {
        aggregateStats(this.m_counters, other.m_counters);
        aggregateStats(this.m_gauges, other.m_gauges);
        aggregateStats(this.m_times, other.m_times);
        if (other.m_periodBeginTime < this.m_periodBeginTime)
            this.m_periodBeginTime = other.m_periodBeginTime;
        if (other.m_periodEndTime <= this.m_periodEndTime) return;
        this.m_periodEndTime = other.m_periodEndTime;
    }

    private <T extends AMetricSnapshot> void aggregateStats(Map<String, T> ss1, Map<String, T> ss2)
    {
        for (T from : ss2.values())
        {
            AMetricSnapshot to = ss1.get(from.getId());
            if (to == null) ss1.put(from.getId(), from);
            else to.aggregate(from);
        }
    }

    Map<String, CounterSnapshot> getCounters()
    {
        return m_counters;
    }

    Map<String, GaugeSnapshot> getGauges()
    {
        return m_gauges;
    }

    Map<String, TimingSnapshot> getTimings()
    {
        return m_times;
    }

    boolean isEmpty()
    {
        return m_counters.isEmpty() && m_gauges.isEmpty() && m_times.isEmpty();
    }

    /**
     * See {@link MetricContainer#getInstanceId() }
     * 
     * @return
     */
    String getInstanceId()
    {
        return m_instanceId;
    }

    /**
     * See {@link MetricContainer#getName()}
     * 
     * @return
     */
    String getName()
    {
        return m_name;
    }

    /**
     * @return start time of interval captured by this snapshot
     */
    long getPeriodBeginTime()
    {
        return m_periodBeginTime;
    }

    /**
     * @return end time of interval captured by this snapshot
     */
    long getPeriodEndTime()
    {
        return m_periodEndTime;
    }
}
