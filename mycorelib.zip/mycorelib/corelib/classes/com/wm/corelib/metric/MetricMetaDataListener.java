package com.wm.corelib.metric;

/**
 * Objects wishing to subscribe to metric container and individual metric
 * add/remove events must implement this interface and register with
 * {@link IMetricRegistry}
 */
public interface MetricMetaDataListener
{
    public void metricAdded(MetricMetaData md);

    public void metricRemoved(MetricMetaData md);

    public void containerAdded(MetricContainer mc);

    public void containerRemoved(MetricContainer mc);
}