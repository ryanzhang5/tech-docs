package com.wm.corelib.metric;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.base.Predicate;
import com.google.common.base.Strings;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;
import com.google.common.collect.MapMaker;

public final class MetricContainer
{
    private final static ExecutorService _tExec = Executors.newCachedThreadPool();

    private static class MetricKey
    {
        private final String _id;
        private final Boolean _isCum;

        private MetricKey(String id, boolean isCum)
        {
            _id = Preconditions.checkNotNull(id);
            _isCum = isCum;
        }

        @Override
        public boolean equals(Object that)
        {
            if (!(that instanceof MetricKey)) return false;
            MetricKey mk = (MetricKey)that;
            return _id.equals(mk._id) && _isCum.equals(mk._isCum);
        }

        @Override
        public int hashCode()
        {
            return _id.hashCode() ^ _isCum.hashCode();
        }

    }

    static String nameOf(Class<?> parentClass, String subName)
    {
        if (parentClass == null) return subName;
        if (!(Strings.nullToEmpty(subName).isEmpty()))
            return parentClass.getSimpleName() + "." + subName;
        return parentClass.getSimpleName();
    }

    private final Class<?> m_parentClass;

    private final String m_metricSubName;

    private final String m_instanceId;
    private final ConcurrentMap<MetricKey, Counter> m_counterMap;
    private final ConcurrentMap<MetricKey, Gauge> m_gaugeMap;
    private final ConcurrentMap<MetricKey, Timing> m_timeMap;

    private MetricMetaDataListener m_metricLsnr;
    private long m_lastResetTime;
    private final ImmutableList<Map<MetricKey, ? extends AMetric>> m_allMetrics;

    MetricContainer(Class<?> parentClass, String subName)
    {
        this(parentClass, subName, null, null);
    }

    MetricContainer(Class<?> parentClass, String subName, String instanceId,
            MetricMetaDataListener lsnr)
    {
        m_lastResetTime = System.currentTimeMillis();
        Preconditions.checkArgument(parentClass != null || subName != null,
                "Either parent class or container name is required");
        Preconditions.checkArgument(instanceId == null || instanceId.length() > 0,
                "invalid instanceId");
        m_parentClass = parentClass;
        m_metricSubName = subName;
        m_instanceId = instanceId;
        m_metricLsnr = lsnr;

        MapMaker mm = new MapMaker();

        m_counterMap = mm.makeComputingMap(new Function<MetricKey, Counter>()
        {
            @Override
            public Counter apply(MetricKey key)
            {
                Counter stat = new Counter(key._id, key._isCum);
                notifyListener(stat);
                return stat;
            }
        });
        m_gaugeMap = mm.makeComputingMap(new Function<MetricKey, Gauge>()
        {
            @Override
            public Gauge apply(MetricKey key)
            {
                Gauge stat = new Gauge(key._id, key._isCum);
                notifyListener(stat);
                return stat;
            }
        });
        m_timeMap = mm.makeComputingMap(new Function<MetricKey, Timing>()
        {
            @Override
            public Timing apply(MetricKey key)
            {
                Timing stat = new Timing(key._id, key._isCum);
                notifyListener(stat);
                return stat;
            }
        });
        m_allMetrics = ImmutableList.<Map<MetricKey, ? extends AMetric>> of(m_counterMap,
                m_gaugeMap, m_timeMap);
    }

    public String getInstanceId()
    {
        return m_instanceId;
    }

    public String getName()
    {
        return nameOf(m_parentClass, m_metricSubName);
    }

    private void notifyListener(final AMetric m)
    {
        if (m_metricLsnr != null && !_tExec.isShutdown()) _tExec.execute(new Runnable()
        {
            @Override
            public void run()
            {
                synchronized (MetricContainer.this)
                {
                    if (m_metricLsnr != null)
                        m_metricLsnr.metricAdded(new MetricMetaData(getName(), m_instanceId, m));
                }
            }
        });
    }

    public void resetMetrics()
    {
        for (Map<MetricKey, ? extends AMetric> map : m_allMetrics)
        {
            for (AMetric m : map.values())
                m.initialize();
        }
    }

    public ImmutableList<Counter> getCounters()
    {
        return ImmutableList.copyOf(m_counterMap.values());
    }

    public ImmutableList<Timing> getTimings()
    {
        return ImmutableList.copyOf(m_timeMap.values());
    }

    public ImmutableList<Gauge> getGauges()
    {
        return ImmutableList.copyOf(m_gaugeMap.values());
    }

    public Counter getCounter(String id, boolean isCumulative)
    {
        return m_counterMap.get(new MetricKey(id, isCumulative));
    }

    public Counter getCounter(String id)
    {
        return getCounter(id, false);
    }

    public long incrementCounter(String id, boolean isCumulative)
    {
        return getCounter(id, isCumulative).increment();
    }

    public long incrementCounter(String id, long count, boolean isCumulative)
    {
        return getCounter(id, isCumulative).increment(count);
    }

    public long decrementCounter(String id, boolean isCumulative)
    {
        return getCounter(id, isCumulative).decrement();
    }

    public long decrementCounter(String id, long count, boolean isCumulative)
    {
        return getCounter(id, isCumulative).decrement(count);
    }

    public long incrementCounter(String id)
    {
        return incrementCounter(id, false);
    }

    public long incrementCounter(String id, long count)
    {
        return incrementCounter(id, count, false);
    }

    public long decrementCounter(String id)
    {
        return decrementCounter(id, false);
    }

    public long decrementCounter(String id, long count)
    {
        return decrementCounter(id, count, false);
    }

    public Gauge getGauge(String id)
    {
        return getGauge(id, false);
    }

    public Gauge getGauge(String id, boolean isCumulative)
    {
        return m_gaugeMap.get(new MetricKey(id, isCumulative));
    }

    public long setGauge(String id, long value)
    {
        return setGauge(id, value, false);
    }

    public long setGauge(String id, long value, boolean isCumulative)
    {
        return getGauge(id, isCumulative).set(value);
    }

    public long incrementGauge(String id, boolean isCumulative)
    {
        return getGauge(id, isCumulative).increment();
    }

    public long incrementGauge(String id, long value, boolean isCumulative)
    {
        return getGauge(id, isCumulative).increment(value);
    }

    public long decrementGauge(String id, boolean isCumulative)
    {
        return getGauge(id, isCumulative).decrement();
    }

    public long decrementGauge(String id, long value, boolean isCumulative)
    {
        return getGauge(id, isCumulative).decrement(value);
    }

    public long incrementGauge(String id)
    {
        return incrementGauge(id, false);
    }

    public long incrementGauge(String id, long value)
    {
        return incrementGauge(id, value, false);
    }

    public long decrementGauge(String id)
    {
        return decrementGauge(id, false);
    }

    public long decrementGauge(String id, long value)
    {
        return decrementGauge(id, value, false);
    }

    public Timing getTime(String id)
    {
        return getTime(id, false);
    }

    public Timing getTime(String id, boolean isCumulative)
    {
        return m_timeMap.get(new MetricKey(id, isCumulative));
    }

    public void addTime(String id, long time)
    {
        addTime(id, time, false);
    }

    public void addTime(String id, long time, boolean isCumulative)
    {
        getTime(id, isCumulative).add(time);
    }

    private <T extends AMetric, V extends AMetricSnapshot> List<V> selectAndResetMetrics(
            Collection<T> metrics, final boolean reset, final boolean includeUnchanged)
    {
        Predicate<T> include = new Predicate<T>()
        {
            @Override
            public boolean apply(T input)
            {
                return includeUnchanged || input.isUpdated();
            }
        };
        return ImmutableList.copyOf(Iterables.transform(Iterables.filter(metrics, include),
                new Function<T, V>()
                {
                    @Override
                    public V apply(T src)
                    {
                        return (V)src.takeSnapshot(reset);
                    }
                }));
    }

    public synchronized void setListener(MetricMetaDataListener lsnr)
    {
        m_metricLsnr = lsnr;
    }

    public Snapshot takeSnapshot(boolean reset)
    {
        return takeSnapshot(reset, true);
    }

    public Snapshot takeSnapshot(boolean reset, boolean includeUnchanged)
    {
        List<CounterSnapshot> counters = selectAndResetMetrics(m_counterMap.values(), reset,
                includeUnchanged);
        List<GaugeSnapshot> gauges = selectAndResetMetrics(m_gaugeMap.values(), reset,
                includeUnchanged);
        List<TimingSnapshot> times = selectAndResetMetrics(m_timeMap.values(), reset,
                includeUnchanged);

        long fromTime = m_lastResetTime;
        long toTime = System.currentTimeMillis();
        if (reset) m_lastResetTime = toTime;

        return new Snapshot(getName(), m_instanceId, fromTime, toTime, counters, gauges, times);
    }

    @Override
    public String toString()
    {
        return "<MetricContainer " + getName() + "/" + m_instanceId + ">";
    }
}
