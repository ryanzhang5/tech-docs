package com.wm.corelib.metric;

import java.util.List;

/**
 * Central metric container registry. This API is divided in two parts:
 * "internal" and "external". The internal part is concerned with application
 * server code wishing to create and register new metric containers and
 * individual metrics. The external portion allows registration of external
 * listeners who wish to be notified whenever a new metric or container is
 * created or removed.
 * 
 */
public interface IMetricRegistry
{
    /**
     * Register new metric metadata listener.
     * 
     * @param listener
     */
    public void addMetaDataListener(MetricMetaDataListener listener);

    /**
     * Remove (unregister) metadata listener
     * 
     * @param listener
     */
    public void removeMetaDataListener(MetricMetaDataListener listener);

    /**
     * Get metric container for given parent class.
     * 
     * @param parentClass
     * @return existing metric container for parent class or new if one doesn't
     *         yet exist
     */
    public MetricContainer get(Class<?> parentClass);

    /**
     * Get metric container for given parent class and container name.
     * 
     * @param parentClass
     * @param name
     * @return existing container or new if one doesn't yet exist
     */
    public MetricContainer get(Class<?> parentClass, String name);

    /**
     * Get metric container for given parent class, container name and instance
     * id. Instance id is useful if associating container instance with some
     * other object, e.g. instance of specified class. Note: at least parent
     * class or name must be provided.
     * 
     * @param parentClass
     * @param name
     * @param instanceId
     * @param createIfNotFound
     *            <code>true</code> if need to create new container when does
     *            not exist, <code>false</code> otherwise
     * @return
     */
    public MetricContainer get(Class<?> parentClass, String name,
            String instanceId, boolean createIfNotFound);

    /**
     * Returns all existing container matching supplied parent class and group
     * name (either one can be null)
     * 
     * @param parentClass
     * @param name
     * @return matching metric containers
     */
    public List<MetricContainer> getContainers(Class<?> parentClass, String name);

    /**
     * Removes previously created metric container from the registry.
     * 
     * @param container
     */
    public void remove(MetricContainer container);
}