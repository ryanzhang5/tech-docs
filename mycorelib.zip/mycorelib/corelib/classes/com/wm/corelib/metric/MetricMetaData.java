package com.wm.corelib.metric;

/**
 * Metric descriptor representation
 */
public final class MetricMetaData
{
    /**
     * Metric container id
     */
    private final String m_containerId;

    /**
     * Container instance id, if any.
     */
    private final String m_instanceId;

    /**
     * Metric id
     */
    private final String m_metricId;

    /**
     * Class of described metric
     */
    private final Class<? extends AMetric> m_type;

    public MetricMetaData(String groupId, String instanceId, AMetric metric)
    {
        m_containerId = groupId;
        m_instanceId = instanceId;
        m_metricId = metric.getId();
        m_type = metric.getClass();
    }

    public String getContainerId()
    {
        return m_containerId;
    }

    public String getInstanceId()
    {
        return m_instanceId;
    }

    public String getMetricId()
    {
        return m_metricId;
    }

    public Class<? extends AMetric> getType()
    {
        return m_type;
    }

    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder(128);
        sb.append('<').append(m_containerId).append(' ').append(m_instanceId)
                .append(' ').append(m_metricId).append(' ')
                .append(m_type.toString()).append('>');

        return sb.toString();
    }

}
