package com.wm.corelib.metric;

public final class GaugeSnapshot extends AMetricSnapshot
{
    private long m_changeCt;
    private long m_min;
    private long m_max;
    private long m_value;

    public GaugeSnapshot(String id)
    {
        this(id, Long.MAX_VALUE, Long.MIN_VALUE, 0, 0);
    }

    public GaugeSnapshot(String id, long min, long max, long value, long changeCt)
    {
        super(id);
        m_min = min;
        m_max = max;
        m_value = value;
        m_changeCt = changeCt;
    }

    public boolean hasBeenSet()
    {
        return (m_min <= m_max);
    }

    public long getValue()
    {
        return m_value;
    }

    public long getMin()
    {
        return m_min;
    }

    public long getMax()
    {
        return m_max;
    }

    public long getChangeCount()
    {
        return m_changeCt;
    }

    @Override
    public void aggregate(AMetricSnapshot other)
    {
        if (!(other instanceof GaugeSnapshot))
            throw new IllegalArgumentException("wrong snapshot type, " + other);
        GaugeSnapshot gss = (GaugeSnapshot)other;
        m_value = gss.m_value;
        if (gss.m_min < m_min) m_min = gss.m_min;
        if (gss.m_max > m_max) m_max = gss.m_max;
        m_changeCt += gss.m_changeCt;

    }

    @Override
    public String fieldsToString()
    {
        return "value=" + m_value + " min=" + m_min + " max=" + m_max + " changes=" + m_changeCt;
    }

}
