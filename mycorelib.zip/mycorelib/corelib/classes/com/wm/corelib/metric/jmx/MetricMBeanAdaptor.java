package com.wm.corelib.metric.jmx;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.management.Descriptor;
import javax.management.IntrospectionException;
import javax.management.MBeanParameterInfo;
import javax.management.ObjectName;
import javax.management.modelmbean.DescriptorSupport;
import javax.management.modelmbean.ModelMBean;
import javax.management.modelmbean.ModelMBeanAttributeInfo;
import javax.management.modelmbean.ModelMBeanInfo;
import javax.management.modelmbean.ModelMBeanInfoSupport;
import javax.management.modelmbean.ModelMBeanOperationInfo;
import javax.management.modelmbean.RequiredModelMBean;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.wm.corelib.jmxadmin.JmxUtil;
import com.wm.corelib.metric.AMetric;
import com.wm.corelib.metric.Counter;
import com.wm.corelib.metric.Gauge;
import com.wm.corelib.metric.MetricContainer;
import com.wm.corelib.metric.Timing;

public final class MetricMBeanAdaptor
{
    private static ExecutorService s_exec = Executors.newCachedThreadPool();

    /**
     * Creates and registers a model MBean for interfacing with Hyperic Agent's
     * JMX auto-inventory model.
     * 
     * @param cont
     */
    public static void createModelMBean(final MetricContainer cont)
    {
        final Map<AMetric, Collection<Method>> operations = Maps.newHashMap();
        final Map<AMetric, Collection<Method>> getters = Maps.newHashMap();
        final Map<AMetric, Collection<Method>> setters = Maps.newHashMap();

        s_exec.execute(new Runnable()
        {
            @Override
            public void run()
            {
                try
                {
                    for (Counter c : cont.getCounters())
                    {
                        Collection<Method> metricOps = Lists.newArrayList();
                        Collection<Method> metricGetters = Lists.newArrayList();

                        // Read access
                        Method getter = c.getClass().getMethod("getValue");
                        metricOps.add(getter);
                        metricGetters.add(getter);

                        getters.put(c, metricGetters);
                        // Mutation
                        metricOps.addAll(Lists.newArrayList(c.getClass().getMethod("increment"), c
                                .getClass().getMethod("increment", long.class), c.getClass()
                                .getMethod("decrement"),
                                c.getClass().getMethod("decrement", long.class), c.getClass()
                                        .getMethod("initialize")));
                        operations.put(c, metricOps);
                    }

                    for (Timing t : cont.getTimings())
                    {
                        Collection<Method> metricOps = Lists.newArrayList();
                        Collection<Method> metricGetters = Lists.newArrayList();

                        // Read access
                        Collection<Method> accessors = Lists.newArrayList(
                                t.getClass().getMethod("getAvgValue"),
                                t.getClass().getMethod("getMinValue"),
                                t.getClass().getMethod("getMaxValue"),
                                t.getClass().getMethod("getLastValue"),
                                t.getClass().getMethod("getCount"));
                        metricGetters.addAll(accessors);
                        metricOps.addAll(accessors);

                        getters.put(t, metricGetters);

                        // Mutation
                        metricOps.addAll(Lists.newArrayList(
                                t.getClass().getMethod("add", long.class),
                                t.getClass().getMethod("initialize")));
                        operations.put(t, metricOps);
                    }

                    for (Gauge g : cont.getGauges())
                    {
                        Collection<Method> metricOps = Lists.newArrayList();
                        Collection<Method> metricGetters = Lists.newArrayList();

                        // Read access
                        Collection<Method> accessors = Lists.newArrayList(
                                g.getClass().getMethod("getValue"),
                                g.getClass().getMethod("getMinValue"),
                                g.getClass().getMethod("getMaxValue"));
                        metricGetters.addAll(accessors);
                        metricOps.addAll(accessors);

                        getters.put(g, metricGetters);

                        metricOps.addAll(Lists
                                .newArrayList(g.getClass().getMethod("increment"), g.getClass()
                                        .getMethod("increment", long.class), g.getClass()
                                        .getMethod("initialize"),
                                        g.getClass().getMethod("set", long.class)));
                        operations.put(g, metricOps);

                    }

                    Collection<ModelMBeanAttributeInfo> attrInfo = Lists.newArrayList();

                    // Create availability attribute - required for Hyperic
                    attrInfo.add(new ModelMBeanAttributeInfo("Availability", "int", "Availability",
                            true, false, false, new DescriptorSupport(new String[] { "name",
                                    "descriptorType", "value" }, new Object[] { "Availability",
                                    "attribute", 1 })));
                    Pattern valNamePt = Pattern.compile("get(\\w+)Value");

                    for (Map.Entry<AMetric, Collection<Method>> getter : getters.entrySet())
                    {
                        AMetric metric = getter.getKey();
                        for (Method g : getter.getValue())
                        {
                            Matcher m = valNamePt.matcher(g.getName());
                            String attrName = (m.matches() ? m.group(1) + metric.getId()
                                    : ("getCount".equals(g.getName()) ? metric.getId() + "Count"
                                            : metric.getId()));
                            attrInfo.add(metric2AttrInfo(metric, g, null, attrName));
                        }
                    }

                    Collection<ModelMBeanOperationInfo> opInfo = Lists.newArrayList();
                    for (Map.Entry<AMetric, Collection<Method>> op : operations.entrySet())
                    {
                        AMetric metric = op.getKey();
                        for (Method m : op.getValue())
                        {
                            String opName = metric.getId() + ":" + m.getName();
                            Descriptor opDesc = new DescriptorSupport(new String[] {
                                    "targetObject", "name", "descriptorType" }, new Object[] {
                                    metric, m.getName(), "operation" });
                            Class<?>[] paramTypes = m.getParameterTypes();
                            Collection<MBeanParameterInfo> params = Lists.newArrayList();
                            int i = 0;
                            for (Class<?> pType : paramTypes)
                            {
                                params.add(new MBeanParameterInfo("p" + i++, pType.getName(), null));
                            }
                            ModelMBeanOperationInfo mmbOp = new MetricMBeanOperationInfo(opName,
                                    opName, params.toArray(new MBeanParameterInfo[params.size()]),
                                    m.getReturnType().getName(), opDesc);
                            opInfo.add(mmbOp);
                        }
                    }

                    // TODO add setter support
                    ModelMBeanInfo mmbi = new ModelMBeanInfoSupport(cont.getName(), cont.getName(),
                            attrInfo.toArray(new ModelMBeanAttributeInfo[attrInfo.size()]), null, // constructors
                            opInfo.toArray(new ModelMBeanOperationInfo[opInfo.size()]), null, // notifications
                            new DescriptorSupport("name=" + cont.getInstanceId(),
                                    "descriptorType=mbean", "export=true"));
                    ModelMBean mbean = new RequiredModelMBean(mmbi);
                    JmxUtil.getMBeanServer().registerMBean(
                            mbean,
                            new ObjectName("spring.application:type=" + cont.getName() + ",name="
                                    + cont.getInstanceId()));
                } catch (Exception ex)
                {
                    throw new RuntimeException(ex);
                }
            }
        });
    }

    private static ModelMBeanAttributeInfo metric2AttrInfo(AMetric obj, Method getter,
            Method setter, String attrName) throws IntrospectionException
    {
        List<String> descriptors = Lists.newArrayList();
        descriptors.add("name=" + attrName);
        descriptors.add("descriptorType=attribute");
        descriptors.add("metricType=" + (obj instanceof Counter ? "counter" : "gauge"));
        descriptors.add("category="
                + (obj instanceof Timing ? "PERFORMANCE" : (obj instanceof Counter ? "THROUGHPUT"
                        : "UTILIZATION")));
        if (getter != null)
        {
            descriptors.add("getMethod=" + obj.getId() + ":" + getter.getName());
        }
        if (setter != null)
        {
            descriptors.add("setMethod=" + obj.getId() + ":" + setter.getName());
        }

        Descriptor attrD = new DescriptorSupport(
                descriptors.toArray(new String[descriptors.size()]));

        return new ModelMBeanAttributeInfo(attrName, attrName, getter, setter, attrD);
    }

}
