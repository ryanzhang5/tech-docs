package com.wm.corelib.metric;

public final class TimingSnapshot extends AMetricSnapshot
{
    private long m_count;
    private long m_min;
    private long m_max;
    private long m_total;

    public TimingSnapshot(String id)
    {
        this(id, 0, Long.MAX_VALUE, Long.MIN_VALUE, 0);
    }

    public TimingSnapshot(String id, long count, long min, long max, long total)
    {
        super(id);
        m_count = count;
        m_min = min;
        m_max = max;
        m_total = total;
    }

    @Override
    public void aggregate(AMetricSnapshot other)
    {
        if (!(other instanceof TimingSnapshot)) { throw new IllegalArgumentException(
                "wrong snapshot type, " + other); }
        TimingSnapshot tss = (TimingSnapshot)other;
        m_count += tss.m_count;
        if (tss.m_min < m_min) m_min = tss.m_min;
        if (tss.m_max > m_max) m_max = tss.m_max;
        m_total += tss.m_total;
    }

    @Override
    public String fieldsToString()
    {
        return "count=" + m_count
                + ((m_count > 0) ? " min=" + m_min + " avg=" + getAvg() + " max=" + m_max : "");
    }

    public float getAvg()
    {
        return m_count > 0 ? m_total / m_count : 0;
    }

    public long getCount()
    {
        return m_count;
    }

    public long getMax()
    {
        return m_count > 0 ? m_max : 0;
    }

    public long getMin()
    {
        return m_count > 0 ? m_min : 0;
    }

    public long getTotal()
    {
        return m_total;
    }

}
