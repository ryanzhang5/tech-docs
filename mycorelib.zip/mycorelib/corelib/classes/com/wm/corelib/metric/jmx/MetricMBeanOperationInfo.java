package com.wm.corelib.metric.jmx;

import javax.management.Descriptor;
import javax.management.MBeanOperationInfo;
import javax.management.MBeanParameterInfo;
import javax.management.modelmbean.ModelMBeanOperationInfo;

/**
 * This class is needed to do custom management of operation descriptors; this
 * is required to circumvent BS op name validity checks in superclass. We need
 * to be able to work with valid Java method names but scope attribute/accessor
 * method names to their respective target objects, which means having operation
 * (metric) names different from their respective method names.
 * {@link ModelMBeanOperationInfo} does not allow this, nor does it expose this
 * field in superclass (it is private).
 * <p>
 * For example:<br>
 * <ul>
 * <li>metric name: <b>HitCount</b></li>
 * <li>attribute descriptor name: <b>HitCount</b></li>
 * <li>get method / operation name (must be unique within MBean:
 * <b>HitCount:getValue</b> (NOTE: there maybe be other counter instances on
 * whom one can call <code>getValue</code>)</li>
 * <li>operation descriptor name (same as actual Java method name):
 * <b>getValue</b></li>
 * </ul>
 */

public final class MetricMBeanOperationInfo extends ModelMBeanOperationInfo
{
    private Descriptor m_desc;

    public MetricMBeanOperationInfo(String name, String description,
            MBeanParameterInfo[] signature, String type, Descriptor desc)
    {
        super(name, description, signature, type, MBeanOperationInfo.UNKNOWN);
        m_desc = desc;
    }

    @Override
    public Descriptor getDescriptor()
    {
        return (Descriptor)m_desc.clone();
    }

    @Override
    public void setDescriptor(Descriptor inDescriptor)
    {
        m_desc = (Descriptor)inDescriptor.clone();
    }

    @Override
    public Object clone()
    {
        return new MetricMBeanOperationInfo(getName(), getDescription(), getSignature(),
                getReturnType(), (Descriptor)(m_desc != null ? m_desc.clone() : null));
    }

}
