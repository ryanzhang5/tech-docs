package com.wm.corelib.metric;

/**
 * Metric that represents a timing measurement. This can, for instance,
 * represent request latencies measured over a period of time.
 * <p>
 * Usage:
 * 
 * <pre>
 * Timing timeStat = new Timing(&quot;AccessTimes&quot;);
 * 
 * long start = System.currentTimeMillis();
 * doSomething();
 * timeStat.add(System.currentTimeMillis() - start);
 * </pre>
 * 
 * Or:
 * 
 * <pre>
 * timeStat.eventStart();
 * processMessages();
 * timeStat.eventEnd();
 * </pre>
 * 
 * The second use case only works if {@link #eventEnd()} is called in the same
 * thread as {@link #eventStart()}
 */
public final class Timing extends AMetric
{
    private long m_count = 0;
    private long m_min = Long.MAX_VALUE;
    private long m_max = Long.MIN_VALUE;
    private long m_total = 0;
    private long m_last = 0;

    private final ThreadLocal<Long> m_chkPt = new ThreadLocal<Long>();

    public Timing(String id)
    {
        super(id);
    }

    public Timing(String id, boolean isCumulative)
    {
        super(id, isCumulative);
    }

    @Override
    public TimingSnapshot takeSnapshot(boolean reset)
    {
        TimingSnapshot tss = new TimingSnapshot(getId(), m_count, m_min, m_max, m_total);
        if (reset) initialize();
        return tss;
    }

    /**
     * Resets aggregate values to their initial state, but keep the last
     * recorded measurement.
     */
    @Override
    protected synchronized void reset()
    {
        m_count = 0;
        m_total = 0;
        m_min = Long.MAX_VALUE;
        m_max = Long.MIN_VALUE;
    }

    @Override
    public synchronized boolean isUpdated()
    {
        return m_count > 0;
    }

    /**
     * @return sample size of this metric
     */
    public synchronized long getCount()
    {
        return m_count;
    }

    /**
     * @return sum total of all values
     */
    public synchronized long getTotal()
    {
        return m_total;
    }

    public synchronized long getMinValue()
    {
        return m_count > 0 ? m_min : 0;
    }

    public synchronized long getMaxValue()
    {
        return m_count > 0 ? m_max : 0;
    }

    /**
     * @return average of all values since last reset
     */
    public synchronized float getAvgValue()
    {
        return m_count > 0 ? m_total / m_count : 0;
    }

    /**
     * @return last recorded value
     */
    public synchronized long getLastValue()
    {
        return m_last;
    }

    @Override
    public synchronized String fieldsToString()
    {
        return "count="
                + m_count
                + ((m_count > 0) ? " min=" + m_min + " avg=" + getAvgValue() + " max=" + m_max : "");
    }

    public synchronized void add(long value)
    {
        m_count++;
        m_total += value;
        if (value < m_min) m_min = value;
        if (value > m_max) m_max = value;
        m_last = value;
    }

    /**
     * Start of timed event
     */
    public void eventStart()
    {
        m_chkPt.set(System.currentTimeMillis());
    }

    /**
     * End of timed event; records duration internally
     */
    public void eventEnd()
    {
        Long evtStart = m_chkPt.get();
        // TODO: should we throw IllegalStateException here if eventStart() was
        // never invoked in calling thread?
        if (evtStart == null) return;
        add(System.currentTimeMillis() - evtStart);
    }
}
