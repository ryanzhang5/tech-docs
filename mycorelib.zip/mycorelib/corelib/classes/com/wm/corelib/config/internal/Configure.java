/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.config.internal;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.LinkedHashMap;

/**
 * ConfigureXml
 *
 * @author mkishore
 * @since 2.5.2
 */
public class Configure {
    private List<KeyGroup> keyGroups;

    public Configure() {
        // default cons
    }

    public void addKeyGroup(KeyGroup keyGroup) {
        if (keyGroups == null) {
            keyGroups = new ArrayList<KeyGroup>();
        }
        keyGroups.add(keyGroup);
        keyGroup.setConfigureXml(this);
    }

    public List<KeyGroup> getKeyGroups() {
        return keyGroups;
    }

    public Map<String, Key> getKeys() {
        Map<String, Key> keys = new LinkedHashMap<String, Key>();
        if (keyGroups != null) for (KeyGroup keyGroup : keyGroups) {
            keys.putAll(keyGroup.getKeys());
        }
        return keys;
    }
}
