/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.config;

import java.util.List;
import java.util.ArrayList;
import java.util.Properties;

/**
 * AppConfigLoader - uses a ordered list of PropertyLoaders to get property
 * values from different locations and merge them into a final set, which is
 * then used to initialize the AppConfig object.
 *
 * @author mkishore
 * @since 2.5.2
 */
public class AppConfigLoader {
    private List<PropertiesLoader> propertiesLoaders = new ArrayList<PropertiesLoader>();
    private boolean initializeSingleton = false;

    /**
     * Returns the list of properties loaders used by this loader
     * @return the list of properties loaders used by this loader
     */
    public List<PropertiesLoader> getPropertiesLoaders() {
        return propertiesLoaders;
    }

    /**
     * Sets the list of properties loaders used by this loader
     * @param propertiesLoaders - the list of properties loaders used by this loader
     */
    public void setPropertiesLoaders(List<PropertiesLoader> propertiesLoaders) {
        this.propertiesLoaders = propertiesLoaders;
    }

    /**
     * Returns true if this loader is meant to initialize the AppConfig singleton instance
     *
     * @return true if this loader is meant to initialize the AppConfig singleton instance
     */
    public boolean isInitializeSingleton() {
        return initializeSingleton;
    }

    /**
     * Sets the flag that determines if this loader will initialize the AppConfig singleton instance.
     * If set to false, this loader will create new AppConfig instance each time.
     *
     * @param initializeSingleton - true if this loader should initialize the AppConfig singleton instance
     */
    public void setInitializeSingleton(boolean initializeSingleton) {
        this.initializeSingleton = initializeSingleton;
    }

    /**
     * Iterates through the list of properties loaders and creates a single unified
     * set of property values - which is used to initialize the AppConfig instance
     *
     * @return an AppConfig object initialized with values from the properties loaders
     */
    public AppConfig load() {
        AppConfig appConfig = (initializeSingleton) ? AppConfig.getInstance() : new AppConfig();
        Properties props = new Properties();
        for (PropertiesLoader loader : propertiesLoaders) {
            Properties childProps = loader.load();
            props.putAll(childProps);
        }
        appConfig.setProperties(props);
        return appConfig;
    }
    
}
