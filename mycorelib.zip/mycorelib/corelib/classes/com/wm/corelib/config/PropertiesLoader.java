/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.config;

import java.util.Properties;

/**
 * PropertiesLoader - simple interface to abstract different ways of
 * loading property values.
 *
 * @author mkishore
 * @since 2.5.2
 */
public interface PropertiesLoader {
    /**
     * The implementation should load and return the properties object
     *
     * @return a Properties object
     */
    public Properties load();

}
