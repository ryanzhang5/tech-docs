/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.config.internal;

import com.wm.corelib.config.AppConfig;

import java.util.Properties;
import java.util.Map;
import java.util.List;
import java.util.TreeMap;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.io.*;

/**
 * ConfigureXmlProcessor - processes the configure.xml to .snapshot.config
 *
 * @author mkishore
 * @since 2.5.2
 */
public class ConfigureXmlProcessor { // implement PropertiesLoader??
    private static final Logger logger = Logger.getLogger(ConfigureXmlProcessor.class.getName());

    private Configure configure;
    private Properties overrides;
    private Properties context = inferContext();

    public Properties process() {
        Properties props = new Properties();
        if (context != null) {
            props.putAll(context);
        }
        if (overrides != null) {
            props.putAll(overrides);
        }
        if (configure != null) {
            Map<String, Key> keys = configure.getKeys();
            for (Map.Entry<String, Key> entry : keys.entrySet()) {
                processKey(entry.getValue(), props);
            }
        }
        return props;
    }

    private void processKey(Key key, Properties props) {
        if (key == null) return;

        String name = key.getName();
        String val = key.getDefault();

        List<Rule> rules = key.getRules();
        if (rules != null) for (Rule rule : rules) {
            String ruleVal = processRule(rule, props);
            if (ruleVal != null) val = ruleVal;
        }
        val = processValue(val, props);
        props.setProperty(name, val);
    }

    private String processRule(Rule rule, Properties props) {
        if (rule == null) return null;

        String type = rule.getType();
        String var = rule.getVar();
        String val = rule.getVal();

        if (!props.containsKey(var)) {
            throw new RuntimeException("Invalid rule based on undefined veraible: " + var);
        }
        String actual = props.getProperty(var);
        boolean match = false;
        if ("exact".equals(type)) {
            match = val.equals(actual);
        } else if ("regex".equals(type)) {
            String regex = val;
            if (!regex.startsWith("^")) regex = ".*" + regex;
            if (!regex.endsWith("$")) regex = regex + ".*";
            match = actual != null && actual.matches(regex);
        }
        if (match) {
            if (rule.getKeyVal() != null) {
                return rule.getKeyVal();
            } else if (rule.getRules() != null) {
                String childVal = null;
                for (Rule child : rule.getRules()) {
                    String ruleVal = processRule(child, props);
                    if (ruleVal != null) childVal = ruleVal;
                }
                return childVal;
            }
        }
        return null;
    }

    private String processValue(String value, Properties props) {
        int ndx = value.indexOf("${");
        while (ndx >= 0) {
            int end = value.indexOf('}', ndx + 3);
            if (end == -1) break;
            String token = value.substring(ndx+2, end);
            if (!props.containsKey(token)) {
                throw new RuntimeException("Invalid value based on undefined variable: " + token);
            }
            String tokenValue = props.getProperty(token);
            if (end == value.length()-1) {
                value = value.substring(0, ndx) + tokenValue;
            } else {
                value = value.substring(0, ndx) + tokenValue + value.substring(end + 1);
            }
            // check again
            ndx = value.indexOf("${");
        }
        return value;
    }

    public Configure getConfigure() {
        return configure;
    }

    public void setConfigure(Configure configure) {
        this.configure = configure;
    }

    public Properties getOverrides() {
        return overrides;
    }

    public void setOverrides(Properties overrides) {
        this.overrides = overrides;
    }

    public Properties getContext() {
        return context;
    }

    public void setContext(Properties context) {
        this.context = context;
    }

    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            log("Usage: java " + ConfigureXmlProcessor.class.getName() + " configure.xml");
            System.exit(1);
        }

        ConfigureXmlParser parser = new ConfigureXmlParser();
        parser.setInputStream(new FileInputStream(args[0]));
        Configure configure = parser.parse();
        ConfigureXmlProcessor processor = new ConfigureXmlProcessor();
        processor.setConfigure(configure);
        Map props = new TreeMap(processor.process());
        for (Object key : props.keySet()) {
            log(key + "=" + props.get(key));
        }
        
    }

    private static void log(String msg) {
        (System.out).println(msg);
    }

    public static Properties inferContext() {
        Properties context = new Properties();
        // explicitly passed in
        context.setProperty("ENVIRONMENT", AppConfig.getEnvironment());
        context.setProperty("APPLICATION", AppConfig.getInstance().getAppName());

        // application root folder
        String root = System.getProperty("user.dir");
        context.setProperty("ROOT", root);
        // infer and format hostname
        String hostname = AppConfig.getHostname();
        if (hostname == null) try {
            hostname = InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            logger.log(Level.WARNING, "Error looking up the hostname", e);
        }
        if (hostname != null && hostname.contains(".")) {
            hostname = hostname.substring(0, hostname.indexOf('.'));
        }
        context.setProperty("HOSTNAME", hostname);

        // WEBAPPS should NOT care about OS and CPU level differences...

        // uname -s --system-name; works okay
        String os = System.getProperty("os.name");
        context.setProperty("OS", os);
        // uname -m --machine-hardware; not lining up for Linux
        // uname=i686, java(os.arch)=i386 (same as uname -i, but that's not available on solaris)
        String arch = exec("uname -m", System.getProperty("os.arch"));
        context.setProperty("ARCH", arch);
        // uname -p --processor (but, override to 'unknown' for Linux with ix86)
        String cpu = "Linux".equals(os) ?"unknown" :exec("uname -p", "unknown");
        context.setProperty("CPU", cpu);

        // not used - deprecate?
        context.setProperty("USER", System.getProperty("user.name"));
        // used in httpd.conf - do we need it? Can it be replaced with 127.0.0.1?
        String hostip = null;
        try {
            hostip = InetAddress.getLocalHost().getHostAddress();
        } catch (UnknownHostException e) {
            logger.log(Level.WARNING, "Error looking up the local host name", e);
            hostip = "127.0.0.1";
        }
        context.setProperty("HOSTIP", hostip);

        // deprecated
        context.setProperty("GROUPS", "");
        context.setProperty("LIKE_HOST", hostname);

        // RELEASE_VERSION - ??
        return context;
    }

    private static String exec(String cmd, String defaultValue) {
        try {
            Process p = Runtime.getRuntime().exec(cmd);
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                pw.println(line);
            }
            pw.flush();
            sw.flush();
            return sw.toString();
        } catch (IOException e) {
            logger.log(Level.WARNING, "Error trying to execute system command: " + cmd, e);
            return defaultValue;
        }
    }
}
