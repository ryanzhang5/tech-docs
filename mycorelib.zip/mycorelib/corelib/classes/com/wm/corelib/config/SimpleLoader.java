/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.config;

import com.wm.corelib.io.Resource;

import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * SimpleLoader - loads a properties file from the given path (classpath or filesystem)
 *
 * @author mkishore
 * @since 2.5.2
 */
public class SimpleLoader implements PropertiesLoader {
    private static final Logger logger = Logger.getLogger(SimpleLoader.class.getName());

    private Resource file;

    public Resource getFile() {
        return file;
    }

    public void setFile(Resource file) {
        this.file = file;
    }

    /**
     * Loads the properties from the file (on the classpath or the filesystem)
     *
     * @return the properties loaded from the file
     */
    public Properties load() {
        Properties props = new Properties();
        try {
            InputStream is = file.getInputStream();
            props.load(is);
            logger.info("Successfully loaded properties from: " + file.getURL());
            if (logger.isLoggable(Level.FINE)) {
                logger.fine("Properties loaded: " + props);
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error loading properties from: " + file.getDescription(), e);
        }
        return props;
    }

}
