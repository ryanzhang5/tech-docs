/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.config.internal;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * KeyGroup
 *
 * @author mkishore
 * @since 2.5.2
 */
public class KeyGroup {
    private Configure configure;

    private String name;
    private Map<String, Key> keys;

    public KeyGroup(String name) {
        this.name = name;
    }

    public void addKey(Key key) {
        if (keys == null) {
            keys = new LinkedHashMap<String, Key>();
        }
        keys.put(key.getName(), key);
        key.setKeyGroup(this);
    }

    public void setConfigureXml(Configure configure) {
        this.configure = configure;
    }

    public Configure getConfigureXml() {
        return configure;
    }

    public String getName() {
        return name;
    }

    public Map<String, Key> getKeys() {
        return keys;
    }
    
}
