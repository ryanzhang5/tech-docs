/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.config.internal;

import java.util.List;
import java.util.ArrayList;

/**
 * Key
 *
 * @author mkishore
 * @since 2.5.2
 */
public class Key {
    private KeyGroup keyGroup;
    
    private String name;
    private String defaultVal;
    private String prompt;

    private List<Rule> rules;

    public Key(String name, String defaultVal, String prompt) {
        this.name = name;
        this.defaultVal = defaultVal;
        this.prompt = prompt;
    }

    public void addRule(Rule rule) {
        if (rules == null) {
            rules = new ArrayList<Rule>();
        }
        rules.add(rule);
    }

    public void setKeyGroup(KeyGroup keyGroup) {
        this.keyGroup = keyGroup;
    }

    public KeyGroup getKeyGroup() {
        return keyGroup;
    }

    public String getName() {
        return name;
    }

    public String getDefault() {
        return defaultVal;
    }

    public String getPrompt() {
        return prompt;
    }

    public List<Rule> getRules() {
        return rules;
    }
}
