/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.config;

import com.wm.corelib.config.internal.ConfigureXmlProcessor;

import java.util.logging.Logger;
import java.util.logging.Level;
import java.util.Properties;
import java.net.URLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;

/**
 * HttpBasedLoader - loads properties from an HTTP endpoint
 *
 * @author mkishore
 * @since 2.5.2
 */
public class HttpBasedLoader implements PropertiesLoader {
    private static Logger logger = Logger.getLogger(HttpBasedLoader.class.getName());

    private String URL;
    private Properties context = inferContext();
    private int connectTimeout = 1000; // 1 second
    private int readTimeout = 10000; // 10 seconds
    private String charset = "UTF-8"; // default charset

    private static Properties inferContext() {
        Properties context = new Properties();
        context.setProperty("domain", AppConfig.getInstance().getAppName());
        context.setProperty("release", AppConfig.getInstance().getAppVersion());
        context.setProperty("app", AppConfig.getInstance().getAppName());
        context.setProperty("env", AppConfig.getEnvironment());
        context.setProperty("server", AppConfig.getHostname());
        return context;
    }

    public String getURL() {
        return URL;
    }

    public void setURL(String URL) {
        this.URL = URL;
    }

    public Properties getContext() {
        return context;
    }

    public void setContext(Properties context) {
        this.context = context;
    }

    public int getConnectTimeout() {
        return connectTimeout;
    }

    public void setConnectTimeout(int connectTimeout) {
        this.connectTimeout = connectTimeout;
    }

    public int getReadTimeout() {
        return readTimeout;
    }

    public void setReadTimeout(int readTimeout) {
        this.readTimeout = readTimeout;
    }

    public String getCharset() {
        return charset;
    }

    public void setCharset(String charset) {
        this.charset = charset;
    }

    public Properties load() {
        Properties props = new Properties();
        if (URL != null) {
            try {
                String url = createURL(URL, context);
                URLConnection con = openConnection(url);
                con.connect();
                InputStream is = con.getInputStream();
                props.load(is);
                logger.info("Successfully loaded properties from: " + url);
                if (logger.isLoggable(Level.FINE)) {
                    logger.fine("Properties loaded: " + props);
                }
                is.close();
            } catch (IOException e) {
                logger.log(Level.SEVERE, "Error loading properties from: " + URL, e);
            }
        }
        return props;
    }

    private String createURL(String str, Properties params) throws UnsupportedEncodingException {
        String url = str;
        String prefix = (url.contains("?")) ?"&" :"?";
        for (String name : params.stringPropertyNames()) {
            String value = params.getProperty(name);
            url += prefix + URLEncoder.encode(name, charset) + "=" + URLEncoder.encode(value, charset);
            prefix = "&";
        }
        return url;
    }

    private URLConnection openConnection(String str) throws IOException {
        URL url = new URL(str);
        URLConnection con = url.openConnection();
        con.setConnectTimeout(connectTimeout);
        con.setReadTimeout(readTimeout);
        con.setAllowUserInteraction(false);
        con.setDoInput(true);
        con.setDoOutput(false);
        con.setUseCaches(false);
        return con;
    }
}
