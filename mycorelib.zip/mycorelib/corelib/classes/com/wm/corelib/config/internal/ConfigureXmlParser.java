/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.corelib.config.internal;


import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 * This class takes a configure.xml and creates an object model from it
 */
public class ConfigureXmlParser {
    protected static final Logger logger = Logger.getLogger(ConfigureXmlParser.class.getName());

    private InputStream inputStream;

    public InputStream getInputStream() {
        return inputStream;
    }

    public void setInputStream(InputStream inputStream) {
        this.inputStream = inputStream;
    }

    public Configure parse() {
        try {
            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document doc = builder.parse(inputStream);
            return parseConfigure(doc.getDocumentElement());
        } catch (Exception ex) {
            throw new RuntimeException("Error parsing the configure.xml from the given input-stream", ex);
        }
    }

    private static Configure parseConfigure(Element el) {
        if (el == null) return null;

        Configure configure = new Configure();

        Element keys = getChild(el, "keys");
        if (keys != null) {
            List<Element> keyGroups = getChildren(keys, "keygroup");
            if (keyGroups != null) for (Element keyGroup : keyGroups) {
                configure.addKeyGroup(parseKeyGroup(keyGroup));
            }
        }
        return configure;
    }

    private static KeyGroup parseKeyGroup(Element el) {
        if (el == null) return null;

        String name = el.getAttribute("name");
        KeyGroup keyGroup = new KeyGroup(name);

        List<Element> keys = getChildren(el, "key");
        if (keys != null) for (Element key : keys) {
            keyGroup.addKey(parseKey(key));
        }
        return keyGroup;
    }

    private static Key parseKey(Element el) {
        if (el == null) return null;

        String name =  el.getAttribute("name");
        String defaultVal = el.getAttribute("default");
        String prompt = el.getAttribute("prompt");
        Key key = new Key(name, defaultVal, prompt);

        List<Element> rules = getChildren(el, "rule");
        if (rules != null) for (Element rule : rules) {
            key.addRule(parseRule(rule));
        }
        return key;
    }

    private static Rule parseRule(Element el) {
        if (el == null) return null;

        String type = el.getAttribute("type");
        String var = el.getAttribute("var");
        String val = el.getAttribute("val");
        Rule rule = new Rule(type, var, val);

        Element keyval = getChild(el, "keyval");
        if (keyval != null) {
            rule.setKeyVal(keyval.getAttribute("val"));
        }

        List<Element> nestedRules = getChildren(el, "rule");
        if (nestedRules != null) for (Element nestedRule : nestedRules) {
            rule.addRule(parseRule(nestedRule));
        }
        return rule;
    }

    private static Element getChild(Element parent, String name) {
        if (parent == null) return null;
        NodeList nl = parent.getChildNodes();
        for (int i=0; i < nl.getLength(); i++) {
            Node n = nl.item(i);
            if (n.getNodeType() == Node.ELEMENT_NODE && n.getNodeName().equals(name)) {
                return (Element) n;
            }
        }
        return null;
    }

    private static List<Element> getChildren(Element parent, String name) {
        List<Element> children = new ArrayList<Element>();
        if (parent == null) return children;
        NodeList nl = parent.getChildNodes();
        for (int i=0; i < nl.getLength(); i++) {
            Node n = nl.item(i);
            if (n.getNodeType() == Node.ELEMENT_NODE && n.getNodeName().equals(name)) {
                children.add((Element) n);
            }
        }
        return children;
    }

    // TESTING/DEBUGGING stuff below this line..

    public static void main(String[] args) throws FileNotFoundException {
        if (args.length < 1) {
            log("Usage: java " + ConfigureXmlParser.class.getName() + " configure.xml");
            System.exit(1);
        }

        ConfigureXmlParser parser = new ConfigureXmlParser();
        parser.setInputStream(new FileInputStream(args[0]));
        Configure configure = parser.parse();
        parser.log("", configure);
    }

    private static void log(String s) {
        (System.out).println(s);
    }

    private static void log(String prefix, Configure configure) {
        log(prefix + "configure");
        for (KeyGroup kg : configure.getKeyGroups()) {
            log(prefix + "  ", kg);
        }
    }

    private static void log(String prefix, KeyGroup keyGroup) {
        log(prefix + "keygroup: " + keyGroup.getName());
        for (Key k : keyGroup.getKeys().values()) {
            log(prefix + "  ", k);
        }
    }

    private static void log(String prefix, Key key) {
        log(prefix + "key: " + key.getName() + ", default: " + key.getDefault() + ", prompt: " + key.getPrompt());
        if (key.getRules() != null) for (Rule r : key.getRules()) {
            log(prefix + "  ", r);
        }
    }

    private static void log(String prefix, Rule rule) {
        log(prefix + "rule: " + rule.getType() + ", var: " + rule.getVar() + ", val: " + rule.getVal());
        if (rule.getKeyVal() != null) {
            log(prefix + "  " + "keyval: " + rule.getKeyVal());
        }
        if (rule.getRules() != null) for (Rule r : rule.getRules()) {
            log(prefix + "  ", r);
        }
    }

}