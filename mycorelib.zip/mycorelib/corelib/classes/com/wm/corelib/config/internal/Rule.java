/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.config.internal;

import java.util.List;
import java.util.ArrayList;

/**
 * Rule
 *
 * @author mkishore
 * @since 2.5.2
 */
public class Rule {
    private String type;
    private String var;
    private String val;

    private List<Rule> rules;
    private String keyVal;

    public Rule(String type, String var, String val) {
        this.type = type;
        this.var = var;
        this.val = val;
    }

    public void setKeyVal(String keyVal) {
        this.keyVal = keyVal;
    }

    public void addRule(Rule rule) {
        if (rules == null) {
            rules = new ArrayList<Rule>();
        }
        rules.add(rule);
    }

    public String getType() {
        return type;
    }

    public String getVar() {
        return var;
    }

    public String getVal() {
        return val;
    }

    public List<Rule> getRules() {
        return rules;
    }

    public String getKeyVal() {
        return keyVal;
    }
}
