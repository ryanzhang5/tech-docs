package com.wm.corelib.concurrent;

import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Wrapper around ThreadPoolExecutor to provide more fine-grained control over the pool.<br /><br />
 *
 * The major things that are different from the default implementation are a custom ThreadFactory
 * (with a custom UncaughtExceptionHandler) and a custom RejectedExecutionHandler.<br /><br />
 *
 * ArrayBlockingQueue is used to store incoming tasks, keepAliveTime is specified in seconds<br />
 *
 * @since November 2005
 * @author Igor.Dralyuk@walmart.com
 */
public class WMThreadPoolExecutor extends ThreadPoolExecutor {

    /**
     * The number of this pool
     */
    private final int _number;

    /**
     * Number sequence (keeps track of how many pools we have created)
     */
    private static final AtomicInteger _numberSequence = new AtomicInteger(1);

    /**
     * The IO_BOUND pool should be used to process tasks that are not CPU intensive -- e.g I/O.<br />
     * The CPU_BOUND pool should be used to process CPU intensive tasks.<br />
     * Other pool types can be added in the future.
     */
    public enum PoolType {
        IO_BOUND, CPU_BOUND, INSTANT_CREDIT_ELIGIBILITY, INSTANT_CREDIT_QUICKSCREEN, OTHER, ASN_TP;

        public static PoolType parse(String s) {
            PoolType type = null;
            for (PoolType t : PoolType.values()) {
                if (t.toString().equals(s)) {
                    type = t;
                    break;
                }
            }
            if (type == null) {
                throw new RuntimeException("PoolType \"" + s + "\" doesn't exist");
            }
            return type;
        }
    }

    /**
     * The type of this pool
     */
    private final PoolType _type;

    /**
     * Identification String of this pool, composed using pool number, dash ('-') and pool type
     */
    private final String _poolID;

    /**
     * Our logger instance
     */
    private static final Logger _log = Logger.getLogger(WMThreadPoolExecutor.class.getName());

    /**
     * Support for pausing task execution in the pool (applies to new tasks only, i.e. if a task
     * is already running, we don't pause it.
     */
    private boolean _isPaused;
    private ReentrantLock _pauseLock = new ReentrantLock();
    private Condition _unpaused = _pauseLock.newCondition();

    /**
     * Maximum queue length
     */
    private final int _queueCapacity;

    /**
     * Start time for each Runnable - used to calculate execution time for each task
     */
    private final ConcurrentMap<Integer, Long> _startTimes = new ConcurrentHashMap<Integer, Long>();

    /**
     * Internal Pool Data Map - Raison d'etre    <br/><br />
     *
     * Each pool has some associated statistics it needs to keep track of (e.g. totalAcceptedRequests,
     * totalRejectedRequests, etc.)<br/><br />
     *
     * There are a couple creatures (<tt>WMRejectedExecutionHandler</tt>, <tt>WMUncaughtExceptionHandler</tt>) as well
     * as <tt>beforeExecute()</tt> and <tt>afterExecute()</tt> that update these statistics.<br/><br />
     *
     * The creatures need to be passed into the super() constructor when we obviously don't have our
     * WMThreadPoolExecutor (this) instance created, so we resort to creating a static map of <tt>InternalData</tt> objects.
     * Another way of saying this: we would like to pass a reference to an object that will be created in the future.
     * In the present we know that we will be able to look up the new object using "poolID", so
     * we establish "<i>loose coupling</i>" by mapping poolID to the data object.<br/><br />
     *
     * Once the WMThreadPoolExecutor instance is running and one of the creatures needs to update
     * a statistic, it will look up the <tt>InternalData</tt> object by doing <tt>_data.get(_poolID)</tt>,
     * access the member object by doing <tt>.objectName</tt> and update the statistic.
     * The whole thing may look like this: <tt>_data.get(_poolID).totalAcceptedRequests.getAndIncrement()</tt><br/><br />
     */
    private static final ConcurrentMap<String, InternalData> _data = new ConcurrentHashMap<String, InternalData>();

    /**
     * Creates a new WMThreadPoolExecutor with the given initial parameters.
     *
     * @param corePoolSize Pool doesn't shrink below this number
     * @param maximumPoolSize Pool doesn't grow beyond this number
     * @param keepAliveTime How long should threads be kept alive once created (in seconds).<br />
     *        Note: corePoolSize threads are alive forever (or until the pool is shutdown)
     * @param queueSize How large is the queue
     */
    public WMThreadPoolExecutor(PoolType type, int corePoolSize, int maximumPoolSize, long keepAliveTime, int queueSize) {
        super(corePoolSize, maximumPoolSize, keepAliveTime, TimeUnit.SECONDS, new ArrayBlockingQueue<Runnable>(queueSize));
        //super(corePoolSize, maximumPoolSize, keepAliveTime, TimeUnit.SECONDS, new WMQueue<Runnable>());
        _number = _numberSequence.getAndIncrement();
        _type = type;
        _poolID = _number + "-" + type;
        _queueCapacity = queueSize;
        _data.put(_poolID, new InternalData());

        setThreadFactory(new WMThreadFactory(_poolID));
        setRejectedExecutionHandler(new WMRejectedExecutionHandler(_poolID));

        if (_log.isLoggable(Level.FINE)) {
            _log.log(Level.FINE, "poolNumber = " + _number + ", poolType = " + type +
                    ", corePoolSize = " + corePoolSize + ", maximumPoolSize = " + maximumPoolSize +
                    ", keepAliveTime = " + keepAliveTime + " s, queueSize = " + queueSize);
        }
    }

    /**
     * Creates a new WMThreadPoolExecutor with the given initial parameters.
     *
     * @param corePoolSize Pool doesn't shrink below this number
     * @param maximumPoolSize Pool doesn't grow beyond this number
     * @param keepAliveTime How long should threads be kept alive once created (in seconds).<br />
     *        Note: corePoolSize threads are alive forever (or until the pool is shutdown)
     * @param queueSize How large is the queue
     */
    public WMThreadPoolExecutor(PoolType type, int corePoolSize, int maximumPoolSize, long keepAliveTime, int queueSize, ThreadFactory tf) {
        super(corePoolSize, maximumPoolSize, keepAliveTime, TimeUnit.SECONDS, new ArrayBlockingQueue<Runnable>(queueSize));
        //super(corePoolSize, maximumPoolSize, keepAliveTime, TimeUnit.SECONDS, new WMQueue<Runnable>());
        _number = _numberSequence.getAndIncrement();
        _type = type;
        _poolID = _number + "-" + type;
        _queueCapacity = queueSize;
        _data.put(_poolID, new InternalData());

        setThreadFactory(tf);
        setRejectedExecutionHandler(new WMRejectedExecutionHandler(_poolID));

        if (_log.isLoggable(Level.FINE)) {
            _log.log(Level.FINE, "poolNumber = " + _number + ", poolType = " + type +
                    ", corePoolSize = " + corePoolSize + ", maximumPoolSize = " + maximumPoolSize +
                    ", keepAliveTime = " + keepAliveTime + " s, queueSize = " + queueSize);
        }
    }
    /**
     * Method invoked prior to executing the given Runnable in the
     * given thread.  This method is invoked by thread <tt>t</tt> that
     * will execute task <tt>r</tt>.
     * It is used to provide support for pausing execution of tasks in this pool,
     * as well as collecting statistics and logging.
     *
     * @param t the thread that will run task r.
     * @param r the task that will be executed.
     */
    protected void beforeExecute(Thread t, Runnable r) {
        super.beforeExecute(t, r);

        InternalData data = _data.get(_poolID);
        if (data != null) data.totalAcceptedRequests.getAndIncrement();
        _startTimes.put(r.hashCode(), System.currentTimeMillis());

        _pauseLock.lock();

        try {
            while (_isPaused) {
                _unpaused.await();
            }
        } catch(InterruptedException ie) {
            t.interrupt();
        } finally {
            _pauseLock.unlock();
        }
    }

    /**
     * Method invoked upon completion of execution of the given Runnable.
     * This method is invoked by the thread that executed the task.
     * If non-null, the Throwable is the uncaught exception
     * that caused execution to terminate abruptly.
     *
     * @param r the runnable that has completed.
     * @param t the exception that caused termination, or null if
     * execution completed normally.
     */
    protected void afterExecute(Runnable r, Throwable t) {
        super.afterExecute(r, t);

        InternalData data = _data.get(_poolID);
        Long startTime = _startTimes.remove(r.hashCode());

        if (data != null && startTime != null) {
            data.totalCompletedRequests.getAndIncrement();
            data.totalExecutionTime.getAndAdd(System.currentTimeMillis() - startTime);
        }
    }

    /**
     * Initiates an orderly shutdown in which previously submitted
     * tasks are executed, but no new tasks will be
     * accepted. Invocation has no additional effect if already shut down.
     *
     * @throws SecurityException if a security manager exists and
     * shutting down this WMThreadPoolExecutor may manipulate threads that
     * the caller is not permitted to modify because it does not hold
     * {@link java.lang.RuntimePermission}<tt>("modifyThread")</tt>,
     * or the security manager's <tt>checkAccess</tt>  method denies access.
     */
    public void shutdown() {
        if (_log.isLoggable(Level.INFO)) _log.info(_type + " pool " + _number + " shutting down.");
        _data.remove(_poolID);
        super.shutdown();
    }

    /**
     * Attempts to stop all actively executing tasks, halts the
     * processing of waiting tasks, and returns a list of the tasks that were
     * awaiting execution.
     *
     * <p>This implementation cancels tasks via {@link Thread#interrupt},
     * so if any tasks mask or fail to respond to interrupts, they may never terminate.
     *
     * @return list of tasks that never commenced execution
     * @throws SecurityException if a security manager exists and shutting down this
     * WMThreadPoolExecutor may manipulate threads that the caller is not permitted to
     * modify because it does not hold {@link java.lang.RuntimePermission}<tt>("modifyThread")</tt>,
     * or the security manager's <tt>checkAccess</tt> method denies access.
     */
    public List<Runnable> shutdownNow() {
        if (_log.isLoggable(Level.INFO)) _log.info(_type + " pool " + _number + " shutting down now!");
        _data.remove(_poolID);

        return super.shutdownNow();
    }

    /**
     * Pauses execution of tasks in this pool.
     */
    public void pause() {
        if (_log.isLoggable(Level.INFO)) _log.info(_poolID + " pause()");
        _pauseLock.lock();
        try {
            _isPaused = true;
        } finally {
            _pauseLock.unlock();
        }
    }

    /**
     * Resumes execution of tasks in this pool.
     */
    public void resume() {
        if (_log.isLoggable(Level.INFO)) _log.info(_poolID + " resume()");
        _pauseLock.lock();
        try {
            _isPaused = false;
            _unpaused.signalAll();
        } finally {
            _pauseLock.unlock();
        }
    }

    /**
     * Retrieves the total number of accepted requests.
     *
     * @return long
     */
    public long getTotalAcceptedRequests() {
        InternalData data = _data.get(_poolID);
        if (data != null) return data.totalAcceptedRequests.get();
        else return -1;
    }

    /**
     * Retrieves the total number of completed requests.
     *
     * @return long
     */
    public long getTotalCompletedRequests() {
        InternalData data = _data.get(_poolID);
        if (data != null) return data.totalCompletedRequests.get();
        else return -1;
    }

    /**
     * Retrieves the total number of rejected requests.
     *
     * @return long
     */
    public long getTotalRejectedRequests() {
        InternalData data = _data.get(_poolID);
        if (data != null) return data.totalRejectedRequests.get();
        else return -1;
    }

    /**
     * Retrieves the total number of uncaught exceptions.
     *
     * @return long
     */
    public long getTotalUncaughtExceptions() {
        InternalData data = _data.get(_poolID);
        if (data != null) return data.totalUncaughtExceptions.get();
        else return -1;
    }

    /**
     * Retrieves the total execution time for all completed requests.
     *
     * @return long
     */
    public long getTotalExecutionTime() {
        InternalData data = _data.get(_poolID);
        if (data != null) return data.totalExecutionTime.get();
        else return -1;
    }

    /**
     * How large is the queue.
     *
     * @return int
     */
    public int getQueueCapacity() {
        return _queueCapacity;
    }

    /**
     * How many tasks are on the queue.
     *
     * @return int
     */
    public int getQueueSize() {
        return getQueue().size();
    }

    /**
     * Retrieves the type of this pool<br />
     * Current possible values are <tt>PoolType.CPU_BOUND</tt> and <tt>PoolType.IO_BOUND</tt>
     *
     * @return PoolType
     */
    public PoolType getType() {
        return _type;
    }

    /**
     * Retrieves the Identification String of this pool
     *
     * @return String
     */
    public String getID() {
        return _poolID;
    }

    /**
     * Retrieves pool statistics data object.
     *
     * @return PoolStats
     */
    public PoolStats getStats() {
        return new PoolStats(_number, _type, _poolID,
                getQueueSize(),
                getTotalAcceptedRequests(),
                getTotalCompletedRequests(),
                getTotalUncaughtExceptions(),
                getTotalRejectedRequests(),
                getTotalExecutionTime());
    }

    /**
     * Creates a PoolStats object from the given InternalData object.
     * Used by <tt>resetStats()</tt>.
     *
     * @param data
     * @return PoolStats
     */
    private PoolStats getStats(InternalData data) {
        if (data == null) return null;
        else return new PoolStats(_number, _type, _poolID,
                getQueueSize(),
                data.totalAcceptedRequests.get(),
                data.totalCompletedRequests.get(),
                data.totalUncaughtExceptions.get(),
                data.totalRejectedRequests.get(),
                data.totalExecutionTime.get());
    }

    /**
     * Reset statistics
     *
     * @return old statistics
     */
    public PoolStats resetStats() {
        if (_log.isLoggable(Level.INFO)) _log.info(_poolID + " resetStats()");
        InternalData newData = new InternalData(), oldData;
        oldData = _data.put(_poolID, newData);
        return getStats(oldData);
    }

    /**
     * This class is used to provide custom Threads for the pool.
     */
    private static class WMThreadFactory implements ThreadFactory {
        private final ThreadGroup group;
        private final AtomicInteger threadNumber = new AtomicInteger(1);
        private final String namePrefix;
        private final WMUncaughtExceptionHandler exceptionHandler;

        public WMThreadFactory(String poolID) {
            SecurityManager s = System.getSecurityManager();
            group = (s != null) ? s.getThreadGroup() : Thread.currentThread().getThreadGroup();
            namePrefix = "wm-pool-" + poolID.toLowerCase() + "-thread-";
            exceptionHandler = new WMUncaughtExceptionHandler(poolID);
        }

        public Thread newThread(Runnable r) {
            Thread t = new Thread(group, r, namePrefix + threadNumber.getAndIncrement(), 0);
            t.setUncaughtExceptionHandler(exceptionHandler);
            if (!t.isDaemon()) t.setDaemon(true);
            if (t.getPriority() != Thread.NORM_PRIORITY) t.setPriority(Thread.NORM_PRIORITY);
            return t;
        }
    }

    /**
     * Log the rejection, count it and delegate to the ThreadPoolExecutor.CallerRunsPolicy<br/><br/>
     *
     * Policy summary: the thread that invokes execute() will run the task itself if the task is rejected.<br/>
     * This provides a simple feedback control mechanism that will slow down the rate that new tasks are submitted.<br /><br />
     */
    private static class WMRejectedExecutionHandler extends ThreadPoolExecutor.CallerRunsPolicy {
        private final String poolID;

        public WMRejectedExecutionHandler(String id) {
            poolID = id;
        }

        public void rejectedExecution(Runnable runnable, ThreadPoolExecutor threadPoolExecutor) {
            _log.warning("Queue is full or pool is down, running the task in the calling thread");
            InternalData data = _data.get(poolID);
            if (data != null) data.totalRejectedRequests.getAndIncrement();
            super.rejectedExecution(runnable, threadPoolExecutor);
        }
    }

    /**
     * Log the exception
     */
    private static class WMUncaughtExceptionHandler implements Thread.UncaughtExceptionHandler {
        private final String poolID;

        public WMUncaughtExceptionHandler(String id) {
            poolID = id;
        }

        public void uncaughtException(Thread thread, Throwable throwable) {
            _log.log(Level.WARNING, "{0}: {1} at line {2} of {3}",
                    new Object[] { thread.getName(), throwable.toString(),
                            throwable.getStackTrace()[0].getLineNumber(),
                            throwable.getStackTrace()[0].getFileName()});
            InternalData data = _data.get(poolID);
            if (data != null) data.totalUncaughtExceptions.getAndIncrement();
        }
    }

    /**
     * Read-only data object used to transfer pool statistics.
     */
    public class PoolStats {
        final int poolNumber;
        final PoolType poolType;
        final String poolID;
        final int totalQueuedRequests;
        final long totalAcceptedRequests;
        final long totalCompletedRequests;
        final long totalRejectedRequests;
        final long totalUncaughtExceptions;
        final long totalExecutionTime;
        long averageExecutionTime;

        public PoolStats(int poolNumber, PoolType poolType, String poolID,
                         int totalQueuedRequests, long totalAcceptedRequests, long totalCompletedRequests,
                         long totalUncaughtExceptions, long totalRejectedRequests, long totalExecutionTime) {
            this.poolNumber = poolNumber;
            this.poolType = poolType;
            this.poolID = poolID;
            this.totalQueuedRequests = totalQueuedRequests;
            this.totalAcceptedRequests = totalAcceptedRequests;
            this.totalCompletedRequests = totalCompletedRequests;
            this.totalUncaughtExceptions = totalUncaughtExceptions;
            this.totalRejectedRequests = totalRejectedRequests;
            this.totalExecutionTime = totalExecutionTime;
        }

        public int getPoolNumber() {
            return poolNumber;
        }

        public PoolType getPoolType() {
            return poolType;
        }

        public String getPoolID() {
            return poolID;
        }

        public int getTotalQueuedRequests() {
            return totalQueuedRequests;
        }

        public long getTotalAcceptedRequests() {
            return totalAcceptedRequests;
        }

        public long getTotalCompletedRequests() {
            return totalCompletedRequests;
        }

        public long getTotalUncaughtExceptions() {
            return totalUncaughtExceptions;
        }

        public long getTotalRejectedRequests() {
            return totalRejectedRequests;
        }

        public long getTotalExecutionTime() {
            return totalExecutionTime;
        }

        /**
         * Return averageExecutionTime. Use previously calculated result.
         * Avoid "Divide by zero" error by checking whether the denominator is equal to zero.
         *
         * @return averageExecutionTime
         */
        public long getAverageExecutionTime() {
            if (averageExecutionTime == 0)
                averageExecutionTime = (totalCompletedRequests == 0) ? 0 : (totalExecutionTime / totalCompletedRequests);
            return averageExecutionTime;
        }

        public String toString() {
            StringBuffer sb = new StringBuffer().append("\nStatistics for Thread Pool ").append(poolNumber)
                    .append(", ").append(poolType)
                    .append("\nTotal Queued    Requests   : ").append(totalQueuedRequests)
                    .append("\nTotal Accepted  Requests   : ").append(totalAcceptedRequests)
                    .append("\nTotal Completed Requests   : ").append(totalCompletedRequests)
                    .append("\nTotal Uncaught  Exceptions : ").append(totalUncaughtExceptions)
                    .append("\nTotal Rejected  Requests   : ").append(totalRejectedRequests)
                    .append("\nAverage Execution Time     : ").append(getAverageExecutionTime()).append(" ms");
            return sb.toString();
        }
    }

    /**
     * Stores pool statistics.
     */
    private static class InternalData {
        final AtomicLong totalUncaughtExceptions = new AtomicLong(0);
        final AtomicLong totalAcceptedRequests = new AtomicLong(0);
        final AtomicLong totalCompletedRequests = new AtomicLong(0);
        final AtomicLong totalRejectedRequests = new AtomicLong(0);
        final AtomicLong totalExecutionTime = new AtomicLong(0);
    }
}

