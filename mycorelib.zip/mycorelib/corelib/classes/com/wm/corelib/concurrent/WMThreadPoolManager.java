package com.wm.corelib.concurrent;

import com.wm.corelib.concurrent.WMThreadPoolExecutor.PoolType;
import com.wm.corelib.jmxadmin.JmxUtil;
import com.wm.corelib.management.ThreadPool;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Arrays;
  
import com.wm.corelib.config.AppConfig;

/**
 * Facility for managing thread pools.<br /><br />
 *
 * WMThreadPoolExecutor is the class that implements a thread pool.<br /><br />
 *
 * This class makes the assumption that a single JVM should not need more than one instance of each pool type.
 * i.e. one IO_BOUND pool and one CPU_BOUND pool. If this assumption turns out to be incorrect,
 * another thread pool can be created directly by calling the <tt>WMThreadPoolExecutor</tt> or this
 * class may be modified to support multiple pools of the same type.<br /><br />
 *
 * Usage:
 *
 * <pre>

 * import java.util.concurrent.Callable;
 * import java.util.concurrent.FutureTask;
 * import com.wm.corelib.concurrent.WMThreadPoolExecutor;
 * import com.wm.corelib.concurrent.WMThreadPoolExecutor.PoolType;
 * import com.wm.corelib.concurrent.WMThreadPoolManager;
 *
 * public class Foo {
 *     public void bar() {
 *         WMThreadPoolExecutor pool = WMThreadPoolManager.getPool(); // default pool is IO_BOUND
 *
 *         pool.execute(new Runnable() {
 *             public void run() {
 *                 // Do something useful
 *             }
 *         });
 *
 *         // or, for CPU intensive tasks:
 *
 *         WMThreadPoolExecutor cpu_pool = WMThreadPoolManager.getPool(PoolType.CPU_BOUND);
 *
 *         FutureTask&lt;String&gt; ft = new FutureTask&lt;String&gt;(new Callable&lt;String&gt;() {
 *             public String call() {
 *                 // Do something useful
 *                 return "baz";
 *             }
 *         });
 *
 *         cpu_pool.execute(ft);
 *     }
 * }
 * </pre>
 *
 * @since November 2005
 * @version $Id: WMThreadPoolManager.java,v 1.4 2012/03/30 22:42:01 cshah Exp $
 * @author Igor.Dralyuk@walmart.com
 */
public class WMThreadPoolManager {

    /**
     * Used by <tt>loadParams()</tt> to read System properties.
     */
    public static final String WM_THREADPOOL_PREFIX_KEY = "com.wm.corelib.concurrent.threadpool";

    /**
     * Used by <tt>loadParams()</tt> to read System properties.
     */
    public static final String WM_THREADPOOL_COUNT_KEY = "count";

    /**
     * Used by <tt>loadParams()</tt> to read System properties.
     */
    public static final String WM_THREADPOOL_TYPE_KEY = "type";

    /**
     * Used by <tt>loadParams()</tt> to read System properties.
     */
    public static final String WM_THREADPOOL_CORESIZE_KEY = "coresize";

    /**
     * Used by <tt>loadParams()</tt> to read System properties.
     */
    public static final String WM_THREADPOOL_MAXSIZE_KEY = "maxsize";

    /**
     * Used by <tt>loadParams()</tt> to read System properties.
     */
    public static final String WM_THREADPOOL_KEEPALIVE_KEY = "keepalive";

    /**
     * Used by <tt>loadParams()</tt> to read System properties.
     */
    public static final String WM_THREADPOOL_QUEUESIZE_KEY = "queuesize";

    /** MBeans are registered with this name prefix */
    public static final String WM_THREADPOOL_MBEAN_NAME_PREFIX = "ThreadPool:type=";

    /**
     * Our Logger instance
     */
    private static final Logger _log = Logger.getLogger(WMThreadPoolManager.class.getName());

    /**
     * Map of thread pools that we are managing
     */
    private static ConcurrentMap<PoolType, WMThreadPoolExecutor> _pools = new ConcurrentHashMap<PoolType, WMThreadPoolExecutor>();

    /**
     * Map of initialization parameters for thread pools that we are managing
     */
    private static ConcurrentMap<PoolType, PoolParams> _poolParams = new ConcurrentHashMap<PoolType, PoolParams>();

    /**
     * Our default pool type is IO_BOUND
     */
    public static final PoolType DEFAULT_POOL_TYPE = PoolType.IO_BOUND;

    private static ThreadFactory tf = null;
    
    static { // Try to initialize statically.
        try {
            loadParams();
        } catch (Exception e) {
            _log.log(Level.SEVERE, "Cannot initialize", e);
        }
    }

    public WMThreadPoolManager() {
    	 super();
    	}

    public WMThreadPoolManager(ThreadFactory tf) {
    	  super();
    	 this.tf = tf;
    	}
    /**
     * Retrieves parameters from System properties.<br /><br />
     *
     * Here is the format of what it expects:
     *
     * <pre>
     * com.wm.corelib.concurrent.threadpool.count = 2
     *
     * com.wm.corelib.concurrent.threadpool.1.type = IO_BOUND
     * com.wm.corelib.concurrent.threadpool.1.coresize = 100
     * com.wm.corelib.concurrent.threadpool.1.maxsize = 100
     * com.wm.corelib.concurrent.threadpool.1.keepalive = 300
     * com.wm.corelib.concurrent.threadpool.1.queuesize = 10000
     *
     * com.wm.corelib.concurrent.threadpool.2.type = CPU_BOUND
     * com.wm.corelib.concurrent.threadpool.2.coresize = 2
     * com.wm.corelib.concurrent.threadpool.2.maxsize = 2
     * com.wm.corelib.concurrent.threadpool.2.keepalive = 300
     * com.wm.corelib.concurrent.threadpool.2.queuesize = 1000
     * </pre>
     */
    public static void loadParams() {
        try {
            int poolCount = Integer.parseInt(AppConfig.getInstance().getProperty(WM_THREADPOOL_PREFIX_KEY + "." + WM_THREADPOOL_COUNT_KEY));

            for (int i = 1; i <= poolCount; i++) {
                PoolType type = PoolType.parse(AppConfig.getInstance().getProperty(WM_THREADPOOL_PREFIX_KEY + "." + i + "." + WM_THREADPOOL_TYPE_KEY));
                int coresize = Integer.parseInt(AppConfig.getInstance().getProperty(WM_THREADPOOL_PREFIX_KEY + "." + i + "." + WM_THREADPOOL_CORESIZE_KEY));
                int maxsize = Integer.parseInt(AppConfig.getInstance().getProperty(WM_THREADPOOL_PREFIX_KEY + "." + i + "." + WM_THREADPOOL_MAXSIZE_KEY));
                int keepalive = Integer.parseInt(AppConfig.getInstance().getProperty(WM_THREADPOOL_PREFIX_KEY + "." + i + "." + WM_THREADPOOL_KEEPALIVE_KEY));
                int queuesize = Integer.parseInt(AppConfig.getInstance().getProperty(WM_THREADPOOL_PREFIX_KEY + "." + i + "." + WM_THREADPOOL_QUEUESIZE_KEY));

                PoolParams p = new PoolParams(coresize, maxsize, keepalive, queuesize);

                if (_log.isLoggable(Level.FINE)) {
                    _log.fine("Read System properties for " + type + " thread pool: " + p.toString());
                }
                _poolParams.put(type, p);
            }
        } catch (Exception e) {
            _log.log(Level.SEVERE, "Unable to load parameters (" + e.getMessage() + "), using defaults.");
            getPoolParams(PoolType.CPU_BOUND);
            getPoolParams(PoolType.IO_BOUND);
        }
    }

    /**
     * Retrieves pool parameters for the given pool type.<br />
     * Checks the <tt>_poolParams</tt> first, and if not found creates a new PoolParams object and puts it into <tt>_poolParams</tt>.
     */
    private static PoolParams getPoolParams(PoolType t) {
        PoolParams p = _poolParams.get(t);
        if (p == null) {
            p = new PoolParams();
            _poolParams.put(t, p);
            _log.severe(t + " thread pool parameters haven't been initialized, using default " + p);
        }
        return p;
    }

    /**
     * Creates the given pool type with the given parameters.
     */
    private static WMThreadPoolExecutor createPool(PoolType t, PoolParams p) {
    	if (tf != null) {
    	   return new WMThreadPoolExecutor(t, p.getCoreSize(), p.getMaxSize(), p.getKeepAliveTime(), p.getQueueSize(),tf);
    	}
        return new WMThreadPoolExecutor(t, p.getCoreSize(), p.getMaxSize(), p.getKeepAliveTime(), p.getQueueSize());
    }

    /**
     * Initialize all pools.
     */
    public static synchronized void init() {
        for (PoolType t : _poolParams.keySet()) {
            initPool(t);
        }
    }

    /**
     * Initialize the pool of given type.
     */
    public static void initPool(PoolType t) {
        if (_log.isLoggable(Level.INFO)) _log.info("Initializing " + t + " thread pool");

        WMThreadPoolExecutor newPool = createPool(t, getPoolParams(t));
        WMThreadPoolExecutor oldPool = _pools.put(t, newPool);

        if (oldPool != null) {
            String oldName = WM_THREADPOOL_MBEAN_NAME_PREFIX + oldPool.getType();
            if (_log.isLoggable(Level.FINE)) _log.fine("Unregistering old mbean " + oldName);
            JmxUtil.unRegisterMBean(oldName);
            oldPool.shutdown();
        }

        String newName = WM_THREADPOOL_MBEAN_NAME_PREFIX + newPool.getType();

        try {
            ThreadPool mbean = new ThreadPool(newPool);
            if (_log.isLoggable(Level.INFO)) _log.info("Registering " + newName);
            JmxUtil.registerMBean(newName, mbean, null);
        } catch (Exception e) {
            _log.log(Level.SEVERE, "Unable to initialize MBean " + newName, e);
        }

        if (_log.isLoggable(Level.INFO)) _log.info(t + " thread pool ready");
    }

    /**
     * Shutdown the pool of given type.
     */
    public static void shutdownPool(PoolType t) {
        if (_log.isLoggable(Level.INFO)) _log.info(t + " thread pool shutdown requested");
        _pools.get(t).shutdown();
    }

    /**
     * Shutdown all pools.
     */
    public static void shutdownAll() {
        for (PoolType t : _poolParams.keySet()) {
            shutdownPool(t);
        }
    }

    /**
     * Convenience method to return the default thread pool.<br />
     * Can be null if the pool hasn't been initialized yet.
     *
     * @return WMThreadPoolExecutor
     */
    public static WMThreadPoolExecutor getPool() {
        return _pools.get(DEFAULT_POOL_TYPE);
    }

    /**
     * Can be null if the pool hasn't been initialized yet.
     *
     * @return WMThreadPoolExecutor
     */
    public static WMThreadPoolExecutor getPool(PoolType t) {
        return _pools.get(t);
    }

    public static class PoolParams {

        public static final int DEFAULT_CORE_POOL_SIZE = 10;
        public static final int DEFAULT_MAXIMUM_POOL_SIZE = 100;
        public static final int DEFAULT_KEEP_ALIVE_TIME = 60 * 5; // 300 seconds = 5 minutes
        public static final int DEFAULT_QUEUE_SIZE = 10000;

        int coreSize = DEFAULT_CORE_POOL_SIZE;
        int maxSize = DEFAULT_MAXIMUM_POOL_SIZE;
        int keepAliveTime = DEFAULT_KEEP_ALIVE_TIME;
        int queueSize = DEFAULT_QUEUE_SIZE;

        public PoolParams() {
            // use default params
        }

        public PoolParams(int coreSize, int maxSize, int keepAliveTime, int queueSize) {
            this.coreSize = coreSize;
            this.maxSize = maxSize;
            this.keepAliveTime = keepAliveTime;
            this.queueSize = queueSize;
        }

        public int getCoreSize() {
            return coreSize;
        }

        public void setCoreSize(int coreSize) {
            this.coreSize = coreSize;
        }

        public int getMaxSize() {
            return maxSize;
        }

        public void setMaxSize(int maxSize) {
            this.maxSize = maxSize;
        }

        public int getKeepAliveTime() {
            return keepAliveTime;
        }

        public void setKeepAliveTime(int keepaliveTime) {
            this.keepAliveTime = keepaliveTime;
        }

        public int getQueueSize() {
            return queueSize;
        }

        public void setQueueSize(int queueSize) {
            this.queueSize = queueSize;
        }

        public String toString() {
            StringBuffer sb = new StringBuffer().append("PoolParams: ")
                    .append("coreSize = ").append(coreSize)
                    .append(", maxSize = ").append(maxSize)
                    .append(", keepaliveTime = ").append(keepAliveTime)
                    .append(" s, queueSize = ").append(queueSize);
            return sb.toString();
        }
    }
}
