
package com.wm.corelib.bool;

import com.wm.corelib.dbc.Assert;
import com.wm.corelib.core.IState;

public class Predicate implements IPredicate
{
  public Predicate()
  {
  }
  public String getName() { return _name; }
  public void setName( String v ) 
  { 
    Assert.pre( v != null );
    _name = v; 
  }
  public boolean eval( IState state )
  {
    return _eval;
  }

  public void setValue( boolean v )
  {
    _eval = v;
  }
  public boolean getValue()
  {
    return _eval;
  }
  public String toString()
  {
    return _name;
  }
  private boolean _eval = false;
  private String  _name = null;
}
