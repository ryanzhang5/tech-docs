
package com.wm.corelib.bool;

import java.util.StringTokenizer;
import java.util.ArrayList;
import java.text.ParseException;
import com.wm.corelib.util.StringUtil;
import com.wm.corelib.dbc.Assert;

public class BoolExpParser implements IBoolFactory
{
  ////////////////////////////////////////////////////////////////////
  // public object interface
  ////////////////////////////////////////////////////////////////////
  /**
     returns IBool created by parsing s.
     getBoolInstance( String boolName ) is called every time boolName is encountered
     bool_exp := boolName 
                 bop( bool_exp, bool_exp )
                 uop( bool_exp )
    
     bop := AND
            OR
            XOR
    
     uop := NOT
     AND( isOneDone OR( canEnterTwo NOT( canEnterThree ) ) )
  **/
  public IBool parse( String s ) throws ParseException
  {
    _allTokens = getTokens( s );
    _currToken = 0;
    if ( !hasMoreTokens() )
      return null;
    return parse();
  }

  public IBoolFactory getIBoolFactory()
  {
    if ( _boolFactory == null )
    {
      _boolFactory = this;
    }
    return _boolFactory;
  }

  public BoolExpParser( IBoolFactory bf )
  {
    Assert.pre( bf != null );
    _boolFactory = bf;
  }

  public BoolExpParser()
  {
  }

  public IPredicate makeIBoolInstance( String boolName )
  {
    IPredicate rv = new Predicate();
    rv.setName( boolName );
    return rv;
  }

  ////////////////////////////////////////////////////////////////////
  // private class interface
  ////////////////////////////////////////////////////////////////////
  private static final String NOT          = "NOT";
  private static final String AND          = "AND";
  private static final String OR           = "OR";
  private static final String XOR          = "XOR";
  private static final String OPEN_PARENT  = "(";
  private static final String CLOSE_PARENT = ")";
  private static final String COMMA        = ",";

  ////////////////////////////////////////////////////////////////////
  // private object interface
  ////////////////////////////////////////////////////////////////////
  private IBool parse() throws ParseException
  {
    IBool rv = null;
    String currToken = getCurrToken();
    if ( NOT.equals( currToken ) )
    {
      return parseNot();
    }
    if ( AND.equals( currToken ) )
    {
      return parseAnd();
    }
    if ( OR.equals( currToken ) )
    {
      return parseOr();
    }
    if ( XOR.equals( currToken ) )
    {
      return parseXor();
    }
    return parseOp();
  }

  private boolean parseToken( String token ) throws ParseException
  {
    Assert.pre( token != null );
    Assert.pre( token.length() > 0 );
    if ( token.equals( getCurrToken() ) )
    {
      nextToken();
      return true;
    }
    else
    {
      String allParsed = _parsedTokens.toString();
      String msg       = "Syntax Error: " + token + " is expected at " + allParsed.length() + " in " + allParsed;
      throw new ParseException( msg, allParsed.length() );
    }
  }
  private IBool parseOp() throws ParseException
  {
    String currToken = getCurrToken();
    if ( ! isValidOp( currToken ) )
    {
      String allParsed = _parsedTokens.toString();
      throw new ParseException( "Invalid Operator Name " + currToken, allParsed.length() );
    }
    nextToken();
    return getIBoolFactory().makeIBoolInstance( currToken );
  }
  private boolean isValidOp( String op )
  {
    return !op.equals( OPEN_PARENT ) 
           && !op.equals( CLOSE_PARENT ) 
           && !op.equals( COMMA ) ;

  }
  private IBool parseAnd() throws ParseException
  {
    parseToken( AND );
    parseToken( OPEN_PARENT );
    IBool op1 = parse();
    parseToken( COMMA );
    IBool op2 = parse();
    parseToken( CLOSE_PARENT );
    return new And( op1, op2 );
  }

  private IBool parseXor() throws ParseException
  {
    parseToken( XOR );
    parseToken( OPEN_PARENT );
    IBool op1 = parse();
    parseToken( COMMA );
    IBool op2 = parse();
    parseToken( CLOSE_PARENT );
    return new Xor( op1, op2 );
  }

  private IBool parseOr() throws ParseException
  {
    parseToken( OR );
    parseToken( OPEN_PARENT );
    IBool op1 = parse();
    parseToken( COMMA );
    IBool op2 = parse();
    parseToken( CLOSE_PARENT );
    return new Or( op1, op2 );
  }
  private IBool parseNot() throws ParseException
  {
    parseToken( NOT );
    parseToken( OPEN_PARENT );
    IBool op = parse();
    parseToken( CLOSE_PARENT );
    return new Not( op );
  }

  private String[] getTokens( String s )
  {
    try
    {
    s = StringUtil.stripWhitespace( s ); 
    StringTokenizer st = new StringTokenizer( s, "(),", true );
    ArrayList       al = new ArrayList();
    while ( st.hasMoreTokens() )
    {
      String t = st.nextToken();
      al.add( t );
    }
    String rv[] = new String[al.size()];
    al.toArray( rv );
    return rv;
    }
    catch ( Exception e )
    {
    }
    return null;
  }

  private String getCurrToken()
  {
    if ( !hasMoreTokens() )
      return StringUtil.BLANK_STRING;
    return _allTokens[_currToken];
  }

  private void nextToken()
  {
    _parsedTokens.append( getCurrToken() );
    _currToken++;
  }

  private boolean hasMoreTokens()
  {
    return _currToken < _allTokens.length;
  }

  private String _allTokens[] = null;
  private int    _currToken = 0;
  private StringBuffer _parsedTokens = new StringBuffer();
  private IBoolFactory _boolFactory  = null;

  ////////////////////////////////////////////////////////////////////
  // debug
  ////////////////////////////////////////////////////////////////////
  public static void main( String args[] )
  {
      try
      {
        BoolExpParser exp = new BoolExpParser();
        //IBool b = exp.parse( "zero" );
        IBool b = exp.parse( "( zero, NOT( AND( one, two ) )" );
        System.out.println( b );
      }
      catch ( ParseException e )
      {
        System.out.println( e );
      }
  }

}
