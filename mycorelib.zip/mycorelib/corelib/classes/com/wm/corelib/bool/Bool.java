
package com.wm.corelib.bool;

import com.wm.corelib.core.IState;

public class Bool implements IBool
{
  public Bool( String name )
  {
    _name = name;
  }
  public Bool( String name, boolean v )
  {
    _eval = v;
  }

  public boolean eval( IState state )
  {
    return _eval;
  }

  public String toString()
  {
    return _name;
  }
  private boolean _eval = false;
  private String  _name = null;
}
