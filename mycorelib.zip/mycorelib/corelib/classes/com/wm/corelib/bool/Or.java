
package com.wm.corelib.bool;
import com.wm.corelib.core.IState;

public class Or implements IBool
{
  public boolean eval( IState state )
  {
    return _op1.eval( state ) || _op2.eval( state );
  }

  public Or( IBool op1, IBool op2 )
  {
    _op1 = op1;
    _op2 = op2;
  }

  public String toString()
  {
    return "OR( " + _op1 + ", " + _op2 + " )";
  }

  private IBool _op1 = null;
  private IBool _op2 = null;
}
