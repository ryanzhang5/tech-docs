
package com.wm.corelib.bool;

import com.wm.corelib.dbc.Assert;
import com.wm.corelib.core.IState;

public class Always extends Predicate
{
  public Always()
  {
    super();
  }
  public boolean eval( IState state )
  {
    return true;
  }

}
