
package com.wm.corelib.bool;

import com.wm.corelib.core.IState;

public interface IBool
{
  public boolean eval( IState s );
}
