package com.wm.corelib.introspect;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PackageUtil
{

  /**
   * @return array of Class objects that belong to the specified
   *         package. Never returns null.
   */
  public static Class[] getPackageClasses( String packageName )
    throws IOException
  {
    if ( packageName == null || "".equals( packageName.trim() ) )
      return new Class[0];
    Class[] rv = null;
    ArrayList classes = new ArrayList();
    // A "resource" (as far as I can tell) is a specific class file
    // or directory within the CLASSPATH
    String resourceName = packageName.replace( '.', File.separatorChar );
    Enumeration resources = ClassLoader.getSystemClassLoader().getResources( resourceName );
    while ( resources.hasMoreElements() )
    {
      Object resourceObj = resources.nextElement();
      String resourceLocation = resourceObj.toString();
      Matcher fileMatcher = fileURLPattern.matcher( resourceLocation );
      Matcher jarMatcher  = jarURLPattern.matcher( resourceLocation );
      boolean isJarFile = false;
      File resourceFile = null;
      String classFilePattern = null;
      if ( fileMatcher.matches() ) {
        resourceFile = new File( fileMatcher.group( 1 ) );
        classFilePattern = resourceFile.getAbsolutePath() + File.separator + ".+\\.class";
      } else if ( jarMatcher.matches() ) {
        isJarFile = true;
        resourceFile = new File( jarMatcher.group( 1 ) );
        classFilePattern = jarMatcher.group(2) + "/([^/\\\\]+)\\.class";
      }
      if ( resourceFile == null )
      {
        System.err.println( "Unknown resource URL[" + resourceLocation + "]" );
        continue; // Unknown file type
      }
      if ( isJarFile ) {
        // Jar/Zip file
        JarFile jarFile = new JarFile( resourceFile, true );
        Enumeration jarEntries = jarFile.entries();
        while ( jarEntries.hasMoreElements() )
        {
          Object o = jarEntries.nextElement();
          if ( ! (o instanceof JarEntry) )
          {
            System.err.println( "Could not read java.util.jar.JarFile entry of type[" + o.getClass().getName() + "]" );
            continue;
          }
          JarEntry je = (JarEntry) o;
          if ( Pattern.matches( classFilePattern, je.getName() ) ) {
            // We found a (hopefully) valid class
            String className = je.getName().replace( File.separatorChar, '.' ).replaceAll( "\\.class$", "" );
            try {
              Class c = Class.forName( className );
              classes.add( c );
            } catch ( Throwable t ) {
              System.err.println( "Exception when loading class[" + className + "] --> " + t.getMessage() );
              t.printStackTrace( System.err );
            }
          } else {
            // Ignore this entry
          }
        }
      } else {
        // Regular directory
        File[] fsClassFiles = resourceFile.listFiles();
        if ( fsClassFiles != null ) {
          // We found (hopefully) some valid class files
          for ( int pos = 0; pos < fsClassFiles.length; ++pos )
          {
            if (    fsClassFiles[pos].isFile()
                 && Pattern.matches( classFilePattern, fsClassFiles[pos].getAbsolutePath() ) ) {
              String className = packageName + "." + fsClassFiles[pos].getName();
              className = className.replaceAll( "\\.class$", "" );
              try {
                Class c = Class.forName( className );
                classes.add( c );
              } catch ( Throwable t ) {
                System.err.println( "Exception when loading class[" + className + "] --> " + t.getMessage() );
                t.printStackTrace( System.err );
              }
            } else {
              // Ignore this file
            }
          }
        } else {
          // Uh-oh, I/O exception or something went wrong when reading the
          // directory
        }
      }
    }
    rv = new Class[ classes.size() ];
    classes.toArray( rv );
    //assert rv != null : "Violated contract: returning null value in " + ClassUtil.class.getName() + ".getPackageClasses(String)";
    return rv;
  }

  public static void main( String[] args )
    throws Exception
  {
    for ( int pos = 0; pos < args.length; ++pos )
    {
      Class[] classes = getPackageClasses( args[pos] );
      System.out.println( "Loaded " + classes.length + " classes from package[" + args[pos] + "]" );
      for ( int pos2 = 0; pos2 < classes.length; ++pos2 )
      {
        System.out.println( "\t" + classes[pos2].getName() );
      }
    }
  }

  private static final Pattern fileURLPattern = Pattern.compile( "^file:(.+)$" );
  private static final Pattern jarURLPattern  = Pattern.compile( "^jar:file:(.+)!/(.+)$" );
}
