
package com.wm.corelib.action;

import com.wm.corelib.core.IState;

/**
  Sequence implementation.
  This is an aggregate action that will sequencially execute all contained actions objects.
  All actions in a sequence are independent of each other and will cause rollback method to
  be called.  A Sequence Aggregate action's execution always succeedes.
**/
public class Sequence extends AggregateAction
{
  /**
    Construct Sequence object.
    @param actions non-empty array of actions to be contained in this transaction.
  **/
  public Sequence( IAction actions[] )
  {
    super( actions );
  }
 
  ///////////////////////////////////////////////////////////////////
  // IAction interface START
  ///////////////////////////////////////////////////////////////////
  /**
    Execute all actions in this aggregate in order.
    All actions in a sequence are independent.  No rollbacks will be called.
    A sequence of actions always succeeds.
    @return always returns true.
  **/
  public boolean execute( IState state )
  {
    IAction actions[] = getActions();
    for ( int i = 0; i < actions.length; i++ )
    {
      actions[i].execute( state );
    }
    return true;
  }

  /**
    Rollback all actions in this aggregate.
    This can happen only if this aggregate was a part of larger transaction.
  **/
  public void rollback( IState state )
  {
    rollbackActions( state );
  }

  public String toString()
  {
    return "SEQ( " + super.toString() + " )";
  }
  ///////////////////////////////////////////////////////////////////
  // IAction interface END
  ///////////////////////////////////////////////////////////////////
}
