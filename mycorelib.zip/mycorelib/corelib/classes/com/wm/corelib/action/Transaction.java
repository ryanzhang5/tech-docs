
package com.wm.corelib.action;

import com.wm.corelib.core.IState;

/**
  Transaction implementation.
  This is an aggregate action that will sequencially execute all contained actions objects.
  If an execution fails, rollback method will be called on all executed action objects and
  processing will terminate.
**/
public class Transaction extends AggregateAction
{
  /**
    Create Transaction object.
    @param actions non-empty array of actions to be contained in this transaction.
  **/
  public Transaction( IAction actions[] )
  {
    super( actions );
  }
 
  ///////////////////////////////////////////////////////////////////
  // IAction interface START
  ///////////////////////////////////////////////////////////////////
  /**
    Execute all actions in this aggregate in order.
    Try to call execute( IState ) method on every contained action object
    in order.  If execute( IState ) method returns false, then rollback( IState )
    method will be called on every execute object and false will be returned.
    @return true if all contained actions were executed successfully; false otherwise.
  **/
  public boolean execute( IState state )
  {
    IAction actions[] = getActions();
    boolean rv = true;
    int     i  = 0;
    for ( i = 0; rv && i < actions.length; i++ )
    {
      rv = actions[i].execute( state );
    }
    if ( !rv )
    {
      rollbackActions( 0, i + 1, state );
    }
    return rv;
  }

  /**
    Rollback all actions in this aggregate.
  **/
  public void rollback( IState state )
  {
    rollbackActions( state );
  }
  ///////////////////////////////////////////////////////////////////
  // IAction interface END
  ///////////////////////////////////////////////////////////////////

  public String toString()
  {
    return "TNX( " + super.toString() + " )";
  }
}
