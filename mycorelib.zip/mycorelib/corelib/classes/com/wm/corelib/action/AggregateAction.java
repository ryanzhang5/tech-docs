
package com.wm.corelib.action;

import com.wm.corelib.core.IState;
import com.wm.corelib.dbc.Assert;

/**
  Base class for all aggregate actions.
**/
abstract class AggregateAction implements IAggregateAction
{
  ///////////////////////////////////////////////////////////////////
  // public interface
  ///////////////////////////////////////////////////////////////////
  public String toString()
  {
    StringBuffer sb = new StringBuffer();
    IAction actions[] = getActions();
    for ( int i = 0; i < actions.length; i++ )
    {
      sb.append( actions[i].toString() );
      if ( i < (actions.length - 1 ) )
        sb.append( ", " );
    }
    return sb.toString();
  }

  ///////////////////////////////////////////////////////////////////
  // protected interface
  ///////////////////////////////////////////////////////////////////
  /**
    Construct AggregateAction object.
    @param actions a non-empty array of action objects to be contained in this aggregate action; cannot be null.
  **/
  protected AggregateAction( IAction actions[] )
  {
    Assert.pre( actions != null );
    _actions = actions;
  }

  /**
    Get contained actions.
    @return non-empty array of contained actions objects; never returns null.
  **/
  public IAction[] getActions()
  {
    return _actions;
  }  

  /**
    Rollback specified contained actions.
    This helper method calls rollback( IState ) method on the contained action
    objects with index &leq; startIndex and &le; endIndex.
    @param startIndex index into array returned from getActions() method.
    @param endIndex index into array returned from getActions() method.
  **/
  protected void rollbackActions( int startIndex, int endIndex, IState state )
  {
    IAction actions[] = getActions();
    for ( int i = startIndex; i < endIndex; i++ )
    {
      actions[i].rollback( state );
    }
  }

  /**
    Rollback all actions contained in this aggregate.
  **/
  protected void rollbackActions( IState state )
  {
    rollbackActions( 0, getActions().length, state );
  }

  ///////////////////////////////////////////////////////////////////
  // private interface
  ///////////////////////////////////////////////////////////////////
  private IAction _actions[] = null;
}
