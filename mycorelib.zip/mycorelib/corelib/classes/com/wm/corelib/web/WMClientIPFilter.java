/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.web;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * WMClientIPFilter - plucks out the actual Client IP address and makes it available to
 * the downstream application classes
 *
 * @author mkishore
 * @since 2.5.1
 */
public class WMClientIPFilter implements Filter {
    private static final String PARAM_HEADER_NAMES = "headerNames";

    private List<String> headerNames = new ArrayList<String>();

    public void init(FilterConfig filterConfig) throws ServletException {
        String param = filterConfig.getInitParameter(PARAM_HEADER_NAMES);
        if (param != null) {
            String[] array = param.split("\\s*,\\s*");
            if (array != null) headerNames = Arrays.asList(array);
        }
    }

    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        if (servletRequest instanceof HttpServletRequest) {
            filterChain.doFilter(new HttpServletRequestWrapper((HttpServletRequest) servletRequest) {
                @Override
                public String getRemoteAddr() {
                    // iterate through the header-names and return the first one found
                    for (String headerName : headerNames) {
                        String headerValue = getHeader(headerName);
                        if (headerValue != null) return headerValue;
                    }
                    return super.getRemoteAddr();
                }

                // return the IP address instead of the hostname
                public String getRemoteHost() {
                    return getRemoteAddr();
                }
            }, servletResponse);
        } else {
            filterChain.doFilter(servletRequest, servletResponse);
        }

    }

    public void destroy() {
        // no-op
    }

}
