/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.web;

import com.wm.corelib.logging.ThreadGroupID;
import com.wm.corelib.logging.ThreadRequestID;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Date;
import java.util.Enumeration;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
  


/**
 * WMTimerFilter
 *
 * @author mkishore
 * @since 2.5.1
 */
public class WMTimerFilter implements Filter, Runnable {
    private static final ConcurrentHashMap runningThreads = new ConcurrentHashMap(256);
    private static long timerThreshold = 60000; // 1 minute
    private static long sleepTime = 120000; // 2 minutes

    private static boolean threadCreated = false;
    private static final String PROP_HOSTNAME = "com.wm.hostname.real";

    public WMTimerFilter() {
        if (!threadCreated) {
            threadCreated = true;
            Thread t = new Thread(this);
            t.setName("WMTimerFilter-ThreadWatcher");
            t.setDaemon(true);
            t.start();
        }
    }

    public static void setReportingThreshold(long threshold) {
        timerThreshold = threshold;
    }

    public static long getReportingThreshold() {
        return timerThreshold;
    }

    public static void setThreadSleepTime(long time) {
        if (time < 1000) {
            time = 1000;
        }

        sleepTime = time;
    }

    public static long getThreadSleepTime() {
        return sleepTime;
    }

    public void init(FilterConfig config) throws ServletException {
        if (config.getInitParameter("threadSleepTime") != null) {
            setThreadSleepTime(Long.parseLong(config.getInitParameter("threadSleepTime")));
        }

        if (config.getInitParameter("reportingThreshold") != null) {
            setReportingThreshold(Long.parseLong(config.getInitParameter("reportingThreshold")));
        }
    }

    public void destroy() {
        // no-op
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        if ((request != null) && request instanceof HttpServletRequest) {
            HttpServletRequest httpRequest = (HttpServletRequest) request;
            HttpServletResponse httpResponse = (HttpServletResponse) response;

            Thread thread = Thread.currentThread();
            String threadName = thread.getName();
            Object o = runningThreads.put(threadName, new RunningThreadData(thread, httpRequest));
            if (o != null) {
                RunningThreadData rtd = (RunningThreadData) o;
                System.err.println("WMTimerFilter ERROR: Previous request on thread never ended: " + rtd.toString());
            }

            try {
                String hostID = System.getProperty(PROP_HOSTNAME, "NA");
                int ndx = hostID.indexOf('.');
                if (ndx != -1) hostID = hostID.substring(0, ndx);
                if (hostID.length() > 4 && "dc-".equals(hostID.substring(1, 4))) {
                    hostID = hostID.charAt(0) + hostID.substring(4);
                }

                String originalQry = httpRequest.getQueryString();
                String originalUrl = httpRequest.getRequestURI() + ((originalQry == null) ? "" : ("?" + originalQry));

                String requestID = RequestID.getRequestID(hostID, originalUrl);
                request.setAttribute("com.wm.RequestID", requestID);
                ThreadRequestID.set(requestID);
                System.err.println("TOMCAT REQ: " + originalUrl
                        + " " + new Date().toString()
                        + " <RequestID: " + requestID + ">"
                );
                // set the response header before passing down the chain
                httpResponse.setHeader("Via", request.getProtocol() + " " + hostID + " (" + requestID + ")");

                chain.doFilter(request, response);

                Object threadData = runningThreads.remove(threadName);
                if (threadData == null) {
                    System.err.println("WMTimerFilter ERROR: Thread " + threadName + " never started?");
                } else {
                    RunningThreadData rtd = (RunningThreadData) threadData;
                    String sessionID = ThreadGroupID.get();
                    if (sessionID == null) {
                        HttpSession session = httpRequest.getSession(false);
                        if (session != null) sessionID = session.getId();
                    }
                    System.err.println("TOMCAT BENCH: " + originalUrl
                            + " " + rtd.getElapsed() + " elapsed"
                            + " " + new Date().toString()
                            + " <SessionID: " + (sessionID != null ? sessionID : "NULL") + ">"
                            + " <RequestID: " + requestID + ">"
                    );
                }
            } finally {
                runningThreads.remove(threadName);
            }
        } else {
            System.err.println("WMTimerFilter::doFilter -> Request is not of type HttpServletRequest");
        }
    }

    // This is the thread loop that iterates through the running threads table looking for stuck threads
    public void run() {
        while (true) {
            try {
                Thread.sleep(WMTimerFilter.getThreadSleepTime());
            } catch (InterruptedException e) {
                // ignore
            }

            try {
                long threshold = WMTimerFilter.getReportingThreshold();
                long currentTime = System.currentTimeMillis();
                Enumeration currentThreads = runningThreads.elements();

                while (currentThreads.hasMoreElements()) {
                    Object o = currentThreads.nextElement();

                    if ((o == null) || (!(o instanceof RunningThreadData))) {
                        continue;
                    }

                    RunningThreadData rtd = (RunningThreadData) o;

                    if ((currentTime - rtd.getStartTime()) >= threshold) {
                        System.err.println("WMTimerFilter ERROR: Stuck Thread " + rtd.toString());
                    }
                }
            } catch (Throwable t) {
                System.err.println("ERROR: Exception while looping through threads: " + t);
            }
        }
    }

    static public Enumeration getRunningThreads() {
        return runningThreads.elements();
    }

    static public String runningThreadsReport() {
        StringBuffer report = new StringBuffer();
        try {
            Enumeration currentThreads = runningThreads.elements();
            while (currentThreads.hasMoreElements()) {
                Object o = currentThreads.nextElement();

                if ((o == null) || (!(o instanceof RunningThreadData))) {
                    report.append("INTERNAL ERROR IN HASHTABLE\n");
                } else {
                    RunningThreadData rtd = (RunningThreadData) o;
                    report.append("Running thread " + rtd.toString() + "\n");
                }
            }
        } catch (Throwable t) {
            report.append("ERROR: Exception while looping through threads: " + t + "\n");
        }
        return report.toString();
    }

    // a little helper class to keep tabs on tomcat threads
    public class RunningThreadData {
        private String url = "";
        private long startTime;
        private String threadName;
        private Thread thread;
        private HttpServletRequest request;

        public RunningThreadData(Thread thread, HttpServletRequest request) {
            startTime = System.currentTimeMillis();

            url += request.getRequestURI();
            url += ((request.getQueryString() == null) ? "" : ("?" + (request.getQueryString())));

            threadName = thread.getName();
            this.thread = thread;
            this.request = request;
        }

        public String getUrl() {
            return url;
        }

        public String getThreadName() {
            return threadName;
        }

        public long getStartTime() {
            return startTime;
        }

        public String getStartTimeStr() {
            return new java.util.Date(getStartTime()).toString();
        }

        public long getElapsed() {
            return System.currentTimeMillis() - startTime;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("{ url:=" + url)
                    .append(", startTime:=" + new java.util.Date(startTime))
                    .append(", " + getElapsed() + " elapsed")
                    .append(", thread:=" + threadName)
                    .append(", requestID:=" + request.getAttribute("com.wm.RequestID"));
            StackTraceElement[] stack = thread.getStackTrace();
            if (stack != null) {
                sb.append(", stack:=[");
                for (int i = 0; i < 50 && i < stack.length; i++) {
                    if (i != 0) sb.append("  at ");
                    sb.append(stack[i]);
                }
                sb.append("]");
            }
            sb.append(" }");
            return sb.toString();
        }
    }

    private static class RequestID {
        private static final Random RD = new Random();
        private static final int RANDOM_RANGE = 1000000;

        public static String getRequestID(String hostID, String url) {
            StringBuffer sb = new StringBuffer();
            if (hostID != null) {
                sb.append(hostID).append("_");
            }
            if (url != null) {
                sb.append(format(url.hashCode(), 10)).append("_");
            }
            sb.append(getRandomId());
            return sb.toString();
        }

        private static String getRandomId() {
            int r_id = 1 + RD.nextInt(RANDOM_RANGE);
            return format(r_id, 8);
        }

        private static String format(double unformated, int suffixLength) {
            String s = String.valueOf(Double.doubleToLongBits(unformated));
            return s.substring(s.length() - suffixLength);

        }

    }

}
