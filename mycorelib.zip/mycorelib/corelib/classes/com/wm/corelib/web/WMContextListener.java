/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.web;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.LogManager;
  

/**
 * WMContextListener - loads up the system properties from a given file, and initializes
 * the log manager.
 *
 * @author mkishore
 * @since 2.5.1
 */
public class WMContextListener implements ServletContextListener {
    private static final String PARAM_SYSTEM_PROPERTIES = "systemProperties";

    public void contextInitialized(ServletContextEvent servletContextEvent) {
        ServletContext context = servletContextEvent.getServletContext();
        String param = context.getInitParameter(PARAM_SYSTEM_PROPERTIES);
        if (param != null) {
            context.log("Loading system properties from: " + param);
            File file = new File(param);
            if (file.exists() && file.canRead()) {
                try {
                    System.getProperties().load(new FileInputStream(file));
                } catch (IOException e) {
                    context.log("Error loading system properties from: " + param, e);
                }
            } else {
                context.log("Cannot read the system properties from: " + param);
            }
        }
        try {
            context.log("Initializing LogManager configuration");
            LogManager.getLogManager().readConfiguration();
        } catch (IOException e) {
            context.log("Error re-loading LogManager configuration", e);
        }
    }

    public void contextDestroyed(ServletContextEvent servletContextEvent) {
        // no-op
    }
}
