package com.wm.corelib.timeflow;

import java.io.*;

class TestTouch implements Serializable {

  public static void runTouch() {
    try 
    {
      Runtime.getRuntime().exec("touch subir.txt");
      System.out.println("Task2 - Touch.runTouch() Standalone Class - Touched Subir.txt");
    } catch (Exception e) {
        System.out.println(e);
      }   
    }
}

