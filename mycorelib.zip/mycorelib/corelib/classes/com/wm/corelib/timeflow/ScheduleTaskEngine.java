package com.wm.corelib.timeflow;

import java.util.Timer;
import java.util.TimerTask;
import java.util.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.io.*;
  
import com.wm.corelib.config.AppConfig;

//Future enhancements. Use a hashtable.  Use a thread pool.  Limit # of times a repeating task runs. 
/**
*   This factory class is responsible for setting up and scheduling all tasks.  It also is responsible
*   for persistence and reading from storage when the class is instantiated.  Tasks read from
*   storage are also rescheduled if they need to be. 
*/
public class ScheduleTaskEngine
{
  public static final String CONF_TASKDIR = "com.wm.corelib.timeflow.taskDir";
  private Timer _timer;
  private ArrayList _taskList = new ArrayList();
  private TaskIO _dir;
  private final String SPECIFICDATE = "ScheduleSpecificDate";
  private final String FIXEDTIME = "ScheduleFixedTime";
  private final String REPEATINGDATE = "ScheduleRepeatingDate";
  private final String REPEATINGTIME = "ScheduleRepeatingTime";
  private final String RELATIVEONCE = "RunRelativeOnce";
  private final String RELATIVEREPEATING = "RunRelativeRepeating";
  private String  taskDir = AppConfig.getInstance().getProperty( CONF_TASKDIR );
  private ScheduleTaskEngine( )
  {
    //if the Timeflow directory exists load tasks else create the directory
    if ( !new File(taskDir).exists() )
    {
      new File( taskDir ).mkdir();
    }
    try
    {
      _dir = new TaskIO(new File( taskDir ));
    } catch ( IOException e )
    {
      System.out.println("IOException reading from " + taskDir + "  " + e);
    }
    getPersistedTasks( );
  }

  /**
   * One Time Task.  Schedule a one time task at a specific date and time
   * Set maxTardiness to the amount of time that you want to wait to reschedule a task.  0 means the task will not be rescheduled.
   * For example if the task doesn't run within 30 minutes of it's scheduled time (due to the site being down, for example) then set
   * this arguement to 1800000 milliseconds.  Should we accept minutes instead?
   */
  public String scheduleSpecificDate( Runnable taskToRun, int month, int day, int year, int hour, int minute, int second, long maxTardiness )
  {
    _timer = new Timer( true );   //one timer thread per task.  Need to use thread pool.  to do.
    Calendar calendar = Calendar.getInstance();
    calendar.set(year, month, day, hour, minute, second);
    Date time = calendar.getTime();
    System.out.println("Month is " + calendar.get(calendar.MONTH));
    Task task = new Task();
    task.setIsRepeatable( false );
    task.setIsPersisted( true );
    task.setScheduledDateTime( time );
    task.setTaskToRun( taskToRun );
    task.setMaxTardiness(maxTardiness);
    task.setTypeOfSchedule( SPECIFICDATE );
    _timer.schedule( task, task.getScheduledDateTime()  );
    _taskList.add( task );  //check and see if it's already in there - to do
    this.persistTask(task);
    return task.getTaskID();
  }

  /**
   * One Time Task.  Schedule a one time task at a specific date and time
   * Set maxTardiness to the amount of time that you want to wait to reschedule a task.  0 means the task will not be rescheduled.
   * For example if the task doesn't run within 30 minutes of it's scheduled time (due to the site being down, for example) then set
   * this arguement to 1800000 milliseconds.  Should we accept minutes instead?
   */
  public String scheduleSpecificDate( Runnable taskToRun, long date, int maxTardiness )
  {
    _timer = new Timer( true );   //one timer thread per task.  Need to use thread pool.  to do.
    Date dt = new Date(date);
    System.err.println("Date is " + dt.toString());
    Task task = new Task();
    task.setIsRepeatable( false );
    task.setIsPersisted( true );
    task.setScheduledDateTime( dt );
    task.setTaskToRun( taskToRun );
    task.setMaxTardiness(maxTardiness);
    task.setTypeOfSchedule( SPECIFICDATE );
    _timer.schedule( task, task.getScheduledDateTime()  );
    _taskList.add( task );  //check and see if it's already in there - to do
    this.persistTask(task);
    return task.getTaskID();
  }

  /**
   * Repeating Task. Schedule a task that runs once a day at a specific time
   * Set maxTardiness to the amount of time that you want to wait to reschedule a task.  0 means the task will not be rescheduled.
   * For example if the task doesn't run within 30 minutes of it's scheduled time (due to the site being down, for example) then set
   * this arguement to 1800000 milliseconds.  Should we accept minutes instead?
   */
  public String scheduleFixedTime( Runnable taskToRun, int hour, int minute, int second, long maxTardiness )
  {
    _timer = new Timer( true );
    Calendar calendar = Calendar.getInstance();
    calendar.set(Calendar.HOUR_OF_DAY, hour);
    calendar.set(Calendar.MINUTE, minute);
    calendar.set(Calendar.SECOND, second);
    Date time = calendar.getTime();
    Task task = new Task();
    task.setIsRepeatable( false );
    task.setIsPersisted( true );
    task.setScheduledDateTime( time );
    task.setTaskToRun( taskToRun );
    task.setMaxTardiness(maxTardiness);
    task.setTypeOfSchedule( FIXEDTIME );
    _timer.schedule( task, task.getScheduledDateTime()  );
    _taskList.add( task );  //check and see if it's already in there - to do
    this.persistTask(task);
    return task.getTaskID();
  }

  /**
   * Repeating Task.  Starts at a specific Date/Time and repeats at specified intervals .
   * interval is set in milliseconds
   * Set maxTardiness to the amount of time that you want to wait to reschedule a task.  0 means the task will not be rescheduled.
   * For example if the task doesn't run within 30 minutes of it's scheduled time (due to the site being down, for example) then set
   * this arguement to 1800000 milliseconds.  Should we accept minutes instead?
   */
  public String scheduleRepeatingDate( Runnable taskToRun, int month, int day, int year, int hour, int minute, int second, int interval, long maxTardiness )
  {
    _timer = new Timer( true );
    Calendar calendar = Calendar.getInstance();
    calendar.set(year, month, day, hour, minute, second);
    Date time = calendar.getTime();
    Task task = new Task();
    task.setIsRepeatable( false );
    task.setIsPersisted( true );
    task.setScheduledDateTime( time );
    task.setScheduledInterval( interval );
    task.setTypeOfSchedule( REPEATINGDATE );
    task.setTaskToRun( taskToRun );
    task.setMaxTardiness(maxTardiness);
    _timer.schedule( task, task.getScheduledDateTime(), task.getScheduledInterval()  );
    _taskList.add( task );  
    this.persistTask(task);
    return task.getTaskID();
  }

  /**
  * Repeating Task.  Starts at a specific Time and repeats at specified intervals
  * interval is set in milliseconds
   * Set maxTardiness to the amount of time that you want to wait to reschedule a task.  0 means the task will not be rescheduled.
   * For example if the task doesn't run within 30 minutes of it's scheduled time (due to the site being down, for example) then set
   * this arguement to 1800000 milliseconds.  Should we accept minutes instead?
  */
  public String scheduleRepeatingTime( Runnable taskToRun, int hour, int minute, int second, int interval, long maxTardiness )
  {
    _timer = new Timer( true );
    Calendar calendar = Calendar.getInstance();
    calendar.set(Calendar.HOUR_OF_DAY, hour);
    calendar.set(Calendar.MINUTE, minute);
    calendar.set(Calendar.SECOND, second);
    Date time = calendar.getTime();
    Task task = new Task();
    task.setIsRepeatable( false );
    task.setIsPersisted( true );
    task.setScheduledDateTime( time );
    task.setScheduledInterval( interval );
    task.setTypeOfSchedule( REPEATINGTIME );
    task.setTaskToRun( taskToRun );
    task.setMaxTardiness(maxTardiness);
    _timer.schedule( task, task.getScheduledDateTime(), task.getScheduledInterval()  );
    _taskList.add( task );  
    this.persistTask(task);
    return task.getTaskID();
  }

  /**
  * One Time Task. Starts at a Time relative to the time it is setup
  * initTime is set in milliseconds
   * Set maxTardiness to the amount of time that you want to wait to reschedule a task.  0 means the task will not be rescheduled.
   * For example if the task doesn't run within 30 minutes of it's scheduled time (due to the site being down, for example) then set
   * this arguement to 1800000 milliseconds.  Should we accept minutes instead?
  */
  public String runRelativeOnce( Runnable taskToRun, int initTime, long maxTardiness )
  {
    _timer = new Timer( true );
    Task task = new Task();
    task.setIsRepeatable( false );
    task.setIsPersisted( true );
    task.setScheduledInitialTime( initTime );
    task.setTypeOfSchedule( RELATIVEONCE );
    task.setTaskToRun( taskToRun );
    task.setMaxTardiness(maxTardiness);
    _timer.schedule( task, task.getScheduledInitialTime()  );
    _taskList.add( task );  
    this.persistTask(task);
    return task.getTaskID();
  }

  /**
  * Repeating Task.  Starts at a Time relative to the time it is setup and repeats at specified intervals
  * interval and initTime are set in milliseconds
   * Set maxTardiness to the amount of time that you want to wait to reschedule a task.  0 means the task will not be rescheduled.
   * For example if the task doesn't run within 30 minutes of it's scheduled time (due to the site being down, for example) then set
   * this arguement to 1800000 milliseconds.  Should we accept minutes instead?
  */
  public String runRelativeRepeating( Runnable taskToRun, int initTime, int interval, long maxTardiness )
  {
    _timer = new Timer( true );
    Task task = new Task();
    task.setIsRepeatable( true );
    task.setIsPersisted( true );
    task.setScheduledInitialTime( initTime );
    task.setScheduledInterval( interval );
    task.setTypeOfSchedule( RELATIVEREPEATING );
    task.setTaskToRun( taskToRun );
    task.setMaxTardiness(maxTardiness);
    _timer.schedule( task, task.getScheduledInitialTime(), task.getScheduledInterval()  );
    _taskList.add( task );  
    this.persistTask(task);
    return task.getTaskID();
  }

  private static ScheduleTaskEngine TaskScheduler  = null;

  // Get a singleton TaskEngine
  public static synchronized ScheduleTaskEngine getInstance()
  {
    if ( TaskScheduler == null )
      TaskScheduler = new ScheduleTaskEngine( );
    return TaskScheduler;
  }

  public boolean cancelTask(String taskID)
  {
    Task task = findTaskByID(taskID);
    if ( task != null )
    {
      task.setIsCancelled( true );
      _taskList.remove( task );
      task.cancel();

      _dir.delete( task );
      return true;
    } else
    {
      //to do something
      //System.out.println("Task not found: " + task.getTaskID());
      return false;
    }
  }

  public Task findTaskByID( String taskID )
  {
    for ( int i = 0; i < _taskList.size(); i++ )
    {
      Task task = (Task)_taskList.get( i );
      if ( task.getTaskID().equals( taskID ) )
      {
        return task;
      }
    }
    return null;
  }

  public void cancelAllTasks()
  {
    _taskList.clear();
    _dir.deleteAll();
    //_timer.cancel();
  }

  public Task[] getAllTasks()
  {
    ArrayList _list = new ArrayList( );
    for ( int i = 0; i < _taskList.size(); i++ )
    {
      Task task = (Task)_taskList.get( i );
      _list.add( task );
    }
    Task[] out = new Task[ _list.size() ];
    for ( int i = 0; i < out.length; i++ )
    {
      out[ i ] = (Task)_list.get( i );
    }
    _list = null;
    return out;
  }

  void persistTaskByID(String taskID)
  {
    this.persistTask( this.findTaskByID( taskID ) );
  }

  private void persistTask(Task task)
  {
    try
    {
      task.setIsPersisted( true );
      _dir.write(task);
    } catch ( IOException e )
    {
      System.out.println(e);
    }
  }

  private void getPersistedTasks() 
  {
    try
    {
      System.out.println("# of tasks: " + (_dir.readAll()).length );
      Task _tasks[] =  _dir.readAll();
      int _numTasks = (_dir.readAll()).length;
      for ( int i = 0; i < _numTasks; i++ )
      {
        //Task task = _numTasks()[i];
        System.out.println("Now processing: " + i + " " + _tasks[i].getTaskID());
        if ( _tasks[i].getMaxTardiness() == 0 ) //if getMaxTardiness is 0, do not reschedule
        {
          _dir.delete( _tasks[i] );
          System.out.println("Deleted: "+  _tasks[i].getTaskID());
        } else
        {
          System.out.println("Rescheduling: "+  _tasks[i].getTaskID());
          rescheduleTasks( _tasks[i] );
        }
      }
    } catch ( IOException e )
    {
      System.out.println(e);
    } catch ( ClassNotFoundException e )
    {
      System.out.println(e);
    }
  }

  private void rescheduleTasks(Task task)
  {
    _timer = new Timer( true );
    if ( task.getTypeOfSchedule().equals(SPECIFICDATE) )
    {
      if ( ((System.currentTimeMillis() - task.getScheduledDateTime().getTime()) >= task.getMaxTardiness()) ||
           task.getLastRunTime() != 0 )
      {
        _dir.delete(task);
      } else
      {
        _timer.schedule( task, task.getScheduledDateTime()  );
        _taskList.add(task);
      }
    } else if ( task.getTypeOfSchedule().equals(FIXEDTIME) )
    {
      if ( (System.currentTimeMillis() - task.getScheduledDateTime().getTime()) >= task.getMaxTardiness() )
      {
        _dir.delete(task);
      } else
      {
        _timer.schedule( task, task.getScheduledDateTime()  );
        _taskList.add(task);
      }
    } else if ( task.getTypeOfSchedule().equals(REPEATINGDATE) )
    {

      if ( (System.currentTimeMillis() - task.getScheduledDateTime().getTime()) >= task.getMaxTardiness() )
      {
        _dir.delete(task);
      } else
      {
        _timer.schedule( task, task.getScheduledDateTime(), task.getScheduledInterval());
        _taskList.add(task);
      }
    } else if ( task.getTypeOfSchedule().equals(REPEATINGTIME) )
    {
      if ( (System.currentTimeMillis() - task.getScheduledDateTime().getTime()) >= task.getMaxTardiness() )
      {
        _dir.delete(task);
      } else
      {
        _timer.schedule( task, task.getScheduledDateTime(), task.getScheduledInterval()  );
        _taskList.add(task);
      }
    } else if ( task.getTypeOfSchedule().equals(RELATIVEONCE) )
    {
      if ( ((System.currentTimeMillis() - task.getCreatedDate()) >= task.getMaxTardiness()) ||
           task.getLastRunTime() != 0 )
      {
        _dir.delete(task);
      } else
      {
        _timer.schedule( task, task.getScheduledInitialTime()  );
        _taskList.add(task);
      }
    } else if ( task.getTypeOfSchedule().equals(RELATIVEREPEATING) )
    {
      if ( (System.currentTimeMillis() - task.getCreatedDate()) >= task.getMaxTardiness() )
      {
        _dir.delete(task);
      } else
      {
        _timer.schedule( task, task.getScheduledInitialTime(), task.getScheduledInterval()  );
        _taskList.add(task);
      }
    }
  }

}
