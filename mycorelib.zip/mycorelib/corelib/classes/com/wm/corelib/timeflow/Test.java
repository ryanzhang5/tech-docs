package com.wm.corelib.timeflow;

class Test {

  public static void main(String args[]) {

    int _day = 01;
    int _month = 3;
    int _year = 2002;
    int _hour = Integer.parseInt(args[0]);
    int _min = Integer.parseInt(args[1]);
    int _sec = 0;

    //System.out.println("get instance of singleton.. \n");
    ScheduleTaskEngine scheduler = ScheduleTaskEngine.getInstance();

    //System.out.println("instantiate tasks..\n");
    System.out.println("Task1: " + scheduler.scheduleSpecificDate(new TestTouch2("Task1"),
                        _month, _day, _year, _hour, _min, _sec,0));
    System.out.println("Task2: " + scheduler.scheduleFixedTime(new TestTouch2("Task2"),
                        _hour, _min, _sec,0));
    System.out.println("Task3: " + scheduler.scheduleRepeatingDate(new TestTouch2("Task3"),
                        _month, _day, _year, _hour, _min, _sec, 5000,0));
    System.out.println("Task4: " + scheduler.scheduleRepeatingTime(new TestTouch2("Task4"),
                        _hour, _min, _sec, 5000,0));
    System.out.println("Task5: " + scheduler.runRelativeOnce(new TestTouch2("Task5"),
                        5000,0));
    System.out.println("Task6: " + scheduler.runRelativeRepeating(new TestTouch2("Task6"),
                        5000, 5000,100000));

    System.out.println("\nList all scheduled tasks \n");
    for (int i=0; i < (scheduler.getAllTasks()).length;i++) {
      System.out.println(scheduler.getAllTasks()[i] + "\n");
    }

    System.out.println("done..");
  }

}
