package com.wm.corelib.timeflow;

import java.io.*;

public class TestTouch2 implements Runnable, Serializable {
  private String _msg = null;
  private String _cmd = null;

  public TestTouch2(String msg) {
    this._msg = msg;
    this._cmd = "touch " + _msg +".txt";

  }

  public void run() {
    try
    {
      Runtime.getRuntime().exec(_cmd);
      System.out.println( _msg + " - implements Runnable - Touched " + _msg + ".txt");
      //TestTouch.runTouch();
    } catch (Exception e) {
        System.out.println(e);
      }
  }
}

