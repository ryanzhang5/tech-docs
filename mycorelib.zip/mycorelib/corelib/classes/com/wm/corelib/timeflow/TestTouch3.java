package com.wm.corelib.timeflow;

import java.io.*;

class TestTouch3 implements Serializable, Runnable {

  public void runTouch() {
    try
    {
      Runtime.getRuntime().exec("touch subir3.txt");
      System.out.println("Task3 - Touch.runTouch() Standalone Class - Touched Subir3.txt");
    }
    catch (Exception e)
    {
      System.out.println(e);
    }
  }

  public void run() {
    this.runTouch();
  }
}

