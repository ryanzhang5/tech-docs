package com.wm.corelib.timeflow;

import java.util.TimerTask;
import java.util.Random;
import java.io.*;
import java.util.Date;
/**
 * This represents a task that needs to be run at a scheduled interval.  Tasks are
 * scheduled by the ScheduleTaskEngine
 *
 * @author Subir Sengupta
 */
class Task extends TimerTask implements Serializable {

  //Instance variables
  private long _scheduledInitialTime = 0;
  private long _scheduledInterval = 0;
  private long _maxTardiness = 1800000; //30 minutes in milliseconds
  private int _numTimesRun = 0;
  private Date _scheduledDateTime = null;
  private long _createdDate = 0;
  private boolean _isCancelled = false;
  private boolean _isPersisted = false;
  private boolean _isRepeatable = false;
  private String _typeOfSchedule = null;
  private long _lastRunTime = 0;
  private String _taskID = null;
  private Runnable _taskToRun = null;

  //Static variables
  private static transient long s_taskID = 1;

  protected Task()   //Constructor
  {
    this._createdDate = System.currentTimeMillis();
    this._taskID = String.valueOf(_createdDate) + String.valueOf(s_taskID); // + String.valueOf(new Random().nextLong())
    s_taskID++;
    //if( s_taskID == Long.MAX_VALUE ) s_taskID = 0;
  }

  //setters
  public void setScheduledInitialTime(long InitialTime)
  {
    this._scheduledInitialTime = InitialTime;
  }
  
  public void setScheduledInterval(long interval)
  {
    this._scheduledInterval = interval;
  }

  public void setIsRepeatable(boolean isRepeatable)
  {
    this._isRepeatable = isRepeatable;
  }

  public void setIsPersisted(boolean isPersisted)
  {
    this._isPersisted = isPersisted;
  }

  public void setIsCancelled(boolean isCancelled)
  {
    this._isCancelled = isCancelled;
  }

  public void setScheduledDateTime(Date scheduledDateTime)
  {
    this._scheduledDateTime = scheduledDateTime;
  }

  public void setTypeOfSchedule(String typeOfSchedule)
  {
    this._typeOfSchedule = typeOfSchedule;
  }

  public void setTaskToRun(Runnable task)
  {
    this._taskToRun = task;
  }

  public void setMaxTardiness(long maxTardiness )
  {
    this._maxTardiness = maxTardiness;
  }

  //getters
  public long getScheduledInitialTime()
  {
    return _scheduledInitialTime;
  }

  public long getScheduledInterval()
  {
    return _scheduledInterval;
  }

  public String getTaskID()
  {
    return _taskID;
  }

  public boolean getIsRepeatable()
  {
    return _isRepeatable;
  }

  public boolean getIsPersisted()
  {
    return _isPersisted;
  }

  public boolean getIsCancelled()
  {
    return _isCancelled;
  }

  public Date getScheduledDateTime()
  {
    return _scheduledDateTime;
  }

  public Runnable getTaskToRun()
  {
    return _taskToRun;
  }

  public String getTypeOfSchedule()
  {
    return _typeOfSchedule;
  }

  public long getLastRunTime()
  {
    return _lastRunTime;
  }

  public long getMaxTardiness()
  {
    return _maxTardiness;
  }

  public int getNumTimesRun()
  {
    return _numTimesRun;
  }

  public long getCreatedDate()
  {
    return _createdDate;
  }

  public final void run()
  {
    //if (System.currentTimeMillis() - getLastRunTime() >= _maxTardiness)
    //  return;  // Too late; skip this execution.
    _run();
    _numTimesRun++;
    _lastRunTime = System.currentTimeMillis();
    ScheduleTaskEngine scheduler = ScheduleTaskEngine.getInstance();
    scheduler.persistTaskByID(this.getTaskID()); //do we need to remove this task from the tasklist and read it from the disk again?
  }

  public void _run(){
    _taskToRun.run();
  }

  public String toString()
  {
    return getClass().getName() +
           "\n{" +
           "\ntaskID = " + getTaskID() + 
           "\ncreatedDate = " + _createdDate +
           "\nscheduledInitialTime = " + getScheduledInitialTime() +
           "\nscheduledInterval = " + getScheduledInterval() +
           "\nscheduledDateTime = " + getScheduledDateTime() +
           "\nisCancelled = " + getIsCancelled() +
           "\nisRepeatable = " + getIsRepeatable() +
           "\ntypeOfSchedule = " + getTypeOfSchedule() +
           "\nisPersisted = " + getIsPersisted() +
           "\nlastExecuted = " + getLastRunTime() +
           "\ngetMaxTardiness = " + getMaxTardiness() +
           "\ngetNumTimesRun = " + getNumTimesRun() +
           "\nTaskToRun = "  + _taskToRun.toString() +
           "\n}";
  }
}

