package com.wm.corelib.timeflow;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.*;

/**
* This class handles all the io related functions for persisting, retrieving and deleting tasks 
* from storage.  These methods can also be used from an Admin page.  
*/


public class TaskIO
{

  protected String TASK_FILE_EXT = ".task";

  // instance variables
  private File _dir;
  private TaskFileFilter _taskFileFilter;


  protected TaskIO() throws IOException
  {
    //this.init( new File( "/home/ssengupta/www/classes/com/wm/corelib/timeflow"));
  }


  /**
   * Set the directory which is our persistent storage.
   * @param directory The directory to which to write the files.
   * @exception IOException if the passed File is not a directory
   */
  public TaskIO( File directory )
                      throws IOException
  {
    this.init( directory );
  }



  protected void init( File directory )
                  throws IOException
  {
    _dir = directory;
    if( ! _dir.isDirectory() )
      throw new IOException( "Expected a directory: " + directory.getPath() );

    _taskFileFilter = new TaskFileFilter();
  }



  /**
   * filters to .task files
   */
  private class TaskFileFilter implements FilenameFilter
  {
    public boolean accept(File dir, String name)
    {
      if( name.endsWith( TASK_FILE_EXT ) )
        return true;
      else
        return false;
    }
  }



  /**
   * Read all the tasks in persisted storage
   * @exception IOException on file issues
   * @exception ClassNotFoundException on bad file
   */
  public Task[] readAll() throws IOException, ClassNotFoundException
  {
    synchronized( this )
    {
      ObjectInputStream inStream;
      FileInputStream file;

      File[] taskFiles = _dir.listFiles( _taskFileFilter );
      Task[] tasks = new Task[ taskFiles.length ];

      for( int i = 0; i < taskFiles.length; i++ )
      {
        file = new FileInputStream( taskFiles[ i ] );
        inStream = new ObjectInputStream( file );
        tasks[ i ] = (Task)inStream.readObject();
        inStream.close();
        file.close();
      }
      return tasks;
    }
  }




  /**
   * Write the task
   * @param task The Task to write
   *
   */
  public void write( Task task ) throws IOException
  {
    synchronized( this )
    {
      ObjectOutputStream outStream;
      FileOutputStream file;

      String fileName = new String( _dir.getPath()
                                    + File.separator
                                    + task.getTaskID()
                                    + TASK_FILE_EXT );

      file = new FileOutputStream( fileName );
      outStream = new ObjectOutputStream( file );
      outStream.writeObject( task );
      outStream.close();
    }
  }


  /**
   * Delete the task
   */
  public void delete( Task task )
  {
    synchronized( this )
    {
      String fileName = new String( _dir.getPath()
                                    + File.separator
                                    + task.getTaskID()
                                    + TASK_FILE_EXT );
      System.out.println("deleting file " + fileName);
      File file = new File( fileName );
      file.delete();
    }
  }


  /**
   * Clear all tasks
   */
  public void deleteAll()
  {
    synchronized( this )
    {
      File[] taskFiles = _dir.listFiles( _taskFileFilter );

      for( int i = 0; i < taskFiles.length; i++ )
      {
        taskFiles[ i ].delete();
      }
    }
  }

}