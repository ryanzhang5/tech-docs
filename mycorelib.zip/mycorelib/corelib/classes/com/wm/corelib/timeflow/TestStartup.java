package com.wm.corelib.timeflow;

class TestStartup {

  public static void main(String args[]) {

    ScheduleTaskEngine scheduler = ScheduleTaskEngine.getInstance();

    System.out.println("\nList all scheduled tasks \n");
    for (int i=0; i < (scheduler.getAllTasks()).length;i++) {
      System.out.println(scheduler.getAllTasks()[i] + "\n");
    }

    System.out.println("done..");
  }

}
