package com.wm.corelib.smtp;

import java.util.Hashtable;
import java.util.Vector;


/**
 * Encapsulates a single e-mail message.
 *
 * @author James Cooper <pixel@bitmechanic.com>
 */
public class MailMessage {
    private Vector toList;
    private Vector ccList;
    private Vector bccList;
    private String from;
    private String smtpfrom;
    private String subject;
    private StringBuffer body;
    private Hashtable headers = new Hashtable();

    public MailMessage(String[] to, String from, String smtpfrom,
                       String subject, String body) {
        this();
        this.body.append(body);
        this.from = from;
        this.smtpfrom = smtpfrom;
        this.subject = subject;

        if (to != null) {
            for (int i = 0; i < to.length; i++) {
                addTo(to[i]);
            }
        }
    }

    public MailMessage(String to, String from, String smtpfrom, String subject,
                       String body) {
        this();
        this.body.append(body);
        this.from = from;
        this.smtpfrom = smtpfrom;
        this.subject = subject;
        addTo(to);
    }

    public MailMessage() {
        toList = new Vector();
        ccList = new Vector();
        bccList = new Vector();
        body = new StringBuffer();
    }

    public void addTo(String to) {
        toList.addElement(to);
    }

    public String[] getToList() {
        String[] list = new String[toList.size()];
        toList.copyInto(list);

        return list;
    }

    public void clearToList() {
        toList.removeAllElements();
    }

    public void addCC(String cc) {
        ccList.addElement(cc);
    }

    public String[] getCCList() {
        String[] list = new String[ccList.size()];
        ccList.copyInto(list);

        return list;
    }

    public void clearCCList() {
        ccList.removeAllElements();
    }

    public void addBCC(String bcc) {
        bccList.addElement(bcc);
    }

    public String[] getBCCList() {
        String[] list = new String[bccList.size()];
        bccList.copyInto(list);

        return list;
    }

    public void clearBCCList() {
        bccList.removeAllElements();
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getFrom() {
        return from;
    }

    public String getSMTPFrom() {
        return smtpfrom;
    }

    public void setSMTPFrom(String f) {
        this.smtpfrom = f;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getSubject() {
        return subject;
    }

    public void setBody(String body) {
        this.body.setLength(0);
        this.body.append(body);
    }

    public void appendBody(String str) {
        body.append(str);
    }

    public String getBody() {
        return body.toString();
    }

    public void clearBody() {
        body.setLength(0);
    }

    public void addHeader(String name, String value) {
        if (value == null) {
            headers.remove(name);
        } else {
            headers.put(name, value);
        }
    }

    public Hashtable getHeaders() {
        return headers;
    }
}
