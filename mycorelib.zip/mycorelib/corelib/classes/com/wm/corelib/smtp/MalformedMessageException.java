package com.wm.corelib.smtp;

public class MalformedMessageException extends Exception {
    public MalformedMessageException(String msg) {
        super(msg);
    }
}
