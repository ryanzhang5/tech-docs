package com.wm.corelib.smtp;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
  

/**
 * Asynchronous SMTP mailer designed for embedding inside server applications.
 * Holds an open connection to an SMTP server and sends messages down the
 * socket one at time.    Prevents the spawning of oodles of sendmail processes
 *
 * @author James Cooper <pixel@bitmechanic.com>
 */
public class Mailer implements Runnable {
    private static Mailer _theInstance = null;
    protected String smtphost;
    protected String localhost;
    protected String sendmail_bin;
    protected long messagesDelivered;
    private Thread t;
    private Queue mailQueue;
    private boolean suspended;
    private final char SMTP_ERROR_CODE1 = '4';
    private final char SMTP_ERROR_CODE2 = '5';
    private final boolean debug = false;

    private Mailer() {
    }

    /**
     * Creates a new Mailer.    Starts a thread that is used to flush the queue
     * of pending messages.  Mailer uses suspend()/resume() to manage when the
     * thread is active.
     *
     * @param smtphost hostname of machine running SMTP server
     */
    private Mailer(String smtphost) {
        this(smtphost, null);
    }

    /**
     * Creates a Mailer that can use sendmail to send mail if the SMTP server
     * down or unavailable.  Only works on UNIX platforms.  Will always try to
     * connect to the SMTP server first.    sendmail will be invoked with the -t
     * flag so that BCC, CC, and TO headers are parsed for recipients.
     *
     * @param smtphost hostname of machine running an SMTP server
     * @param sendmail_bin path to sendmail binary on this machine (UNIX only)
     */
    private Mailer(String smtphost, String sendmail_bin) {
        if (sendmail_bin != null) {
            // Make sure we can at least read the binary
            try {
                File file = new File(sendmail_bin);

                if (file.canRead()) {
                    sendmail_bin = sendmail_bin + " -t";
                } else {
                    sendmail_bin = null;
                }
            } catch (Exception e) {
                sendmail_bin = null;
            }
        }

        this.smtphost = smtphost;
        this.sendmail_bin = sendmail_bin;

        messagesDelivered = 0;
        mailQueue = new Queue();

        suspended = false;
        t = new Thread(this);
        t.setDaemon(true);
        t.setName("com.wm.corelib.smtp.Mailer-Worker-Thread");
        t.start();

        try {
            InetAddress me = InetAddress.getLocalHost();
            localhost = me.getHostName();
        } catch (UnknownHostException e) {
            localhost = "localhost";
            log(e);
        }
    }

    public static Mailer getInstance() {
        if (_theInstance == null) {
            String smtpserver = System.getProperty("com.wm.sys.SMTPServer", "localhost");
            _theInstance = new Mailer(smtpserver, "/usr/lib/sendmail");
        }

        return _theInstance;
    }

    /**
     * Returns number of messages delivered to the SMTP host
     */
    private long getMessagesDelivered() {
        return messagesDelivered;
    }

    /**
     * Returns number of messages currently waiting in the queue
     */
    private long getMessagesQueued() {
        return mailQueue.size();
    }

    /**
     * Queues a message up for delivery and notifies the delivery thread to
     * begin delivering mail
     */
    public synchronized void send(MailMessage message) {
        mailQueue.enqueue(message);
        notifyAll();
    }

    /**
     * Logs any exceptions that occur while trying to deliver mail.  This
     * implementation just calls e.printStackTrace().     Subclass Mailer
     * and override this method to log the message to a logfile if you wish
     */
    private void log(Exception e) {
        e.printStackTrace();
    }

    /**
     * Main delivery loop;  Creates an SMTP connection and flushes the mail
     * queue.     When all messages are delivered it closes the SMTP connection
     * and calls suspend()
     */
    public void run() {
        Socket s = null;
        PrintWriter os = null;
        BufferedReader in = null;
        Process proc = null;
        boolean caught_exception;

        while (true) {
            Vector session = new Vector(20);
            boolean use_smtp = true;
            caught_exception = false;

            try {
                while (!mailQueue.empty()) {
                    if (debug) {
                        session.removeAllElements();
                    }

                    if (s == null) {
                        try {
                            s = new Socket(smtphost, 25);
                            os = new PrintWriter(s.getOutputStream());
                            in = new BufferedReader(new InputStreamReader(s.getInputStream()));
                            readReply(in, session);
                            sendCommand(os, "HELO " + localhost, session);
                            readReply(in, session);
                            use_smtp = true;
                        } catch (Exception e) {
                            if (sendmail_bin == null) {
                                throw e;
                            }

                            s = null;
                            os = null;
                            in = null;
                            use_smtp = false;
                            proc = Runtime.getRuntime().exec(sendmail_bin);
                            os = new PrintWriter(proc.getOutputStream());
                        }
                    }

                    MailMessage message = (MailMessage) mailQueue.dequeue();
                    String[] to = message.getToList();
                    String[] cc = message.getCCList();
                    String[] bcc = message.getBCCList();
                    Hashtable rcpt = new Hashtable();

                    if (use_smtp) {
                        sendCommand(os, "MAIL FROM: " + message.getSMTPFrom(),
                                    session);
                        readReply(in, session);
                        sendList(to, rcpt, session, os, in);
                        sendList(cc, rcpt, session, os, in);
                        sendList(bcc, rcpt, session, os, in);

                        sendCommand(os, "DATA", session);
                        readReply(in, session);
                    }

                    os.print("To: ");

                    for (int i = 0; i < to.length; i++) {
                        if (i != 0) {
                            os.print(", ");
                        }

                        os.print(to[i]);
                    }

                    if (cc.length > 0) {
                        os.print("\r\nCC: ");

                        for (int i = 0; i < cc.length; i++) {
                            if (i != 0) {
                                os.print(", ");
                            }

                            os.print(cc[i]);
                        }
                    }

                    if (bcc.length > 0) {
                        os.print("\r\nBCC: ");

                        for (int i = 0; i < bcc.length; i++) {
                            if (i != 0) {
                                os.print(", ");
                            }

                            os.print(bcc[i]);
                        }
                    }

                    os.print("\r\nFrom: ");
                    os.print(message.getFrom());
                    os.print("\r\nSubject: ");
                    os.print(message.getSubject());

                    // output any additional headers
                    Hashtable headers = message.getHeaders();
                    Enumeration e = headers.keys();

                    while (e.hasMoreElements()) {
                        String key = (String) e.nextElement();
                        String value = (String) headers.get(key);
                        os.print("\r\n" + key + ": " + value);
                    }

                    os.print("\r\n\r\n");
                    os.println(message.getBody());

                    if (use_smtp) {
                        os.print("\r\n.\r\n");
                    }

                    os.flush();

                    if (use_smtp) {
                        readReply(in, session);
                    } else {
                        os.close();
                        proc.waitFor();
                        proc = null;
                    }

                    if (debug) {
                        for (int i = 0; i < session.size(); i++) {
                            System.err.println("Session line #" + i + ": " +
                                               session.elementAt(i));
                        }
                    }

                    messagesDelivered++;
                }
            } catch (Exception e) {
                if (debug) {
                    for (int i = 0; i < session.size(); i++) {
                        System.err.println("Session line #" + i + ": " +
                                           session.elementAt(i));
                    }
                }

                log(e);
                caught_exception = true;
            } finally {
                if (s != null) {
                    try {
                        os.flush();
                        s.close();
                    } catch (Exception e2) {
                        System.err.println("Mailer: Unable to close socket to SMTP server");
                        log(e2);
                    }

                    s = null;
                    os = null;
                    in = null;
                }
            }

            synchronized (this) {
                if (mailQueue.empty() || caught_exception) {
                    try {
                        wait();
                    } catch (InterruptedException e) {
                    }
                }
            }
        }
    }

    private void sendList(String[] list, Hashtable rcpt, Vector session,
                          PrintWriter os, BufferedReader in)
                   throws IOException
    {
        for (int i = 0; i < list.length; i++) {
            if (rcpt.get(list[i]) == null) {
                sendCommand(os, "RCPT TO: " + list[i], session);
                readReply(in, session);
                rcpt.put(list[i], list[i]);
            }
        }
    }

    /*
     * These two methods were written by Thornton Rose.  There was no copyright
     * notice on the source, and it was on www.developer.com, so I hope it's
     * cool to use them here.
     */
    private void sendCommand(PrintWriter writer, String message, Vector session)
                      throws IOException
    {
        if (debug) {
            session.addElement(message);
        }

        writer.write(message);
        writer.write("\r\n");
        writer.flush();
    }

    private void readReply(BufferedReader reader, Vector session)
                    throws IOException
    {
        String reply;
        char statusCode;

        reply = reader.readLine();
        statusCode = reply.charAt(0);

        if (debug) {
            session.addElement(reply);
        }

        if ((statusCode == SMTP_ERROR_CODE1) |
                (statusCode == SMTP_ERROR_CODE2)) {
            throw (new IOException("SMTP: " + reply));
        }
    }
}
