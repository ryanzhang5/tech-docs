package com.wm.corelib.smtp;

public class TestMail {
    
    public static void main( String[] args ) {
        
        if( args.length < 1 ) {
            System.out.println("Usage: TestMail toaddress");
            return;
        }

        String sender = "TestMail@walmart.com";
        MailMessage msg = new MailMessage(args[0], sender, sender,
                "test message from TestMail.main()", "this is\na test\n");

        Mailer.getInstance().send(msg);
        
        long t = System.currentTimeMillis() + 3000;
        while (System.currentTimeMillis() < t)
            ;
    }
}
