package com.wm.corelib.event;

import com.wm.corelib.core.IState;

public class WMEventEngineTest
{
  public void test()
  {
    System.out.println("Setting up my objects...");
    WMEventEngine engine = WMEventEngine.getInstance();
    String nameFoo = "foo";
    String nameBar = "bar";
    WMEventManager managerFoo = new WMEventManager( nameFoo );
    WMEventManager managerBar = new WMEventManager( nameBar );

    WMEventListener listenerFoo1 = new WMEventListener() {
        public void handleEvent( IState state, WMEventManager manager )
        {
          System.out.println("listenerFoo1 handling foo event: " + state + manager );
        }
      };

    WMEventListener listenerFoo2 = new WMEventListener() {

        public void handleEvent( IState state, WMEventManager manager )
        {
          System.out.println("listenerFoo2 handling foo event: " + state + manager );
        }
      };

    WMEventListener listenerBar1 = new WMEventListener() {
        public void handleEvent( IState state, WMEventManager manager )
        {
          System.out.println("listenerBar1 handling bar event: " + state  + manager );
        }
      };

    WMEventListener listenerBar2 = new WMEventListener() {
        public void handleEvent( IState state, WMEventManager manager )
        {
          System.out.println("listenerBar2 handling bar event: " + state  + manager );
        }
      };

    IState state1 = new IState() {};
    IState state2 = new IState() {};

    System.out.println("Adding event managers...");

    engine.addEventManager( managerFoo );
    engine.addEventManager( managerBar );

    System.out.println("Adding listeners...");

    engine.addListener( nameFoo, listenerFoo1 );
    managerFoo.addListener( listenerFoo2 );
    
    engine.addListener( nameBar, listenerBar1 );
    managerFoo.addListener( listenerBar2 );

    System.out.println("Firing events (managers in parallel)...");

    engine.fireEvent( nameFoo, state1 );
    engine.fireEvent( nameBar, state1 );
    
     System.out.println("Firing events (managers in series)...");

     managerFoo.setFireInParallel( false );
     managerBar.setFireInParallel( false );

     engine.fireEvent( nameFoo, state2 );
     engine.fireEvent( nameBar, state2 );
  }

  public static void main( String[] args )
  {
    new WMEventEngineTest().test();
  }
}
