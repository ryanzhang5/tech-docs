package com.wm.corelib.event;

import com.wm.corelib.core.IState;
import com.wm.corelib.dbc.Assert;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

public class WMEventManager
{
  
  public WMEventManager( String name )
  {
    super();
    _name = name;
  }

  /**
   * The name is only mutable at object creation time.
   */
  public String getName()
  {
    return _name;
  }

  /**
   * Set whether or not each registered handler gets called in its own thread
   * (true) or if they get called serially (false).
   *
   * Default is true.
   */
  public void setFireInParallel( boolean v )
  {
    _parallel = v;
  }

  /**
   * Determines whether or not each registered handler gets called in its own thread
   * (true) or if they get called serially (false).
   *
   * Default is true.
   */
  public boolean isFireInParallel()
  {
    return _parallel;
  }

  /**
   * Registers a listener with this event manager.  Listeners will get put in threads
   * (or called) in the order in which they are added.  It's possible to add the same
   * listener more than once.
   */
  public void addListener( WMEventListener listener)
  {
    Assert.pre( listener != null, "listener can't be null!" );
    _listeners.add( listener );
  }

  public boolean removeListener( WMEventListener listener )
  {
    Assert.pre( listener != null, "listener can't be null!" );
    WMEventListener rv = null;
    return _listeners.remove( listener );
  }

  /**
   * Calls all registered handlers.
   */
  public void fireEvent( IState state )
  {
    // XXX: Deal with concurrency issues!

    // Get a method-local copy of whether or not to do this in parallel so that
    // it can't be changed out from under us while we're looping through all of the
    // handlers.
    boolean parallel = _parallel;
    WMEventListener listener = null;
    Iterator iter = _listeners.iterator();
    WMEventRunner runner = null;
    while ( iter.hasNext() ) {
      try 
      {
        listener = (WMEventListener) iter.next();
      }
      catch ( ClassCastException e ) 
      {
        System.err.println("Application Error: object in listeners list isn't of type WMEventListener!");
        e.printStackTrace();
        continue;
      }
      if ( parallel ) {
        // We need a new thread to call this listener from.
        // XXX: Optimization: use a thread pool.
        runner = new WMEventRunner( listener, state, this );
        runner.start();
      }
      else {
        // Just call handleEvent on each listener in series.
        listener.handleEvent( state, this );
      }
    }
  }

  // ???: should default be a public static final value?
  private String  _name = "___DEFAULT___";
  private boolean _parallel = true;
  // ???: Vector ok?  Default init size ok?
  private List    _listeners = new Vector();

  private class WMEventRunner 
    extends Thread
  {
    public WMEventRunner( WMEventListener listener, IState state, WMEventManager manager )
    {
      super();
      _listener = listener;
      _state = state;
      _manager = manager;
    }

    public void run()
    {
      _listener.handleEvent( _state, _manager );
    }

    private WMEventListener _listener;
    private IState          _state;
    private WMEventManager  _manager;
  }
}
