package com.wm.corelib.event;

import com.wm.corelib.core.IState;

public interface WMEventListener
  extends java.util.EventListener
{
  public void handleEvent( IState state, WMEventManager manager );
}
