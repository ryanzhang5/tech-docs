package com.wm.corelib.event;

import com.wm.corelib.core.IState;
import com.wm.corelib.dbc.Assert;
import java.util.Hashtable;
import java.util.Map;

/**
 * A collection of event managers with methods for firing events
 * by name.
 */
public class WMEventEngine
{

  Map managers = new Hashtable(); 

  /**
   * ??? DO we need to pass anything to the constructor?
   */
  private WMEventEngine()
  {
    super();
  }

  /**
   * Add an event manager to the engine.  Returns the event manager that
   * got replaced, if any.
   */
  public WMEventManager addEventManager( WMEventManager manager )
  {
    WMEventManager rv = null;
    Assert.pre( manager.getName() != null, "manager's name shouldn't be null!" );
    Object o = managers.put(manager.getName(), manager);

    try {
      // try to cast what we got out of the managers map to a WMEventManager.
      rv = (WMEventManager)o;
    }
    catch (ClassCastException e) { 
      System.err.println("Application Error: object coming out of managers map is not of type WMEventManager!");
      e.printStackTrace();
    }
    // Return whatever was replaced by the new manager of that name.
    return rv;
  }

  /**
   * Removes the event manager passed in by name.
   * Returns the WMEventManager that got removed.
   * ???: is this a bad idea?
   */
  public WMEventManager removeEventManager( WMEventManager manager )
  {
    Assert.pre( manager.getName() != null, "manager's name shouldn't be null!");
    return removeEventManager( manager.getName() );
  }

  /**
   * Returns the WMEventManager that got removed.
   */
  public WMEventManager removeEventManager( String name )
  {
    Assert.pre( name != null, "name shouldn't be null!");
    WMEventManager rv = null;
    Object o = managers.remove( name );
    try 
    {
      rv = (WMEventManager)o;
    }
    catch ( ClassCastException e ) 
    {
      System.err.println("Application Error: object coming out of managers map is not of type WMEventManager!");
      e.printStackTrace();
    }
    return rv;
  }
  
  public WMEventManager getEventManager( String name )
  {
    // ???: Add type safequards?
    Assert.pre( name != null, "Name can't be null!");
    return (WMEventManager)managers.get( name );
  }

  public void addListener( String name, WMEventListener listener )
  {
    Assert.pre( listener != null, "listener can't be null" );
    WMEventManager manager = getEventManager( name );
    Assert.pre( manager != null, "there is no manager by the name " + name );
    if ( manager != null ) {
      manager.addListener( listener );
    }
  }

  public void fireEvent( String name, IState state )
  {
    Assert.pre( name != null, "Name can't be null!");
    WMEventManager manager = getEventManager( name );
    Assert.pre( manager != null, "No manager for event: " + name );
    if (manager != null) {
      manager.fireEvent( state );
    }
  }


  public static WMEventEngine getInstance()
  {
    return new WMEventEngine();
  }

  private Map eventManagers;
}
