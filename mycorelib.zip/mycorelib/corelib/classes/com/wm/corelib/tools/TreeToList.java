package com.wm.corelib.tools;

import java.io.*;
    
/**
 * This class returns a list of package names for a given root directory.
 *
 * @author Abby Thompson
 **/


public class TreeToList 
{
  
  private static String getListing( File f ) throws IOException
  {
    File list[] = f.listFiles();
    
    for (int i=0; i<list.length; i++) {
      if (list[i].isDirectory()) {
        //recurse file
        getListing(list[i]);
      } else {

        File current = list[i];
        
        if( isGood( current.toString() ) )
        {
          // want to remove first half of path name, based on what given root dir and
          // pretty up string to package format.
          int filePathLength = (filePath.getParent()).length();
          String newPathName = current.getParent();
          String packageName = ( newPathName.substring( filePathLength+1 ) ).replaceAll( "/", "." );

          //Gonna avoid adding duplicates by looking at hashcode.
          if( hashcode != packageName.hashCode() )
          {
            sb.append( " "+packageName );
            hashcode = packageName.hashCode();
          }
        }
      }
    }

    return sb.toString();
  }

  /*
   * Only interested in directories with file names that end in java.
   */

  private static boolean isGood( String s )
  {
    if( s != null ) {
      return s.endsWith( ".java" );
    }
    else{
      return false;
    }
  }

  private static File         filePath = null;
  private static int          hashcode = 0;
  private static StringBuffer sb       = new StringBuffer();

  public static void main(String args[]) 
  {
    try {
      if( args.length == 1 ) {
      String path = args[ 0 ];
      
        filePath = new File( path );
        
        String outlist = getListing( filePath );
        
        System.out.println( outlist );
      }
      else {
        System.err.println( "ERROR: MUST GIVE ONE ROOT DIRECTORY" );
      }
    }
    catch (IOException e) {
      
      System.err.println("Problem: "+e);
    }
  }
}
