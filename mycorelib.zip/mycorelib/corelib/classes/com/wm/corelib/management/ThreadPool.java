package com.wm.corelib.management;

import com.wm.corelib.concurrent.WMThreadPoolExecutor;
import com.wm.corelib.jmxadmin.WmtMBeanImpl;

import javax.management.NotCompliantMBeanException;
import java.util.concurrent.TimeUnit;

/**
 * ThreadPool MBean implementation. Basically delegates requests to the WMThreadPoolExecutor.
 *
 * @since December 2005
 * @version $Id: ThreadPool.java,v 1.2 2009/04/08 05:14:11 mkishore Exp $
 * @author Igor.Dralyuk@walmart.com
 */
public class ThreadPool extends WmtMBeanImpl implements ThreadPoolMBean {

    private final WMThreadPoolExecutor _pool;

    public ThreadPool(WMThreadPoolExecutor pool) throws NotCompliantMBeanException {
        super(ThreadPoolMBean.class);
        _pool = pool;
    }

    public String getID() {
        return _pool.getID();
    }

    public String getType() {
        return _pool.getType().toString();
    }

    public int getQueueCapacity() {
        return _pool.getQueueCapacity();
    }

    public int getQueueSize() {
        return _pool.getQueueSize();
    }

    public long getTotalAcceptedRequests() {
        return _pool.getTotalAcceptedRequests();
    }

    public long getTotalCompletedRequests() {
        return _pool.getTotalCompletedRequests();
    }

    public long getTotalRejectedRequests() {
        return _pool.getTotalRejectedRequests();
    }

    public long getTotalUncaughtExceptions() {
        return _pool.getTotalUncaughtExceptions();
    }

    public long getTotalExecutionTime() {
        return _pool.getTotalExecutionTime();
    }

    public int getMinimumSize() {
        return _pool.getCorePoolSize();
    }

    public int getMaximumSize() {
        return _pool.getMaximumPoolSize();
    }

    public long getKeepAliveTime() {
        return _pool.getKeepAliveTime(TimeUnit.SECONDS);
    }

    public void setMinimumSize(int i) {
        _pool.setCorePoolSize(i);
    }

    public void setMaximumSize(int i) {
        _pool.setMaximumPoolSize(i);
    }

    public void pause() {
        _pool.pause();
    }

    public void resume() {
        _pool.resume();
    }

    public void resetStats() {
        _pool.resetStats();
    }
}
