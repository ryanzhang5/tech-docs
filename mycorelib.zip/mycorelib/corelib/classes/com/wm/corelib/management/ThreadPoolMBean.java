package com.wm.corelib.management;

import com.wm.corelib.jmxadmin.WmtMBean;
import com.wm.corelib.concurrent.WMThreadPoolExecutor;
import com.wm.corelib.annotation.Description;
import com.wm.corelib.annotation.PName;

/**
 * WMThreadPoolExecutorMBean
 *
 * @since December 2005
 * @version $Id: ThreadPoolMBean.java,v 1.2 2009/04/08 05:14:11 mkishore Exp $
 * @author Igor.Dralyuk@walmart.com
 */
public interface ThreadPoolMBean extends WmtMBean {

    /** Retrieves the Identification String of this pool */
    @Description("Retrieves the Identification String of this pool")
    public String getID();

    /** Retrieves the Type (IO_BOUND/CPU_BOUND) of this pool */
    @Description("Retrieves the Type (IO_BOUND/CPU_BOUND) of this pool")
    public String getType();

    /** How large is the queue */
    @Description("How large is the queue")
    public int getQueueCapacity();

    /** How many tasks are on the queue */
    @Description("How many tasks are on the queue")
    public int getQueueSize();

    /** How many requests have been accepted */
    @Description("How many requests have been accepted")
    public long getTotalAcceptedRequests();

    /** How many requests have been completed */
    @Description("How many requests have been completed")
    public long getTotalCompletedRequests();

    /** How many requests have been rejected */
    @Description("How many requests have been rejected")
    public long getTotalRejectedRequests();

    /** How many uncaught exceptions were thrown */
    @Description("How many uncaught exceptions were thrown")
    public long getTotalUncaughtExceptions();

    /** Total amount of time spent executing requests */
    @Description("Total amount of time spent executing requests")
    public long getTotalExecutionTime();

    /** Minimum number of threads in the pool */
    @Description("Minimum number of threads in the pool")
    public int getMinimumSize();

    /** Maximum possible number of threads in the pool */
    @Description("Maximum possible number of threads in the pool")
    public int getMaximumSize();

    /** KeepAlive time for threads (in seconds) */
    @Description("KeepAlive time for threads (in seconds)")
    public long getKeepAliveTime();

    /** Set the minimum number of threads in the pool */
    @Description("Set the minimum number of threads in the pool")
    public void setMinimumSize(@PName("size") int i);

    /** Set the maximum possible number of threads in the pool */
    @Description("Set the maximum possible number of threads in the pool")
    public void setMaximumSize(@PName("size") int i);

    /** Suspends the pool - new tasks will be queued up */
    @Description("Suspends the pool - no new tasks will be executed")
    public void pause();

    /** "Un-pauses" the pool - resumes task execution */
    @Description("\"Un-pauses\" the pool - resumes task execution")
    public void resume();

    /** Resets pool statistics */
    @Description("Resets pool statistics")
    public void resetStats();
}
