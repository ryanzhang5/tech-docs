package com.wm.corelib.logging.console;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.logging.LogRecord;
import com.wm.corelib.logging.LogDataHash;
import com.wm.corelib.logging.LogDataUtil;
import com.wm.corelib.util.NVPair;

/**
 * Formatter for printing a LogDataHash message as a simple string. Should be
 * used when writing the log message to console or the tomcat log.
 * <p>
 * @author David Casper
 */
public class SimpleFormatter extends java.util.logging.Formatter {

    private static final SimpleDateFormat DATE_FORMATTER = 
        new SimpleDateFormat("EEE yyyy/MM/dd HH:mm:ss:SSS z");

    /**
     * Main processing method, this overwrites abstract class in Formatter. 
     * This method first tries to extract a LogDataHash object from the LogRecord 
     * parameter array.  If that's successful, then it formats the message based 
     * on the data contained.  If the LogDataHash is not found, then it uses
     * only LogRecord information to format the message.
     * <p>
     * @param record LogRecord object to be formatted
     * @return Formatted message string
     */
    public String format(LogRecord record) {
        StringBuffer buffer = new StringBuffer();

        // Write log header info
        buffer.append(formatHeader(record));

        // Write data (if present)
        buffer.append(formatData(record));
        buffer.append("\n");

        // Print stack trace (if present)
        buffer.append(formatThrown(record));
        buffer.append("\n");

        return buffer.toString();
    }

    /**
     * Takes information from the LogRecord and passes back a formatted log 
     * header string. None of the information in this header is taken from
     * the BLM Data Hash.
     * <p>
     * @param record LogRecord object to be formatted
     * @return Formatted string
     */
    public String formatHeader(LogRecord record) {
        LogDataHash dh = LogDataUtil.getLogDataHash(record);
        StringBuffer buffer = new StringBuffer();

        buffer.append("[");
        buffer.append(dh.getDomain());
        buffer.append(".");
        buffer.append(dh.getApplication());
        buffer.append(".");
        buffer.append(record.getLevel().toString());
        buffer.append(".");
        buffer.append(dh.getLogID());
        buffer.append("][");
        buffer.append(DATE_FORMATTER.format(new Date(record.getMillis())));
        buffer.append("][");
        buffer.append(record.getSourceClassName());
        buffer.append("/");
        buffer.append(record.getSourceMethodName());
        buffer.append("] <MsgText: ");
        buffer.append(record.getMessage());
        buffer.append("> <ThreadID: ");
        buffer.append(record.getThreadID());
        buffer.append("> <SessionID: ");
        buffer.append((dh.getGroupID() != null) ? dh.getGroupID() : "NULL");
        buffer.append(">" );
        return buffer.toString();
    }

    /**
     * Retrieves Throwable object from the LogRecord (if present) and passes 
     * back a formatted string that contains the stack trace. If no Throwable
     * exists, then passes back an empty string. Never returns null.
     * <p>
     * @param record LogRecord object to be formatted
     * @return Formatted string
     */
    public String formatThrown(LogRecord record) {
        Throwable thrown = LogDataUtil.getThrown(record);
        StringBuffer buffer = new StringBuffer();

        if (thrown != null) {
            StackTraceElement[] traces = thrown.getStackTrace();
            buffer.append(">> Exception: ");
            buffer.append(thrown.toString());
            buffer.append("\n");
            for (int i = 0; i < traces.length; i++) {
                buffer.append(">>     at ");
                buffer.append(traces[i].toString());
                buffer.append("\n");
            }
         }

        return buffer.toString();
    }

    /**
     * Retrieves an array of Objects from the LogRecord (if present) and passes 
     * back a formatted string that contains the object data. The method first 
     * checks if each Object is a NVPair and prints it's name and value.  If not 
     * a NVPair, then it uses a generic toString method to print the object.
     * <p>
     * @param record LogRecord object to be formatted
     * @return Formatted string
     */
    public String formatData(LogRecord record) {
        Object[] data = LogDataUtil.getDataArray(record);
        StringBuffer buffer = new StringBuffer();

        if (data != null) {
            for (int i = 0; i < data.length; i++) {
                if (data[i].getClass() == NVPair.class ||
                    data[i] instanceof NVPair )
                {
                    buffer.append(" <");
                    buffer.append(((NVPair) data[i]).name);
                    buffer.append(": ");
                    buffer.append(((NVPair) data[i]).value);
                    buffer.append(">");
                } else {
                    buffer.append(" <RawData: ");
                    buffer.append(data[i].toString());
                    buffer.append(">");
                }
            }
        }

        return buffer.toString();
    }

}
