package com.wm.corelib.logging.jms;

import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.LogRecord;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class JMSLogHandler extends Handler {

    /** Default handler level if not specified in the config file */
    private static final String DEFAULT_LEVEL = "ALL";

    /** Default log ID if not specified in the config file */
    private static final String DEFAULT_LOG_ID = "00000";

    /** Default handler application if not specified in the config file */
    private static final String DEFAULT_DOMAIN = "LOGGING";

    /** Default handler application if not specified in the config file */
    private static final String DEFAULT_APPLICATION = "WWW";

    /** Default handler message formatter if not specified in the config file */
    private static final String DEFAULT_FORMATTER =  "com.wm.corelib.logging.jms.JMSSimpleFormatter";
    
    /** Application domain from configuration file */
    private String _domain;

    /** Application name from configuration file */
    private String _application;

    /** Global log ID from configuration file */
    private String _globalLogID;
    
    private static final int CONFIG_FAILURE =100;

    private List<ILoggingAgent> agentList = new ArrayList<ILoggingAgent>();

  /** Default constructor */
  private static final BlockingQueue<String> messageQueue = new LinkedBlockingQueue<String>();
  
  private int messageSizeInKB = 5 * 1024; // 5K
  private int messageInterval = 5 * 1000; // 5 seconds
  private volatile int currentSize = 0;
  private volatile boolean isRunning = false;
  private volatile boolean forcePublished = false;
  private long lastUpdated = System.currentTimeMillis();
  /**
   * 
   */
    public JMSLogHandler() {
        super();
        configure();
    }
   
    /**
     * Private method to configure SyslogHandler from handler properties in the 
     * LogManager configuration and/or default values as specified in the 
     * class.
     */
    private void configure() {
        // Define error manager on super().Handler
        setErrorManager(
          new java.util.logging.ErrorManager(){
            public void error(String msg, Exception ex, int code) {
                System.err.println(msg + ex + code);
              }
          }
        );
        
        LogManager manager = LogManager.getLogManager();
        String cname = JMSLogHandler.class.getName();

        setDomain(manager.getProperty(".domain"));
        setApplication(manager.getProperty(".application"));
        setGlobalLogID(manager.getProperty(".logID"));
        setLevel(manager.getProperty(cname + ".level"));
        setFormatter(manager.getProperty(cname + ".formatter"));
        String msgSizeStr = manager.getProperty(cname + ".msgSizeKB");
        String msgIntervalStr = manager.getProperty(cname + ".msgInterval");
        
        try {
          if (msgSizeStr != null) {
            int msgSize = Integer.parseInt(msgSizeStr);
            if (msgSize >= 1024)
                setMessageSizeInKB(msgSize);
          }
              } catch (Exception e) {
            e.printStackTrace();
          }

      try {
        if (msgIntervalStr != null) {
          int msgInt = Integer.parseInt(msgIntervalStr);
          if (msgInt >= 5000)
              setMessageInterval(msgInt);
        }
            } catch (Exception e) {
          e.printStackTrace();
        }
        
        String agentString = manager.getProperty(cname + ".agent");

        if (agentString != null && !agentString.isEmpty() ) {
          StringTokenizer st = new StringTokenizer(agentString,",");
          while (st.hasMoreTokens()) {
            String sAgent = st.nextToken();
            try {
            Object oAgent = Class.forName(sAgent).newInstance();
              if (oAgent instanceof ILoggingAgent ) {
                  //System.err.println("Agent added to the list " + oAgent);
                  agentList.add((ILoggingAgent)oAgent);
                } //if
              } catch (Exception exp) {
                    reportError("Exception occurred while adding agents in the list", exp, -1);
              }//catch
            }//while
        } else {//if
          //no agent found to delegate message
        }
        
      TimerTask runnable = new TimerTask() {
              public void run() {
              try {
                if ( lastUpdated + messageInterval <= System.currentTimeMillis() ) {
                    forcePublished = true;
                    publishMessage();
                } else {
                  forcePublished = false;
                }
              } catch (Exception exp) {
                  exp.printStackTrace();
              }//catch
          }//run
      };
        Timer pauseTimer= new Timer("check-log-timer", true);
        pauseTimer.schedule(runnable,0,messageInterval);
     
    }

    /**
     * Set application domain name attribute, usually called from configure
     * method.
     * @param val New attribute value.
     */
    public void setDomain(String val) {
        // If input isn't defined, use the default value.
        if (val == null || "".equals(val)) {
            val = DEFAULT_DOMAIN;
        }
        _domain = val.trim();
    }
                    
    /**
     * Get value for application domain name, will never return a null.
     * @return Attribute value or default.
     */
    public String getDomain() {
        return (_domain == null) ?  DEFAULT_DOMAIN : _domain; 
    }

    /**
     * Set application name attribute, usually called from configure method.
     * @param val New attribute value.
     */
    public void setApplication(String val) {
        // If input isn't defined, use the default value.
        if (val == null || "".equals(val)) {
            val = DEFAULT_APPLICATION;
        }
        _application = val.trim();
    }

    /**
     * Get value for application name, will never return a null.
     * @return Attribute value or default.  
     */
    public String getApplication() {
        return (_application == null) ?  DEFAULT_APPLICATION : _application;
    }

    /**
     * Set global log ID attribute, usually called from configure method.
     * @param val New attribute value.
     */
    public void setGlobalLogID(String val) {
        // If input isn't defined, use the default value.
        if (val == null || "".equals(val)) {
            val = DEFAULT_LOG_ID;
        }
        _globalLogID = val.trim();
    }

    /**
     * Get value for global log ID, will never return a null.
     * @return Attribute value or default.  
     */
    public String getGlobalLogID() {
        return (_globalLogID == null) ?  DEFAULT_LOG_ID : _globalLogID;
    }
 
    /**
     * Get Level name and set it on the handler.
     * @param val Name of new level
     */
    public void setLevel(String val) {
        // If input isn't defined, use the default value.
        if (val == null || val == "") {
            val = DEFAULT_LEVEL;
        }
        // Register the new level with the logger
        try {
            super.setLevel(Level.parse(val.trim()));
        }
        catch (SecurityException ex) {
            reportError("Register Level failed.", ex, CONFIG_FAILURE);
        }
    }

    /**
     * Get Formatter name and set it on the handler.  This instantiates a Formatter
     * object from the classname and registers it on the super().Handler.
     * @param val Classname of new Formatter
     */
    public void setFormatter(String val) {
        // If input isn't defined, use the default value.
        if (val == null || val == "") {
            val = DEFAULT_FORMATTER;
        }

        // Load new formatter class
        Class clz = null;
        try {
            //clz = ClassLoader.getSystemClassLoader().loadClass(val.trim());
            clz = Thread.currentThread().getContextClassLoader().loadClass(val.trim());
        }
        catch (ClassNotFoundException ex1) {
            reportError("Configured Formatter not found", ex1, 
                CONFIG_FAILURE);
                ex1.printStackTrace();
            try {
                //clz = ClassLoader.getSystemClassLoader().loadClass(DEFAULT_FORMATTER);
                clz = Thread.currentThread().getContextClassLoader().loadClass(DEFAULT_FORMATTER);
            }
            catch (ClassNotFoundException ex2) {
                reportError("Formatter not found", ex2,
                    CONFIG_FAILURE);
                    ex2.printStackTrace();
            }
        }

        // Create new formatter instance
        Formatter newFormatter = null;
        try {
            newFormatter = (Formatter)clz.newInstance();
        }
        catch (InstantiationException ex1) {
            reportError("Create Formatter failed", ex1, CONFIG_FAILURE);
        }
        catch (IllegalAccessException ex2) {
            reportError("Create Formatter failed", ex2, CONFIG_FAILURE);
        }

        // Register new formatter with the logger
        try {
            super.setFormatter(newFormatter);
        }
        catch (SecurityException ex) {
            reportError("Register Formatter failed", ex, CONFIG_FAILURE);
        }
    }

    /**
     *  Gets a LogID value.  First it checks with the LogConfig class to see if a
     * class- or package-level value is applicable for this logger name.  If not,
     * then it takes the global default.
     */
    public String getLogID(String loggerName) {
        String id = null;

        // Use global default if not already set
        if (id == null) {
            id = this.getGlobalLogID(); 
        }
        return id; 
    }

    /**
     * Overwrites an abstract method on the super class that closes the
     * <tt>Handler</tt> and frees all associated resources.
     * <p>
     * The close method will perform a <tt>flush</tt> and then close the
     * <tt>Handler</tt>.  After close has been called this <tt>Handler</tt>
     * should no longer be used.  Method calls may either be silently
     * ignored or may throw runtime exceptions.
     * <p>
     * @exception SecurityException if a security manager exists and if
     * the caller does not have <tt>LoggingPermission("control")</tt>.
     */
    public void close() throws SecurityException {
        this.flush();
/*
      if (getAgentList() != null && !getAgentList().isEmpty()) {
        for (ILoggingAgent agent: getAgentList()) {
          try {
              agent.close();
          } catch (Exception exp) {
              reportError("Exception occurred while closing agents from the list", exp, -1);
            }
          }
        }
      */
    }
        
    /**
     * Overwrites an abstract method on the super class that flushed any buffered
     * output.  We don't do any buffering in this handler, so empty method.
     */
    public void flush() { 
        publishMessage();
      }
   
  /**
   *
   * @param record
   */
    public void publish(LogRecord record) {
        if (!isLoggable(record)) {
            return;
        }

        List<Object> objList = new ArrayList<Object>();
        objList.add(record.getLoggerName());  

        //dh.setGroupID(ThreadGroupID.get());
        objList.add(this.getApplication());
        objList.add(this.getDomain());
        record.setParameters(objList.toArray());
        
        // Log message
        doSyslog(record, record.getLevel(),
            getFormatter().format(record)); 
    }


  /**
   *
   * @param record
   * @param level
   * @param msg
   */
    private void doSyslog(LogRecord record, Level level, String msg) {
      currentSize += (msg != null ? msg.length() : 0);
      messageQueue.add(msg);
      publishMessage();
    }

  private void publishMessage() {
    if (isRunning) {
        return;
      }
    isRunning = true;
    if (currentSize >= getMessageSizeInKB() || (forcePublished && !messageQueue.isEmpty() )) {
          if (forcePublished) {
            forcePublished = false;
          }
          List<String> messageList = new ArrayList<String>();
          messageQueue.drainTo(messageList);
          currentSize = 0;
          lastUpdated = System.currentTimeMillis();
          
          StringBuffer sb = new StringBuffer();
          for (String message : messageList) {
              sb.append(message).append("\n");
            }
        
        if (getAgentList() != null && !getAgentList().isEmpty()) {
          for (ILoggingAgent agent: getAgentList()) {
            try {
                agent.publish(sb.toString());
            } catch (Exception exp) {
                reportError("Exception occurred while publishing message ", exp, -1);
              }
            }
          }
        
    } //if
    isRunning = false;
  }
  
  /**
   *
   * @param agentList
   */
  public void setAgentList(List<ILoggingAgent> agentList) {
    this.agentList = agentList;
  }

  /**
   *
   * @return
   */
  public List<ILoggingAgent> getAgentList() {
    return agentList;
  }

  public void setMessageSizeInKB(int messageSize) {
      if (messageSize >= 1024)
        this.messageSizeInKB = messageSize;
  }

  public int getMessageSizeInKB() {
    return messageSizeInKB;
  }

  public void setMessageInterval(int messageInterval) {
      if (messageInterval >= 0)
        this.messageInterval = messageInterval;
  }

  public int getMessageInterval() {
    return messageInterval;
  }
}
