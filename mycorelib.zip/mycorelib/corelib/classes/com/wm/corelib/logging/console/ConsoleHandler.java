package com.wm.corelib.logging.console;

import java.util.logging.Level;
import java.util.logging.LogRecord;
import com.wm.corelib.logging.LogHandlerCommons;

import java.util.Timer;
import java.util.TimerTask;

/**
 * This Log Handler is intended for processing messages that are destined
 * to be sent to the console (aka the tomcat log for web apps).
 * @author Mark Taylor
 */
public class ConsoleHandler extends java.util.logging.ConsoleHandler {
    private LogHandlerCommons _logHandlerCommons;
    private volatile Level customLogLevel = Level.ALL;
    private long levelFetchTime;


    /** no-arg constructor */
    public ConsoleHandler() {
        super();
        _logHandlerCommons = new LogHandlerCommons(this);
        customLogLevel = super.getLevel();
        levelFetchTime = System.currentTimeMillis(); 
        
      TimerTask task = new TimerTask() {
          boolean isFirstTime = true;
          public void run() {
            setLogLevel();
          }
      };

      Timer consoleTimer = new Timer("ConsoleTimer",true);
      consoleTimer.schedule(task,60000,60000);
        
    }

    public void setLogLevel() {
        customLogLevel = super.getLevel();
      }
    
    /**getLevel() method of java.util.logging.Handler is synchronized and causing 
     * thread blocks due to that. To reduce that issue the getLevel() method is being 
     * overridden here. And we are fetching the logging level every  1 minute instead
     *  for every request and change in logging level would propagate after 1 minute.
     * 
     */
    public  Level getLevel() {
        return customLogLevel;
    }

    public void publish(LogRecord record) {
        if (!isLoggable(record)) {
            return;
        }

        // This step fills the standard walmart.com LogDataHash structure
        _logHandlerCommons.prePublishSetupLdh(record);

        // Log the message the way we want; in this case we just
        // use the inherited implementation of console out
        super.publish(record);
    }
    
}
