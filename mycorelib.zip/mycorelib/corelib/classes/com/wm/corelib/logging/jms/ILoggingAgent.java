package com.wm.corelib.logging.jms;

public interface ILoggingAgent {
  public void publish( String msg) throws Exception;
  public void close();
}
