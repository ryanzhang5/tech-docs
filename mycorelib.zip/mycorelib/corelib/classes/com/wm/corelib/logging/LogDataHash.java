package com.wm.corelib.logging;

import com.wm.corelib.util.NVPair;
import java.util.ArrayList;
import java.util.logging.LogRecord;
import javax.servlet.http.HttpServletRequest;

/** 
 * A container object that represents all data to be logged.
 * @author David Casper
 */

public class LogDataHash {

    ////////////////////////////////////////////////////////////////////////////
    // Instance attributes
    ////////////////////////////////////////////////////////////////////////////

    /** Application name associated with the logging application */
    private String application;

    /** Application domain name associated with the logging application */
    private String domain;

    /** Event's log ID */
    private String logId;

    /** HTTP request */
    private HttpServletRequest request;
    
    /** Request ID*/
    private String requestID;

    /** Activity ID associated with the event, if applicable */
    private String activityId;

    /** Exception associated with the event, if applicable. */
    private Throwable thrown;

    /** List of data elements (NVPair objects) to be logged. */
    private ArrayList logData = new ArrayList();

    ////////////////////////////////////////////////////////////////////////////
    // Constructors
    ////////////////////////////////////////////////////////////////////////////

    /**
     * Construct an empty LogDataHash container
     */
    public LogDataHash() {}

    /**
     * Construct a LogDataHash container with a log ID
     * @param logID string value
     */
    public LogDataHash(String logID) {
        this.setLogID(logID);
    }

    ////////////////////////////////////////////////////////////////////////////
    // Instance methods
    ////////////////////////////////////////////////////////////////////////////

    /**
     * Sets HTTP request
     * @param request Request object
     */
    public void setRequest(HttpServletRequest request) {
        this.request= request;
    }

    /**
     * Gets HTTP request
     * @return Request object
     */
    public HttpServletRequest getRequest() {
        return this.request;
    }

    /**
     * Sets throwable log data
     * @param pThrown Event exception log data
     */
    public void setThrown(Throwable pThrown) {
        this.thrown = pThrown;
    }

    /**
     * Gets throwable log data
     * <p>
     * @return Event exception log data
     */
    public Throwable getThrown() {
        return this.thrown;
    }

    /**
     * Sets Log ID for log data
     * <p>
     * @param LogID Event log ID
     */
    public void setLogID(String logID) {
        this.logId = logID;
    }

    /**
     * Gets Log ID for log data
     * <p>
     * @return Event log ID
     */
    public String getLogID() {
        return this.logId;
    }

    /**
     * Sets Activity ID for log data, where an "activity" is 
     * any unique ID that helps pinpoint the work that was in 
     * progress.  For instance, in a web application this might
     * be the session ID.
     * <p>
     * @param activityID Event Activity ID
     */
    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    /**
     * Gets Activity ID for log data, where an "activity" is 
     * any unique ID that helps pinpoint the work that was in 
     * progress.  For instance, in a web application this might
     * be the session ID.
     * <p>
     * @return Event Activity ID
     */
    public String getActivityId() {
        return this.activityId;
    }

    /**
     * Deprecated method to set Group ID for log data
     * <p>
     * @param groupID Event Group ID
     * @deprecated use setActivityId instead
     */
    public void setGroupID(String groupId) {
        this.activityId = groupId;
    }

    /**
     * Deprecated method to get Group ID for log data
     * <p>
     * @return Event Group ID
     * @deprecated use getActivityId instead
     */
    public String getGroupID() {
        return this.activityId;
    }

    /**
     * Sets application domain name for log data
     * <p>
     * @param domain Application domain name
     */
    public void setDomain(String domain) {
        this.domain = domain;
    }

    /**
     * Gets application domain name for log data
     * <p>
     * @return application domain name
     */
    public String getDomain() {
        return this.domain;
    }

    /**
     * Sets application name for log data
     * <p>
     * @param app Application name
     */
    public void setApplication(String app) {
        this.application = app;
    }

    /**
     * Gets application name for log data
     * <p>
     * @return application name
     */
    public String getApplication() {
        return this.application;
    }

    /**
     * Adds a NVPair data element to the logged data array
     * <p>
     * @param pNVPair Data element as NVPair object
     */
    public void addData(NVPair pPair) {
        if (pPair != null) {
            this.logData.add(pPair);
        }
    }

    /**
     * Adds a NVPair data element to the logged data array
     * <p>
     * @param pNVPair Data element as NVPair object
     */
    public void addData(NVPair[] pPairs) {
        for (int i = 0; i < pPairs.length; i++) {
            this.addData(pPairs[i]);
        }
    }

    /**
     * Adds a data element to the logged data array
     * <p>
     * @param pName Data element name
     * @param pValue Data element value
     */
    public void addData(String pName, String pValue) {
        NVPair data = new NVPair(pName, pValue);
        this.addData(data);
    }

    public void addData(String pName, Object pValue) {
        NVPair data = new NVPair(pName, pValue);
        this.addData(data);
    }
  
    public void addData(String pName, int pValue) {
        NVPair data = new NVPair(pName, pValue);
        this.addData(data);
    }

    public void addData(String pName, char pValue) {
        NVPair data = new NVPair(pName, pValue);
        this.addData(data);
    }

    public void addData(String pName, char[] pValue) {
        NVPair data = new NVPair(pName, pValue);
        this.addData(data);
    }

    public void addData(String pName, char[] pValue, int i, int j) {
        NVPair data = new NVPair(pName, pValue, i , j);
        this.addData(data);
    }

    public void addData(String pName, byte pValue) {
        NVPair data = new NVPair(pName, pValue);
        this.addData(data);
    }

    public void addData(String pName, float pValue) {
        NVPair data = new NVPair(pName, pValue);
        this.addData(data);
    }

    public void addData(String pName, long pValue) {
        NVPair data = new NVPair(pName, pValue);
        this.addData(data);
    }

    public void addData(String pName, short pValue) {
        NVPair data = new NVPair(pName, pValue);
        this.addData(data);
    }

    public void addData(String pName, boolean pValue) {
        NVPair data = new NVPair(pName, pValue);
        this.addData(data);
    }

    public Object[] getData() {
        return this.logData.toArray();
    }

    public NVPair[] getDataAsNVPairArray() {
        NVPair[] rv = new NVPair[ this.logData.size() ];
        this.logData.toArray( rv );
        return rv;
    }

    /**
     * Writes plain-text version of this data element
     * <p>
     * @return printable text as String
     */
    public String toString() {
        StringBuffer buffer = new StringBuffer();

        //buffer.append("'" + this.getName() + "'");
        buffer.append( " = ");
        //buffer.append("'" + this.getValue() + "'");
        return buffer.toString();
    }

	public String getRequestID() {
		return requestID;
	}

	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}
}
