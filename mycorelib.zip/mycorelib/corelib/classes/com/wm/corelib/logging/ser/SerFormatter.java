package com.wm.corelib.logging.ser;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.logging.LogRecord;
import javax.servlet.http.*;
import com.wm.corelib.logging.LogDataHash;
import com.wm.corelib.logging.LogDataUtil;
import com.wm.corelib.util.NVPair;


//TODO: Change all of this code to use StringBuilder once we're on J2SE 5.0


/**
 * Formatter for marshaling a LogDataHash / LogRecord into an XML document
 * for the standard System Event Repository.
 * @author Mark Taylor
 */
public class SerFormatter extends java.util.logging.Formatter {

    /** no-arg constructor */
    public SerFormatter() {
        super();
    }

    /**
     * Main implementation method, as prescribed by abstract class Formatter.
     * @param record LogRecord object to be formatted
     * @return XML Formatted String
     */
    public String format(LogRecord record) {

        StringBuffer buffer = new StringBuffer();

        try {
            if (record == null ) {
                return "Empty LogRecord";
            }

            LogDataHash dh = LogDataUtil.getLogDataHash(record);
            if (dh == null ) {
                return "Empty LogDataHash";
            }

            buffer.append("<?xml version=\"1.0\"?>\n");
            buffer.append("<Event>\n");

            appendLogRecordHeader(buffer, record, dh);
            appendException(buffer, dh.getThrown());
            appendHttpServletRequest(buffer, dh.getRequest());

            buffer.append("</Event>\n");
            
        } catch (Exception e) {
            buffer.append("\n***Unexpected Exception During Formatting: ");
            buffer.append(e.toString());
            buffer.append("\n");
            StackTraceElement[] traces = e.getStackTrace();
            for (int i = 0; i < traces.length; i++) {
                buffer.append(traces[i].toString());
                buffer.append("\n");
            }
        }

        return buffer.toString();
    }

    /**
     * Marshals the LogRecord / LogDataHash header record into the XML structure.
     * @param buffer the StringBuffer to append to
     * @param record LogRecord object to be formatted
     * @param dh the LogDataHash object to be formatted
     */
    private void appendLogRecordHeader(StringBuffer buffer, LogRecord record, LogDataHash dh) {
        buffer.append("<Header");
        appendAttribute(buffer,"Domain",dh.getDomain());
        appendAttribute(buffer,"Application",dh.getApplication());
        appendAttribute(buffer,"Class",record.getSourceClassName());
        appendAttribute(buffer,"Method",record.getSourceMethodName());
        appendAttribute(buffer,"Level",record.getLevel().toString());
        appendAttribute(buffer,"LogId",dh.getLogID());
        appendAttribute(buffer,"Time",logRecordTime(record));
        appendAttribute(buffer,"ThreadId",String.valueOf(record.getThreadID()));
        buffer.append(">\n");  //end the Header opening tag
        
        appendElement(buffer,"ActivityId",(dh.getActivityId() != null ? dh.getActivityId() : "NULL"));
        appendElement(buffer,"Message",record.getMessage());
        
        appendLogRecordDataElements(buffer, record);
        
        buffer.append("</Header>\n");
    }

    /**
     * Retrieves an array of Objects from the LogRecord (if present) and streams
     * them into the buffer as NVpair elements.
     * @param buffer the StringBuffer to append to
     * @param record LogRecord object to be formatted
     */
    private void appendLogRecordDataElements(StringBuffer buffer, LogRecord record) {
        Object[] data = LogDataUtil.getDataArray(record);

        if (data != null) {
            for (int i = 0; i < data.length; i++) {
                if (data[i].getClass() == NVPair.class || data[i] instanceof NVPair ) {
                    appendNvPair(buffer, ((NVPair)data[i]).name, ((NVPair)data[i]).value);
                } else {
                    appendNvPair(buffer, "unknown_"+i, data[i].toString());
                }
            }
        }
    }

    /**
     * Appends a Throwable chain into a buffered XML structure.
     * @param buffer the StringBuffer to append to
     * @param thrown Throwable object to be formatted
     */
    private void appendException(StringBuffer buffer, Throwable thrown) {
        while(thrown != null) {
            StackTraceElement[] traces = thrown.getStackTrace();
            buffer.append("<Exception>\n");
            appendElement(buffer,"Message",thrown.toString());
            buffer.append("<StackTrace>\n");
            for (int i = 0; i < traces.length; i++) {
                buffer.append("<li>");
                buffer.append(traces[i].toString());
                buffer.append("</li>\n");
            }
            buffer.append("</StackTrace>\n");
            buffer.append("</Exception>\n");

            thrown = thrown.getCause();
         }
    }

    /**
     * Appends all data related to an HttpRequest into a buffered XML structure.
     * @param buffer the StringBuffer to append to
     * @param req HttpServletRequest object to be formatted
     */
    private void appendHttpServletRequest(StringBuffer buffer, HttpServletRequest req) {
        if (req == null) return;

        buffer.append("<HttpServletRequest>\n");
        String reqpath = req.getPathInfo();
        appendElement(buffer, "PathInfo", reqpath );
        appendElement(buffer, "RelativePath", req.getRequestURI() );
        appendElement(buffer, "PathTranslated", req.getPathTranslated() );
        appendElement(buffer, "QueryString", req.getQueryString() );
        appendElement(buffer, "ServerName", req.getServerName() ); //TODO: need to get from props?
        appendElement(buffer, "ClientAddress", req.getRemoteAddr() );

        buffer.append("<RequestHeader>\n");
        for (Enumeration names = req.getHeaderNames(); names!=null && names.hasMoreElements(); ){
            String name = (String) names.nextElement();
            String value = req.getHeader(name);
            appendCdataNvPair(buffer, name, value );
        }
        buffer.append("</RequestHeader>\n");

        buffer.append("<RequestParameters>\n");
        for (Enumeration names = req.getParameterNames(); names!=null && names.hasMoreElements(); ){
            String name = (String) names.nextElement();
            String[] vals = req.getParameterValues(name);
            appendCdataNvPair(buffer, name, vals[0] );
        }
        buffer.append("</RequestParameters>\n");

        buffer.append("<RequestAttributes>\n");
        for (Enumeration names = req.getAttributeNames(); names!=null && names.hasMoreElements(); ){
            String name = (String)names.nextElement();
            String value = req.getAttribute(name).toString();
            appendCdataNvPair(buffer, name, value );
        }
        buffer.append("</RequestAttributes>\n");

        buffer.append("<Session>\n");
        HttpSession sess = req.getSession(true);
        for (Enumeration names = sess.getAttributeNames(); names!=null && names.hasMoreElements(); ){
            String name = (String)names.nextElement();
            String value = sess.getAttribute(name).toString();
            appendCdataNvPair(buffer, name, value );
        }
        buffer.append("</Session>\n");

        buffer.append("</HttpServletRequest>\n");
    }


    /**
     * Used for creating attribute markup for known names whose value data is short, 
     * has no quote marks, and needs no XML encoding.
     * @param buffer the StringBuffer to append to
     * @param name name of attribute
     * @param value value of attribute
     */
    private void appendAttribute(StringBuffer buffer, String name, String value) {
        buffer.append(" ");
        buffer.append(name);
        buffer.append("=\"");
        if( value != null ) {
            buffer.append(value);
        } else {
            buffer.append("NULL");
        }
        buffer.append("\" ");
    }
    
    /** 
     * Used for creating stand-alone element tags with known names and complex 
     * value data that may be long, have quotes, or other XML encodables in them. 
     * @param buffer the StringBuffer to append to
     * @param name name of element
     * @param value value of element
     */
    private void appendElement(StringBuffer buffer, String name, String value) {
        buffer.append("<");
        buffer.append(name);
        buffer.append(">");
        if( value != null ) {
            appendAsQuotedXml(buffer, value);
        } else {
            buffer.append("NULL");
        }
        buffer.append("</");
        buffer.append(name);
        buffer.append(">\n");
    }
    
    /** 
     * Used for creating stand-alone element tags with known names and complex 
     * value data that are too complex for simple XML quoting.
     * @param buffer the StringBuffer to append to
     * @param name name of element
     * @param value value of element
     */
    private void appendCdataElement(StringBuffer buffer, String name, String value) {
        buffer.append("<");
        buffer.append(name);
        buffer.append(">");
        if( value != null ) {
            appendAsCdata(buffer, value);
        } else {
            buffer.append("NULL");
        }
        buffer.append("</");
        buffer.append(name);
        buffer.append(">\n");
    }

    /** 
     * Used for enclosing simple NV data in such a way that we will not need
     * to have special elements or attributes for the infinite number of names
     * that might appear in a session or other structure.
     * @param buffer the StringBuffer to append to
     * @param name name of generic data
     * @param value value of generic data
     */
    private void appendNvPair(StringBuffer buffer, String name, String value) {
        buffer.append("<NVpair name=\"");
        appendAsQuotedXml(buffer, name);
        buffer.append("\">");
        if( value != null ) {
            appendAsQuotedXml(buffer, value);  
        } else {
            buffer.append("NULL");
        }
        buffer.append("</NVpair>\n");
    }

    /** 
     * Used for enclosing complex or formatted NV data in such a way that we 
     * will not need to have special elements or attributes for the infinite 
     * number of names that might appear in a session or other structure.
     * @param buffer the StringBuffer to append to
     * @param name name of generic data
     * @param value value of generic data
     */
    private void appendCdataNvPair(StringBuffer buffer, String name, String value) {
        buffer.append("<NVpair name=\"");
        appendAsQuotedXml(buffer, name);
        buffer.append("\">");
        if( value != null ) {
            appendAsCdata(buffer, value);  
        } else {
            buffer.append("NULL");
        }
        buffer.append("</NVpair>\n");
    }

    /** 
     * Adds a String to a StringBuffer replacing all XML special 
     * characters with quoted, safe text 
     * @param buffer the StringBuffer to append to
     * @param string text to be XML quoted
     */
    private void appendAsQuotedXml(StringBuffer buffer, String s) {
        if (s == null) return;
        
        for(int i = 0, max = s.length(); i < max; i++) {
            char c = s.charAt(i);
            if (c == '&') {
                buffer.append("&amp;");
            } else if (c == '<') {
                buffer.append("&lt;");
            } else if (c == '>') {
                buffer.append("&gt;");
            } else if (c == '"') {
                buffer.append("&quot;");
            } else if (c == '\'') {
                buffer.append("&apos;");
            } else if (c == '\r') {
                buffer.append("&#13;");
            } else {
                buffer.append(c);
            }
        }
    }

    /** 
     * Adds a String to a StringBuffer replacing all XML special 
     * characters with quoted, safe text and quoting the whole
     * things as CDATA so whitespace will not be lost.
     * @param buffer the StringBuffer to append to
     * @param string text to be XML quoted
     */
    private void appendAsCdata(StringBuffer buffer, String s) {
        if (s == null) return;
        
        buffer.append("<![CDATA[");
        appendAsQuotedXml(buffer, s);
        buffer.append("]]>");
    }
    
    /** Helper method to get a thread-safe, formatted date string */
    private String logRecordTime(LogRecord record) {
        return new SimpleDateFormat("EEE yyyy/MM/dd HH:mm:ss:SSS z")
            .format( new Date(record.getMillis()) );
    }
    
}
