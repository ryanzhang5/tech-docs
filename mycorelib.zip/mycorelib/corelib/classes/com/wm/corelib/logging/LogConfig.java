package com.wm.corelib.logging;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.logging.Logger;
import java.util.logging.Level;
  

/** 
 * This class is constructed when the Log Manager is initialized. 
 * Designed to initialize local loggers and set specialized behavior for 
 * Walmart.com application logic.
 *
 * @author David Casper
 */
public class LogConfig {

    /** Static internal singleton LogConfig object */
    private static LogConfig _config = null;

    /** Hash of local loggers */
    private Hashtable _loggers = new Hashtable(0);

    /** Hash of local log ids */
    private Hashtable _localLogIDs = new Hashtable(0);

    /** Hash of configuration file properties */
    private Properties _props = new Properties();

    /* Static block that creates new LogConfig and reads the configuration file */
    static {
        if (_config == null) {
            _config = new LogConfig();
        }

        _config.readConfiguration();
    }

    /**
     * Default constructor.  Doesn't anything here, since the work is done in
     * a static block. This needs to be public, because it's called from the 
     * LogManager object.
     */
    public LogConfig() {} 

    /**
     * Static method to get the singleton LogConfig object.
     * <p>
     * @return The internal static LogConfig object
     */
    public static LogConfig getConfig() {
        return _config;
    }

    /**
     * Read the logging configuration from the config file.  This needs to be
     * public, because it can be called from the admin/logging.gsp page to reload
     * the configuration.
     * <p>
     * The same rules are used for locating the configuration properties as are
     * used at startup.  So normally the logging properties will be re-read from
     * the same file that was used at startup.
     */
    public synchronized void readConfiguration() {
        String fname = System.getProperty("java.util.logging.config.file");
        if (fname == null) {
            // All Walmart.com application constants are in the config file,
            // so do nothing if not defined.
            return;
        }

        // reset the properties
        _props.clear();
        InputStream in = null;
        try {
            in = new FileInputStream(fname);
            BufferedInputStream bin = new BufferedInputStream(in);

            // Load the properties
            _props.load(bin);
        } catch (IOException ex) {
            // do something here?
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException ex) {
                    // do something here?
                }
            }
        }

        _config.setLocalLoggers();
    }

    /**
     * Set configuration for local loggers.
     * <p>
     * Looks for local logger definitions in the config file and loads the loggers
     * if they aren't already cached.  Any log level definitions in the file will
     * be applied using Logger.setLevel().
     */
    public synchronized void setLocalLoggers() {
        // reset the local loggers
        _loggers.clear();
        _localLogIDs.clear();

        for (Enumeration names = _props.propertyNames() ; names.hasMoreElements() ;) {
            String name = ((String) names.nextElement()).trim();
            if (!name.startsWith("local.")) {
                continue;
            }

            String paramName = name.substring(name.lastIndexOf(".") + 1);
            String loggerName = name.substring(name.indexOf(".") + 1, name.lastIndexOf("."));
            //System.out.println("Logger: '" + loggerName + "', Param: '" + paramName 
            //    + ", Value: '" + _props.getProperty(name) + "'");
            
            if ("Level".equalsIgnoreCase(paramName)) {
                addLocalLogger(loggerName, _props.getProperty(name));
            } else if ("logID".equalsIgnoreCase(paramName)) {
                addLocalLogger(loggerName, null);
                _localLogIDs.put(loggerName, _props.getProperty(name));
            }
        }
    }

    /**
     * Set local logger in internal hash table. First, it checks if a logger
     * already exists in the hash with the specified name.  If not, then it 
     * creates a new one and inserts it into hash.  Next, it tries to set the
     * level on the new logger if specified (i.e. not null).
     * <p>
     * @param loggerName Logger name
     * @param levelName Logger level as a string (may be null)
     */
    public synchronized void addLocalLogger(String loggerName, String levelName) {
        // Try to get logger from local cache
        Logger theLogger = (Logger) _loggers.get(loggerName);

        // If not found, create new logger with LogManager
        if (theLogger == null) {
            theLogger = Logger.getLogger(loggerName);
            _loggers.put(loggerName, theLogger);
        }

        // Name may be null if this local logger only has a logID property.
        if (levelName != null) {
            theLogger.setLevel(Level.parse(levelName));
        }
    }

    /**
     * Find the log ID that should be applied for a specific class logger. If a
     * localized logID wasn't specified for the class logger, then it climbs the
     * logger heirachy by asking for the logger's parent and checking it for a
     * non-null logID value. Keeps going until it hits the root logger and gets
     * the global default value.
     * <p>
     * @param name Name of the class logger
     * @return logID value for this logger or null if none was found.
     */
    public String getLocalLogID(String name) {
        // Get named logger and initialize id variable.
        Logger target = Logger.getLogger(name);
        String id = null;

        // Climb logger heirarchy and look for first non-null id.
        while (target != null && id == null) {
            id = (String) _localLogIDs.get((Object) target.getName());
            //System.out.println("getLocalLogID: [id="+id+"], target=["+target.getName()+"]");
            target = target.getParent();
        }

        // Return localized value or null if not found.
        return id;
    }

    /**
     * Get the contents of the internal logger has as an object array.  This is
     * used by the admin screen to display the configuration.
     * <p>
     * @return Array of customized local loggers
     */
    public Object[] getLocalLoggers() {
        return _loggers.values().toArray();
    }
}
