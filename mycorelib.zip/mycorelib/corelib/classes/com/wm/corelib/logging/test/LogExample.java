package com.wm.corelib.logging.test;

import java.util.logging.Level;
import java.util.logging.Logger;
import com.wm.corelib.logging.LogDataHash;

public class LogExample implements LogDataKey {
    private static String className = LogExample.class.getName();

    public static void main(String[] args) {
        LogExample le = new LogExample();
        le.logSimpleMessage(Level.WARNING);
        le.logDataMessage(Level.SEVERE);
        le.logException(Level.FINE);
    }
  
    public LogExample() {}
  
    public void logSimpleMessage(Level myLevel) {
        this.logSimpleMessage(myLevel, className);
    }
    public void logSimpleMessage(Level myLevel, String name) {
        Logger theLogger = Logger.getLogger( name );
        if ( theLogger.isLoggable(myLevel) ) {
            String msg = "Hello logging, this is " + myLevel.getName() + "!";
            theLogger.log(myLevel, msg);
        }
    }

    public void logDataMessage(Level myLevel) {
        this.logDataMessage(myLevel, className);
    }
    public void logDataMessage(Level myLevel, String name) {
        Logger theLogger = Logger.getLogger( name );
        if ( theLogger.isLoggable(myLevel) ) {
            String msg = "Hello data logging, this is " + myLevel.getName() + "!";
            LogDataHash dh = new LogDataHash();
            dh.setActivityId("123456789aaa");
            dh.addData(ORDER_ID, "2677000111222");
            theLogger.log(myLevel, msg, dh);
        }
    }

    public void logException(Level myLevel) {
        this.logException(myLevel, className);
    }

    public void logException(Level myLevel, String name) {
        int numer = 1;
        int denom = 0;
        int result = 0;

        Logger theLogger = Logger.getLogger( name );
        try {
            result = numer / denom;
        } catch (Throwable th) {
            if ( theLogger.isLoggable(myLevel) ) {
                String msg = "Hello exception logging, this is " + myLevel.getName() + "!";
                LogDataHash dh = new LogDataHash();
                dh.setActivityId("123456789bbb");
                dh.setThrown(th);
                dh.addData(TARGET_URL, "http://www.ineedmorecowbell.com");
                theLogger.log(myLevel, msg, dh);
            }
        }
    }
}
