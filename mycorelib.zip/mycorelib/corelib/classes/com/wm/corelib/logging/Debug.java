package com.wm.corelib.logging;

import com.wm.corelib.util.StringUtil;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;

/**
 * Utilities for debugging and examining the current
 * threads call stack.  You must either set the system
 * property defined by DEBUG_PROPERTY to "true" or instantiate
 * a Debug object as <code>new Debug( true )</code> to see any
 * output.
 */
public class Debug
{
    // System property, this governs the "enabled" flag for the default
    // Debug object
    public static final String DEBUG_PROPERTY = "com.wm.corelib.logging.debug";

    // Default debug prefix
    public static final String DEBUG_PREFIX = "[cl.debug] ==>";

    // Indent to use for the stacktrace
    public static final String STACKTRACE_INDENT = "    ";

    // Default debug object
    private static Debug defaultInstance;

    // Whether we are to print messages or not
    private boolean enabled;

    /**
     * Wrapper for Debug( Boolean.getProperty( DEBUG_PROPERTY ) ).
     */
    private Debug()
    {
        this( Boolean.getBoolean( DEBUG_PROPERTY ) );
    }

    /**
     * If called with a "false" argument then debug() calls
     * will do nothing -- if enabled then
     */
    public Debug( boolean enabled )
    {
        setEnabled( enabled );
    }

    /**
     * @return a default Debug object that is governed by the
     *         system property named by DEBUG_PROPERTY.
     */
    public static Debug getDefaultInstance()
    {
        if ( defaultInstance == null ) {
            defaultInstance = new Debug();
        }
        return defaultInstance;
    }

    /**
     * If set to true enables debug output, if false no output is
     * generated.
     */
    public void setEnabled( boolean enabled )
    {
        this.enabled = enabled;
    }

    /**
     * @return true if debug output is enabled, false otherwise.
     */
    public boolean getEnabled()
    {
        return enabled;
    }

    /**
     * Prints a debug message with the default prefix, showing all
     * stacktrace elements to System.out.
     */
    public static void debug( String message )
    {
        Debug debug = getDefaultInstance();
        if ( debug.getEnabled() ) {
            // Write our debug message
            debug.debug( DEBUG_PREFIX, message, System.out, 1, -1 );
        }
    }

    /**
     * Prints a debug message to given stream (if non-null), with the
     * given prefix and up to the given number of stacktrace elements.
     * <p>
     * If <code>ignoreDepth</code> is positive, <code>ignoreDepth</code>
     * stacktrace elements are popped from the stack before printing.
     * <p>
     * If <code>maxDepth</code> is negative then all stacktrace elements
     * are printed.
     */
    public void debug( String prefix, String message, OutputStream os,
            int ignoreDepth, int maxDepth )
    {
        if ( ! enabled || os == null ) {
            return;
        }
        debug( prefix, message, new OutputStreamWriter( os ),
                ignoreDepth + 1, maxDepth );
    }

    /**
     * Prints a debug message to given writer (if non-null), with the
     * given prefix and up to the given number of stacktrace elements.
     * <p>
     * If <code>ignoreDepth</code> is positive, <code>ignoreDepth</code>
     * stacktrace elements are popped from the stack before printing.
     * <p>
     * If <code>maxDepth</code> is negative then all stacktrace elements
     * are printed.
     */
    public void debug( String prefix, String message, Writer writer,
            int ignoreDepth, int maxDepth )
    {
        if ( ! enabled || writer == null ) {
            return;
        }

        // Save in a StringBuffer to write at once, this will minimize the
        // chances that output from other threads would get mixed up with
        // us
        StringBuffer output = new StringBuffer( "\n" );

        // Make sure we don't print out nulls for a prefix
        String pref = StringUtil.getNonNull( prefix );

        // Print out the main message, inserting our prefix in any newline
        // breaks in the original message
        output.append( pref + " " +
                (message != null ? message.replaceAll( "\n", pref + " " ) : "(null message)")
                + "\n" );

        // Print out the call stack
        output.append( pref + " " + "Call stack:\n" );
        StackTraceElement[] stack = getCallStack( ignoreDepth + 1 );
        // Use a variable to save a method call in the for loop
        int depth = maxDepth < 0 ? stack.length : Math.min( stack.length, maxDepth );
        for ( int pos = 0; pos < depth; ++pos ) {
            output.append( pref + " " + STACKTRACE_INDENT
                    + stack[pos].getClassName()
                    + "." + stack[pos].getMethodName() + "()"
                    + (stack[pos].isNativeMethod() ? " [native method]" : StringUtil.BLANK_STRING)
                    + " at line " + stack[pos].getLineNumber()
                    + " of " + stack[pos].getFileName() + "\n" );
        }

        // Write our output and flush the writer
        PrintWriter pw = (writer instanceof PrintWriter) ? (PrintWriter) writer : new PrintWriter( writer );
        pw.println( output.toString() );
        pw.flush();
    }

    /**
     * Shortcut to get the current call stack minus the callers method.
     */
    public static StackTraceElement[] getCallStack()
    {
        return getCallStack( 1 );
    }

    /**
     * Gets the current call stack.  If <code>removeCaller</code> is true then
     * the callers stacktrace element is removed before being returned.
     *
     * @return the current stacktrace, optionally minus the callers stacktrace
     *         element.
     */
    public static StackTraceElement[] getCallStack( boolean removeCaller )
    {
        return getCallStack( removeCaller ? 2 : 1 );
    }

    /**
     * Utility method to perform the extra lines of code to create a
     * new exception and remove the first <code>ignoreDepth</code>
     * elements of the call stack (since the caller is often not interested in their
     * own method call). Never returns null.
     * <p>
     * <b>NOTE</b>: be careful when wrapping this method as it adds another
     * <code>StackTraceElement</code> to the stack.
     */
    public static StackTraceElement[] getCallStack( int ignoreDepth )
    {
        // Increment our ignoreDepth by one -- we never want THIS method
        // to be in the call stack
        StackTraceElement[] fullStack = new Exception().getStackTrace();
        int depth = fullStack != null ? Math.min( fullStack.length, (ignoreDepth+1) ) : 0;
        if ( depth < 0 ) {
            // Some wiseguy passed us a negative number
            depth = 0;
        }
        StackTraceElement[] callerStack = new StackTraceElement[ fullStack.length - depth ];

        // Skip the first <depth> elements of the full stack trace
        for ( int pos = depth; fullStack != null && pos < fullStack.length; ++pos ) {
            callerStack[ (pos-depth) ] = fullStack[ pos ];
        }
        return callerStack;
    }
}
