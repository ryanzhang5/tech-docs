package com.wm.corelib.logging.test;

public interface LogDataKey {

    public static final String ORDER_ID = "OrderID";
    public static final String ITEM_ID = "ItemID";
    public static final String TARGET_URL = "TargetURL";

}
