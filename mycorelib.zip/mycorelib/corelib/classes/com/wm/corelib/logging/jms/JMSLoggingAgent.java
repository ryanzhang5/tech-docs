package com.wm.corelib.logging.jms;

import com.tibco.tibems.ufo.TibjmsUFOQueueConnectionFactory;

import java.util.logging.LogManager;

import javax.jms.ExceptionListener;
import javax.jms.JMSException;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;

/**
 * 
 */
public class JMSLoggingAgent implements ILoggingAgent, ExceptionListener {
  private static final String DEFAULT_EMSSERVERURL = "tcp://localhost:7222";
  private static final String DEFAULT_EMSQUEUENAME = "msgqueue";

  private String tibcoURL = null;
  private String queueName = null;  
  private String tibcoUser, tibcoPass = null;
  
  private QueueSession        queueSession          = null;
  private QueueConnection     queueConnection       = null;
  private QueueConnectionFactory queueFactory       = null;
  private javax.jms.Queue queue = null;
  private QueueSender sender = null;


  /**
  * 
  */
  public JMSLoggingAgent() {
      super();
      try {
      LogManager manager = LogManager.getLogManager();
      String cname = JMSLogHandler.class.getName();

      tibcoURL = manager.getProperty(cname + ".emshosturl");
      queueName = manager.getProperty(cname + ".emsqueuename");
      tibcoUser = manager.getProperty(cname + ".emshostuser");
      tibcoPass = manager.getProperty(cname + ".emshostpass");
      
      if (tibcoURL == null || tibcoURL.isEmpty()) {
          tibcoURL = DEFAULT_EMSSERVERURL;
      }
  
      if (queueName == null || queueName.isEmpty()) {
          queueName = DEFAULT_EMSQUEUENAME;
      }
      configureQueue();
      } catch (Exception exp) {
          exp.printStackTrace();
        }
  }

  /**
   * 
   */
  private void configureQueue() {
      try {
          close();
          queueFactory = new TibjmsUFOQueueConnectionFactory(tibcoURL);
          queueConnection = queueFactory.createQueueConnection(tibcoUser,tibcoPass);
          queueConnection.setExceptionListener(this);
          queueConnection.start();

        if (queueConnection != null && queueSession == null) {
          queueSession = queueConnection.createQueueSession(false,javax.jms.Session.AUTO_ACKNOWLEDGE);
          queue = queueSession.createQueue(queueName); 
          sender = queueSession.createSender(queue);
        } 
      } catch (Exception e) {
        e.printStackTrace();
      }
    
    }
  /**
   *
   * @param message
   * @throws Exception
   */
  private void sendMessageToTibco(String message) throws Exception{
    try {
/*      
      if (queueFactory == null) {
        queueFactory = new TibjmsUFOQueueConnectionFactory(tibcoURL);
      }
      if (queueFactory != null && queueConnection == null) {
        queueConnection = queueFactory.createQueueConnection(null,null);
        queueConnection.setExceptionListener(this);
        queueConnection.start();
        checkAndcreateQueue();
      }
*/
      if (queueSession == null) {
          configureQueue();
      }
      
      if (queueSession != null) {
          javax.jms.TextMessage emsmsg = queueSession.createTextMessage();
          emsmsg.setText(message);
          sender.send(emsmsg);
      }
    }catch (JMSException jmse) {
      jmse.printStackTrace();
      configureQueue();
      throw jmse;
    }catch (Exception e) {
      e.printStackTrace();
      configureQueue();
      throw e;
    }
  }

  /**
   *
   * @param msg
   * @throws Exception
   */
  public void publish( String msg) throws Exception {
        sendMessageToTibco(msg);
    }

  /**
   *
   * @param e
   */
  public void onException(JMSException e) {
      try {
          // print the connection exception status
          e.printStackTrace();
        if (queueFactory instanceof TibjmsUFOQueueConnectionFactory) {
          ((TibjmsUFOQueueConnectionFactory)queueFactory).recoverConnection(queueConnection);
            recoverQueue();
        }
      } catch (JMSException ex) {
          ex.printStackTrace();
      }
  }

  /**
   *
   * @throws JMSException
   */
  private void recoverQueue() throws JMSException {
      if (queueConnection != null && queueSession == null) {
        queueSession = queueConnection.createQueueSession(false,javax.jms.Session.AUTO_ACKNOWLEDGE);
        queue = queueSession.createQueue(queueName); 
        sender = queueSession.createSender(queue);
      } 
    }      

  public void close() {
      try {
        if  (sender != null) {
          sender.close();
        }
      } catch (Exception exp) {
          //exp.printStackTrace();
        }

      try {
        if  (queueSession != null) {
          queueSession.close();
        }
      } catch (Exception exp) {
          //exp.printStackTrace();
        }

      try {
        if  (queueConnection != null) {
          queueConnection.stop();
        }
      } catch (Exception exp) {
          //exp.printStackTrace();
        }

      queueFactory = null;
      queueConnection = null;
      queueSession = null;
      
      
    }  
}
