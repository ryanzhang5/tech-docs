package com.wm.corelib.logging;

import java.util.ArrayList;
import java.util.logging.LogRecord;
import com.wm.corelib.util.NVPair;

/** 
 * A set of utility methods around the LogDataHash object definition.
 * @author David Casper
 */

public class LogDataUtil {

    ////////////////////////////////////////////////////////////////////////////
    // Static class methods
    ////////////////////////////////////////////////////////////////////////////

    /**
     * Static utility method for getting a LogDataHash object out of a Java 
     * logging LogRecord object.
     * <p>
     * @param record A java.util.logging.LogRecord object.
     * @return The LogDataHash object or null.
     */
    public static LogDataHash getLogDataHash(LogRecord record) {
        LogDataHash dh = null;
        Object[] params = record.getParameters();
        int paramsLength = ( params == null ) ? 0 : params.length;

        if ((paramsLength == 1) && (params[0] != null) && 
            (params[0].getClass() == LogDataHash.class || params[0] instanceof LogDataHash)) 
        {
            dh = (LogDataHash) params[0];
        } else {
            dh = convertParams(params, record.getThrown());
            params = new Object[1];
            params[0] = (Object) dh;
            record.setParameters(params);
        }

        return dh;
    }

    /**
     * Convert LogRecord parameters into a LogDataHash object. 
     * This gets called if the parameter list doesn't contain exactly one
     * object that's a LogDataHash.
     * <p>
     * @param params Object array taken from the LogRecord
     * @param thrown Thrown object taken from the LogRecord
     * @return Converted LogDataHash object
     */
    private static LogDataHash convertParams(Object[] params, Throwable thrown) {
        LogDataHash dh = new LogDataHash();

        for (int i = 0; params !=null && i < params.length; i++) {
            dh.addData("UnknownData", (params[i] == null) ? "NULL" : params[i].toString());
        }

        if (thrown != null) {
            dh.setThrown(thrown);
        }
         
        return dh;
    }

    /**
     * Static utility method for getting a Throwable object out of a Java 
     * logging LogRecord object.
     * <p>
     * @param record A java.util.logging.LogRecord object.
     * @return A Throwable object or null.
     */
    public static Throwable getThrown(LogRecord record) {
        LogDataHash dh = getLogDataHash(record);
 
        // if LogDataHash is not null, then return Throwable on the data
        // hash (may be null).  Otherwise take the Throwable from the
        // Log Record (may be null).
        return ( (dh != null) ? dh.getThrown() : record.getThrown() );
    }

    /**
     * Static utility method for getting an array of data Objects from a Java
     * logging LogRecord object.
     * <p>
     * @param record A java.util.logging.LogRecord object.
     * @return Array of data objects.
     */
    public static Object[] getDataArray(LogRecord record) {
        LogDataHash dh = getLogDataHash(record);
 
        // if LogDataHash is not null, then return Throwable on the data
        // hash (may be null).  Otherwise take the Throwable from the
        // Log Record (may be null).
        return ( (dh != null) ? dh.getData() : record.getParameters() );
    }

}
