package com.wm.corelib.logging;

import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.LogRecord;
import com.wm.corelib.logging.ErrorManager;
import com.wm.corelib.logging.LogDataHash;
import com.wm.corelib.logging.LogDataUtil;
import com.wm.corelib.logging.LogConfig;
import com.wm.corelib.logging.ThreadGroupID;

/**
 * This class defines a set of shared Walmart.com extensions and helper 
 * implementations for log message handling. The simplest way to use this 
 * framework is to extend a system log Handler (such as <code>Handler</code> 
 * or <code>StreamHandler</code>) and include an instance of this class in it.
 * Call this class' constructor at the end of your Handler's constructor, and
 * call the <code>publishPrep()</code> method at the top of your Handler's 
 * publish method.
 * <p>
 * <b>Configuration:</b>
 * Unless you provide valid values in the <tt>LogManager</tt> configuration 
 * properties, your Handler will be initialized using the following values:
 * <ul>
 * <li>   .domain
 *        source application domain for generated log messages
 *        (defaults to <tt>UNDEFINED</tt>)
 * <li>   .application
 *        source application for generated log messages
 *        (defaults to <tt>UNDEFINED</tt>)
 * <li>   .logID
 *        default Log ID for generated log messages
 *        (defaults to <tt>00000</tt>)
 * <li>   com.wm.corelib.logging.BaseLogHandler.level
 *        specifies the default level for the <tt>Handler</tt>
 *        (defaults to <tt>Level.ALL</tt>).
 * <li>   com.wm.corelib.logging.BaseLogHandler.formatter
 *        specifies the name of a <tt>Formatter</tt> class to use
 *        (defaults to <tt>com.wm.corelib.logging.SimpleTextFormatter</tt>).
 * </ul>
 * <p>
 *
 * @author Mark Taylor (based on the prior work of David Casper)
 */
public class LogHandlerCommons {

    /** Default handler application if not specified in the config file */
    private static final String DEFAULT_DOMAIN = "UNDEFINED";

    /** Default handler application if not specified in the config file */
    private static final String DEFAULT_APPLICATION = "UNDEFINED";

    /** Default log ID if not specified in the config file */
    private static final String DEFAULT_LOG_ID = "00000";

    /** Default handler level if not specified in the config file */
    private static final String DEFAULT_LEVEL = "ALL";

    /** Default handler message formatter if not specified in the config file */
    private static final String DEFAULT_FORMATTER =
        "com.wm.corelib.logging.SimpleTextFormatter";

    /** Application domain from configuration file */
    private String _domain;

    /** Application name from configuration file */
    private String _application;

    /** Global log ID from configuration file */
    private String _globalLogID;

    /** Retains a ref back to the parent so we can interact with it  */
    private Handler _parent;
    
    /** Retains a ref to the ErrorManager set on the parent, 
     * so we can interact with it  
     */
    private ErrorManager _errmgr;

    /** inaccessible no-arg constructor */
    private LogHandlerCommons () {}

    /** Required constructor which provides a reference to the parent Handler */
    public LogHandlerCommons ( Handler parent ) {

        // retain a back-pointer for future use
        _parent = parent;
        
        // Set a "stderr" error manager on the parent Handler
        _errmgr = new ErrorManager();
        _parent.setErrorManager(_errmgr);

        // Get configuration details from the property file using
        // the current class' name as a base string.  Classes extended
        // from the BaseLogHandler will have their own names used.
        String cname = _parent.getClass().getName();
        LogManager manager = LogManager.getLogManager();
        setDomain(manager.getProperty(".domain"));
        setApplication(manager.getProperty(".application"));
        setGlobalLogID(manager.getProperty(".logID"));
        setLevel(manager.getProperty(cname + ".level"));
        setFormatter(manager.getProperty(cname + ".formatter"));
    }

    /**
     * Set application domain name attribute, usually called from configure
     * method.
     * @param val New attribute value.
     */
    void setDomain(String val) {
        // If input isn't defined, use the default value.
        if (val == null || "".equals(val)) {
            val = DEFAULT_DOMAIN;
        }
        _domain = val.trim();
    }

    /**
     * Get value for application domain name, will never return a null.
     * @return Attribute value or default.
     */
    String getDomain() {
        return (_domain == null) ?  DEFAULT_DOMAIN : _domain;
    }

    /**
     * Set application name attribute, usually called from configure method.
     * @param val New attribute value.
     */
    void setApplication(String val) {
        // If input isn't defined, use the default value.
        if (val == null || "".equals(val)) {
            val = DEFAULT_APPLICATION;
        }
        _application = val.trim();
    }

    /**
     * Get value for application name, will never return a null.
     * @return Attribute value or default.
     */
    String getApplication() {
        return (_application == null) ?  DEFAULT_APPLICATION : _application;
    }

    /**
     * Set global log ID attribute, usually called from configure method.
     * @param val New attribute value.
     */
    void setGlobalLogID(String val) {
        // If input isn't defined, use the default value.
        if (val == null || "".equals(val)) {
            val = DEFAULT_LOG_ID;
        }
        _globalLogID = val.trim();
    }

    /**
     * Get value for global log ID, will never return a null.
     * @return Attribute value or default.
     */
    String getGlobalLogID() {
        return (_globalLogID == null) ?  DEFAULT_LOG_ID : _globalLogID;
    }

    /**
     * Get Level name and set it on the handler.
     * @param val Name of new level
     */
    void setLevel(String val) {
        // If input isn't defined, use the default value.
        if (val == null || val == "") {
            val = DEFAULT_LEVEL;
        }
        // Register the new level with the logger
        try {
            _parent.setLevel(Level.parse(val.trim()));
        }
        catch (SecurityException ex) {
            reportError("Register Level failed.", ex, ErrorManager.CONFIG_FAILURE);
        }
    }

    /**
     * Get Formatter name and set it on the handler.  This instantiates a Formatter
     * object from the classname and registers it on the parent's Handler.
     * @param val Classname of new Formatter
     */
    void setFormatter(String val) {
        // If input isn't defined, use the default value.
        if (val == null || val == "") {
            val = DEFAULT_FORMATTER;
        }

        // Load new formatter class
        Class clz = null;
        try {
            clz = this.getClass().getClassLoader().loadClass(val.trim());
        }
        catch (ClassNotFoundException ex1) {
            reportError("Configured Formatter not found", ex1,
                ErrorManager.CONFIG_FAILURE);
            try {
                clz = this.getClass().getClassLoader().loadClass(DEFAULT_FORMATTER);
            }
            catch (ClassNotFoundException ex2) {
                reportError("Formatter not found", ex2,
                    ErrorManager.CONFIG_FAILURE);
            }
        }

        // Create new formatter instance
        Formatter newFormatter = null;
        try {
            newFormatter = (Formatter)clz.newInstance();
        }
        catch (InstantiationException ex1) {
            reportError("Create Formatter failed", ex1, ErrorManager.CONFIG_FAILURE);
        }
        catch (IllegalAccessException ex2) {
            reportError("Create Formatter failed", ex2, ErrorManager.CONFIG_FAILURE);
        }

        // Register new formatter with the logger
        try {
            _parent.setFormatter(newFormatter);
        }
        catch (SecurityException ex) {
            reportError("Register Formatter failed", ex, ErrorManager.CONFIG_FAILURE);
        }
    }

    /**
     * Gets a LogID value.  First it checks with the LogConfig class to see if a
     * class- or package-level value is applicable for this logger name.  If not,
     * then it takes the global default.
     */
    String getLogID(String loggerName) {
        String id = null;

        // Try the LogConfig class for a local logger
        if (loggerName != null) {
            id = LogConfig.getConfig().getLocalLogID(loggerName);
        }

        // Use global default if not already set
        if (id == null) {
            id = this.getGlobalLogID();
        }
        return id;
    }

    /** Same purpose as in the logging framework's Handler classes */
    void reportError(String msg, Exception ex, int code) {
       // Since the Handler.reportError() method is defined by the JDK to be
       // protected, we can't call the convenience method in the parent.  
       // But we can directly interact with the saved ref to the ErrorManager.
        _errmgr.error(msg, ex, code);
    }
    
    /**
     * Setup the walmart.com LogDataHash structure before we <tt>publish</tt> 
     */
    public void prePublishSetupLdh(LogRecord record) {
        // Retrieve LogDataHash object
        LogDataHash dh = LogDataUtil.getLogDataHash(record);

        // Add Event ID to the LogDataHash
        if (dh.getLogID() == null) {
            dh.setLogID(this.getLogID(record.getLoggerName()));
        }

        // Add group ID, application and domain to the LogDataHash
        dh.setRequestID(ThreadRequestID.get());
        dh.setActivityId(ThreadGroupID.get());
        dh.setApplication(this.getApplication());
        dh.setDomain(this.getDomain());

        // Put LogDataHash back into the LogRecord
        Object[] params = new Object[1];
        params[0] = dh;
        record.setParameters(params);
    }
}
