package com.wm.corelib.logging;

/** 
 * An object to contain a ThreadLocal reference to the Group ID string.
 * @author David Casper
 */
public class ThreadGroupID {

    /** Threadlocal variable to store group ID for logging */
    private static ThreadLocal groupID = new ThreadLocal() {
        protected synchronized Object initialValue() {
            return (Object) null;
        }
    };

    /**
     * Retrieve the string value stored in the ThreadLocal variable. 
     * May return null.
     * <p>
     * @return Value retrieved from the variable.
     */
    public static String get() {
        return (String) (groupID.get());
    }

    /**
     * Set the value stored in the ThreadLocal variable. 
     * <p>
     * @param id String value to be stored.
     */
    public static void set(String id) {
        groupID.set(id);
    }

    /**
     * Sets the value stored in the ThreadLocal variable to null.
     */
    public static void reset() {
        groupID.set(null);
    }
}
