package com.wm.corelib.logging.jms;

import java.util.logging.LogRecord;

public class JMSSimpleFormatter extends java.util.logging.Formatter {

    /**
     * Main processing method, this overwrites abstract class in Formatter.
     * This method first tries to extract a LogDataHash object from the LogRecord
     * parameter array.  If that's successful, then it formats the message based
     * on the BLM data provided.  If the LogDataHash is not found, then it uses
     * only LogRecord information to format the message.
     * <p>
     * Not passing much through to the log via this formatter. Right now we're
     * just passing class name, method name and message to Syslog and this formatter
     * is designed to support the same level of logging. This may change later.
     * <p>
     * @param record LogRecord object to be formatted
     * @return Formatted message string
     */
    public String format(LogRecord record) {
        StringBuffer buffer = new StringBuffer();
//        buffer.append(" <MsgText: ");
        buffer.append(record.getMessage());
  //      buffer.append(">");

        // Write data (if present)
        //buffer.append(formatData(record));

        return buffer.toString();
    }

    /**
     * Retrieves an array of Objects from the LogRecord (if present) and passes
     * back a formatted string that contains the object data. The method first
     * checks if each Object is a NVPair and prints it's name and value.  If not
     * a NVPair, then it uses a generic toString method to print the object.
     * <p>
     * @param record LogRecord object to be formatted
     * @return Formatted string
     */
    public String formatData(LogRecord record) {
        return null;
    }
}
