package com.wm.corelib.logging;

/** 
 * Contains custom error handling for the Walmart.com logging framework.
 * @author David Casper
 */
public class ErrorManager extends java.util.logging.ErrorManager {

    /** Error classification code indicating configuration error */
    public static final int CONFIG_FAILURE = 100;

    /**
     * Handles error message. This prints a message to STDERR, because we can't
     * log the error (logger is throwing the error).
     * <p>
     * @param msg Text message (may be null)
     * @param ex Thrown exception (may be null)
     * @param code Integer code indicating the error classification
     */
    public void error(String msg, Exception ex, int code) {
        System.err.println(msg + ex + code);
    }
}
