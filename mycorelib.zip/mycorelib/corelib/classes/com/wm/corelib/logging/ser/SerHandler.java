package com.wm.corelib.logging.ser;

import java.util.logging.ErrorManager;
import java.util.logging.LogManager;
import java.util.logging.LogRecord;
import com.wm.corelib.logging.LogDataHash;
import com.wm.corelib.logging.LogDataUtil;
import com.wm.corelib.logging.LogHandlerCommons;
import com.wm.corelib.smtp.MailMessage;
import com.wm.corelib.smtp.Mailer;


/**
 * This Log Handler is intended for processing messages by the
 * System Event Repository.
 * @author Mark Taylor
 */
public class SerHandler extends java.util.logging.Handler {

    /**
     * Encapsulation of walmart.com-standard logging configuration
     * and LogRecord population logic.
     */
    private LogHandlerCommons _logHandlerCommons;

    // some application constants
    private static final String PROPERTY_ROOT = "com.wm.corelib.logging.ser.SerHandler";
    private static final String ORGNSRVR_PROPERTY = PROPERTY_ROOT + ".orgnserver";
    private static final String MAILFROM_PROPERTY = PROPERTY_ROOT + ".mailfrom";
    private static final String MAILTO_PROPERTY = PROPERTY_ROOT + ".mailto";

    // used for smtp processing
    private static String MAILFROM_VALUE;
    private static String MAILTO_VALUE;


    /** no-arg constructor */
    public SerHandler() {
        super();
        _logHandlerCommons = new LogHandlerCommons(this);

        // sender email address only needs to be constucted once per server
        LogManager manager = LogManager.getLogManager();
        MAILFROM_VALUE = manager.getProperty(ORGNSRVR_PROPERTY) + "-"
                + manager.getProperty(MAILFROM_PROPERTY);
        MAILTO_VALUE = manager.getProperty(MAILTO_PROPERTY);
            
//XXX Need to get corelib out of the System loader (called "App") and
//XXX into the application level loader (called "WebappClassLoader")
//Throwable t = new Throwable("SerHandler Constructed from:");
//t.printStackTrace();
//com.wm.corelib.util.ClassLineage.whence(this.getClass());
    }

    /**
     * Implementation of an abstract method from <tt>java.util.logging.Handler</tt>
     * which closes this <tt>Handler</tt> and frees all associated resources.
     * <p>
     * After close has been called this <tt>Handler</tt> should no longer be used.
     * <p>
     * @exception SecurityException if a security manager exists and if
     * the caller does not have <tt>LoggingPermission("control")</tt>.
     */
    public void close() throws SecurityException {
        _logHandlerCommons = null;
    }
        
    /**
     * Implementation of an abstract method from <tt>java.util.logging.Handler</tt>
     * that flushes buffered output.  A no-op in this class' case because this is
     * not a streaming/buffering based log handler.
     */
    public void flush() { }
   
    /**
     * Implementation of an abstract method from <tt>java.util.logging.Handler</tt>
     * which fills out the Walmart.com LogDataHash structure, formats the message
     * and sends it via email to its configured destination.
     */
    public void publish(LogRecord record) {

        // bail out before we do any work if we're not going to log anything
        if (!isLoggable(record)) {
            return;
        }

        // Fill the standard walmart.com LogDataHash structure
        // so the formatter will find what it needs.
        _logHandlerCommons.prePublishSetupLdh(record);

        // Format the log message using the configured formatter
        String msg;
        try {
            msg = getFormatter().format(record);
        } catch (Exception ex) {
            // We don't want to throw an exception here, but we
            // report the exception to any registered ErrorManager.
            reportError(null, ex, ErrorManager.FORMAT_FAILURE);
            return;
        }

        try {
            // Since email generation needs some of the same data,
            // set up some convenient, local handles to it.
            LogDataHash dh = LogDataUtil.getLogDataHash(record);
            Throwable thrown = dh.getThrown();

            // Format the email message's subject
            // note that this is only for the benefit of human readers
            // of the email, which should come to be an extreme minority,
            // as the plan is to have the bodies parsed by software and
            // stored in a DB for querying.
            StringBuffer subject = new StringBuffer();
            try {
                // for non-exception log messages, the subject is the calling 
                // class+method and the beginning of the log message
                if( thrown == null ) {
                    subject.append(record.getSourceClassName());
                    subject.append(".");
                    subject.append(record.getSourceMethodName());
                    subject.append(": ");
                    String mess = record.getMessage();
                    if (mess.length() > 40) {
                        mess = mess.substring(0,39);
                    }
                    subject.append(mess);

                    // Considered including some of these, but decided to see 
                    // what works before making it too complex.  As needed...
                    //subject.append(dh.getDomain());
                    //subject.append(":");
                    //subject.append(dh.getApplication());
                    //subject.append(":");
                    //subject.append(record.getLevel().toString());
                    //subject.append(":");
                    //subject.append(dh.getLogID());

                } else {
                // for unhandled exceptions, the subject is the exception type plus 
                // the URI that received the unhandled exception 
                    subject.append(thrown.getClass().getName());
                    if (dh!=null && dh.getRequest()!=null ) { 
                        subject.append(": ");
                        subject.append(dh.getRequest().getRequestURI());
                    }
                }
            } catch ( Exception e ) {
                subject.append(">ERROR in handler while formatting subject line");
            }

            // send it via email
            MailMessage m = new MailMessage(MAILTO_VALUE, 
                    MAILFROM_VALUE, MAILFROM_VALUE, subject.toString(), msg);
            m.addHeader("Content-Type", "text/xml");
            Mailer.getInstance().send(m);
            
        } catch (Exception ex) {
            // We don't want to throw an exception here, but we
            // report the exception to any registered ErrorManager.
            reportError(null, ex, ErrorManager.WRITE_FAILURE);
            
            // output to tomcat log -- better than nothing!
            System.err.println("---------------------------------------------------------------------");
            System.err.println(msg);
            System.err.println("---------------------------------------------------------------------");
        }
    }
}
