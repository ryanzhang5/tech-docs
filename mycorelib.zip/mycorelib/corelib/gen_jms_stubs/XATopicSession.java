/*
 * @(#)XATopicSession.java	1.10 01/02/15
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;

/** An <CODE>XATopicSession</CODE> provides a regular <CODE>TopicSession</CODE>.
  * which can be used to create <CODE>TopicSubscriber</CODE> and 
  * <CODE>TopicPublisher</CODE> objects (optional).
  *
  * @version     1.0 - 14 May 1998
  * @author      Mark Hapner
  * @author      Rich Burridge
  *
  * @see         javax.jms.XASession
  * @see         javax.jms.TopicSession
  */

public interface XATopicSession extends XASession {

    /** Gets the topic session associated with this <CODE>XATopicSession</CODE>.
      *   
      * @return the topic session object
      *   
      * @exception JMSException if an internal error occurs.
      */  
  
    TopicSession 
    getTopicSession() throws JMSException;
}
