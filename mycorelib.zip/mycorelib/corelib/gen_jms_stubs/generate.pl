#!/usr/bin/perl -w

use strict;
use Data::Dumper;
use FindBin;

my $DEBUG = 0;
if ($#ARGV != -1) {
    print "DEBUGGING IS ON!!!!!!!!!!!!!\n";
    $DEBUG = 1;
}


my $TRUE=(1==1);
my $FALSE=! $TRUE;

my $srcDir = $FindBin::Bin || ".";
opendir DIR, $srcDir || die "cannot open directory [$srcDir]";

my @sources = grep { /\.java$/ && -f "./$_" } readdir(DIR);

closedir DIR;

my %CLASSES = ();
my %TREE = ();

foreach my $source (@sources) {
    next if ($source =~ m/Exception\.java$/);
    next if ($source =~ m/TopicRequestor\.java$/);
    next if ($source =~ m/QueueRequestor\.java$/);
    
    my $code = `cpp $source | grep -v '^\#'`;
    
    $code =~ s/\{/;/g;
    $code =~ s/\}//g;    
    $code =~ s/\n/ /g;
    $code =~ s/ +/ /g;
    $code =~ s/ +\[/\[/g;    
    
    my @bits = split(";", $code);
    
    my $class = "";
    my @imports = ();
    
    foreach my $bit (@bits) {
        $bit =~ s/^[ \t]*//;
        $bit =~ s/\t/ /g;
        
        next if ($bit =~ m/^[ \t]*$/);       
        next if ($bit =~ m/^package javax\.jms/);
        next if ($bit =~ m/^static final /);
                
        if ($bit =~ m/^import /) {
            push @imports, $bit;
        }
        if ($bit =~ m/^public interface ([^ ]+)(.*)$/) {           
            die "internal error" if ($class ne "");
            
            $class = $1;
            
            my $parents = $2;
            my @parents = ();
            
            if (not exists $CLASSES{$class}) {
                $CLASSES{$class} = ();
                $CLASSES{$class}{methods} = [];
                $CLASSES{$class}{imports} = [@imports];
                $CLASSES{$class}{all_parents} = ();
                @imports = ();
            }
            
            if ($parents =~ /^.*extends (.*)$/) {
                $parents = $1; 
                $parents =~ s/ //g;
                @parents = split(",", $parents);
            }

            foreach my $parent(@parents) {
                next if ($parent eq "Runnable");

                if (not exists $TREE{$parent}) {
                    $TREE{$parent} = ();
                }
                $TREE{$parent}{$class} = 1;
            }
          
            $CLASSES{$class}{parents} = \@parents;
        }
        else {
            next if ($class eq "");

            $bit =~ s/public //;
            my %meth = ();
            
            $bit =~ m/^([^ ]+) ([^\(]+)\(([^\)]*)\)(.*)$/;
            $meth{rt} = $1 || "";
            $meth{name} = $2 || "";
            $meth{sig} = $3 || "";
            $meth{throws} = $4 || "";
            $meth{throws} =~ s/^ *//g;
            
            if ($meth{rt} eq "Enumeration") {
                $meth{rt} = "java.util.Enumeration";
            }

            if ($meth{rt} eq "Serializable") {
                $meth{rt} = "java.io.Serializable";
            }

            if ($meth{rt} eq "XAResource") {
                $meth{rt} = "javax.transaction.xa.XAResource";
            }
            
            $meth{args} = [];
            
            $meth{sig} =~ s/Serializable/java.io.Serializable/g;
            
            my @args = split(/, ?/, $meth{sig});
            
            foreach my $arg (@args) {
                my ($type, $name) = split(" ", $arg);
                
                my %param = ();
                $param{type} = $type;
                $param{name} = $name;
                
                push @{$meth{args}}, \%param;
            }            
            
            $meth{fullsig} = "$meth{name}($meth{sig})";

            push @{$CLASSES{$class}{methods}}, \%meth;
        }        
    }
}    


foreach my $class (sort keys %CLASSES) {  
    buildParentList($class);
}


sub buildParentList {
    my $class = shift;
    my $parent = shift;    
    
    if (defined($parent)) {
        $CLASSES{$class}{all_parents}{$parent} = 1;
    }
    else {
        $parent = $class;
    }
    
    return if (not exists $CLASSES{$parent});
    
    foreach my $parent (@{$CLASSES{$parent}{parents}}) {
        next if ($parent eq "Runnable");
        buildParentList($class, $parent);
    }
}

# print Dumper %CLASSES; exit;
# print Dumper %TREE; exit;

chdir("../classes/com/wm/corelib/mq/jmswrap") || die "cannot change to destination directory";

my %methods_outputed = ();
foreach my $key (sort keys %CLASSES) {
    %methods_outputed = ();

    my @impl = ();
    my $proxyObj = "_" . lcfirst($key) . "Impl";
    
    open OUT, "> WM$key.java";
    
    print OUT "package com.wm.corelib.mq.jmswrap;\n\n";
    print OUT "import javax.jms.*;\n\n";
    print OUT "public class WM$key";
    
    if (@{$CLASSES{$key}{parents}}) {
        
        my $extends = "";
        foreach my $parent (@{$CLASSES{$key}{parents}}) {            
            if ($parent eq "Runnable") { push @impl, $parent; next; };
            if ($parent eq "XAConnection") { push @impl, $parent; next; };
            if ($parent eq "XAConnectionFactory") { push @impl, $parent; next; };
            if (exists $CLASSES{$parent}) {
                $extends .= "WM$parent, ";
            }
            else {
                $extends .= "$parent, ";
            }
        }
        $extends =~ s/\, $//;
        if ($extends ne "") { print OUT " extends $extends"; }
    }
    
    push @impl, $key;
    print OUT " implements " . join(", ", @impl);
    
    print OUT " {\n\n";

    print OUT "  public String toString() {\n";
    print OUT "    System.err.println(\"entering method \" + getClass().getName().toString() + \".toString()\");\n" if ($DEBUG);
    print OUT "    return getNative${key}Impl().toString();\n";
    print OUT "  }\n\n";    
    $methods_outputed{"toString()"} = 1;
    
    print OUT "  //////////////////\n";
    print OUT "  // declared interface methods\n";
    print OUT "  //////////////////\n";
    &spewMethods($key, $FALSE);

    foreach my $parent (keys %{$CLASSES{$key}{all_parents}}) {
        print OUT "  //////////////////\n";
        print OUT "  // inherited methods from class $parent (proxy to custom WM objects)\n";
        print OUT "  //////////////////\n";
        &spewMethods($parent, $TRUE);
    }
    
    print OUT "  public static void setClass(Class c) { _clazz = c; }\n\n";
    print OUT "  public static WM" . $key . " newInstance($key nativeImpl) {\n";
    print OUT "    System.err.println(_clazz.getName() + \".newInstance() called for native JMS Object: \" + nativeImpl.getClass().getName() + \"@\" + nativeImpl.hashCode());\n" if ($DEBUG);
    print OUT "    try {\n";    
    print OUT "      WM" . $key . " newObj = (WM" . $key . ")_clazz.newInstance();\n";
    print OUT "      newObj.setNative${key}Impl(nativeImpl);\n";
    
    foreach my $parent (keys %{$CLASSES{$key}{all_parents}}) {
        next if ($parent eq "Runnable");
        
        if (($parent ne "XAConnection") && ($parent ne "XAConnectionFactory")) {
            print OUT "      newObj.setNative${parent}Impl(($parent)nativeImpl);\n";
        }
        
        print OUT "      newObj.setInternal${parent}Impl(WM$parent.newInstance(($parent)nativeImpl));\n";        
    }

    print OUT "      System.err.println(_clazz.getName() + \".newInstance() returning \" + newObj.getClass().getName() + \"@\" + newObj.hashCode());\n" if ($DEBUG);

    print OUT "      return newObj;\n";
    print OUT "    }\n";
    print OUT "    catch (java.lang.InstantiationException ie)  { throw new java.lang.RuntimeException(ie);  }\n";
    print OUT "    catch (java.lang.IllegalAccessException iae) { throw new java.lang.RuntimeException(iae); }\n";
    print OUT "    catch (java.lang.Throwable t)                { throw new java.lang.RuntimeException(t);   }\n";
    print OUT "\n    /* UNREACHABLE */\n";
    print OUT "  }\n\n";   
    
#     print OUT "  //////////////////\n";    
#     print OUT "  // constructor\n";
#     print OUT "  //////////////////\n";
#     print OUT "  protected WM$key($key nativeImpl) {\n";
#     print OUT "    $proxyObj = nativeImpl;\n";
#     print OUT "  }\n\n";
        
    print OUT "  //////////////////\n";    
    print OUT "  // native implementation access methods\n";
    print OUT "  //////////////////\n";
    print OUT "  protected $key getNative${key}Impl() {\n";
    print OUT "    return $proxyObj;\n";
    print OUT "  }\n\n";
    print OUT "  protected void setNative${key}Impl($key nativeImpl) {\n";
    print OUT "    $proxyObj = nativeImpl;\n";
    print OUT "  }\n\n";
    
    foreach my $parent (keys %{$CLASSES{$key}{all_parents}}) {
        next if ($parent eq "Runnable");

        print OUT "  //////////////////\n";    
        print OUT "  // internal proxy implementations for parent classe $parent\n";
        print OUT "  //////////////////\n";        
        my $parentProxy = "_internal" . $parent . "Impl";
        print OUT "  private WM$parent " . $parentProxy . " = null;\n";
        print OUT "  private WM$parent getInternal${parent}Impl() {\n";
        print OUT "    return $parentProxy;\n";
        print OUT "  }\n\n";
        print OUT "  private void setInternal${parent}Impl(WM$parent nativeImpl) {\n";
        print OUT "    $parentProxy = nativeImpl;\n";
        print OUT "  }\n\n";                       
    }
    
    print OUT "  protected WM$key() { }\n";
    print OUT "  private $key " . $proxyObj . " = null;\n";
    print OUT "  private static Class _clazz = WM" . $key . ".class;\n";

    print OUT "}\n";
   
    close OUT;
    

    # write the skeleton that allows customization
    if (! -f "../WM$key.java") {
        open OUT, "> ../WM$key.java";
        
        print OUT "package com.wm.corelib.mq;\n\n";
        print OUT "import javax.jms.*;\n\n";
        print OUT "public class WM$key extends com.wm.corelib.mq.jmswrap.WM$key {\n";
        print OUT "\n";
        print OUT "  ////////////////////////////////\n";
        print OUT "  // Use me to customize any portion of the javax.jms.$key interface\n";
        print OUT "  ////////////////////////////////\n";
        print OUT "\n";
        print OUT "}\n";    
        close OUT;
    }
}




sub spewMethods {
    my $class = shift;
    my $proxy = shift || $FALSE;
    
    foreach my $meth (@{$CLASSES{$class}{methods}}) {
        next if (exists $methods_outputed{$meth->{fullsig}});
        
        $methods_outputed{$meth->{fullsig}} = 1;
        
        print OUT "  public " . $meth->{rt} . " " . $meth->{fullsig} . " " . $meth->{throws} . " {\n";
        
        print OUT "    System.err.println(\"entering " . ($proxy ? "proxy " : "") .  "method \" + getClass().getName().toString() + \"." . $meth->{fullsig} . "\");\n" if ($DEBUG);
        
        my @args = @{$meth->{args}};
        
        if ($proxy) {
            if ($meth->{rt} ne "void") {                   
                print OUT "    return ";
            }
            else {
                print OUT "    ";
            }
            
            print OUT "getInternal${class}Impl()." . $meth->{name} . "(";
            
            my @argList = ();
            for (my $i=0; $i<=$#args; $i++) {
                push @argList, $args[$i]->{name};
            }
            
            print OUT join(", ", @argList);
            print OUT ");\n";
            print OUT "  }\n\n";
            next;
        }        
        
        for (my $i=0; $i<=$#args; $i++) {
            print OUT "    " . $args[$i]->{type} . " arg$i = ";
            
            if (exists $CLASSES{$args[$i]->{type}}) {
                print OUT "(" . $args[$i]->{name} . " instanceof WM" . $args[$i]->{type} . ") ? ((WM" . $args[$i]->{type} . ")" . $args[$i]->{name} . ").getNative" . $args[$i]->{type} . "Impl() : " . $args[$i]->{name};
            }
            else {
                print OUT $args[$i]->{name};
            }
            print OUT ";\n";
        }

        if ($meth->{rt} ne "void") {                   
            print OUT "    $meth->{rt} rv = ";
        }
        else {
            print OUT "    ";
        }

        print OUT "getNative${class}Impl()." . $meth->{name} . "(";
        
        for (my $i=0; $i<=$#args; $i++) {
            print OUT "arg$i";
            print OUT ", " if ($i <= ($#args-1));
        }
        
        print OUT ");\n";
        
        my @possibleTypes = getPossibleSubClasses($meth->{rt});

        
        if ($meth->{rt} =~ m/^[A-Z]/) {
            print OUT "    if (rv == null) { return null; }\n";
        }

        foreach my $t (@possibleTypes) {
            print OUT "    else if (rv instanceof $t) {\n";
            print OUT "      System.err.println(\"--> rv object is of type $t\");\n" if ($DEBUG);
            print OUT "      rv = (" . $meth->{rt} . ")WM" . $t . ".newInstance(($t)rv);\n";
            print OUT "    }\n";
        }
        
        if (exists $CLASSES{$meth->{rt}}) {
            if (@possibleTypes) {
                print OUT "    else {\n";
                print OUT "      System.err.println(\"--> rv object is of DEFAULT type!\");\n" if ($DEBUG);
                print OUT "      rv = (" . $meth->{rt} . ")WM" . $meth->{rt} . ".newInstance((" . $meth->{rt} . ")rv);\n";
                print OUT "    }\n";
            }
            else {
                print OUT "    rv = (" . $meth->{rt} . ")WM" . $meth->{rt} . ".newInstance((" . $meth->{rt} . ")rv);\n";
            }
        }            
        
        if ($meth->{rt} ne "void") {
            print OUT "    return rv;\n";
        }
        
        print OUT "  }\n\n";
    }
    
    print OUT "\n\n";
    
}


sub getPossibleSubClasses {
    my $class = shift;
    
    my @rv = ();
    
    foreach my $t (keys %{$TREE{$class}}) {
        push @rv, $t;
        foreach my $t2 (getPossibleSubClasses($t)) {
            push @rv, $t2;
        }
    }
    
    return @rv;
}








