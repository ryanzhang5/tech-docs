/*
 * @(#)XATopicConnectionFactory.java	1.12 01/02/15
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;

/** An <CODE>XATopicConnectionFactory</CODE> provides the same create options as 
  * a <CODE>TopicConnectionFactory</CODE> (optional).
  *
  * @version     1.0 - 14 May 1998
  * @author      Mark Hapner
  * @author      Rich Burridge
  *
  * @see         javax.jms.TopicConnectionFactory
  * @see         javax.jms.XAConnectionFactory
  */

public interface XATopicConnectionFactory 
	extends XAConnectionFactory, TopicConnectionFactory {

    /** Creates an XA topic connection with the default user identity.
      * The connection is created in stopped mode. No messages 
      * will be delivered until the <code>Connection.start</code> method
      * is explicitly called.
      *
      * @return a newly created XA topic connection
      *
      * @exception JMSException if the JMS provider fails to create an XA topic 
      *                         connection due to some internal error.
      * @exception JMSSecurityException  if client authentication fails due to 
      *                         an invalid user name or password.
      */ 

    XATopicConnection
    createXATopicConnection() throws JMSException;


    /** Creates an XA topic connection with the specified user identity.
      * The connection is created in stopped mode. No messages 
      * will be delivered until the <code>Connection.start</code> method
      * is explicitly called.
      *  
      * @param userName the caller's user name
      * @param password the caller's password
      *  
      * @return a newly created XA topic connection
      *
      * @exception JMSException if the JMS provider fails to create an XA topic 
      *                         connection due to some internal error.
      * @exception JMSSecurityException  if client authentication fails due to 
      *                         an invalid user name or password.
      */ 

    XATopicConnection
    createXATopicConnection(String userName, String password) 
					     throws JMSException;
}
