/*
 * @(#)Session.java	1.41 01/05/08
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;

import java.io.Serializable;

/** <P>A <CODE>Session</CODE> object is a single-threaded context for producing and consuming 
  * messages. Although it may allocate provider resources outside the Java 
  * virtual machine (JVM), it is considered a lightweight JMS object.
  *
  * <P>A session serves several purposes:
  *
  * <UL>
  *   <LI>It is a factory for its message producers and consumers.
  *   <LI>It supplies provider-optimized message factories.
  *   <LI>It supports a single series of transactions that combine work 
  *       spanning its producers and consumers into atomic units.
  *   <LI>It defines a serial order for the messages it consumes and 
  *       the messages it produces.
  *   <LI>It retains messages it consumes until they have been 
  *       acknowledged.
  *   <LI>It serializes execution of message listeners registered with 
  *       its message consumers.
  * </UL>
  *
  * <P>A session can create and service multiple message producers and 
  * consumers.
  *
  * <P>One typical use is to have a thread block on a synchronous 
  * <CODE>MessageConsumer</CODE> until a message arrives. The thread may then
  * use one or more of the <CODE>Session</CODE>'s <CODE>MessageProducer</CODE>s.
  *
  * <P>If a client desires to have one thread produce messages while others 
  * consume them, the client should use a separate session for its producing 
  * thread.
  *
  * <P>Once a connection has been started, any session with one or more 
  * registered message listeners is dedicated to the thread of control that 
  * delivers messages to it. It is erroneous for client code to use this session
  * or any of its constituent objects from another thread of control. The
  * only exception to this rule is the use of the session or connection 
  * <CODE>close</CODE> method.
  *
  * <P>It should be easy for most clients to partition their work naturally
  * into sessions. This model allows clients to start simply and incrementally
  * add message processing complexity as their need for concurrency grows.
  *
  * <P>The <CODE>close</CODE> method is the only session method that can be 
  * called while some other session method is being executed in another thread.
  *
  * <P>A session may be specified as transacted. Each transacted 
  * session supports a single series of transactions. Each transaction groups 
  * a set of message sends and a set of message receives into an atomic unit 
  * of work. In effect, transactions organize a session's input message 
  * stream and output message stream into series of atomic units. When a 
  * transaction commits, its atomic unit of input is acknowledged and its 
  * associated atomic unit of output is sent. If a transaction rollback is 
  * done, the transaction's sent messages are destroyed and the session's input 
  * is automatically recovered.
  *
  * <P>The content of a transaction's input and output units is simply those 
  * messages that have been produced and consumed within the session's current 
  * transaction.
  *
  * <P>A transaction is completed using either its session's <CODE>commit</CODE>
  * method or its session's <CODE>rollback</CODE> method. The completion of a
  * session's current transaction automatically begins the next. The result is
  * that a transacted session always has a current transaction within which its 
  * work is done.  
  *
  * <P>The Java Transaction Service (JTS) or some other transaction monitor may 
  * be used to combine a session's transaction with transactions on other 
  * resources (databases, other JMS sessions, etc.). Since Java distributed 
  * transactions are controlled via the Java Transaction API (JTA), use of the 
  * session's <CODE>commit</CODE> and <CODE>rollback</CODE> methods in 
  * this context is prohibited.
  *
  * <P>The JMS API does not require support for JTA; however, it does define 
  * how a provider supplies this support.
  *
  * <P>Although it is also possible for a JMS client to handle distributed 
  * transactions directly, it is unlikely that many JMS clients will do this.
  * Support for JTA in the JMS API is targeted at systems vendors who will be 
  * integrating the JMS API into their application server products.
  *
  * @version     1.0 - 6 August 1998
  * @author      Mark Hapner
  * @author      Rich Burridge
  *
  * @see         javax.jms.QueueSession
  * @see         javax.jms.TopicSession
  * @see         javax.jms.XASession
  */ 
 
public interface Session extends Runnable {

    /** With this acknowledgment mode, the session automatically acknowledges
      * a client's receipt of a message either when the session has successfully 
      * returned from a call to <CODE>receive</CODE> or when the message 
      * listener the session has called to process the message successfully 
      * returns.
      */ 

    static final int AUTO_ACKNOWLEDGE = 1;

    /** With this acknowledgment mode, the client acknowledges a consumed 
      * message by calling the message's <CODE>acknowledge</CODE> method. 
      * Acknowledging a consumed message acknowledges all messages that the 
      * session has consumed.
      *
      * <P>When client acknowledgment mode is used, a client may build up a 
      * large number of unacknowledged messages while attempting to process 
      * them. A JMS provider should provide administrators with a way to 
      * limit client overrun so that clients are not driven to resource 
      * exhaustion and ensuing failure when some resource they are using 
      * is temporarily blocked.
      *
      * @see javax.jms.Message#acknowledge()
      */ 

    static final int CLIENT_ACKNOWLEDGE = 2;

    /** This acknowledgment mode instructs the session to lazily acknowledge 
      * the delivery of messages. This is likely to result in the delivery of 
      * some duplicate messages if the JMS provider fails, so it should only be 
      * used by consumers that can tolerate duplicate messages. Use of this  
      * mode can reduce session overhead by minimizing the work the 
      * session does to prevent duplicates.
      */

    static final int DUPS_OK_ACKNOWLEDGE = 3;

    /** Creates a <CODE>BytesMessage</CODE> object. A <CODE>BytesMessage</CODE> 
      * object is used to send a message containing a stream of uninterpreted 
      * bytes.
      *  
      * @exception JMSException if the JMS provider fails to create this message
      *                         due to some internal error.
      */ 

    BytesMessage 
    createBytesMessage() throws JMSException; 

 
    /** Creates a <CODE>MapMessage</CODE> object. A <CODE>MapMessage</CODE> 
      * object is used to send a self-defining set of name-value pairs, where 
      * names are <CODE>String</CODE> objects and values are primitive values 
      * in the Java programming language.
      *  
      * @exception JMSException if the JMS provider fails to create this message
      *                         due to some internal error.
      */ 

    MapMessage 
    createMapMessage() throws JMSException; 

 
    /** Creates a <CODE>Message</CODE> object. The <CODE>Message</CODE> 
      * interface is the root interface of all JMS messages. A 
      * <CODE>Message</CODE> object holds all the 
      * standard message header information. It can be sent when a message 
      * containing only header information is sufficient.
      *  
      * @exception JMSException if the JMS provider fails to create this message
      *                         due to some internal error.
      */ 

    Message
    createMessage() throws JMSException;


    /** Creates an <CODE>ObjectMessage</CODE> object. An 
      * <CODE>ObjectMessage</CODE> object is used to send a message 
      * that contains a serializable Java object.
      *  
      * @exception JMSException if the JMS provider fails to create this message
      *                         due to some internal error.
      */ 

    ObjectMessage
    createObjectMessage() throws JMSException; 


    /** Creates an initialized <CODE>ObjectMessage</CODE> object. An 
      * <CODE>ObjectMessage</CODE> object is used 
      * to send a message that contains a serializable Java object.
      *  
      * @param object the object to use to initialize this message
      *
      * @exception JMSException if the JMS provider fails to create this message
      *                         due to some internal error.
      */ 

    ObjectMessage
    createObjectMessage(Serializable object) throws JMSException;

 
    /** Creates a <CODE>StreamMessage</CODE> object. A 
      * <CODE>StreamMessage</CODE> object is used to send a 
      * self-defining stream of primitive values in the Java programming 
      * language.
      *  
      * @exception JMSException if the JMS provider fails to create this message
      *                         due to some internal error.
      */

    StreamMessage 
    createStreamMessage() throws JMSException;  

 
    /** Creates a <CODE>TextMessage</CODE> object. A <CODE>TextMessage</CODE> 
      * object is used to send a message containing a <CODE>String</CODE>
      * object.
      *  
      * @exception JMSException if the JMS provider fails to create this message
      *                         due to some internal error.
      */ 

    TextMessage 
    createTextMessage() throws JMSException; 


    /** Creates an initialized <CODE>TextMessage</CODE> object. A 
      * <CODE>TextMessage</CODE> object is used to send 
      * a message containing a <CODE>String</CODE>.
      *
      * @param text the string used to initialize this message
      *
      * @exception JMSException if the JMS provider fails to create this message
      *                         due to some internal error.
      */ 

    TextMessage
    createTextMessage(String text) throws JMSException;


    /** Indicates whether the session is in transacted mode.
      *  
      * @return true if the session is in transacted mode
      *  
      * @exception JMSException if the JMS provider fails to return the 
      *                         transaction mode due to some internal error.
      */ 

    boolean
    getTransacted() throws JMSException;


    /** Commits all messages done in this transaction and releases any locks
      * currently held.
      *
      * @exception JMSException if the JMS provider fails to commit the
      *                         transaction due to some internal error.
      * @exception TransactionRolledBackException if the transaction
      *                         is rolled back due to some internal error
      *                         during commit.
      * @exception IllegalStateException if the method is not called by a 
      *                         transacted session.
      */

    void
    commit() throws JMSException;


    /** Rolls back any messages done in this transaction and releases any locks 
      * currently held.
      *
      * @exception JMSException if the JMS provider fails to roll back the
      *                         transaction due to some internal error.
      * @exception IllegalStateException if the method is not called by a 
      *                         transacted session.
      *                                     
      */

    void
    rollback() throws JMSException;


    /** Closes the session.
      *
      * <P>Since a provider may allocate some resources on behalf of a session 
      * outside the JVM, clients should close the resources when they are not 
      * needed. 
      * Relying on garbage collection to eventually reclaim these resources 
      * may not be timely enough.
      *
      * <P>There is no need to close the producers and consumers
      * of a closed session. 
      *
      * <P> This call will block until a <CODE>receive</CODE> call or message 
      * listener in progress has completed. A blocked message consumer
      * <CODE>receive</CODE> call returns <CODE>null</CODE> when this session 
      * is closed.
      *
      * <P>Closing a transacted session must roll back the transaction
      * in progress.
      * 
      * <P>This method is the only <CODE>Session</CODE> method that can 
      * be called concurrently. 
      *
      * <P>Invoking any other <CODE>Session</CODE> method on a closed session 
      * must throw a <CODE>JMSException.IllegalStateException</CODE>. Closing a 
      * closed session must <I>not</I> throw an exception.
      * 
      * @exception JMSException if the JMS provider fails to close the
      *                         session due to some internal error.
      */

    void
    close() throws JMSException;


    /** Stops message delivery in this session, and restarts message delivery
      * with the oldest unacknowledged message.
      *  
      * <P>All consumers deliver messages in a serial order.
      * Acknowledging a received message automatically acknowledges all 
      * messages that have been delivered to the client.
      *
      * <P>Restarting a session causes it to take the following actions:
      *
      * <UL>
      *   <LI>Stop message delivery
      *   <LI>Mark all messages that might have been delivered but not 
      *       acknowledged as "redelivered"
      *   <LI>Restart the delivery sequence including all unacknowledged 
      *       messages that had been previously delivered. Redelivered messages
      *       do not have to be delivered in 
      *       exactly their original delivery order.
      * </UL>
      *
      * @exception JMSException if the JMS provider fails to stop and restart
      *                         message delivery due to some internal error.
      * @exception IllegalStateException if the method is called by a 
      *                         transacted session.
      */ 

    void
    recover() throws JMSException;


    /** Returns the session's distinguished message listener (optional).
      *
      * @return the message listener associated with this session
      *
      * @exception JMSException if the JMS provider fails to get the message 
      *                         listener due to an internal error.
      *
      * @see javax.jms.Session#setMessageListener
      * @see javax.jms.ServerSessionPool
      * @see javax.jms.ServerSession
      */

    MessageListener
    getMessageListener() throws JMSException;


    /** Sets the session's distinguished message listener (optional).
      *
      * <P>When the distinguished message listener is set, no other form of 
      * message receipt in the session can 
      * be used; however, all forms of sending messages are still supported.
      * 
      * <P>This is an expert facility not used by regular JMS clients.
      *
      * @param listener the message listener to associate with this session
      *
      * @exception JMSException if the JMS provider fails to set the message 
      *                         listener due to an internal error.
      *
      * @see javax.jms.Session#getMessageListener
      * @see javax.jms.ServerSessionPool
      * @see javax.jms.ServerSession
      */

    void
    setMessageListener(MessageListener listener) throws JMSException;

    /**
     * Optional operation, intended to be used only by Application Servers,
     * not by ordinary JMS clients.
     *
     * @see javax.jms.ServerSession
     */
    public void run();
}
