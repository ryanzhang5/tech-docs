/*
 * @(#)XAConnectionFactory.java	1.8 01/05/08
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;

/** The <CODE>XAConnectionFactory</CODE> interface is a base interface for the
  * <CODE>XAQueueConnectionFactory</CODE> and 
  * <CODE>XATopicConnectionFactory</CODE> interfaces.
  *
  * <P>Some application servers provide support for grouping JTS capable 
  * resource use into a distributed transaction (optional). To include JMS API transactions 
  * in a JTS transaction, an application server requires a JTS aware JMS
  * provider. A JMS provider exposes its JTS support using an
  * <CODE>XAConnectionFactory</CODE> object, which an application server uses 
  * to create <CODE>XAConnection</CODE> objects.
  *
  * <P><CODE>XAConnectionFactory</CODE> objects are JMS administered objects, 
  * just like <CODE>ConnectionFactory</CODE> objects. It is expected that 
  * application servers will find them using the Java Naming and Directory
  * Interface (JNDI) API.
  *
  * @version     1.0 - 14 May 1998
  * @author      Mark Hapner
  * @author      Rich Burridge
  *
  * @see         javax.jms.XAQueueConnectionFactory
  * @see         javax.jms.XATopicConnectionFactory
  */

public interface XAConnectionFactory {
}
