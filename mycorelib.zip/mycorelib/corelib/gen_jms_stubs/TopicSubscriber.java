/*
 * @(#)TopicSubscriber.java	1.26 01/02/08
 *
 * Copyright 1997-1999 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

package javax.jms;

/** A client uses a <CODE>TopicSubscriber</CODE> object to receive messages that
  * have been published to a topic. A <CODE>TopicSubscriber</CODE> object is the
  * publish/subscribe form of a message consumer.
  *
  * <P>A <CODE>TopicSession</CODE> allows the creation of multiple 
  * <CODE>TopicSubscriber</CODE> objects per topic.  It will deliver each 
  * message for a topic to each
  * subscriber eligible to receive it. Each copy of the message
  * is treated as a completely separate message. Work done on one copy has
  * no effect on the others; acknowledging one does not acknowledge the
  * others; one message may be delivered immediately, while another waits
  * for its subscriber to process messages ahead of it.
  *
  * <P>Regular <CODE>TopicSubscriber</CODE> objects are not durable. They 
  * receive only messages that are published while they are active.
  *
  * <P>Messages filtered out by a subscriber's message selector will never 
  * be delivered to the subscriber. From the subscriber's perspective, they 
  * do not exist.
  *
  * <P>In some cases, a connection may both publish and subscribe to a topic.
  * The subscriber <CODE>NoLocal</CODE> attribute allows a subscriber to inhibit
  * the 
  * delivery of messages published by its own connection.
  *
  * <P>If a client needs to receive all the messages published on a topic, 
  * including the ones published while the subscriber is inactive, it uses 
  * a durable <CODE>TopicSubscriber</CODE>. The JMS provider retains a record of
  * this durable 
  * subscription and insures that all messages from the topic's publishers 
  * are retained until they are acknowledged by this durable 
  * subscriber or they have expired.
  *
  * <P>Sessions with durable subscribers must always provide the same client 
  * identifier. In addition, each client must specify a name that uniquely 
  * identifies (within client identifier) each durable subscription it creates.
  * Only one session at a time can have a <CODE>TopicSubscriber</CODE> for a 
  * particular durable subscription. 
  *
  * <P>A client can change an existing durable subscription by creating a 
  * durable <CODE>TopicSubscriber</CODE> with the same name and a new topic 
  * and/or message 
  * selector. Changing a durable subscription is equivalent to unsubscribing 
  * (deleting) the old one and creating a new one.
  *
  * <P><CODE>TopicSession</CODE>s provide the <CODE>unsubscribe</CODE> method 
  * for deleting a durable 
  * subscription created by their client. This method deletes the state being 
  * maintained on behalf of the subscriber by its provider.
  * 
  * @version     1.0 - 7 August 1998
  * @author      Mark Hapner
  * @author      Rich Burridge
  *
  * @see         javax.jms.TopicSession
  * @see         javax.jms.TopicSession#createSubscriber(Topic)
  * @see         javax.jms.TopicSession#createSubscriber(Topic, String, boolean)
  * @see         javax.jms.TopicSession#createDurableSubscriber(Topic, String)
  * @see         javax.jms.TopicSession#createDurableSubscriber(Topic, String, String, boolean)
  * @see         javax.jms.MessageConsumer
  */

public interface TopicSubscriber extends MessageConsumer {

    /** Gets the <CODE>Topic</CODE> associated with this subscriber.
      *  
      * @return this subscriber's <CODE>Topic</CODE>
      *  
      * @exception JMSException if the JMS provider fails to get the topic for
      *                         this topic subscriber
      *                         due to some internal error.
      */ 

    Topic
    getTopic() throws JMSException;


    /** Gets the <CODE>NoLocal</CODE> attribute for this subscriber. 
      * The default value for this attribute is false.
      *  
      * @return true if locally published messages are being inhibited
      *  
      * @exception JMSException if the JMS provider fails to get the
      *                         <CODE>NoLocal</CODE> attribute for
      *                         this topic subscriber
      *                         due to some internal error.
      */ 

    boolean
    getNoLocal() throws JMSException;
}
