These files are meant to facilitate a one-time migration of java code containing
the following patterns:

- System.out.println(xyz);	=> logger.info(xyz);
- System.err.println(xyz);	=> logger.warning(xyz);
- e.printStackTrace();		=> logger.log(Level.WARNING, "DEFAULT_ERROR_MESSAGE", e);

You need to run the scripts in this order:

1) $ ./findFiles.sh ~/www/src/
This will create a new folder called ~/www/.logging - which can be deleted after
the whole process. It will create a list of java files that need to be processed
for the above listed use-cases.

After this step, we need to send the files-to-process.txt to the app teams to let
them review and send back a files-to-ignore.txt file - which is added to the same
.logging folder.


2) $ perl processFiles.pl ~/www/src/
This will go through the above list of files and do the basic migration. 


3) $ make -s classes > make.log 2>&1
Now, we need to fix the compilation issues. Run the appropriate "make" command and 
capture the output in a log file.

Check to verify that the number of errors is less than 100 - otherwise, you may 
need to repeat steps 3 after completing step 4.


4) $ perl postProcess.pl ~/www/make.log
This will go through the above log file and apply the following transformation:

- System.out.println(obj);	=> System.out.println(String.valueOf(obj));

Which is expected to resolve a lot of compilation issues. 

Now, you need to fix the issues on a case-by-case basis. A few examples are:
- when the same java file has two class definitions, we may need to add the Logger
  manually.
- when a java class has a static block, the logger may need to be moved to the top
  of the class definition.
