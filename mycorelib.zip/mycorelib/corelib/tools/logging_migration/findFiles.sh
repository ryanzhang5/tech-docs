#!/bin/sh

if [ $# -eq 0 ] || [ ! -d $1 ]; then
  echo Usage: $0 \<base-directory\>
  exit 1
fi

CURRDIR=`pwd`
BASEDIR=$1;
cd $BASEDIR
WORKDIR=../.logging
if [ ! -d $WORKDIR ]; then mkdir $WORKDIR ; fi ;

grep -F "System.out.print"   -r . | grep -v -P "^[^:]+:\s*\/\/" > $WORKDIR/grep-SystemOut.txt
grep -F "System.err.print"   -r . | grep -v -P "^[^:]+:\s*\/\/" > $WORKDIR/grep-SystemErr.txt
grep -F ".printStackTrace()" -r . | grep -v -P "^[^:]+:\s*\/\/" > $WORKDIR/grep-StackTrace.txt

cut -d ":" -f 1 $WORKDIR/grep-SystemOut.txt | sort -u > $WORKDIR/files-SystemOut.txt
cut -d ":" -f 1 $WORKDIR/grep-SystemErr.txt | sort -u > $WORKDIR/files-SystemErr.txt
cut -d ":" -f 1 $WORKDIR/grep-StackTrace.txt | sort -u > $WORKDIR/files-StackTrace.txt

cat $WORKDIR/files-S* | sort -u > $WORKDIR/files-to-process.txt

echo Number of files to be processed: `wc -l $WORKDIR/files-to-process.txt`

cd $CURRDIR
