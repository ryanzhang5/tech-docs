sub date {
  my($sec, $min, $hour, $mday, $mon, $year_off)=localtime;
  my $year = $year_off + 1900;
  return sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year, $mon, $mday, $hour, $min, $sec);
}

sub debug {
  print STDERR "DEBUG: ".date()." - @_\n";
}


sub processFile { my($filename) = @_;
  debug("processing file: $filename");
  if (! open (INFILE, $filename) ) {
    debug("error: could not open $filename - $!"); 
    return false;
  }

  # read in the file contents into a string
  my @lines = <INFILE>;
  close INFILE;
  $_ = join '', @lines;

  # check if the class already has a logger
  my $loggerName = "logger";
  my $hasLogger  = /\s(\w+)\s*=\s*(java\.util\.logging\.)?Logger\s*.getLogger\s*\(/;
  if ($hasLogger) {
    $loggerName = "$1";
    debug("found an existing logger: $loggerName");
  }

  # we need to import "Level" class, if we use the Logger.log(Level, String, Throwable) call
  # we are trying to capture cases like: ex.getRootCause().printStackTrace(System.err)
  my $needsLevel  = s/(\s|\{)([a-zA-Z0-9_.()]+)\.printStackTrace\s*\(\s*(System\.(err|out))?\s*\)/$1$loggerName.log(Level.WARNING, "DEFAULT ERROR MSG", $2)/g;
  debug("needs level: $needsLevel");

  # at this point, if we need a Level, it means that we also need a Logger
  my $needsLogger = $needsLevel;

  # special case handling for: try { ... } catch (Exception ex) { System.out.println(ex); ... }
  $needsLogger += s/(\}\s*catch\s*\(\s*\w+\s+(\w+)\s*\)\s*\{\s*)System\.out\.print(?:ln)?\s*\(\s*\2\s*\)/$1$loggerName.info($2.toString())/g;
  # the generic case: System.out.println(abc) 
  $needsLogger += s/System\.out\.print(?:ln)?\s*\((\s*[^)])/$loggerName.info($1/g;
  # the no-arg System.out.println()
  $needsLogger += s/System\.out\.print(?:ln)?\s*\(\s*\)/$loggerName.info("")/g;
  debug("needs logger for System.out: $needsLogger");

  # special case handling for: try { ... } catch (Exception ex) { System.err.println(ex); ... }
  $needsLogger += s/(\}\s*catch\s*\(\s*\w+\s+(\w+)\s*\)\s*\{\s*)System\.err\.print(?:ln)?\s*\(\s*\2\s*\)/$1$loggerName.warning($2.toString())/g;
  # the generic case: System.err.println(abc) 
  $needsLogger += s/System\.err\.print(?:ln)?\s*\((\s*[^)])/$loggerName.warning($1/g;
  # the no-arg System.err.println()
  $needsLogger += s/System\.err\.print(?:ln)?\s*\(\s*\)/$loggerName.warning("")/g;
  debug("needs logger for System.err: $needsLogger");

  # did we replace anything?
  if ($needsLogger) {
    # do we have a Logger available - if not, we need to add one.
    if (!$hasLogger) {
      my $getLoggerStmt = "    private static final Logger logger = Logger.getLogger";
      if (! s/(\n(?:public|abstract|final|\s)*class\s+)(\w+)([^{]*{)/$1$2$3\n$getLoggerStmt($2.class.getName());/ ) {
        debug("error: could not parse the beginning of the class"); 
        return false;
      }
      # my $className = "$2";
      debug("added a getLogger() statement");
    }

    # next, check if we need to import the Logger and/or Level class
    my $importsLoggingPackage = /import\s+java.util.logging.\*/;
    my $importsLoggerClass    = /import\s+java.util.logging.Logger/;
    my $importsLevelClass     = /import\s+java.util.logging.Level/;
  
    if (!$importsLoggingPackage) {
      # we assume that all classes have a package statement
      if ($needsLevel and !$importsLevelClass) {
        s/(package\s.*\n+)/$1import java.util.logging.Level;\n/;
        debug("added an import for the Level");
      }
      if (!$importsLoggerClass) {
        s/(package\s.*\n+)/$1import java.util.logging.Logger;\n/;
        debug("added an import for the Logger");
      }
    }
  }

  debug("writing out the modified file");
  if (! open (OUTFILE, ">$filename") ) {
    debug("error: could not open the file for writing - $!");
    return false;
  }
  print OUTFILE $_;
  close OUTFILE;
}

sub processFiles { my($baseDir) = @_;
  debug("processing files in: $baseDir");
  chdir $baseDir || die "error: could not chdir into $baseDir - $!\n";

  my $workDir = "../.logging";

  open (TOPROCESS, "$workDir/files-to-process.txt") || die "error: could not open the list of files to process - $!\n";
  my @filesToProcess = <TOPROCESS>;
  close TOPROCESS;
  chomp @filesToProcess;

  my @filesToIgnore  = ();
  if ( open (TOIGNORE,  "$workDir/files-to-ignore.txt") ) {
    @filesToIgnore = <TOIGNORE>;
    close TOIGNORE;
    chomp @filesToIgnore;
  }

  foreach my $filename (@filesToProcess) {
    if (grep {$_ eq $filename} @filesToIgnore) {
      debug("ignoring file: $filename");
    } else {
      processFile($filename);
    }
  }
}

processFiles($ARGV[0]);

