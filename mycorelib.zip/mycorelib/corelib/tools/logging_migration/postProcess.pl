sub date {
  my($sec, $min, $hour, $mday, $mon, $year_off)=localtime;
  my $year = $year_off + 1900;
  return sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year, $mon, $mday, $hour, $min, $sec);
}

sub debug {
  print STDERR "DEBUG: ".date()." - @_\n";
}


sub postProcess { my($filename) = @_;
  debug("post processing file: $filename");
  if (! open (INFILE, $filename) ) {
    debug("error: could not open $filename - $!"); 
    return false;
  }

  # read in the file contents into a string
  my @lines = <INFILE>;
  close INFILE;

  $currdir = "";
  foreach (@lines) {
    if (/Entering directory `(.*)'/) {
      $currdir = $1;
    } 
    if (/^(.*\.java):(\d+):.*cannot be applied to/) {
      $javafile = $1;
      $linenumber = $2;

      # semi-hack for parsing "make" output (as opposed to ant output)
      if (! ($javafile =~ /\//) ) {
        $javafile = "$currdir/$javafile";
      }
      debug("opening java file: $javafile:$linenumber");
      if (! open (JAVAFILE, $javafile) ) {
        debug("error: could not open $javafile - $!"); 
        next;
      }
      my @javalines = <JAVAFILE>;
      close JAVAFILE;

      # trying to fix the cases: System.out.println(someObject);
      if ($javalines[$linenumber-1] =~ s/(^\s*\w+\.(?:info|warning)\s*\()(.*)(\)\s*;)/$1String.valueOf($2)$3/) {
        debug("successfully added the String.valueOf()");
        if (! open (JAVAFILE, ">$javafile") ) {
          debug("error: could not open $javafile for writing - $!"); 
          next;
        }
        print JAVAFILE join('', @javalines);
        close JAVAFILE;
      } else {
        debug("error: could not add the String.valueOf()");
      }
    }
  }
}

postProcess($ARGV[0]);

