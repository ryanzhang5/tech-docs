package com::wm::corelib::mq::Constants;

require Exporter;
use strict;
use vars qw(@ISA @EXPORT @EXPORT_OK $NATIVE_ENCODING $CP_UTF8);
use MQSeries;
use MQSeries::Message;
use Carp;

@ISA = qw(Exporter);
@EXPORT = qw();
@EXPORT_OK = qw();


$CP_UTF8 = 1208;                # Code page 128, (UTF-8), 0x000004B8
$NATIVE_ENCODING = 237;         # Native Encoding, 0x00000111;


1;
