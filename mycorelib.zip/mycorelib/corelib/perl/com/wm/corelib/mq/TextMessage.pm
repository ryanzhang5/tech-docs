package com::wm::corelib::mq::TextMessage;

require Exporter;
use strict;
use vars qw(@ISA @EXPORT @EXPORT_OK);
use Carp;
use com::wm::corelib::mq::Message;

our $TRUE = (1==1);
our $FALSE = ! $TRUE;

@ISA = qw(Exporter com::wm::corelib::mq::Message);
@EXPORT = qw();
@EXPORT_OK = qw();

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $this  = $class->SUPER::new();

    $this->{JMSMessageClass} = "jms_text";
    $this->{TextData} = "";    
        
    bless ($this, $class);
    
    return $this;
}

sub setText {
    my $self = shift;
    $self->{TextData} = (shift || "");
}

sub getText {
    my $self = shift;
    return ($self->{TextData} || "");
}

sub _cook {
    my $self = shift;
    return ($self->{TextData} || "");
}

sub fillInTestData {   
    my $self = shift;
    
    # clear any existing data
    $self->{TextData} = "";

    my $chars = ' !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\]^_`abcdefghijklmnopqrstuvwxyz{|}~';
    
    $self->{TextData} = ($chars . "\n") x 255;
}
    
    

1;
