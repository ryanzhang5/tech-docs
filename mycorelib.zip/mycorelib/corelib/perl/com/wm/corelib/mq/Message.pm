package com::wm::corelib::mq::Message;

require Exporter;
use strict;
use vars qw(@ISA @EXPORT @EXPORT_OK);
use MQSeries;
use MQSeries::Message;
use Carp;
use Time::HiRes qw( gettimeofday );

use Math::BigInt;

@ISA = qw(Exporter);
@EXPORT = qw();
@EXPORT_OK = qw();

our $TRUE = (1==1);
our $FALSE = ! $TRUE;

# XXX: overload the MQSeries package carp error handlers?
# XXX: provide error handlers locally too (instead of just confess()'ing)
# XXX: set the BufferLen property on the MQ Message object. default is 32k

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $this  = {};
    
    $this->{JMSProps} = ();
    $this->{JMSFolder} = ();
    
    $this->{Persitence} = MQPER_PERSISTENCE_AS_Q_DEF;
    $this->{Priority} = MQPRI_PRIORITY_AS_Q_DEF; # XXX: should the default be 4 like it is for JMS?
    
    $this->{MQMessage} = MQSeries::Message->new( MsgDesc => { Format => MQFMT_RF_HEADER_2, Encoding => 273, CodedCharSetId => 1208 ,
                                                              Persistence => $this->{Persistence},
                                                              Priority => $this->{Priority} } );
    
    bless ($this, $class);
    
    return $this;
}


sub getMQMessage {
    my $self = shift;
    my $debug = shift || 0;

    $self->_prepareMessage($debug);
    
    return $self->{MQMessage};
}

sub clearBody {
    my $self = shift;
    $self->{MQMessage}->Data();
    
    
    # XXX: what does this clear exactly? Does it erase the message props? Does it erase bytes values or mapped values?
    # XXX: ie. does this need to be overloaded in each class to erase state (like the map data for a mapped message?)
}

sub clearProperties {
    my $self = shift;
    $self->{JMSProps} = ();
}

sub getProperty {
    my ($self, $name) = @_;
    return ($self->{JMSProps}->{$name}->{value});
}

sub getPropertyNames {
    my $self = shift;
    return (keys %{$self->{JMSProps}});
}

sub propertyExists {
    my ($self, $name) = @_;
    return (exists $self->{JMSProps}->{$name});
}

sub getJMSMessageID {
    my ($self, $mid) = @_;
    
    return $self->{MQMessage}->{MsgDesc}->{MessageId};
}

#  java.lang.String getJMSCorrelationID() 
#  int getJMSDeliveryMode() 
#  Destination getJMSDestination() 
#  long getJMSExpiration() 
#  int getJMSPriority() 
#  boolean getJMSRedelivered() 
#  Destination getJMSReplyTo() 
#  long getJMSTimestamp() 
#  java.lang.String getJMSType() 

sub setJMSCorrelationID {
    my ($self, $cid) = @_;
    $self->{JMSFolder}->{Cid}= $self->_createString("Cid", $cid);
}

sub setJMSMessageID {
    my ($self, $mid) = @_;    
    $self->{MQMessage}->{MsgDesc}->{MessageId} = $mid;
}

sub setJMSReplyTo {
    my ($self, $replyTo) = @_;
    $self->{JMSFolder}->{Rto}= $self->_createString("Rto", $replyTo);
}

#  void setJMSType(java.lang.String type) 


sub setJMSDeliveryMode {
    my ($self, $dm) = @_;
    
    if ($dm =~ m/^persistent$/i) {
        $self->{MQMessage}->{MsgDesc}->{Persistence} = MQPER_PERSISTENT;
        return;
    }
    elsif ($dm =~ m/^non_persistent$/i) {
        $self->{MQMessage}->{MsgDesc}->{Persistence} = MQPER_NOT_PERSISTENT;
        return;
    }
    
    confess "Delivery mode must be either 'PERSISTENT' or 'NON_PERSISTENT'";
}

sub setJMSPriority {
    my ($self, $pri) = @_;
    
    if ($pri !~ /^\d$/) {
        confess "message priority must be numeric";
    }
    
    if ( ($pri < 0) || ($pri > 9)) {
        confess "message priority must be in the range 0-9";
    }
    
    $self->{MQMessage}->{MsgDesc}->{Priority} = $pri;   
}


# XXX:  what should the actual set expiration method (from the JMS API) do?

sub setTTL {
    my ($self, $ttl) = @_;
    
    if ($ttl !~ m/^\d+$/) {
        confess "TTL value must be numberic";
    }
    
    my $MQExp;
    if ($ttl >= 2147483647) {
        $MQExp = MQEI_UNLIMITED;
    }
    else {
        $MQExp = $ttl / 10;
    }
    
    my @now = gettimeofday();    
    my $exp = ($now[0] * 1000) + int($now[1] / 1000) + $ttl;
    
    $self->{JMSFolder}->{Exp}= $self->_createLong("Exp", Math::BigInt->new("$exp"));
    $self->{MQMessage}->{MsgDesc}->{Expiry} = $MQExp;
}    

#  void setJMSDestination(Destination destination)
#  void setJMSRedelivered(boolean redelivered)

sub setStringProperty {
    my ($self, $name, $value) = @_;
    $self->{JMSProps}->{$name} = $self->_createString($name, $value);
}

sub setBooleanProperty {
    my ($self, $name, $value) = @_;
    $self->{JMSProps}->{$name} = $self->_createBoolean($name, $value);
}

sub setByteProperty {
    my ($self, $name, $value) = @_;
    $self->{JMSProps}->{$name} = $self->_createByte($name, $value);
}

sub setShortProperty {
    my ($self, $name, $value) = @_;
    $self->{JMSProps}->{$name} = $self->_createShort($name, $value);
}

sub setIntProperty {
    my ($self, $name, $value) = @_;
    $self->{JMSProps}->{$name} = $self->_createInt($name, $value);
}

sub setLongProperty {
    my ($self, $name, $value) = @_;
    $self->{JMSProps}->{$name} = $self->_createLong($name, $value);
}

sub setFloatProperty {
    my ($self, $name, $value) = @_;
    $self->{JMSProps}->{$name} = $self->_createFloat($name, $value);
}

sub setDoubleProperty {
    my ($self, $name, $value) = @_;
    $self->{JMSProps}->{$name} = $self->_createDouble($name, $value);
}


my $RFH2Start = "RFH " . chr(0x00) . chr(0x00) . chr(0x00) . chr(0x02); # "RFH " . version 2
my $enc = "" . chr(0x00) . chr(0x00) . chr(0x01) . chr(0x11); # 273 - native enconding
my $ccsi = "" . chr(0x00) . chr(0x00) . chr(0x04) . chr(0xB8); # 1208 - us ascii char set
my $flags = "" . chr(0x00) . chr(0x00) . chr(0x00) . chr(0x00);

sub _prepareMessage {
    my $self = shift;
    my $debug = shift;

    my $format = "";
    my $mcd = "";
        
    if ($self->{JMSMessageClass} eq "jms_map") {
        $format = 'MQSTR   ';
        $mcd = "". chr(0x00) . chr(0x00) . chr(0x00) . chr(0x20) . '<mcd><Msd>jms_map</Msd></mcd>   ';
    }
    elsif ($self->{JMSMessageClass} eq "jms_bytes") {
        $format = '        ';
        $mcd = "". chr(0x00) . chr(0x00) . chr(0x00) . chr(0x20) . '<mcd><Msd>jms_bytes</Msd></mcd> ';
    }
    elsif ($self->{JMSMessageClass} eq "jms_text") {
        $format = 'MQSTR   ';
        $mcd = "". chr(0x00) . chr(0x00) . chr(0x00) . chr(0x20) . '<mcd><Msd>jms_text</Msd></mcd>  ';
    }
    else {
        confess "internal error - JMS Message type [" . $self->{JMSMessageClass} . "] unknown";
    }   
    
    
    my $usr = "";
    if (keys %{$self->{JMSProps}}) {
        $usr = $self->hashToXML("usr", $self->{JMSProps});
        if ( (length($usr) % 4) != 0) {
            $usr .= ' ' x (4 - (length($usr) % 4));
        }
        
        $usr = "" . join("", createBytesForInt(length($usr))) . $usr;
    }

    
    my $jms = "";
    if (keys %{$self->{JMSFolder}}) {
        $jms = $self->hashToXML("jms", $self->{JMSFolder});
        if ( (length($jms) % 4) != 0) {
            $jms .= ' ' x (4 - (length($jms) % 4));
        }
        
        $jms = "" . join("", createBytesForInt(length($jms))) . $jms;
    }
    
    my $RFH2Len = 
        length($RFH2Start) +
        4 +
        length($enc) +
        length($ccsi) +
        length($format) +
        length($flags) +
        length($ccsi) +
        length($mcd) +
        length($usr) +
        length($jms);
    
    
    my $RFH2 = $RFH2Start . join("", createBytesForInt($RFH2Len)) . $enc . $ccsi . $format . $flags . $ccsi . $mcd . $usr . $jms;
    
    $self->{MQMessage}->Data($RFH2 . $self->_cook());

    if ($debug) { print STDERR $self->{MQMessage}->Data() . "\n"; }
}

sub createBytesForInt {
    my $val = shift;
    
    my @bytes = ();
    
    $bytes[0] = (0xff000000 & $val) >> 24;
    $bytes[1] = (0x00ff0000 & $val) >> 16;
    $bytes[2] = (0x0000ff00 & $val) >> 8;
    $bytes[3] = (0x000000ff & $val);
    
    return map(chr, @bytes);
}


sub _validateName {
    my $name = shift;
    
    # property names and map elements must follow java identifier naming standards
    if ($name =~ m/^[A-Z\$\_][A-Z0-9\_]+$/i) {
        return;
    }
    
    confess "invalid property or map element name [$name]";
}


sub _createString {
    my $self = shift;

    my ($name, $value) = @_;
    _validateName($name);
    
    die "invalid string value" if (! defined($value));
    
    $value =~ s/\&/\&amp\;/g;
    $value =~ s/\</\&lt\;/g;
    $value =~ s/\>/\&gt\;/g;
    $value =~ s/\'/\&apos\;/g;
    $value =~ s/\"/\&quot\;/g;
    
    return { value => $value, 
             type => ''         # special case for strings
             }; 
}


sub _createBoolean {
    my $self = shift;

    my ($name, $value) = @_;
    _validateName($name);
    
    return { value => _validateBoolean($value), type => 'boolean' };
}

sub _createByte {
    my $self = shift;

    my ($name, $value) = @_;
    _validateName($name);
    return { value => _validateDecimal($value, -128, 127, "byte"),
             type => 'i1' };
}

sub _createShort {
    my $self = shift;

    my ($name, $value) = @_;
    _validateName($name);
    return { value => _validateDecimal($value, -32768, 32767, "short"),
             type => 'i2' };
}

sub _createInt {
    my $self = shift;

    my ($name, $value) = @_;
    _validateName($name);
    return { value => _validateDecimal($value, -2147483648, 2147483647, "int"),
             type => 'i4' };
}


our $LONG_MAX = Math::BigInt->new("+9223372036854775807");
our $LONG_MIN = Math::BigInt->new("-9223372036854775808");

sub _createLong {
    my $self = shift;

    my ($name, $value) = @_;
    _validateName($name);
    
    
    if ( (ref($value) ne "REF") && (! UNIVERSAL::isa($value, "Math::BigInt")) ) {
        confess "you must use Math::BigInt for long values";
    }
    
    return { value => _validateDecimal($value, $LONG_MIN, $LONG_MAX, "long"),
             type => 'i8' };
}


sub _createFloat {
    my $self = shift;

    my ($name, $value) = @_;
    return __createFloatOrDouble($name, $value, "float");
}

sub _createDouble {
    my $self = shift;

    my ($name, $value) = @_;
    return __createFloatOrDouble($name, $value, "double");
}

sub __createFloatOrDouble {
    my ($name, $value, $type) = @_;
    _validateName($name);
    
    my $v2 = _validateFloatOrDouble($value, $type);
    
    my $rv = ();    
    $rv->{value} = $v2;
    
    if ($type eq "float") {
        $rv->{type} = 'r4';
    }
    elsif ($type eq "double") {
        $rv->{type} = 'r8';
    }

    return $rv;
}


sub _createBytes {
    my $self = shift;

    my ($name, $value) = @_;
    _validateName($name);
    
    return { value => unpack("H*", $value), 
             type => 'bin.hex' };
}


sub _validateBoolean {
    my $val = shift;

    if ($val =~ m/^\d+$/) {
        if ($val > 0) {
            return 1;
        }        
        return 0;
    }
    
    if ($val =~ m/^[ \t]*true[ \t]*$/i) {
        return 1;
    }
    elsif ($val =~ m/^[ \t]*false[ \t]*$/i) {
        return 0;
    }
    
    confess "invalid boolean value [$val]";
}

sub _validateFloatOrDouble {
    my ($val, $name) = @_;
    
    my $str = "$val";
    
    if ($str =~ m/^[-+]?\d+\.?\d*([eE][-+]?\d+)?$/) {
        my $rv = sprintf("%.8e", $val);    
        return $rv;
    }
    
    confess "invalid $name value [$val]";    
}


sub _validateDecimal {
    my ($val, $min, $max, $name) = @_;
    
    if ($val !~ m/^[\+\-]?\d+$/) { confess "invalid $name value [$val]"; }
    
    if (($val >= $min) && ($val <= $max)) {
        return $val+0;
    }
    
    confess "invalid $name value [$val]";
}


sub _cook {
    my $self = shift;
    return $self->toXML();
}

sub hashToXML {
    my $self = shift;
    my $topElement = shift;
    my $hr = shift;
    
    my $rv = "<$topElement>";
    for my $key (keys %{$hr}) {
        my $item = $hr->{$key};
        $rv .= "<$key";
        my $type = $item->{type};
        if ($type ne "") {
            $rv .= " dt='$type'";
        }

	if ($type =~ m/^i/) {
	    my $num = $item->{value};
	    $num =~ s/^\+//;	# strip leading '+' character
	    $rv .= ">" . $num . "</$key>";
	}
	else {
	    $rv .= ">" . $item->{value} . "</$key>";
	}

    }
    $rv .= "</$topElement>";
   
    return $rv;
}



1;
