package com::wm::corelib::mq::MapMessage;

require Exporter;
use strict;
use vars qw(@ISA @EXPORT @EXPORT_OK);
use Carp;
use com::wm::corelib::mq::Message;

our $TRUE = (1==1);
our $FALSE = ! $TRUE;

@ISA = qw(Exporter com::wm::corelib::mq::Message);
@EXPORT = qw();
@EXPORT_OK = qw();

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $this  = $class->SUPER::new();

    $this->{JMSMessageClass} = "jms_map";    
    $this->{MappedData} = ();    
        
    bless ($this, $class);
    
    return $this;
}


sub setString {
    my ($self, $name, $value) = @_;
    $self->{MappedData}->{$name} = $self->SUPER::_createString($name, $value);
}

sub setBoolean {
    my ($self, $name, $value) = @_;
    $self->{MappedData}->{$name} = $self->SUPER::_createBoolean($name, $value);
}

sub setByte {
    my ($self, $name, $value) = @_;
    $self->{MappedData}->{$name} = $self->SUPER::_createByte($name, $value);
}

sub setShort {
    my ($self, $name, $value) = @_;
    $self->{MappedData}->{$name} = $self->SUPER::_createShort($name, $value);
}

sub setInt {
    my ($self, $name, $value) = @_;
    $self->{MappedData}->{$name} = $self->SUPER::_createInt($name, $value);
}

sub setLong {
    my ($self, $name, $value) = @_;
    $self->{MappedData}->{$name} = $self->SUPER::_createLong($name, $value);
}

sub setFloat {
    my ($self, $name, $value) = @_;
    $self->{MappedData}->{$name} = $self->SUPER::_createFloat($name, $value);
}

sub setDouble {
    my ($self, $name, $value) = @_;
    $self->{MappedData}->{$name} = $self->SUPER::_createDouble($name, $value);
}

sub setBytes {
    my ($self, $name, $value) = @_;
    $self->{MappedData}->{$name} = $self->SUPER::_createBytes($name, $value);
}

sub _cook {
    my $self = shift;
    return $self->toXML();
}

sub toXML {
    my $self = shift;        
    return $self->SUPER::hashToXML("map", $self->{MappedData});
}

sub fillInTestData {   
    my $self = shift;

    # clear any existing data
    $self->{MappedData} = ();
    
    # booleans 
    $self->setBoolean("bool1", "true");
    $self->setBoolean("bool2", "false");
    $self->setBoolean("bool3", 1);
    $self->setBoolean("bool4", 0);
    
    # send all possible byte values
    for (my $i=-128; $i<=127; $i++) {
        my $n = $i+128;
        if ($n <= 9) { $n = "00" . $n; }
        elsif ($n <= 99) { $n = "0" . $n; }    
        $self->setByte("b".$n, $i);
    }
    
    # shorts 
    $self->setShort("s1",  32767);
    $self->setShort("s2", -32768);
    $self->setShort("s3", "0");
    $self->setShort("s4", "1");
    $self->setShort("s5", "-1");
    
    # ints
    $self->setInt("i1",  2147483647);
    $self->setInt("i2", -2147483648);
    $self->setInt("i3", "0");
    $self->setInt("i4", "1");
    $self->setInt("i5", "-1");
    
    # longs 
    $self->setLong("l1", Math::BigInt->new(" 9223372036854775807"));
    $self->setLong("l2", Math::BigInt->new("-9223372036854775808"));
    $self->setLong("l3", Math::BigInt->new("0"));
    $self->setLong("l4", Math::BigInt->new("1"));
    $self->setLong("l5", Math::BigInt->new("-1"));
    
    # floats
    $self->setFloat("f1", 3.40282347E+38);
    $self->setFloat("f2", 1.175E-37);
    $self->setFloat("f3", "1");
    $self->setFloat("f4", "0");
    $self->setFloat("f5", "-1");
    $self->setFloat("f6", -3.40282347E+38);
    $self->setFloat("f7", -1.175E-37);
    

    # doubles
    $self->setDouble("d1", 1.7976931348623E+308);
    $self->setDouble("d2", 2.225E-307);
    $self->setDouble("d3", "1");
    $self->setDouble("d4", "0");
    $self->setDouble("d5", "-1");
    $self->setDouble("d6", -1.7976931348623E+308);
    $self->setDouble("d7", -2.225E-307);
    
    # send every possible byte value in a byte array
    my $bytes = "";
    for (my $i=0; $i<=255; $i++) {
        $bytes .= chr($i);
    }
    $self->setBytes("byteData", $bytes x 10);
    
    # send a string with a few characters that will be escaped
    $self->setString("stringData", "now 'is' the \"time\" for <all> good men to come to the aid of their country");
}
    
    

1;
