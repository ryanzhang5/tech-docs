package com::wm::corelib::mq::BytesMessage;

require Exporter;
use strict;
use vars qw(@ISA @EXPORT @EXPORT_OK);
use Carp;
use com::wm::corelib::mq::Message;

our $TRUE = (1==1);
our $FALSE = ! $TRUE;

@ISA = qw(Exporter com::wm::corelib::mq::Message);
@EXPORT = qw();
@EXPORT_OK = qw();

sub new {
    my $proto = shift;
    my $class = ref($proto) || $proto;
    my $this  = $class->SUPER::new();

    $this->{JMSMessageClass} = "jms_bytes";
    $this->{BytesData} = "";    
        
    bless ($this, $class);
    
    return $this;
}


sub getBodyLength {
    my $self = shift;
    
    if ((exists $self->{BytesData}) && (defined $self->{BytesData})) {
        return length($self->{BytesData});
    }
    
    return 0;   
}


sub setBytes {
    my $self = shift;
    
    $self->{BytesData} = (shift || "");
}

sub getBytes {
    return unless defined wantarray;
    
    my $self = shift;
    
    if (! wantarray) {
        return ($self->{BytesData} || "");
    }
    
    if ((exists $self->{BytesData}) && (defined $self->{BytesData})) {
        return split(//, $self->{BytesData});
    }
    
    return ();
}

sub _cook {
    my $self = shift;
    return ($self->{BytesData} || "");
}

sub fillInTestData {   
    my $self = shift;
    
    # clear any existing data
    $self->{BytesData} = "";
    
    my $bytes = "";
    for (my $i=0; $i <= 255; $i++) {
        $bytes .= chr($i);
    }
   
    $self->{BytesData} = $bytes x 100;
}
    

    

1;
