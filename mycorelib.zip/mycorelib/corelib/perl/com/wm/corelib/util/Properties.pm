package com::wm::corelib::util::Properties;

#
# Java-style properties handling.
# author: Orion Letizi
#
sub new {
  my ( $class, $file ) = @_;
  my $self = {};
  bless $self, $class;

  if ( ! defined $file ) {
      warn "No configuration file specified!";
  }
  else {
      eval
      {
          $self->_loadProps( $file );
      };
      if ( $@ ) 
      {
          warn "Properties.pm: Exception: " . $@;
      }
  }
  return $self;
}

sub getProperty {
  my ( $self, $name ) = @_;
  my $value = $self->{$name};
  $value = "" unless defined $value;
  return $value;
}

sub setProperty {
  my ( $self, $name, $value ) = @_;
  $self->{$name} = $value;
}

sub _loadProps {
  my ( $self, $file ) = @_;

  open FILE, $file or warn "Can't open $file for reading!\n";

  while ( <FILE> ) {
    my $line = $_;
    unless ( $line =~ /^\s*\#/ or $line =~ /^\s*$/ ) {
      my ( $name, $value ) = split /=/, $line;
      chomp($name);
      chomp($value);
      $name =~ s/^\s+//; # remove leading white spaces
      $name =~ s/\s+$//; # remove trailing white spaces
      $value =~ s/^\s+//; # remove leading white spaces
      $value =~ s/\s+$//; # remove trailing white spaces

      $self->{$name} = $value;
    }
  }
  close FILE;
}

1;
