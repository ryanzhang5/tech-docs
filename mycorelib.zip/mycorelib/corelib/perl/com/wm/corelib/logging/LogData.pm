package com::wm::corelib::logging::LogData;

use strict;


sub new
{
    my ( $class ) = @_;
    my $self = {};
    bless $self, $class;
    $self->{ '_payload' } = {};
    return $self;
}

sub getEventId
{
    my ( $self ) = @_;
    return $self->{'_eventId'};
}

sub setEventId
{
    my ( $self, $eventId ) = @_;
    $self->{'_eventId'} = $eventId;
}

sub getGroupId
{
    my ( $self ) = @_;
    return $self->{'_groupId'};
}

sub setGroupId 
{
    my ( $self, $groupId ) = @_;
    $self->{'_groupId'} = $groupId;
}

# call this to add a name value pair.
sub addData
{
    my ( $self, $name, $value ) = @_;
    $self->getPayload()->{ $name } = $value;
}

sub toString
{
    my ( $self ) = @_;
    my $buf =  "LogData { \n";
    foreach ( sort keys %{ $self } )
    {
        $buf .= "\t$_:" . $self->{$_} . "\n";
    }
    $buf .= "\t}\n";
    return $buf;
}

sub getPayload
{
    my ( $self ) = @_;
    return $self->{'_payload'};
}

1;
