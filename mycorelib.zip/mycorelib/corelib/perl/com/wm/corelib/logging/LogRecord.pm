package com::wm::corelib::logging::LogRecord;

sub new
{
    my ( $class, $logdata ) = @_;
    my $self = {};
    bless $self, $class;
    $self->setLogData( $logdata );
    # should this be time or localtime( time )?
    my $now = time();
    $now *= 1000;
    $self->setCreatedTime( $now );
    # this is unix-specific.
    $self->setHostname( `hostname` );
    return $self;
}

sub setLogData
{
    my ( $self, $logdata ) = @_;
    $self->{'_logdata'} = $logdata;
}

sub getLogData
{
    my ( $self ) = @_;
    return $self->{'_logdata'};
}

sub getCreatedTime 
{
    my ( $self ) = @_;
    return $self->{'_createdTime'};
}

sub setCreatedTime 
{
    my ( $self, $createdTime ) = @_;
    $self->{'_createdTime'} = $createdTime;
}

sub setHostname
{
    my ( $self, $hostname ) = @_;
    $self->{'_hostname'} = $hostname;
}

sub getHostname
{
    my ( $self, $hostname ) = @_;
    return $self->{'_hostname'};
}

sub setLevel
{
    my ( $self, $priority ) = @_;
    $self->{'_level'} = $priority;
}

sub getLevel
{
    my ( $self ) = @_;
    return $self->{'_level'};
}

1;
