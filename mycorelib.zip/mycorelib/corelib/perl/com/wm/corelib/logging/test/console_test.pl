#!/usr/bin/perl -w

use strict;
use lib $ENV{'CORELIB_HOME'} . "/perl";
use com::wm::corelib::logging::LogData;
use com::wm::corelib::logging::Logger;

my $logger = new com::wm::corelib::logging::Logger ("/path/to/properties/file");
$logger->addDriver( "com::wm::corelib::logging::driver::Console" );


my $logdata = new com::wm::corelib::logging::LogData ();

$logdata->setEventId( "LOGGER.0.100" );
$logdata->setGroupId( "12345" );
$logdata->addData( "Name 1", "Value 1" );
$logdata->addData( "Name 2", "Value 2" );

$logger->doLog( 1, $logdata );

