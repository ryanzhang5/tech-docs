package com::wm::corelib::logging::driver::Console;
use Carp;

sub new
{
    my ( $class, $props ) = @_;
    my $self = {};
    bless $self, $class;
    unless ( defined $props )
    {
        carp ("Console: You didn't pass me a properties object!");
    }
    $self->_setProperties( $props );
    return $self;
}

# accepts a LogRecord and does something nice with it.
sub handleRecord
{
    my ( $self, $logRecord ) = @_;
    my $logData = $logRecord->getLogData();
    my $out = $logRecord->getCreatedTime() . ": EID: " . $logData->getEventId();
    $out .= "; GID: " . $logData->getGroupId() . "; ";
    foreach ( sort keys %{ $logData->getPayload() } ) 
    {
        $out .= "$_=" . $logData->getPayload()->{ $_ };
    }
    $out .= "\n";
    print $out;
}

sub getProperty
{
    my ( $self, $propName ) = @_;
    return $self->_getProperties()->getProperty( $propName );
}

sub _getProperties
{
    my ( $self ) = @_;
    return $self->{'_properties'}
}

sub _setProperties
{
    my ( $self, $props ) = @_;
    $self->{'_properties'} = $props;
}

1;
