package com::wm::corelib::logging::Logger;

use strict;
use com::wm::corelib::util::Properties;
use com::wm::corelib::logging::LogRecord;

sub new
{
    my ( $class, $propthing ) = @_;
    my $self = {};
    bless $self, $class;
    my $props;
    unless ( scalar $propthing =~ /com::wm::corelib::util::Properties/ ) {
      # we did not get a pre-build properties object.
      $props = new com::wm::corelib::util::Properties( $propthing );
    }
    else {
      # we did get a pre-build properties object.
      $props = $propthing;
    }

    $self->_setProperties( $props );

    # initialize an array reference to put the log drivers in.
    $self->{'_drivers'} = [];
    # Now add all of the drivers...
    my $drivers = $props->getProperty( "com.wm.corelib.logging.perl.drivers" );
    my @drivers = split /,/, $drivers;
    foreach ( @drivers )
    {
        $self->addDriver( $_ );
    }

    # Now check to make sure that there is at least one driver
    # XXX: Is there a way to check if the driver at least conforms to
    # the implied interface?
    unless ( scalar @{ $self->getDrivers() } )
    {
        warn "Logger.pm: There were no drivers configured.  I'm automatically adding the Console driver.";
        $self->addDriver( "com::wm::corelib::logging::driver::Console" );
    }

    # XXX: This is totally lame.  This should come from properties,
    # not from executing a command.
    $self->setHostname(`hostname`);

    return $self;
}

sub addDriver
{
    my ( $self, $driverName ) = @_;
    my $drivers = $self->getDrivers();
    my $driver;
    my $properties = $self->_getProperties();
    eval {
        loadDriver( $driverName );
        $driver = $driverName->new( $properties );
        push @$drivers, $driver;
    };
    if ( $@ )
    {
        warn "Logger.addDriver: Exception adding driver $driverName: " . $@;
    }
}

## This subroutine can blow up, so you'd better wrap it in a nice
## eval block.
sub loadDriver
{
    # XXX: This is totally dumb.  There's should be an automatic way to do this
    # in perl (there probably is).
    my ( $driverName ) = @_;
    my $exp = "::";
    my $replace = "/";
    $driverName =~ s/$exp/$replace/g;
    $driverName .= ".pm";
    foreach ( @INC )
    {
        my $prefix = $_;
        my $filename = "$prefix/$driverName";
        if ( -e $filename )
        {
            require $filename;
            return;
        }
    }
}

sub getDrivers
{
    my ( $self ) = @_;
    return $self->{'_drivers'};
}

sub doLog
{
  my ( $self, $loglevel, $logdata ) = @_;
  my $logRecord = new com::wm::corelib::logging::LogRecord( $logdata );
  # set the log level in the log record
  $logRecord->setLevel( $loglevel );

  my $drivers = $self->getDrivers();
  ## give each driver a chance to act on the log record.
  foreach ( @$drivers )
  {
      my $driver = $_;
      # Notice that every driver must implement a method
      # called handleRecord.  If it doesn't, we've got a problem
      eval {
          $driver->handleRecord( $logRecord );
      };
      if ( $@ )
      {
          warn "Logger: problem calling handleRecord on log driver: " . $@;
      }
  }
}

sub setHostname
{
    my ( $self, $hostname ) = @_;
    $self->{ '_hostname' } = $hostname;
}

sub getHostname
{
    my ( $self ) = @_;
    return $self->{'_hostname'};
}

sub getProperty
{
    my ( $self, $propName ) = @_;
    return $self->{'_properties'}->getProperty( $propName );
}

sub setProperty {
  my ( $self, $propName, $propValue ) = @_;
  $self->{'_properties'}->setProperty( $propName, $propValue );
}

sub _initConfig
{
    my ( $self, $configFile ) = @_;
    my $props = new com::wm::corelib::util::Properties( $configFile );
    $self->_setProperties( $props );
}

sub _setProperties
{
    my ( $self, $props ) = @_;
    $self->{'_properties'} = $props;
}

sub _getProperties
{
    my ( $self ) = @_;
    return $self->{'_properties'};
}

1;
