#include "carton.H"
#include "cartonConf.H"

carton::carton( const string & cartonType ) {
  assert( cartonConf::CartonDefinitions != NULL );

//  carton::MasterCarton = this;

  origin = new point( 0.01, 0.01, 0.01 );
  children[ 0 ] = children[ 1 ] = children[ 2 ] = NULL;
  i = NULL;
  setIsMaster( true );
  actualOrigin = new point( 0.01, 0.01, 0.01 );
  conf = cartonConf::CartonDefinitions;
  dim = conf->findCartonByName( cartonType );
  commonName = new string( cartonType );
}

carton::carton( string * commonName, cartonConf * conf, point * actualOrigin ) {
  this->commonName = commonName;
  this->conf = conf;
  this->actualOrigin = actualOrigin;

  this->origin = new point( 0.01, 0.01, 0.01 );
  this->dim = new point( actualOrigin->getDim_X( ) - origin->getDim_X( ),
			 actualOrigin->getDim_Y( ) - origin->getDim_Y( ),
			 actualOrigin->getDim_Z( ) - origin->getDim_Z( ) );
}


/* -- deprecated
 *carton::carton( const carton & parentCarton, const string & cartonType ) {
 * origin = new point( 0, 0, 0 );
 * children = NULL;
 * i = NULL;
 * actualOrigin = new point( ( parentCarton.i )->getDim_X( ) + parentCarton.getDim_X( ),
 *			      ( parentCarton.i )->getDim_Y( ) + parentCarton.getDim_Y( ),
 *			      ( parentCarton.i )->getDim_Z( ) + parentCarton.getZ_AXIS( ) );
 *   dim = NULL;
 *   commonName = new string( cartonType );
 *}
*/


//////////
// Recurses down the children looking for the item by name
//////////
item * carton::findItemInAllCartons( const string & itemName ) const {
  item * ret_x,
       * ret_y,
       * ret_z;

  if( this->i->getCommonName( ) == itemName ) {
    return i;
  }
  else if( children[ 0 ] == NULL ) {
    return NULL;
  }
  else {
    ret_x = children[ X_AXIS ]->findItemInAllCartons( itemName );
    ret_y = children[ Y_AXIS ]->findItemInAllCartons( itemName );
    ret_z = children[ Z_AXIS ]->findItemInAllCartons( itemName );

    // XXX: not ideal.  Assumes item won't ever show up in more than one place.
    assert( ( ret_x == NULL ) || ( ret_y == NULL ) || ( ret_z == NULL ) );

    if( ret_x ) return ret_x;
    if( ret_y ) return ret_y;
    if( ret_z ) return ret_z;
  }

  return NULL;
}

bool carton::cartonize( item & i ) {
  if( this->canHold( i ) ) {
    this->i = & i;    //XXX: NOT SAFE!  The 'i' reference could be a stack variable, not heap.
    return true;
  }
  else {
    return false;
  }
}


// Assumes carton's dimensions and item's dimensions are both sorted
bool carton::canHold( const item & i ) const {
  return( ( * dim ) > i.getDimensions( ) );
}

int carton::createVirtualChildCartons( ) {
  point *x,
        *y,
        *z;

  carton *c_x,
         *c_y,
         *c_z;


  assert( i != NULL );

  x = clipRegionWithItems( X_AXIS );
  y = clipRegionWithItems( Y_AXIS );
  z = clipRegionWithItems( Z_AXIS );

  // Construct the 3 clipped cartons created by the item insert and assign them to this carton's children.
  c_x = new carton( commonName, conf, x ); children[ X_AXIS ] = c_x;
  c_y = new carton( commonName, conf, y ); children[ Y_AXIS ] = c_y;
  c_z = new carton( commonName, conf, z ); children[ Z_AXIS ] = c_z;

  return 3;
}

// The returned value is allocated on the heap.  be careful to free it if you don't need it anymore.
// Intended to be passed to a carton.origin member value so should not need freeing separate of the
// carton destructor.
point * carton::clipRegionWithItems( int axis ) {
  point * newPoint;
  float x, y, z;

  assert( i != NULL );

  switch( axis ) {
  case X_AXIS:
    x = origin->getDim_X( ) + i->getDim_X( );
    y = origin->getDim_Y( );
    z = origin->getDim_Z( );
    break;
  case Y_AXIS:
    x = origin->getDim_X( );
    y = origin->getDim_Y( ) + i->getDim_Y( );
    z = origin->getDim_Z( );
    break;
  case Z_AXIS:
    x = origin->getDim_X( );
    y = origin->getDim_Y( );
    z = origin->getDim_Z( ) + i->getDim_Z( );
    break;
  }

  printf( "CLIPPED [%f] [%f] [%f]\n", x, y, z );
  // DO NOT SORT THE COORDINATES!  Order is important as these are dimensionally-relevant
  newPoint = new point( x, y, z );
  return newPoint;
}

float carton::percentFreeWithItem( const item & i ) const {
  return( ( i.getDim_X( ) * i.getDim_Y( ) * i.getDim_Z( ) ) / 
          ( dim->getDim_X( ) * dim->getDim_Y( ) * dim->getDim_Z( ) ) );
}


bool carton::add( item & i ) {
  float pct_x,
        pct_y,
        pct_z;

  if(this->i == NULL ) {        // No items so add it right here.
    this->i = & i;
    return true;
  }

  if( children[ 0 ] == NULL )  createVirtualChildCartons( );

  pct_x = children[ X_AXIS ]->percentFreeWithItem( i );
  pct_y = children[ Y_AXIS ]->percentFreeWithItem( i );
  pct_z = children[ Z_AXIS ]->percentFreeWithItem( i );
    
}
