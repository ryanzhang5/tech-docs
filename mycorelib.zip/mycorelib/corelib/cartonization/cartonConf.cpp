#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

#define __CARTONCONF_INTERNAL__
#include "cartonConf.H"
#include "util.H"

cartonConf::cartonConf( const string & fileName ) {
  fd = -1;
  _isValidFile = false;
  _isValidSyntax = false;
  next = NULL;
  fName = fileName;

  _isValidFile = openFile( );
  _isValidSyntax = parseAndLoad( );
}

cartonConf::~cartonConf( ) {
  assert( fd != -1 );
  close( fd );
}

cartonConf::cartonConf( ) {
  _isValidFile = _isValidSyntax = false;
  dim = NULL;
  fd = -1;
}

bool cartonConf::isValid( ) const {
  return( _isValidFile && _isValidSyntax );
}

point * cartonConf::findCartonByName( const string & cartonName ) {

  if( cartonName == * this->commonName ) {
    return this->dim;
  }
  else if( next == NULL ) {
    return NULL;
  }
  else {
    return next->findCartonByName( cartonName );
  }
}

bool cartonConf::openFile( ) {
  _isValidFile = true;

  if( ( fd = open( fName.data( ), O_RDONLY | O_EXCL, 0 ) ) < 0 ) {
    _isValidFile = false;
  }

  return _isValidFile;
}

bool cartonConf::parseAndLoad( ) {
  assert( _isValidFile );
  _isValidSyntax = true;

  cartonConf * newElement, *currElement = NULL;
  char buf[65536],
    strBuf[256],
       * tempPtr;
  int res = 0,
      i = 0,
      count = 0;

  float x,
    y,
    z;


  memset( buf, 0, 65536 );
  memset( strBuf, 0, 256 );

  do {
    i = read( fd, buf + res, 65536 - res );
    res += i;
  } while( i  > 0 );

  PRINTF( "File [%s] is [%d] bytes long...parsing.\n", fName.data( ), res );

  i = 0;
  if( CartonDefinitions ) {
    currElement = CartonDefinitions;
  }
  else {
    currElement = this;
    CartonDefinitions = this;
  }

  while( i < res ) {

    tempPtr = strstr( &buf[ i ], "carton definition" );
    if( ( tempPtr == NULL ) && count == 0 ) {   // no carton definitions in file
      _isValidSyntax = false;
      break;
  }
    else if( tempPtr == NULL ) break;

    i = tempPtr - buf;
    tempPtr = strstr( &buf[ i ], "{" ); 

    if( !( strpbrk( &buf[ i ], "\t\n " ) ) || (tempPtr < strpbrk( & buf[ i ], "\t\n " ) ) ) {
      _isValidSyntax = false;
      break;
    }

    i = tempPtr - buf;
    tempPtr = strstr( &buf[ i ], "carton name" );
    sscanf( tempPtr,  "carton name = %s\n", strBuf );
    currElement->commonName = new string( strBuf );

    i = tempPtr - buf;
    tempPtr = strstr( &buf[ i ], "x" );
    sscanf( tempPtr, "x = %f\n", &x );
    i = tempPtr - buf;

    tempPtr = strstr( &buf[ i ], "y" );
    sscanf( tempPtr, "y = %f\n", &y );
    i = tempPtr - buf;

    tempPtr = strstr(& buf[ i ], "z" );
    sscanf( tempPtr, "z = %f\n", &z );
    i = tempPtr - buf;
    currElement->dim = new point( x, y, z, true );

    tempPtr = strstr( &buf[ i ] , "}" );
    i = tempPtr - buf;

    newElement = new cartonConf( );
    currElement->next = newElement;
    currElement = newElement;
    count++;
  } // while

  if( ! count) {
    _isValidSyntax = false;
  }

  return _isValidSyntax;
}

cartonConf * cartonConf::CartonDefinitions = NULL;
#undef __CARTONCONF_INTERNAL__
