#include <stdlib.h>

#include "util.H"
#include "point.H"


//////////
//Simple constructor
//////////
point::point( float x, float y, float z ) {

  assert( x > 0 );
  assert(y > 0 );
  assert( z > 0 );

  dim_x = x;
  dim_y = y;
  dim_z = z;
}


//////////
// Constructor w/ auto-sorting capabilities
//////////
point::point( float x, float y, float z, bool sort ) {
  float dimVector[3] = {x, y, z};
  float *ptr = NULL;

  if( sort ) {
    ptr = sortDimensions( dimVector );

    PRINTF( "sorted dimensions are: [%f] [%f] [%f]\n", dimVector[ 0 ],
	    dimVector[ 1 ],
	    dimVector[ 2 ] );

    // Call the base constructor to insert in point descending order
  }

  dim_x = dimVector[ 0 ];
  dim_y = dimVector[ 1 ];
  dim_z = dimVector[ 2 ];
  _isSorted = true;

}

point & point::operator+( const point & otherPoint ) {
  point * val = new point( );

  val->setDim_X( dim_x + otherPoint.dim_x );
  val->setDim_Y( dim_y + otherPoint.dim_y );
  val->setDim_Z( dim_z + otherPoint.dim_z );

  return * val;
}

point & point::operator-( const point & otherPoint ) {
  point * val = new point( );

  val->setDim_X( dim_x - otherPoint.dim_y );
  val->setDim_Y( dim_y - otherPoint.dim_y );
  val->setDim_Z( dim_z - otherPoint.dim_z );

  return * val;
}

bool point::operator== ( const point & otherPoint ) {
  return( ( dim_x == otherPoint.dim_x ) &&
	  ( dim_y == otherPoint.dim_y ) &&
	  ( dim_z == otherPoint.dim_z ) );
}

bool point::operator> ( const point & otherPoint ) {
  return( ( dim_x > otherPoint.dim_x ) &&
	  ( dim_y > otherPoint.dim_y ) &&
	  ( dim_z > otherPoint.dim_z ) );
}

bool point::operator< ( const point & otherPoint ) {
  return( ( dim_x < otherPoint.dim_x ) &&
	  ( dim_y < otherPoint.dim_y ) &&
	  ( dim_z < otherPoint.dim_z ) );
}

point::point( ) {
  dim_x = dim_y = dim_z = 0;
}
