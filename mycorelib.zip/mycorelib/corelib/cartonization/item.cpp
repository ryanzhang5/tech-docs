#include "util.H"
#include "item.H"

item::item( float dim_x, float dim_y, float dim_z ) {
  p = new point( dim_x, dim_y, dim_z, true );
  commonName = new string( "testing 1 2 3" );
}

item::item( ) {
  p = new point( 0, 0, 0 );
}

bool item::operator>( const item & b ) {
  return( p > b.p );
}

bool item::operator==( const item & b ) {
  return( p == b.p);
}

bool item::operator<( const item & b ) {
  return( p < b.p );
}
