#include <stdio.h>
#include <assert.h>
#include "util.H"


float * sortDimensions( float * dimensions ) {
  int i = 0,
    j = 0,
    maxIndex = 0;

  float max = 0,
    temp;

  assert( dimensions != NULL );

  for( i = 0; i < DIMENSIONS; i++ ) {
    for( j = i; j < DIMENSIONS; j ++ ) {
      if( dimensions[ j ] >= dimensions[ i ] ) { max = dimensions[ j ]; maxIndex = j; }
    }

    temp = dimensions[ i ];
    dimensions[ i ] = max;
    dimensions[ maxIndex ] = temp;
  }

  return dimensions;
}
