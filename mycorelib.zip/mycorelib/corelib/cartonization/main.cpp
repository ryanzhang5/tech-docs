#include <stdio.h>

#include "item.H"
#include "carton.H"
#include "cartonConf.H"

int main( int argc, char ** argv ) {
  string * foo = new string( "450" );
  string * bar = new string( "foo.conf" );
  cartonConf::CartonDefinitions = new cartonConf( * bar );

  item a = item(1, 2, 3 );
  item b = item( 6, 5, 89 );

  carton c = carton( * foo );
  delete( foo );
  foo = new string( "900" );
  carton d = carton( * foo );
  delete( foo );

  foo = new string( "150" );
  carton e = carton( * foo );

  printf( "Carton [%s] can %s hold item a\n", c.getCommonName( )->data( ), c.canHold( a ) ? "" : "not" );
  printf( "Carton [%s] can %s hold item b\n", c.getCommonName( )->data( ), c.canHold( b ) ? "" : "not" );
  printf( "Carton [%s] can %s hold item a\n", d.getCommonName( )->data( ), d.canHold( a ) ? "" : "not" );
  printf( "Carton [%s] can %s hold item b\n", d.getCommonName( )->data( ), d.canHold( b ) ? "" : "not" );
  printf( "Carton [%s] can %s hold item a\n", e.getCommonName( )->data( ), e.canHold( a ) ? "" : "not" );
  printf( "Carton [%s] can %s hold item b\n", e.getCommonName( )->data( ), e.canHold( b ) ? "" : "not" );
  return 1;
}

