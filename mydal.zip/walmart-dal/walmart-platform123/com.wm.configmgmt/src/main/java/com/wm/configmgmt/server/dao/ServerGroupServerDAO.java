/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.ServerGroupServer;
import com.wm.configmgmt.server.dataobject.VersionedKeyMulti;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * ServerGroupServerDAO
 *
 * @author mkishore
 * @since 1.0
 */
public class ServerGroupServerDAO extends BaseDAO<ServerGroupServer, VersionedKeyMulti> implements IServerGroupServerDAO {
    @PersistenceContext (name = "configmgmt")
    public void setEntityManager(EntityManager entityManager) {
        super.setEntityManager(entityManager);
    }
}