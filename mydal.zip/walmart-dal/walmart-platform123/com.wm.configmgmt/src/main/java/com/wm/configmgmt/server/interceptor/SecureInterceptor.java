/*
 * Copyright 2009 Walmart.com. All rights Reserved
 */
package com.wm.configmgmt.server.interceptor;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.ValidationAware;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
import com.opensymphony.xwork2.validator.DelegatingValidatorContext;
import com.opensymphony.xwork2.validator.ValidatorContext;
import com.wm.configmgmt.server.action.IUserAware;
import com.wm.configmgmt.server.security.ISecurityService;
import com.wm.configmgmt.server.security.User;
import com.wm.configmgmt.server.util.AppContextProvider;
import org.apache.commons.lang.xwork.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.Map;

/**
 * This interceptor will intercept all the requests to check whether the user is logged in and authenticated.
 * This implementation refers http://www.vitarara.org/cms/struts_2_cookbook/creating_a_login_interceptor.
 *
 * @author Nagesh Cherukuri
 *         Date: Dec 8, 2009
 *         Time: 10:53:40 AM
 */
public class SecureInterceptor extends AbstractInterceptor {
    private static final Log log = LogFactory.getLog(SecureInterceptor.class);

    private static final String USER = "WM_USER_SESSSION_HANDLE";
    private static final String LOGIN_ATTEMPT = "WM_LOGIN_ATTEMPT";
    private static final String USERNAME = "WM_USERNAME";
    private static final String PASSWORD = "WM_PASSWORD";

    private static final String LOGIN_PAGE = "login";
    private static final String LOGIN_SUCCESS = "index";

    public String intercept(ActionInvocation invocation) throws Exception {
        Map<String, Object> session = invocation.getInvocationContext().getSession();
        Object action = invocation.getAction();

        // Is there a "user" object stored in the user's HttpSession?
        User user = (User) session.get(USER);
        if (user == null) {
            Map<String, Object> request = invocation.getInvocationContext().getParameters();
            String loginAttempt = getParameter(request, LOGIN_ATTEMPT);
            // The user is *not* submitting login credentials.
            if (StringUtils.isBlank(loginAttempt)) {
                return LOGIN_PAGE;
            }
            // The user submitted credentials are not correct
            if ((user = processLoginAttempt(request, session)) == null) {
                if (action instanceof ValidationAware) {
                    ValidatorContext validatorContext = new DelegatingValidatorContext(action);
                    ((ValidationAware) action).addActionError(validatorContext.getText("user.invalidlogin"));
                }
                return LOGIN_PAGE;
            } else {
                return LOGIN_SUCCESS;
            }
        }
        // if we get here, it means that the user is logged in
        if (action instanceof IUserAware) {
            ((IUserAware) action).setUser(user);
        }
        return invocation.invoke();
    }

    private String getParameter(Map<String, Object> request, String name) {
        Object value = request.get(name);
        if (value instanceof String[] && ((String[]) value).length > 0) {
            return ((String[]) value)[0];
        } else if (value != null) {
            return value.toString();
        } else {
            return null;
        }
    }

    /**
     * Attempt to process the user's login attempt delegating the work to the
     * SecurityManager.
     */
    private User processLoginAttempt(Map<String, Object> request, Map<String, Object> session) {
        String username = getParameter(request, USERNAME);
        String password = getParameter(request, PASSWORD);

        try {
            ISecurityService service = (ISecurityService) AppContextProvider.appContext.getBean("securityService");
            User user = service.authenticate(username, password);
            if (user != null) {
                session.put(USER, user);
                return user;
            }
        } catch (Exception e) {
            e.printStackTrace();

        }

        return null;
    }

}
