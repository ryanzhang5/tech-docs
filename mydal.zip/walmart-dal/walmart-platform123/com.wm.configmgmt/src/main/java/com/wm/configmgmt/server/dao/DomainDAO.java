/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.Domain;
import com.wm.configmgmt.server.dataobject.VersionedKey;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * DomainDAO
 *
 * @author mkishore
 * @since 1.0
 */
public class DomainDAO extends SoftDeleteDAO<Domain, VersionedKey> implements IDomainDAO {
    @PersistenceContext (name = "configmgmt")
    public void setEntityManager(EntityManager entityManager) {
        super.setEntityManager(entityManager);
    }
}
