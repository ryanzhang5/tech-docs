/*
 * Copyright 2010 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.client.tools.overrides;

import java.io.*;
import java.util.Properties;

/**
 * OverridesManager
 *
 * @author cshah
 * @since 1.0
 */
public class OverridesManager {
    private static final String APP_HOME = "com.wm.app.home";
    private static final String DEFAULT_LOCATION = "etc";
    private static final String FILE_NAME = ".overrides.config";

    public Properties getProperties() {
        Properties properties = new Properties();
        String data = readFile();
        if (data == null) data = "";
        try {
            properties.load(new StringReader(data));
        } catch (IOException e) {
            throw new RuntimeException("Error loading the overrides", e);
        }
        return properties;
    }

    public String getProperty(String propertyName) {
        return getProperties().getProperty(propertyName);
    }

    public void setProperty(String propertyName, String propertyValue) {
        Properties properties = getProperties();
        properties.setProperty(propertyName, propertyValue);
        StringWriter writer = new StringWriter();
        try {
            properties.store(writer, null);
        } catch (IOException e) {
            throw new RuntimeException("Error serializing the overrides", e);
        }
        writeFile(writer.toString());
    }

    public String removeProperty(String propertyName) {
        Properties properties = getProperties();
        String propertyValue = (String) properties.remove(propertyName);
        StringWriter writer = new StringWriter();
        try {
            properties.store(writer, null);
        } catch (IOException e) {
            throw new RuntimeException("Error serializing the overrides", e);
        }
        writeFile(writer.toString());
        return propertyValue;
    }

    private void writeFile(String data) {
        String fileName = getFileName();
        File file = new File(fileName);
        try {
            FileOutputStream fos = new FileOutputStream(file);
            DataOutputStream dos = new DataOutputStream(fos);
            dos.writeBytes(data);
            dos.flush();
            dos.close();
            fos.close();
        } catch (Exception e) {
            throw new RuntimeException("Error writing to file: " + file.getAbsolutePath(), e);
        }
    }

    private String readFile() {
        String data = null;
        String fileName = getFileName();
        File file = new File(fileName);
        if (file.isFile()) {
            byte[] byteArray = toByteArray(file);
            data = new String(byteArray);
        }
        return data;
    }

    private static byte[] toByteArray(File file) {
        try {
            int length = (int) file.length();
            byte[] array = new byte[length];
            InputStream in = new FileInputStream(file);
            int offset = 0;
            while (offset < length) {
                int count = in.read(array, offset, (length - offset));
                offset += count;
            }
            in.close();
            return array;
        } catch (Exception e) {
            throw new RuntimeException("Error reading from file: " + file.getAbsolutePath(), e);
        }
    }

    private String getFileName() {
        String returnFileName = FILE_NAME;
        String baseDir = System.getProperty(APP_HOME, System.getProperty("user.dir"));
        if (baseDir != null) {
            File file = new File(baseDir, FILE_NAME);
            if (file.exists()) {
                returnFileName = file.getAbsolutePath();
            } else {
                File etcDir = new File(new File(baseDir).getParentFile(), DEFAULT_LOCATION);
                file = new File(etcDir, FILE_NAME);
                if (file.exists()) {
                    returnFileName = file.getAbsolutePath();
                }
            }
        }
        return returnFileName;
    }

    private void doList() {
        try {
            StringWriter writer = new StringWriter();
            getProperties().store(writer, null);
            String data = writer.toString();
            data = data.substring(data.indexOf('\n') + 1);
            System.out.println(data);
        } catch (IOException e) {
            throw new RuntimeException("Error serializing the overrides", e);
        }
    }

    private void doGet(String propertyName) {
        String propertyValue = getProperty(propertyName);
        propertyValue = (propertyValue != null) ? propertyValue : "";
        System.out.println(propertyName + "=" + propertyValue);
    }

    private void doPut(String propertyName, String propertyValue) {
        propertyValue = (propertyValue != null) ? propertyValue : "";
        setProperty(propertyName, propertyValue);
        System.out.println(propertyName + "=" + propertyValue);
    }

    private void doRemove(String propertyName) {
        String propertyValue = removeProperty(propertyName);
        propertyValue = (propertyValue != null) ? propertyValue : "";
        System.out.println(propertyName + "=" + propertyValue);
    }

    public static void main(String[] args) {
        if (args == null || args.length == 0) {
            showUsageAndExit();
        }

        OverridesManager main = new OverridesManager();
        String command = args[0];
        if ("list".equals(command)) {
            main.doList();
        } else if ("get".equals(command)) {
            if (args.length < 2) {
                showUsageAndExit();
            }
            String propertyName = args[1];
            main.doGet(propertyName);
        } else if ("put".equals(command)) {
            if (args.length < 3) {
                showUsageAndExit();
            }
            String propertyName = args[1];
            String propertyValue = args[2];
            main.doPut(propertyName, propertyValue);
        } else if ("remove".equals(command)) {
            if (args.length < 2) {
                showUsageAndExit();
            }
            String propertyName = args[1];
            main.doRemove(propertyName);
        } else {
            showUsageAndExit();
        }
    }

    private static void showUsageAndExit() {
        System.out.println("Usage: Please enter valid argument(s):");
        System.out.println("- list");
        System.out.println("- get <Property Name>");
        System.out.println("- put <Property Name> <Property Value>");
        System.out.println("- remove <Property Name>");
        System.exit(1);
    }
}
