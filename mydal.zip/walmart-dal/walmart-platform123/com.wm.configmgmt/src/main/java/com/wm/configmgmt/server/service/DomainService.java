/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.service;

import com.wm.configmgmt.server.dao.IDomainDAO;
import com.wm.configmgmt.server.dataobject.*;
import org.springframework.transaction.annotation.Transactional;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.XMLOutputter;
import org.jdom.output.Format;

import java.sql.Timestamp;
import java.util.*;
import java.util.logging.Logger;
import java.io.FileWriter;
import java.io.StringWriter;

/**
 * DomainService
 *
 * @author mkishore
 * @since 1.0
 */
public class DomainService {
    private IDomainDAO domainDAO;
    private ConfigGroupService configGroupService;
    private ConfigService configService;
    private ConfigValueService configValueService;
    private LogicalLayerService logicalLayerService;
    private PhysicalLayerService physicalLayerService;
    private PublishRecordService publishRecordService;
    private ServerGroupService serverGroupService;
    private ServerService serverService;

    protected static final Logger logger = Logger.getLogger(DomainService.class.getName());

    @Transactional
    public List<Domain> findAll() {
        String query = "select d from Domain d";
        List<Domain> domains = domainDAO.findAllByQuery(query);
        return domains;
    }

    @Transactional
    public Domain find(long id, String releaseVersion) {
        Domain domain = domainDAO.findById(new VersionedKey(id, releaseVersion));
        return domain;
    }

    @Transactional
    public Domain findByName(String name, String releaseVersion) {
        Domain result = null;
        String query = "select d from Domain d where d.name = ?1 and d.PK.releaseVersion = ?2";
        List<Domain> domains = domainDAO.findAllByQuery(query, name, releaseVersion);
        if (domains != null && domains.size() > 0) {
            result = domains.get(0);
        }
        return result;
    }

    @Transactional
    public Domain findWithChildren(long id, String releaseVersion) {
        Domain domain = domainDAO.findById(new VersionedKey(id, releaseVersion));
        if (domain != null) {
            ServiceUtil.initialize(domain.getConfigGroups());
            ServiceUtil.initialize(domain.getConfigs());
            ServiceUtil.initialize(domain.getLogicalLayers());
            ServiceUtil.initialize(domain.getPhysicalLayers());
            ServiceUtil.initialize(domain.getPublishRecords());
            ServiceUtil.initialize(domain.getServerGroups());
            ServiceUtil.initialize(domain.getServers());
        }
        return domain;
    }

    @Transactional
    public void save(Domain domain) throws DuplicateException {
        Domain namedDO = findByName(domain.getName(), domain.getReleaseVersion());
        if (domain.getId() == null) {
            if (namedDO != null) {
                throw new DuplicateException();
            }
            domainDAO.insert(domain);
        } else {
            if (namedDO != null && !namedDO.getId().equals(domain.getId())) {
                throw new DuplicateException();
            }
            domainDAO.update(domain);
        }
    }

    @Transactional
    public void delete(long id, String releaseVersion, String user, Timestamp dtm, String CCReference) {
        Domain domain = findWithChildren(id, releaseVersion);
        if (domain != null) {
            deleteConfigGroups(domain);
            deleteConfigs(domain, user, dtm, CCReference);
            deleteLogicalLayers(domain);
            deletePhysicalLayers(domain);
            deleteServerGroups(domain);
            deleteServers(domain);
            domainDAO.delete(domain);
        }
    }

    private void deleteConfigGroups(Domain domain) {
        Set<ConfigGroup> configGroups = domain.getConfigGroups();
        if (configGroups != null && configGroups.size() > 0) {
            for (Iterator<ConfigGroup> it = configGroups.iterator(); it.hasNext();) {
                ConfigGroup configGroup = it.next();
                if (configGroup != null) {
                    configGroupService.delete(configGroup.getId(), configGroup.getReleaseVersion());
                    it.remove();
                }
            }
        }
    }

    private void deleteConfigs(Domain domain, String user, Timestamp dtm, String CCReference) {
        Set<Config> configs = domain.getConfigs();
        if (configs != null && configs.size() > 0) {
            for (Iterator<Config> it = configs.iterator(); it.hasNext();) {
                Config config = it.next();
                if (config != null) {
                    configService.delete(config.getId(), config.getReleaseVersion(), user, dtm, CCReference);
                    it.remove();
                }
            }
        }
    }

    private void deleteLogicalLayers(Domain domain) {
        Set<LogicalLayer> logicalLayers = domain.getLogicalLayers();
        if (logicalLayers != null && logicalLayers.size() > 0) {
            for (Iterator<LogicalLayer> it = logicalLayers.iterator(); it.hasNext();) {
                LogicalLayer logicalLayer = it.next();
                if (logicalLayer != null) {
                    logicalLayerService.delete(logicalLayer.getId(), logicalLayer.getReleaseVersion());
                    it.remove();
                }
            }
        }
    }

    private void deletePhysicalLayers(Domain domain) {
        Set<PhysicalLayer> physicalLayers = domain.getPhysicalLayers();
        if (physicalLayers != null && physicalLayers.size() > 0) {
            for (Iterator<PhysicalLayer> it = physicalLayers.iterator(); it.hasNext();) {
                PhysicalLayer physicalLayer = it.next();
                if (physicalLayer != null) {
                    physicalLayerService.delete(physicalLayer.getId(), physicalLayer.getReleaseVersion());
                    it.remove();
                }
            }
        }
    }

    private void deleteServerGroups(Domain domain) {
        Set<ServerGroup> serverGroups = domain.getServerGroups();
        if (serverGroups != null && serverGroups.size() > 0) {
            for (Iterator<ServerGroup> it = serverGroups.iterator(); it.hasNext();) {
                ServerGroup serverGroup = it.next();
                if (serverGroup != null) {
                    serverGroupService.delete(serverGroup.getId(), serverGroup.getReleaseVersion());
                    it.remove();
                }
            }
        }
    }

    private void deleteServers(Domain domain) {
        Set<Server> servers = domain.getServers();
        if (servers != null && servers.size() > 0) {
            for (Iterator<Server> it = servers.iterator(); it.hasNext();) {
                Server server = it.next();
                if (server != null) {
                    serverService.delete(server.getId(), server.getReleaseVersion());
                    it.remove();
                }
            }
        }
    }

    private Map<Long, ConfigGroup> upgradeConfigGroups(Domain oldDomain, Domain newDomain) throws DuplicateException {
        Map<Long, ConfigGroup> map = new HashMap<Long, ConfigGroup>();
        Set<ConfigGroup> oldConfigGroups = oldDomain.getConfigGroups();
        if (oldConfigGroups != null && oldConfigGroups.size() > 0) {
            for (ConfigGroup oldDO : oldConfigGroups) {
                if (oldDO != null) {
                    ConfigGroup newDO = new ConfigGroup();
                    newDO.setDomain(newDomain);
                    newDO.setReleaseVersion(newDomain.getReleaseVersion());
                    newDO.setName(oldDO.getName());
                    newDO.setDescription(oldDO.getDescription());
                    newDO.setOwnerTeam(oldDO.getOwnerTeam());
                    newDO.setCreatedBy(oldDO.getCreatedBy());
                    newDO.setCreatedDTM(oldDO.getCreatedDTM());
                    newDO.setModifiedBy(oldDO.getModifiedBy());
                    newDO.setModifiedDTM(oldDO.getModifiedDTM());
                    configGroupService.save(newDO);
                    map.put(oldDO.getId(), newDO);
                }
            }
        }
        return map;
    }

    private Map<Long, Config> upgradeConfigs(Domain oldDomain, Domain newDomain, Map<Long, ConfigGroup> mapCG) throws DuplicateException {
        Map<Long, Config> map = new HashMap<Long, Config>();
        Set<Config> oldConfigs = oldDomain.getConfigs();
        if (oldConfigs != null && oldConfigs.size() > 0) {
            for (Config oldDO : oldConfigs) {
                if (oldDO != null) {
                    Config newDO = new Config();
                    newDO.setDomain(newDomain);
                    newDO.setReleaseVersion(newDomain.getReleaseVersion());
                    newDO.setName(oldDO.getName());
                    newDO.setDescription(oldDO.getDescription());
                    newDO.setCreatedBy(oldDO.getCreatedBy());
                    newDO.setCreatedDTM(oldDO.getCreatedDTM());
                    newDO.setModifiedBy(oldDO.getModifiedBy());
                    newDO.setModifiedDTM(oldDO.getModifiedDTM());
                    newDO.setConfigGroup(mapCG.get(oldDO.getConfigGroupId()));
                    configService.save(newDO);
                    map.put(oldDO.getId(), newDO);
                }
            }
        }
        return map;
    }

    private Map<Long, PhysicalLayer> upgradePhysicalLayers(Domain oldDomain, Domain newDomain) throws DuplicateException {
        Map<Long, PhysicalLayer> map = new HashMap<Long, PhysicalLayer>();
        List<PhysicalLayer> oldPhysicalLayers = physicalLayerService.findRootLayersWithChildren(oldDomain.getId(), oldDomain.getReleaseVersion());
        doUpgradePhysicalLayers(newDomain, oldPhysicalLayers, null, map);
        return map;
    }

    private void doUpgradePhysicalLayers(Domain newDomain, Collection<PhysicalLayer> oldPhysicalLayers,
             PhysicalLayer newParentLayer, Map<Long, PhysicalLayer> map) throws DuplicateException {
        if (oldPhysicalLayers != null && oldPhysicalLayers.size() > 0) {
            for (PhysicalLayer oldDO : oldPhysicalLayers) {
                if (oldDO != null) {
                    PhysicalLayer newDO = new PhysicalLayer();
                    newDO.setDomain(newDomain);
                    newDO.setReleaseVersion(newDomain.getReleaseVersion());
                    newDO.setName(oldDO.getName());
                    newDO.setDescription(oldDO.getDescription());
                    newDO.setCreatedBy(oldDO.getCreatedBy());
                    newDO.setCreatedDTM(oldDO.getCreatedDTM());
                    newDO.setModifiedBy(oldDO.getModifiedBy());
                    newDO.setModifiedDTM(oldDO.getModifiedDTM());
                    newDO.setParentLayer(newParentLayer);
                    physicalLayerService.save(newDO);
                    map.put(oldDO.getId(), newDO);
                    doUpgradePhysicalLayers(newDomain, oldDO.getChildLayers(), newDO, map);
                }
            }
        }
    }

    private Map<Long, LogicalLayer> upgradeLogicalLayers(Domain oldDomain, Domain newDomain) throws DuplicateException {
        Map<Long, LogicalLayer> map = new HashMap<Long, LogicalLayer>();
        List<LogicalLayer> oldLogicalLayers = logicalLayerService.findRootLayersWithChildren(oldDomain.getId(), oldDomain.getReleaseVersion());
        doUpgradeLogicalLayers(newDomain, oldLogicalLayers, null, map);
        return map;
    }

    private void doUpgradeLogicalLayers(Domain newDomain, Collection<LogicalLayer> oldLogicalLayers,
            LogicalLayer newParentLayer, Map<Long, LogicalLayer> map) throws DuplicateException {
        if (oldLogicalLayers != null && oldLogicalLayers.size() > 0) {
            for (LogicalLayer oldDO : oldLogicalLayers) {
                if (oldDO != null) {
                    LogicalLayer newDO = new LogicalLayer();
                    newDO.setDomain(newDomain);
                    newDO.setReleaseVersion(newDomain.getReleaseVersion());
                    newDO.setName(oldDO.getName());
                    newDO.setDescription(oldDO.getDescription());
                    newDO.setCreatedBy(oldDO.getCreatedBy());
                    newDO.setCreatedDTM(oldDO.getCreatedDTM());
                    newDO.setModifiedBy(oldDO.getModifiedBy());
                    newDO.setModifiedDTM(oldDO.getModifiedDTM());
                    newDO.setParentLayer(newParentLayer);
                    logicalLayerService.save(newDO);
                    map.put(oldDO.getId(), newDO);
                    doUpgradeLogicalLayers(newDomain, oldDO.getChildLayers(), newDO, map);
                }
            }
        }
    }

    private Map<Long, Server> upgradeServers(Domain oldDomain, Domain newDomain, Map<Long, PhysicalLayer> mapPL) throws DuplicateException {
        Map<Long, Server> map = new HashMap<Long, Server>();
        Set<Server> oldServers = oldDomain.getServers();
        if (oldServers != null && oldServers.size() > 0) {
            for (Server oldDO : oldServers) {
                if (oldDO != null) {
                    Server newDO = new Server();
                    newDO.setDomain(newDomain);
                    newDO.setReleaseVersion(newDomain.getReleaseVersion());
                    newDO.setName(oldDO.getName());
                    newDO.setDescription(oldDO.getDescription());
                    newDO.setCreatedBy(oldDO.getCreatedBy());
                    newDO.setCreatedDTM(oldDO.getCreatedDTM());
                    newDO.setModifiedBy(oldDO.getModifiedBy());
                    newDO.setModifiedDTM(oldDO.getModifiedDTM());
                    newDO.setPhysicalLayer(mapPL.get(oldDO.getPhysicalLayerId()));
                    serverService.save(newDO);
                    map.put(oldDO.getId(), newDO);
                }
            }
        }
        return map;
    }

    private Map<Long, ServerGroup> upgradeServerGroups(Domain oldDomain, Domain newDomain, Map<Long, Server> mapS) throws DuplicateException {
        Map<Long, ServerGroup> map = new HashMap<Long, ServerGroup>();
        Set<ServerGroup> serverGroups = oldDomain.getServerGroups();
        if (serverGroups != null && serverGroups.size() > 0) {
            for (ServerGroup oldDO : serverGroups) {
                if (oldDO != null) {
                    ServerGroup newDO = new ServerGroup();
                    newDO.setDomain(newDomain);
                    newDO.setReleaseVersion(newDomain.getReleaseVersion());
                    newDO.setName(oldDO.getName());
                    newDO.setDescription(oldDO.getDescription());
                    newDO.setCreatedBy(oldDO.getCreatedBy());
                    newDO.setCreatedDTM(oldDO.getCreatedDTM());
                    newDO.setModifiedBy(oldDO.getModifiedBy());
                    newDO.setModifiedDTM(oldDO.getModifiedDTM());
                    serverGroupService.save(newDO);
                    map.put(oldDO.getId(), newDO);
                }
            }
            for (ServerGroup oldDO : serverGroups) {
                if (oldDO != null) {
                    ServerGroup newDO = map.get(oldDO.getId());
                    //oldDO = serverGroupService.findWithChildren(oldDO.getId(), oldDO.getReleaseVersion());
                    //newDO = serverGroupService.findWithChildren(newDO.getId(), newDO.getReleaseVersion());
                    Set<Long> newChildGroupIds = new HashSet<Long>();
                    Set<Long> newChildServerIds = new HashSet<Long>();

                    Set<ServerGroupGroup> oldChildGroups = oldDO.getChildGroups();
                    if (oldChildGroups != null && oldChildGroups.size() > 0) {
                        for (ServerGroupGroup oldChildGroup : oldChildGroups) {
                            if (oldChildGroup != null) {
                                ServerGroup newChildGroup = map.get(oldChildGroup.getChildGroupId());
                                newChildGroupIds.add(newChildGroup.getId());
                            }
                        }
                    }
                    Set<ServerGroupServer> oldChildServers = oldDO.getServers();
                    if (oldChildServers != null && oldChildServers.size() > 0) {
                        for (ServerGroupServer oldChildServer : oldChildServers) {
                            if (oldChildServer != null) {
                                Server newChildServer = mapS.get(oldChildServer.getServerId());
                                if (newChildServer != null) {
                                    newChildServerIds.add(newChildServer.getId());
                                }
                            }
                        }
                    }
                    serverGroupService.saveWithChildren(newDO, newChildGroupIds, newChildServerIds);
                }
            }
        }
        return map;
    }

    private void upgradeConfigValues(Domain oldDomain, Domain newDomain,
             Map<Long, Config> mapC, Map<Long, LogicalLayer> mapLL, Map<Long, PhysicalLayer> mapPL, Map<Long, Server> mapS) {
        Set<Config> oldConfigs = oldDomain.getConfigs();
        if (oldConfigs != null && oldConfigs.size() > 0) {
            for (Config oldConfig : oldConfigs) {
                if (oldConfig != null) {
                    Set<ConfigValue> oldConfigValues = oldConfig.getConfigValues();
                    if (oldConfigValues != null && oldConfigValues.size() > 0) {
                        for (ConfigValue oldDO : oldConfigValues) {
                            if (oldDO != null) {
                                ConfigValue newDO = new ConfigValue();
                                newDO.setConfig(mapC.get(oldDO.getConfigId()));
                                newDO.setReleaseVersion(newDomain.getReleaseVersion());
                                newDO.setValue(oldDO.getValue());
                                newDO.setCreatedBy(oldDO.getCreatedBy());
                                newDO.setCreatedDTM(oldDO.getCreatedDTM());
                                newDO.setCCReference(oldDO.getCCReference());
                                newDO.setPhysicalLayer(mapPL.get(oldDO.getPhysicalLayerId()));
                                newDO.setLogicalLayer(mapLL.get(oldDO.getLogicalLayerId()));
                                newDO.setServer(mapS.get(oldDO.getServerId()));
                                configValueService.save(newDO);
                            }
                        }
                    }
                }
            }
        }
    }

    @Transactional
    public Domain upgrade(long domainId, String releaseVersion, String newReleaseVersion, String username) throws DuplicateException {
        Timestamp now = new Timestamp(System.currentTimeMillis());
        Domain oldDO = findWithChildren(domainId, releaseVersion);
        if (oldDO == null) {
            return null;
        }

        Domain newDO = new Domain();
        newDO.setName(oldDO.getName());
        newDO.setReleaseVersion(newReleaseVersion);
        newDO.setDescription(oldDO.getDescription());
        newDO.setCreatedBy(username);
        newDO.setCreatedDTM(now);
        this.save(newDO);

        Map<Long, ConfigGroup> mapCG = this.upgradeConfigGroups(oldDO, newDO);
        Map<Long, Config> mapC = this.upgradeConfigs(oldDO, newDO, mapCG);
        Map<Long, PhysicalLayer> mapPL = this.upgradePhysicalLayers(oldDO, newDO);
        Map<Long, LogicalLayer> mapLL = this.upgradeLogicalLayers(oldDO, newDO);
        Map<Long, Server> mapS = this.upgradeServers(oldDO, newDO, mapPL);
        Map<Long, ServerGroup> mapSG = this.upgradeServerGroups(oldDO, newDO, mapS);
        this.upgradeConfigValues(oldDO, newDO, mapC, mapLL, mapPL, mapS);

        return newDO;
    }

    private static final List<String> SKIP_LOGICAL_LAYERS = Arrays.asList(new String[] {
            "REG2", "WU", "ZDR"
    });
    @Transactional
    public String export(long domainId, String releaseVersion) {
        Domain domain = findWithChildren(domainId, releaseVersion);
        if (domain == null) {
            return null;
        }

        StringWriter writer = new StringWriter();
        try {
            List<ConfigValue> configValues = configValueService.findCurrentConfigValues(domainId, releaseVersion);
            Map<Long, List<ConfigValue>> configValuesForConfig = new HashMap<Long, List<ConfigValue>>();
            for (ConfigValue value : configValues) {
                List<ConfigValue> list = configValuesForConfig.get(value.getConfigId());
                if (list == null) {
                    list = new ArrayList<ConfigValue>();
                    configValuesForConfig.put(value.getConfigId(), list);
                }
                list.add(value);
            }

            Document doc = new Document();
            Element root = new Element("configure").setAttribute("version", "1.0");
            doc.setRootElement(root);
            Element keys = new Element("keys");
            root.addContent(keys);
            Map<String, Element> keygroupMap = new TreeMap<String, Element>();
            for (ConfigGroup group : domain.getConfigGroups()) {
                Element keygroup = new Element("keygroup").setAttribute("name", group.getName());
                keygroupMap.put(group.getName(), keygroup);
                Map<String, Element> keyMap = new TreeMap<String, Element>();
                for (Config config : group.getConfigs()) {
                    Element key = new Element("key").setAttribute("name", config.getName());
                    keyMap.put(config.getName(), key);
                    List<Element> rule1List = new ArrayList<Element>();
                    Map<String, Element> rule2Map = new TreeMap<String, Element>();
                    List<ConfigValue> list = configValuesForConfig.get(config.getId());
                    if (list == null) continue;
                    for (ConfigValue value : list) {
                        String valueStr = value.getValue() != null ?value.getValue() :"";
                        if (value.getLogicalLayerId() == null && value.getPhysicalLayerId() == null && value.getServerId() == null) {
                            key.setAttribute("default", valueStr);
                            break;
                        } else {
                            Element rule1 = null, rule2 = null;
                            if (value.getLogicalLayer() != null) {
                                if (SKIP_LOGICAL_LAYERS.contains(value.getLogicalLayer().getName())) continue;
                                rule1 = new Element("rule")
                                        .setAttribute("type", "exact")
                                        .setAttribute("var", "APP")
                                        .setAttribute("val", value.getLogicalLayer().getName());
                            }
                            if (value.getPhysicalLayer() != null) {
                                // keep PROD, skip everything under it
                                PhysicalLayer layer = value.getPhysicalLayer();
                                while (layer != null) {
                                    layer = layer.getParentLayer();
                                    if (layer != null && layer.getName().equals("PROD")) break;
                                }
                                if (layer != null) continue;
                                rule2 = new Element("rule")
                                        .setAttribute("type", "exact")
                                        .setAttribute("var", "ENV")
                                        .setAttribute("val", value.getPhysicalLayer().getName());
                            } else if (value.getServer() != null) {
                                rule2 = new Element("rule")
                                        .setAttribute("type", "exact")
                                        .setAttribute("var", "HOSTNAME")
                                        .setAttribute("val", value.getServer().getName());
                            }
                            Element keyval = new Element("keyval").setAttribute("val", valueStr);
                            if (rule2 != null) {
                                rule2.addContent(keyval);
                            }
                            if (rule1 != null) {
                                rule1.addContent( (rule2 != null) ?rule2 :keyval);
                                rule1List.add(rule1);
                            } else {
                                rule2Map.put(rule2.getAttributeValue("val"), rule2);
                            }
                        }
                    }
                    for (Element rule : rule2Map.values()) {
                        key.addContent(rule);
                    }
                    for (Element rule : rule1List) {
                        key.addContent(rule);
                    }
                    if (config.getDescription() != null && !config.getDescription().equals("")) {
                        key.setAttribute("prompt", config.getDescription());
                    }
                }
                for (Element key : keyMap.values()) keygroup.addContent(key);
            }
            for (Element keygroup : keygroupMap.values()) keys.addContent(keygroup);

            new XMLOutputter(Format.getPrettyFormat()).output(doc, writer);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return writer.toString();
    }

    public void setDomainDAO(IDomainDAO domainDAO) {
        this.domainDAO = domainDAO;
    }

    public void setConfigGroupService(ConfigGroupService configGroupService) {
        this.configGroupService = configGroupService;
    }

    public void setConfigService(ConfigService configService) {
        this.configService = configService;
    }

    public void setConfigValueService(ConfigValueService configValueService) {
        this.configValueService = configValueService;
    }

    public void setLogicalLayerService(LogicalLayerService logicalLayerService) {
        this.logicalLayerService = logicalLayerService;
    }

    public void setPhysicalLayerService(PhysicalLayerService physicalLayerService) {
        this.physicalLayerService = physicalLayerService;
    }

    public void setPublishRecordService(PublishRecordService publishRecordService) {
        this.publishRecordService = publishRecordService;
    }

    public void setServerGroupService(ServerGroupService serverGroupService) {
        this.serverGroupService = serverGroupService;
    }

    public void setServerService(ServerService serverService) {
        this.serverService = serverService;
    }

}
