/*
 * Copyright 2010 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.common.jms;

import com.wm.weblib.jms.WMMessageAdmin;
import com.wm.weblib.jms.WMMessageException;
import com.wm.weblib.jms.WMMessageType;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;

/**
 * WMConfigChangeNotificationMessage - sent from the management server to the managed nodes.
 *
 * @author mkishore
 * @since 1.0
 */
public class WMMessageConfigChangeNotification extends WMMessageAdmin {
    public static class Payload implements Serializable {
        private Long publishRecordId;
        private String releaseVersion;
        private String logicalLayer;
        private Collection<String> serverNames;
        private String publishMessage;

        public Long getPublishRecordId() {
            return publishRecordId;
        }

        public void setPublishRecordId(Long publishRecordId) {
            this.publishRecordId = publishRecordId;
        }

        public String getReleaseVersion() {
            return releaseVersion;
        }

        public void setReleaseVersion(String releaseVersion) {
            this.releaseVersion = releaseVersion;
        }

        public String getLogicalLayer() {
            return logicalLayer;
        }

        public void setLogicalLayer(String logicalLayer) {
            this.logicalLayer = logicalLayer;
        }

        public Collection<String> getServerNames() {
            return serverNames;
        }

        public void setServerNames(Collection<String> serverNames) {
            this.serverNames = serverNames;
        }

        public String getPublishMessage() {
            return publishMessage;
        }

        public void setPublishMessage(String publishMessage) {
            this.publishMessage = publishMessage;
        }

        @Override
        public String toString() {
            StringBuilder s = new StringBuilder();
            s.append("{ publishRecordId: ").append(this.getPublishRecordId());
            s.append(", releaseVersion: ").append(this.getReleaseVersion());
            s.append(", logicalLayer: ").append(this.getLogicalLayer());
            Collection<String> serverNames = this.getServerNames();
            String str = (serverNames != null) ?serverNames.toString() :"[]";
            if (str.length() > 100) {
                str = str.substring(0, 100) + "...]";
            }
            s.append(", serverNames: ").append(str);
            s.append(", publishMessage: ").append(this.getPublishMessage());
            s.append(" }");
            return s.toString();
        }
    }

    public WMMessageConfigChangeNotification(HashMap valueMap) throws WMMessageException {
        super(WMMessageType.MSG_TYPE_CONFIG_MGMT_NOTIFICATION, valueMap);
    }

    @Override
    public void setObjectMessage(Serializable objmsg) {
        if (objmsg == null || objmsg instanceof Payload) {
            super.setObjectMessage(objmsg);
        } else {
            throw new IllegalArgumentException("This class expects a Payload argument, found: " + objmsg.getClass());
        }
    }

    public Payload getPayload() {
        return (Payload) super.getObjectMessage();
    }
}
