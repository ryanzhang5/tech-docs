/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.IBaseDO;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Base class for all DAO classes
 *
 * @author mkishore
 * @version $Revision: 1.3 $
 * @since 4/2009
 */
public abstract class BaseDAO<T extends IBaseDO, ID extends Serializable> implements IBaseDAO<T, ID> {
    protected EntityManager entityManager;
    protected Class<T> entityClass;

    /**
     * Make the entity instances managed and persistent.
     *
     * @param entities - the list of entities to be persisted
     * @see javax.persistence.EntityManager#persist
     */
    public void insert(T... entities) {
        for (T entity : entities) {
            getEntityManager().persist(entity);
        }
    }

    /**
     * Merge the state of the given entity into the current persistence context.
     *
     * @param entity - the detached object that needs to be merged in
     * @return the instance that the state was merged to
     * @see javax.persistence.EntityManager#merge
     */
    public T update(T entity) {
        return getEntityManager().merge(entity);
    }

    /**
     * Merge the state of the given entities into the current persistence context.
     *
     * @param entities - the list of detached objects that needs to be merged in
     * @return the list of instances that the state was merged to
     * @see javax.persistence.EntityManager#merge
     */
    public List<T> update(List<T> entities) {
        List<T> ret = new ArrayList<T>();
        for (T entity : entities) {
            ret.add(update(entity));
        }
        return ret;
    }

    /**
     * Remove the entity instances.
     *
     * @param entities - the list of entities to be removed
     * @see javax.persistence.EntityManager#remove
     */
    public void delete(T... entities) {
        for (T entity : entities) {
            getEntityManager().remove(entity);
        }
    }

    /**
     * Refresh the state of the instances from the database, overwriting changes made to the entities, if any.
     *
     * @param entities - the list of entities to be refreshed
     * @see javax.persistence.EntityManager#refresh
     */
    public void refresh(T... entities) {
        for (T entity : entities) {
            getEntityManager().refresh(entity);
        }
    }

    /**
     * Check if the instance belongs to the current persistence context.
     *
     * @param entity - the entity to check for
     * @return true if the instance belongs to the current persistence context.
     * @see javax.persistence.EntityManager#contains
     */
    public boolean contains(T entity) {
        return getEntityManager().contains(entity);
    }

    /**
     * Get an instance, whose state may be lazily fetched.
     *
     * @param id - id of the entity to be fetched
     * @return the found entity instance.
     * @see javax.persistence.EntityManager#getReference
     */
    public T getReference(ID id) {
        return getEntityManager().getReference(getEntityClass(), id);
    }

    /**
     * Find by primary key.
     *
     * @param id - primary key
     * @return the found entity instance or null if the entity does not exist.
     * @see javax.persistence.EntityManager#find
     */
    public T findById(ID id) {
        return getEntityManager().find(getEntityClass(), id);
    }

    /**
     * Find a list of entities by their primary keys.
     *
     * @param ids - list of primary keys
     * @return the List of found entity instances or null if the entity does not exist.
     * @see javax.persistence.EntityManager#find
     */
    public List<T> findById(List<ID> ids) {
        List<T> ret = new ArrayList<T>();
        for (ID id : ids) {
            ret.add(findById(id));
        }
        return ret;
    }

    /**
     * Finds all entities based on the Java Persistence query language statement.
     *
     * @param queryString - a Java Persistence query language query string
     * @param params      - list of positional parameter values
     * @return a List of entities
     */
    public List<T> findAllByQuery(String queryString, Object... params) {
        return findByQuery(queryString, params, 0, getMaxResults());
    }

    /**
     * Finds a subset of entities based on the Java Persistence query language statement.
     *
     * @param queryString - a Java Persistence query language query string
     * @param params      - list of positional parameter values
     * @param startIndex  - position of the first result to retrieve
     * @param maxResults  - maximum number of results to retrieve
     * @return a sub-List of entities
     */
    public List<T> findByQuery(String queryString, Object[] params, int startIndex, int maxResults) {
        Query query = getEntityManager().createQuery(queryString);
        return executeQuery(query, params, startIndex, maxResults);
    }

    /**
     * Finds all entities based on the Java Persistence query language statement.
     *
     * @param queryString - a Java Persistence query language query string
     * @param params      - map of named parameter values
     * @return a List of entities
     */
    public List<T> findAllByQueryAndNamedParams(String queryString, Map<String, ?> params) {
        return findByQueryAndNamedParams(queryString, params, 0, getMaxResults());
    }

    /**
     * Finds all entities based on the Java Persistence query language statement.
     *
     * @param queryString - a Java Persistence query language query string
     * @param params      - map of named parameter values
     * @param startIndex  - position of the first result to retrieve
     * @param maxResults  - maximum number of results to retrieve
     * @return a sub-List of entities
     */
    public List<T> findByQueryAndNamedParams(String queryString, Map<String, ?> params, int startIndex, int maxResults) {
        Query query = getEntityManager().createQuery(queryString);
        return executeQuery(query, params, startIndex, maxResults);
    }

    /**
     * Finds all entities based on the named query (in the Java Persistence query language or in native SQL).
     *
     * @param queryName - a named query (in the Java Persistence query language or in native SQL).
     * @param params    - list of positional parameter values
     * @return a List of entities
     */
    public List<T> findAllByNamedQuery(String queryName, Object... params) {
        return findByNamedQuery(queryName, params, 0, getMaxResults());
    }

    /**
     * Finds all entities based on the named query (in the Java Persistence query language or in native SQL).
     *
     * @param queryName  - a named query (in the Java Persistence query language or in native SQL).
     * @param params     - list of positional parameter values
     * @param startIndex - position of the first result to retrieve
     * @param maxResults - maximum number of results to retrieve
     * @return a sub-List of entities
     */
    public List<T> findByNamedQuery(String queryName, Object[] params, int startIndex, int maxResults) {
        Query query = getEntityManager().createNamedQuery(queryName);
        return executeQuery(query, params, startIndex, maxResults);
    }

    /**
     * Finds all entities based on the named query (in the Java Persistence query language or in native SQL).
     *
     * @param queryName - a named query (in the Java Persistence query language or in native SQL)
     * @param params    - map of named parameter values
     * @return a List of entities
     */
    public List<T> findAllByNamedQueryAndNamedParams(String queryName, Map<String, ?> params) {
        return findByNamedQueryAndNamedParams(queryName, params, 0, getMaxResults());
    }

    /**
     * Finds all entities based on the named query (in the Java Persistence query language or in native SQL).
     *
     * @param queryName  - a named query (in the Java Persistence query language or in native SQL)
     * @param params     - map of named parameter values
     * @param startIndex - position of the first result to retrieve
     * @param maxResults - maximum number of results to retrieve
     * @return a sub-List of entities
     */
    public List<T> findByNamedQueryAndNamedParams(String queryName, Map<String, ?> params, int startIndex, int maxResults) {
        Query query = getEntityManager().createNamedQuery(queryName);
        return executeQuery(query, params, startIndex, maxResults);
    }


    // GETTERS AND SETTERS

    public EntityManager getEntityManager() {
        return entityManager;
    }

    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    /**
     * Helper method to get at the data-object class this DAO services.
     *
     * @return the Class of entity this DAO services
     */
    protected Class<T> getEntityClass() {
        if (entityClass == null) {
            Class clazz = this.getClass();
            while (clazz != null) {
                Type type = clazz.getGenericSuperclass();
                if (type instanceof ParameterizedType) {
                    Type[] args = ((ParameterizedType) type).getActualTypeArguments();
                    if (args != null && args[0] instanceof Class) {
                        Class arg = (Class) args[0];
                        if (IBaseDO.class.isAssignableFrom(arg)) {
                            entityClass = arg;
                            break;
                        }
                    }
                }
                clazz = clazz.getSuperclass();
            }
        }
        return entityClass;
    }


    // PRIVATE METHODS

    // TODO: get the maxresults from some configuration
    private int getMaxResults() {
        return -1;
    }

    private List<T> executeQuery(Query query, Object[] params, int startIndex, int maxResults) {
        query.setFirstResult(startIndex);
        if (maxResults != -1) query.setMaxResults(maxResults);
        for (int i=1; i <= params.length; i++) {
            query.setParameter(i, params[i-1]);
        }
        return (List<T>) query.getResultList();
    }

    private List<T> executeQuery(Query query, Map<String, ?> params, int startIndex, int maxResults) {
        query.setFirstResult(startIndex);
        if (maxResults != -1) query.setMaxResults(maxResults);
        for (Map.Entry<String, ?> param : params.entrySet()) {
            query.setParameter(param.getKey(), param.getValue());
        }
        return query.getResultList();
    }


}