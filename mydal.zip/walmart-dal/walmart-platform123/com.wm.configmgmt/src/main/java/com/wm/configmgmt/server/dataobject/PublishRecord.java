/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dataobject;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

/**
 * Keeps track of every publish attempt by the Siteops.
 * We don't really need to scope this under the domain, but is done so to ease the purge logic.
 *
 * @author mkishore
 * @since 1.0
 */
public class PublishRecord extends BaseDO implements IVersionedDO, Cloneable {
    private VersionedKey PK = new VersionedKey();
    private Domain domain;
    private LogicalLayer logicalLayer;
    private String CCReference;
    private String publishMessage;
    private String createdBy;
    private Timestamp createdDTM;

    private Long logicalLayerId;

    private Set<PublishServerRecord> serverRecords = new HashSet<PublishServerRecord>();

    public VersionedKey getPK() {
        return PK;
    }

    public void setPK(VersionedKey PK) {
        this.PK = PK;
    }

    public Long getId() {
        return PK.getId();
    }

    public void setId(Long id) {
        PK.setId(id);
    }

    public String getReleaseVersion() {
        return PK.getReleaseVersion();
    }

    public void setReleaseVersion(String releaseVersion) {
        PK.setReleaseVersion(releaseVersion);
    }

    public Long getDomainId() {
        return (domain != null) ? domain.getId() : null;
    }

    public void setDomainId(Long id) {
        
    }
    
    public Domain getDomain() {
        return domain;
    }

    public void setDomain(Domain domain) {
        this.domain = domain;
    }

    public Long getLogicalLayerId() {
        return (logicalLayerId != null) ? logicalLayerId : (logicalLayer != null) ?logicalLayer.getId() :null;
    }

    public void setLogicalLayerId(Long id) {
        this.logicalLayerId = id;
    }
    
    public LogicalLayer getLogicalLayer() {
        return logicalLayer;
    }

    public void setLogicalLayer(LogicalLayer logicalLayer) {
        this.logicalLayer = logicalLayer;
    }

    public String getCCReference() {
        return CCReference;
    }

    public void setCCReference(String CCReference) {
        this.CCReference = CCReference;
    }

    public String getPublishMessage() {
        return publishMessage;
    }

    public void setPublishMessage(String publishMessage) {
        this.publishMessage = publishMessage;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDTM() {
        return createdDTM;
    }

    public void setCreatedDTM(Timestamp createdDTM) {
        this.createdDTM = createdDTM;
    }

    public Set<PublishServerRecord> getServerRecords() {
        return serverRecords;
    }

    public void setServerRecords(Set<PublishServerRecord> serverRecords) {
        this.serverRecords = serverRecords;
    }
    
    public Object clone() throws CloneNotSupportedException {
    	return super.clone();
    }
}