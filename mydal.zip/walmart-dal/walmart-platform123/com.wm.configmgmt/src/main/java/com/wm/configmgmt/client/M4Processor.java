/*
 * Copyright 2010 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.client;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

/**
 * M4Processor
 *
 * @author mkishore
 * @since 1.0
 */
public class M4Processor {
    public static String process(String input, Properties macros) {
        StringBuilder output = new StringBuilder();
        StringBuilder token = new StringBuilder();
        boolean IN_TOKEN = false;
        char[] chars = input.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            char c = chars[i];
            if (IN_TOKEN) {
                if (check(c)) {
                    token.append(c);
                } else if (c == '$' && i < chars.length-1 && chars[i+1] == '{') {
                    replace(token, macros, output);
                    token.append("${");
                    i++;
                } else {
                    IN_TOKEN = false;
                    boolean delimited = token.toString().startsWith("${") && c == '}';
                    if (delimited) token.append(c);
                    replace(token, macros, output);
                    if (!delimited) output.append(c);
                }
            } else {
                if (check(c)) {
                    IN_TOKEN = true;
                    token.append(c);
                } else if (c == '$' && i < chars.length-1 && chars[i+1] == '{') {
                    IN_TOKEN = true;
                    token.append("${");
                    i++;
                } else {
                    output.append(c);
                }
            }
        }
        replace(token, macros, output);
        return output.toString();
    }

    private static void replace(StringBuilder token, Properties macros, StringBuilder output) {
        String tokenString = token.toString();
        boolean delimited = tokenString.startsWith("${") && tokenString.endsWith("}");
        String key = (delimited) ?tokenString.substring(2, tokenString.length()-1) :tokenString;
        String value = macros.getProperty(key);
        output.append( (value != null) ?value :tokenString);
        token.setLength(0);
    }

    private static boolean check(char c) {
        return (c >= 'a' && c <= 'z')
                || (c >= 'A' && c <= 'Z')
                || (c >= '0' && c <= '9')
                || c == '_';
    }

    public static void main(String[] args) throws IOException {
        StringBuilder input = new StringBuilder();
        BufferedReader br = new BufferedReader(new FileReader("/home/mkishore/dal/conf/dal.conf.m4"));
        String line;
        while ((line = br.readLine()) != null) input.append(line).append("\n");
        Properties macros = new Properties();
        macros.load(new FileInputStream("/home/mkishore/dal/.snapshot.config"));
        System.out.println(process(input.toString(), macros));
    }
}
