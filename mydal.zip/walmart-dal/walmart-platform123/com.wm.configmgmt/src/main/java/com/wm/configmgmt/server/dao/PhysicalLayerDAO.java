/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.PhysicalLayer;
import com.wm.configmgmt.server.dataobject.VersionedKey;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * PhysicalLayerDAO
 *
 * @author mkishore
 * @since 1.0
 */
public class PhysicalLayerDAO extends SoftDeleteDAO<PhysicalLayer, VersionedKey> implements IPhysicalLayerDAO {
    @PersistenceContext (name = "configmgmt")
    public void setEntityManager(EntityManager entityManager) {
        super.setEntityManager(entityManager);
    }
}