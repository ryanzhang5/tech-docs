/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action;

import com.opensymphony.xwork2.ActionSupport;
import com.wm.configmgmt.server.security.User;

/**
 * AbstractUserAction
 *
 * @author mkishore
 * @since 1.0
 */
public abstract class AbstractUserAction extends ActionSupport implements IUserAware {
    protected User user;

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
