/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.ServerGroupServer;
import com.wm.configmgmt.server.dataobject.VersionedKeyMulti;

/**
 * IServerGroupServerDAO
 *
 * @author mkishore
 * @since 1.0
 */
public interface IServerGroupServerDAO extends IBaseDAO<ServerGroupServer, VersionedKeyMulti> {

}