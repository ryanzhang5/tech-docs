package com.wm.configmgmt.client;

/**
 * Copyright 2009 Walmart.com. All rights reserved.
 * User: ncherukuri
 * Date: Dec 22, 2009
 * Time: 10:41:37 AM
 */
public class ConfigObject {
    private String physicalLayer;
    private String logicalLayer;
    private String server;
    private String domain;
    private String release;

    public ConfigObject(String physicalLayer, String logicalLayer, String server, String domain, String release) {

        this.physicalLayer = physicalLayer;
        this.logicalLayer = logicalLayer;
        this.server = server;
        this.domain = domain;
        this.release = release;
    }

    public String getPhysicalLayer() {
        return physicalLayer;
    }

    public void setPhysicalLayer(String physicalLayer) {
        this.physicalLayer = physicalLayer;
    }

    public String getLogicalLayer() {
        return logicalLayer;
    }

    public void setLogicalLayer(String logicalLayer) {
        this.logicalLayer = logicalLayer;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getRelease() {
        return release;
    }

    public void setRelease(String release) {
        this.release = release;
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }


}
