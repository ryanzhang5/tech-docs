/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action.config;

import com.opensymphony.xwork2.Preparable;
import com.wm.configmgmt.server.action.AbstractDomainAction;
import com.wm.configmgmt.server.dataobject.Config;
import com.wm.configmgmt.server.dataobject.ConfigGroup;
import com.wm.configmgmt.server.dataobject.ConfigValue;
import com.wm.configmgmt.server.dataobject.NamedDOComparator;
import com.wm.configmgmt.server.service.ConfigGroupService;
import com.wm.configmgmt.server.service.ConfigService;
import com.wm.configmgmt.server.service.DuplicateException;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * ConfigAction
 *
 * @author mkishore
 * @since 1.0
 */
public class ConfigAction extends AbstractDomainAction implements Preparable {
    private ConfigService configService;
    private ConfigGroupService configGroupService;

    private Config config = new Config();
    private List<ConfigGroup> configGroups = new ArrayList<ConfigGroup>();
    private String configGroupName;
    private String value;

    public void prepare() throws Exception {
        configGroups = configGroupService.findAll(domain.getId(), domain.getReleaseVersion());
        Collections.sort(configGroups, new NamedDOComparator());
    }

    public String add() {
        return SUCCESS;
    }

    public String edit() {
        config = configService.find(config.getId(), config.getReleaseVersion());
        ConfigGroup configGroup = config.getConfigGroup();
        configGroupName = (configGroup != null) ? configGroup.getName() : null;
        ConfigValue defaultValue = configService.findDefaultValue(config.getId(), config.getReleaseVersion());
        value = (defaultValue != null) ?defaultValue.getValue() :null;
        return SUCCESS;
    }

    public String save() {
        Timestamp now = new Timestamp(System.currentTimeMillis());
        if (!isNew()) {
            Config input = config;
            config = configService.find(config.getId(), config.getReleaseVersion());
            config.setName(input.getName());
            config.setDescription(input.getDescription());
            config.setDynamic(input.isDynamic());
        } else {
            config.setDomain(domain);
            config.setReleaseVersion(domain.getReleaseVersion());
            config.setCreatedBy(user.getUsername());
            config.setCreatedDTM(now);
        }
        config.setConfigGroup(saveConfigGroup(now));
        config.setModifiedBy(user.getUsername());
        config.setModifiedDTM(now);
        try {
            configService.save(config, value, CCReference);
        } catch (DuplicateException e) {
            addActionError("Please enter a unique " + e.getProperty() + ".");
            return INPUT;
        }
        return SUCCESS;
    }

    private ConfigGroup saveConfigGroup(Timestamp now) {
        if (configGroupName == null || "".equals(configGroupName)) return null;

        ConfigGroup configGroup = configGroupService.findByName(domain.getId(), domain.getReleaseVersion(), configGroupName);
        if (configGroup == null) {
            configGroup = new ConfigGroup();
            configGroup.setDomain(domain);
            configGroup.setReleaseVersion(domain.getReleaseVersion());
            configGroup.setName(configGroupName);
            configGroup.setCreatedBy(user.getUsername());
            configGroup.setCreatedDTM(now);
            try {
                configGroupService.save(configGroup);
            } catch (DuplicateException e) {
                // should never get here - we are creating only when lookup by name fails!
                throw new RuntimeException(e);
            }
        }
        return configGroup;
    }

    public String delete() {
        Timestamp now = new Timestamp(System.currentTimeMillis());
        configService.delete(config.getId(), config.getReleaseVersion(), user.getUsername(), now, CCReference);
        return SUCCESS;
    }

    public boolean isNew() {
        return config.getId() == null;
    }

    public void setConfigService(ConfigService configService) {
        this.configService = configService;
    }

    public void setConfigGroupService(ConfigGroupService configGroupService) {
        this.configGroupService = configGroupService;
    }

    public Config getConfig() {
        return config;
    }

    public List<ConfigGroup> getConfigGroups() {
        return configGroups;
    }

    public void setId(long id) {
        config.setId(id);
    }

    public void setReleaseVersion(String releaseVersion) {
        config.setReleaseVersion(releaseVersion);
    }

    public String getConfigGroupName() {
        return configGroupName;
    }

    public void setConfigGroupName(String configGroupName) {
        this.configGroupName = configGroupName;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}