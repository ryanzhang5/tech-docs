/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dataobject;

import java.io.Serializable;

/**
 * Most of the tables in the schema are keyed by a composite key comprised of:
 * - generated ID, and
 * - release version string
 *
 * @author mkishore
 * @since 1.0
 */
public class VersionedKey implements Serializable {
    private Long id;
    private String releaseVersion;

    public VersionedKey() {
        // default cons
    }

    public VersionedKey(Long id, String releaseVersion) {
        this.id = id;
        this.releaseVersion = releaseVersion;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getReleaseVersion() {
        return releaseVersion;
    }

    public void setReleaseVersion(String releaseVersion) {
        this.releaseVersion = releaseVersion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof VersionedKey)) return false;

        VersionedKey that = (VersionedKey) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (releaseVersion != null ? !releaseVersion.equals(that.releaseVersion) : that.releaseVersion != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (releaseVersion != null ? releaseVersion.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return getClass().getName() + "[releaseVersion: " + releaseVersion + ", id: " + id + "]";
    }

}
