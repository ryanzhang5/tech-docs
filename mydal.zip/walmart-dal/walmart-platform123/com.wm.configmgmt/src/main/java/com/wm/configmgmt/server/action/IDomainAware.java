/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action;

import com.wm.configmgmt.server.dataobject.Domain;

/**
 * IDomainAware
 *
 * @author mkishore
 * @since 1.0
 */
public interface IDomainAware {
    public void setDomain(Domain domain);
    public void setCCReference(String CCReference);
}
