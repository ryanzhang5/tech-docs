/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dataobject;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

/**
 * Configuration Domain - identified by a name (e.g. "www") and a release version (e.g. "9.5").
 * All rows in all other tables are scoped under a given domain. When we move data from one
 * environment to another, we need to move the data corresponding to a given domain.
 *
 * @author mkishore
 * @since 1.0
 */
public class Domain extends BaseDO implements ISoftDeletable, IVersionedDO, INamedDO, Cloneable {
    private VersionedKey PK = new VersionedKey();
    private String name;
    private String description;
    private boolean locked;
    private String createdBy;
    private Timestamp createdDTM;
    private String modifiedBy;
    private Timestamp modifiedDTM;
    private boolean deleted;

    private Set<ConfigGroup> configGroups = new HashSet<ConfigGroup>();
    private Set<Config> configs = new HashSet<Config>();
    private Set<LogicalLayer> logicalLayers = new HashSet<LogicalLayer>();
    private Set<PhysicalLayer> physicalLayers = new HashSet<PhysicalLayer>();
    private Set<Server> servers = new HashSet<Server>();
    private Set<ServerGroup> serverGroups = new HashSet<ServerGroup>();
    private Set<PublishRecord> publishRecords = new HashSet<PublishRecord>();

    public VersionedKey getPK() {
        return PK;
    }

    public void setPK(VersionedKey PK) {
        this.PK = PK;
    }

    public Long getId() {
        return PK.getId();
    }

    public void setId(Long id) {
        PK.setId(id);
    }

    public String getReleaseVersion() {
        return PK.getReleaseVersion();
    }

    public void setReleaseVersion(String releaseVersion) {
        PK.setReleaseVersion(releaseVersion);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isLocked() {
        return locked;
    }

    public void setLocked(boolean locked) {
        this.locked = locked;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDTM() {
        return createdDTM;
    }

    public void setCreatedDTM(Timestamp createdDTM) {
        this.createdDTM = createdDTM;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Timestamp getModifiedDTM() {
        return modifiedDTM;
    }

    public void setModifiedDTM(Timestamp modifiedDTM) {
        this.modifiedDTM = modifiedDTM;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public Set<ConfigGroup> getConfigGroups() {
        return configGroups;
    }

    public void setConfigGroups(Set<ConfigGroup> configGroups) {
        this.configGroups = configGroups;
    }

    public Set<Config> getConfigs() {
        return configs;
    }

    public void setConfigs(Set<Config> configs) {
        this.configs = configs;
    }

    public Set<LogicalLayer> getLogicalLayers() {
        return logicalLayers;
    }

    public void setLogicalLayers(Set<LogicalLayer> logicalLayers) {
        this.logicalLayers = logicalLayers;
    }

    public Set<PhysicalLayer> getPhysicalLayers() {
        return physicalLayers;
    }

    public void setPhysicalLayers(Set<PhysicalLayer> physicalLayers) {
        this.physicalLayers = physicalLayers;
    }

    public Set<Server> getServers() {
        return servers;
    }

    public void setServers(Set<Server> servers) {
        this.servers = servers;
    }

    public Set<ServerGroup> getServerGroups() {
        return serverGroups;
    }

    public void setServerGroups(Set<ServerGroup> serverGroups) {
        this.serverGroups = serverGroups;
    }

    public Set<PublishRecord> getPublishRecords() {
        return publishRecords;
    }

    public void setPublishRecords(Set<PublishRecord> publishRecords) {
        this.publishRecords = publishRecords;
    }
    
    public Object clone() throws CloneNotSupportedException {
    	return super.clone();
    }
}
