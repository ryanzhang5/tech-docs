/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action.servergroup;

import com.opensymphony.xwork2.Preparable;
import com.wm.configmgmt.server.action.AbstractDomainAction;
import com.wm.configmgmt.server.dataobject.*;
import com.wm.configmgmt.server.service.ServerGroupService;
import com.wm.configmgmt.server.service.ServerService;
import com.wm.configmgmt.server.service.DuplicateException;

import java.sql.Timestamp;
import java.util.*;

/**
 * ServerGroupAction
 *
 * @author mkishore
 * @since 1.0
 */
public class ServerGroupAction extends AbstractDomainAction implements Preparable {
    private ServerGroupService serverGroupService;
    private ServerService serverService;

    private ServerGroup serverGroup = new ServerGroup();

    private List<ServerGroup> availableGroups = new ArrayList<ServerGroup>();
    private List<Server> availableServers = new ArrayList<Server>();
    private Collection<Long> selectedGroupIds = new ArrayList<Long>();
    private Collection<Long> selectedServerIds = new ArrayList<Long>();

    public void prepare() throws Exception {
        // no-op
    }

    public String add() {
        prepareAvailable();
        return SUCCESS;
    }

    public String edit() {
        serverGroup = serverGroupService.findWithChildren(serverGroup.getId(), serverGroup.getReleaseVersion());
        prepareAvailable();
        prepareSelected();
        return SUCCESS;
    }

    // this should help us re-populate the form on error
    public void prepareSave() {
        prepareAvailable();
    }

    public String save() {
        Timestamp now = new Timestamp(System.currentTimeMillis());
        if (isNew()) {
            serverGroup.setCreatedBy(user.getUsername());
            serverGroup.setCreatedDTM(now);
        }
        serverGroup.setDomain(domain);
        serverGroup.setReleaseVersion(domain.getReleaseVersion());
        serverGroup.setModifiedBy(user.getUsername());
        serverGroup.setModifiedDTM(now);

        try {
            serverGroupService.saveWithChildren(serverGroup, selectedGroupIds, selectedServerIds);
        } catch (DuplicateException e) {
            addActionError("Please enter a unique " + e.getProperty() + ".");
            return INPUT;
        }
        return SUCCESS;
    }

    public String delete() {
        serverGroupService.delete(serverGroup.getId(), serverGroup.getReleaseVersion());
        return SUCCESS;
    }

    public boolean isNew() {
        return serverGroup.getId() == null;
    }

    private void prepareAvailable() {
        availableGroups = serverGroupService.findAll(domain.getId(), domain.getReleaseVersion());
        Collections.sort(availableGroups, new NamedDOComparator());
        if (!isNew()) {
            for (Iterator<ServerGroup> it = availableGroups.iterator(); it.hasNext();) {
                ServerGroup sg = it.next();
                if (sg.getId().equals(serverGroup.getId())) {
                    it.remove();
                    break;
                }
            }
        }
        availableServers = serverService.findAll(domain.getId(), domain.getReleaseVersion());
        Collections.sort(availableServers, new NamedDOComparator());
    }

    private void prepareSelected() {
        selectedGroupIds.clear();
        selectedServerIds.clear();

        if (serverGroup == null) return;
        List<ServerGroupGroup> sggList = new ArrayList<ServerGroupGroup>(serverGroup.getChildGroups());
        for (ServerGroupGroup sgg : sggList) {
            selectedGroupIds.add(sgg.getChildGroupId());
        }
        List<ServerGroupServer> sgsList = new ArrayList<ServerGroupServer>(serverGroup.getServers());
        for (ServerGroupServer sgs : sgsList) {
            selectedServerIds.add(sgs.getServerId());
        }
    }

    public void setServerGroupService(ServerGroupService serverGroupService) {
        this.serverGroupService = serverGroupService;
    }

    public void setServerService(ServerService serverService) {
        this.serverService = serverService;
    }

    public ServerGroup getServerGroup() {
        return serverGroup;
    }

    public void setId(long id) {
        serverGroup.setId(id);
    }

    public void setReleaseVersion(String releaseVersion) {
        serverGroup.setReleaseVersion(releaseVersion);
    }

    public List<ServerGroup> getAvailableGroups() {
        return availableGroups;
    }

    public List<Server> getAvailableServers() {
        return availableServers;
    }

    public Collection<Long> getSelectedGroupIds() {
        return selectedGroupIds;
    }

    public void setSelectedGroupIds(Collection<Long> selectedGroupIds) {
        this.selectedGroupIds = selectedGroupIds;
    }

    public Collection<Long> getSelectedServerIds() {
        return selectedServerIds;
    }

    public void setSelectedServerIds(Collection<Long> selectedServerIds) {
        this.selectedServerIds = selectedServerIds;
    }

}