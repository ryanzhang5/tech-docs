/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.service;

import com.wm.configmgmt.server.dao.IConfigDAO;
import com.wm.configmgmt.server.dao.IConfigValueDAO;
import com.wm.configmgmt.server.dataobject.Config;
import com.wm.configmgmt.server.dataobject.ConfigValue;
import com.wm.configmgmt.server.dataobject.VersionedKey;
import org.springframework.transaction.annotation.Transactional;

import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.sql.Timestamp;

/**
 * ConfigService
 *
 * @author mkishore
 * @since 1.0
 */
public class ConfigService {
    private IConfigDAO configDAO;
    private IConfigValueDAO configValueDAO;

    @Transactional
    public List<Config> findAll(long domainId, String releaseVersion) {
        String query = "select c from Config c"
                + " where c.domain.PK.id = ?1"
                + " and c.domain.PK.releaseVersion = ?2"
                ;
        List<Config> configs = configDAO.findAllByQuery(query, domainId, releaseVersion);
        return configs;
    }

    @Transactional
    public ConfigValue findDefaultValue(long configId, String releaseVersion) {
        String query = "select cv from ConfigValue cv"
                + " where cv.config.PK.id = ?1"
                + " and cv.config.PK.releaseVersion = ?2"
                + " and cv.physicalLayer.PK.id is null"
                + " and cv.logicalLayer.PK.id is null"
                + " and cv.server.PK.id is null"
                + " order by cv.createdDTM desc"
                ;
        List<ConfigValue> configValues = configValueDAO.findAllByQuery(query, configId, releaseVersion);
        return (configValues != null && !configValues.isEmpty()) ?configValues.get(0) :null;
    }

    @Transactional
    public Config find(long id, String releaseVersion) {
        Config config = configDAO.findById(new VersionedKey(id, releaseVersion));
//        ServiceUtil.initialize(config.getConfigGroup());
        return config;
    }
    
    @Transactional
    public Config findWithChildren(long id, String releaseVersion) {
        Config config = configDAO.findById(new VersionedKey(id, releaseVersion));
        if (config != null) {
        	ServiceUtil.initialize(config.getConfigGroup());
        	ServiceUtil.initialize(config.getDomain());
        	ServiceUtil.initialize(config.getConfigValues());
        }
        return config;
    }
    
    @Transactional
    public Config findByName(long domainId, String releaseVersion, String name) {
    	if (name == null || "".equals(name) || releaseVersion == null || "".equals(releaseVersion)) {
    		return null;
    	}
    	String query = "select o from Config o"
                + " where o.domain.PK.id = ?1"
                + " and o.domain.PK.releaseVersion = ?2 "
                + " and o.name = ?3"
    		;
    	List<Config> list = configDAO.findAllByQuery(query, domainId, releaseVersion, name);
    	return (list != null && list.size() > 0) ? list.get(0) : null;
    }

    @Transactional
    public void save(Config config) throws DuplicateException {
        Config namedDO = findByName(config.getDomainId(), config.getReleaseVersion(), config.getName());
        if (config.getId() == null) {
            if (namedDO != null) {
                throw new DuplicateException();
            }
            configDAO.insert(config);
        } else {
            if (namedDO != null && !namedDO.getId().equals(config.getId())) {
                throw new DuplicateException();
            }
            configDAO.update(config);
        }
    }

    @Transactional
    public void save(Config config, String value, String ccReference) throws DuplicateException {
        boolean insertConfigValue = true;
        if (config.getId() != null) {
            ConfigValue oldConfigValue = findDefaultValue(config.getId(), config.getReleaseVersion());
            if (oldConfigValue != null) {
                String oldValue = oldConfigValue.getValue();
                if ((oldValue == null && value == null) || (oldValue != null && oldValue.equals(value))) {
                    insertConfigValue = false;
                }
            }
        }
        save(config);
        if (insertConfigValue) {
            ConfigValue configValue = new ConfigValue();
            configValue.setConfig(config);
            configValue.setCCReference(ccReference);
            configValue.setCreatedBy(config.getModifiedBy());
            configValue.setCreatedDTM(config.getModifiedDTM());
            configValue.setReleaseVersion(config.getReleaseVersion());
            configValue.setValue(value);
            configValueDAO.insert(configValue);
        }
    }

    @Transactional
    public void delete(long id, String releaseVersion, String user, Timestamp dtm, String CCReference) {
    	Config config = findWithChildren(id, releaseVersion);
    	if (config != null) {
	    	Set<ConfigValue> configValues = config.getConfigValues();
	    	if (configValues != null && configValues.size() > 0) {
                for (Iterator<ConfigValue> it = configValues.iterator(); it.hasNext();) {
                    ConfigValue configValue = it.next();
                    if (configValue != null) {
                        configValueDAO.delete(user, dtm, CCReference, configValue);
                        it.remove();
                    }
                }
	        }
	    	configDAO.delete(user, dtm, config);
    	}
    }

    public void setConfigDAO(IConfigDAO configDAO) {
        this.configDAO = configDAO;
    }

    public void setConfigValueDAO(IConfigValueDAO configValueDAO) {
        this.configValueDAO = configValueDAO;
    }
}