/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.Config;
import com.wm.configmgmt.server.dataobject.VersionedKey;
import com.wm.configmgmt.server.dataobject.ConfigValue;

import java.sql.Timestamp;

/**
 * IConfigDAO
 *
 * @author mkishore
 * @since 1.0
 */
public interface IConfigDAO extends IBaseDAO<Config, VersionedKey> {

    void delete(String user, Timestamp dtm, Config... entities);

}