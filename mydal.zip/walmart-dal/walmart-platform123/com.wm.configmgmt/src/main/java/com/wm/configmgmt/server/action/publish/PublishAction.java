/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action.publish;

import com.opensymphony.xwork2.Preparable;
import com.wm.configmgmt.common.jms.WMMessageConfigChangeNotification;
import com.wm.configmgmt.server.action.AbstractDomainAction;
import com.wm.configmgmt.server.dataobject.*;
import com.wm.configmgmt.server.service.LogicalLayerService;
import com.wm.configmgmt.server.service.PublishRecordService;
import com.wm.configmgmt.server.service.ServerGroupService;
import com.wm.configmgmt.server.service.ServerService;
import com.wm.weblib.jms.SendJMSMsgToActiveMQ;
import com.wm.weblib.jms.WMJMSObjectMessage;
import com.wm.weblib.jms.WMMessageType;

import java.sql.Timestamp;
import java.util.*;

/**
 * PublishAction
 *
 * @author mkishore
 * @since 1.0
 */
public class PublishAction extends AbstractDomainAction implements Preparable {
    private static final String JMS_QUEUE = "WMJMSAdminListener"; // TODO: read this from configuration
    private static final long JMS_TTL = 60*60*1000; // 1 hour

    private PublishRecordService publishRecordService;
    private ServerGroupService serverGroupService;
    private ServerService serverService;
    private LogicalLayerService logicalLayerService;

    private PublishRecord publishRecord = new PublishRecord();

    private List<ServerGroup> serverGroups = new ArrayList<ServerGroup>();
    private List<Server> servers = new ArrayList<Server>();
    private List<LogicalLayer> logicalLayers = new ArrayList<LogicalLayer>();

    private List<Long> selectedServerGroupIds = new ArrayList<Long>();
    private List<Long> selectedServerIds = new ArrayList<Long>();

    private List<PublishServerRecord> publishServerRecords = new ArrayList<PublishServerRecord>();

    public String status() {
        publishServerRecords = publishRecordService.findAllServerRecords(publishRecord.getId(), domain.getReleaseVersion());
        return SUCCESS;
    }

    public void prepare() throws Exception {
        // no-op
    }

    public String publish() {
        prepareServerGroups();
        prepareServers();
        prepareLogicalLayers();
        return SUCCESS;
    }

    public String submit() {
        Timestamp now = new Timestamp(System.currentTimeMillis());
        publishRecord.setDomain(domain);
        publishRecord.setReleaseVersion(domain.getReleaseVersion());
        publishRecord.setCCReference(CCReference);
        publishRecord.setCreatedBy(user.getUsername());
        publishRecord.setCreatedDTM(now);

        Set<Server> servers = findAllServers();
        publishRecordService.saveWithChildren(publishRecord, servers);
        sendJMSMessage(servers);

        return SUCCESS;
    }

    public String republish() {
        publishRecord = publishRecordService.find(publishRecord.getId(), domain.getReleaseVersion());
        Set<Server> servers = findAllServers();
        sendJMSMessage(servers);

        return SUCCESS;
    }

    private Set<Server> findAllServers() {
        Set<Server> servers = new HashSet<Server>();
        for (Long serverId : selectedServerIds) {
            servers.add(serverService.find(serverId, domain.getReleaseVersion()));
        }
        for (Long serverGroupId : selectedServerGroupIds) {
            servers.addAll(serverGroupService.findAllServersForGroup(serverGroupId, domain.getReleaseVersion()));
        }
        return servers;
    }

    private void sendJMSMessage(Set<Server> servers) {
        Set<String> serverNames = new HashSet<String>();
        for (Server server : servers) {
            serverNames.add(server.getName());
        }
        WMMessageConfigChangeNotification.Payload payload = new WMMessageConfigChangeNotification.Payload();
        payload.setPublishRecordId(publishRecord.getId());
        payload.setReleaseVersion(domain.getReleaseVersion());
        payload.setLogicalLayer(logicalLayerService.getFullName(publishRecord.getLogicalLayerId(), domain.getReleaseVersion()));
        payload.setServerNames(serverNames);
        payload.setPublishMessage(publishRecord.getPublishMessage());
        WMJMSObjectMessage message = new WMJMSObjectMessage(WMMessageType.MSG_TYPE_CONFIG_MGMT_NOTIFICATION.toString(), ".*", payload);
        SendJMSMsgToActiveMQ.sendAQObjectMessage(JMS_QUEUE, JMS_TTL, message, false);
    }

    private void prepareServerGroups() {
        serverGroups = serverGroupService.findAll(domain.getId(), domain.getReleaseVersion());
        Collections.sort(serverGroups, new NamedDOComparator());
    }

    private void prepareServers() {
        servers = serverService.findAll(domain.getId(), domain.getReleaseVersion());
        Collections.sort(servers, new NamedDOComparator());
    }

    private void prepareLogicalLayers() {
        logicalLayers = logicalLayerService.findRootLayersWithChildren(domain.getId(), domain.getReleaseVersion());
    }

    public void setPublishRecordService(PublishRecordService publishRecordService) {
        this.publishRecordService = publishRecordService;
    }

    public void setServerGroupService(ServerGroupService serverGroupService) {
        this.serverGroupService = serverGroupService;
    }

    public void setServerService(ServerService serverService) {
        this.serverService = serverService;
    }

    public void setLogicalLayerService(LogicalLayerService logicalLayerService) {
        this.logicalLayerService = logicalLayerService;
    }

    public PublishRecord getPublishRecord() {
        return publishRecord;
    }

    public void setId(Long id) {
        publishRecord.setId(id);
    }

    public void setReleaseVersion(String releaseVersion) {
        publishRecord.setReleaseVersion(releaseVersion);
    }

    public List<PublishServerRecord> getPublishServerRecords() {
        return publishServerRecords;
    }

    public List<ServerGroup> getServerGroups() {
        return serverGroups;
    }

    public List<Server> getServers() {
        return servers;
    }

    public List<LogicalLayer> getLogicalLayers() {
        return logicalLayers;
    }

    public List<Long> getSelectedServerGroupIds() {
        return selectedServerGroupIds;
    }

    public List<Long> getSelectedServerIds() {
        return selectedServerIds;
    }

    public void setSelectedServerGroupIds(List<Long> selectedServerGroupIds) {
        this.selectedServerGroupIds = selectedServerGroupIds;
    }

    public void setSelectedServerIds(List<Long> selectedServerIds) {
        this.selectedServerIds = selectedServerIds;
    }
}