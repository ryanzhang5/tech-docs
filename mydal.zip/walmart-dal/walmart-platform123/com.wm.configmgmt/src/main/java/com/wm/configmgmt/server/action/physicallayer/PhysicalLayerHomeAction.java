/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action.physicallayer;

import com.wm.configmgmt.server.action.AbstractDomainAction;
import com.wm.configmgmt.server.dataobject.PhysicalLayer;
import com.wm.configmgmt.server.service.PhysicalLayerService;

import java.util.ArrayList;
import java.util.List;

/**
 * PhysicalLayerHomeAction
 *
 * @author mkishore
 * @since 1.0
 */
public class PhysicalLayerHomeAction extends AbstractDomainAction {
    private PhysicalLayerService physicalLayerService;

    private List<PhysicalLayer> rootLayers = new ArrayList<PhysicalLayer>();

    public String home() {
        return SUCCESS;
    }

    public String tree() {
        prepareRootLayers();
        return SUCCESS;
    }

    private void prepareRootLayers() {
        rootLayers = physicalLayerService.findRootLayersWithChildren(domain.getId(), domain.getReleaseVersion());
    }

    public void setPhysicalLayerService(PhysicalLayerService physicalLayerService) {
        this.physicalLayerService = physicalLayerService;
    }

    public List<PhysicalLayer> getRootLayers() {
        return rootLayers;
    }

}