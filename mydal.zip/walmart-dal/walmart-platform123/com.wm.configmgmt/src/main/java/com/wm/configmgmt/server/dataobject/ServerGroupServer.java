/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dataobject;

import java.sql.Timestamp;

/**
 * Represents a mapping from parentGroup to childGroup
 *
 * @author mkishore
 * @since 1.0
 */
public class ServerGroupServer extends BaseDO implements Cloneable {
    private VersionedKeyMulti PK = new VersionedKeyMulti();
    private String createdBy;
    private Timestamp createdDTM;

    private ServerGroup serverGroup;
    private Server server;

    public VersionedKeyMulti getPK() {
        return PK;
    }

    public void setPK(VersionedKeyMulti PK) {
        this.PK = PK;
    }

    public Long getServerGroupId() {
        return PK.getId();
    }

    public void setServerGroupId(Long serverGroupId) {
        PK.setId(serverGroupId);
    }

    public String getReleaseVersion() {
        return PK.getReleaseVersion();
    }

    public void setReleaseVersion(String releaseVersion) {
        PK.setReleaseVersion(releaseVersion);
    }

    public Long getServerId() {
        return PK.getId1();
    }

    public void setServerId(Long serverId) {
        PK.setId1(serverId);
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDTM() {
        return createdDTM;
    }

    public void setCreatedDTM(Timestamp createdDTM) {
        this.createdDTM = createdDTM;
    }

    public ServerGroup getServerGroup() {
        return serverGroup;
    }

    public void setServerGroup(ServerGroup serverGroup) {
        this.serverGroup = serverGroup;
        setServerGroupId((serverGroup != null) ? serverGroup.getId() : null);
    }

    public Server getServer() {
        return server;
    }

    public void setServer(Server server) {
        this.server = server;
        setServerId((server != null) ? server.getId() : null);
    }
    
    public Object clone() throws CloneNotSupportedException {
    	return super.clone();
    }
}