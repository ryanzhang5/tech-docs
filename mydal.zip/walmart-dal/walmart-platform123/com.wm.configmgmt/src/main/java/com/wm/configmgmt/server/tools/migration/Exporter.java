package com.wm.configmgmt.server.tools.migration;

import com.wm.configmgmt.common.tools.CLI;
import oracle.xml.sql.dml.OracleXMLSave;
import oracle.xml.sql.query.OracleXMLQuery;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.sql.DataSource;
import java.io.FileWriter;
import java.io.File;
import java.sql.*;

public class Exporter {
    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH.mm.ss.SSS";

    private DataSource dataSource;

    private String domain;
    private String release;
    private String ccreference;

    private String path;

    private Long domainId;

    private static final String SQL_DOMAIN = "select * from domain " +
            " where name = ? " +
            " and rel_version = ? " +
            " and is_deleted = 'N'";
    private static final String SQL_MIN_MAX_DTM = "select min(cv.created_dtm), max(cv.created_dtm) " +
            " from config_value cv, config c " +
            " where c.domain_id = ? " +
            " and c.rel_version = ? " +
            " and cv.cc_reference = ? " +
            " and cv.config_id = c.config_id";
    private static final String SQL_CONFIG_GROUP = "select * from config_group " +
            " where domain_id = ? " +
            " and rel_version = ? " +
            " and is_deleted = 'N'";
    private static final String SQL_CONFIG = "select * from config " +
            " where domain_id = ? " +
            " and rel_version = ? " +
            " and is_deleted = 'N'";
    private static final String SQL_CONFIG_FOR_CC = "select * from config " +
            " where domain_id = ? " +
            " and rel_version = ? " +
            " and modified_dtm >= ? " +
            " and modified_dtm <= ? " +
            " and is_deleted = 'N'";
    private static final String SQL_PHYSICAL_LAYER = "select * from physical_layer " +
            " where domain_id = ? " +
            " and rel_version = ? " +
            " and is_deleted = 'N' " +
            " start with parent_layer_id is null " +
            " connect by parent_layer_id = prior layer_id";
    private static final String SQL_LOGICAL_LAYER = "select * from logical_layer " +
            " where domain_id = ? " +
            " and rel_version = ? " +
            " and is_deleted = 'N' " +
            " start with parent_layer_id is null " +
            " connect by parent_layer_id = prior layer_id";
    private static final String SQL_SERVER = "select * from server " +
            " where domain_id = ? " +
            " and rel_version = ? " +
            " and is_deleted = 'N'";
    private static final String SQL_CONFIG_VALUE = "select cv.* from config_value cv, " +
            "( " +
            "  select " +
            "    max(cv2.created_dtm) dtm, " +
            "    cv2.config_id, " +
            "    cv2.rel_version, " +
            "    cv2.logical_layer_id, " +
            "    cv2.physical_layer_id, " +
            "    cv2.server_id " +
            "  from config_value cv2, config c " +
            "  where c.config_id = cv2.config_id " +
            "    and c.rel_version = cv2.rel_version " +
            "    and c.domain_id = ? " + //?1 domain_id
            "    and c.rel_version = ? " + //?2 release_version
            "    and (c.is_deleted = 'N' " +
            //"    or (? is not null and c.modified_dtm >= ?) " + //?3 -- for getting CV as of a given timestamp
            "    ) " +
            //"    and (? is null or cv2.created_dtm < ?) " + //?3 -- for getting CV as of a given timestamp
            "  group by " +
            "    cv2.config_id, " +
            "    cv2.rel_version, " +
            "    cv2.logical_layer_id, " +
            "    cv2.physical_layer_id, " +
            "    cv2.server_id " +
            " ) cv3 " +
            " where cv.created_dtm = cv3.dtm " +
            " and cv.config_id = cv3.config_id " +
            " and cv.rel_version = cv3.rel_version " +
            " and nvl(cv.logical_layer_id, -1) = nvl(cv3.logical_layer_id, -1) " +
            " and nvl(cv.physical_layer_id, -1) = nvl(cv3.physical_layer_id, -1) " +
            " and nvl(cv.server_id, -1) = nvl(cv3.server_id, -1) " +
            " and cv.is_deleted = 'N'";
    private static final String SQL_CONFIG_VALUE_FOR_CC = "select cv.* from config_value cv, " +
            "( " +
            "  select " +
            "    max(cv2.created_dtm) dtm, " +
            "    cv2.config_id, " +
            "    cv2.rel_version, " +
            "    cv2.logical_layer_id, " +
            "    cv2.physical_layer_id, " +
            "    cv2.server_id, " +
            "    cv2.cc_reference " +
            "  from config_value cv2, config c " +
            "  where c.config_id = cv2.config_id " +
            "    and c.rel_version = cv2.rel_version " +
            "    and c.domain_id = ? " + //?1 domain_id
            "    and c.rel_version = ? " + //?2 release_version
            "    and cv2.cc_reference = ? " + //?3 cc_reference
            "    and (c.is_deleted = 'N' " +
            //"    or (? is not null and c.modified_dtm >= ?) " + //?3 -- for getting CV as of a given timestamp
            "    ) " +
            //"    and (? is null or cv2.created_dtm < ?) " + //?3 -- for getting CV as of a given timestamp
            "  group by " +
            "    cv2.config_id, " +
            "    cv2.rel_version, " +
            "    cv2.logical_layer_id, " +
            "    cv2.physical_layer_id, " +
            "    cv2.server_id, " +
            "    cv2.cc_reference " +
            " ) cv3 " +
            " where cv.created_dtm = cv3.dtm " +
            " and cv.config_id = cv3.config_id " +
            " and cv.rel_version = cv3.rel_version " +
            " and nvl(cv.logical_layer_id, -1) = nvl(cv3.logical_layer_id, -1) " +
            " and nvl(cv.physical_layer_id, -1) = nvl(cv3.physical_layer_id, -1) " +
            " and nvl(cv.server_id, -1) = nvl(cv3.server_id, -1) " +
            " and cv.cc_reference = cv3.cc_reference";
    private static final String SQL_SERVER_GROUP = "select * from server_group " +
            " where domain_id = ? " +
            " and rel_version = ? " +
            " and is_deleted = 'N'";
    private static final String SQL_SERVER_GROUP_GROUP = "select * from srvgrp_group_map sgm, server_group sg " +
            " where sgm.server_group_id = sg.server_group_id " +
            " and sg.domain_id = ? " +
            " and sg.rel_version = ? " +
            " and sg.is_deleted = 'N'";
    private static final String SQL_SERVER_GROUP_SERVER = "select * from srvgrp_server_map ssm, server_group sg " +
            " where ssm.server_group_id = sg.server_group_id "+
            " and sg.domain_id = ? " +
            " and sg.rel_version = ? " +
            " and sg.is_deleted = 'N'";
    private static final String SQL_PUBLISH_RECORD = "select * from publish_record " +
            " where domain_id = ? " +
            " and rel_version = ?";
    private static final String SQL_PUBLISH_SERVER_RECORD = "select * from publish_server_map psm, publish_record pr " +
            " where psm.publish_record_id = pr.publish_record_id " +
            " and pr.domain_id = ? " +
            " and pr.rel_version = ?";

    private static final String DOMAIN_XMLFILE_NAME = "domain.xml";
    private static final String CONFIG_GROUP_XMLFILE_NAME = "config_group.xml";
    private static final String CONFIG_XMLFILE_NAME = "config.xml";
    private static final String CONFIG_VALUE_XMLFILE_NAME = "config_value.xml";
    private static final String PHYSICAL_LAYER_XMLFILE_NAME = "physical_layer.xml";
    private static final String LOGICAL_LAYER_XMLFILE_NAME = "logical_layer.xml";
    private static final String PUBLISH_RECORD_XMLFILE_NAME = "publish_record.xml";
    private static final String PUBLISH_SERVER_RECORD_XMLFILE_NAME = "publish_server_record.xml";
    private static final String SERVER_XMLFILE_NAME = "server.xml";
    private static final String SERVER_GROUP_XMLFILE_NAME = "server_group.xml";
    private static final String SERVER_GROUP_GROUP_XMLFILE_NAME = "server_group_group.xml";
    private static final String SERVER_GROUP_SERVER_XMLFILE_NAME = "server_group_server.xml";

    private void initializeDomainId() {
        Connection conn = null;
        PreparedStatement psmt = null;
        ResultSet rset = null;
        try {
            conn = dataSource.getConnection();
            psmt = conn.prepareStatement(SQL_DOMAIN);
            psmt.setString(1, domain);
            psmt.setString(2, release);
            rset = psmt.executeQuery();
            if (rset.next()) {
                this.domainId = rset.getLong("domain_id");
                System.out.println("Successfully initializing domainId: " + domainId);
            } else {
                throw new RuntimeException("Could not find a domain with name=" + domain + ", rel_version=" + release);
            }
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        } finally {
            safeClose(rset, psmt, conn);
        }
    }

    private String getXmlString(String sql, Object... params) {
        String xmlString = null;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = dataSource.getConnection();
            pstmt = conn.prepareStatement(sql);
            if (params != null) for (int i = 0; i < params.length; i++) {
                Object param = params[i];
                pstmt.setObject(i + 1, param);
            }
            rs = pstmt.executeQuery();
            OracleXMLQuery xmlQuery = new OracleXMLQuery(conn, rs);
            xmlQuery.setDateFormat(DATE_TIME_FORMAT);
            xmlString = xmlQuery.getXMLString();
            System.out.println("Successfully got xml for: " + sql);
        } catch (Exception e) {
            System.out.println("Failed to get xml for: " + sql);
            throw new RuntimeException(e);
        } finally {
            safeClose(rs, pstmt, conn);
        }
        return xmlString;
    }

    private void generateXmlFile(String sql, String fileName, Object... params) {
        try {
            fileName = prependFilePath(fileName);
            FileWriter writer = new FileWriter(fileName);
            writer.write(this.getXmlString(sql, params));
            writer.close();
            System.out.println("Successfully generated: " + fileName);
        } catch (Exception e) {
            System.out.println("Failed to generate: " + fileName);
            throw new RuntimeException(e);
        }
    }

    private Timestamp[] getMinMaxForCCReference() {
        Timestamp[] ret = new Timestamp[2];
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = dataSource.getConnection();
            stmt = conn.prepareStatement(SQL_MIN_MAX_DTM);
            stmt.setLong(1, domainId);
            stmt.setString(2, release);
            stmt.setString(3, ccreference);
            rs = stmt.executeQuery();
            if (rs.next()) {
                ret[0] = rs.getTimestamp(1);
                ret[1] = rs.getTimestamp(2);
                System.out.println("Found the min/max for CCReference [" + ccreference + "] as: " + ret[0] + " to " + ret[1]);
            } else {
                throw new RuntimeException("No config_value records found for the given CCReference");
            }
        } catch (Exception e) {
            System.out.println("Failed to get min/max timestamps for the given ccreference");
            throw new RuntimeException(e);
        } finally {
            safeClose(rs, stmt, conn);
        }
        return ret;
    }

    public void execute() {
        validateArgs();
        initializeDomainId();
        if (ccreference == null) {
            generateXmlFile(SQL_DOMAIN, DOMAIN_XMLFILE_NAME, domain, release);
            generateXmlFile(SQL_CONFIG_GROUP, CONFIG_GROUP_XMLFILE_NAME, domainId, release);
            generateXmlFile(SQL_CONFIG, CONFIG_XMLFILE_NAME, domainId, release);
            generateXmlFile(SQL_PHYSICAL_LAYER, PHYSICAL_LAYER_XMLFILE_NAME, domainId, release);
            generateXmlFile(SQL_LOGICAL_LAYER, LOGICAL_LAYER_XMLFILE_NAME, domainId, release);
            generateXmlFile(SQL_SERVER, SERVER_XMLFILE_NAME, domainId, release);
            generateXmlFile(SQL_CONFIG_VALUE, CONFIG_VALUE_XMLFILE_NAME, domainId, release);
            generateXmlFile(SQL_SERVER_GROUP, SERVER_GROUP_XMLFILE_NAME, domainId, release);
            generateXmlFile(SQL_SERVER_GROUP_GROUP, SERVER_GROUP_GROUP_XMLFILE_NAME, domainId, release);
            generateXmlFile(SQL_SERVER_GROUP_SERVER, SERVER_GROUP_SERVER_XMLFILE_NAME, domainId, release);
            generateXmlFile(SQL_PUBLISH_RECORD, PUBLISH_RECORD_XMLFILE_NAME, domainId, release);
            generateXmlFile(SQL_PUBLISH_SERVER_RECORD, PUBLISH_SERVER_RECORD_XMLFILE_NAME, domainId, release);
            System.out.println("Successfully generated all xml files.");
        } else {
            Timestamp[] minMax = getMinMaxForCCReference();
            generateXmlFile(SQL_CONFIG_FOR_CC, CONFIG_XMLFILE_NAME, domainId, release, minMax[0], minMax[1]);
            generateXmlFile(SQL_CONFIG_VALUE_FOR_CC, CONFIG_VALUE_XMLFILE_NAME, domainId, release, ccreference);
            System.out.println("Successfully generated config & config-value xml files.");
        }
    }

    private void safeClose(ResultSet rs, Statement stmt, Connection conn) {
        safeClose(rs, stmt, conn, null);
    }

    private void safeClose(ResultSet rs, Statement stmt, Connection conn, OracleXMLSave sav) {
        if (rs != null) try {
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (stmt != null) try {
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (conn != null) try {
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (sav != null) try {
            sav.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String prependFilePath(String fileName) {
        if (this.path != null && !"".equals(this.path)) {
            fileName = this.path + "/" + fileName;
        }
        return fileName;
    }

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getRelease() {
        return release;
    }

    public void setRelease(String release) {
        this.release = release;
    }

    public String getCcreference() {
        return ccreference;
    }

    public void setCcreference(String ccreference) {
        this.ccreference = ccreference;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public static void main(String[] args) {
        Exporter main = new Exporter();
        CLI.parse(args, main);
        ApplicationContext appContext = new ClassPathXmlApplicationContext("/dataSource.xml");
        main.setDataSource((DataSource) appContext.getBean("native_dataSource"));
        main.execute();
    }

    private void validateArgs() {
        if (this.getDataSource() == null) {
            throw new RuntimeException("Please check the dataSource.xml file - 'native_dataSource' bean not found");
        }
        if (this.getDomain() == null) {
            throw new RuntimeException("--domain : Domain Name is needed.");
        }
        if (this.getRelease() == null) {
            throw new RuntimeException("--release : Release Version is needed.");
        }
        if (this.getPath() == null) {
            throw new RuntimeException("--path : File path is needed.");
        } else {
            File dir = new File(path);
            if (!dir.exists()) {
                 dir.mkdirs();
            } else if (!dir.isDirectory() || !dir.canWrite()) {
                throw new RuntimeException("The path is not a directory, or cannot be written to!");
            }
        }
    }

}