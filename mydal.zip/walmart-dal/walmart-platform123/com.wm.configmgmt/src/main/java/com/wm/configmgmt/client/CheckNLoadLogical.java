package com.wm.configmgmt.client;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Copyright 2009 Walmart.com. All rights reserved.
 * User: ncherukuri
 * Date: Dec 22, 2009
 * Time: 1:35:35 PM
 */
public class CheckNLoadLogical {
    private DataSource dataSource;
    private List<String> logicalLayerList = new ArrayList<String>();
    private List<String> logicalLayerIDList = new ArrayList<String>();

    private String domainID;
    private String release;

    private String traverseTopDownSQL = "select ll.layer_id from logical_layer ll " +
            " where ll.domain_id = ? " +
            " and ll.rel_version = ? " +
            " and ll.name = ? " +
            " and nvl(ll.parent_layer_id, -1) = nvl(?, -1) " +
            " and ll.is_deleted = 'N' ";

    public CheckNLoadLogical(DataSource dataSource, List<String> logicalLayerList, String domainID, String release) {
        this.dataSource = dataSource;
        this.logicalLayerList = logicalLayerList;
        this.domainID = domainID;
        this.release = release;
    }

    public List<String> validateNLoad() {
        try {
            Connection conn = dataSource.getConnection();
            conn.setAutoCommit(false);
            PreparedStatement preStmt = conn.prepareStatement(traverseTopDownSQL);
            Long parentLayerID = -1L;
            for (String logicalLayerName : logicalLayerList) {
                preStmt.setString(1, domainID);
                preStmt.setString(2, release);
                preStmt.setString(3, logicalLayerName);
                preStmt.setLong(4, parentLayerID);

                ResultSet rs = preStmt.executeQuery();
                if (rs.next()) {
                    parentLayerID = rs.getLong(1);
                    logicalLayerIDList.add(Long.toString(parentLayerID));
                }
                rs.close();
            }
            preStmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return logicalLayerIDList;
    }

    public List<String> getLogicalLayerList() {
        return logicalLayerList;
    }

    public void setLogicalLayerList(List<String> logicalLayerList) {
        this.logicalLayerList = logicalLayerList;
    }

    public List<String> getLogicalLayerIDList() {
        return logicalLayerIDList;
    }

    public void setLogicalLayerIDList(List<String> logicalLayerIDList) {
        this.logicalLayerIDList = logicalLayerIDList;
    }

    public String getRelease() {
        return release;
    }

    public void setRelease(String release) {
        this.release = release;
    }
}
