/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.*;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * ConfigValueDAO
 *
 * @author mkishore
 * @since 1.0
 */
public class ConfigValueDAO extends BaseDAO<ConfigValue, VersionedKey> implements IConfigValueDAO {
    @PersistenceContext (name = "configmgmt")
    public void setEntityManager(EntityManager entityManager) {
        super.setEntityManager(entityManager);
    }

    public List<AuditGroup> findAllAuditGroups(Long domainId, String releaseVersion) {
        Query query = createNamedQuery("findCCReferences");
        query.setParameter(1, domainId);
        query.setParameter(2, releaseVersion);
        return query.getResultList();
    }

    public List<AuditEntry> findAuditEntriesByCCReference(Long domainId, String releaseVersion, String CCReference) {
        Query query = createNamedQuery("findAuditEntriesByCCReference");
        query.setParameter(1, domainId);
        query.setParameter(2, releaseVersion);
        query.setParameter(3, CCReference);
        return query.getResultList();
    }

    public Timestamp findMinDTMForCCReference(Long domainId, String releaseVersion, String CCReference) {
        Query query = createNamedQuery("findMinDTMForCCReference");
        query.setParameter(1, domainId);
        query.setParameter(2, releaseVersion);
        query.setParameter(3, CCReference);
        return (Timestamp) query.getSingleResult();
    }

    public List<ConfigValueAK> findConfigValueAKsSinceDTM(Long domainId, String releaseVersion, Timestamp minDTM) {
        Query query = createNamedQuery("findConfigValueAKsSinceDTM");
        query.setParameter(1, domainId);
        query.setParameter(2, releaseVersion);
        query.setParameter(3, minDTM);
        List resultList = query.getResultList();
        return resultList;
    }

    private Query createNamedQuery(String queryName) {
        Query query = getEntityManager().createNamedQuery(queryName);
        return query;
    }


    /**
     * We do not UPDATE/DELETE this in the database. All operations result in an INSERT.
     *
     * @param entities - the list of entities to be removed
     * @see javax.persistence.EntityManager#remove
     */
    public void delete(String user, Timestamp dtm, String CCReference, ConfigValue... entities) {
        List<ConfigValue> copies = new ArrayList<ConfigValue>();
        for (ConfigValue entity : entities) {
            ConfigValue copy = copy(user, dtm, entity);
            copy.setCCReference(CCReference);
            copy.setDeleted(true);
            copies.add(copy);
        }
        super.insert(copies.toArray(new ConfigValue[copies.size()]));
    }

    /**
     * We do not UPDATE/DELETE this in the database. All operations result in an INSERT.
     *
     * @param input - the detached object that needs to be merged in
     * @return the instance that the state was merged to
     * @see javax.persistence.EntityManager#merge
     */
    public ConfigValue update(ConfigValue input) {
        ConfigValue copy = copy(input.getCreatedBy(), input.getCreatedDTM(), input);
        super.insert(copy);
        return copy;
    }

    private ConfigValue copy(String user, Timestamp dtm, ConfigValue input) {
        ConfigValue copy = new ConfigValue();
        copy.setReleaseVersion(input.getReleaseVersion());
        copy.setConfigId(input.getConfigId());
        copy.setLogicalLayerId(input.getLogicalLayerId());
        copy.setPhysicalLayerId(input.getPhysicalLayerId());
        copy.setServerId(input.getServerId());
        copy.setValue(input.getValue());
        copy.setCCReference(input.getCCReference());
        copy.setCreatedBy(user);
        copy.setCreatedDTM(dtm);
        return copy;
    }
}