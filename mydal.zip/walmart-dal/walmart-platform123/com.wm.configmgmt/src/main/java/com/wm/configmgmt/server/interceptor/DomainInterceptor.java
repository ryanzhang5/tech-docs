/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.interceptor;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;
import com.wm.configmgmt.server.action.IDomainAware;
import com.wm.configmgmt.server.dataobject.Domain;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * This interceptor grabs the domain object from the session and injects into Actions
 * that implement the IDomainAware interface.
 *
 * @author mkishore
 * @since 1.0
 */
public class DomainInterceptor extends AbstractInterceptor {
    private static final String DOMAIN = "WM_DOMAIN";
    private static final String CC_REFERENCE = "WM_CC_REFERENCE";

    private static final List<String> LOCKED_METHODS = Arrays.asList(
            "save",
            "delete",
            "rollback"
    );

    public String intercept(ActionInvocation invocation) throws Exception {
        Map<String, Object> session = invocation.getInvocationContext().getSession();

        String CCReference = (String) session.get(CC_REFERENCE);
        if (CCReference == null) {
            CCReference = "Default-CC";
            session.put(CC_REFERENCE, CCReference);
        }

        Domain domain = (Domain) session.get(DOMAIN);

        Object action = invocation.getAction();
        if (action instanceof IDomainAware) {
            IDomainAware domainAware = (IDomainAware) action;
            domainAware.setCCReference(CCReference);
            if (domain != null) {
                domainAware.setDomain(domain);
                if (domain.isLocked()) {
                    String method = invocation.getProxy().getMethod();
                    if (LOCKED_METHODS.contains(method)) {
                        return "success";
                    }
                }
            }
        }
        return invocation.invoke();
    }

}