/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action.server;

import com.wm.configmgmt.server.action.AbstractDomainAction;
import com.wm.configmgmt.server.dataobject.NamedDOComparator;
import com.wm.configmgmt.server.dataobject.Server;
import com.wm.configmgmt.server.service.ServerService;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ServerListAction
 *
 * @author mkishore
 * @since 1.0
 */
public class ServerListAction extends AbstractDomainAction {
    private ServerService serverService;

    private List<Server> servers = new ArrayList<Server>();

    public String list() {
        servers = serverService.findAll(domain.getId(), domain.getReleaseVersion());
        Collections.sort(servers, new NamedDOComparator());
        return SUCCESS;
    }

    public void setServerService(ServerService serverService) {
        this.serverService = serverService;
    }

    public List<Server> getServers() {
        return servers;
    }

    /*
    public Map<String, List<Server>> getServers() {
        return servers;
    }

    private void prepareServers(List<Server> list) {
        servers.clear();
        String prefix = null;
        List<Server> sublist = new ArrayList<Server>();
        for (Server server : list) {
            String name = server.getName();
            if (prefix != null && name.startsWith(prefix)) {
                sublist.add(server);
            } else {
                // get the prefix, create new sublist and add server to sublist
                prefix = getPrefix(name);
                sublist = new ArrayList<Server>();
                sublist.add(server);
                servers.put(prefix, sublist);
            }
        }
    }

    private static final Pattern PATTERN = Pattern.compile("[0-9]");
    private String getPrefix(String name) {
        Matcher matcher = PATTERN.matcher(name);
        if (matcher.find()) {
            int ndx = matcher.start();
            return name.substring(0, ndx);
        }
        return name;
    }
    */
}