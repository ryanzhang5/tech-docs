package com.wm.configmgmt.client;

import com.wm.configmgmt.common.DriverManagerDataSource;
import com.wm.configmgmt.client.tools.overrides.OverridesManager;

import javax.sql.DataSource;
import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Read the properties file to get Connection for DB from a a path.
 * 0. Read the Physical layers List
 * 1. Read the Logical layers List
 * 2. Read the server name.
 * 3. Make the object to be passed to the Prepared Statement to read.
 * 4. Execute it and read the results into a hash map.
 * 5. Return the HashMap as a .snapshot file.
 * Copyright 2009 Walmart.com. All rights reserved.
 * User: ncherukuri
 * Date: Dec 22, 2009
 * Time: 10:29:19 AM
 * <p/>
 * INFO: Load complete {CONF_DAL_LOGLEVEL=2, CONF_OMS_DB_MAX_WAIT_CLIENT=${CONF_DB_MAX_WAIT_CLIENT}, CONF_CAT_AVO_DB_MIN_CONNECTIONS=${CONF_DB_MIN_CONNECTIONS}, JAVA_HOME=${ROOT}/java, CONF_CAT_DB_HOST=jackhammer, CONF_OMS_AVO_DB_MIN_CONNECTIONS=${CONF_DB_MIN_CONNECTIONS}, CONF_SES_DB_MAX_WAIT_CLIENT=${CONF_DB_MAX_WAIT_CLIENT}, CONF_OMS_DB_MAX_WAIT_TIMEOUT=${CONF_DB_MAX_WAIT_TIMEOUT}, CONF_INV_DB_HOST=jackhammer, CONF_JMS_LISTENERS_RECONNECT_INTERVAL_IN_MINUTE=2, CONF_PPC_DB_PASSWORD=clm_user, CONF_DB_POOL_ALIAS=dalpool_oms,dalpool_oms_ssl,dalpool_oms_l2,dalpool_oms_avo,dalpool_catalog,dalpool_catalog_ssl,dalpool_catalog_l2,dalpool_catalog_avo,dalpool_inventory,dalpool_security,dalpool_session,dalpool_ppc, CONF_DB_MIN_CONNECTIONS=5, CONF_DAL_ADMIN_USER=admin, CONF_DAL_READ_SELECTOR=1, CONF_OMS_DB_MAX_IDLE_TIMEOUT=${CONF_DB_MAX_IDLE_TIMEOUT}, CONF_DAL_SERVER_TYPE=netty, CONF_INV_DB_MAX_CHECKOUT_TIMEOUT=${CONF_DB_MAX_CHECKOUT_TIMEOUT}, CONF_JMS_ACTIVEMQ_PASSWORD=null, CONF_OMS_DB_L2_MAX_CONNECTIONS=${CONF_DB_MAX_CONNECTIONS}, CONF_SEC_DB_MAX_IDLE_TIMEOUT=${CONF_DB_MAX_IDLE_TIMEOUT}, CONF_JSERV_SESSION_DB_INSTANCE=wmdevd2, CONF_JMS_IS_DURABLE_SUBSCRIBER=WMJMSAdminListener, CONF_JMS_LISTENERS=WMJMSAdminListener, CONF_DAL_NS_URL=null, CONF_DB_POOL_DISABLE_XA_RECOVERY=true, CONF_JSERV_SESSION_DB_PASSWORD=web_user1, JAVA_LIB=${ROOT}/lib/java, CONF_JSERV_SESSION_DB_USER=web_user, CONF_SEC_DB_LOCK_TIMEOUT=${CONF_DB_LOCK_TIMEOUT}, CONF_OMS_DB_SSL_MAX_CONNECTIONS=${CONF_DB_MAX_CONNECTIONS}, SECURITY_DB_HOST=jackhammer, SECURITY_DB_INSTANCE=wmdevd2, CONF_INV_DB_MIN_CONNECTIONS=${CONF_DB_MIN_CONNECTIONS}, CONF_PPC_DB_USER=clm_user, CONF_SES_DB_MAX_WAIT_TIMEOUT=${CONF_DB_MAX_WAIT_TIMEOUT}, CONF_JMS_WMJMSAdminListener_AQ_SCHEMA=aq_inventory, CONF_USE_DEBUGGER=false, CONF_INV_DB_MAX_CHECKOUT=${CONF_DB_MAX_CHECKOUT}, CONF_OMS_DB_RETRY_INTERVAL=${CONF_DB_RETRY_INTERVAL}, CONF_JSERV_SESSION_DB_HOST=jackhammer, CONF_SEC_DB_MAX_WAIT_CLIENT=${CONF_DB_MAX_WAIT_CLIENT}, APPLICATION_DOMAIN_CODE=${APPLICATION}, CONF_SEC_DB_MAX_CONNECTIONS=5, CONF_SEC_DB_MIN_CONNECTIONS=0, CONF_SES_DB_RETRY_INTERVAL=${CONF_DB_RETRY_INTERVAL}, CONF_PPC_DB_MAX_CONNECTIONS=${CONF_DB_MAX_CONNECTIONS}, CONF_DB_MAX_CHECKOUT=1000000000, CONF_INV_DB_PASSWORD=wusedev, CONF_SEC_DB_URL=jdbc:oracle:thin:@${SECURITY_DB_HOST}:1521:${SECURITY_DB_INSTANCE}, CONF_CAT_DB_MAX_IDLE_TIMEOUT=${CONF_DB_MAX_IDLE_TIMEOUT}, HOMEWAREHOUSE_DB_INSTANCE=wmdevd2, CONF_DAL_HTTP_PORT=1730, JDK_NAME=java-1.6.0_13, CONF_USE_DEBUGGER_LEVEL=lines,source,vars, CONF_DAL_SERVER_MODE_ENABLED=true, CONF_INV_DB_URL=jdbc:oracle:thin:@${CONF_INV_DB_HOST}:1521:${CONF_INV_DB_INSTANCE}, JAVA=${JAVA_HOME}/bin/java, CONF_DAL_JMX_KEEP_ALIVE=300, CONF_DAL_NS_USER=null, CONF_SEC_DB_MAX_CHECKOUT=${CONF_DB_MAX_CHECKOUT}, CONF_INV_DB_RETRY_INTERVAL=${CONF_DB_RETRY_INTERVAL}, CONF_DB_RETRY_INTERVAL=30000, CONF_DAL_NS_PASSWORD=null, CONF_DB_MAX_WAIT_TIMEOUT=3000, CONF_CAT_DB_LOCK_TIMEOUT=${CONF_DB_LOCK_TIMEOUT}, CONF_PPC_DB_RETRY_INTERVAL=${CONF_DB_RETRY_INTERVAL}, CONF_DAL_HTTP_RESOURCEBASE=${ROOT}/htdocs/, CONF_DAL_NS_LBSERVER=null, HOMEWAREHOUSE_DB_USER=web_user, CONF_CAT_DB_RETRY_INTERVAL=${CONF_DB_RETRY_INTERVAL}, CONF_DB_MAX_CHECKOUT_TIMEOUT=120, CONF_JMS_WMJMSAdminListener_AQ_QUEUE_NAME=WebApp_queue_R0302, CONF_JMS_IS_AQ_ENABLED=false, CONF_DAL_SERVER_HOST_LIST=null, CONF_PPC_DB_MAX_CHECKOUT_TIMEOUT=${CONF_DB_MAX_CHECKOUT_TIMEOUT}, CONF_OMS_DB_URL=jdbc:oracle:thin:@${HOMEWAREHOUSE_DB_HOST}:1521:${HOMEWAREHOUSE_DB_INSTANCE}, DAL_HOME=${ROOT}, CONF_CAT_DB_PASSWORD=wuseqa, CONF_DB_LOCK_TIMEOUT=1800000, CONF_CAT_DB_SSL_MIN_CONNECTIONS=${CONF_DB_MIN_CONNECTIONS}, CONF_INV_DB_INSTANCE=wminvd1, CONF_CAT_DB_SSL_MAX_CONNECTIONS=${CONF_DB_MAX_CONNECTIONS}, CONF_CAT_DB_MAX_WAIT_TIMEOUT=${CONF_DB_MAX_WAIT_TIMEOUT}, MAX_IO_WORKER_THREADS=800, CONF_PPC_DB_MAX_WAIT_CLIENT=${CONF_DB_MAX_WAIT_CLIENT}, CONF_CAT_DB_USER=web_user, CONF_DAL_JMX_CORE_SIZE=10, CONF_JMS_LISTENERS_ENABLED=true, CONF_INV_DB_MAX_WAIT_CLIENT=${CONF_DB_MAX_WAIT_CLIENT}, DAL_SERVER_LB_REFRESH_INTERVAL=5, APPLICATION_ENVIRONMENT=${ENVIRONMENT}, CONF_DAL_THREADPOOL_TYPE=IO_BOUND, CONF_PPC_DB_MAX_WAIT_TIMEOUT=${CONF_DB_MAX_WAIT_TIMEOUT}, CONF_DAL_ADMIN_PASSWORD=admin, CONF_INV_DB_MAX_IDLE_TIMEOUT=${CONF_DB_MAX_IDLE_TIMEOUT}, ORACLE_CLASSES=classes9i_14.zip, CONF_INV_DB_USER=web_user, CONF_DAL_JMX_PORT=9099, CONF_DB_MAX_CONNECTIONS=15, DAL_IP=${HOSTIP}, CONF_DAL_CONNECTION_TIMEOUT=300, CONF_JMS_ACTIVEMQ_USER=null, CONF_SES_DB_MAX_CONNECTIONS=4, CONF_DB_MAX_IDLE_TIMEOUT=3600, CONF_JSERV_MAXMEM=1024, CONF_JMS_THROTTLED_TIMEOUT=250, CONF_PPC_DB_MAX_CHECKOUT=${CONF_DB_MAX_CHECKOUT}, CONF_OMS_DB_MIN_CONNECTIONS=${CONF_DB_MIN_CONNECTIONS}, CONF_JMS_TIMEOUT=30000, CONF_CAT_DB_URL=jdbc:oracle:thin:@${CONF_CAT_DB_HOST}:1521:${CONF_CAT_DB_INSTANCE}, CONF_JMS_ACTIVEMQ_URL=failover:(${CONF_JMS_ACTIVEMQ_CONN_URL})?randomize=false&initialReconnectDelay=100&maxReconnectDelay=5000, CONF_PPC_DB_MIN_CONNECTIONS=${CONF_DB_MIN_CONNECTIONS}, CONF_LOGFILE_DIR=/log, HOMEWAREHOUSE_DB_HOST=jackhammer, EXECUTOR_THREADS=10, CONF_OMS_DB_MAX_CHECKOUT=${CONF_DB_MAX_CHECKOUT}, CONF_OMS_DB_SSL_MIN_CONNECTIONS=${CONF_DB_MIN_CONNECTIONS}, CONF_CAT_DB_INSTANCE=wmpcatd1, CONF_CAT_DB_MAX_CHECKOUT=${CONF_DB_MAX_CHECKOUT}, CONF_CAT_DB_MAX_CHECKOUT_TIMEOUT=${CONF_DB_MAX_CHECKOUT_TIMEOUT}, CONF_CAT_DB_MAX_WAIT_CLIENT=${CONF_DB_MAX_WAIT_CLIENT}, CONF_INV_DB_MAX_WAIT_TIMEOUT=${CONF_DB_MAX_WAIT_TIMEOUT}, CONF_ROTATE_LOGS=false, CONF_OMS_DB_MAX_CONNECTIONS=${CONF_DB_MAX_CONNECTIONS}, CONF_DAL_THREADPOOL_KEEP_ALIVE=300, CONF_JMS_ACTIVEMQ_SEND_URL=fanout:(static:(${CONF_JMS_ACTIVEMQ_CONN_URL}))?minAckCount=1&initialReconnectDelay=100&maxReconnectDelay=5000, CONF_SES_DB_MAX_CHECKOUT=${CONF_DB_MAX_CHECKOUT}, HOSTIP=172.28.76.211, CONF_SEC_DB_MAX_CHECKOUT_TIMEOUT=${CONF_DB_MAX_CHECKOUT_TIMEOUT}, CONF_SES_DB_LOCK_TIMEOUT=${CONF_DB_LOCK_TIMEOUT}, KEYTOOL=${ROOT}/java/bin/keytool, CONF_OMS_DB_LOCK_TIMEOUT=${CONF_DB_LOCK_TIMEOUT}, CONF_DAL_THREADPOOL_QUEUE_SIZE=300, CONF_DAL_THREADPOOL_CORE_SIZE=100, SECURITY_DB_PASSWORD=web_user1, CONF_JMS_WMJMSAdminListener_FACTORY=com.wm.dal.jms.apps.WMMessageAdminFactory, CONF_CAT_DB_MIN_CONNECTIONS=${CONF_DB_MIN_CONNECTIONS}, CONF_JMS_WMJMSAdminListener_HANDLERS=com.wm.weblib.jms.common.WMMessageHandlerClearDBPool,  com.wm.dal.jms.apps.WMMessageHandlerPing, com.wm.weblib.jms.common.WMMessageHandlerSetConnectionPoolInfo, com.wm.weblib.jms.common.WMMessageHandlerDBPoolUrlKeys, CONF_INV_DB_LOCK_TIMEOUT=${CONF_DB_LOCK_TIMEOUT}, DAL_HOST=${HOSTNAME}.walmart.com, CONF_OMS_DB_MAX_CHECKOUT_TIMEOUT=${CONF_DB_MAX_CHECKOUT_TIMEOUT}, CONF_SES_DB_MAX_IDLE_TIMEOUT=${CONF_DB_MAX_IDLE_TIMEOUT}, CONF_PPC_JDBC_URL=jdbc:mysql://jackhammer:3306/clm, CONF_DB_MAX_WAIT_CLIENT=100, CONF_DAL_JMX_TYPE=CPU_BOUND, CONF_DAL_SERVER_COUNT=0, DAL_LB_ALGORITHM=com.wm.dal.server.health.NSActiveServers, CONF_JMS_STOP_ON_CONTEXT_RELOAD=false, CONF_PPC_DB_LOCK_TIMEOUT=${CONF_DB_LOCK_TIMEOUT}, CONF_MACHINE_CPU=${CPU}, CONF_DAL_WRITE_SELECTOR=1, CONF_DAL_JMX_MAX_SIZE=10, CONF_JMS_ACTIVEMQ_CONN_URL=tcp://jackhammer.walmart.com:61616, CONF_SUPPRESS_CATEGORY_NAMES=false, CONF_DAL_PORT=1729, CONF_OMS_AVO_DB_MAX_CONNECTIONS=${CONF_DB_MAX_CONNECTIONS}, CONF_SEC_DB_RETRY_INTERVAL=60000, DAL_SERVER_LB_ENABLED=true, CONF_CAT_DB_MAX_CONNECTIONS=${CONF_DB_MAX_CONNECTIONS}, CONF_MACHINE_OS=${OS}, CONF_PPC_DB_MAX_IDLE_TIMEOUT=${CONF_DB_MAX_IDLE_TIMEOUT}, JAVAC=${ROOT}/java/bin/javac, CONF_INV_DB_MAX_CONNECTIONS=${CONF_DB_MAX_CONNECTIONS}, CONF_DAL_THREADPOOL_MAX_SIZE=100, SECURITY_DB_USER=web_user, CONF_CAT_DB_L2_MIN_CONNECTIONS=${CONF_DB_MIN_CONNECTIONS}, HOMEWAREHOUSE_DB_PASSWORD=web_user1, CONF_DAL_BUFFER_SIZE=1024, CONF_JDK=${JDK_NAME}-${OS}-${ARCH}, CONF_CAT_DB_L2_MAX_CONNECTIONS=${CONF_DB_MAX_CONNECTIONS}, CONF_SES_DB_URL=jdbc:oracle:thin:@${CONF_JSERV_SESSION_DB_HOST}:1521:${CONF_JSERV_SESSION_DB_INSTANCE}, CONF_JMS_WMJMSAdminListener_JMS_TYPE=topic, CONF_PPC_ENABLE=true, CONF_DB_POOL_DISABLE_XA=true, CONF_SES_DB_MIN_CONNECTIONS=1, CONF_DAL_JMX_QUEUE_SIZE=1000, BRANCH_ROOT_DIR=${ROOT}, CONF_OMS_DB_L2_MIN_CONNECTIONS=${CONF_DB_MIN_CONNECTIONS}, CONF_DEBUGGER_PORT=5055, CONF_SES_DB_MAX_CHECKOUT_TIMEOUT=${CONF_DB_MAX_CHECKOUT_TIMEOUT}, CONF_CAT_AVO_DB_MAX_CONNECTIONS=${CONF_DB_MAX_CONNECTIONS}, CONF_JBOSS_OBJECT_STORE_DIR=${ROOT}/data/jboss_osd_${ENVIRONMENT}, CONF_MACHINE_ARCH=${ARCH}, CONF_SEC_DB_MAX_WAIT_TIMEOUT=${CONF_DB_MAX_WAIT_TIMEOUT}}
 */
public class LoadConfig {
    private static final Logger logger = Logger.getLogger(LoadConfig.class.getName());

    private static final String ARG_PREFIX_ENV = "--env=";
    private static final String ARG_PREFIX_APP = "--app=";
    private static final String ARG_PREFIX_SERVER = "--server=";
    private static final String ARG_PREFIX_DOMAIN = "--domain=";
    private static final String ARG_PREFIX_RELEASE = "--release=";

    private DataSource dataSource;

    private String domain;
    private String release;
    private String env;
    private String app;
    private String server;

    private String domainID;
    private String serverID;
    private List<String> physicalLayerList = new ArrayList<String>();
    private List<String> logicalLayerList = new ArrayList<String>();
    private List<String> physicalLayerIDList = new ArrayList<String>();
    private List<String> logicalLayerIDList = new ArrayList<String>();

    private HashMap<String, String> configMap = new HashMap<String, String>();

    public static final String REGEX_PATTERN = "\\$\\{([^\\}]*)\\}";
    public static final String INCL_FILE = "./makefile.incl";
    public static final String OS_FILE = "./.osprop.incl";
    public static final String MARCO_FILE = "./macros.m4";
    public static final String SNAP_FILE = "./.snapshot.config";
    public static final String TS_FILE = "./config_timestamp.gen";
    public static final String EQUALSTO = "=";

    private String overrideFile;

    private String retrieveServerIDSQL = " select server_id from server where name = ? and domain_id = ? and rel_version = ? and is_deleted = 'N'";
    private String retrieveDomainIDSQL = " select domain_id from domain where name = ? and rel_version = ? and is_deleted = 'N'";


    private static String retrieveConfigSQL = "select c.name, cv.value from config_value cv, config c, "
            + "(select cv2.config_id, cv2.physical_layer_id, cv2.logical_layer_id, cv2.server_id, max(cv2.created_dtm) dtm from config_value cv2  "
            + "group by cv2.config_id, cv2.physical_layer_id, cv2.logical_layer_id, cv2.server_id ) cv3   "
            + "where c.config_id = cv.config_id   "
            + "and c.rel_version = cv.rel_version "
            + "and c.is_deleted = 'N'      "
            + "and cv.created_dtm = cv3.dtm     "
            + "and cv3.config_id = cv.config_id       "
            + "and ((cv3.physical_layer_id IS NULL AND cv.physical_layer_id IS NULL) OR cv.physical_layer_id = cv3.physical_layer_id)    "
            + "and ((cv3.logical_layer_id IS NULL AND cv.logical_layer_id IS NULL) OR cv.logical_layer_id = cv3.logical_layer_id)   "
            + "and ((cv3.server_id IS NULL AND cv.server_id IS NULL) OR cv.server_id = cv3.server_id)    "
            + "and ((? IS NULL AND cv.physical_layer_id IS NULL) OR cv.physical_layer_id = ?)    "
            + "and ((? IS NULL AND cv.logical_layer_id IS NULL) OR cv.logical_layer_id = ?)    "
            + "and ((? IS NULL AND cv.server_id IS NULL) OR cv.server_id = ?)         "
            + "and c.rel_version = ?   "
            + "and c.domain_id = ? "
            + "and cv.is_deleted = 'N' ";

    public static void main(String[] args) throws Exception {
        LoadConfig configLoader = new LoadConfig();
        for (String arg : args) {
            if (arg.startsWith(ARG_PREFIX_DOMAIN)) {
                configLoader.setDomain(arg.substring(ARG_PREFIX_DOMAIN.length()));
            } else if (arg.startsWith(ARG_PREFIX_RELEASE)) {
                configLoader.setRelease(arg.substring(ARG_PREFIX_RELEASE.length()));
            } else if (arg.startsWith(ARG_PREFIX_ENV)) {
                configLoader.setEnv(arg.substring(ARG_PREFIX_ENV.length()));
            } else if (arg.startsWith(ARG_PREFIX_APP)) {
                configLoader.setApp(arg.substring(ARG_PREFIX_APP.length()));
            } else if (arg.startsWith(ARG_PREFIX_SERVER)) {
                configLoader.setServer(arg.substring(ARG_PREFIX_SERVER.length()));
            } else {
                if (arg.indexOf(EQUALSTO) != -1) {
                    configLoader.configMap.put(arg.substring(0, arg.indexOf(EQUALSTO)), arg.substring(arg.indexOf(EQUALSTO) + 1, arg.length()));

                }

            }
        }
        configLoader.flushOSProps();
        configLoader.setDataSource(createDataSource(configLoader.getEnv()));
        configLoader.initialize();
        configLoader.loadConfigMap();
        configLoader.applyOverrideConfig();
        configLoader.flush();
        configLoader.writeTmpStampFile();
    }

    private static DataSource createDataSource(String env) {
        try {
            FileInputStream fis = new java.io.FileInputStream(new java.io.File("conf/configdbprops/db.props."+ env));
            Properties props = new Properties();
            props.load(fis);
            fis.close();
            DriverManagerDataSource dataSource = new DriverManagerDataSource();
            dataSource.setDriverClassName(props.getProperty("DRIVER_CLASS_NAME"));
            dataSource.setUrl(props.getProperty("DB_CONN_STRING"));
            dataSource.setUsername(props.getProperty("USER_NAME"));
            dataSource.setPassword(props.getProperty("PASSWORD"));
            return dataSource;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void initialize() {

        logger.log(Level.CONFIG, "Initialize configMap load! ");
        applyOSProps();
        this.setDomainID(this.retrieveDomainID(domain, release));
        this.setServerID(this.retrieveServerID(server, domainID, release));
        this.getLogicalLayerList().addAll(Arrays.asList(app.split("/")));
        this.getPhysicalLayerList().addAll(Arrays.asList(env.split("/")));
        CheckNLoadPhysical checkPhysical = new CheckNLoadPhysical(dataSource, physicalLayerList, domainID, release, serverID);
        this.setPhysicalLayerIDList(checkPhysical.validateNLoad());
        CheckNLoadLogical checkLogical = new CheckNLoadLogical(dataSource, logicalLayerList, domainID, release);
        this.setLogicalLayerIDList(checkLogical.validateNLoad());
        logger.log(Level.CONFIG, "Initialize configMap complete! ");


    }

    private void applyOSProps() {
        logger.log(Level.INFO, "Loading the OS properties");
        try {
            File file = new File(OS_FILE);
            if (file.exists()) {
                FileInputStream in = new FileInputStream(file);
                Properties osProps = new Properties();
                osProps.load(in);
                for (String key : osProps.stringPropertyNames()) {
                    configMap.put(key, osProps.getProperty(key));
                }
            } else {
                throw new RuntimeException("Could not find the required file: " + OS_FILE);
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error loading the OS properties from: " + OS_FILE, e);
        }
    }

    public void loadConfigMap() {
        logger.log(Level.INFO, "Starting to Create Objects ");

        List<String> extendedPhysicalLayerIDs = new ArrayList<String>();
        extendedPhysicalLayerIDs.add("");
        extendedPhysicalLayerIDs.addAll(physicalLayerIDList);

        List<String> extendedLogicalLayerIDs = new ArrayList<String>();
        extendedLogicalLayerIDs.add("");
        extendedLogicalLayerIDs.addAll(logicalLayerIDList);

        for (String physicalLayerID : extendedPhysicalLayerIDs) {
            for (String logicalLayerID : extendedLogicalLayerIDs) {
                ConfigObject confObj = new ConfigObject(physicalLayerID, logicalLayerID, "", domainID, release);
                loadConfigForSpecificLayer(confObj);
            }
        }

        if (!"".equals(serverID)) for (String logicalLayerID : extendedLogicalLayerIDs) {
            ConfigObject confObj = new ConfigObject("", logicalLayerID, serverID, domainID, release);
            loadConfigForSpecificLayer(confObj);
        }
        logger.log(Level.INFO, "Load complete " + configMap.toString());
    }


    private void loadConfigForSpecificLayer(ConfigObject confObj) {
        try {
            Connection conn = dataSource.getConnection();
            conn.setAutoCommit(false);
            PreparedStatement preStmt = conn.prepareStatement(retrieveConfigSQL);

            preStmt.setString(1, confObj.getPhysicalLayer());
            preStmt.setString(2, confObj.getPhysicalLayer());
            preStmt.setString(3, confObj.getLogicalLayer());
            preStmt.setString(4, confObj.getLogicalLayer());
            preStmt.setString(5, confObj.getServer());
            preStmt.setString(6, confObj.getServer());
            preStmt.setString(7, confObj.getRelease());
            preStmt.setString(8, confObj.getDomain());
            ResultSet rs = preStmt.executeQuery();
            while (rs.next()) {
                configMap.put(rs.getString(1), rs.getString(2));
            }
            rs.close();
            preStmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Map<String, String> interpolate(Map<String, String> input) {
        Map<String, String> output = new HashMap<String, String>();
        // first add all entries without any variables
        // then iterate over each, check if not done, call doInterpolate w/ empty stack
        return output;
    }
    private void doInterpolate(Map<String, String> input, Map<String, String> output, String key, List<String> stack) {
        // if stack contains key - throw circular dependency error
        // break up value into patterns that need to be evaluated
        // add current key to the stack and make recursive call to doInterpolate
    }

    private String getValueDependency(String val) throws Exception {

        String returnVal = val;
        ArrayList<String> depends = null;
        if (val == null) return null;

        Matcher matcher = Pattern.compile(REGEX_PATTERN).matcher(val);
        while (matcher.find()) {
            if (depends == null) {
                depends = new ArrayList<String>();
            }
            depends.add(matcher.group());
        }

        if (depends != null) {
            for (String de : depends) {
                String dependKey = de.replaceAll("\\$\\{", "").replaceAll("\\}", "");
                String dependVal = (configMap.get(dependKey) != null ? configMap.get(dependKey) : "");                
                matcher = Pattern.compile(REGEX_PATTERN).matcher(dependVal);
                if(matcher.find()) dependVal = getValueDependency(dependVal);
                dependVal = Matcher.quoteReplacement(dependVal);
                returnVal = returnVal.replaceAll("\\$\\{" + dependKey + "\\}", dependVal);
            }
        }

        return returnVal;
    }

    public void writeTmpStampFile() {
        logger.log(Level.INFO, "Create TimeStampFile ");
        try {
            java.io.FileWriter f = new FileWriter(getConfigTimestampFilename(), true);
            f.write((new java.util.Date()).toString());
            f.flush();
            f.close();
        } catch (java.io.IOException ee) {
            logger.log(Level.SEVERE, null, ee);
            //ee.printStackTrace();
        }

    }

    private String getConfigTimestampFilename() {
        return TS_FILE ;
    }


    public void applyOverrideConfig() throws Exception {
        logger.log(Level.INFO, "Applying the overrides");
        try {
            Properties overrides = new OverridesManager().getProperties();
            for (String key : overrides.stringPropertyNames()) {
                configMap.put(key, overrides.getProperty(key));
            }
        } catch (Exception ex) {
            logger.log(Level.INFO, "ERROR: Failed to load override file: " + overrideFile, ex);
        }
    }

    public void flushOSProps() throws Exception {
        logger.log(Level.INFO, "Flush the OS Props file ");
        BufferedWriter output = null;
        try {
            output = new BufferedWriter(new FileWriter(OS_FILE));
            output.write("\n");
            if (configMap != null) {
                for (String key : configMap.keySet()) {
                    if (configMap.get(key) != null) {
                        String val = configMap.get(key);
                        output.write(key + "=" + val + "\n");
                    }
                }
            }
            else
            logger.log(Level.WARNING, "Empty OS Props file wriiten!");
            output.write("\n");
            output.flush();
        } catch (IOException ex) {
            logger.log(Level.SEVERE, null, ex);
            throw ex;
        } catch (Exception ex) {
            logger.log(Level.SEVERE, null, ex);
            throw ex;
        } finally {
            try {
                if (output != null) output.close();
            } catch (Exception ex) {
                logger.log(Level.SEVERE, null, ex);
            }
        }
    }

    public void flush() throws Exception {
        Set<String> keys = new TreeSet<String>(configMap.keySet());

        logger.log(Level.INFO, "Flush the o/p files ");
        BufferedWriter output = null;
        try {
            output = new BufferedWriter(new FileWriter(INCL_FILE));
            output.write("\n");
            for (String key : keys) {
                if (configMap.get(key) != null) {
                    if (configMap.get(key).contains("$")) {
                        String val = getValueDependency(configMap.get(key));
                        output.write("export " + key + "=" + val + "\n");
                    } else output.write("export " + key + "=" + configMap.get(key) + "\n");
                } else {
                    output.write("export " + key + "=" + "" + "\n");
                }
            }

            output.write("\n");
            output.write("M4_MACROS=\\\n");
            for (String key : keys) {
                output.write("-D" + key + "=\"${" + key + "}\"\\\n");
            }
            output.flush();

        } catch (IOException ex) {
            logger.log(Level.SEVERE, null, ex);
            throw ex;
        } catch (Exception ex) {
            logger.log(Level.SEVERE, null, ex);
            throw ex;
        } finally {
            try {
                output.close();
            } catch (Exception ex) {
                logger.log(Level.SEVERE, null, ex);
            }
        }

        try {
            output = new BufferedWriter(new FileWriter(MARCO_FILE));
            for (String key : keys) {
                if (configMap.get(key) != null) {
                    if (configMap.get(key).contains("$")) {
                        String val = getValueDependency(configMap.get(key));
                        output.write("define(`" + key + "', `" + val + "')dnl\n");
                    } else {
                        output.write("define(`" + key + "', `" + configMap.get(key) + "')dnl\n");
                    }
                } else {
                    output.write("define(`" + key + "', `')dnl\n");
                }
            }
            output.flush();

        } catch (IOException ex) {
            logger.log(Level.SEVERE, null, ex);
            throw ex;
        } catch (Exception ex) {
            logger.log(Level.SEVERE, null, ex);
            throw ex;
        } finally {
            try {
                output.close();
            } catch (Exception ex) {
                logger.log(Level.SEVERE, null, ex);
                ex.printStackTrace();
            }
        }

        try {
            output = new BufferedWriter(new FileWriter(SNAP_FILE));
            for (String key : keys) {
                if (configMap.get(key) != null) {
                    if (configMap.get(key).contains("$")) {
                        String val = getValueDependency(configMap.get(key));
                        output.write(key + "=" + val + "\n");
                    } else output.write(key + "=" + configMap.get(key) + "\n");
                } else {
                    output.write(key + "=" + "" + "\n");
                }
            }
            output.flush();

        } catch (IOException ex) {
            logger.log(Level.SEVERE, null, ex);
            throw ex;
        } catch (Exception ex) {
            logger.log(Level.SEVERE, null, ex);
            throw ex;
        } finally {
            try {
                output.close();
            } catch (Exception ex) {
                logger.log(Level.SEVERE, null, ex);
                ex.printStackTrace();
            }
        }

    }


    private String retrieveServerID(String server, String domainID, String release) {
        String serverID = "";
        try {
            Connection conn = dataSource.getConnection();
            conn.setAutoCommit(false);

            PreparedStatement preStmt = conn.prepareStatement(retrieveServerIDSQL);
            preStmt.setString(1, server);
            preStmt.setString(2, domainID);
            preStmt.setString(3, release);
            ResultSet rs = preStmt.executeQuery();
            if (rs.next()) {
                serverID = Integer.toString(rs.getInt(1));
            }
            rs.close();
            preStmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return serverID;
    }

    private String retrieveDomainID(String domain, String release) {
        String domainID = "";
        try {
            Connection conn = dataSource.getConnection();
            conn.setAutoCommit(false);

            PreparedStatement preStmt = conn.prepareStatement(retrieveDomainIDSQL);
            preStmt.setString(1, domain);
            preStmt.setString(2, release);
            ResultSet rs = preStmt.executeQuery();
            if (rs.next()) {
                domainID = Integer.toString(rs.getInt(1));
            }
            rs.close();
            preStmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return domainID;
    }

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getRelease() {
        return release;
    }

    public void setRelease(String release) {
        this.release = release;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public String getApp() {
        return app;
    }

    public void setApp(String app) {
        this.app = app;
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }

    public String getDomainID() {
        return domainID;
    }

    public void setDomainID(String domainID) {
        this.domainID = domainID;
    }

    public String getServerID() {
        return serverID;
    }

    public void setServerID(String serverID) {
        this.serverID = serverID;
    }

    public List<String> getPhysicalLayerList() {
        return physicalLayerList;
    }

    public void setPhysicalLayerList(List<String> physicalLayerList) {
        this.physicalLayerList = physicalLayerList;
    }

    public List<String> getLogicalLayerList() {
        return logicalLayerList;
    }

    public void setLogicalLayerList(List<String> logicalLayerList) {
        this.logicalLayerList = logicalLayerList;
    }

    public List<String> getPhysicalLayerIDList() {
        return physicalLayerIDList;
    }

    public void setPhysicalLayerIDList(List<String> physicalLayerIDList) {
        this.physicalLayerIDList = physicalLayerIDList;
    }

    public List<String> getLogicalLayerIDList() {
        return logicalLayerIDList;
    }

    public void setLogicalLayerIDList(List<String> logicalLayerIDList) {
        this.logicalLayerIDList = logicalLayerIDList;
    }

    public HashMap<String, String> getConfigMap() {
        return configMap;
    }

    public void setConfigMap(HashMap<String, String> configMap) {
        this.configMap = configMap;
    }
}
