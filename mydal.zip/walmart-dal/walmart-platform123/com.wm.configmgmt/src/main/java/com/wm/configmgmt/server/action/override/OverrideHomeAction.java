/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action.override;

import com.wm.configmgmt.server.action.AbstractDomainAction;
import com.wm.configmgmt.server.dataobject.LogicalLayer;
import com.wm.configmgmt.server.dataobject.PhysicalLayer;
import com.wm.configmgmt.server.service.LogicalLayerService;
import com.wm.configmgmt.server.service.PhysicalLayerService;

import java.util.ArrayList;
import java.util.List;

/**
 * OverrideHomeAction
 *
 * @author mkishore
 * @since 1.0
 */
public class OverrideHomeAction extends AbstractDomainAction {
    private LogicalLayerService logicalLayerService;
    private PhysicalLayerService physicalLayerService;

    private List<PhysicalLayer> physicalLayers = new ArrayList<PhysicalLayer>();
    private List<LogicalLayer> logicalLayers = new ArrayList<LogicalLayer>();

    public String home() {
        preparePhysicalLayers();
        prepareLogicalLayers();
        return SUCCESS;
    }

    private void preparePhysicalLayers() {
        physicalLayers = physicalLayerService.findRootLayersWithChildren(domain.getId(), domain.getReleaseVersion());
    }

    private void prepareLogicalLayers() {
        logicalLayers = logicalLayerService.findRootLayersWithChildren(domain.getId(), domain.getReleaseVersion());
    }

    public void setLogicalLayerService(LogicalLayerService logicalLayerService) {
        this.logicalLayerService = logicalLayerService;
    }

    public void setPhysicalLayerService(PhysicalLayerService physicalLayerService) {
        this.physicalLayerService = physicalLayerService;
    }

    public List<PhysicalLayer> getPhysicalLayers() {
        return physicalLayers;
    }

    public List<LogicalLayer> getLogicalLayers() {
        return logicalLayers;
    }

}