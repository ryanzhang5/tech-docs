/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.tools.parser;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This class is a complete replacement for the current configure.pl
 */
public class ConfigureXmlProcessor {
	
	private String confFile = null;
	private String overrideFile = null;
	private Document doc = null;
	
	
	private Properties osProp;
	private Properties appProp;
	private Properties overrideProp;
	
	//prop = osProp + appProp
	private SortedMap<String, String> prop;
	
	private HashMap<String, HashSet<String>> keysMap = new HashMap<String, HashSet<String>>();
	
	public static final String REGEX_PATTERN = "\\$\\{([^\\}]*)\\}";
	public static final String INCL_FILE  = "./makefile.incl.2";
	public static final String MARCO_FILE = "./macros.m4.2";
	public static final String SNAP_FILE = "./.snapshot.config.2";
	protected static final Logger logger = Logger.getLogger(ConfigureXmlProcessor.class.getName());
	
	public ConfigureXmlProcessor(String confFile, String oscontext) throws JDOMException, IOException, Exception{
		this(confFile, null, oscontext);
	}
	
	public ConfigureXmlProcessor(String confFile, String overrideFile, String oscontext) throws JDOMException, IOException, Exception{
		try{
			this.confFile = confFile;
			this.overrideFile=overrideFile;
			SAXBuilder builder = new SAXBuilder();
			doc =  builder.build(confFile);
			
			osProp = new Properties();
			setOSProperties(oscontext);
		
		}catch (JDOMException ex) {
			logger.log(Level.SEVERE, null, ex);
			throw ex;
		} catch (IOException ex) {
			logger.log(Level.SEVERE, null, ex);
			throw ex;
		}catch (Exception ex) {
			logger.log(Level.SEVERE, null, ex);
			throw ex;
		}
	}


    private void setOSProperties(String oscontext){
		String[] props =oscontext.split(";");
		for (String p : props) {
			osProp.put( p.substring(0, p.indexOf('=')), p.substring(p.indexOf('=')+1) );
		}
	}
	
	
	private void determinOverConfigs() throws Exception{
		if (overrideFile==null){
			String root = osProp.getProperty("ROOT");
        	String[] overrideFiles = getElementValueByName(doc, "configure  ->  overrides-file-search-path").split(":");
        	for (String file : overrideFiles) {
        		overrideFile = root+"/"+file.trim();
        		if(new File(overrideFile).exists() ){
        			break;
        		}
			}			
		}
		
		if(overrideFile ==null || ! new File(overrideFile).exists() ){
			logger.log(Level.WARNING, "override file: "+overrideFile+" not exist, will ignore override setting!");
			overrideFile = null;
			return;
		}

		overrideProp = new Properties();
        try  {
       		overrideProp.load( new FileInputStream(overrideFile) );
       		logger.log(Level.INFO, "Using override file: "+overrideFile);
        } catch (Exception ex) {
        	logger.log(Level.WARNING, "ERROR: Failed to load override file: "+overrideFile, ex);
        }
	}	
	
	
	/**
	 * 1) The following OS context which is NOT allowed to be overrides
	 * ROOT, OS, ARCH, CPU, APPLICATION, ENVIRONMENT, JDK_NAME
	 * 
	 * 2) The following OS context which is allowed to be overrides
	 * USER, HOSTIP, HOSTNAME, LIKE_HOST, GROUPS
	 */
	private void processOSProps() throws Exception{
		
		validateAppAndEnv();
		
		if(overrideProp == null){
			return;
		}
		
		overrideNotAllowedValidate("ROOT");
		overrideNotAllowedValidate("OS");
		overrideNotAllowedValidate("ARCH");
		overrideNotAllowedValidate("CPU");
		overrideNotAllowedValidate("APPLICATION");
		overrideNotAllowedValidate("ENVIRONMENT");
		overrideNotAllowedValidate("JDK_NAME");
		
		overrideProps("USER",      osProp, overrideProp, overrideFile);
		overrideProps("HOSTIP",    osProp, overrideProp, overrideFile);
		overrideProps("HOSTNAME",  osProp, overrideProp, overrideFile);
		overrideProps("LIKE_HOST", osProp, overrideProp, overrideFile);
		overrideProps("GROUPS",    osProp, overrideProp, overrideFile);		
	}	

	private static void overrideProps(String key, Properties props, Properties overrideProps, String overrideFile) throws Exception{
		String osValue = props.getProperty(key);
		String overrideValue = overrideProps.getProperty(key);
		if(overrideValue!=null && !overrideValue.trim().equals(osValue) ){
			props.put(key, overrideValue);
			logger.log(Level.INFO, "overriding Properties: ["+key+"] '"+osValue+"' -> '"+overrideValue+"' from override file: "+overrideFile);
		}
	}	
	
	private void overrideNotAllowedValidate(String key) throws Exception{
		String osValue = osProp.getProperty(key);
		String overrideValue = overrideProp.getProperty(key);
		if(overrideValue!=null && !overrideValue.trim().equals(osValue) ){
			throw new Exception("Un-overridable Properties: ["+key+"] '"+osValue+"' -> '"+overrideValue+"' , please remove it from override file: "+overrideFile);
		}
	}

	private void validateAppAndEnv() throws Exception{
		boolean supportedAPP = false;
		String apps = getElementValueByName(doc, "configure  ->  applications");
		for (String app : apps.split(",")) {
			if (osProp.getProperty("APPLICATION").equals(app)) {
				supportedAPP=true;
				break;
			}
		}
		if(!supportedAPP){
			throw new Exception("OS Properties: [APPLICATION]='"+osProp.getProperty("APPLICATION")+"' IS NOT in supported scope: "+apps);
		}
		
		boolean supportedENV = false;
		String envs = getElementValueByName(doc, "configure  ->  environments");
		for (String env : envs.split(",")) {
			if (osProp.getProperty("ENVIRONMENT").equals(env)) {
				supportedENV=true;
				break;
			}
		}
		if(!supportedENV){
			throw new Exception("OS Properties: [ENVIRONMENT]='"+osProp.getProperty("ENVIRONMENT")+"' IS NOT in supported scope: "+envs);
		}
	}	
	



	private void processAppProps() throws Exception{
		parseAppKeys();
		
		if(overrideFile ==null) return;
		for (Iterator iterator =  overrideProp.keySet().iterator(); iterator.hasNext(); ) {
			String key =(String) iterator.next();
			if (appProp.containsKey(key)){
				overrideProps(key,    appProp, overrideProp, overrideFile);		
			}
		} 
	}
	

	/**
	 *   1) for each key, checking following:
	 *   a) check if the name of the key is conflicted with OS keys
	 *   b) check if there are some circular dependencies for this key
            NOTE: circular dependencies will be detected and error message will be printed.  For example, the following is illegal:
            <key name='BAD'     default='${TWO_BAD}' />
            <key name='TWO_BAD' default='${BAD}'     />	
            
	 *   2)Parse pattern is:
	 *   keys -> keygroup -> key -> (rule){0,n} -> keyval            
	 */	
	private void parseAppKeys() throws Exception{
		appProp = new Properties();
		
		List<Element> keygroups = doc.getRootElement().getChild("keys").getChildren();
		for (Element keygroup : keygroups) {
			if ( !"keygroup".equals(keygroup.getName()) ) continue;
			
			String groupName = keygroup.getAttributeValue("name");
			keysMap.put(groupName, new HashSet<String>());
			
			List<Element> keys = keygroup.getChildren();
			for (Element key : keys) {
				if ( !"key".equals(key.getName()) ) continue;
				
				String value = doParseKeyValue(key);
				
				String keyName = key.getAttributeValue("name");
				
				if( osProp.getProperty(keyName)!= null && !osProp.getProperty(keyName).equals(value) )
					throw new Exception("ERROR: Properties: ["+keyName+"]  IS an OS Property, value: "+osProp.getProperty(keyName)
							+", CAN NOT BE RESET by App keygroup keys: keygroup ["+groupName+"], key["+keyName+"], value: "+value);
				
				appProp.put(keyName, value);
				keysMap.get(groupName).add(keyName);
			}
		}
	}
	

	private String doParseKeyValue(Element key) throws Exception{
		String keyName = key.getAttributeValue("name");
		String defVal  = getValueDependency(key.getAttributeValue("default"), osProp, appProp, keyName);
		String value = null;
		
		List<Element> rules = key.getChildren();
		for (Element rule : rules) {

			String valueByRule = doParseKeyValueByRule(keyName, rule);
			if(valueByRule != null){
				value = valueByRule;
			}
		}
		
		if(value==null){
			return (defVal != null ? defVal : "" );
		}else{
			return value;
		}
	}
	
	
	private String doParseKeyValueByRule(String keyName, Element rule) throws Exception{
		String returnVal = null;
		//<rule type="exact" var="APPLICATION" val="AVOCADO">
		//check if this is a rule 
		if ( !"rule".equals(rule.getName()) )
			throw new Exception("ERROR: Can't determin Element "+rule.getName()+" for key:" + keyName);
			
		String ruleType = rule.getAttributeValue("type");
		String ruleVar = rule.getAttributeValue("var");
		String ruleVal = rule.getAttributeValue("val");	
		
		if(ruleType==null || (!ruleType.equals("regex") && !ruleType.equals("exact")) )
			throw new Exception("ERROR: role type is not regex / exact , but : "+ ruleType + " for key:" + keyName);
		
		if(ruleVar==null )
			throw new Exception("ERROR: role Attribute [var] can't be Null for key:" + keyName);
		String valueFromProp = ( osProp.getProperty(ruleVar)!=null ? osProp.getProperty(ruleVar) : appProp.getProperty(ruleVar) );
		if(valueFromProp==null )
			throw new Exception("ERROR: Can't find dependent var="+ruleVar+" for roles for key:" + keyName);
		
		if(ruleVal==null )
			throw new Exception("ERROR: role Attribute [val] can't be Null for key:" + keyName);
		
		ruleVal = getValueDependency(ruleVal, osProp, appProp, keyName);	
		boolean matchCurrentRule = false;

		
		if(ruleType.equals("exact")){
			if( ruleVal.equals(valueFromProp) ){
				matchCurrentRule = true;
			}
		}else if(ruleType.equals("regex")){
			if( Pattern.matches(ruleVal, valueFromProp)  ){
				matchCurrentRule = true;
			}
		}
		
		if(matchCurrentRule){
			if ( rule.getChildren()!=null && rule.getChildren().size()==1 && rule.getChild("keyval")!=null ){
				String keyValVal = rule.getChild("keyval").getAttributeValue("val");
				if(keyValVal==null )
					throw new Exception("ERROR: keyval Attribute [val] can't be Null for key:" + keyName);

				returnVal = getValueDependency(keyValVal, osProp, appProp, keyName);				
			}else{
				List<Element> subRules = rule.getChildren();
				for (Element sub : subRules) {
					String subVal = doParseKeyValueByRule(keyName, sub);
					if(subVal!=null){
						returnVal = subVal;
					}
				}
			}
			
		}else{
			returnVal=null;
		}
		
		return returnVal;

	}

	
	private static String getValueDependency(String val, Properties os, Properties app, String keyname) throws Exception{
		
		String returnVal = val;
		ArrayList<String> depends = null;
		if(val==null) return null;
		
        Matcher matcher = Pattern.compile(REGEX_PATTERN).matcher(val);
        while(matcher.find()){
        	if(depends == null){
        		depends = new ArrayList<String>();
        	}
        	depends.add(matcher.group());
        }
        
        if (depends != null){
        	for (String de : depends) {
				String dependKey = de.replaceAll("\\$\\{", "").replaceAll("\\}", "");
				String dependVal = ( os.getProperty(dependKey) != null ? os.getProperty(dependKey) : app.getProperty(dependKey) );
				if(dependVal == null){
					throw new Exception("ERROR: Can't determine dependent Property: "+ de + " for key: "+keyname);
				}
				returnVal = returnVal.replaceAll("\\$\\{"+dependKey+"\\}", dependVal);
			}
        }
		
		return returnVal;
	}	
	
	
	public void parse() throws Exception{
		
		try {
			determinOverConfigs();
			processOSProps();			
			processAppProps();	
			
			Properties p = new Properties();
			p.putAll(osProp);
			p.putAll(appProp);
			prop = new TreeMap(p);
			
		}catch (JDOMException ex) {
			logger.log(Level.SEVERE, null, ex);
			throw ex;
		} catch (IOException ex) {
			logger.log(Level.SEVERE, null, ex);
			throw ex;
		}catch (Exception ex) {
			logger.log(Level.SEVERE, null, ex);
			throw ex;
		}
	}
	
	public Properties getOsProperties(){
		return new Properties(osProp);
	}
	public Properties getAppProperties(){
		return new Properties(appProp);
	}
	public Properties getAllProperties(){
		Properties all = new Properties();
		all.putAll(osProp);
		all.putAll(appProp);
		return all;
	}
	public HashMap<String, HashSet<String>> getKeyGroups(){
		return keysMap;
	}	
	public void output() throws Exception{
		
		BufferedWriter output = null;
		try {
		    output = new BufferedWriter(new FileWriter(INCL_FILE));
		    output.write("\n");
		    for (Iterator<String> iterator = prop.keySet().iterator(); iterator.hasNext();) {
		    	String key = iterator.next();
		        output.write( "export "+ key + "=" + prop.get(key) +"\n");
			}
		    
		    output.write("\n");
		    output.write("M4_MACROS=\\\n");
		    for (Iterator<String> iterator = prop.keySet().iterator(); iterator.hasNext();) {
		    	String key = iterator.next();
		        output.write( "-D"+ key + "=\"${" + key +"}\"\\\n");
			}
		    output.flush();

		} catch (IOException ex) {
			logger.log(Level.SEVERE, null, ex);
			throw ex;
		}catch (Exception ex) {
			logger.log(Level.SEVERE, null, ex);
			throw ex;
		}finally{
			try{
				output.close();
			}catch (Exception ex) {}
		}
		
		try {
		    output = new BufferedWriter(new FileWriter(MARCO_FILE));
		    for (Iterator<String> iterator = prop.keySet().iterator(); iterator.hasNext();) {
		    	String key = iterator.next();
		        output.write( "define(`"+ key + "', `" + prop.get(key) +"')dnl\n");
			}
		    output.flush();

		} catch (IOException ex) {
			logger.log(Level.SEVERE, null, ex);
			throw ex;
		}catch (Exception ex) {
			logger.log(Level.SEVERE, null, ex);
			throw ex;
		}finally{
			try{
				output.close();
			}catch (Exception ex) {}
		}		
	
		try {
		    output = new BufferedWriter(new FileWriter(SNAP_FILE));
		    for (Iterator<String> iterator = prop.keySet().iterator(); iterator.hasNext();) {
		    	String key = iterator.next();
		        output.write( key + "=" + prop.get(key) +"\n");
			}
		    output.flush();

		} catch (IOException ex) {
			logger.log(Level.SEVERE, null, ex);
			throw ex;
		}catch (Exception ex) {
			logger.log(Level.SEVERE, null, ex);
			throw ex;
		}finally{
			try{
				output.close();
			}catch (Exception ex) {}
		}			
		
	}
	
	
	
	
	private static String getElementValueByName(Document doc, String location) throws Exception{
		Element e =null;
		String[] path = location.split(" -> ");
		try {
			for (int i = 0; i < path.length; i++) {
				if(i==0) {
					e = doc.getRootElement();
				}else{
					e = e.getChild(path[i].trim());
				}
			}
		} catch (Exception ex) {
			logger.log(Level.SEVERE, "Error: invalid location for element search: "+location, ex);
			throw ex;
		}	
		return e.getText();
	}	
	
	
	
	
	
	
	
	private static void printXMLTree(Element e, int treeDepth) throws JDOMException, IOException{
		//if(treeDepth==1)
		System.out.println(getPrefix(treeDepth) + e.getName() );
		
		List<Element> children = e.getChildren();
		for (Element child : children) {
			printXMLTree(child, treeDepth+1);
		}				
	}
	
	private static String getPrefix(int treeDepth){
		if (treeDepth==0) return "";
		
		StringBuffer prefix = new StringBuffer();
		for(int i=treeDepth; i>0; i--){
			prefix.append(" + ");
		}
		return prefix.toString();
	}
	
	
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		if (args==null || args.length <1){
			logger.log(Level.WARNING, "ERROR: NO PARAMETER FOUND !\n"
					+"      USAGE: ./ConfigureXmlProcessor <os_context_properties>");
			return;
		}
		
		try {
		    ConfigureXmlProcessor xmlProcessor = new ConfigureXmlProcessor("./configure.xml", "./../etc/.overrides.config", args[0]);
//			xmlProcessor.setOverridesFile("./a.overrides.config");
			xmlProcessor.parse();
			xmlProcessor.output();
			
			logger.log(Level.INFO, "\n"
					+"configure - walmart.com\n"
					+"\n"
					+"Configuring:\n"
					+"APPLICATION = "+ xmlProcessor.getAllProperties().getProperty("APPLICATION")+"\n"
					+"ENVIRONMENT = "+ xmlProcessor.getAllProperties().getProperty("ENVIRONMENT")+"\n"
					+"ROOT        = "+ xmlProcessor.getAllProperties().getProperty("ROOT")+"\n"
					+"\n"
					+"Done	\n"
					);

		}catch (Exception ex) {}
	}

}
