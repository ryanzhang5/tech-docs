/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dataobject;

import java.sql.Timestamp;

/**
 * ConfigValue - Stores the actual values for the configuration attributes.
 * This table stores both the default value for a given attribute, as well as any overrides
 * specified for a given combination of physical and logical layers.
 * e.g. CONF_DAL_PORT = 1729 (default), and CONF_DAL_PORT = 1731 (for ZDR servers).
 *
 * There are no deletes for this table - all changes (updates and deletes) are captured as inserts.
 * The selects need to filter by MAX created_dtm
 *
 * @author mkishore
 * @since 1.0
 */
public class ConfigValue extends BaseDO implements IVersionedDO, Cloneable {
    private VersionedKey PK = new VersionedKey();
    private Config config;
    private Long configId;
    private PhysicalLayer physicalLayer;
    private Long physicalLayerId;
    private LogicalLayer logicalLayer;
    private Long logicalLayerId;
    private Server server;
    private Long serverId;
    private String value;
    private String CCReference;
    private String createdBy;
    private Timestamp createdDTM;
    private boolean deleted;

    public VersionedKey getPK() {
        return PK;
    }

    public void setPK(VersionedKey PK) {
        this.PK = PK;
    }

    public Long getId() {
        return PK.getId();
    }

    public void setId(Long id) {
        PK.setId(id);
    }

    public String getReleaseVersion() {
        return PK.getReleaseVersion();
    }

    public void setReleaseVersion(String releaseVersion) {
        PK.setReleaseVersion(releaseVersion);
    }

    public Long getConfigId() {
        return configId;
    }

    public void setConfigId(Long configId) {
        this.configId = configId;
    }

    public Config getConfig() {
        return config;
    }

    public void setConfig(Config config) {
        this.config = config;
        configId = (config != null) ? config.getId() : null;
    }

    public Long getPhysicalLayerId() {
        return physicalLayerId;
    }

    public void setPhysicalLayerId(Long physicalLayerId) {
        this.physicalLayerId = physicalLayerId;
    }

    public PhysicalLayer getPhysicalLayer() {
        return physicalLayer;
    }

    public void setPhysicalLayer(PhysicalLayer physicalLayer) {
        this.physicalLayer = physicalLayer;
        physicalLayerId = (physicalLayer != null) ? physicalLayer.getId() : null;
    }

    public Long getLogicalLayerId() {
        return logicalLayerId;
    }

    public void setLogicalLayerId(Long logicalLayerId) {
        this.logicalLayerId = logicalLayerId;
    }

    public LogicalLayer getLogicalLayer() {
        return logicalLayer;
    }

    public void setLogicalLayer(LogicalLayer logicalLayer) {
        this.logicalLayer = logicalLayer;
        this.logicalLayerId = (logicalLayer != null) ? logicalLayer.getId() : null;
    }

    public Long getServerId() {
        return serverId;
    }

    public void setServerId(Long serverId) {
        this.serverId = serverId;
    }

    public Server getServer() {
        return server;
    }

    public void setServer(Server server) {
        this.server = server;
        this.serverId = (server != null) ? server.getId() : null;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getCCReference() {
        return CCReference;
    }

    public void setCCReference(String CCReference) {
        this.CCReference = CCReference;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDTM() {
        return createdDTM;
    }

    public void setCreatedDTM(Timestamp createdDTM) {
        this.createdDTM = createdDTM;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public Object clone() throws CloneNotSupportedException {
    	return super.clone();
    }
}