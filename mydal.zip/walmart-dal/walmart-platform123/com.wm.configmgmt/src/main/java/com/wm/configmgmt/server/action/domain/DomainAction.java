/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action.domain;

import com.wm.configmgmt.server.action.AbstractUserAction;
import com.wm.configmgmt.server.dataobject.Domain;
import com.wm.configmgmt.server.service.DomainService;
import com.wm.configmgmt.server.service.DuplicateException;
import org.apache.struts2.interceptor.SessionAware;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.io.InputStream;
import java.io.ByteArrayInputStream;

/**
 * DomainAction
 *
 * @author mkishore
 * @since 1.0
 */
public class DomainAction extends AbstractUserAction implements SessionAware {
    private static final String DOMAIN = "WM_DOMAIN"; // @see DomainInterceptor
    private static final String CC_REFERENCE = "WM_CC_REFERENCE"; // @see DomainInterceptor

    private DomainService domainService;
    private String CCReference;
    private String upgradeVersion;

    private Domain domain = new Domain();
    private Map<String, Object> session = new HashMap<String, Object>();

    private InputStream exportOutput;

    public String view() {
        domain = domainService.find(domain.getId(), domain.getReleaseVersion());
        session.put(DOMAIN, domain);
        return SUCCESS;
    }

    public String add() {
        return SUCCESS;
    }

    public String edit() {
        domain = domainService.find(domain.getId(), domain.getReleaseVersion());
        return SUCCESS;
    }

    public String save() {
        Timestamp now = new Timestamp(System.currentTimeMillis());
        if (!isNew()) {
            Domain input = domain;
            domain = domainService.find(domain.getId(), domain.getReleaseVersion());
            domain.setName(input.getName());
            domain.setDescription(input.getDescription());
            domain.setLocked(input.isLocked());
        } else {
            domain.setCreatedBy(user.getUsername());
            domain.setCreatedDTM(now);
        }
        domain.setModifiedBy(user.getUsername());
        domain.setModifiedDTM(now);
        try {
            domainService.save(domain);
        } catch (DuplicateException e) {
            addActionError("Please enter a unique " + e.getProperty() + ".");
            return INPUT;
        }
        return SUCCESS;
    }

    public String delete() {
        Timestamp now = new Timestamp(System.currentTimeMillis());
        domain = domainService.find(domain.getId(), domain.getReleaseVersion());
        if (domain != null && !domain.isLocked()) {
            domainService.delete(domain.getId(), domain.getReleaseVersion(), user.getUsername(), now, CCReference);
        }
        return SUCCESS;
    }

    public String upgrade() {
        try {
            domainService.upgrade(domain.getId(), domain.getReleaseVersion(), upgradeVersion, user.getUsername());
            return SUCCESS;
        } catch (DuplicateException e) {
            throw new RuntimeException(e);
        }
    }

    public String export() {
        String xml = domainService.export(domain.getId(), domain.getReleaseVersion());
        exportOutput = new ByteArrayInputStream(xml.getBytes());
        return SUCCESS;
    }

    public InputStream getExportOutput() {
        return exportOutput;
    }

    public String changeCCReference() {
        session.put(CC_REFERENCE, CCReference);
        return SUCCESS;
    }

    public boolean isNew() {
        return domain.getId() == null;
    }


    public void setDomainService(DomainService domainService) {
        this.domainService = domainService;
    }

    public Domain getDomain() {
        return domain;
    }

    public void setId(long id) {
        domain.setId(id);
    }

    public void setReleaseVersion(String releaseVersion) {
        domain.setReleaseVersion(releaseVersion);
    }

    public void setCCReference(String CCReference) {
        this.CCReference = CCReference;
    }

    public void setSession(Map<String, Object> session) {
        this.session = session;
    }

    public void setUpgradeVersion(String upgradeVersion) {
        this.upgradeVersion = upgradeVersion;
    }
}