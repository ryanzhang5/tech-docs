/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action;

import com.wm.configmgmt.server.security.User;

/**
 * IUserAware
 *
 * @author mkishore
 * @since 1.0
 */
public interface IUserAware {
    public void setUser(User user);
}
