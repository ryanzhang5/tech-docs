/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dataobject;

import java.sql.Timestamp;

/**
 * ISoftDeletable - the DOs that are soft-deleted (flagged) as opposed to real deletes.
 *
 * @author mkishore
 * @since 1.0
 */
public interface ISoftDeletable extends IBaseDO {
    /**
     * Returns true if the DO represents a deleted element.
     * @return true if the DO represents a deleted element.
     */
    boolean isDeleted();

    /**
     * Marks the DO as deleted (or not) as per the parameter.
     * @param deleted - true, if you wish to mark the DO as deleted.
     */
    void setDeleted(boolean deleted);

    /**
     * This allows the DAO to track the time when the entity is deleted
     * @param modifiedTM
     */
    void setModifiedDTM(Timestamp modifiedTM);
}
