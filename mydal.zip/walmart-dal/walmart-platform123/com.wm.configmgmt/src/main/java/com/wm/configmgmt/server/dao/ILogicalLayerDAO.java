/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.LogicalLayer;
import com.wm.configmgmt.server.dataobject.VersionedKey;

/**
 * ILogicalLayerDAO
 *
 * @author mkishore
 * @since 1.0
 */
public interface ILogicalLayerDAO extends IBaseDAO<LogicalLayer, VersionedKey> {

}