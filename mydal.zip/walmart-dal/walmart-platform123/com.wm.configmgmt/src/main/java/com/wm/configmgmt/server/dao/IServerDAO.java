/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.Server;
import com.wm.configmgmt.server.dataobject.VersionedKey;

/**
 * IServerDAO
 *
 * @author mkishore
 * @since 1.0
 */
public interface IServerDAO extends IBaseDAO<Server, VersionedKey> {

}