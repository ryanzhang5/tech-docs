/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action.publish;

import com.wm.configmgmt.server.action.AbstractDomainAction;
import com.wm.configmgmt.server.dataobject.PublishRecord;
import com.wm.configmgmt.server.service.PublishRecordService;

import java.util.ArrayList;
import java.util.List;

/**
 * PublishListAction
 *
 * @author mkishore
 * @since 1.0
 */
public class PublishListAction extends AbstractDomainAction {
    private PublishRecordService publishRecordService;

    private List<PublishRecord> publishRecords = new ArrayList<PublishRecord>();

    public String list() {
        publishRecords = publishRecordService.findAll(domain.getId(), domain.getReleaseVersion());
        return SUCCESS;
    }

    public List<PublishRecord> getPublishRecords() {
        return publishRecords;
    }

    public void setPublishRecordService(PublishRecordService publishRecordService) {
        this.publishRecordService = publishRecordService;
    }

}