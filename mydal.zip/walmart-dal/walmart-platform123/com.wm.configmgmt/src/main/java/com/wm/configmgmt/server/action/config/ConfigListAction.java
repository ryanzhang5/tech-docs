/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action.config;

import com.wm.configmgmt.server.action.AbstractDomainAction;
import com.wm.configmgmt.server.dataobject.Config;
import com.wm.configmgmt.server.dataobject.ConfigGroup;
import com.wm.configmgmt.server.dataobject.NamedDOComparator;
import com.wm.configmgmt.server.service.ConfigService;

import java.util.*;

/**
 * ConfigListAction
 *
 * @author mkishore
 * @since 1.0
 */
public class ConfigListAction extends AbstractDomainAction {
    private ConfigService configService;

    private Map<String, List<Config>> configs = new HashMap<String, List<Config>>();

    public String list() {
        List<Config> list = configService.findAll(domain.getId(), domain.getReleaseVersion());
        Collections.sort(list, new NamedDOComparator());
        prepareConfigs(list);
        return SUCCESS;
    }

    public Map<String, List<Config>> getConfigs() {
        return configs;
    }

    public void setConfigService(ConfigService configService) {
        this.configService = configService;
    }

    private void prepareConfigs(List<Config> list) {
        configs.clear();
        for (Config config : list) {
            ConfigGroup group = config.getConfigGroup();
            String name = (group != null) ?group.getName() :"<Non-Grouped>";
            List<Config> sublist = configs.get(name);
            if (sublist == null) {
                sublist = new ArrayList<Config>();
                configs.put(name, sublist);
            }
            sublist.add(config);
        }
    }

}