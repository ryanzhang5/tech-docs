/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.service;

import com.wm.configmgmt.server.dao.IConfigValueDAO;
import com.wm.configmgmt.server.dataobject.*;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ConfigValueService
 *
 * @author mma
 * @since 1.0
 */
public class ConfigValueService {
    private IConfigValueDAO configValueDAO;

    private static final String EMPTY_STRING = "";

    @Transactional
    public List<ConfigValue> findAll(long configId, String releaseVersion) {
        String query = "select cv from ConfigValue cv"
                + " where cv.config.PK.id = ?1"
                + " and cv.config.PK.releaseVersion = ?2"
                ;
        List<ConfigValue> configValues = configValueDAO.findAllByQuery(query, configId, releaseVersion);
        return configValues;
    }

    @Transactional
    public List<AuditGroup> findAllAuditGroups(long domainId, String releaseVersion) {
        List<AuditGroup> auditGroups = configValueDAO.findAllAuditGroups(domainId, releaseVersion);
        return auditGroups;
    }

    @Transactional
    public List<AuditEntry> findAuditEntriesByCCReference(long domainId, String releaseVersion, String CCReference) {
        List<AuditEntry> auditEntries = configValueDAO.findAuditEntriesByCCReference(domainId, releaseVersion, CCReference);
        return auditEntries;
    }

    @Transactional
    public void rollbackByCCReference(long domainId, String releaseVersion, String CCReference,
                                      String newCCReference, String user) {
        Timestamp timestamp = configValueDAO.findMinDTMForCCReference(domainId, releaseVersion, CCReference);
        rollbackByTimestamp(domainId, releaseVersion, timestamp, newCCReference, user);
    }

    @Transactional
    public void rollbackByTimestamp(long domainId, String releaseVersion, Timestamp timestamp,
                                    String newCCReference, String user) {
        Map<ConfigValueAK, String> oldValues = prepareConfigValueMap(
                configValueDAO.findAllByNamedQuery("findConfigValues",
                        domainId, releaseVersion, nvl(timestamp)
                )
        );
        Map<ConfigValueAK, String> newValues = prepareConfigValueMap(
                configValueDAO.findAllByNamedQuery("findConfigValues",
                        domainId, releaseVersion, nvl(null)
                )
        );
        Timestamp now = new Timestamp(System.currentTimeMillis());
        List<ConfigValueAK> keys = configValueDAO.findConfigValueAKsSinceDTM(domainId, releaseVersion, timestamp);
        if (keys != null) for (ConfigValueAK ak : keys) {
            String oldValue = oldValues.get(ak);
            String newValue = newValues.get(ak);
            boolean insertValue = false;
            if (newValue != null) {
                if (oldValue == null || !newValue.equals(oldValue)) {
                    insertValue = true;
                }
            } else if (oldValue != null) {
                insertValue = true;
            }
            if (insertValue) {
                ConfigValue cv = new ConfigValue();
                cv.setReleaseVersion(releaseVersion);
                cv.setConfigId(ak.getConfigId());
                cv.setLogicalLayerId(ak.getLogicalLayerId());
                cv.setPhysicalLayerId(ak.getPhysicalLayerId());
                cv.setServerId(ak.getServerId());
                cv.setValue(oldValue);
                cv.setCCReference(newCCReference);
                cv.setCreatedBy(user);
                cv.setCreatedDTM(now);
                cv.setDeleted(oldValue == null);
                configValueDAO.insert(cv);
            }
        }
    }

    private Map<ConfigValueAK, String> prepareConfigValueMap(List<ConfigValue> list) {
        Map<ConfigValueAK, String> map = new HashMap<ConfigValueAK, String>();
        if (list != null) for (ConfigValue cv : list) {
            String value = cv.getValue();
            if (value == null) value = EMPTY_STRING;
            map.put(new ConfigValueAK(
                            cv.getConfigId(),
                            cv.getLogicalLayerId(),
                            cv.getPhysicalLayerId(),
                            cv.getServerId()), value);
        }
        return map;
    }

    @Transactional
    public List<ConfigValue> findConfigValuesForLayer(long domainId, String releaseVersion,
                                              Long logicalLayerId, Long physicalLayerId, Long serverId, Timestamp maxDTM) {
        List<ConfigValue> configValues = configValueDAO.findAllByNamedQuery("findConfigValuesForLayer",
                domainId, releaseVersion, nvl(logicalLayerId), nvl(physicalLayerId), nvl(serverId), nvl(maxDTM)
        );
        return configValues;
    }

    @Transactional
    public List<ConfigValue> findCurrentConfigValues(long domainId, String releaseVersion) {
        List<ConfigValue> configValues = configValueDAO.findAllByNamedQuery("findConfigValues",
                domainId, releaseVersion, nvl(null)
        );
        return configValues;
    }

    @Transactional
    public ConfigValue find(long id, String releaseVersion) {
        ConfigValue configValue = configValueDAO.findById(new VersionedKey(id, releaseVersion));
        return configValue;
    }
    
    @Transactional
    public ConfigValue findByName(String releaseVersion, Config config, PhysicalLayer physicalLayer, 
    						LogicalLayer logicalLayer, Server server) {
    	if (releaseVersion == null || "".equals(releaseVersion) || config == null) {
    		return null;
    	}
    	String query = "select o from ConfigValue o"
                + " where o.PK.releaseVersion = ?1 "
    			+ " and o.configId = ?2"
                + " and o.physicalLayerId = ?3 "
    			+ " and o.logicalLayerId = ?4"
                + " and o.serverId = ?5"
                + " order by o.createdDTM desc";
    	List<ConfigValue> list = configValueDAO.findAllByQuery(query, releaseVersion, config.getId(),
                (physicalLayer != null) ? physicalLayer.getId() : -1,
                (logicalLayer != null) ? logicalLayer.getId() : -1,
                (server != null) ? server.getId() : -1
        );
        ConfigValue result = (list != null && list.size() > 0) ? list.get(0) : null;
    	result = (result != null && !result.isDeleted()) ? result : null;
    	return result;
    }
    
    @Transactional
    public ConfigValue findWithChildren(long id, String releaseVersion) {
        ConfigValue configValue = configValueDAO.findById(new VersionedKey(id, releaseVersion));
        if (configValue != null) {
            ServiceUtil.initialize(configValue.getConfig());
            ServiceUtil.initialize(configValue.getLogicalLayer());
            ServiceUtil.initialize(configValue.getPhysicalLayer());
            ServiceUtil.initialize(configValue.getServer());
        }
        return configValue;
    }

    @Transactional
    public void save(ConfigValue configValue) {
        if (configValue.getId() == null) {
            configValueDAO.insert(configValue);
        } else {
            configValueDAO.update(configValue);
        }
    }

    @Transactional
    public void delete(long id, String releaseVersion, String user, Timestamp dtm, String CCReference) {
        ConfigValue configValue = configValueDAO.findById(new VersionedKey(id, releaseVersion));
        if (configValue != null) configValueDAO.delete(user, dtm, CCReference, configValue);
    }

    private static Object nvl(Object o) {
        return (o != null) ?o :"";
    }


    public void setConfigValueDAO(IConfigValueDAO configValueDAO) {
        this.configValueDAO = configValueDAO;
    }

}