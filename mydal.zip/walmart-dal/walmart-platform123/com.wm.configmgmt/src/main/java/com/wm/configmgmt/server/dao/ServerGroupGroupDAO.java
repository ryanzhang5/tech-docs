/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.ServerGroupGroup;
import com.wm.configmgmt.server.dataobject.VersionedKeyMulti;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * ServerGroupGroupDAO
 *
 * @author mkishore
 * @since 1.0
 */
public class ServerGroupGroupDAO extends BaseDAO<ServerGroupGroup, VersionedKeyMulti> implements IServerGroupGroupDAO {
    @PersistenceContext (name = "configmgmt")
    public void setEntityManager(EntityManager entityManager) {
        super.setEntityManager(entityManager);
    }
}