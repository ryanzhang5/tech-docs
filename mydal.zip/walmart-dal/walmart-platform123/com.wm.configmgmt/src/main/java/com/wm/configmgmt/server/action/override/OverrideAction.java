/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action.override;

import com.wm.configmgmt.server.action.AbstractDomainAction;
import com.wm.configmgmt.server.dataobject.Config;
import com.wm.configmgmt.server.dataobject.ConfigValue;
import com.wm.configmgmt.server.dataobject.NamedDOComparator;
import com.wm.configmgmt.server.service.ConfigService;
import com.wm.configmgmt.server.service.ConfigValueService;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * OverrideAction
 *
 * @author mkishore
 * @since 1.0
 */
public class OverrideAction extends AbstractDomainAction {
    private ConfigValueService configValueService;
    private ConfigService configService;

    private ConfigValue configValue = new ConfigValue();

    private List<Config> configs = new ArrayList<Config>();

    private Long configId;
    private Long logicalLayerId;
    private Long physicalLayerId;
    private Long serverId;

    public String add() {
        prepareConfigs();
        return SUCCESS;
    }

    public String edit() {
        if (configValue.getId() != null) {
            configValue = configValueService.find(configValue.getId(), domain.getReleaseVersion());
            configId = (configValue != null) ? configValue.getConfigId() : null;
        }
        return SUCCESS;
    }

    public String save() {
        Timestamp now = new Timestamp(System.currentTimeMillis());
        if (!isNew()) {
            ConfigValue input = configValue;
            configValue = configValueService.find(configValue.getId(), domain.getReleaseVersion());
            configValue.setValue(input.getValue());
        } else {
            configValue.setReleaseVersion(domain.getReleaseVersion());
            configValue.setConfigId(configId);
            configValue.setLogicalLayerId(logicalLayerId);
            configValue.setPhysicalLayerId(physicalLayerId);
            configValue.setServerId(serverId);
        }
        configValue.setCCReference(CCReference);
        configValue.setCreatedBy(user.getUsername());
        configValue.setCreatedDTM(now);

        configValueService.save(configValue);
        return SUCCESS;
    }

    public String delete() {
        Timestamp now = new Timestamp(System.currentTimeMillis());
        configValueService.delete(configValue.getId(), configValue.getReleaseVersion(), user.getUsername(), now, CCReference);
        return SUCCESS;
    }

    public boolean isNew() {
        return configValue.getId() == null;
    }

    private void prepareConfigs() {
        configs = configService.findAll(domain.getId(), domain.getReleaseVersion());
        Collections.sort(configs, new NamedDOComparator());
    }

    public void setConfigValueService(ConfigValueService configValueService) {
        this.configValueService = configValueService;
    }

    public void setConfigService(ConfigService configService) {
        this.configService = configService;
    }

    public ConfigValue getConfigValue() {
        return configValue;
    }

    public void setId(Long id) {
        configValue.setId(id);
    }

    public void setReleaseVersion(String releaseVersion) {
        configValue.setReleaseVersion(releaseVersion);
    }

    public List<Config> getConfigs() {
        return configs;
    }

    public Long getConfigId() {
        return configId;
    }

    public void setConfigId(Long configId) {
        this.configId = configId;
    }

    public Long getLogicalLayerId() {
        return logicalLayerId;
    }

    public void setLogicalLayerId(Long logicalLayerId) {
        this.logicalLayerId = logicalLayerId;
    }

    public Long getPhysicalLayerId() {
        return physicalLayerId;
    }

    public void setPhysicalLayerId(Long physicalLayerId) {
        this.physicalLayerId = physicalLayerId;
    }

    public Long getServerId() {
        return serverId;
    }

    public void setServerId(Long serverId) {
        this.serverId = serverId;
    }

}