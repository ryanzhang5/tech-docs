/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.service;

import com.wm.configmgmt.server.dao.IServerGroupDAO;
import com.wm.configmgmt.server.dao.IServerGroupGroupDAO;
import com.wm.configmgmt.server.dao.IServerGroupServerDAO;
import com.wm.configmgmt.server.dataobject.*;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * ServerGroupService
 *
 * @author mma
 * @since 1.0
 */
public class ServerGroupService {
    private IServerGroupDAO serverGroupDAO;
    private IServerGroupGroupDAO serverGroupGroupDAO;
    private IServerGroupServerDAO serverGroupServerDAO;

    @Transactional
    public List<ServerGroup> findAll(long domainId, String releaseVersion) {
        String query = "select sg from ServerGroup sg"
                + " where sg.domain.PK.id = ?1"
                + " and sg.domain.PK.releaseVersion = ?2"
                ;
        List<ServerGroup> serverGroups = serverGroupDAO.findAllByQuery(query, domainId, releaseVersion);
        return serverGroups;
    }

    @Transactional
    public ServerGroup find(long id, String releaseVersion) {
    	ServerGroup serverGroup = serverGroupDAO.findById(new VersionedKey(id, releaseVersion));
        return serverGroup;
    }
    
    @Transactional
    public List<ServerGroupServer> findAllParentsForServer(String releaseVersion, long serverId) {
        String query = "select sgs from ServerGroupServer sgs"
                + " where sgs.PK.releaseVersion = ?1"
                + " and sgs.PK.id1 = ?2"
                ;
        List<ServerGroupServer> serverGroupServers = serverGroupServerDAO.findAllByQuery(query, releaseVersion, serverId);
        return serverGroupServers;
    }
    
    @Transactional
    public List<ServerGroupGroup> findAllParentsForGroup(String releaseVersion, long childId) {
        String query = "select sgg from ServerGroupGroup sgg"
                + " where sgg.PK.releaseVersion = ?1"
                + " and sgg.PK.id1 = ?2"
                ;
        List<ServerGroupGroup> serverGroupGroups = serverGroupGroupDAO.findAllByQuery(query, releaseVersion, childId);
        return serverGroupGroups;
    }

    @Transactional
    public ServerGroup findWithChildren(long id, String releaseVersion) {
    	ServerGroup serverGroup = serverGroupDAO.findById(new VersionedKey(id, releaseVersion));
        if (serverGroup != null) {
        	ServiceUtil.initialize(serverGroup.getDomain());
            ServiceUtil.initialize(serverGroup.getChildGroups());
            Set<ServerGroupGroup> srvrGrupGrups = serverGroup.getChildGroups();
            if (srvrGrupGrups != null && srvrGrupGrups.size() > 0) {
	            for (ServerGroupGroup sgg : srvrGrupGrups) {
	            	ServiceUtil.initialize(sgg.getChildGroup());
	            }
            }
            ServiceUtil.initialize(serverGroup.getServers());
            Set<ServerGroupServer> srvrGrupSrvrs = serverGroup.getServers();
            if (srvrGrupSrvrs != null && srvrGrupSrvrs.size() > 0) {
            	for (ServerGroupServer sgs : srvrGrupSrvrs) {
            		ServiceUtil.initialize(sgs.getServer());
            	}
            }
        }
        return serverGroup;
    }
    
    @Transactional
    public ServerGroup findByName(long domainId, String releaseVersion, String name) {
    	if (name == null || "".equals(name) || releaseVersion == null || "".equals(releaseVersion)) {
    		return null;
    	}
    	String query = "select o from ServerGroup o"
                + " where o.domain.PK.id = ?1"
                + " and o.domain.PK.releaseVersion = ?2 "
                + " and o.name = ?3"
    		;
    	List<ServerGroup> list = serverGroupDAO.findAllByQuery(query, domainId, releaseVersion, name);
    	return (list != null && list.size() > 0) ? list.get(0) : null;
    }

    @Transactional
    public List<Server> findAllServersForGroup(Long serverGroupId, String releaseVersion) {
        List<Server> servers = serverGroupDAO.findAllServersForGroup(serverGroupId, releaseVersion);
        return servers;
    }

    @Transactional
    public void save(ServerGroup serverGroup) throws DuplicateException {
        ServerGroup namedDO = findByName(serverGroup.getDomainId(), serverGroup.getReleaseVersion(), serverGroup.getName());
        if (serverGroup.getId() == null) {
            if (namedDO != null) {
                throw new DuplicateException();
            }
            serverGroupDAO.insert(serverGroup);
        } else {
            if (namedDO != null && !namedDO.getId().equals(serverGroup.getId())) {
                throw new DuplicateException();
            }
            serverGroupDAO.update(serverGroup);
        }
    }

    @Transactional
    public void saveWithChildren(ServerGroup serverGroup, Collection<Long> groupIds, Collection<Long> serverIds) throws DuplicateException {
        boolean isUpdate = (serverGroup.getId() != null);
        save(serverGroup);
        if (isUpdate) serverGroup = findWithChildren(serverGroup.getId(), serverGroup.getReleaseVersion());
        updateChildGroups(serverGroup, groupIds);
        updateChildServers(serverGroup, serverIds);
    }

    @Transactional
    public void delete(long id, String releaseVersion) {
    	ServerGroup serverGroup = findWithChildren(id, releaseVersion);
    	if (serverGroup != null) {
	    	Set<ServerGroupGroup> childGroups = serverGroup.getChildGroups();
	    	if (childGroups != null && childGroups.size() > 0) {
                for (Iterator<ServerGroupGroup> it = childGroups.iterator(); it.hasNext();) {
                    ServerGroupGroup sgg = it.next();
                    if (sgg != null) {
                        serverGroupGroupDAO.delete(sgg);
                        it.remove();
                    }
                }
	        }
	    	Set<ServerGroupServer> childServers = serverGroup.getServers();
	    	if (childServers != null && childServers.size() > 0) {
                for (Iterator<ServerGroupServer> it = childServers.iterator(); it.hasNext();) {
                    ServerGroupServer sgs = it.next();
                    if (sgs != null) {
                        serverGroupServerDAO.delete(sgs);
                        it.remove();
                    }
                }
	    	}
            List<ServerGroupGroup> parentGroups = findAllParentsForGroup(serverGroup.getReleaseVersion(), serverGroup.getId());
            if (parentGroups != null && parentGroups.size() > 0) {
                for (ServerGroupGroup sgg : parentGroups) {
                    serverGroupGroupDAO.delete(sgg);
                }
            }
	    	serverGroupDAO.delete(serverGroup);
    	}
    }

    @Transactional
    public void deleteServer(long id, String releaseVersion) {
        List<ServerGroupServer> parentGroups = findAllParentsForServer(releaseVersion, id);
        if (parentGroups != null && parentGroups.size() > 0) {
            for (ServerGroupServer sgs : parentGroups) {
                serverGroupServerDAO.delete(sgs);
            }
        }
    }

    private void updateChildGroups(ServerGroup serverGroup, Collection<Long> newGroupIds) {
        Set<Long> oldGroupIds = new HashSet<Long>();
        Set<ServerGroupGroup> oldGroups = serverGroup.getChildGroups();
        if (oldGroups != null && oldGroups.size() > 0) {
	        for (ServerGroupGroup sgg : oldGroups) {
	            oldGroupIds.add(sgg.getChildGroupId());
	        }
        }
        if (newGroupIds != null && newGroupIds.size() > 0) {
	        for (Long id : newGroupIds) {
	            if (oldGroupIds.remove(id)) continue;
	
	            ServerGroupGroup sgg = new ServerGroupGroup();
	            sgg.setReleaseVersion(serverGroup.getReleaseVersion());
	            sgg.setServerGroup(serverGroup);
	            sgg.setChildGroupId(id);
	            sgg.setCreatedBy(serverGroup.getModifiedBy());
	            sgg.setCreatedDTM(serverGroup.getModifiedDTM());
	            serverGroupGroupDAO.insert(sgg);
	        }
        }
        if (oldGroups != null && oldGroups.size() > 0) {
	        for (Iterator<ServerGroupGroup> it = oldGroups.iterator(); !oldGroups.isEmpty() && it.hasNext();) {
	            ServerGroupGroup sgg = it.next();
	            if (oldGroupIds.contains(sgg.getChildGroupId())) {
	                it.remove();
	                serverGroupGroupDAO.delete(sgg);
	            }
	        }
        }
    }

    private void updateChildServers(ServerGroup serverGroup, Collection<Long> newServerIds) {
        Set<Long> oldServerIds = new HashSet<Long>();
        Set<ServerGroupServer> oldServers = serverGroup.getServers();
        if (oldServers != null && oldServers.size() > 0) {
	        for (ServerGroupServer sgs : oldServers) {
	            oldServerIds.add(sgs.getServerId());
	        }
        }
        if (newServerIds != null && newServerIds.size() > 0) {
	        for (Long id : newServerIds) {
	            if (oldServerIds.remove(id)) continue;
	
	            ServerGroupServer sgs = new ServerGroupServer();
	            sgs.setReleaseVersion(serverGroup.getReleaseVersion());
	            sgs.setServerGroup(serverGroup);
	            sgs.setServerId(id);
	            sgs.setCreatedBy(serverGroup.getModifiedBy());
	            sgs.setCreatedDTM(serverGroup.getModifiedDTM());
	            serverGroupServerDAO.insert(sgs);
	        }
        }
        if (oldServers != null && oldServers.size() > 0) {
	        for (Iterator<ServerGroupServer> it = oldServers.iterator(); !oldServers.isEmpty() && it.hasNext();) {
	            ServerGroupServer sgs = it.next();
	            if (oldServerIds.contains(sgs.getServerId())) {
	                it.remove();
	                serverGroupServerDAO.delete(sgs);
	            }
	        }
        }
    }

    public void setServerGroupDAO(IServerGroupDAO serverGroupDAO) {
        this.serverGroupDAO = serverGroupDAO;
    }

    public void setServerGroupGroupDAO(IServerGroupGroupDAO serverGroupGroupDAO) {
        this.serverGroupGroupDAO = serverGroupGroupDAO;
    }

    public void setServerGroupServerDAO(IServerGroupServerDAO serverGroupServerDAO) {
        this.serverGroupServerDAO = serverGroupServerDAO;
    }
    
}