/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.Server;
import com.wm.configmgmt.server.dataobject.ServerGroup;
import com.wm.configmgmt.server.dataobject.VersionedKey;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

/**
 * ServerGroupDAO
 *
 * @author mkishore
 * @since 1.0
 */
public class ServerGroupDAO extends SoftDeleteDAO<ServerGroup, VersionedKey> implements IServerGroupDAO {
    @PersistenceContext (name = "configmgmt")
    public void setEntityManager(EntityManager entityManager) {
        super.setEntityManager(entityManager);
    }

    public List<Server> findAllServersForGroup(Long serverGroupId, String releaseVersion) {
        Query query = createNamedQuery("findAllServersForGroup");
        query.setParameter(1, serverGroupId);
        query.setParameter(2, releaseVersion);
        return query.getResultList();
    }

    private Query createNamedQuery(String str) {
        Query query = getEntityManager().createNamedQuery(str);
        return query;
    }

}