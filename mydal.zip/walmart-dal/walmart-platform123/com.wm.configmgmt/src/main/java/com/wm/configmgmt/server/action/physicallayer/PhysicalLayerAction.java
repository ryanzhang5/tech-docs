/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action.physicallayer;

import com.opensymphony.xwork2.Preparable;
import com.wm.configmgmt.server.action.AbstractDomainAction;
import com.wm.configmgmt.server.dataobject.NamedDOComparator;
import com.wm.configmgmt.server.dataobject.PhysicalLayer;
import com.wm.configmgmt.server.dataobject.Server;
import com.wm.configmgmt.server.service.PhysicalLayerService;
import com.wm.configmgmt.server.service.ServerService;
import com.wm.configmgmt.server.service.DuplicateException;

import java.sql.Timestamp;
import java.util.*;

/**
 * PhysicalLayerAction
 *
 * @author mkishore
 * @since 1.0
 */
public class PhysicalLayerAction extends AbstractDomainAction implements Preparable {
    private PhysicalLayerService physicalLayerService;
    private ServerService serverService;

    private PhysicalLayer physicalLayer = new PhysicalLayer();

    private Long parentLayerId;
    private String parentLayerName;
    private Map<Long, String> availableServers = new LinkedHashMap<Long, String>();
    private Collection<Long> selectedServerIds = new ArrayList<Long>();

    public void prepare() throws Exception {
        // no-op
    }

    // this is actually an "Add Child" call
    public String add() {
        if (physicalLayer.getId() != null) {
            physicalLayer = physicalLayerService.find(physicalLayer.getId(), physicalLayer.getReleaseVersion());
        }
        if (physicalLayer == null) physicalLayer = new PhysicalLayer();
        parentLayerId = physicalLayer.getId();
        parentLayerName = physicalLayer.getName();
        physicalLayer = new PhysicalLayer();
        prepareAvailable();
        prepareSelected();
        return SUCCESS;
    }

    public String edit() {
        if (physicalLayer.getId() != null) {
            physicalLayer = physicalLayerService.findWithChildren(physicalLayer.getId(), physicalLayer.getReleaseVersion());
        }
        if (physicalLayer == null) physicalLayer = new PhysicalLayer();
        parentLayerId = physicalLayer.getParentLayerId();
        parentLayerName = (physicalLayer.getParentLayer() != null) ? physicalLayer.getParentLayer().getName() : null;
        prepareAvailable();
        prepareSelected();
        return SUCCESS;
    }

    // this should help us re-populate the form on error
    public void prepareSave() {
        prepareAvailable();
    }

    public String save() {
        Timestamp now = new Timestamp(System.currentTimeMillis());
        if (!isNew()) {
            PhysicalLayer input = physicalLayer;
            physicalLayer = physicalLayerService.find(physicalLayer.getId(), physicalLayer.getReleaseVersion());
            physicalLayer.setName(input.getName());
            physicalLayer.setDescription(input.getDescription());
        } else {
            physicalLayer.setDomain(domain);
            physicalLayer.setReleaseVersion(domain.getReleaseVersion());
            physicalLayer.setCreatedBy(user.getUsername());
            physicalLayer.setCreatedDTM(now);
        }
        physicalLayer.setModifiedBy(user.getUsername());
        physicalLayer.setModifiedDTM(now);

        try {
            physicalLayerService.saveWithChildren(physicalLayer, parentLayerId, selectedServerIds);
        } catch (DuplicateException e) {
            addActionError("Please enter a unique " + e.getProperty() + ".");
            return INPUT;
        }
        return SUCCESS;
    }

    public String delete() {
        physicalLayerService.delete(physicalLayer.getId(), physicalLayer.getReleaseVersion());
        return SUCCESS;
    }

    public boolean isNew() {
        return physicalLayer.getId() == null;
    }

    private void prepareAvailable() {
        availableServers.clear();
        List<Server> sList = serverService.findByPhysicalLayerOrNull(domain.getId(), domain.getReleaseVersion(), physicalLayer.getId());
        Collections.sort(sList, new NamedDOComparator());
        for (Server s : sList) {
            availableServers.put(s.getId(), s.getName());
        }
    }

    private void prepareSelected() {
        selectedServerIds.clear();
        List<Server> serverList = new ArrayList<Server>(physicalLayer.getServers());
        for (Server server : serverList) {
            selectedServerIds.add(server.getId());
        }
    }

    public void setPhysicalLayerService(PhysicalLayerService physicalLayerService) {
        this.physicalLayerService = physicalLayerService;
    }

    public void setServerService(ServerService serverService) {
        this.serverService = serverService;
    }

    public PhysicalLayer getPhysicalLayer() {
        return physicalLayer;
    }

    public void setId(Long id) {
        physicalLayer.setId(id);
    }

    public void setReleaseVersion(String releaseVersion) {
        physicalLayer.setReleaseVersion(releaseVersion);
    }

    public Long getParentLayerId() {
        return parentLayerId;
    }

    public void setParentLayerId(Long parentLayerId) {
        this.parentLayerId = parentLayerId;
    }

    public String getParentLayerName() {
        return (parentLayerName != null) ? parentLayerName : "Root";
    }

    public void setParentLayerName(String parentLayerName) {
        this.parentLayerName = parentLayerName;
    }

    public Map<Long, String> getAvailableServers() {
        return availableServers;
    }

    public Collection<Long> getSelectedServerIds() {
        return selectedServerIds;
    }

    public void setSelectedServerIds(Collection<Long> selectedServerIds) {
        this.selectedServerIds = selectedServerIds;
    }

}