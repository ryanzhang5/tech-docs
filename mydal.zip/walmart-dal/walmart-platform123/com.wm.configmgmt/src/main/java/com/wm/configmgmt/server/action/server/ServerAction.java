/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action.server;

import com.wm.configmgmt.server.action.AbstractDomainAction;
import com.wm.configmgmt.server.dataobject.Server;
import com.wm.configmgmt.server.service.ServerService;
import com.wm.configmgmt.server.service.DuplicateException;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ServerAction
 *
 * @author mkishore
 * @since 1.0
 */
public class ServerAction extends AbstractDomainAction {
    private ServerService serverService;

    private Server server = new Server();

    public String add() {
        return SUCCESS;
    }

    public String edit() {
        server = serverService.find(server.getId(), server.getReleaseVersion());
        return SUCCESS;
    }

    public String save() {
        Timestamp now = new Timestamp(System.currentTimeMillis());
        if (!isNew()) {
            Server copy = serverService.find(server.getId(), server.getReleaseVersion());
            copy.setName(server.getName());
            copy.setDescription(server.getDescription());
            copy.setModifiedBy(user.getUsername());
            copy.setModifiedDTM(now);
            try {
                serverService.save(copy);
            } catch (DuplicateException e) {
                addActionError("Please enter a unique " + e.getProperty() + ".");
            return INPUT;
            }
        } else {
            List<Server> copies = new ArrayList<Server>();
            for (String name : getAllNames(server.getName())) {
                Server copy = new Server();
                copy.setDomain(domain);
                copy.setReleaseVersion(domain.getReleaseVersion());
                copy.setName(name);
                copy.setDescription(server.getDescription());
                copy.setCreatedBy(user.getUsername());
                copy.setCreatedDTM(now);
                copy.setModifiedBy(user.getUsername());
                copy.setModifiedDTM(now);
                copies.add(copy);
            }
            try {
                serverService.save(copies.toArray(new Server[copies.size()]));
            } catch (DuplicateException e) {
                addActionError("Please enter a unique " + e.getProperty() + ".");
                return INPUT;
            }
        }
        return SUCCESS;
    }

    public String delete() {
        serverService.delete(server.getId(), server.getReleaseVersion());
        return SUCCESS;
    }

    public boolean isNew() {
        return server.getId() == null;
    }

    private static Pattern PATTERN = Pattern.compile("\\[(\\d+)-(\\d+)\\]");
    private List<String> getAllNames(String name) {
        List<String> ret = new ArrayList<String>();
        Matcher matcher = PATTERN.matcher(name);
        if (matcher.find()) {
            int min = Integer.parseInt(matcher.group(1));
            int max = Integer.parseInt(matcher.group(2));
            String prefix = name.substring(0, matcher.start());
            int end = matcher.end();
            String suffix = (end < name.length()) ?name.substring(end) :"";
            for (int i=min; i <= max; i++) {
                ret.addAll(getAllNames(prefix+i+suffix));
            }
        } else {
            ret.add(name);
        }
        return ret;
    }

    public void setServerService(ServerService serverService) {
        this.serverService = serverService;
    }

    public Server getServer() {
        return server;
    }

    public void setId(long id) {
        server.setId(id);
    }

    public void setReleaseVersion(String releaseVersion) {
        server.setReleaseVersion(releaseVersion);
    }

}