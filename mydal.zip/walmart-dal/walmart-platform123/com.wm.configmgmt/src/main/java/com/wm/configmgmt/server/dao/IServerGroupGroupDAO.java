/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.ServerGroupGroup;
import com.wm.configmgmt.server.dataobject.VersionedKeyMulti;

/**
 * IServerGroupGroupDAO
 *
 * @author mkishore
 * @since 1.0
 */
public interface IServerGroupGroupDAO extends IBaseDAO<ServerGroupGroup, VersionedKeyMulti> {

}