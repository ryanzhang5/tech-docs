/*
 * Copyright 2010 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.jms;

import com.wm.configmgmt.common.jms.WMMessageConfigChangeAck;
import com.wm.configmgmt.common.jms.WMMessageConfigChangeNotification;
import com.wm.weblib.jms.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

/**
 * WMMessageAdminFactory - mostly copied over the WWW/WEBLIB codebase
 *
 * @author mkishore
 * @since 1.0
 */
public class WMMessageAdminFactory extends MessageFactory {
    private static final Logger logger = Logger.getLogger(WMMessageAdminFactory.class.getName());

    /**
     * parses JMS text message and generates list of WMMessages.
     *
     * @param m JMS text message
     * @return list of WMMessages
     * @throws WMMessageException
     */
    public List<WMMessage> parseJMSTextMessage(javax.jms.TextMessage m) throws WMMessageException {

        try {
            String textMessage = m.getText();
            List<WMMessage> msgs = createMessage(textMessage);

            for (int i = 0; i < msgs.size(); i++) {
                WMMessage msg = msgs.get(i);
                int indx = m.getText().lastIndexOf("origin=");
                int lstIndx = m.getText().indexOf(",", indx);
                String origServer = (lstIndx == -1) ? m.getText().substring(indx + 7) : m.getText().substring(indx + 7, lstIndx);
                msg.setOriginServer(origServer);

                //createMessage doesn't have time stamp,
                //so set it from JMS message time stamp
                msg.setTimestamp(new Date(m.getJMSTimestamp()));
            }

            return msgs;

        } catch (javax.jms.JMSException e) {
            throw new WMMessageException(e.getMessage());
        }

    }

    public List<WMMessage> parseJMSObjectMessage(WMJMSObjectMessage message) throws WMMessageException {
        List<WMMessage> msgs = new ArrayList();

        HashMap<String, String> valueMap = new HashMap<String, String>();
        valueMap.put(WMMessage.MSG_TYPE_KEY, message.getMsgType());
        valueMap.put(WMMessage.ORIGIN, message.getOrigin());
        valueMap.put(WMMessage.TARGET, message.getTarget());

        WMMessage msg = getMessage(valueMap);

        //msg.setOriginServer(message.getOrigin());
        msg.setObjectMessage(message.getObjectMessage());

        msgs.add(msg);

        return msgs;
    }


    /**
     * parses text message and generates list of WMMessages.
     *
     * @param textMessage text message
     * @param targetRegex target host name if any
     * @return list of WMMessages
     * @throws WMMessageException
     */
    public List<WMMessage> createMessage(String textMessage, String targetRegex) throws WMMessageException {

        ArrayList msgs = new ArrayList();

        List<HashMap> valueMaps = WMMessageParser.parse(textMessage, targetRegex);

        for (int i = 0; i < valueMaps.size(); i++) {
            WMMessage msg = createMessage(valueMaps.get(i));
            msgs.add(msg);
        }

        return msgs;
    }


    /**
     * parses text message and generates list of WMMessages.
     *
     * @param textMessage text message
     * @return list of WMMessages
     * @throws WMMessageException
     */
    public List<WMMessage> createMessage(String textMessage) throws WMMessageException {

        ArrayList msgs = new ArrayList();

        List<HashMap> valueMaps = WMMessageParser.parse(textMessage, null);

        for (int i = 0; i < valueMaps.size(); i++) {
            WMMessage msg = createMessage(valueMaps.get(i));
            msgs.add(msg);
        }

        return msgs;
    }


    private WMMessage createMessage(HashMap valueMap) throws WMMessageException {

        return getMessage(valueMap);
    }


    /**
     * method to create WMMessage object
     *
     * @param valueMap map containing message information after parsing.
     * @return WMMessage a WMMessage object.
     * @throws WMMessageException
     */
    private WMMessage getMessage(HashMap<String, String> valueMap) throws WMMessageException {
        WMMessage msg = super.newInstance(valueMap);
        if (msg != null) {
            return msg;
        }

        String msgType = valueMap.get(WMMessage.MSG_TYPE_KEY);

        if (msgType.equals(WMMessageType.MSG_TYPE_PING.toString())) {
            msg = new WMMessageAdminPing(valueMap);
        } else if (msgType.equals(WMMessageType.MSG_TYPE_CONFIG_MGMT_NOTIFICATION.toString())) {
            msg = new WMMessageConfigChangeNotification(valueMap);
        } else if (msgType.equals(WMMessageType.MSG_TYPE_CONFIG_MGMT_ACK.toString())) {
            msg = new WMMessageConfigChangeAck(valueMap);
        }

        if (msg != null) {
            msg.setQueueInfo(_qName, _qSchema);
            return msg;
        } else {
            throw new WMMessageException("Invalid Message received " + msgType);
        }

    }

}
