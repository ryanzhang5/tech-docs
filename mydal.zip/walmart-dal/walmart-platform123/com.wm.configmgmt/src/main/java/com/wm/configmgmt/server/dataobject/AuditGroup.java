/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dataobject;

import java.sql.Timestamp;

/**
 * AuditGroup - represents a logically related group of audit entries
 *
 * @author mkishore
 * @since 1.0
 */
public class AuditGroup extends BaseDO {
    private String CCReference;
    private Long count;
    private Timestamp minDTM;
    private Timestamp maxDTM;

    public String getCCReference() {
        return CCReference;
    }

    public void setCCReference(String CCReference) {
        this.CCReference = CCReference;
    }

    public Long getCount() {
        return count;
    }

    public void setCount(Long count) {
        this.count = count;
    }

    public Timestamp getMinDTM() {
        return minDTM;
    }

    public void setMinDTM(Timestamp minDTM) {
        this.minDTM = minDTM;
    }

    public Timestamp getMaxDTM() {
        return maxDTM;
    }

    public void setMaxDTM(Timestamp maxDTM) {
        this.maxDTM = maxDTM;
    }
}
