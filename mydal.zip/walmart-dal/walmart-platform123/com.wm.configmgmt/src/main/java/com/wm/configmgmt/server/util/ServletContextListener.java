/*
 * Copyright 2010 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.util;

import com.wm.corelib.jmxadmin.JmxUtil;
import com.wm.weblib.jms.WMJMSListenerManager;

import javax.servlet.ServletContextEvent;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * ServletContextListener
 *
 * @author mkishore
 * @since 1.0
 */
public class ServletContextListener implements javax.servlet.ServletContextListener {
    private static final String PROP_CONF_FILE = "com.wm.conf";
    private static final String PROP_JMS_TIMEOUT = "PROP_JMS_TIMEOUT";

    private static final String DEFAULT_JMS_TIMEOUT = "30000";

    public void contextInitialized(ServletContextEvent servletContextEvent) {
        initializesystemProperties(servletContextEvent);
        initializeJMX();
        initializeJMS();
    }

    /**
     * This is needed for the 3rd party libraries that rely on the system properties
     * for their configuration.
     *
     * @param sce
     */
    private void initializesystemProperties(ServletContextEvent sce) {
        // can alternatively be read off the ServletContext..
        String confFile = System.getProperty(PROP_CONF_FILE);
        Properties confProps = new Properties();
        try {
            confProps.load(new FileInputStream(confFile));
            confProps.putAll(System.getProperties());
            System.setProperties(confProps);
        } catch (IOException e) {
            log(sce, "Error loading the configuration file: " + confFile, e);
        }
    }

    /**
     * Uses system properties to setup the RMI connector for JMX etc.
     */
    private void initializeJMX() {
        JmxUtil.getInstance();
    }

    /**
     * Uses system properties to setup the JMS listeners
     */
    private void initializeJMS() {
        int jmsTimeout = Integer.parseInt(System.getProperty(PROP_JMS_TIMEOUT, DEFAULT_JMS_TIMEOUT));
        WMJMSListenerManager.getInstance().start(2 * jmsTimeout);
    }


    // CONTEXT SHUTDOWN METHODS
    
    public void contextDestroyed(ServletContextEvent sce) {
        shutdownJMS(sce);
    }

    private void shutdownJMS(ServletContextEvent sce) {
        if ("true".equalsIgnoreCase(System.getProperty("PROP_JMS_STOP_ON_CONTEXT_RELOAD"))) {
            log(sce, "############ Shutting down JMS connection");
            WMJMSListenerManager.getInstance().JMSStopAll();
        }
    }


    private void log(ServletContextEvent servletContextEvent, String message) {
        servletContextEvent.getServletContext().log(message);
    }

    private void log(ServletContextEvent sce, String message, IOException e) {
        sce.getServletContext().log(message, e);
    }

}
