/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action.clientview;

import com.wm.configmgmt.client.LoadConfig;
import com.wm.configmgmt.server.action.AbstractDomainAction;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * ClientViewListAction
 *
 * @author mkishore
 * @since 1.0
 */
public class ClientViewListAction extends AbstractDomainAction {
    private DataSource dataSource;

    private String env;
    private String app;
    private String server;

    Map<String, String> configMap = new TreeMap<String, String>();

    public String home() {
        return SUCCESS;
    }

    public String list() {
        configMap.clear();
        LoadConfig loader = new LoadConfig();
        loader.setDataSource(dataSource);
        loader.setDomain(domain.getName());
        loader.setRelease(domain.getReleaseVersion());
        loader.setEnv(env);
        loader.setApp(app);
        loader.setServer(server);
        loader.initialize();
        loader.loadConfigMap();
        configMap.putAll(loader.getConfigMap());
        return SUCCESS;
    }

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public String getApp() {
        return app;
    }

    public void setApp(String app) {
        this.app = app;
    }

    public String getServer() {
        return server;
    }

    public void setServer(String server) {
        this.server = server;
    }

    public Map<String, String> getConfigMap() {
        return configMap;
    }

    public void setConfigMap(Map<String, String> configMap) {
        this.configMap = configMap;
    }
}