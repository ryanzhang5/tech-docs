/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.service;

import com.wm.configmgmt.server.dao.IConfigValueDAO;
import com.wm.configmgmt.server.dao.IPhysicalLayerDAO;
import com.wm.configmgmt.server.dao.IServerDAO;
import com.wm.configmgmt.server.dataobject.ConfigValue;
import com.wm.configmgmt.server.dataobject.PhysicalLayer;
import com.wm.configmgmt.server.dataobject.Server;
import com.wm.configmgmt.server.dataobject.VersionedKey;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * PhysicalLayerService
 *
 * @author mma
 * @since 1.0
 */
public class PhysicalLayerService {
    private IPhysicalLayerDAO physicalLayerDAO;
    private IServerDAO serverDAO;
    private IConfigValueDAO configValueDAO;

    private ServerService serverService;

    @Transactional
    public List<PhysicalLayer> findAll(long domainId, String releaseVersion) {
        String query = "select pl from PhysicalLayer pl"
                + " where pl.domain.PK.id = ?1"
                + " and pl.domain.PK.releaseVersion = ?2"
                ;
        List<PhysicalLayer> physicalLayers = physicalLayerDAO.findAllByQuery(query, domainId, releaseVersion);
        return physicalLayers;
    }

    @Transactional
    public List<PhysicalLayer> findRootLayersWithChildren(long domainId, String releaseVersion) {
        String query = "select pl from PhysicalLayer pl"
                + " where pl.domain.PK.id = ?1"
                + " and pl.domain.PK.releaseVersion = ?2"
                + " and pl.parentLayerId is null"
                ;
        List<PhysicalLayer> physicalLayers = physicalLayerDAO.findAllByQuery(query, domainId, releaseVersion);
        iterateOverChildLayers(physicalLayers);
        return physicalLayers;
    }
    private void iterateOverChildLayers(Collection<PhysicalLayer> physicalLayers) {
        if (physicalLayers != null) {
            for (PhysicalLayer childLayer : physicalLayers) {
                if (childLayer != null) {
                    if (childLayer.getServers() != null) childLayer.getServers().size();
                    iterateOverChildLayers(childLayer.getChildLayers());
                }
            }
        }
    }

    @Transactional
    public PhysicalLayer find(Long id, String releaseVersion) {
        PhysicalLayer physicalLayer = physicalLayerDAO.findById(new VersionedKey(id, releaseVersion));
        return physicalLayer;
    }
    
    @Transactional
    public PhysicalLayer findByName(long domainId, String releaseVersion, Long parentLayerId, String name) {
    	if (name == null || "".equals(name) || releaseVersion == null || "".equals(releaseVersion)) {
    		return null;
    	}
    	String query = "select o from PhysicalLayer o"
                + " where o.domain.PK.id = ?1"
                + " and o.domain.PK.releaseVersion = ?2 "
                + " and ((o.parentLayerId is null and ?3 is null) or (o.parentLayerId = ?3)) "
                + " and o.name = ?4"
    		;
    	List<PhysicalLayer> list = physicalLayerDAO.findAllByQuery(query, domainId, releaseVersion, nvl(parentLayerId), name);
    	return (list != null && list.size() > 0) ? list.get(0) : null;
    }

    private Object nvl(Object obj) {
        return (obj != null) ?obj :"";
    }

    @Transactional
    public PhysicalLayer findByName(long domainId, String releaseVersion, String name) {
    	if (name == null || "".equals(name) || releaseVersion == null || "".equals(releaseVersion)) {
    		return null;
    	}
    	String query = "select o from PhysicalLayer o"
                + " where o.domain.PK.id = ?1"
                + " and o.domain.PK.releaseVersion = ?2 "
                + " and o.name = ?3"
    		;
    	List<PhysicalLayer> list = physicalLayerDAO.findAllByQuery(query, domainId, releaseVersion, name);
    	return (list != null && list.size() > 0) ? list.get(0) : null;
    }

    @Transactional
    public PhysicalLayer findWithChildren(long id, String releaseVersion) {
        PhysicalLayer physicalLayer = physicalLayerDAO.findById(new VersionedKey(id, releaseVersion));
        if (physicalLayer != null) {
            ServiceUtil.initialize(physicalLayer.getParentLayer());
            ServiceUtil.initialize(physicalLayer.getChildLayers());
            ServiceUtil.initialize(physicalLayer.getServers());
        }
        return physicalLayer;
    }

    @Transactional
    public void save(PhysicalLayer physicalLayer) throws DuplicateException {
        PhysicalLayer namedDO = findByName(
                physicalLayer.getDomainId(),
                physicalLayer.getReleaseVersion(),
                physicalLayer.getParentLayerId(),
                physicalLayer.getName()
        );
        if (physicalLayer.getId() == null) {
            if (namedDO != null) {
                throw new DuplicateException();
            }
            physicalLayerDAO.insert(physicalLayer);
        } else {
            if (namedDO != null && !namedDO.getId().equals(physicalLayer.getId())) {
                throw new DuplicateException();
            }
            physicalLayerDAO.update(physicalLayer);
        }
    }

    @Transactional
    public void saveWithChildren(PhysicalLayer physicalLayer, Long parentLayerId, Collection<Long> serverIds) throws DuplicateException {
        boolean isNew = (physicalLayer.getId() == null);
        if (isNew) {
            PhysicalLayer parentLayer = find(parentLayerId, physicalLayer.getReleaseVersion());
            physicalLayer.setParentLayer(parentLayer);
        }
        save(physicalLayer);
        if (!isNew) physicalLayer = findWithChildren(physicalLayer.getId(), physicalLayer.getReleaseVersion());
        updateChildServers(physicalLayer, serverIds);
    }

    @Transactional
    public void delete(long id, String releaseVersion) {
    	PhysicalLayer physicalLayer = findWithChildren(id, releaseVersion);
        if (physicalLayer != null) {
        	Set<PhysicalLayer> childLayers = physicalLayer.getChildLayers();
        	if (childLayers != null && childLayers.size() > 0) {
                for (Iterator<PhysicalLayer> it = childLayers.iterator(); it.hasNext();) {
                    PhysicalLayer childLayer = it.next();
                    if (childLayer != null) {
                        delete(childLayer.getId(), childLayer.getReleaseVersion());
                        it.remove();
                    }
                }
	        }
        	Set<Server> childServers = physicalLayer.getServers();
        	if (childServers != null && childServers.size() > 0) {
                for (Iterator<Server> it = childServers.iterator(); it.hasNext();) {
                    Server childServer = it.next();
                    if (childServer != null) {
                        try {
                            childServer.setPhysicalLayer(null);
                            serverService.save(childServer);
                            it.remove();
                        } catch (DuplicateException e) {
                            // this should neven happen - we are not changing the name!
                            throw new RuntimeException(e);
                        }
                    }
                }
        	}
            Set<ConfigValue> configValues = physicalLayer.getConfigValues();
            if (configValues != null && configValues.size() > 0) {
                for (Iterator<ConfigValue> it = configValues.iterator(); it.hasNext();) {
                    ConfigValue configValue = it.next();
                    if (configValue != null) {
                        configValueDAO.delete(configValue);
                        it.remove();
                    }
                }
            }
        	physicalLayerDAO.delete(physicalLayer);
        }
    }

    private void updateChildServers(PhysicalLayer physicalLayer, Collection<Long> newServerIds) {
        Set<Long> oldServerIds = new HashSet<Long>();
        Set<Server> oldServers = physicalLayer.getServers();
        for (Server server : oldServers) {
            oldServerIds.add(server.getId());
        }
        for (Long id : newServerIds) {
            if (oldServerIds.remove(id)) continue;

            Server server = serverDAO.findById(new VersionedKey(id, physicalLayer.getReleaseVersion()));
            server.setPhysicalLayer(physicalLayer);
            server.setModifiedBy(physicalLayer.getModifiedBy());
            server.setModifiedDTM(physicalLayer.getModifiedDTM());
            serverDAO.update(server);
        }
        for (Iterator<Server> it = oldServers.iterator(); !oldServers.isEmpty() && it.hasNext();) {
            Server server = it.next();
            if (oldServerIds.contains(server.getId())) {
                it.remove();
                server.setPhysicalLayer(null);
                server.setModifiedBy(physicalLayer.getModifiedBy());
                server.setModifiedDTM(physicalLayer.getModifiedDTM());
                serverDAO.update(server);
            }
        }
    }

    public void setPhysicalLayerDAO(IPhysicalLayerDAO physicalLayerDAO) {
        this.physicalLayerDAO = physicalLayerDAO;
    }

    public void setServerDAO(IServerDAO serverDAO) {
        this.serverDAO = serverDAO;
    }

    public void setConfigValueDAO(IConfigValueDAO configValueDAO) {
        this.configValueDAO = configValueDAO;
    }

    public void setServerService(ServerService serverService) {
    	this.serverService = serverService;
    }
}