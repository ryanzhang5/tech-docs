/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.PhysicalLayer;
import com.wm.configmgmt.server.dataobject.VersionedKey;

/**
 * IPhysicalLayerDAO
 *
 * @author mkishore
 * @since 1.0
 */
public interface IPhysicalLayerDAO extends IBaseDAO<PhysicalLayer, VersionedKey> {

}