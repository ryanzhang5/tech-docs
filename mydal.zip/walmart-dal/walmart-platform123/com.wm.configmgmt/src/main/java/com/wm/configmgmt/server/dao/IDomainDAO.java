/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.Domain;
import com.wm.configmgmt.server.dataobject.VersionedKey;

/**
 * IDomainDAO
 *
 * @author mkishore
 * @since 1.0
 */
public interface IDomainDAO extends IBaseDAO<Domain, VersionedKey> {

}
