/**
 * Copyright 2009 Walmart.com. All rights Reserved
 */
package com.wm.configmgmt.server.security;

/**
 * @author Nagesh Cherukuri
 *  
 */
public class AuthenticationException extends Exception {
	
	public AuthenticationException() {
		super();
	}
	public AuthenticationException(String msg) {
		super(msg);
	}
	public AuthenticationException(String msg, Throwable cause) {
		super(msg, cause);
	}

}
