/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action.logicallayer;

import com.wm.configmgmt.server.action.AbstractDomainAction;
import com.wm.configmgmt.server.dataobject.LogicalLayer;
import com.wm.configmgmt.server.service.LogicalLayerService;
import com.wm.configmgmt.server.service.DuplicateException;

import java.sql.Timestamp;

/**
 * LogicalLayerAction
 *
 * @author mkishore
 * @since 1.0
 */
public class LogicalLayerAction extends AbstractDomainAction {
    private LogicalLayerService logicalLayerService;

    private LogicalLayer logicalLayer = new LogicalLayer();

    private Long parentLayerId;
    private String parentLayerName;

    // this is actually an "Add Child" call
    public String add() {
        if (logicalLayer.getId() != null) {
            logicalLayer = logicalLayerService.find(logicalLayer.getId(), logicalLayer.getReleaseVersion());
        }
        if (logicalLayer == null) logicalLayer = new LogicalLayer();
        parentLayerId = logicalLayer.getId();
        parentLayerName = logicalLayer.getName();
        logicalLayer = new LogicalLayer();
        return SUCCESS;
    }

    public String edit() {
        if (logicalLayer.getId() != null) {
            logicalLayer = logicalLayerService.findWithChildren(logicalLayer.getId(), logicalLayer.getReleaseVersion());
        }
        if (logicalLayer == null) logicalLayer = new LogicalLayer();
        parentLayerId = logicalLayer.getParentLayerId();
        parentLayerName = (logicalLayer.getParentLayer() != null) ? logicalLayer.getParentLayer().getName() : null;
        return SUCCESS;
    }

    public String save() {
        Timestamp now = new Timestamp(System.currentTimeMillis());
        if (!isNew()) {
            LogicalLayer input = logicalLayer;
            logicalLayer = logicalLayerService.find(logicalLayer.getId(), logicalLayer.getReleaseVersion());
            logicalLayer.setName(input.getName());
            logicalLayer.setDescription(input.getDescription());
        } else {
            logicalLayer.setDomain(domain);
            logicalLayer.setReleaseVersion(domain.getReleaseVersion());
            logicalLayer.setCreatedBy(user.getUsername());
            logicalLayer.setCreatedDTM(now);
        }
        logicalLayer.setModifiedBy(user.getUsername());
        logicalLayer.setModifiedDTM(now);

        try {
            logicalLayerService.saveWithChildren(logicalLayer, parentLayerId);
        } catch (DuplicateException e) {
            addActionError("Please enter a unique " + e.getProperty() + ".");
            return INPUT;
        }
        return SUCCESS;
    }

    public String delete() {
        logicalLayerService.delete(logicalLayer.getId(), logicalLayer.getReleaseVersion());
        return SUCCESS;
    }

    public boolean isNew() {
        return logicalLayer.getId() == null;
    }

    public void setLogicalLayerService(LogicalLayerService logicalLayerService) {
        this.logicalLayerService = logicalLayerService;
    }

    public LogicalLayer getLogicalLayer() {
        return logicalLayer;
    }

    public void setId(Long id) {
        logicalLayer.setId(id);
    }

    public void setReleaseVersion(String releaseVersion) {
        logicalLayer.setReleaseVersion(releaseVersion);
    }

    public Long getParentLayerId() {
        return parentLayerId;
    }

    public void setParentLayerId(Long parentLayerId) {
        this.parentLayerId = parentLayerId;
    }

    public String getParentLayerName() {
        return (parentLayerName != null) ? parentLayerName : "Root";
    }

    public void setParentLayerName(String parentLayerName) {
        this.parentLayerName = parentLayerName;
    }

}