/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.service;

import com.wm.configmgmt.server.dao.IDomainDAO;
import com.wm.configmgmt.server.dataobject.*;
import org.springframework.transaction.annotation.Transactional;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.XMLOutputter;
import org.jdom.output.Format;

import java.sql.Timestamp;
import java.util.*;
import java.util.logging.Logger;
import java.io.FileWriter;
import java.io.StringWriter;

/**
 * ClientServiceService
 *
 * @author pho
 * @since 1.0
 */
public class ClientServiceService {

    protected static final Logger logger = Logger.getLogger(ClientServiceService.class.getName());

    private IDomainDAO domainDAO;
    private ConfigGroupService configGroupService;
    private ConfigService configService;
    private ConfigValueService configValueService;

    @Transactional
    public String export(Map<String, String[]> parameters) {
	String[] domainValues = parameters.get("domain");  
	String domainName = domainValues[0];

	String[] releaseVersionValues = parameters.get("release");  
	String releaseVersion = releaseVersionValues[0];

        Domain domain = findByName(domainName, releaseVersion);
        if (domain == null) {
            return "domain=" + domainName + "\nrelease=" + releaseVersion + "\nerror=nodomain\n";
        }
	Long domainId = domain.getId();

	StringWriter writer = new StringWriter();
        try {
            List<ConfigValue> configValues = configValueService.findCurrentConfigValues(domainId, releaseVersion);
	    for (ConfigValue configValue : configValues) {
	        writer.write(Long.toString(configValue.getId()) + "=" + configValue.getValue() + "\n");
	    }
        } catch (Exception e) {
            e.printStackTrace();
            return "domain=" + domainName + "\nrelease=" + releaseVersion + "\nerror=here\n";
        }
        return writer.toString();
    }

    @Transactional
    public Domain findByName(String name, String releaseVersion) {
        Domain result = null;
        String query = "select d from Domain d where d.name = ?1 and d.PK.releaseVersion = ?2";
        List<Domain> domains = domainDAO.findAllByQuery(query, name, releaseVersion);
        if (domains != null && domains.size() > 0) {
            result = domains.get(0);
        }
        return result;
    }

    public void setDomainDAO(IDomainDAO domainDAO) {
        this.domainDAO = domainDAO;
    }

    public void setConfigGroupService(ConfigGroupService configGroupService) {
        this.configGroupService = configGroupService;
    }

    public void setConfigService(ConfigService configService) {
        this.configService = configService;
    }

    public void setConfigValueService(ConfigValueService configValueService) {
        this.configValueService = configValueService;
    }

}
