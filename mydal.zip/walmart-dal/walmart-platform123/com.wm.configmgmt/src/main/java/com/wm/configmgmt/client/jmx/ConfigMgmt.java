package com.wm.configmgmt.client.jmx;

import com.wm.corelib.jmxadmin.WmtMBeanImpl;

import javax.management.*;
import java.io.*;
import java.util.Iterator;
import java.util.Properties;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.logging.Level;


/**
 * Config Management Bean which retrives all the required properties
 *
 * @author ncherukuri
 * @version $Revision: 1.4 $
 * @since 1/2010
 */

public class ConfigMgmt extends WmtMBeanImpl implements ConfigMgmtMBean {

    private String _theMessage = null;
    protected final String propertyFileName;
    protected final Properties properties;

    private static final String CONF_FILE = System.getProperty("com.wm.conf");

    public ConfigMgmt() throws NotCompliantMBeanException {
        super(ConfigMgmtMBean.class);
        this.propertyFileName = CONF_FILE;
        properties = new Properties();
        try {
            load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        _theMessage = "Config Management Bean for the Configuration Management";
    }


    public void setMessage(String theMessage) {
        this._theMessage = theMessage;
    }

    public String getMessage() {
        return _theMessage;
    }

    public void setLastInitialization(String s) {
        //to be implemented
    }

    public String getLastInitialization() {
        // to be implemented
        return null;
    }
    /////////////////////////
    // Operations
    /////////////////////////


    public synchronized String getAttribute(String name)
            throws AttributeNotFoundException {
        String value = properties.getProperty(name);
        if (value != null)
            return value;
        else
            throw new AttributeNotFoundException("No such property: " + name);
    }

    public synchronized void setAttribute(Attribute attribute)
            throws InvalidAttributeValueException, MBeanException, AttributeNotFoundException {
        String name = attribute.getName();
        if (properties.getProperty(name) == null)
            throw new AttributeNotFoundException(name);
        Object value = attribute.getValue();
        if (!(value instanceof String)) {
            throw new InvalidAttributeValueException(
                    "Attribute value not a string: " + value);
        }
        properties.setProperty(name, (String) value);
    }

    public synchronized AttributeList getAttributes(String[] names) {
        AttributeList list = new AttributeList();
        for (String name : names) {
            String value = properties.getProperty(name);
            if (value != null)
                list.add(new Attribute(name, value));
        }
        return list;
    }

    public synchronized AttributeList setAttributes(AttributeList list) {
        Attribute[] attrs = (new Attribute[0]);
        AttributeList retlist = new AttributeList();
        for (Attribute attr : attrs) {
            String name = attr.getName();
            Object value = attr.getValue();
            if (properties.getProperty(name) != null && value instanceof String) {
                properties.setProperty(name, (String) value);
                retlist.add(new Attribute(name, value));
            }
        }
        try {
            save();
        } catch (IOException e) {
            return new AttributeList();
        }
        return retlist;
    }

    public Object invoke(String name, Object[] args, String[] sig)
            throws MBeanException, ReflectionException {
        /* if (name.equals("reload") &&
                (args == null || args.length == 0) &&
                (sig == null || sig.length == 0)) {
            try {
                load();
                return null;
            } catch (IOException e) {
                throw new MBeanException(e);
            }
        } */

        if (name.equals("load") &&
                (args == null || args.length == 0) &&
                (sig == null || sig.length == 0)) {
            try {
                load();
                return null;
            } catch (IOException e) {
                throw new MBeanException(e);
            }
        }

        if (name.equals("save") &&
                (args == null || args.length == 0) &&
                (sig == null || sig.length == 0)) {
            try {
                save();
                return null;
            } catch (IOException e) {
                throw new MBeanException(e);
            }
        }
        throw new ReflectionException(new NoSuchMethodException(name));
    }

    public synchronized MBeanInfo getMBeanInfo() {
        SortedSet<String> names = new TreeSet<String>();
        for (Object name : properties.keySet())
            names.add((String) name);
        MBeanAttributeInfo[] attrs = new MBeanAttributeInfo[names.size()];
        Iterator<String> it = names.iterator();
        for (int i = 0; i < attrs.length; i++) {
            String name = it.next();
            attrs[i] = new MBeanAttributeInfo(
                    name,
                    "java.lang.String",
                    "Property " + name,
                    true,   // isReadable
                    true,   // isWritable
                    false); // isIs
        }
        MBeanOperationInfo[] opers = {
                /* new MBeanOperationInfo(
               "reload",
               "Reload properties from file",
               null,   // no parameters
               "void",
               MBeanOperationInfo.ACTION) ,*/
                new MBeanOperationInfo(
                        "load",
                        "Reload properties from file",
                        null,   // no parameters
                        "void",
                        MBeanOperationInfo.ACTION),
                new MBeanOperationInfo(
                        "save",
                        "Reload properties from file",
                        null,   // no parameters
                        "void",
                        MBeanOperationInfo.ACTION)
        };
        return new MBeanInfo(
                this.getClass().getName(),
                "Config Management Bean",
                attrs,
                null,  // constructors
                opers,
                null); // notifications
    }

    public void load() throws IOException {
        //System.out.println(" XXXXX  Loading Props from "+propertyFileName);
        InputStream input = new FileInputStream(propertyFileName);
        properties.load(input);
        input.close();
    }

    public void save() throws IOException {
        String newPropertyFileName = propertyFileName + "##mod";
        File file = new File(newPropertyFileName);
        OutputStream output = new FileOutputStream(file);
        String comment = "Modified by " + this.getClass().getName();
        properties.store(output, comment);
        output.close();
        if (!file.renameTo(new File(propertyFileName))) {
            throw new IOException("Rename " + newPropertyFileName + " to " +
                    propertyFileName + " failed");
        }
       //Need to reload the MBean
    }

}
