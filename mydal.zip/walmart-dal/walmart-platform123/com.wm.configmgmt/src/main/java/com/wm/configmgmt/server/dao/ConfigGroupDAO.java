/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.ConfigGroup;
import com.wm.configmgmt.server.dataobject.VersionedKey;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * ConfigGroupDAO
 *
 * @author mkishore
 * @since 1.0
 */
public class ConfigGroupDAO extends SoftDeleteDAO<ConfigGroup, VersionedKey> implements IConfigGroupDAO {
    @PersistenceContext (name = "configmgmt")
    public void setEntityManager(EntityManager entityManager) {
        super.setEntityManager(entityManager);
    }
}