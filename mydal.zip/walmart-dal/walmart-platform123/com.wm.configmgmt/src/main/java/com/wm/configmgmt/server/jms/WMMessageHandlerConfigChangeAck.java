/*
 * Copyright 2010 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.jms;

import com.wm.configmgmt.common.jms.WMMessageConfigChangeAck;
import com.wm.configmgmt.server.dataobject.PublishRecord;
import com.wm.configmgmt.server.dataobject.PublishServerRecord;
import com.wm.configmgmt.server.dataobject.Server;
import com.wm.configmgmt.server.service.PublishRecordService;
import com.wm.configmgmt.server.service.ServerService;
import com.wm.configmgmt.server.util.AppContextProvider;
import com.wm.weblib.jms.WMMessage;
import com.wm.weblib.jms.WMMessageHandlerStatus;
import com.wm.weblib.jms.WMMessageType;
import com.wm.weblib.jms.common.WMAdminMessageHandler;
import org.springframework.context.ApplicationContext;

import java.sql.Timestamp;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * WMMessageHandlerConfigChangeAck - receives ACKs from the managed nodes and updates the database
 *
 * @author mkishore
 * @since 1.0
 */
public class WMMessageHandlerConfigChangeAck extends WMAdminMessageHandler {
    private static final Logger logger = Logger.getLogger(WMMessageHandlerConfigChangeAck.class.getName());

    protected boolean canHandle(WMMessage message) {
        return WMMessageType.MSG_TYPE_CONFIG_MGMT_ACK.equals(message.getMessageType());
    }

    public WMMessageHandlerStatus handleMessage(WMMessage m) {
        try {
            if (!canHandle(m)) return _defaultStatus;

            WMMessageConfigChangeAck message = (WMMessageConfigChangeAck) m;
            WMMessageConfigChangeAck.Payload payload = message.getPayload();
            if (payload == null) throw new Exception("Payload is null");

            ApplicationContext context = AppContextProvider.appContext;
            PublishRecordService publishRecordService = (PublishRecordService) context.getBean("publishRecordService");
            ServerService serverService = (ServerService) context.getBean("serverService");
            PublishRecord publishRecord = publishRecordService.find(payload.getPublishRecordId(), payload.getReleaseVersion());
            Server server = serverService.findByName(publishRecord.getDomainId(), publishRecord.getReleaseVersion(), payload.getServerName());
            if (server == null) throw new RuntimeException("Could not lookup the server for the server-name: " + payload.getServerName());
            PublishServerRecord serverRecord = publishRecordService.findServerRecord(payload.getPublishRecordId(), payload.getReleaseVersion(), server.getId());
            serverRecord.setResponseDTM(new Timestamp(System.currentTimeMillis()));
            serverRecord.setResponseCode(payload.getResponseCode());
            serverRecord.setResponseMessage(payload.getResponseMessage());
            publishRecordService.save(serverRecord);

            _successStatus.setMessage(this.getClass().getName() + ": successfully processed message " + m);
        } catch (Exception e) {
            logger.log(Level.WARNING, "Unexpected error while handling message: " + m, e);
            return new WMMessageHandlerStatus(WMMessageHandlerStatus.CODE_FAILURE, e.toString());
        }
        return _successStatus;
    }

}
