/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.*;

import java.sql.Timestamp;
import java.util.List;

/**
 * IConfigValueDAO
 *
 * @author mkishore
 * @since 1.0
 */
public interface IConfigValueDAO extends IBaseDAO<ConfigValue, VersionedKey> {

    void delete(String user, Timestamp dtm, String CCReference, ConfigValue... entities);

    List<AuditGroup> findAllAuditGroups(Long domainId, String releaseVersion);

    List<AuditEntry> findAuditEntriesByCCReference(Long domainId, String releaseVersion, String CCReference);

    Timestamp findMinDTMForCCReference(Long domainId, String releaseVersion, String CCReference);

    List<ConfigValueAK> findConfigValueAKsSinceDTM(Long domainId, String releaseVersion, Timestamp minDTM);
}