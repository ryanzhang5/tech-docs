/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.LogicalLayer;
import com.wm.configmgmt.server.dataobject.VersionedKey;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * LogicalLayerDAO
 *
 * @author mkishore
 * @since 1.0
 */
public class LogicalLayerDAO extends SoftDeleteDAO<LogicalLayer, VersionedKey> implements ILogicalLayerDAO {
    @PersistenceContext (name = "configmgmt")
    public void setEntityManager(EntityManager entityManager) {
        super.setEntityManager(entityManager);
    }
}