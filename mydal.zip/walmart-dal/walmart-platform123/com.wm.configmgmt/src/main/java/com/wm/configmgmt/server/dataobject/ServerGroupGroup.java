/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dataobject;

import java.sql.Timestamp;

/**
 * Represents a mapping from parentGroup to childGroup
 *
 * @author mkishore
 * @since 1.0
 */
public class ServerGroupGroup extends BaseDO implements Cloneable {
    private VersionedKeyMulti PK = new VersionedKeyMulti();
    private String createdBy;
    private Timestamp createdDTM;

    private ServerGroup serverGroup;
    private ServerGroup childGroup;

    public VersionedKeyMulti getPK() {
        return PK;
    }

    public void setPK(VersionedKeyMulti PK) {
        this.PK = PK;
    }

    public Long getServerGroupId() {
        return PK.getId();
    }

    public void setServerGroupId(Long serverGroupId) {
        PK.setId(serverGroupId);
    }

    public String getReleaseVersion() {
        return PK.getReleaseVersion();
    }

    public void setReleaseVersion(String releaseVersion) {
        PK.setReleaseVersion(releaseVersion);
    }

    public Long getChildGroupId() {
        return PK.getId1();
    }

    public void setChildGroupId(Long childGroupId) {
        PK.setId1(childGroupId);
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDTM() {
        return createdDTM;
    }

    public void setCreatedDTM(Timestamp createdDTM) {
        this.createdDTM = createdDTM;
    }

    public ServerGroup getServerGroup() {
        return serverGroup;
    }

    public void setServerGroup(ServerGroup serverGroup) {
        this.serverGroup = serverGroup;
        setServerGroupId((serverGroup != null) ? serverGroup.getId() : null);
    }

    public ServerGroup getChildGroup() {
        return childGroup;
    }

    public void setChildGroup(ServerGroup childGroup) {
        this.childGroup = childGroup;
        setChildGroupId((childGroup != null) ? childGroup.getId() : null);
    }
    
    public Object clone() throws CloneNotSupportedException {
    	return super.clone();
    }
}