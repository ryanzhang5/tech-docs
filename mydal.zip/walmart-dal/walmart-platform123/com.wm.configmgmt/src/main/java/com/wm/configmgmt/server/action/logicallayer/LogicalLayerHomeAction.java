/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action.logicallayer;

import com.wm.configmgmt.server.action.AbstractDomainAction;
import com.wm.configmgmt.server.dataobject.LogicalLayer;
import com.wm.configmgmt.server.service.LogicalLayerService;

import java.util.ArrayList;
import java.util.List;

/**
 * LogicalLayerHomeAction
 *
 * @author mkishore
 * @since 1.0
 */
public class LogicalLayerHomeAction extends AbstractDomainAction {
    private LogicalLayerService logicalLayerService;

    private List<LogicalLayer> rootLayers = new ArrayList<LogicalLayer>();

    public String home() {
        return SUCCESS;
    }

    public String tree() {
        prepareRootLayers();
        return SUCCESS;
    }

    private void prepareRootLayers() {
        rootLayers = logicalLayerService.findRootLayersWithChildren(domain.getId(), domain.getReleaseVersion());
    }

    public void setLogicalLayerService(LogicalLayerService logicalLayerService) {
        this.logicalLayerService = logicalLayerService;
    }

    public List<LogicalLayer> getRootLayers() {
        return rootLayers;
    }

}