/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.service;

import com.wm.configmgmt.server.dao.IConfigValueDAO;
import com.wm.configmgmt.server.dao.ILogicalLayerDAO;
import com.wm.configmgmt.server.dataobject.ConfigValue;
import com.wm.configmgmt.server.dataobject.LogicalLayer;
import com.wm.configmgmt.server.dataobject.VersionedKey;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * LogicalLayerService
 *
 * @author mma
 * @since 1.0
 */
public class LogicalLayerService {
    private ILogicalLayerDAO logicalLayerDAO;
    private IConfigValueDAO configValueDAO;

    @Transactional
    public List<LogicalLayer> findAll(long domainId, String releaseVersion) {
        String query = "select ll from LogicalLayer ll"
                + " where ll.domain.PK.id = ?1"
                + " and ll.domain.PK.releaseVersion = ?2"
                ;
        List<LogicalLayer> logicalLayers = logicalLayerDAO.findAllByQuery(query, domainId, releaseVersion);
        return logicalLayers;
    }

    @Transactional
    public List<LogicalLayer> findRootLayersWithChildren(long domainId, String releaseVersion) {
        String query = "select ll from LogicalLayer ll"
                + " where ll.domain.PK.id = ?1"
                + " and ll.domain.PK.releaseVersion = ?2"
                + " and ll.parentLayerId is null"
                ;
        List<LogicalLayer> logicalLayers = logicalLayerDAO.findAllByQuery(query, domainId, releaseVersion);
        iterateOverChildLayers(logicalLayers);
        return logicalLayers;
    }
    
    private void iterateOverChildLayers(Collection<LogicalLayer> logicalLayers) {
        if (logicalLayers != null) {
            for (LogicalLayer childLayer : logicalLayers) {
                if (childLayer != null) {
		    ServiceUtil.initialize(childLayer.getChildLayers());
                    iterateOverChildLayers(childLayer.getChildLayers());
                }
            }
        }
    }

    @Transactional
    public LogicalLayer find(Long id, String releaseVersion) {
        LogicalLayer logicalLayer = logicalLayerDAO.findById(new VersionedKey(id, releaseVersion));
        return logicalLayer;
    }

    @Transactional
    public LogicalLayer findByName(long domainId, String releaseVersion, Long parentLayerId, String name) {
    	if (name == null || "".equals(name) || releaseVersion == null || "".equals(releaseVersion)) {
    		return null;
    	}
    	String query = "select o from LogicalLayer o"
                + " where o.domain.PK.id = ?1"
                + " and o.domain.PK.releaseVersion = ?2 "
                + " and ((o.parentLayerId is null and ?3 is null) or (o.parentLayerId = ?3)) "
                + " and o.name = ?4"
    		;
    	List<LogicalLayer> list = logicalLayerDAO.findAllByQuery(query, domainId, releaseVersion, nvl(parentLayerId), name);
    	return (list != null && list.size() > 0) ? list.get(0) : null;
    }

    private Object nvl(Object obj) {
        return (obj != null) ?obj :"";
    }

    @Transactional
    public LogicalLayer findByName(long domainId, String releaseVersion, String name) {
    	if (name == null || "".equals(name) || releaseVersion == null || "".equals(releaseVersion)) {
    		return null;
    	}
    	String query = "select o from LogicalLayer o"
                + " where o.domain.PK.id = ?1"
                + " and o.domain.PK.releaseVersion = ?2 "
                + " and o.name = ?3"
    		;
    	List<LogicalLayer> list = logicalLayerDAO.findAllByQuery(query, domainId, releaseVersion, name);
    	return (list != null && list.size() > 0) ? list.get(0) : null;
    }

    @Transactional
    public LogicalLayer findWithChildren(long id, String releaseVersion) {
        LogicalLayer logicalLayer = logicalLayerDAO.findById(new VersionedKey(id, releaseVersion));
        if (logicalLayer != null) {
            ServiceUtil.initialize(logicalLayer.getParentLayer());
            ServiceUtil.initialize(logicalLayer.getChildLayers());
        }
        return logicalLayer;
    }

    @Transactional
    public String getFullName(Long layerId, String releaseVersion) {
        String fullName = null;
        LogicalLayer logicalLayer = (layerId != null) ? find(layerId, releaseVersion) : null;
        while (logicalLayer != null) {
            fullName = logicalLayer.getName() + (fullName != null ? "/" + fullName : "");
            logicalLayer = logicalLayer.getParentLayer();
        }
        return fullName;
    }

    @Transactional
    public void save(LogicalLayer logicalLayer) throws DuplicateException {
        LogicalLayer namedDO = findByName(
                logicalLayer.getDomainId(),
                logicalLayer.getReleaseVersion(),
                logicalLayer.getParentLayerId(),
                logicalLayer.getName()
        );
        if (logicalLayer.getId() == null) {
            if (namedDO != null) {
                throw new DuplicateException();
            }
            logicalLayerDAO.insert(logicalLayer);
        } else {
            if (namedDO != null && !namedDO.getId().equals(logicalLayer.getId())) {
                throw new DuplicateException();
            }
            logicalLayerDAO.update(logicalLayer);
        }
    }

    @Transactional
    public void saveWithChildren(LogicalLayer logicalLayer, Long parentLayerId) throws DuplicateException {
        boolean isNew = (logicalLayer.getId() == null);
        if (isNew) {
            LogicalLayer parentLayer = find(parentLayerId, logicalLayer.getReleaseVersion());
            logicalLayer.setParentLayer(parentLayer);
        }
        save(logicalLayer);
    }

    @Transactional
    public void delete(long id, String releaseVersion) {
        LogicalLayer logicalLayer = findWithChildren(id, releaseVersion);
        if (logicalLayer != null) {
        	Set<LogicalLayer> childLayers = logicalLayer.getChildLayers();
        	if (childLayers != null && childLayers.size() > 0) {
                for (Iterator<LogicalLayer> it = childLayers.iterator(); it.hasNext();) {
                    LogicalLayer ll = it.next();
                    if (ll != null) {
                        delete(ll.getId(), ll.getReleaseVersion());
                        it.remove();
                    }
                }
	        }
            Set<ConfigValue> configValues = logicalLayer.getConfigValues();
            if (configValues != null && configValues.size() > 0) {
                for (Iterator<ConfigValue> it = configValues.iterator(); it.hasNext();) {
                    ConfigValue configValue = it.next();
                    if (configValue != null) {
                        configValueDAO.delete(configValue);
                        it.remove();
                    }
                }
            }
        	logicalLayerDAO.delete(logicalLayer);
        }
    }


    public void setLogicalLayerDAO(ILogicalLayerDAO logicalLayerDAO) {
        this.logicalLayerDAO = logicalLayerDAO;
    }

    public void setConfigValueDAO(IConfigValueDAO configValueDAO) {
        this.configValueDAO = configValueDAO;
    }
}
