/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action.override;

import com.wm.configmgmt.server.action.AbstractDomainAction;
import com.wm.configmgmt.server.dataobject.ConfigValue;
import com.wm.configmgmt.server.dataobject.NamedDOComparator;
import com.wm.configmgmt.server.service.ConfigValueService;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * OverrideListAction
 *
 * @author mkishore
 * @since 1.0
 */
public class OverrideListAction extends AbstractDomainAction {
    private ConfigValueService configValueService;

    private Long logicalLayerId;
    private Long physicalLayerId;
    private Long serverId;

    private List<ConfigValue> configValues = new ArrayList<ConfigValue>();

    public String list() {
        configValues = configValueService.findConfigValuesForLayer(
                domain.getId(), domain.getReleaseVersion(), logicalLayerId, physicalLayerId, serverId, null
        );
        Collections.sort(configValues, new Comparator<ConfigValue>() {
            public int compare(ConfigValue o1, ConfigValue o2) {
                if (o1 == null && o2 == null) return 0;
                if (o1 == null) return -1;
                if (o2 == null) return 1;

                return new NamedDOComparator().compare(o1.getConfig(), o2.getConfig());
            }
        });
        return SUCCESS;
    }

    public Long getLogicalLayerId() {
        return logicalLayerId;
    }

    public void setLogicalLayerId(Long logicalLayerId) {
        this.logicalLayerId = logicalLayerId;
    }

    public Long getPhysicalLayerId() {
        return physicalLayerId;
    }

    public void setPhysicalLayerId(Long physicalLayerId) {
        this.physicalLayerId = physicalLayerId;
    }

    public Long getServerId() {
        return serverId;
    }

    public void setServerId(Long serverId) {
        this.serverId = serverId;
    }

    public List<ConfigValue> getConfigValues() {
        return configValues;
    }

    public void setConfigValueService(ConfigValueService configValueService) {
        this.configValueService = configValueService;
    }

}