/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.Server;
import com.wm.configmgmt.server.dataobject.ServerGroup;
import com.wm.configmgmt.server.dataobject.VersionedKey;

import java.util.List;

/**
 * IServerGroupDAO
 *
 * @author mkishore
 * @since 1.0
 */
public interface IServerGroupDAO extends IBaseDAO<ServerGroup, VersionedKey> {

    List<Server> findAllServersForGroup(Long serverGroupId, String releaseVersion);

}