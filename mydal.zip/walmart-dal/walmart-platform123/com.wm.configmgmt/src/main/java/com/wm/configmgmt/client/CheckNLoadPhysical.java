package com.wm.configmgmt.client;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * Copyright 2009 Walmart.com. All rights reserved.
 * User: ncherukuri
 * Date: Dec 22, 2009
 * Time: 1:28:29 PM
 */
public class CheckNLoadPhysical {
    private DataSource dataSource;
    private List<String> physicalLayerList = new ArrayList<String>();
    private List<String> physicalLayerIDList = new ArrayList<String>();
    private String domainID;
    private String release;
    private String serverID;

    private String getPhysicalLayerForServerSQL = "select s.physical_layer_id from server s " +
            "   where s.server_id = ? " +
            "   and s.rel_version = ? " +
            " ";

    private String guessPhysicalLayerByNameSQL = "select pl.layer_id from physical_layer pl " +
            "   where pl.name = ? " +
            "   and pl.rel_version = ? " +
            "   and pl.domain_id = ? " +
            "   and pl.is_deleted = 'N' " +
            " ";

    private String traverseBottomUpSQL = "select pl.layer_id from physical_layer pl " +
            " start with (pl.layer_id = ? and pl.rel_version = ?) " +
            " connect by ( " +
            "   pl.layer_id = prior pl.parent_layer_id " +
            "   and pl.rel_version = prior pl.rel_version " +
            " ) ";

    private String traverseTopDownSQL = "select pl.layer_id from physical_layer pl " +
            " where pl.domain_id = ? " +
            " and pl.rel_version = ? " +
            " and pl.name = ? " +
            " and nvl(pl.parent_layer_id, -1) = nvl(?, -1) " +
            " and pl.is_deleted = 'N' ";


    public CheckNLoadPhysical(DataSource dataSource, List<String> physicalLayerList, String domainID, String release, String serverID) {
        this.dataSource = dataSource;
        this.physicalLayerList = physicalLayerList;
        this.domainID = domainID;
        this.release = release;
        this.serverID = serverID;
    }

    public List<String> validateNLoad() {
        if ("".equals(serverID)) {
            traverseTopDown();
        } else {
            traverseBottomUp(executeSQL(getPhysicalLayerForServerSQL, serverID, release));
        }
        if (physicalLayerIDList.isEmpty() && !physicalLayerList.isEmpty()) {
            traverseBottomUp(executeSQL(guessPhysicalLayerByNameSQL, physicalLayerList.get(0), release, domainID));
        }
        return physicalLayerIDList;
    }

    private void traverseTopDown() {
        try {
            Connection conn = dataSource.getConnection();
            conn.setAutoCommit(false);
            PreparedStatement preStmt = conn.prepareStatement(traverseTopDownSQL);
            Long parentLayerID = -1L;
            for (String physicalLayerName : physicalLayerList) {
                preStmt.setString(1, domainID);
                preStmt.setString(2, release);
                preStmt.setString(3, physicalLayerName);
                preStmt.setLong(4, parentLayerID);

                ResultSet rs = preStmt.executeQuery();
                if (rs.next()) {
                    parentLayerID = rs.getLong(1);
                    physicalLayerIDList.add(Long.toString(parentLayerID));
                }
                rs.close();
            }
            preStmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String executeSQL(String SQL, String... args) {
        String ret = null;
        try {
            Connection conn = dataSource.getConnection();
            conn.setAutoCommit(false);
            PreparedStatement preStmt = conn.prepareStatement(SQL);
            for (int i=0; i < args.length; i++) {
                preStmt.setString(i+1, args[i]);
            }
            ResultSet rs = preStmt.executeQuery();
            if (rs.next()) {
                ret = rs.getString(1);
            }
            rs.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ret;
    }

    private void traverseBottomUp(String physicalLayerId) {
        if (physicalLayerId == null) return;
        try {
            Connection conn = dataSource.getConnection();
            conn.setAutoCommit(false);
            PreparedStatement preStmt = conn.prepareStatement(traverseBottomUpSQL);
            preStmt.setString(1, physicalLayerId);
            preStmt.setString(2, release);
            ResultSet rs = preStmt.executeQuery();
            while (rs.next()) {
                physicalLayerIDList.add(0, rs.getString(1));
            }
            rs.close();
            preStmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<String> getPhysicalLayerList() {
        return physicalLayerList;
    }

    public void setPhysicalLayerList(List<String> physicalLayerList) {
        this.physicalLayerList = physicalLayerList;
    }

    public String getServerID() {
        return serverID;
    }

    public void setServerID(String serverID) {
        this.serverID = serverID;
    }

    public String getDomainID() {
        return domainID;
    }

    public void setDomainID(String domainID) {
        this.domainID = domainID;
    }

    public String getRelease() {
        return release;
    }

    public void setRelease(String release) {
        this.release = release;
    }
}
