/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.service;

import com.wm.configmgmt.server.dao.IPublishRecordDAO;
import com.wm.configmgmt.server.dao.IPublishServerRecordDAO;
import com.wm.configmgmt.server.dataobject.*;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;

/**
 * PublishRecordService
 *
 * @author mma
 * @since 1.0
 */
public class PublishRecordService {
    private IPublishRecordDAO publishRecordDAO;
    private IPublishServerRecordDAO publishServerRecordDAO;

    @Transactional
    public List<PublishRecord> findAll(long domainId, String releaseVersion) {
        String query = "select pr from PublishRecord pr"
                + " where pr.domain.PK.id = ?1"
                + " and pr.domain.PK.releaseVersion = ?2"
                + " order by pr.createdDTM desc"
                ;
        List<PublishRecord> publishRecords = publishRecordDAO.findAllByQuery(query, domainId, releaseVersion);
        return publishRecords;
    }

    @Transactional
    public List<PublishServerRecord> findAllServerRecords(long publishRecordId, String releaseVersion) {
        String query = "select psr from PublishServerRecord psr"
                + " where psr.PK.id = ?1"
                + " and psr.PK.releaseVersion = ?2"
                + " order by psr.createdDTM desc"
                ;
        List<PublishServerRecord> publishServerRecords  = publishServerRecordDAO.findAllByQuery(query, publishRecordId, releaseVersion);
        if (publishServerRecords != null) for (PublishServerRecord publishServerRecord : publishServerRecords) {
            ServiceUtil.initialize(publishServerRecord.getServer());
        }
        return publishServerRecords;
    }

    @Transactional
    public PublishRecord find(long id, String releaseVersion) {
    	PublishRecord publishRecord = publishRecordDAO.findById(new VersionedKey(id, releaseVersion));
        return publishRecord;
    }

    @Transactional
    public PublishServerRecord findServerRecord(long id, String releaseVersion, long serverId) {
    	PublishServerRecord publishServerRecord = publishServerRecordDAO.findById(new VersionedKeyMulti(id, releaseVersion, serverId, null));
        return publishServerRecord;
    }

    @Transactional
    public PublishRecord findWithChildren(long id, String releaseVersion) {
        PublishRecord publishRecord = publishRecordDAO.findById(new VersionedKey(id, releaseVersion));
        if (publishRecord != null) {
        	ServiceUtil.initialize(publishRecord.getDomain());
        	ServiceUtil.initialize(publishRecord.getServerRecords());
        }
        return publishRecord;
    }
    
    @Transactional
    public PublishServerRecord findServerRecordWithChildren(long id, String releaseVersion, long serverId) {
    	PublishServerRecord publishServerRecord = publishServerRecordDAO.findById(
    			new VersionedKeyMulti(id, releaseVersion, serverId, null));
    	if (publishServerRecord != null) {
    		ServiceUtil.initialize(publishServerRecord.getServer());
    		ServiceUtil.initialize(publishServerRecord.getServerId());
    		ServiceUtil.initialize(publishServerRecord.getPublishRecordId());
    	}
        return publishServerRecord;
    }
    
    @Transactional
    public PublishRecord findByName(long domainId, String releaseVersion, String name) {
    	if (name == null || "".equals(name) || releaseVersion == null || "".equals(releaseVersion)) {
    		return null;
    	}
    	String query = "select o from PublishRecord o"
                + " where o.domain.PK.id = ?1"
                + " and o.domain.PK.releaseVersion = ?2 "
                + " and o.name = ?3"
    		;
    	List<PublishRecord> list = publishRecordDAO.findAllByQuery(query, domainId, releaseVersion, name);
    	return (list != null && list.size() > 0) ? list.get(0) : null;
    }

    @Transactional
    public void saveWithChildren(PublishRecord publishRecord, Set<Server> servers) {
    	this.save(publishRecord);
        if (servers != null) for (Server server : servers) {
            PublishServerRecord publishServerRecord = new PublishServerRecord();
            publishServerRecord.setCreatedBy(publishRecord.getCreatedBy());
            publishServerRecord.setCreatedDTM(publishRecord.getCreatedDTM());
            publishServerRecord.setPublishRecordId(publishRecord.getId());
            publishServerRecord.setReleaseVersion(publishRecord.getReleaseVersion());
            publishServerRecord.setServerId(server.getId());
            publishServerRecordDAO.insert(publishServerRecord);
        }
    }

    @Transactional
    public void save(PublishServerRecord publishServerRecord) {
        if (publishServerRecord.getResponseDTM() == null) {
            publishServerRecordDAO.insert(publishServerRecord);
        } else {
            publishServerRecordDAO.update(publishServerRecord);
        }
    }
    
    @Transactional
    public void save(PublishRecord publishRecord) {
    	if (publishRecord.getId() == null) {
    		publishRecordDAO.insert(publishRecord);
    	} else {
    		publishRecordDAO.update(publishRecord);
    	}
    }

    public void setPublishRecordDAO(IPublishRecordDAO publishRecordDAO) {
        this.publishRecordDAO = publishRecordDAO;
    }

    public void setPublishServerRecordDAO(IPublishServerRecordDAO publishServerRecordDAO) {
        this.publishServerRecordDAO = publishServerRecordDAO;
    }

}