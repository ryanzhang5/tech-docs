/**
 * Copyright 2009 Walmart.com. All rights Reserved
 */
package com.wm.configmgmt.server.security;

/**
 * @author Nagesh Cherukuri
 *
 */

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.NamingEnumeration;
import javax.naming.directory.*;
import java.util.Hashtable;
import java.util.ArrayList;
import java.util.List;

public class LDAPSecurityService implements ISecurityService {
    private static final Log log = LogFactory.getLog(LDAPSecurityService.class);

    private static final String DEFAULT_INITIAL_CONTEXT_FACTORY = "com.sun.jndi.ldap.LdapCtxFactory";
    private static final String DEFAULT_SECURITY_AUTHENTICATION = "simple";

    private static final String ATTR_CN = "cn";
    private static final String ATTR_UID = "uid";
    private static final String GROUP_DN = "ou=group,dc=walmart,dc=com";


    private String initialContextFactory = DEFAULT_INITIAL_CONTEXT_FACTORY;
    private String securityAuthentication = DEFAULT_SECURITY_AUTHENTICATION;
    private String providerURL; // ldap://cap-ldap1:389
    private String baseDN; // ou=People,dc=walmart,dc=com

    public User authenticate(String username, String password) throws AuthenticationException {
        String userDN = ATTR_UID + "=" + username + "," + baseDN;

        Hashtable authEnv = new Hashtable(6);
        authEnv.put(Context.INITIAL_CONTEXT_FACTORY, initialContextFactory);
        authEnv.put(Context.PROVIDER_URL, providerURL);
        authEnv.put(Context.SECURITY_AUTHENTICATION, securityAuthentication);

        User user = new User();
        try {
            
            // Step 0: Empty password not allowed
            if (password == null || password.length() == 0)
                throw new NamingException("Authentication failed");

            // Step 1: Bind anonymously
            DirContext ctx = new InitialDirContext(authEnv);

            // Step 2: Search the directory for groups
            String filter = "(&(memberUid={0}))";
            SearchControls ctls = new SearchControls();
            ctls.setSearchScope(SearchControls.SUBTREE_SCOPE);
            ctls.setReturningAttributes(new String[]{ATTR_CN});
            ctls.setReturningObjFlag(true);
            NamingEnumeration enm = ctx.search(GROUP_DN, filter, new String[]{username}, ctls);

            if (enm == null) {
                // uid not found
                throw new AuthenticationException("Authentication failed");
            }

            String dn = null;

            List<String> roleList = new ArrayList();
            while (enm.hasMore()) {
                SearchResult result = (SearchResult) enm.next();
                String role = result.getAttributes().get(ATTR_CN).get(0).toString();
                roleList.add(role);
                //System.out.println("role: "+role);
            }



            // Step 3: Bind with found DN and given password
            ctx.addToEnvironment(Context.SECURITY_PRINCIPAL, userDN);
            ctx.addToEnvironment(Context.SECURITY_CREDENTIALS, password);

            // Perform a lookup in order to force a bind operation with JNDI
            ctx.lookup(userDN);
            Attributes attrs = ctx.getAttributes(userDN);
            user.setFirstName((String) attrs.get(ATTR_CN).get());
            user.setUsername((String) attrs.get(ATTR_UID).get());
            String[] roleArray = roleList.toArray(new String[roleList.size()]);
            user.setRoles(roleArray);
            System.out.println("Authentication successful");
            ctx.close();
        } catch (NamingException e) {
            e.printStackTrace();
            throw new AuthenticationException("Authentication failed");
        } catch (Exception e) {
            throw new AuthenticationException("Authentication failed", e.fillInStackTrace());
        } finally {
            //ctx.close();
        }
        return user;
    }

    public String getInitialContextFactory() {
        return initialContextFactory;
    }

    public void setInitialContextFactory(String initialContextFactory) {
        this.initialContextFactory = initialContextFactory;
    }

    public String getSecurityAuthentication() {
        return securityAuthentication;
    }

    public void setSecurityAuthentication(String securityAuthentication) {
        this.securityAuthentication = securityAuthentication;
    }

    public String getProviderURL() {
        return providerURL;
    }

    public void setProviderURL(String providerURL) {
        this.providerURL = providerURL;
    }

    public String getBaseDN() {
        return baseDN;
    }

    public void setBaseDN(String baseDN) {
        this.baseDN = baseDN;
    }
}





