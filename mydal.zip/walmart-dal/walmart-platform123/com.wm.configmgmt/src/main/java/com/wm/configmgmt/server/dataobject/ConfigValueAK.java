package com.wm.configmgmt.server.dataobject;

import java.io.Serializable;

public class ConfigValueAK implements Serializable {
    private String id;
    private Long configId;
    private Long logicalLayerId;
    private Long physicalLayerId;
    private Long serverId;

    public ConfigValueAK() {

    }
    
    public ConfigValueAK(Long configId, Long logicalLayerId, Long physicalLayerId, Long serverId) {
        this.configId = configId;
        this.logicalLayerId = logicalLayerId;
        this.physicalLayerId = physicalLayerId;
        this.serverId = serverId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getConfigId() {
        return configId;
    }

    public void setConfigId(Long configId) {
        this.configId = configId;
    }

    public Long getLogicalLayerId() {
        return logicalLayerId;
    }

    public void setLogicalLayerId(Long logicalLayerId) {
        this.logicalLayerId = logicalLayerId;
    }

    public Long getPhysicalLayerId() {
        return physicalLayerId;
    }

    public void setPhysicalLayerId(Long physicalLayerId) {
        this.physicalLayerId = physicalLayerId;
    }

    public Long getServerId() {
        return serverId;
    }

    public void setServerId(Long serverId) {
        this.serverId = serverId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ConfigValueAK that = (ConfigValueAK) o;

        if (!configId.equals(that.configId)) return false;
        if (logicalLayerId != null ? !logicalLayerId.equals(that.logicalLayerId) : that.logicalLayerId != null)
            return false;
        if (physicalLayerId != null ? !physicalLayerId.equals(that.physicalLayerId) : that.physicalLayerId != null)
            return false;
        if (serverId != null ? !serverId.equals(that.serverId) : that.serverId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = configId.hashCode();
        result = 31 * result + (logicalLayerId != null ? logicalLayerId.hashCode() : 0);
        result = 31 * result + (physicalLayerId != null ? physicalLayerId.hashCode() : 0);
        result = 31 * result + (serverId != null ? serverId.hashCode() : 0);
        return result;
    }
}