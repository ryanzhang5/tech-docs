/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action.domain;

import com.wm.configmgmt.server.action.AbstractUserAction;
import com.wm.configmgmt.server.dataobject.Domain;
import com.wm.configmgmt.server.service.DomainService;

import java.util.ArrayList;
import java.util.List;

/**
 * DomainListAction
 *
 * @author mkishore
 * @since 1.0
 */
public class DomainListAction extends AbstractUserAction {
    private DomainService domainService;
    
    private List<Domain> list = new ArrayList<Domain>();

    public String list() {
        list = domainService.findAll();
        return SUCCESS;
    }

    public void setDomainService(DomainService domainService) {
        this.domainService = domainService;
    }

    public List<Domain> getList() {
        return list;
    }
}
