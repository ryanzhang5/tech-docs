/**
 * Copyright 2009 Walmart.com. All rights Reserved
 */
package com.wm.configmgmt.server.security;

import javax.naming.NamingException;

/**
 * @author Nagesh Cherukuri
 *
 */
public interface ISecurityService {

	public User authenticate(String username, String password)
		throws AuthenticationException;
}
