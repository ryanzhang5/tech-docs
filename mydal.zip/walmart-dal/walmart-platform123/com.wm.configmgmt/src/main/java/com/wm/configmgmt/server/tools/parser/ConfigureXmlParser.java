/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.tools.parser;


import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * This class takes a configure.xml and pushes it into the database.
 */
public class ConfigureXmlParser {
    protected static final Logger logger = Logger.getLogger(ConfigureXmlParser.class.getName());

    protected Map<String, List<String>> groupKeys = new LinkedHashMap<String, List<String>>();
    protected Map<String, String> keyPrompts = new LinkedHashMap<String, String>();
    protected Map<String, List<String[]>> keyValues = new LinkedHashMap<String, List<String[]>>();
    protected Map<String, List<Element>> failedRules = new LinkedHashMap<String, List<Element>>();

    public void parse(String confFile) {
        try {
            Document doc = new SAXBuilder().build(new FileInputStream(confFile));
            List<Element> keygroups = doc.getRootElement().getChild("keys").getChildren("keygroup");
            for (Element keygroup : keygroups) {
                parseKeyGroup(keygroup);
            }
        } catch (Exception ex) {
            throw new RuntimeException("Error parsing the confFile: " + confFile, ex);
        }
    }

    private void parseKeyGroup(Element keygroup) {
        if (!"keygroup".equals(keygroup.getName())) {
            logger.severe("Found unknown element instead of a <keygroup>: " + keygroup);
            return;
        }

        String groupName = keygroup.getAttributeValue("name");
        groupKeys.put(groupName, new ArrayList<String>());

        List<Element> keys = keygroup.getChildren("key");
        for (Element key : keys) {
            parseKey(groupName, key);
        }
    }

    private void parseKey(String groupName, Element key) {
        if (!"key".equals(key.getName())) {
            logger.severe("Found unknown element instead of a <key>: " + key);
            return;
        }

        String keyName = key.getAttributeValue("name");
        groupKeys.get(groupName).add(keyName);

        String prompt = key.getAttributeValue("prompt");
        if (prompt != null) keyPrompts.put(keyName, prompt);

        ArrayList<String[]> values = new ArrayList<String[]>();
        keyValues.put(keyName, values);

        String defVal = key.getAttributeValue("default");
        if (defVal != null) {
            values.add(new String[]{"", "", "", defVal});
        }

        List<Element> rules = key.getChildren("rule");
        if (rules != null) {
            for (Element rule : rules) {
                try {
                    parseRule(keyName, rule, values, new String[]{"", "", "", ""});
                } catch (Exception e) {
                    getFailedRulesForKey(keyName).add(rule);
                }
            }
        }
    }

    private void parseRule(String keyName, Element rule, ArrayList<String[]> values, String[] context) throws Exception {
        if (!"rule".equals(rule.getName())) {
            throw new RuntimeException("Found unknown element instead of a <rule>: " + rule);
        }

        if (!"exact".equals(rule.getAttributeValue("type"))) {
            throw new RuntimeException("Found a non-exact match for the rule: " + rule);
        }

        context = context.clone(); // to eliminate side-effects when coming out of recursive call

        String var = rule.getAttributeValue("var");
        String val = rule.getAttributeValue("val");
        if ("ENVIRONMENT".equals(var)) {
            context[0] = val;
        } else if ("APPLICATION".equals(var)) {
            context[1] = val;
        } else if ("HOSTNAME".equals(var)) {
            context[2] = val;
        } else {
            throw new RuntimeException("Found a rule based on something other than ENVIRONMENT, APPLICATION and HOSTNAME: " + rule);
        }

        Element keyval = rule.getChild("keyval");
        if (keyval != null) {
            context[3] = keyval.getAttributeValue("val");
            values.add(context);
            return;
        }

        List<Element> nestedRules = rule.getChildren("rule");
        if (nestedRules != null) {
            for (Element nestedRule : nestedRules) {
                try {
                    parseRule(keyName, nestedRule, values, context);
                } catch (Exception e) {
                    getFailedRulesForKey(keyName).add(nestedRule);
                }
            }
        } else {
            throw new RuntimeException("Found a rule that doesn't have a keyval and nested rules: " + rule);
        }

    }

    private List<Element> getFailedRulesForKey(String keyName) {
        List<Element> list = failedRules.get(keyName);
        if (list == null) {
            list = new ArrayList<Element>();
            failedRules.put(keyName, list);
        }
        return list;
    }


    public Map<String, List<String>> getGroupKeys() {
        return groupKeys;
    }

    public Map<String, String> getKeyPrompts() {
        return keyPrompts;
    }

    /**
     * index of String[] defined as following:
     * 0  PHYSICAL_LAYER_ID
     * 1  LOGICAL_LAYER_ID
     * 2  SERVER_ID
     * 3  VALUE
     *
     * @return
     */
    public Map<String, List<String[]>> getKeyValues() {
        return keyValues;
    }

    public Map<String, List<Element>> getFailedRules() {
        return failedRules;
    }

    public void printSuccessfulKeys() {
        StringBuilder sb = new StringBuilder("Successful Keys(" + keyValues.keySet().size() + "):\n");
        for (String key : keyValues.keySet()) {
            //sb.append(key).append(": \n");
            for (String[] value : keyValues.get(key)) {
                //sb.append("\tPHYSICAL_LAYER_ID=").append(value[0]).append(", LOGICAL_LAYER_ID=").append(value[1]).append(", SERVER_ID=").append(value[2]).append(", VALUE=").append(value[3]).append("\n");
            }
        }
        logger.log(Level.INFO, sb.toString());
    }

    public void printFailedRules() {
        StringWriter sw = new StringWriter();
        sw.append("Failed Rules (" + failedRules.size() + "):\n");
        for (String key : failedRules.keySet()) {
            sw.append(key).append(":\n");
            try {
                new XMLOutputter().output(failedRules.get(key), sw);
            } catch (IOException e) {
                sw.append("Error printing out the XML for key: " + key);
            }
            sw.append("\n");
        }
        logger.log(Level.INFO, sw.toString());
    }

    public void printUniqueNames() {
        Set<String> p = new TreeSet<String>();
        Set<String> l = new TreeSet<String>();
        Set<String> s = new TreeSet<String>();
        for (String key : keyValues.keySet()) {
            List<String[]> values = keyValues.get(key);
            for (String[] v : values) {
                p.add(v[0]);
                l.add(v[1]);
                s.add(v[2]);
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Physical Layers:");
        for (String name : p) {
            sb.append("\t").append(name).append("\n");
        }
        sb.append("Logical Layers:");
        for (String name : l) {
            sb.append("\t").append(name).append("\n");
        }
        sb.append("Servers:");
        for (String name : s) {
            sb.append("\t").append(name).append("\n");
        }
        logger.log(Level.INFO, sb.toString());
    }

    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Usage: java " + ConfigureXmlParser.class.getName() + " configure.xml");
            System.exit(1);
        }

        ConfigureXmlParser parser = new ConfigureXmlParser();
        parser.parse(args[0]);
        parser.printSuccessfulKeys();
        parser.printFailedRules();
        parser.printUniqueNames();
    }

}

