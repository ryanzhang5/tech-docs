/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dataobject;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

/**
 * Configuration Group - Can be used to optionally group together related sets
 * of configuration attributes. e.g "DAL Http Server".
 *
 * @author mkishore
 * @since 1.0
 */
public class ConfigGroup extends BaseDO implements ISoftDeletable, IVersionedDO, INamedDO, Cloneable {
    private VersionedKey PK = new VersionedKey();
    private Domain domain;
    private String name;
    private String description;
    private String ownerTeam;
    private String createdBy;
    private Timestamp createdDTM;
    private String modifiedBy;
    private Timestamp modifiedDTM;
    private boolean deleted;

    private Set<Config> configs = new HashSet<Config>();

    public VersionedKey getPK() {
        return PK;
    }

    public void setPK(VersionedKey PK) {
        this.PK = PK;
    }

    public Long getId() {
        return PK.getId();
    }

    public void setId(Long id) {
        PK.setId(id);
    }

    public String getReleaseVersion() {
        return PK.getReleaseVersion();
    }

    public void setReleaseVersion(String releaseVersion) {
        PK.setReleaseVersion(releaseVersion);
    }

    public Long getDomainId() {
        return (domain != null) ? domain.getId() : null;
    }

    public void setDomainId(Long id) {

    }
    
    public Domain getDomain() {
        return domain;
    }

    public void setDomain(Domain domain) {
        this.domain = domain;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getOwnerTeam() {
        return ownerTeam;
    }

    public void setOwnerTeam(String ownerTeam) {
        this.ownerTeam = ownerTeam;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDTM() {
        return createdDTM;
    }

    public void setCreatedDTM(Timestamp createdDTM) {
        this.createdDTM = createdDTM;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Timestamp getModifiedDTM() {
        return modifiedDTM;
    }

    public void setModifiedDTM(Timestamp modifiedDTM) {
        this.modifiedDTM = modifiedDTM;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public Set<Config> getConfigs() {
        return configs;
    }

    public void setConfigs(Set<Config> configs) {
        this.configs = configs;
    }
    
    public Object clone() throws CloneNotSupportedException {
    	return super.clone();
    }
}