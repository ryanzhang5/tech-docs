/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action.audit;

import com.wm.configmgmt.server.action.AbstractDomainAction;
import com.wm.configmgmt.server.dataobject.AuditEntry;
import com.wm.configmgmt.server.dataobject.AuditGroup;
import com.wm.configmgmt.server.service.ConfigValueService;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * AuditListAction
 *
 * @author mkishore
 * @since 1.0
 */
public class AuditListAction extends AbstractDomainAction {
    private ConfigValueService configValueService;

    private String ccref;
    private String maxDTM;
    private List<AuditGroup> auditGroups = new ArrayList<AuditGroup>();
    private List<AuditEntry> auditEntries = new ArrayList<AuditEntry>();

    public String list() {
        auditGroups = configValueService.findAllAuditGroups(domain.getId(), domain.getReleaseVersion());
        return SUCCESS;
    }

    public String detail() {
        auditEntries = configValueService.findAuditEntriesByCCReference(domain.getId(), domain.getReleaseVersion(), ccref);
        return SUCCESS;
    }

    public String rollback() {
        if (ccref != null) {
            configValueService.rollbackByCCReference(domain.getId(), domain.getReleaseVersion(), ccref, CCReference, user.getUsername());
        } else if (maxDTM != null) {
            try {
                Timestamp ts = new Timestamp(new SimpleDateFormat("MM/dd/yy HH:mm:ss").parse(maxDTM).getTime());
                configValueService.rollbackByTimestamp(domain.getId(), domain.getReleaseVersion(), ts, CCReference, user.getUsername());
            } catch (ParseException e) {
                this.addActionError("Could not parse the input timestamp: " + maxDTM);
                list();
                return INPUT;
            }
        }
        return SUCCESS;
    }

    public List<AuditGroup> getAuditGroups() {
        return auditGroups;
    }

    public List<AuditEntry> getAuditEntries() {
        return auditEntries;
    }

    public void setConfigValueService(ConfigValueService configValueService) {
        this.configValueService = configValueService;
    }

    public String getCcref() {
        return ccref;
    }

    public void setCcref(String ccref) {
        this.ccref = ccref;
    }

    public String getMaxDTM() {
        return maxDTM;
    }

    public void setMaxDTM(String maxDTM) {
        this.maxDTM = maxDTM;
    }
    
}