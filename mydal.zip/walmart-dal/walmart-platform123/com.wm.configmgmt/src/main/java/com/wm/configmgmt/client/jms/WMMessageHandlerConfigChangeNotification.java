/*
 * Copyright 2010 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.client.jms;

import com.wm.configmgmt.common.DriverManagerDataSource;
import com.wm.configmgmt.client.LoadConfig;
import com.wm.configmgmt.client.M4Processor;
import com.wm.configmgmt.common.jms.WMMessageConfigChangeAck;
import com.wm.configmgmt.common.jms.WMMessageConfigChangeNotification;
import com.wm.weblib.jms.*;
import com.wm.weblib.jms.common.WMAdminMessageHandler;

import java.io.*;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;



/**
 * WMMessageHandlerConfigChangeNotification - receives config change notification from the server
 * and updated the managed node.
 *
 * @author mkishore
 * @since 1.0
 */
public class WMMessageHandlerConfigChangeNotification extends WMAdminMessageHandler {
    private static final Logger logger = Logger.getLogger(WMMessageHandlerConfigChangeNotification.class.getName());

    private static final String JMS_QUEUE = "ConfigMgmtResponseListener"; // TODO: read this from configuration
    private static final long JMS_TTL = 60 * 60 * 1000; // 1 hour
    private static final String HOST_NAME = "com.wm.hostname.real";
    private static final String SNAPSHOT_FILE = ".snapshot.config";
    private static final String OS_FILE = System.getProperty("com.wm.app.home") + "/.osprop.incl";
    private static final String DBPROPS = "/conf/configdbprops/db.props.";



    protected boolean canHandle(WMMessage message) {
        return WMMessageType.MSG_TYPE_CONFIG_MGMT_NOTIFICATION.equals(message.getMessageType());
    }

    public WMMessageHandlerStatus handleMessage(WMMessage m) {

        logger.log(Level.INFO, " In Handler to handle the Config Notification");

        WMMessageConfigChangeAck.Payload messageAckPayLoad = new WMMessageConfigChangeAck.Payload();
        try {
            if (!canHandle(m)) return _defaultStatus;

            WMMessageConfigChangeNotification message = (WMMessageConfigChangeNotification) m;
            WMMessageConfigChangeNotification.Payload payload = message.getPayload();


            if (payload == null) throw new Exception("Payload is null");
            // TODO: process the payload - maybe implement a pluggable interface to be provided by the apps

            String hostname = System.getProperty(HOST_NAME);
            int ndxDot = hostname.indexOf('.');
            if (ndxDot > 0) hostname = hostname.substring(0, ndxDot);

            logger.log(Level.INFO, " Setting AckPayLoad");
            messageAckPayLoad.setPublishRecordId(payload.getPublishRecordId());
            messageAckPayLoad.setReleaseVersion(payload.getReleaseVersion());
            messageAckPayLoad.setResponseMessage(payload.getPublishMessage());
            messageAckPayLoad.setServerName(hostname);
            messageAckPayLoad.setResponseCode("-1");


            if (payload.getServerNames().contains(hostname)) {

                logger.log(Level.INFO, " Loading dataSource");
                //LoadConfig
                DriverManagerDataSource dataSource = new DriverManagerDataSource();
                try {
                    FileInputStream fis = new java.io.FileInputStream(new java.io.File(System.getProperty("com.wm.app.home") +DBPROPS +System.getProperty("com.wm.ApplicationEnvironment")));
                    Properties props = new Properties();
                    props.load(fis);
                    fis.close();

                    dataSource.setDriverClassName(props.getProperty("DRIVER_CLASS_NAME"));
                    dataSource.setUrl(props.getProperty("DB_CONN_STRING"));
                    dataSource.setUsername(props.getProperty("USER_NAME"));
                    dataSource.setPassword(props.getProperty("PASSWORD"));

                } catch (Exception e) {
                    e.printStackTrace();
                    throw new RuntimeException(e);
                }


                logger.log(Level.INFO, " Loading OS_FILE");
                Properties pro = new Properties();
                FileInputStream in = new FileInputStream(OS_FILE);
                pro.load(in);

                logger.log(Level.INFO, " Loading configuration" + pro);
                LoadConfig loader = new LoadConfig();
                //loader.setDataSource(dataSource);
                loader.setDataSource(dataSource);
                loader.setDomain(pro.getProperty("DOMAIN"));
                loader.setRelease(pro.getProperty("RELEASE"));
                loader.setEnv(pro.getProperty("ENVIRONMENT"));
                loader.setApp(pro.getProperty("APPLICATION"));
                loader.setServer(hostname);
                loader.initialize();
                loader.loadConfigMap();
                loader.applyOverrideConfig();
                loader.flush();
                loader.writeTmpStampFile();

                logger.log(Level.INFO, " Loading configuration complete");


                logger.log(Level.INFO, " Updating conf file" + System.getProperty("com.wm.conf") + " --Home--" + System.getProperty("com.wm.app.home") + SNAPSHOT_FILE);
                updateConfFile(System.getProperty("com.wm.conf"));


                logger.log(Level.INFO, " Updating VM");
                //LoadProps to app/system
                updateVM();
                messageAckPayLoad.setResponseCode("0");
            }

            _successStatus.setMessage(this.getClass().getName() + ": successfully processed message " + m);
            WMJMSObjectMessage ackMessage = new WMJMSObjectMessage(WMMessageType.MSG_TYPE_CONFIG_MGMT_ACK.toString(), ".*", messageAckPayLoad);
            SendJMSMsgToActiveMQ.sendAQObjectMessage(JMS_QUEUE, JMS_TTL, ackMessage, false);

        } catch (Exception e) {
            logger.log(Level.WARNING, "Unexpected error while handling message: " + m, e);
            messageAckPayLoad.setResponseCode("1");
            WMJMSObjectMessage ackMessage = new WMJMSObjectMessage(WMMessageType.MSG_TYPE_CONFIG_MGMT_ACK.toString(), ".*", messageAckPayLoad);
            SendJMSMsgToActiveMQ.sendAQObjectMessage(JMS_QUEUE, JMS_TTL, ackMessage, false);
            return new WMMessageHandlerStatus(WMMessageHandlerStatus.CODE_FAILURE, e.toString());
        }
        return _successStatus;
    }

    protected void updateVM() {
        //Load the properties ex:dal.conf to app/system context
        //App teams should override this method to load their props into their app.

    }

    public void updateConfFile(String m4FilePath) throws IOException {
        File source = new File(m4FilePath);

        // The target file name to which the source file will be copied.
        File target = new File(m4FilePath + ".backup");
       copy(source,target);

        StringBuilder input = new StringBuilder();
        BufferedReader br = new BufferedReader(new FileReader(m4FilePath + ".m4"));
        String line;
        while ((line = br.readLine()) != null) input.append(line).append("\n");
        Properties macros = new Properties();
        macros.load(new FileInputStream(System.getProperty("com.wm.app.home") + "/" + SNAPSHOT_FILE));

        String strOutput = M4Processor.process(input.toString(), macros);
        WriteFile(m4FilePath, strOutput.getBytes());

    }

    //Copies src file to dst file. // If the dst file does not exist, it is created
    void copy(File src, File dst) throws IOException {
        InputStream in = new FileInputStream(src);
        OutputStream out = new FileOutputStream(dst);
        // Transfer bytes from in to out
        byte[] buf = new byte[1024];
        int len;
        while ((len = in.read(buf)) > 0) {
            out.write(buf, 0, len);
        }
        in.close();
        out.close();
    }


    // helper function to write a byte array into a file

    private void WriteFile(String strFile, byte[] pData) throws IOException {
        BufferedOutputStream outStream = new BufferedOutputStream(new FileOutputStream(strFile), 32768);
        if (pData.length > 0) outStream.write(pData, 0, pData.length);
        outStream.close();
    }
}
