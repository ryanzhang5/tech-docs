/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.IBaseDO;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Base interface for all DAO interfaces
 *
 * @author mkishore
 * @version $Revision: 1.2 $
 * @since 4/2009
 */
public interface IBaseDAO<T extends IBaseDO, ID extends Serializable> {
    /**
     * Make the entity instances managed and persistent.
     *
     * @param entities - the list of entities to be persisted
     * @see javax.persistence.EntityManager#persist
     */
    void insert(T... entities);

    /**
     * Merge the state of the given entity into the current persistence context.
     *
     * @param entity - the detached object that needs to be merged in
     * @return the instance that the state was merged to
     * @see javax.persistence.EntityManager#merge
     */
    T update(T entity);

    /**
     * Merge the state of the given entities into the current persistence context.
     *
     * @param entities - the list of detached objects that needs to be merged in
     * @return the list of instances that the state was merged to
     * @see javax.persistence.EntityManager#merge
     */
    List<T> update(List<T> entities);

    /**
     * Remove the entity instances.
     *
     * @param entities - the list of entities to be removed
     * @see javax.persistence.EntityManager#remove
     */
    void delete(T... entities);

    /**
     * Refresh the state of the instances from the database, overwriting changes made to the entities, if any.
     *
     * @param entities - the list of entities to be refreshed
     * @see javax.persistence.EntityManager#refresh
     */
    void refresh(T... entities);

    /**
     * Check if the instance belongs to the current persistence context.
     *
     * @param entity - the entity to check for
     * @return true if the instance belongs to the current persistence context.
     * @see javax.persistence.EntityManager#contains
     */
    boolean contains(T entity);

    /**
     * Get an instance, whose state may be lazily fetched.
     *
     * @param id - id of the entity to be fetched
     * @return the found entity instance.
     * @see javax.persistence.EntityManager#getReference
     */
    T getReference(ID id);

    /**
     * Find by primary key.
     *
     * @param id - primary key
     * @return the found entity instance or null if the entity does not exist.
     * @see javax.persistence.EntityManager#find
     */
    T findById(ID id);

    /**
     * Find a list of entities by their primary keys.
     *
     * @param ids - list of primary keys
     * @return the List of found entity instances or null if the entity does not exist.
     * @see javax.persistence.EntityManager#find
     */
    List<T> findById(List<ID> ids);

    /**
     * Finds all entities based on the Java Persistence query language statement.
     *
     * @param queryString - a Java Persistence query language query string
     * @param params      - list of positional parameter values
     * @return a List of entities
     */
    List<T> findAllByQuery(String queryString, Object... params);

    /**
     * Finds a subset of entities based on the Java Persistence query language statement.
     *
     * @param queryString - a Java Persistence query language query string
     * @param params      - list of positional parameter values
     * @param startIndex  - position of the first result to retrieve
     * @param maxResults  - maximum number of results to retrieve
     * @return a sub-List of entities
     */
    List<T> findByQuery(String queryString, Object[] params, int startIndex, int maxResults);

    /**
     * Finds all entities based on the Java Persistence query language statement.
     *
     * @param queryString - a Java Persistence query language query string
     * @param params      - map of named parameter values
     * @return a List of entities
     */
    List<T> findAllByQueryAndNamedParams(String queryString, Map<String, ?> params);

    /**
     * Finds all entities based on the Java Persistence query language statement.
     *
     * @param queryString - a Java Persistence query language query string
     * @param params      - map of named parameter values
     * @param startIndex  - position of the first result to retrieve
     * @param maxResults  - maximum number of results to retrieve
     * @return a sub-List of entities
     */
    List<T> findByQueryAndNamedParams(String queryString, Map<String, ?> params, int startIndex, int maxResults);

    /**
     * Finds all entities based on the named query (in the Java Persistence query language or in native SQL).
     *
     * @param queryName - a named query (in the Java Persistence query language or in native SQL).
     * @param params    - list of positional parameter values
     * @return a List of entities
     */
    List<T> findAllByNamedQuery(String queryName, Object... params);

    /**
     * Finds all entities based on the named query (in the Java Persistence query language or in native SQL).
     *
     * @param queryName  - a named query (in the Java Persistence query language or in native SQL).
     * @param params     - list of positional parameter values
     * @param startIndex - position of the first result to retrieve
     * @param maxResults - maximum number of results to retrieve
     * @return a sub-List of entities
     */
    List<T> findByNamedQuery(String queryName, Object[] params, int startIndex, int maxResults);

    /**
     * Finds all entities based on the named query (in the Java Persistence query language or in native SQL).
     *
     * @param queryName - a named query (in the Java Persistence query language or in native SQL)
     * @param params    - map of named parameter values
     * @return a List of entities
     */
    List<T> findAllByNamedQueryAndNamedParams(String queryName, Map<String, ?> params);

    /**
     * Finds all entities based on the named query (in the Java Persistence query language or in native SQL).
     *
     * @param queryName  - a named query (in the Java Persistence query language or in native SQL)
     * @param params     - map of named parameter values
     * @param startIndex - position of the first result to retrieve
     * @param maxResults - maximum number of results to retrieve
     * @return a sub-List of entities
     */
    List<T> findByNamedQueryAndNamedParams(String queryName, Map<String, ?> params, int startIndex, int maxResults);

    /*

    void flush();

    void clear();

    void lock(T entity, LockModeType mode);

    boolean isOpen(); // app managed EM

    void close(); // app managed EM

    EntityTransaction getTransaction(); // resource local transaction

    void joinTransaction(); // allows a non-transacted EM to join a JTA one

    */

}