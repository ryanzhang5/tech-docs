/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dataobject;

import java.sql.Timestamp;

/**
 * Keeps track of which servers are the target of a given publish attempt,
 * and if the management server got a successful response from the managed node..
 *
 * @author mkishore
 * @since 1.0
 */
public class PublishServerRecord extends BaseDO implements Cloneable {
    private VersionedKeyMulti PK = new VersionedKeyMulti();
    private String responseCode;
    private String responseMessage;
    private Timestamp responseDTM;
    private String createdBy;
    private Timestamp createdDTM;
    private Server server;

    public VersionedKeyMulti getPK() {
        return PK;
    }

    public void setPK(VersionedKeyMulti PK) {
        this.PK = PK;
    }

    public Long getPublishRecordId() {
        return PK.getId();
    }

    public void setPublishRecordId(Long publishRecordId) {
        PK.setId(publishRecordId);
    }

    public String getReleaseVersion() {
        return PK.getReleaseVersion();
    }

    public void setReleaseVersion(String releaseVersion) {
        PK.setReleaseVersion(releaseVersion);
    }

    public Long getServerId() {
        return PK.getId1();
    }

    public void setServerId(Long serverId) {
        PK.setId1(serverId);
    }

    public Server getServer() {
        return server;
    }

    public void setServer(Server server) {
        this.server = server;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public String getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }

    public Timestamp getResponseDTM() {
        return responseDTM;
    }

    public void setResponseDTM(Timestamp responseDTM) {
        this.responseDTM = responseDTM;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDTM() {
        return createdDTM;
    }

    public void setCreatedDTM(Timestamp createdDTM) {
        this.createdDTM = createdDTM;
    }

    public Object clone() throws CloneNotSupportedException {
    	return super.clone();
    }
}