/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.PublishRecord;
import com.wm.configmgmt.server.dataobject.VersionedKey;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * PublishRecordDAO
 *
 * @author mkishore
 * @since 1.0
 */
public class PublishRecordDAO extends BaseDAO<PublishRecord, VersionedKey> implements IPublishRecordDAO {
    @PersistenceContext (name = "configmgmt")
    public void setEntityManager(EntityManager entityManager) {
        super.setEntityManager(entityManager);
    }
}