/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dataobject;

/**
 * IVersionedDO
 *
 * @author mkishore
 * @since 1.0
 */
public interface IVersionedDO extends IBaseDO {
    /**
     * Returns the primary-key object for this DO
     *
     * @return the primary-key object for this DO
     */
    public VersionedKey getPK();

    /**
     * Sets the primary-key object for this DO.
     *
     * @param PK the primary-key object for this DO
     */
    public void setPK(VersionedKey PK);
}
