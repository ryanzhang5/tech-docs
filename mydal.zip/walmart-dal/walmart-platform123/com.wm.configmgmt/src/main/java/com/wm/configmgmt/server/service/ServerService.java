/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.service;

import com.wm.configmgmt.server.dao.IConfigValueDAO;
import com.wm.configmgmt.server.dao.IServerDAO;
import com.wm.configmgmt.server.dataobject.ConfigValue;
import com.wm.configmgmt.server.dataobject.Server;
import com.wm.configmgmt.server.dataobject.VersionedKey;
import org.springframework.transaction.annotation.Transactional;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * ServerService
 *
 * @author mkishore
 * @since 1.0
 */
public class ServerService {
    private IServerDAO serverDAO;
    private IConfigValueDAO configValueDAO;

    private ServerGroupService serverGroupService;

    @Transactional
    public List<Server> findAll(long domainId, String releaseVersion) {
        String query = "select s from Server s"
                + " where s.domain.PK.id = ?1"
                + " and s.domain.PK.releaseVersion = ?2"
                ;
        List<Server> servers = serverDAO.findAllByQuery(query, domainId, releaseVersion);
        return servers;
    }

    @Transactional
    public List<Server> findByPhysicalLayerOrNull(long domainId, String releaseVersion, Long physicalLayerId) {
        String query = "select s from Server s"
                + " where s.domain.PK.id = ?1"
                + " and s.domain.PK.releaseVersion = ?2"
                + " and (s.physicalLayerId is null or s.physicalLayerId = ?3)"
                ;
        List<Server> servers = serverDAO.findAllByQuery(query, domainId, releaseVersion, physicalLayerId);
        return servers;
    }

    @Transactional
    public Server find(long id, String releaseVersion) {
        Server server = serverDAO.findById(new VersionedKey(id, releaseVersion));
        return server;
    }
    
    @Transactional
    public Server findWithChildren(long id, String releaseVersion) {
    	Server srvr = serverDAO.findById(new VersionedKey(id, releaseVersion));
        if (srvr != null) {
        	ServiceUtil.initialize(srvr.getDomain());
        	ServiceUtil.initialize(srvr.getPhysicalLayer());
        	ServiceUtil.initialize(srvr.getConfigValues());
        }
        return srvr;
    }
    
    @Transactional
    public Server findByName(long domainId, String releaseVersion, String name) {
    	if (name == null || "".equals(name) || releaseVersion == null || "".equals(releaseVersion)) {
    		return null;
    	}
    	String query = "select o from Server o"
                + " where o.domain.PK.id = ?1"
                + " and o.domain.PK.releaseVersion = ?2 "
                + " and o.name = ?3"
    		;
    	List<Server> list = serverDAO.findAllByQuery(query, domainId, releaseVersion, name);
    	return (list != null && list.size() > 0) ? list.get(0) : null;
    }

    @Transactional
    public void save(Server... servers) throws DuplicateException {
        for (Server server : servers) {
            Server namedDO = findByName(server.getDomainId(), server.getReleaseVersion(), server.getName());
            if (server.getId() == null) {
                if (namedDO != null) {
                    throw new DuplicateException();
                }
                serverDAO.insert(server);
            } else {
                if (namedDO != null && !namedDO.getId().equals(server.getId())) {
                    throw new DuplicateException();
                }
                serverDAO.update(server);
            }
        }
    }

    @Transactional
    public void delete(long id, String releaseVersion) {
    	Server server = findWithChildren(id, releaseVersion);
    	if (server != null) {
	    	Set<ConfigValue> configValues = server.getConfigValues();
	    	if (configValues != null && configValues.size() > 0) {
                for (Iterator<ConfigValue> it = configValues.iterator(); it.hasNext();) {
                    ConfigValue configValue = it.next();
                    if (configValue != null) {
                        configValueDAO.delete(configValue);
                        it.remove();
                    }

                }
	        }
            serverGroupService.deleteServer(server.getId(), server.getReleaseVersion());
	    	serverDAO.delete(server);
    	}
    }

    public void setServerDAO(IServerDAO serverDAO) {
        this.serverDAO = serverDAO;
    }
    
    public void setConfigValueDAO(IConfigValueDAO configValueDAO) {
    	this.configValueDAO = configValueDAO;
    }

    public void setServerGroupService(ServerGroupService serverGroupService) {
        this.serverGroupService = serverGroupService;
    }
}