/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dataobject;

/**
 * INamedEntity
 *
 * @author mkishore
 * @since 1.0
 */
public interface INamedDO {
    public String getName();
}
