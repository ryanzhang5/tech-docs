/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.PublishServerRecord;
import com.wm.configmgmt.server.dataobject.VersionedKeyMulti;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * PublishServerRecordDAO
 *
 * @author mkishore
 * @since 1.0
 */
public class PublishServerRecordDAO extends BaseDAO<PublishServerRecord, VersionedKeyMulti> implements IPublishServerRecordDAO {
    @PersistenceContext (name = "configmgmt")
    public void setEntityManager(EntityManager entityManager) {
        super.setEntityManager(entityManager);
    }
}