package com.wm.configmgmt.server.tools.migration;

import com.wm.configmgmt.common.tools.CLI;
import oracle.xml.sql.dml.OracleXMLSave;

import java.sql.*;
import java.util.List;
import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.sql.DataSource;

public class Purger {
    static {
        try {
            DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private DataSource dataSource;

    private String domain;
    private String release;

    public static final String SQL_DOMAIN = "select * from domain " +
            " where name = ? " +
            " and rel_version = ? ";

    private static final String DELETE_PUBLISH_SERVER_MAP = "delete from publish_server_map psm " +
            " where (publish_record_id, rel_version) in ( " +
            "   select pr.publish_record_id, pr.rel_version from publish_record pr " +
            "   where pr.domain_id= ? " +
            "   and pr.rel_version = ? " +
            " )";
    private static final String DELETE_PUBLISH_RECORD = "delete from publish_record " +
            " where domain_id = ? " +
            " and rel_version = ?";
    private static final String DELETE_SRVGRP_SERVER_MAP = "delete from srvgrp_server_map ssm " +
            " where (server_group_id, rel_version) in ( " +
            "   select sg.server_group_id, sg.rel_version from server_group sg " +
            "   where sg.domain_id= ? " +
            "   and sg.rel_version = ? " +
            " )";
    private static final String DELETE_SRVGRP_GROUP_MAP = "delete from srvgrp_group_map sgm " +
            " where (server_group_id, rel_version) in ( " +
            "   select sg.server_group_id, sg.rel_version from server_group sg " +
            "   where sg.domain_id= ? " +
            "   and sg.rel_version = ? " +
            " )";
    private static final String DELETE_SERVER_GROUP = "delete from server_group " +
            " where domain_id = ? " +
            " and rel_version = ?";
    private static final String DELETE_CONFIG_VALUE = "delete from config_value cv " +
            " where (config_id, rel_version) in ( " +
            "   select c.config_id, c.rel_version from config c " +
            "   where c.domain_id= ? " +
            "   and c.rel_version = ? " +
            " )";
    private static final String DELETE_SERVER = "delete from server " +
            " where domain_id = ? " +
            " and rel_version = ?";
    private static final String DELETE_LOGICAL_LAYER = "delete from logical_layer " +
            " where domain_id = ? " +
            " and rel_version = ?";
    private static final String DELETE_PHYSICAL_LAYER = "delete from physical_layer " +
            " where domain_id = ? " +
            " and rel_version = ?";
    private static final String DELETE_CONFIG = "delete from config " +
            " where domain_id = ? " +
            " and rel_version = ?";
    private static final String DELETE_CONFIG_GROUP = "delete from config_group " +
            " where domain_id = ? " +
            " and rel_version = ?";
    private static final String DELETE_DOMAIN = "delete from domain " +
            " where domain_id = ? " +
            " and rel_version = ?";

    private List<Long> getDomainIds() {
        List<Long> domainIds = new ArrayList<Long>();
        Connection conn = null;
        PreparedStatement psmt = null;
        ResultSet rset = null;
        try {
            conn = dataSource.getConnection();
            psmt = conn.prepareStatement(SQL_DOMAIN);
            psmt.setString(1, domain);
            psmt.setString(2, release);
            rset = psmt.executeQuery();
            while (rset.next()) {
                domainIds.add(rset.getLong("domain_id"));
            }
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        } finally {
            safeClose(rset, psmt, conn);
        }
        System.out.println("Found [" + domainIds.size() + "] domainId(s) matching the inputs");
        return domainIds;
    }

    public void execute() {
        validateArgs();
        
        Connection conn = null;
        PreparedStatement psmt = null;
        List<Long> domainIds = getDomainIds();
        for (Long domainId : domainIds) {
            try {
                conn = dataSource.getConnection();
                conn.setAutoCommit(false);
                execute(conn, DELETE_PUBLISH_SERVER_MAP, domainId, release);
                execute(conn, DELETE_PUBLISH_RECORD, domainId, release);
                execute(conn, DELETE_SRVGRP_SERVER_MAP, domainId, release);
                execute(conn, DELETE_SRVGRP_GROUP_MAP, domainId, release);
                execute(conn, DELETE_SERVER_GROUP, domainId, release);
                execute(conn, DELETE_CONFIG_VALUE, domainId, release);
                execute(conn, DELETE_SERVER, domainId, release);
                execute(conn, DELETE_LOGICAL_LAYER, domainId, release);
                execute(conn, DELETE_PHYSICAL_LAYER, domainId, release);
                execute(conn, DELETE_CONFIG, domainId, release);
                execute(conn, DELETE_CONFIG_GROUP, domainId, release);
                execute(conn, DELETE_DOMAIN, domainId, release);
                conn.commit();
                System.out.println("Successfully deleted data for domainId: " + domainId);
            } catch (Exception e) {
                System.out.println("Failed to delete data for domainId: " + domainId);
                try {
                    if (conn != null) conn.rollback();
                } catch (SQLException e1) {
                    System.out.println("Error rolling back the changes");
                }
                throw new RuntimeException(e);
            } finally {
                safeClose(null, psmt, conn);
            }
        }
    }

    private void execute(Connection conn, String sql, Object... params) throws SQLException {
        PreparedStatement pstmt = conn.prepareStatement(sql);
        try {
            if (params != null) for (int i = 0; i < params.length; i++) {
                Object param = params[i];
                pstmt.setObject(i + 1, param);
            }
            pstmt.executeUpdate();
        } finally {
            safeClose(null, pstmt, null);
        }
    }

    private void safeClose(ResultSet rs, Statement stmt, Connection conn) {
        safeClose(rs, stmt, conn, null);
    }

    private void safeClose(ResultSet rs, Statement stmt, Connection conn, OracleXMLSave sav) {
        if (rs != null) try {
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (stmt != null) try {
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (conn != null) try {
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (sav != null) try {
            sav.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getRelease() {
        return release;
    }

    public void setRelease(String release) {
        this.release = release;
    }

    public static void main(String[] args) {
        Purger main = new Purger();
        CLI.parse(args, main);
        ApplicationContext appContext = new ClassPathXmlApplicationContext("/dataSource.xml");
        main.setDataSource((DataSource) appContext.getBean("native_dataSource"));
        main.execute();
    }

    private void validateArgs() {
        if (this.getDataSource() == null) {
            throw new RuntimeException("Please check the dataSource.xml file - 'dataSource' bean not found");
        }
        if (this.getDomain() == null) {
            throw new RuntimeException("--domain : Domain Name is needed.");
        }
        if (this.getRelease() == null) {
            throw new RuntimeException("--release : Release Version is needed.");
        }
    }

}