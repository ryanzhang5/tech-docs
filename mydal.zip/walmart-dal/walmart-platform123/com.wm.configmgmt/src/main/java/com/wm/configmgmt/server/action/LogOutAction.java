package com.wm.configmgmt.server.action;

import com.opensymphony.xwork2.ActionSupport;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts2.interceptor.SessionAware;

import java.util.Map;


/**
 * LogOutAction is used to log the user out,when Signout is clicked. 
 * Copyright 2009 Walmart.com. All rights reserved.
 *
 * @author Nagesh Cherukuri
 *         Date: Dec 8, 2009
 *         Time: 5:31:38 PM
 */
public class LogOutAction extends ActionSupport implements SessionAware {
    private static final Log log = LogFactory.getLog(LogOutAction.class);
    private Map<String, Object> session;

    public void setSession(Map<String, Object> session) {
        this.session = session;
    }

    public String execute() throws Exception {
        log.info("Clear User Handle " + session.get("WM_USER_SESSSION_HANDLE"));
        session.remove("WM_USER_SESSSION_HANDLE");        
        session.clear();
        log.info("Cleared the user from Session");
        return "login";
    }

}