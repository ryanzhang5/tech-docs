/*
 * Copyright 2010 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.common.jms;

import com.wm.weblib.jms.WMMessageAdmin;
import com.wm.weblib.jms.WMMessageException;
import com.wm.weblib.jms.WMMessageType;

import java.io.Serializable;
import java.util.HashMap;

/**
 * WMConfigChangeAckMessage - sent from the managed nodes back to the management server
 *
 * @author mkishore
 * @since 1.0
 */
public class WMMessageConfigChangeAck extends WMMessageAdmin {
    public static class Payload implements Serializable {
        private Long publishRecordId;
        private String releaseVersion;
        private String serverName;
        private String responseCode;
        private String responseMessage;

        public Long getPublishRecordId() {
            return publishRecordId;
        }

        public void setPublishRecordId(Long publishRecordId) {
            this.publishRecordId = publishRecordId;
        }

        public String getReleaseVersion() {
            return releaseVersion;
        }

        public void setReleaseVersion(String releaseVersion) {
            this.releaseVersion = releaseVersion;
        }

        public String getServerName() {
            return serverName;
        }

        public void setServerName(String serverName) {
            this.serverName = serverName;
        }

        public String getResponseCode() {
            return responseCode;
        }

        public void setResponseCode(String responseCode) {
            this.responseCode = responseCode;
        }

        public String getResponseMessage() {
            return responseMessage;
        }

        public void setResponseMessage(String responseMessage) {
            this.responseMessage = responseMessage;
        }

        @Override
        public String toString() {
            StringBuilder s = new StringBuilder();
            s.append("{ publishRecordId: ").append(this.getPublishRecordId());
            s.append(", releaseVersion: ").append(this.getReleaseVersion());
            s.append(", serverName: ").append(this.getServerName());
            s.append(", responseCode: ").append(this.getResponseCode());
            s.append(", responseMessage: ").append(this.getResponseMessage());
            s.append(" }");
            return s.toString();
        }

    }

    public WMMessageConfigChangeAck(HashMap valueMap) throws WMMessageException {
        super(WMMessageType.MSG_TYPE_CONFIG_MGMT_ACK, valueMap);
    }

    @Override
    public void setObjectMessage(Serializable objmsg) {
        if (objmsg == null || objmsg instanceof Payload) {
            super.setObjectMessage(objmsg);
        } else {
            throw new IllegalArgumentException("This class expects a Payload argument, found: " + objmsg.getClass());
        }
    }

    public Payload getPayload() {
        return (Payload) super.getObjectMessage();
    }
}