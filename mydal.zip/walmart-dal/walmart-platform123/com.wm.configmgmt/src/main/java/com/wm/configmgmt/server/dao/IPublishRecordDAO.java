/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.PublishRecord;
import com.wm.configmgmt.server.dataobject.VersionedKey;

/**
 * IPublishRecordDAO
 *
 * @author mkishore
 * @since 1.0
 */
public interface IPublishRecordDAO extends IBaseDAO<PublishRecord, VersionedKey> {

}