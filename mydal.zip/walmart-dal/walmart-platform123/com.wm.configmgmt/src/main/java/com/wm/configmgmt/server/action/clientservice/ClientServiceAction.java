/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action.clientservice;

import com.wm.configmgmt.server.action.AbstractUserAction;
import com.wm.configmgmt.server.service.ClientServiceService;
import org.apache.struts2.interceptor.ParameterAware;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Map;

/**
 * ClientServiceAction
 *
 * @author pho
 * @since 1.0
 */
public class ClientServiceAction extends AbstractUserAction implements ParameterAware {

    private ClientServiceService clientServiceService;
    private Map<String, String[]> parameters;
    private InputStream exportOutput;

    public String exportOverrides() {
        String xml = clientServiceService.export(this.parameters);
        this.exportOutput = new ByteArrayInputStream(xml.getBytes());
        return SUCCESS;
    }

    public void setClientServiceService(ClientServiceService clientServiceService) {
        this.clientServiceService = clientServiceService;
    }

    public void setParameters(Map<String, String[]> parameters) { 
        this.parameters = parameters;
    }

    public InputStream getExportOutput() {
        return this.exportOutput;
    }

}
