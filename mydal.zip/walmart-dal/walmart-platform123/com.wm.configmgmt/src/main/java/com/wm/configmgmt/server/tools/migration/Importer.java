package com.wm.configmgmt.server.tools.migration;

import com.wm.configmgmt.common.tools.CLI;
import oracle.xml.sql.dml.OracleXMLSave;

import javax.sql.DataSource;
import java.net.URL;
import java.sql.*;
import java.io.File;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Importer {
    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH.mm.ss.SSS";

    private DataSource dataSource;

    private String path;

    private static final String DOMAIN_TABLE_NAME = "DOMAIN";
    private static final String CONFIG_GROUP_TABLE_NAME = "CONFIG_GROUP";
    private static final String CONFIG_TABLE_NAME = "CONFIG";
    private static final String CONFIG_VALUE_TABLE_NAME = "CONFIG_VALUE";
    private static final String PHYSICAL_LAYER_TABLE_NAME = "PHYSICAL_LAYER";
    private static final String LOGICAL_LAYER_TABLE_NAME = "LOGICAL_LAYER";
    private static final String PUBLISH_RECORD_TABLE_NAME = "PUBLISH_RECORD";
    private static final String PUBLISH_SERVER_RECORD_TABLE_NAME = "PUBLISH_SERVER_MAP";
    private static final String SERVER_TABLE_NAME = "SERVER";
    private static final String SERVER_GROUP_TABLE_NAME = "SERVER_GROUP";
    private static final String SERVER_GROUP_GROUP_TABLE_NAME = "SRVGRP_GROUP_MAP";
    private static final String SERVER_GROUP_SERVER_TABLE_NAME = "SRVGRP_SERVER_MAP";

    private static final String DOMAIN_XMLFILE_NAME = "domain.xml";
    private static final String CONFIG_GROUP_XMLFILE_NAME = "config_group.xml";
    private static final String CONFIG_XMLFILE_NAME = "config.xml";
    private static final String CONFIG_VALUE_XMLFILE_NAME = "config_value.xml";
    private static final String PHYSICAL_LAYER_XMLFILE_NAME = "physical_layer.xml";
    private static final String LOGICAL_LAYER_XMLFILE_NAME = "logical_layer.xml";
    private static final String PUBLISH_RECORD_XMLFILE_NAME = "publish_record.xml";
    private static final String PUBLISH_SERVER_RECORD_XMLFILE_NAME = "publish_server_record.xml";
    private static final String SERVER_XMLFILE_NAME = "server.xml";
    private static final String SERVER_GROUP_XMLFILE_NAME = "server_group.xml";
    private static final String SERVER_GROUP_GROUP_XMLFILE_NAME = "server_group_group.xml";
    private static final String SERVER_GROUP_SERVER_XMLFILE_NAME = "server_group_server.xml";

    private static final String RESET_CONFIG = "{ call reset_sequence('SEQ_CONFIG','CONFIG','CONFIG_ID') }";
    private static final String RESET_CONFIG_GROUP = "{ call reset_sequence('SEQ_CONFIG_GROUP','CONFIG_GROUP','CONFIG_GROUP_ID') }";
    private static final String RESET_CONFIG_VALUE = "{ call reset_sequence('SEQ_CONFIG_VALUE','CONFIG_VALUE','CONFIG_VALUE_ID') }";
    private static final String RESET_DOMAIN = "{ call reset_sequence('SEQ_DOMAIN','DOMAIN','DOMAIN_ID') }";
    private static final String RESET_LOGICAL_LAYER = "{ call reset_sequence('SEQ_LOGICAL_LAYER','LOGICAL_LAYER','LAYER_ID') }";
    private static final String RESET_PHYSICAL_LAYER = "{ call reset_sequence('SEQ_PHYSICAL_LAYER','PHYSICAL_LAYER','LAYER_ID') }";
    private static final String RESET_PUBLISH_RECORD = "{ call reset_sequence('SEQ_PUBLISH_RECORD','PUBLISH_RECORD','PUBLISH_RECORD_ID') }";
    private static final String RESET_SERVER = "{ call reset_sequence('SEQ_SERVER','SERVER','SERVER_ID') }";
    private static final String RESET_SERVER_GROUP = "{ call reset_sequence('SEQ_SERVER_GROUP','SERVER_GROUP','SERVER_GROUP_ID') }";

    private static final String GET_MAX_CONFIG = "select max(CONFIG_ID) from CONFIG";
    private static final String GET_MAX_CONFIG_GROUP = "select max(CONFIG_GROUP_ID) from CONFIG_GROUP";
    private static final String GET_MAX_CONFIG_VALUE = "select max(CONFIG_VALUE_ID) from CONFIG_VALUE";
    private static final String GET_MAX_DOMAIN = "select max(DOMAIN_ID) from DOMAIN";
    private static final String GET_MAX_LOGICAL_LAYER = "select max(LAYER_ID) from LOGICAL_LAYER";
    private static final String GET_MAX_PHYSICAL_LAYER = "select max(LAYER_ID) from PHYSICAL_LAYER";
    private static final String GET_MAX_PUBLISH_RECORD = "select max(PUBLISH_RECORD_ID) from PUBLISH_RECORD";
    private static final String GET_MAX_SERVER = "select max(SERVER_ID) from SERVER";
    private static final String GET_MAX_SERVER_GROUP = "select max(SERVER_GROUP_ID) from SERVER_GROUP";

    private static final String INCR_SEQ_CONFIG = "select SEQ_CONFIG.nextval from dual";
    private static final String INCR_SEQ_CONFIG_GROUP = "select SEQ_CONFIG_GROUP.nextval from dual";
    private static final String INCR_SEQ_CONFIG_VALUE = "select SEQ_CONFIG_VALUE.nextval from dual";
    private static final String INCR_SEQ_DOMAIN = "select SEQ_DOMAIN.nextval from dual";
    private static final String INCR_SEQ_LOGICAL_LAYER = "select SEQ_LOGICAL_LAYER.nextval from dual";
    private static final String INCR_SEQ_PHYSICAL_LAYER = "select SEQ_PHYSICAL_LAYER.nextval from dual";
    private static final String INCR_SEQ_PUBLISH_RECORD = "select SEQ_PUBLISH_RECORD.nextval from dual";
    private static final String INCR_SEQ_SERVER = "select SEQ_SERVER.nextval from dual";
    private static final String INCR_SEQ_SERVER_GROUP = "select SEQ_SERVER_GROUP.nextval from dual";

    private void insertXmlFile(Connection conn, String fileName, String tableName) {
        OracleXMLSave sav = null;
        try {
            fileName = prependFilePath(fileName);
            if (!new File(fileName).exists()) {
                System.out.println("Could not find the file: " + fileName);
                return;
            }
            sav = new OracleXMLSave(conn, tableName);
            sav.setBatchSize(1);
            sav.setCommitBatch(1);
            sav.setDateFormat(DATE_TIME_FORMAT);
            URL url = OracleXMLSave.getURL(fileName);
            int rowCount = sav.insertXML(url);
            System.out.println("Successfully inserted " + rowCount + " rows into " + tableName);
        } catch (Exception e) {
            if (e.getMessage().contains("No rows to modify")) {
                System.out.println("No rows to insert for: " + fileName);
            } else {
                System.out.println("Fail to insert values to from: " + fileName);
                throw new RuntimeException(e);
            }
        } finally {
            safeClose(null, null, null, sav);
        }
    }

    private void resetSequences(Connection conn) {
        Statement stmt = null;
        try {
            stmt = conn.createStatement();
            /*
            resetSequence(stmt, RESET_CONFIG);
            resetSequence(stmt, RESET_CONFIG_GROUP);
            resetSequence(stmt, RESET_CONFIG_VALUE);
            resetSequence(stmt, RESET_DOMAIN);
            resetSequence(stmt, RESET_LOGICAL_LAYER);
            resetSequence(stmt, RESET_PHYSICAL_LAYER);
            resetSequence(stmt, RESET_PUBLISH_RECORD);
            resetSequence(stmt, RESET_SERVER);
            resetSequence(stmt, RESET_SERVER_GROUP);
            */
            resetSequence(stmt, GET_MAX_CONFIG, INCR_SEQ_CONFIG);
            resetSequence(stmt, GET_MAX_CONFIG_GROUP, INCR_SEQ_CONFIG_GROUP);
            resetSequence(stmt, GET_MAX_CONFIG_VALUE, INCR_SEQ_CONFIG_VALUE);
            resetSequence(stmt, GET_MAX_DOMAIN, INCR_SEQ_DOMAIN);
            resetSequence(stmt, GET_MAX_LOGICAL_LAYER, INCR_SEQ_LOGICAL_LAYER);
            resetSequence(stmt, GET_MAX_PHYSICAL_LAYER, INCR_SEQ_PHYSICAL_LAYER);
            resetSequence(stmt, GET_MAX_PUBLISH_RECORD, INCR_SEQ_PUBLISH_RECORD);
            resetSequence(stmt, GET_MAX_SERVER, INCR_SEQ_SERVER);
            resetSequence(stmt, GET_MAX_SERVER_GROUP, INCR_SEQ_SERVER_GROUP);
        } catch (Exception e) {
            System.out.println("Failed to call reset procedure in target database.");
            throw new RuntimeException(e);
        } finally {
            safeClose(null, stmt, null);
        }
    }

    private void resetSequence(Statement stmt, String getMaxSQL, String incrSeqSQL) throws SQLException {
        // stmt.executeUpdate(resetSQL);
        ResultSet rs = stmt.executeQuery(getMaxSQL);
        if (rs.next()) {
            long maxId = rs.getLong(1);
            rs.close();
            long nextVal = Long.MAX_VALUE;
            do {
                rs = stmt.executeQuery(incrSeqSQL);
                if (rs.next()) {
                    nextVal = rs.getLong(1);
                }
            } while (nextVal < maxId);
        }
    }

    public void execute() {
        validateArgs();

        Connection conn = null;
        try {
            conn = dataSource.getConnection();
            conn.setAutoCommit(false);

            insertXmlFile(conn, DOMAIN_XMLFILE_NAME, DOMAIN_TABLE_NAME);
            insertXmlFile(conn, CONFIG_GROUP_XMLFILE_NAME, CONFIG_GROUP_TABLE_NAME);
            insertXmlFile(conn, CONFIG_XMLFILE_NAME, CONFIG_TABLE_NAME);
            insertXmlFile(conn, PHYSICAL_LAYER_XMLFILE_NAME, PHYSICAL_LAYER_TABLE_NAME);
            insertXmlFile(conn, LOGICAL_LAYER_XMLFILE_NAME, LOGICAL_LAYER_TABLE_NAME);
            insertXmlFile(conn, SERVER_XMLFILE_NAME, SERVER_TABLE_NAME);
            insertXmlFile(conn, CONFIG_VALUE_XMLFILE_NAME, CONFIG_VALUE_TABLE_NAME);
            insertXmlFile(conn, SERVER_GROUP_XMLFILE_NAME, SERVER_GROUP_TABLE_NAME);
            insertXmlFile(conn, SERVER_GROUP_GROUP_XMLFILE_NAME, SERVER_GROUP_GROUP_TABLE_NAME);
            insertXmlFile(conn, SERVER_GROUP_SERVER_XMLFILE_NAME, SERVER_GROUP_SERVER_TABLE_NAME);
            insertXmlFile(conn, PUBLISH_RECORD_XMLFILE_NAME, PUBLISH_RECORD_TABLE_NAME);
            insertXmlFile(conn, PUBLISH_SERVER_RECORD_XMLFILE_NAME, PUBLISH_SERVER_RECORD_TABLE_NAME);
            System.out.println("Successfully inserted values from all xml files.");

            resetSequences(conn);
            System.out.println("Successfully reset sequences in target database.");

            conn.commit();
        } catch (Exception e) {
            if (conn != null) try {
                conn.rollback();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
            throw new RuntimeException(e);
        } finally {
            safeClose(null, null, conn);
        }
    }

    private void safeClose(ResultSet rs, Statement stmt, Connection conn) {
        safeClose(rs, stmt, conn, null);
    }

    private void safeClose(ResultSet rs, Statement stmt, Connection conn, OracleXMLSave sav) {
        if (rs != null) try {
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (stmt != null) try {
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (conn != null) try {
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (sav != null) try {
            sav.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String prependFilePath(String fileName) {
        if (this.path != null && !"".equals(this.path)) {
            fileName = this.path + "/" + fileName;
        }
        return fileName;
    }

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public static void main(String[] args) {
        Importer main = new Importer();
        CLI.parse(args, main);
        ApplicationContext appContext = new ClassPathXmlApplicationContext("/dataSource.xml");
        main.setDataSource((DataSource) appContext.getBean("native_dataSource"));
        main.execute();
    }

    private void validateArgs() {
        if (this.getDataSource() == null) {
            throw new RuntimeException("Please check the dataSource.xml file - 'dataSource' bean not found");
        }
        if (this.getPath() == null) {
            throw new RuntimeException("--path : File path is needed.");
        }
    }
}