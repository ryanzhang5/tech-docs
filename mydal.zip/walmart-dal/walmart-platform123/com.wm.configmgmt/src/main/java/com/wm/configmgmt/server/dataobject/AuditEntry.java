/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dataobject;

import java.sql.Timestamp;

/**
 * AuditEntry - represents an atomic change to a configuration value
 *
 * @author mkishore
 * @since 1.0
 */
public class AuditEntry extends BaseDO {
    // copied from ConfigValue
    private VersionedKey PK = new VersionedKey();
    private Long configId;
    private Long physicalLayerId;
    private Long logicalLayerId;
    private Long serverId;
    private String value;
    private String CCReference;
    private String createdBy;
    private Timestamp createdDTM;
    private boolean deleted;

    // additional fields
    private String configName;
    private String logicalLayerName;
    private String physicalLayerName;
    private String serverName;

    public VersionedKey getPK() {
        return PK;
    }

    public void setPK(VersionedKey PK) {
        this.PK = PK;
    }

    public Long getConfigId() {
        return configId;
    }

    public void setConfigId(Long configId) {
        this.configId = configId;
    }

    public Long getPhysicalLayerId() {
        return physicalLayerId;
    }

    public void setPhysicalLayerId(Long physicalLayerId) {
        this.physicalLayerId = physicalLayerId;
    }

    public Long getLogicalLayerId() {
        return logicalLayerId;
    }

    public void setLogicalLayerId(Long logicalLayerId) {
        this.logicalLayerId = logicalLayerId;
    }

    public Long getServerId() {
        return serverId;
    }

    public void setServerId(Long serverId) {
        this.serverId = serverId;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getCCReference() {
        return CCReference;
    }

    public void setCCReference(String CCReference) {
        this.CCReference = CCReference;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDTM() {
        return createdDTM;
    }

    public void setCreatedDTM(Timestamp createdDTM) {
        this.createdDTM = createdDTM;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }
    public String getConfigName() {
        return configName;
    }

    public void setConfigName(String configName) {
        this.configName = configName;
    }

    public String getLogicalLayerName() {
        return logicalLayerName;
    }

    public void setLogicalLayerName(String logicalLayerName) {
        this.logicalLayerName = logicalLayerName;
    }

    public String getPhysicalLayerName() {
        return physicalLayerName;
    }

    public void setPhysicalLayerName(String physicalLayerName) {
        this.physicalLayerName = physicalLayerName;
    }

    public String getServerName() {
        return serverName;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

}
