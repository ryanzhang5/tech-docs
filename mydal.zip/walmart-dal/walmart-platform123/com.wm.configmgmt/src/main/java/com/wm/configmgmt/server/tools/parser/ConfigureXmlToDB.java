/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.tools.parser;

import com.wm.configmgmt.server.dataobject.*;
import com.wm.configmgmt.server.service.*;
import com.wm.configmgmt.common.tools.CLI;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.util.List;
import java.util.Set;

/**
 * This class is a helper tool for the ConfigureRuleParser
 */
public class ConfigureXmlToDB extends ConfigureXmlParser {
    private String domain;
    private String release;
    private String ccreference;
    private String username;

    private DomainService domainService;
    private ConfigGroupService configGroupService;
    private ConfigService configService;
    private ConfigValueService configValueService;
    private PhysicalLayerService physicalLayerService;
    private LogicalLayerService logicalLayerService;
    private ServerService serverService;

    @Transactional
    public void saveValues() throws DuplicateException {
        Timestamp now = new Timestamp(System.currentTimeMillis());
        Domain domain = domainService.findByName(this.domain, this.release);
        if (domain == null) {
            domain = new Domain();
            domain.setReleaseVersion(this.release);
            domain.setName(this.domain);
            domain.setDescription("");
            domain.setCreatedBy(username);
            domain.setCreatedDTM(now);
            domainService.save(domain);
        }
        long domainId = domain.getId();
        Set<String> keyGroupNames = this.groupKeys.keySet();
        for (String keyGroupName : keyGroupNames) {
            ConfigGroup configGroup = configGroupService.findByName(domainId, release, keyGroupName);
            if (configGroup == null) {
                configGroup = new ConfigGroup();
                configGroup.setDomain(domain);
                configGroup.setReleaseVersion(this.release);
                configGroup.setName(keyGroupName);
                configGroup.setDescription("");
                configGroup.setCreatedBy(username);
                configGroup.setCreatedDTM(now);
                configGroupService.save(configGroup);
            }
            List<String> keys = this.groupKeys.get(keyGroupName);
            for (String keyName : keys) {
                Config config = configService.findByName(domainId, release, keyName);
                if (config == null) {
                    config = new Config();
                    config.setDomain(domain);
                    config.setReleaseVersion(this.release);
                    config.setConfigGroup(configGroup);
                    config.setName(keyName);
                    config.setDescription(keyPrompts.get(keyName));
                    config.setCreatedBy(username);
                    config.setCreatedDTM(now);
                    configService.save(config);
                }
                List<String[]> list = this.keyValues.get(keyName);
                for (String[] values : list) {
                    String physicalLayerName = values[0];
                    String logicalLayerName = values[1];
                    String serverName = values[2];
                    String value = values[3];
                    // Look for physical layer according to physical layer name
                    PhysicalLayer physicalLayer = null;
                    if (physicalLayerName != null && !"".equals(physicalLayerName)) {
                        physicalLayer = physicalLayerService.findByName(domainId, release, physicalLayerName);
                        if (physicalLayer == null) {
                            physicalLayer = new PhysicalLayer();
                            physicalLayer.setReleaseVersion(domain.getReleaseVersion());
                            physicalLayer.setDomain(domain);
                            physicalLayer.setParentLayer(null);
                            physicalLayer.setName(physicalLayerName);
                            physicalLayer.setDescription("");
                            physicalLayer.setCreatedBy(username);
                            physicalLayer.setCreatedDTM(now);
                            physicalLayerService.save(physicalLayer);
                        }
                    }
                    // Look for logical layer according to logical layer name
                    LogicalLayer logicalLayer = null;
                    if (logicalLayerName != null && !"".equals(logicalLayerName)) {
                        logicalLayer = logicalLayerService.findByName(domainId, release, logicalLayerName);
                        if (logicalLayer == null) {
                            logicalLayer = new LogicalLayer();
                            logicalLayer.setReleaseVersion(domain.getReleaseVersion());
                            logicalLayer.setDomain(domain);
                            logicalLayer.setParentLayer(null);
                            logicalLayer.setName(logicalLayerName);
                            logicalLayer.setDescription("");
                            logicalLayer.setCreatedBy(username);
                            logicalLayer.setCreatedDTM(now);
                            logicalLayerService.save(logicalLayer);
                        }
                    }
                    // Look for server according to server name
                    Server server = null;
                    if (serverName != null && !"".equals(serverName)) {
                        server = serverService.findByName(domainId, release, serverName);
                        if (server == null) {
                            server = new Server();
                            server.setReleaseVersion(domain.getReleaseVersion());
                            server.setDomain(domain);
                            server.setPhysicalLayer(null);
                            server.setName(serverName);
                            server.setDescription("");
                            server.setCreatedBy(username);
                            server.setCreatedDTM(now);
                            serverService.save(server);
                        }
                    }
                    // Look for configvalue according to configvalue keys
                    ConfigValue configValue = configValueService.findByName(domain.getReleaseVersion(), config, physicalLayer, logicalLayer, server);
                    if (configValue == null
                            || (value == null && configValue.getValue() != null)
                            || (value != null && !value.equals(configValue.getValue()))) {
                        configValue = new ConfigValue();
                        configValue.setReleaseVersion(domain.getReleaseVersion());
                        configValue.setConfig(config);
                        configValue.setPhysicalLayer(physicalLayer);
                        configValue.setLogicalLayer(logicalLayer);
                        configValue.setServer(server);
                        configValue.setValue(value);
                        configValue.setCCReference(ccreference);
                        configValue.setCreatedBy(username);
                        configValue.setCreatedDTM(now);
                    }
                    configValueService.save(configValue);
                }
            }
        }
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getRelease() {
        return release;
    }

    public void setRelease(String release) {
        this.release = release;
    }

    public String getCcreference() {
        return ccreference;
    }

    public void setCcreference(String ccreference) {
        this.ccreference = ccreference;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setDomainService(DomainService domainService) {
        this.domainService = domainService;
    }

    public void setConfigService(ConfigService configService) {
        this.configService = configService;
    }

    public void setConfigGroupService(ConfigGroupService configGroupService) {
        this.configGroupService = configGroupService;
    }

    public void setConfigValueService(ConfigValueService configValueService) {
        this.configValueService = configValueService;
    }

    public void setPhysicalLayerService(PhysicalLayerService physicalLayerService) {
        this.physicalLayerService = physicalLayerService;
    }

    public void setLogicalLayerService(LogicalLayerService logicalLayerService) {
        this.logicalLayerService = logicalLayerService;
    }

    public void setServerService(ServerService serverService) {
        this.serverService = serverService;
    }

    public static void main(String[] args) {
        try {
            ApplicationContext appContext = new ClassPathXmlApplicationContext("/applicationContext.xml");
            ConfigureXmlToDB xmlToDB = (ConfigureXmlToDB) appContext.getBean("xml2db");
            String file = CLI.parse(args, xmlToDB)[0];
            xmlToDB.validateArgs();
            xmlToDB.parse(file);
            xmlToDB.saveValues();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void validateArgs() {
        if (this.getDomain() == null) {
            throw new RuntimeException("--domain : Domain Name is needed.");
        }
        if (this.getRelease() == null) {
            throw new RuntimeException("--release : Release Version is needed.");
        }
        if (this.getUsername() == null) {
            throw new RuntimeException("--username : User name is needed.");
        }
        if (this.getCcreference() == null) {
            throw new RuntimeException("--ccreference : CC-Reference is needed.");
        }
    }
}
