package com.wm.configmgmt.server.util;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.ApplicationContext;

import java.io.IOException;
import java.util.Properties;

/**
 * Single point of property provider for both
 * - the application runtime, as well as
 * - the spring configuration file 
 */
public class AppProperties extends PropertyPlaceholderConfigurer {
    private static final Properties EMPTY_PROPS = new Properties();

    private static Properties properties;

    private static Properties getProperties() {
        if (properties != null) {
            return properties;
        }
        ApplicationContext context = AppContextProvider.appContext;
        if (context != null) {
            AppProperties appProperties = (AppProperties) context.getBean("appProperties");
            try {
                properties = appProperties.mergeProperties();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        // TODO: log severe error 
        return EMPTY_PROPS;
    }

    public static String getProperty(String name) {
        return getProperties().getProperty(name);
    }


}
