/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action.servergroup;

import com.wm.configmgmt.server.action.AbstractDomainAction;
import com.wm.configmgmt.server.dataobject.NamedDOComparator;
import com.wm.configmgmt.server.dataobject.ServerGroup;
import com.wm.configmgmt.server.service.ServerGroupService;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * ServerGroupListAction
 *
 * @author mkishore
 * @since 1.0
 */
public class ServerGroupListAction extends AbstractDomainAction {
    private ServerGroupService serverGroupService;

    private List<ServerGroup> serverGroups = new ArrayList<ServerGroup>();

    public String list() {
        serverGroups = serverGroupService.findAll(domain.getId(), domain.getReleaseVersion());
        Collections.sort(serverGroups, new NamedDOComparator());
        return SUCCESS;
    }

    public List<ServerGroup> getServerGroups() {
        return serverGroups;
    }

    public void setServerGroupService(ServerGroupService serverGroupService) {
        this.serverGroupService = serverGroupService;
    }

}