/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.Config;
import com.wm.configmgmt.server.dataobject.VersionedKey;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.sql.Timestamp;

/**
 * ConfigDAO
 *
 * @author mkishore
 * @since 1.0
 */
public class ConfigDAO extends SoftDeleteDAO<Config, VersionedKey> implements IConfigDAO {
    @PersistenceContext (name = "configmgmt")
    public void setEntityManager(EntityManager entityManager) {
        super.setEntityManager(entityManager);
    }

    public void delete(String user, Timestamp dtm, Config... entities) {
        for (Config config : entities) {
            config.setModifiedBy(user);
            config.setModifiedDTM(dtm);
        }
        super.delete(entities);
    }
}