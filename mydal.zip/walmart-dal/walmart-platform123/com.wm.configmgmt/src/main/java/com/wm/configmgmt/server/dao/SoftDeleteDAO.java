/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.ISoftDeletable;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Arrays;

/**
 * DAO that converts all DELETEs to UPDATEs (with the IS_DELETED flag set to true)
 *
 * @author mkishore
 * @since 1.0
 */
public abstract class SoftDeleteDAO<T extends ISoftDeletable, ID extends Serializable> extends BaseDAO<T, ID> {
    /**
     * Remove the entity instances.
     *
     * @param entities - the list of entities to be removed
     * @see javax.persistence.EntityManager#remove
     */
    @Override
    public void delete(T... entities) {
        // Is this a hack? Should we have the clients pass in the actual TS?
        // But then, the clients need to be aware that this is a soft delete
        Timestamp now = new Timestamp(System.currentTimeMillis());
        for (T entity : entities) {
            entity.setDeleted(true);
            entity.setModifiedDTM(now);
        }
        super.update(Arrays.asList(entities));
    }
}
