/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.service;

import java.util.Collection;

/**
 * ServiceUtil
 *
 * @author mkishore
 * @since 1.0
 */
public class ServiceUtil {
    public static void initialize(Object proxy) {
        if (proxy == null) {
            // no-op
        } else if (proxy instanceof Collection) {
            ((Collection) proxy).size();
        } else {
            if (invoke(proxy, "getName")) return;
            if (invoke(proxy, "getId")) return;
        }
    }

    private static boolean invoke(Object proxy, String method) {
        try {
            Class clazz = proxy.getClass();
            clazz.getMethod(method).invoke(proxy);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
