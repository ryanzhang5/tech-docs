/*
 * Copyright 2010 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.common.tools;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * CLI - helps build command line tools by parsing the command line options
 * and initializing a POJO.
 *
 * @author mkishore
 * @since 1.0
 */
public class CLI {
    private static final String[] EMPTY_ARRAY = new String[0];

    public static String[] parse(String[] args, Object pojo) {
        if (args == null) return EMPTY_ARRAY;

        List<String> nonProps = new ArrayList<String>();
        for (String arg : args) {
            if (!injectProperty(arg, pojo)) {
                nonProps.add(arg);
            }
        }
        return nonProps.toArray(new String[nonProps.size()]);
    }

    public static boolean injectProperty(String arg, Object pojo) {
        if (arg == null || !arg.startsWith("--") || arg.indexOf('=') < 0) return false;

        int ndxEquals = arg.indexOf('=');
        String propName = arg.substring(2, ndxEquals);
        try {
            Method setter = pojo.getClass().getMethod(
                    "set"
                    + Character.toUpperCase(propName.charAt(0))
                    + propName.substring(1),
                    String.class
            );
            if (setter != null) {
                setter.invoke(pojo, arg.substring(ndxEquals+1));
                return true;
            }
        } catch (Exception e) {
            // no-op; ignore all errors, and assume that it is not a property
        }
        return false;
    }
}
