/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.security;

/**
 * TestSecurityServiceImpl
 *
 * @author mkishore
 * @since 1.0
 */
public class TestSecurityService implements ISecurityService {
    public User authenticate(String username, String password) throws AuthenticationException {
        return new User("Test User", "test", "user", "", new String[0]);
    }
}
