/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.service;

import com.wm.configmgmt.server.dao.IConfigGroupDAO;
import com.wm.configmgmt.server.dataobject.Config;
import com.wm.configmgmt.server.dataobject.ConfigGroup;
import com.wm.configmgmt.server.dataobject.VersionedKey;
import org.springframework.transaction.annotation.Transactional;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * ConfigGroupService
 *
 * @author mkishore
 * @since 1.0
 */
public class ConfigGroupService {
    private IConfigGroupDAO configGroupDAO;
    private ConfigService configService;

    @Transactional
    public List<ConfigGroup> findAll(long domainId, String releaseVersion) {
        String query = "select cg from ConfigGroup cg"
                + " where cg.domain.PK.id = ?1"
                + " and cg.domain.PK.releaseVersion = ?2"
                ;
        List<ConfigGroup> configGroups = configGroupDAO.findAllByQuery(query, domainId, releaseVersion);
        return configGroups;
    }
    
    @Transactional
    public ConfigGroup find(long id, String releaseVersion) {
        ConfigGroup configGroup = configGroupDAO.findById(new VersionedKey(id, releaseVersion));
        return configGroup;
    }
    
    @Transactional
    public ConfigGroup findWithChildren(long id, String releaseVersion) {
        ConfigGroup configGroup = configGroupDAO.findById(new VersionedKey(id, releaseVersion));
        if (configGroup != null) {
        	ServiceUtil.initialize(configGroup.getConfigs());
        	ServiceUtil.initialize(configGroup.getDomain());
        }
        return configGroup;
    }
    
    @Transactional
    public ConfigGroup findByName(long domainId, String releaseVersion, String name) {
    	if (name == null || "".equals(name) || releaseVersion == null || "".equals(releaseVersion)) {
    		return null;
    	}
    	String query = "select o from ConfigGroup o"
                + " where o.domain.PK.id = ?1"
                + " and o.domain.PK.releaseVersion = ?2 "
                + " and o.name = ?3"
    		;
    	List<ConfigGroup> list = configGroupDAO.findAllByQuery(query, domainId, releaseVersion, name);
    	return (list != null && list.size() > 0) ? list.get(0) : null;
    }

    @Transactional
    public void save(ConfigGroup configGroup) throws DuplicateException {
        ConfigGroup namedDO = findByName(configGroup.getDomainId(), configGroup.getReleaseVersion(), configGroup.getName());
        if (configGroup.getId() == null) {
            if (namedDO != null) {
                throw new DuplicateException();
            }
            configGroupDAO.insert(configGroup);
        } else {
            if (namedDO != null && !namedDO.getId().equals(configGroup.getId())) {
                throw new DuplicateException();
            }
            configGroupDAO.update(configGroup);
        }
    }

    @Transactional
    public void delete(long id, String releaseVersion) {
    	ConfigGroup configGroup = findWithChildren(id, releaseVersion);
    	if (configGroup != null) {
	    	Set<Config> configs = configGroup.getConfigs();
	    	if (configs != null && configs.size() > 0) {
                for (Iterator<Config> it = configs.iterator(); it.hasNext();) {
                    Config config = it.next();
                    if (config != null) {
                        try {
                            config.setConfigGroup(null);
                            configService.save(config);
                            it.remove();
                        } catch (DuplicateException e) {
                            // should never happen as we are not changing the name
                            throw new RuntimeException(e);
                        }
                    }
                }
	        }
	    	configGroupDAO.delete(configGroup);
    	}
    }

    public void setConfigGroupDAO(IConfigGroupDAO configGroupDAO) {
        this.configGroupDAO = configGroupDAO;
    }
    
    public void setConfigService(ConfigService configService) {
    	this.configService = configService;
    }
}