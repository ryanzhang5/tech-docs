/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dataobject;

import java.sql.Timestamp;
import java.util.HashSet;
import java.util.Set;

/**
 * The server groups are purely used for publishing change notifications.
 * These groups are not used to define overriding configuration values.
 * As such, a given group can contain other groups and/or servers as its members.
 * A given group can be part of multiple other groups.
 *
 * @author mkishore
 * @since 1.0
 */
public class ServerGroup extends BaseDO implements ISoftDeletable, IVersionedDO, INamedDO, Cloneable {
    private VersionedKey PK = new VersionedKey();
    private Domain domain;
    private String name;
    private String description;
    private String createdBy;
    private Timestamp createdDTM;
    private String modifiedBy;
    private Timestamp modifiedDTM;
    private boolean deleted;

    private Set<ServerGroupGroup> childGroups = new HashSet<ServerGroupGroup>();
    private Set<ServerGroupServer> servers = new HashSet<ServerGroupServer>();

    public VersionedKey getPK() {
        return PK;
    }

    public void setPK(VersionedKey PK) {
        this.PK = PK;
    }

    public Long getId() {
        return PK.getId();
    }

    public void setId(Long id) {
        PK.setId(id);
    }

    public String getReleaseVersion() {
        return PK.getReleaseVersion();
    }

    public void setReleaseVersion(String releaseVersion) {
        PK.setReleaseVersion(releaseVersion);
    }

    public Long getDomainId() {
        return (domain != null) ? domain.getId() : null;
    }

    public void setDomainId(Long id) {
        
    }

    public Domain getDomain() {
        return domain;
    }

    public void setDomain(Domain domain) {
        this.domain = domain;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Timestamp getCreatedDTM() {
        return createdDTM;
    }

    public void setCreatedDTM(Timestamp createdDTM) {
        this.createdDTM = createdDTM;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Timestamp getModifiedDTM() {
        return modifiedDTM;
    }

    public void setModifiedDTM(Timestamp modifiedDTM) {
        this.modifiedDTM = modifiedDTM;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public Set<ServerGroupGroup> getChildGroups() {
        return childGroups;
    }

    public void setChildGroups(Set<ServerGroupGroup> childGroups) {
        this.childGroups = childGroups;
    }

    public Set<ServerGroupServer> getServers() {
        return servers;
    }

    public void setServers(Set<ServerGroupServer> servers) {
        this.servers = servers;
    }

    public Object clone() throws CloneNotSupportedException {
    	return super.clone();
    }
}