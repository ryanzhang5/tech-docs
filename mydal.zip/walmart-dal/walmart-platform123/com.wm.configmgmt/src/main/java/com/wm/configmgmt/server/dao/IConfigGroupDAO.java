/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dao;

import com.wm.configmgmt.server.dataobject.ConfigGroup;
import com.wm.configmgmt.server.dataobject.VersionedKey;

/**
 * IConfigGroupDAO
 *
 * @author mkishore
 * @since 1.0
 */
public interface IConfigGroupDAO extends IBaseDAO<ConfigGroup, VersionedKey> {

}