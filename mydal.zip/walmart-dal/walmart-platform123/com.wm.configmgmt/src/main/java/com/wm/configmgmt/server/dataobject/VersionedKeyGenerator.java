/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.dataobject;

import org.hibernate.HibernateException;
import org.hibernate.MappingException;
import org.hibernate.dialect.Dialect;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.id.Configurable;
import org.hibernate.id.IdentifierGenerator;
import org.hibernate.id.IdentifierGeneratorFactory;
import org.hibernate.id.PersistentIdentifierGenerator;
import org.hibernate.property.BasicPropertyAccessor;
import org.hibernate.property.Getter;
import org.hibernate.type.LongType;
import org.hibernate.type.Type;

import java.io.Serializable;
import java.util.Properties;

/**
 * VersionedKeyGenerator
 *
 * @author mkishore
 * @since 1.0
 */
public class VersionedKeyGenerator implements PersistentIdentifierGenerator, Configurable {
    private static final LongType LONG_TYPE = new LongType();

    private static final String PARAM_STRATEGY = "vkg_strategy";
    private static final String PARAM_PKPROPERTY = "vkg_pkproperty";

    private IdentifierGenerator delegate;
    private String pkProperty;

    public void configure(Type type, Properties properties, Dialect dialect) throws MappingException {
        String strategy = properties.getProperty(PARAM_STRATEGY, "sequence");
        pkProperty = properties.getProperty(PARAM_PKPROPERTY, "PK");
        delegate = IdentifierGeneratorFactory.create(strategy, LONG_TYPE, properties, dialect);
    }

    public Serializable generate(SessionImplementor sessionImplementor, Object o) throws HibernateException {
        Getter getter = BasicPropertyAccessor.createGetter(o.getClass(), pkProperty);
        Object pk = (getter != null) ? getter.get(o) : null;
        if (pk instanceof VersionedKey) {
            VersionedKey vk = (VersionedKey) pk;
            if (vk.getId() == null) {
                Long id = (Long) delegate.generate(sessionImplementor, o);
                vk.setId(id);
            }
        }
        return (pk instanceof Serializable) ?(Serializable)pk :null;
    }

    public String[] sqlCreateStrings(Dialect dialect) throws HibernateException {
        return (delegate instanceof PersistentIdentifierGenerator)
                ? ((PersistentIdentifierGenerator)delegate).sqlCreateStrings(dialect)
                : new String[0];
    }

    public String[] sqlDropStrings(Dialect dialect) throws HibernateException {
        return (delegate instanceof PersistentIdentifierGenerator)
                ? ((PersistentIdentifierGenerator)delegate).sqlDropStrings(dialect)
                : new String[0];
    }

    public Object generatorKey() {
        return (delegate instanceof PersistentIdentifierGenerator)
                ? ((PersistentIdentifierGenerator)delegate).generatorKey()
                : null;
    }

}
