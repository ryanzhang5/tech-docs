package com.wm.configmgmt.client.jmx;

import com.wm.corelib.jmxadmin.WmtMBean;

import javax.management.DynamicMBean;
import java.io.IOException;


/**
 * Config Management Bean which retrieves all the required properties
 *
 * @author ncherukuri
 * @version $Revision: 1.2 $
 * @since 1/2010
 */

public interface ConfigMgmtMBean extends WmtMBean, DynamicMBean{

    //@Description("Get All Properties")
    //public String getProperties();

    //@Description("Set Property Value")
    //public void modifyProperty(@PName("Property Name") String propertyName, @PName("Property Value")String propertyValue);



    public void load() throws IOException;
    public void save() throws IOException;



}
