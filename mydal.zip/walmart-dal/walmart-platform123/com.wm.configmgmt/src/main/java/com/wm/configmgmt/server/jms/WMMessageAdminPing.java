/*
 * Copyright 2010 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.jms;

import com.wm.weblib.jms.WMMessageAdmin;
import com.wm.weblib.jms.WMMessageException;
import com.wm.weblib.jms.WMMessageType;

import java.util.HashMap;

/**
 * Copied over from DAL
 *
 * @author mkishore
 * @since 1.0
 */
public class WMMessageAdminPing extends WMMessageAdmin {

    private static final String RANDOMID = "randomId";

    /**
     * Since ping is used for checking queue status,
     * no target is needed
     */
    public WMMessageAdminPing() throws WMMessageException {
        super(WMMessageType.MSG_TYPE_PING, (String) null);
    }

    public WMMessageAdminPing(HashMap valueMap) throws WMMessageException {
        super(WMMessageType.MSG_TYPE_PING, (String) null);
        setValue(RANDOMID, valueMap.get(RANDOMID));
    }

    public String getRandomId() {
        return getValue(RANDOMID);
    }

}
