/*
 * Copyright 2010 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.service;

/**
 * DuplicateException
 *
 * @author mkishore
 * @since 1.0
 */
public class DuplicateException extends Exception {
    private String property;

    public DuplicateException() {
        this("name");
    }

    public DuplicateException(String property) {
        this.property = property;
    }

    public String getProperty() {
        return property;
    }
}
