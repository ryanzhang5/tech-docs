/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.configmgmt.server.action;

import com.wm.configmgmt.server.dataobject.Domain;

/**
 * AbstractDomainAction
 *
 * @author mkishore
 * @since 1.0
 */
public abstract class AbstractDomainAction extends AbstractUserAction implements IDomainAware {
    protected Domain domain;
    protected String CCReference;

    public Domain getDomain() {
        return domain;
    }

    public void setDomain(Domain domain) {
        this.domain = domain;
    }

    public String getCCReference() {
        return CCReference;
    }

    public void setCCReference(String CCReference) {
        this.CCReference = CCReference;
    }
}
