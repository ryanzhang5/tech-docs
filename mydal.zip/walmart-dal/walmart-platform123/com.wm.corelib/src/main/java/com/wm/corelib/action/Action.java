
package com.wm.corelib.action;

import com.wm.corelib.core.IState;
import com.wm.corelib.dbc.Assert;

/**
  This is a reference implementation of IAction interface.
  It can be used for testing and debugging of classes in 
  com.wm.corelib.action package and its clients.
**/
public class Action implements IAtomicAction
{
  public Action()
  {
  }

  /**
    Construct Action object.
    @param action name; cannot be null
  **/
  public Action( String name )
  {
    setName( name );
  }

  public String getName() { return _name; }
  public void setName( String v ) 
  { 
    Assert.pre( v != null );
    _name = v; 
  }




  /**
    Execute action.
    @param state state object; cannot be null.
    @return true if executed successfully.
  **/
  public boolean   execute    ( IState state ) 
  { 
    Assert.pre( state != null );
    return true; 
  }

  /**
    Undo results of the call to execute method.
    This method must restore IState object to its pre-execute state.
    @param state state object; cannot be null.
  **/
  public void rollback( IState state ) 
  {
    Assert.pre( state != null );
  }

  /**
    Print this object to a String.
    Use for debugging only!
    @return String object; never returns null.
  **/
  public String toString()
  {
    return _name;
  }

  private String _name = null;
}
