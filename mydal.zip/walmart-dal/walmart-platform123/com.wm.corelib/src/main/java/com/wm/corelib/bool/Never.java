
package com.wm.corelib.bool;

import com.wm.corelib.dbc.Assert;
import com.wm.corelib.core.IState;

public class Never extends Predicate
{
  public Never()
  {
    super();
  }
  public boolean eval( IState state )
  {
    return false;
  }

}
