package com.wm.corelib.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import static java.lang.annotation.ElementType.PARAMETER;

/**
 * Parameter Name annotation
 *
 * Can be used to name a parameter
 *
 * See http://java.sun.com/j2se/1.5.0/docs/guide/language/annotations.html for more info
 *
 * @author idralyuk
 * @version $Id: PName.java,v 1.2 2005/11/05 02:08:05 idralyuk Exp $
 */

@Retention(RetentionPolicy.RUNTIME)
@Target({PARAMETER})
public @interface PName {
    String value();
}