
package com.wm.corelib.bool;

import java.util.ArrayList;
import com.wm.corelib.dbc.Assert;
import com.wm.corelib.util.StringUtil;

/**
  This class is a utility data structure to maintain ordered list of IPredicate 
  objects.
  @see com.wm.corelib.workflow.IPredicate
**/
public class PredicateList 
{
  /**
    Search this list for the specified IPredicate.
    @param name name of the wanted IPredicate; cannot be null.
    @return IPredicate if found, NULL otherwise.
  **/
  public IPredicate findByName( String name )
  {
    for ( int i = 0; i < getSize(); i++ )
    {
      IPredicate t = getPredicate( i );
      if ( t.getName().equals( name ) )
        return t;
    }
    return null;
  }

  /**
    Get size of this PredicateList.
    @return number of IPredicate's in this PredicateList.
  **/
  public int getSize()
  {
    return _list.size();
  }

  /**
    Get IPredicate stored at the index i in this PredicateList.
    @param i index; index must satisfy the following condition: 0 &leq; i &le; getSize().
    @return IPredicate stored at the index i in this PredicateList.
  **/
  public IPredicate getPredicate( int i )
  {
    Assert.pre( i >= 0 );
    Assert.pre( i < getSize() );
    return (IPredicate)_list.get( i );
  }

  /**
    Get the first IPredicate in this PredicateList.
    @return null if this PredicateList is empty; returns getPredicate( 0 ) otherwise.
  **/
  public IPredicate getFirstPredicate()
  {
    if ( getSize() == 0 ) return null;
    return getPredicate( 0 );
  }

  /**
    Get the last IPredicate in this PredicateList.
    @return null if this PredicateList is empty; returns getPredicate( getSize() - 1 ) otherwise.
  **/
  public IPredicate getLastPredicate()
  {
    if ( getSize() == 0 ) return null;
    return getPredicate( getSize() - 1 );
  }

  /**
    Add IPredicate t to this PredicateList.
    @param t an IPredicate to add to this PredicateList; cannot be null.
  **/
  public void addPredicate( IPredicate t )
  {
    Assert.pre( t != null );
    _list.add( t );
  }

  /**
    Prints this PredicateList to a String.
    Note: use only for debugging.
    @return a string representation of this PredicateList; never returns null.
  **/
  public String toString()
  {
    return StringUtil.toString( _list );
  }

  /**
    the repository for all IPredicate's in this PredicateList.
  **/
  private ArrayList _list    = new ArrayList();
}
