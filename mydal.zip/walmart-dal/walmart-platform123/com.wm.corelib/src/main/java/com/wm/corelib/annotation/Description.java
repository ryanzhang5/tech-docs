package com.wm.corelib.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.ElementType.TYPE;

/**
 * Description annotation
 *
 * Can be used to provide a description of a constructor, method, parameter or type
 *
 * See http://java.sun.com/j2se/1.5.0/docs/guide/language/annotations.html for more info
 *
 * @author idralyuk
 * @version $Id: Description.java,v 1.2 2005/11/05 02:08:05 idralyuk Exp $
 */

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({CONSTRUCTOR, METHOD, PARAMETER, TYPE})
public @interface Description {
    String value();
}