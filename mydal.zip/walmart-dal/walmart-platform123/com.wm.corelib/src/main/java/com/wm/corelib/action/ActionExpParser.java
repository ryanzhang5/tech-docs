
package com.wm.corelib.action;

import java.util.StringTokenizer;
import java.util.ArrayList;
import java.text.ParseException;
import com.wm.corelib.util.StringUtil;
import com.wm.corelib.dbc.Assert;

public class ActionExpParser implements IActionFactory
{
  ////////////////////////////////////////////////////////////////////
  // public object interface
  ////////////////////////////////////////////////////////////////////
  /**
     returns IAction created by parsing s.
     getIActionInstance( String actionName ) is called every time actionName is encountered
     action_exp := actionName 
                   SEQ( action_list )
                   TNX( action_list )
     action_list := action_exp
                    action_exp, action_list
    
     SEQ( isOneDone TNX( canEnterTwo canEnterThree ) )
  **/
  public IAction parse( String s ) throws ParseException
  {
    _allTokens = getTokens( s );
    _currToken = 0;
    if ( !hasMoreTokens() )
      return null;
    return parse();
  }

  public IActionFactory getIActionFactory()
  {
    if ( _boolFactory == null )
    {
      _boolFactory = this;
    }
    return _boolFactory;
  }

  public ActionExpParser( IActionFactory bf )
  {
    Assert.pre( bf != null );
    _boolFactory = bf;
  }

  public ActionExpParser()
  {
  }

  public IAtomicAction makeIActionInstance( String boolName )
  {
    return new Action( boolName );
  }

  ////////////////////////////////////////////////////////////////////
  // private class interface
  ////////////////////////////////////////////////////////////////////
  private static final String SEQ          = "SEQ";
  private static final String TNX          = "TNX";
  private static final String OPEN_PARENT  = "(";
  private static final String CLOSE_PARENT = ")";
  private static final String COMMA        = ",";

  ////////////////////////////////////////////////////////////////////
  // private object interface
  ////////////////////////////////////////////////////////////////////
  private IAction parse() throws ParseException
  {
    IAction rv = null;
    String currToken = getCurrToken();
    if ( SEQ.equals( currToken ) )
    {
      return parseSeq();
    }
    if ( TNX.equals( currToken ) )
    {
      return parseTnx();
    }
    return parseAction();
  }

  private boolean parseToken( String token ) throws ParseException
  {
    Assert.pre( token != null );
    Assert.pre( token.length() > 0 );
    if ( token.equals( getCurrToken() ) )
    {
      nextToken();
      return true;
    }
    else
    {
      String allParsed = _parsedTokens.toString();
      String msg       = "Syntax Error: " + token + " is expected at " + allParsed.length() + " in " + allParsed;
      throw new ParseException( msg, allParsed.length() );
    }
  }
  private IAction parseAction() throws ParseException
  {
    String currToken = getCurrToken();
    if ( ! isValidOp( currToken ) )
    {
      String allParsed = _parsedTokens.toString();
      throw new ParseException( "Invalid Operator Name " + currToken, allParsed.length() );
    }
    nextToken();
    return getIActionFactory().makeIActionInstance( currToken );
  }
  private boolean isValidOp( String op )
  {
    return !op.equals( OPEN_PARENT ) 
           && !op.equals( CLOSE_PARENT ) 
           && !op.equals( COMMA ) ;

  }

  private IAction[] parseActionList() throws ParseException
  {
    ArrayList actions = new ArrayList();
    while ( true )
    {
      IAction a = parse();
      actions.add( a );
      if ( getCurrToken().equals( COMMA ) )
        parseToken( COMMA );
      else
        break;
    }
    IAction rv[] = new IAction[actions.size()];
    actions.toArray( rv );
    return rv;
  }

  private IAction parseSeq() throws ParseException
  {
    parseToken( SEQ );
    parseToken( OPEN_PARENT );
    IAction actions[] = parseActionList();
    parseToken( CLOSE_PARENT );
    return new Sequence( actions );
  }

  private IAction parseTnx() throws ParseException
  {
    parseToken( TNX );
    parseToken( OPEN_PARENT );
    IAction actions[] = parseActionList();
    parseToken( CLOSE_PARENT );
    return new Transaction( actions );
  }

  private String[] getTokens( String s )
  {
    ArrayList al   = new ArrayList();
    try
    {
      s = StringUtil.stripWhitespace( s ); 
      StringTokenizer st = new StringTokenizer( s, "(),", true );
      while ( st.hasMoreTokens() )
      {
        String t = st.nextToken();
        al.add( t );
      }
    }
    catch ( Exception e )
    {
    }
    String rv[] = new String[al.size()];
    al.toArray( rv );
    Assert.post( rv != null );
    return rv;
  }

  private String getCurrToken()
  {
    if ( !hasMoreTokens() )
      return StringUtil.BLANK_STRING;
    return _allTokens[_currToken];
  }

  private void nextToken()
  {
    _parsedTokens.append( getCurrToken() );
    _currToken++;
  }

  private boolean hasMoreTokens()
  {
    return _currToken < _allTokens.length;
  }

  private String _allTokens[] = null;
  private int    _currToken = 0;
  private StringBuffer _parsedTokens = new StringBuffer();
  private IActionFactory _boolFactory  = null;

  ////////////////////////////////////////////////////////////////////
  // debug
  ////////////////////////////////////////////////////////////////////
  public static void main( String args[] )
  {
      try
      {
        ActionExpParser exp = new ActionExpParser();
        //IAction b = exp.parse( "zero" );
        IAction a = exp.parse( "a1" );
        System.out.println( a );

        a = exp.parse( "SEQ( a1, a2, a3 )" );
        System.out.println( a );

        a = exp.parse( "TNX( a1, a2, a3 )" );
        System.out.println( a );

        a = exp.parse( "TNX( SEQ( s1, s2 ), t2, t3 )" );
        System.out.println( a );
      }
      catch ( ParseException e )
      {
        System.out.println( e );
      }
  }

}
