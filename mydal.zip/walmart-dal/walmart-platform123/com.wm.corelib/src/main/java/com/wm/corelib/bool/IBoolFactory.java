
package com.wm.corelib.bool;

import java.text.ParseException;

public interface IBoolFactory
{
  public IPredicate makeIBoolInstance( String boolName ) throws ParseException;
}
