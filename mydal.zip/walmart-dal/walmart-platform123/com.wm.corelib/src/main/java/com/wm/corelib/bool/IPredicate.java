
package com.wm.corelib.bool;

import com.wm.corelib.core.IState;
import com.wm.corelib.bool.IBool;

/**
  This interface defines atomic boolean operands.
  Each operand has a name which uniquely identifies this operand.
  setName( String ) method must be called on each new instance
  of IPredicate right after it has been constructed.
**/
public interface IPredicate extends IBool
{
  /**
    Get this test's name which must uniquely identify operand.
    @return this test's name; never returns null.
  **/
  public String  getName();

  /**
    Set this test's name.
    This method must be called on ever instance of IPredicate right after it's constructed.
    @param v string which uniquely identifies this operand; cannot be NULL.
  **/
  public void setName( String v );
}
