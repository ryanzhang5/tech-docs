
package com.wm.corelib.action;

import com.wm.corelib.core.IState;
import com.wm.corelib.dbc.Assert;

/**
  Aggregate Action Interface
**/
public interface IAggregateAction extends IAction
{
  /**
    Get list of actions contained in this aggregate.
    @return array of contained actions; never returns null.
  **/
  public IAction[] getActions();
}
