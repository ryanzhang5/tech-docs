/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.config;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * HierarchicalLoader - loads (and merges) the properties from the classpath.
 * e.g.
 * it checks the pathKey, which is set to "QA3".
 * it looks for a match in the pathMap and finds that it points to "QA"
 * it looks at the basePath (say "env") and fileName (say "app.conf")
 * it then loads up the properties from the classpath in the following order:
 * - env/QA/app.conf
 * - env/QA/QA3/app.conf 
 *
 * @author mkishore
 * @since 2.5.2
 */
public class HierarchicalLoader implements PropertiesLoader {
    private static Logger logger = Logger.getLogger(HierarchicalLoader.class.getName());

    private String pathKey;
    private Map<String, String> pathMap = new HashMap<String, String>();
    private String basePath = "";
    private String fileName = "app.conf";

    /**
     * Returns the name that acts as a lookup-key against the pathMap
     *
     * @return the name that acts as a lookup-key against the pathMap
     */
    public String getPathKey() {
        return pathKey;
    }

    /**
     * Sets the name that acts as a lookup-key against the pathMap
     *
     * @param pathKey - the name that acts as a lookup-key against the pathMap
     */
    public void setPathKey(String pathKey) {
        this.pathKey = pathKey;
    }

    /**
     * Returns the mapping from pathName to a hierarchical path
     *
     * @return the mapping from pathName to a hierarchical path
     */
    public Map<String, String> getPathMap() {
        return pathMap;
    }

    /**
     * Sets the mapping from pathName to a hierarchical path
     *
     * @param pathMap - the mapping from pathName to a hierarchical path
     */
    public void setPathMap(Map<String, String> pathMap) {
        this.pathMap = pathMap;
    }

    /**
     * Returns the base-path used as a prefix to the values in the path-map
     *
     * @return the base-path used as a prefix to the values in the path-map
     */
    public String getBasePath() {
        return basePath;
    }

    /**
     * Sets the base-path used as a prefix to the values in the path-map
     *
     * @param basePath - the base-path used as a prefix to the values in the path-map
     */
    public void setBasePath(String basePath) {
        if (basePath.startsWith("/")) basePath = basePath.substring(1);
        if (basePath.endsWith("/")) basePath = basePath.substring(0, basePath.length()-1);
        this.basePath = basePath;
    }

    /**
     * Returns the name of the properties file - which will be present under each level of
     * the configuration hieararchy
     *
     * @return the name of the properties file
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Sets the name of the properties file - which will be present under each level of
     * the configuration hieararchy
     *
     * @param fileName - name of the properties file
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * Loads the properties from a hierarchical properties store
     *
     * @return a properly overlaid properties instance
     */
    public Properties load() {
        Properties props = new Properties();
        if (pathKey == null) {
            logger.severe("Error - the pathKey property has not been initialized");
            return props;
        }
        String path = findPath(pathKey);
        if (path == null) {
            logger.warning("Error getting a config hierarchy based on the pathKey: " + pathKey);
            // default to the input pathName as-is
            path = pathKey;
        } else {
            // append the pathKey - allows for more generic rules e.g. QA[0-9]+ -> QA
            path += "/" + pathKey;
        }

        boolean loaded = false;
        ClassLoader cl = Thread.currentThread().getContextClassLoader();
        String prefix = basePath;
        String[] segments = path.split("/");
        for (String segment : segments) {
            // skip empty segments
            if (segment == null || "".equals(segment)) continue;
            // avoid a leading slash (e.g. is basePath == "")
            prefix  = (prefix.equals("") ? "" : prefix + "/") + segment;
            String file = prefix + "/" + fileName;
            try {
                InputStream is = cl.getResourceAsStream(file);
                if (is != null) {
                    props.load(is);
                    loaded = true;
                    logger.info("Successfully loaded properties from: " + file);
                }
            } catch (Exception e) {
                logger.log(Level.SEVERE, "Error loading properties from: " + file, e);
            }
        }
        if (loaded) {
            if (logger.isLoggable(Level.FINE)) {
                logger.fine("Properties loaded: " + props);
            }
        } else {
            logger.severe("Could not load properties from any segment of the path: " + path);
        }
        return props;
    }

    private String findPath(String env) {
        for (Map.Entry<String, String> entry : pathMap.entrySet()) {
            if (env.matches(entry.getKey())) {
                return entry.getValue();
            }
        }
        return null;
    }

}
