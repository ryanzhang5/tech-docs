
package com.wm.corelib.action;

import com.wm.corelib.core.IState;

/**
  Action interface.
**/
public interface IAction
{
  /**
    Execute action.
    An aggregate action will in turn execute all contained actions.
    @param state state object; cannot be null.
    @return true if executed successfully.
  **/
  public boolean   execute    ( IState state );

  /**
    Undo results of the call to execute method.
    This method must restore IState object to its pre-execute state.
    @param state state object; cannot be null.
  **/
  public void      rollback   ( IState state );

}
