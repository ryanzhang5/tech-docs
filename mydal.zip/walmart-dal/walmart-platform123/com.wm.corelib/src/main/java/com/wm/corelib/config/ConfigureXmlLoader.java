/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.config;

import com.wm.corelib.io.Resource;
import com.wm.corelib.config.internal.ConfigureXmlParser;
import com.wm.corelib.config.internal.ConfigureXmlProcessor;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * ConfigureXmlLoader - loads the properties from a configure.xml file
 *
 * @author mkishore
 * @since 2.5.2
 */
public class ConfigureXmlLoader implements PropertiesLoader {
    private static Logger logger = Logger.getLogger(ConfigureXmlLoader.class.getName());
    
    private Resource file;
    private Properties overrides;

    public Resource getFile() {
        return file;
    }

    public void setFile(Resource file) {
        this.file = file;
    }

    public Properties getOverrides() {
        return overrides;
    }

    public void setOverrides(Properties overrides) {
        this.overrides = overrides;
    }

    public Properties load() {
        ConfigureXmlProcessor processor = new ConfigureXmlProcessor();
        ConfigureXmlParser parser = new ConfigureXmlParser();
        parser.setInputStream(file.getInputStream());
        processor.setConfigure(parser.parse());
        processor.setOverrides(overrides);
        Properties props = processor.process();
        if (logger.isLoggable(Level.FINE)) {
            logger.fine("Properties loaded: " + props);
        }
        return props;
    }
}
