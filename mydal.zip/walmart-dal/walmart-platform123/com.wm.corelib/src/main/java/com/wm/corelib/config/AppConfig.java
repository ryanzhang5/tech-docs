/*
 * Copyright 2011 Walmart.com. All rights reserved.
 */
package com.wm.corelib.config;

import java.util.Properties;
import java.util.Map;
import java.util.Set;
import java.util.Collection;
import java.util.logging.Logger;

/**
 * AppConfig - a drop-in replacement for System.getProperty() calls. The application will
 * need to suitably initialize the underlying properties for this class.
 *
 * The class also implements a Map interface - making it easy to consume this from scripting
 * and/or declarative mediums. 
 *
 * @author mkishore
 * @since 2.5.2
 */
public class AppConfig implements Map<String, String> {
    private static final Logger logger = Logger.getLogger(AppConfig.class.getName());
    
    // system property names
    public static final String PROP_HOSTNAME = "com.wm.hostname.real";
    public static final String PROP_ENVIRONMENT = "com.wm.app.environment";
    public static final String PROP_NAMING_PREFIX = "com.wm.app.naming.prefix";
    public static final String PROP_OVERRIDES_DIR = "com.wm.app.overrides.dir";
    public static final String PROP_CONFIG_URL = "com.wm.app.config.url";

    // singleton instance
    private static final AppConfig instance = new AppConfig();
    public static AppConfig getInstance() {
        return instance;
    }

    private String appName;
    private String appVersion;
    private String contextPath;
    private String derivedPath = "";
    // underlying config - default to System props
    private Properties properties = System.getProperties();

    /**
     * Returns the name of the application
     *
     * @return the name of the application
     */
    public String getAppName() {
        return appName;
    }

    /**
     * Sets the name of the application
     *
     * @param appName - the name of the application
     */
    public void setAppName(String appName) {
        this.appName = appName;
    }

    /**
     * Returns the version of the application
     *
     * @return the version of the application
     */
    public String getAppVersion() {
        return appVersion;
    }

    /**
     * Sets the version of the application
     *
     * @param appVersion - the version of the application
     */
    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    /**
     * Returns the context-path for the application
     *
     * @return the context-path for the application
     */
    public String getContextPath() {
        return contextPath;
    }

    /**
     * Sets the context-path for the application
     *
     * @param contextPath - the context-path for the application
     */
    public void setContextPath(String contextPath) {
        this.contextPath = contextPath;
        if (contextPath == null) {
            derivedPath = "";
        } else {
            String path = contextPath;
            while (path.startsWith("/")) path = path.substring(1);
            path = path.replaceAll("/", "#");
            derivedPath = path;
        }
    }

    /**
     * Returned the path as derived from the context-path - basically replaces the
     * "/" characters with "#". This can be used as the name of the folder used to store
     * the application specific overrides.
     *
     * @return the path as derived from the context-path
     */
    public String getDerivedPath() {
        return derivedPath;
    }

    // Methods to allow AppConfig to act as a drop-in replacement for System
    
    /**
     * Returns the underlying config
     *
     * @return - the underlying config
     */
    public Properties getProperties() {
        return properties;
    }

    /**
     * Sets the underlying config
     *
     * @param properties - the underlying config
     */
    public void setProperties(Properties properties) {
        this.properties = properties;
    }

    /**
     * Delegates to get(key) method
     *
     * @param key - configuration key
     * @return - configuration value
     */
    public String getProperty(String key) {
        return get(key);
    }

    /**
     * Delegates to get(key, defaultValue) method
     *
     * @param key - configuration key
     * @param defaultValue - the default value to return if the key does not have a matching value
     * @return - configuration value
     */
    public String getProperty(String key, String defaultValue) {
        return get(key, defaultValue);
    }

    /**
     * Delegates to put(key, value) method
     *
     * @param key - configuration key
     * @param value - configuration value
     * @return the previous value of the specified key in this property list, or
     *         <code>null</code> if it did not have one
     */
    public String setProperty(String key, String value) {
        return put(key, value);
    }

    // MAP implementation - just delegate to the underlying properties

    public String get(Object key) {
        return get((String) key, null);
    }

    /**
     * Returns the configuration value corresponding to the input key
     *
     * @param key - configuration key
     * @param defaultValue - the default value to return if the key does not have a matching value
     * @return - configuration value
     */
    public String get(String key, String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }

    public String put(String key, String value) {
        return (String) properties.setProperty(key, value);
    }

    public int size() {
        return properties.size();
    }

    public boolean isEmpty() {
        return properties.isEmpty();
    }

    public boolean containsKey(Object key) {
        return properties.containsKey(key);
    }

    public boolean containsValue(Object value) {
        return properties.containsValue(value);
    }

    public String remove(Object key) {
        return (String) properties.remove(key);
    }

    public void putAll(Map<? extends String, ? extends String> m) {
        properties.putAll(m);
    }

    public void clear() {
        properties.clear();
    }

    public Set<String> keySet() {
        return properties.stringPropertyNames();
    }

    public Collection values() {
        return properties.values();
    }

    public Set entrySet() {
        return properties.entrySet();
    }

    // Helper methods to access system property derived values

    /**
     * Returns the "real" hostname of the server running this app
     *
     * @return the "real" hostname of the server running this app
     */
    public static String getHostname() {
        return System.getProperty(PROP_HOSTNAME);
    }

    /**
     * Returns the environment this application (or its container) is currently
     * configured for.
     *
     * @return the environment this application is currently configured for
     */
    public static String getEnvironment() {
        String ret = System.getProperty(PROP_ENVIRONMENT);
        if (ret == null) {
            ret = System.getProperty("com.wm.ApplicationEnvironment");
            if (ret != null) {
                logger.severe("Please update your configuration to use the new '"+PROP_ENVIRONMENT+"' variable");
            }
        }
        return ret;
    }

    /**
     * Returns the prefix to be used for creating globally unique names e.g. JMS subecriber names
     * Defaults to truncated hostname - for backward compatibility.
     *
     * @return the prefix to be used for creating globally unique names
     */
    public static String getNamingPrefix() {
        String ret = System.getProperty(PROP_NAMING_PREFIX);
        if (ret == null) {
            ret = getHostname();
            if (ret != null) {
                logger.severe("Please update your configuration to use the new '"+PROP_NAMING_PREFIX+"' variable");
                int ndx = ret.indexOf('.');
                if (ndx > 0) {
                    ret = ret.substring(0, ndx);
                }
            }
        }
        return ret;
    }

    /**
     * Returns the file-system path to the directory containing the configuration overrides
     *
     * @return the file-system path to the directory containing the configuration overrides
     */
    public static String getOverridesDir() {
        return System.getProperty(PROP_OVERRIDES_DIR);
    }

    /**
     * Returns the URL to the config-mgmt server
     *
     * @return the URL to the config-mgmt server
     */
    public static String getConfigURL() {
        return System.getProperty(PROP_CONFIG_URL);
    }
}
