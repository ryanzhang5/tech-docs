
package com.wm.corelib.bool;
import com.wm.corelib.core.IState;

public class Xor implements IBool
{
  public boolean eval( IState state )
  {
    boolean v1 = _op1.eval( state );
    boolean v2 = _op2.eval( state );
    return (v1 || v2) // one is true
           && 
           (!(v1 && v2)); // but not both
  }

  public Xor( IBool op1, IBool op2 )
  {
    _op1 = op1;
    _op2 = op2;
  }

  public String toString()
  {
    return "XOR( " + _op1 + ", " + _op2 + " )";
  }

  private IBool _op1 = null;
  private IBool _op2 = null;
}
