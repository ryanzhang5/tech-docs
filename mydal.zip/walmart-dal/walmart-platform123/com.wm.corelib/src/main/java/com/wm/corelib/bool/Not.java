
package com.wm.corelib.bool;

import com.wm.corelib.core.IState;

public class Not implements IBool
{
  public boolean eval( IState state )
  {
    return !_op.eval( state );
  }

  public Not( IBool op )
  {
    _op = op;
  }

  public String toString()
  {
    return "NOT( " + _op + " )";
  }

  private IBool _op = null;
}
