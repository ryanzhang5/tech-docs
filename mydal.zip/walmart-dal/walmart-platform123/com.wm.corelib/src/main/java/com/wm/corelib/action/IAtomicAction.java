
package com.wm.corelib.action;

/**
  Atomic Action interface.
**/
public interface IAtomicAction extends IAction
{
  /**
    Get name of this action.
    @return String; never returns null
  **/
  public String getName();

  /**
    Set name of this action.
    This method must be called on all newly-constructed IAtomicAction objects.
    @param v action name, cannot be null.
  **/
  public void setName( String v );
}
