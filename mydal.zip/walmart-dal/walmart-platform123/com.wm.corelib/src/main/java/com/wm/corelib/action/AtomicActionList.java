
package com.wm.corelib.action;

import java.util.ArrayList;
import com.wm.corelib.dbc.Assert;
import com.wm.corelib.util.StringUtil;
import com.wm.corelib.core.IState;

/**
  This class is a utility data structure to maintain ordered list of IAtomicAction 
  objects.
  @see com.wm.corelib.workflow.IAtomicAction
**/
public class AtomicActionList 
{
  /**
    Search this list for the specified IAtomicAction.
    @param name name of the wanted IAtomicAction; cannot be null.
    @return IAtomicAction if found, NULL otherwise.
  **/
  public IAtomicAction findByName( String name )
  {
    for ( int i = 0; i < getSize(); i++ )
    {
      IAtomicAction t = getAction( i );
      if ( t.getName().equals( name ) )
        return t;
    }
    return null;
  }

  /**
    Get size of this ActionList.
    @return number of IAtomicAction's in this ActionList.
  **/
  public int getSize()
  {
    return _list.size();
  }

  /**
    Get IAtomicAction stored at the index i in this ActionList.
    @param i index; index must satisfy the following condition: 0 &leq; i &le; getSize().
    @return IAtomicAction stored at the index i in this ActionList.
  **/
  public IAtomicAction getAction( int i )
  {
    Assert.pre( i >= 0 );
    Assert.pre( i < getSize() );
    return (IAtomicAction)_list.get( i );
  }

  /**
    Get the first IAtomicAction in this ActionList.
    @return null if this ActionList is empty; returns getAction( 0 ) otherwise.
  **/
  public IAtomicAction getFirstAction()
  {
    if ( getSize() == 0 ) return null;
    return getAction( 0 );
  }

  /**
    Get the last IAtomicAction in this ActionList.
    @return null if this ActionList is empty; returns getAction( getSize() - 1 ) otherwise.
  **/
  public IAtomicAction getLastAction()
  {
    if ( getSize() == 0 ) return null;
    return getAction( getSize() - 1 );
  }

  /**
    Add IAtomicAction t to this ActionList.
    @param t an IAtomicAction to add to this ActionList; cannot be null.
  **/
  public void addAction( IAtomicAction t )
  {
    Assert.pre( t != null );
    _list.add( t );
  }

  /**
    Prints this ActionList to a String.
    Note: use only for debugging.
    @return a string representation of this ActionList; never returns null.
  **/
  public String toString()
  {
    return StringUtil.toString( _list );
  }

  /**
    the repository for all IAtomicAction's in this ActionList.
  **/
  private ArrayList _list    = new ArrayList();
}
