
package com.wm.corelib.action;

import java.text.ParseException;

/**
  Object factory for action objects.
**/
public interface IActionFactory
{
  /**
    Make an instance of IAction given actionName.
    @param actionName name of the action to be constructed; cannot be null.
    @return instance of IAction object; never returns null.
  **/
  public IAtomicAction makeIActionInstance( String actionName ) throws ParseException;
}
