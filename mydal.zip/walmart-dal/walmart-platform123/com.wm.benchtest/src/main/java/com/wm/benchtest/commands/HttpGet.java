
package com.wm.benchtest.commands;

import java.net.URL;
import java.io.InputStream;
import java.net.MalformedURLException;

public class HttpGet
  implements Runnable
{
  URL url;
  byte[] buffer = new byte[4096];

  public
  HttpGet(String url)
    throws MalformedURLException
  {
    this.url = new URL(url);
  }

  public void
  run()
  {
    try
    {
      InputStream is = url.openStream();
      while(is.read(buffer) > 0)
        ;
    }
    catch(Exception ex)
    {
      ex.printStackTrace();
    }
  }

  public String
  toString()
  {
    return String.valueOf(url);
  }
}
