
package com.wm.benchtest;

import java.text.DecimalFormat;

public class BenchCommand extends BenchResult
{
  Runnable command;
  long runtime;

  public
  BenchCommand(Runnable command, long runtime)
  {
    this(command.toString(), command, runtime);
  }

  public
  BenchCommand(String label, Runnable command, long runtime)
  {
    super(label);
    this.command = command;
    this.runtime = runtime;
  }
  
  public Runnable
  getCommand()
  {
    return command;
  }

  public double
  getTPS()
  {
    return ((double)count) / ((double)runtime / 1000.0);
  }

  public void
  dump()
  {
    super.dump();
    System.out.println("TPS: "+new DecimalFormat("##.####").format(getTPS()));
  }
}
