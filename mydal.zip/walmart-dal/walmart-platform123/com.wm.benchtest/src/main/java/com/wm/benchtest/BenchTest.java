package com.wm.benchtest;

import com.wm.benchtest.commands.HttpGet;

class BenchRunner extends Thread
{
  BenchCommand results;
  Runnable command;
  long recordStart;
  long recordEnd;

  public
  BenchRunner(String name, Runnable command, long recordStart, long recordEnd)
  {
    super(name);
    this.results = new BenchCommand(command, recordEnd-recordStart);
    this.command = command;
    this.recordStart = recordStart;
    this.recordEnd = recordEnd;
  }

  BenchCommand
  getResults()
  {
    return results;
  }

  public void
  run()
  {
    while(true)
    {
      long start = System.currentTimeMillis();
      command.run();
      long stop = System.currentTimeMillis();
      if (start > recordStart && start < recordEnd)
        results.add(stop-start);
      if (stop > recordEnd)
        break;
    }
  }
}

public class BenchTest
{
  Runnable command;
  long warmupTime;
  long runTime;
  BenchRunner[] runners;

  public 
  BenchTest(Runnable command, int threadCount)
  {
    this.command = command;
    this.runners = new BenchRunner[threadCount];
  }

  public BenchCommand
  execute(long warmupTime, long runTime)
  {
    long now = System.currentTimeMillis();
    long start = now + warmupTime;
    long stop = start+runTime;
    BenchCommand results = new BenchCommand(command, runTime);

    for (int ii = 0 ; ii < runners.length ; ii++)
      runners[ii] = new BenchRunner(String.valueOf(ii), command, start, stop);

    for (int i = 0 ; i < runners.length ; i++)
      runners[i].start();

    for (int i = 0 ; i < runners.length ; i++)
    {
      try
      {
        runners[i].join();
      }
      catch(InterruptedException ex)
      {
        ex.printStackTrace();
      }
      results.add(runners[i].getResults());
    }

    return results;
  }

  public static void
  main(String[] args)
    throws Exception
  {
    if (args.length != 2)
      throw new IllegalArgumentException("Usage: "+BenchTest.class.getName()+" threads url");
      
    //BenchTest bt = new BenchTest(new Sleeper(200), 5);
    BenchTest bt = new BenchTest(new HttpGet(args[1]), Integer.parseInt(args[0]));
    BenchCommand rc = bt.execute(30*1000, 30*1000);
    rc.dump();
  }
}
