package com.wm.benchtest;

class Time
{
  long time;

  public
  Time()
  {
    this.time = System.currentTimeMillis();
  }

  public
  Time(long time)
  {
    this.time = time;
  }

  private static double
  reduce(long value)
  {
    if (value < 1000)
      return value;
    else if (value < 60.0 * 1000.0)
      return value / (1000.0);
    else if (value < 60.0 * 60.0 * 1000.0)
      return value / (60.0 * 1000.0);
    else if (value < 24.0 * 60.0 * 60.0 * 1000.0)
      return value / (60.0 * 60.0 * 1000.0);
    else
      return value / (24.0 * 60.0 * 60.0 * 1000.0);
  }

  private static String
  units(long value)
  {
    if (value < 1000.0)
      return "ms";
    else if (value < 60.0 * 1000.0)
      return "s";
    else if (value < 60.0 * 60.0 * 1000.0)
      return "m";
    else if (value < 24.0 * 60.0 * 60.0 * 1000.0)
      return "h";
    else
      return "d";
  }

  public String
  toString()
  {
    return String.valueOf(reduce(time))+units(time);
  }
}
