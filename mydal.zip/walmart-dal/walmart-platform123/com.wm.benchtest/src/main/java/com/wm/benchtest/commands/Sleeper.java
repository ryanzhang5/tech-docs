
package com.wm.benchtest.commands;

public class Sleeper
  implements Runnable
{
  long mills;

  public
  Sleeper(long mills)
  {
    this.mills = mills;
  }

  public void
  run()
  {
    try
    {
      Thread.currentThread().sleep(mills);
    }
    catch(InterruptedException ex)
    {
      ex.printStackTrace(System.err);
    }
  }
}
