package com.wm.benchtest;

import java.text.DecimalFormat;

public class BenchResult
{
  String label;
  long min = Long.MAX_VALUE;
  long max = 0;
  long sum = 0;
  double sum2 = 0;
  long count = 0;

  public BenchResult(String label)
  {
    this.label = label;
  }

  public void
  add(long time)
  {
    min = Math.min(min, time);
    max = Math.max(max, time);
    sum += time;
    sum2 += ((double)time) * ((double)time);
    count++;
  }

  public void
  add(BenchResult result)
  {
    min = Math.min(this.min, result.min);
    max = Math.max(this.max, result.max);
    sum += result.sum;
    sum2 += result.sum2;
    count += result.count;
  }

  public Time
  getAverageTime()
  {
    if (count == 0)
	throw new IllegalStateException("Test Did Run {count==0}");
    return new Time(sum/count);
  }

  public Time
  getMinimumTime()
  {
    return new Time(min);
  }

  public Time
  getMaximumTime()
  {
    return new Time(max);
  }

  public Time
  getStandardDeviation()
  {
    return new Time((long)(Math.sqrt((sum2 - ((double)sum)*((double)sum)/count) / count)));
  }

  public long
  getCount()
  {
    return count;
  }

  public void
  dump()
  {
    System.out.println("Name: "+label);
    System.out.println("Average Time: "+getAverageTime());
    System.out.println("Minimum Time: "+getMinimumTime());
    System.out.println("Maximum Time: "+getMaximumTime());
    System.out.println("Std Dev: "+getStandardDeviation());
    System.out.println("Count: "+getCount());
  }
}
