
package com.wm.benchtest.commands;

public class Spinner
  implements Runnable
{
  long mills;

  Spinner(long mills)
  {
    this.mills = mills;
  }

  public void
  run()
  {
    long stop = System.currentTimeMillis() + mills;
    while(System.currentTimeMillis() < stop)
      ;
  }
}
