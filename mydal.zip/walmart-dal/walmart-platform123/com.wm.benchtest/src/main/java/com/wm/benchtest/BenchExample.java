package com.wm.benchtest;

import com.wm.benchtest.commands.HttpGet;

public class BenchExample
{
  public static void main(String args[])
    throws Exception
  {
    if (args.length != 1)
      throw new IllegalArgumentException("Usage: "+BenchExample.class.getName()+" url");

    BenchResult results = new BenchResult("Test Get");
    Runnable test = new HttpGet(args[0]);

    // warm up
    for (int ii = 0 ; ii < 10 ; ii++)
      test.run();

    // test up
    for (int ii = 0 ; ii < 10 ; ii++)
    {
      long start = System.currentTimeMillis();
      test.run();
      long stop = System.currentTimeMillis();
      results.add(stop-start);
    }

    results.dump();
  }
}
