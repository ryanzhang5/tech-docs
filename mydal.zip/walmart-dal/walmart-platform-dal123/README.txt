
To checkout and run the DAL integration tests from the command line

0. It is assume that a suitable version of subversion, maven (3.0.3) and JDK are installed 

     http://subversion.apache.org/packages.html
     http://www.oracle.com/technetwork/java/javase/downloads/jdk-6u27-download-440405.html
     http://maven.apache.org/download.html

   or
   
     yum install subversion java-1.6.0-openjdk maven-3.0.3

1. Check out the example

   svn co svn://172.29.64.24/walmart-platform-dal/trunk walmart-platform-dal
   cd walmart-platform-dal

2. Compile, Deploy, Run Example

     mvn 

   Note: This exeuction does the following:
    - compiles and starts DAL
    - downloads JBoss 5.0.1
    - unpacks JBoss into target/cargo/...
    - starts JBoss
    - builds Integration Test Cases
    - Builds, Packages and Deploys a Testable Ear to JBoss
    - Executes Integration Tests using Arquillian
    - Generates TestNG Reports into target/failsafe-reports

   Note: To Run with JBoss 4.0.5:
     mvn '-P!jbossas-5.0.1,jbossas-4.0.5' clean verify

3. Inspect the Results:
 
   firefox com.wm.dal/target/failsafe-reports/index.html 
