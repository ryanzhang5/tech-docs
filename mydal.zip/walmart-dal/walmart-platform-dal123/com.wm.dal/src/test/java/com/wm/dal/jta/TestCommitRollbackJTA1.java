package com.wm.dal.jta;

import static org.testng.Assert.fail;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.testng.annotations.Test;

@Test(singleThreaded = true)
public class TestCommitRollbackJTA1 extends BaseTestCase 
{
    protected String 
    getTableName() 
    {
        return "itemtbl_testcommitrollback1";
    }

    @Test(groups = { "mysql", "oracle", "create" })
    public void 
    testCreate() 
      throws SQLException
    {
      String creaTablMySql = "CREATE TABLE " + getTableName() + "("
          + "var_string varchar(10) default NULL"
          + ") ENGINE=InnoDB DEFAULT CHARSET=utf8;";

      logger.info("begin to create itemtbl table.");
      pureTemplate1.dropTableIfExists(getTableName());
      pureTemplate1.getJdbcOperations().execute(creaTablMySql);
      logger.info("itemtbl table is created.");

      logger.info("begin to create itemtbl table.");
      pureTemplate2.dropTableIfExists(getTableName());
      pureTemplate2.getJdbcOperations().execute(
          "CREATE TABLE " + getTableName()
              + "(var_string VARCHAR2(10) default NULL)");
      logger.info("itemtbl table is created.");

      testQueryForCreateMysql();
      testQueryForCreateOracle();
    }

    @Test(dependsOnMethods = "testCreate", groups = { "mysql", "oracle", "insert" })
    public void
    testMetaData() 
      throws SQLException
    {
      Connection pcon1 = null; // Mysql Connection
      Connection pcon2 = null; // Oracle Connection
      Connection con1 = null; // Mysql Connection
      Connection con2 = null; // Oracle Connection
      
      ResultSet prs1 = null;
      ResultSet prs2 = null;
      
      ResultSet rs1 = null;
      ResultSet rs2 = null;
      
      ResultSet pkrs1 = null;
      ResultSet pkrs2 = null;
      
      ResultSet krs1 = null;
      ResultSet krs2 = null;
      
      boolean success = false;
      try {
        logger.info("begin to get itemtbl metadata.");
        pcon1 = pureDataSource1.getConnection();
        pcon2 = pureDataSource2.getConnection();
        
        con1 = DS1.getConnection();
        con2 = DS2.getConnection();

        prs1 = pcon1.getMetaData().getColumns(null, "test", getTableName(), "*");
        prs2 = pcon2.getMetaData().getColumns(null, "wmdev2", getTableName(), "*");
        
        rs1 = con1.getMetaData().getColumns(null, "test", getTableName(), "*");
        rs2 = con2.getMetaData().getColumns(null, "wmdev2", getTableName(), "*");
        
        compare(rs1, prs1);
        compare(rs2, prs2);
        
        pkrs1 = pcon1.getMetaData().getPrimaryKeys(null, "test", getTableName());
        pkrs2 = pcon2.getMetaData().getPrimaryKeys(null, "wmdev2", getTableName());
        
        krs1 = con1.getMetaData().getPrimaryKeys(null, "test", getTableName());
        krs2 = con2.getMetaData().getPrimaryKeys(null, "wmdev2", getTableName());
        
        compare(krs1, pkrs1);
        compare(krs2, pkrs2);
        
      } finally {
        close(success, prs1, prs2, rs1, rs2, pkrs1, pkrs2, krs1, krs2, pcon1, pcon2, con1, con2);
      }
    }
    
    //@Test(dependsOnMethods = "testMetaData", groups = { "mysql", "oracle", "insert" })
    public void 
    testMultipleMetaData()
      throws SQLException 
    {
        Connection con2 = null; // Oracle Connection

        ResultSet rs2 = null;
        
      
        boolean success = false;
        try {
          logger.info("begin to qury itemtbl metadata.");
          con2 = DS2.getConnection();

          ArrayList list = new ArrayList(3000);
          for (int ii = 0 ; ii < 3000 ; ii++) {
        	  System.out.println("HERE I AM: "+ii);
          rs2 = con2.getMetaData().getColumns(null, "wmdev2", getTableName(), "*");
          //list.add(rs2);
          rs2.close();
          }
          success = true;
        } finally {
          close(success, con2);
        }
    }
    
    @Test(dependsOnMethods = "testMetaData", groups = { "mysql", "oracle", "insert" })
    public void 
    testSuccessInsert()
      throws SQLException 
    {
      Connection con1 = null; // Mysql Connection
      Connection con2 = null; // Oracle Connection
      PreparedStatement pstm1 = null; // Mysql Statement
      PreparedStatement pstm2 = null; // Oracle Statement
      TransactionStatus status = txManager
          .getTransaction(new DefaultTransactionDefinition());

      boolean success = false;
      try {
        logger.info("begin to insert itemtbl data.");
        con1 = DS1.getConnection();
        con2 = DS2.getConnection();
        pstm1 = con1.prepareStatement("INSERT INTO " + getTableName()
            + " VALUES(?)");
        pstm2 = con2.prepareStatement("INSERT INTO " + getTableName()
            + " VALUES(?)");
        pstm1.setString(1, "HelloWorld");
        pstm2.setString(1, "HelloWorld");
        pstm1.executeUpdate();
        pstm2.executeUpdate();
        logger.info("itemtbl data are inserted.");
        testQueryForFailureInsertMysql();
        testQueryForFailureInsertOracle();
        success = true;
      } finally {
        finalize(success, status, pstm1, pstm2, con1, con2);
      }
      testQueryForSuccessInsertOracle();
      testQueryForSuccessInsertMysql();
    }

    @Test(dependsOnMethods = "testSuccessInsert", groups = { "mysql", "oracle", "insert" })
    public void 
    testNoOp() throws SQLException
    {
      Connection con1 = null; // Mysql Connection
      Connection con2 = null; // Oracle Connection
      TransactionStatus status = txManager.getTransaction(new DefaultTransactionDefinition());

      boolean success = false;
      try {
        logger.info("begin to delete itemtbl data.");
        con1 = DS1.getConnection();
        con2 = DS2.getConnection();
        success = true;
      } finally {
        finalize(success, status, con1, con2);
      }
    }
    
    //@Test(dependsOnMethods = "testNoOp", groups = { "mysql", "oracle", "insert" })
    public void 
    testSuspend() 
      throws SQLException 
    {
      Connection con1 = null; // Mysql Connection
      Connection con2 = null; // Oracle Connection
      ResultSet rs1 = null;
      ResultSet rs2 = null;
      DefaultTransactionDefinition td = new DefaultTransactionDefinition();
      td.setTimeout(60*60);
      TransactionStatus status = txManager.getTransaction(td);

      boolean success = false;
      try {
        logger.info("begin test Suspend");
        con1 = DS1.getConnection();
        con2 = DS2.getConnection();
        rs1 = con1.getMetaData().getColumns(null, "test", getTableName(), "*");
        rs2 = con2.getMetaData().getColumns(null, "wmdev2", getTableName(), "*");
        
        ResultSet nrs1 = null;
        ResultSet nrs2 = null;
        DefaultTransactionDefinition ntd = new DefaultTransactionDefinition();
        ntd.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
        TransactionStatus nstatus = txManager.getTransaction(ntd);
        
        boolean nsuccess = false;
        try {
          nrs1 = con1.getMetaData().getColumns(null, "test", getTableName(), "*");
          nrs2 = con2.getMetaData().getColumns(null, "wmdev2", getTableName(), "*");
          success = true;
        } finally {
          finalize(nsuccess, nstatus, nrs1, nrs2);
        }
        
        rs1 = con1.getMetaData().getColumns(null, "test", getTableName(), "*");
        rs2 = con2.getMetaData().getColumns(null, "wmdev2", getTableName(), "*");
        
        success = true;
      } finally {
        finalize(success, status, rs1, rs2, con1, con2);
      }      
    }
    
    @Test(dependsOnMethods = "testNoOp", groups = { "mysql", "oracle", "insert" })
    public void 
    testDelete() 
      throws SQLException 
    {
      Connection con1 = null; // Mysql Connection
      Connection con2 = null; // Oracle Connection
      Statement stmt1 = null; // Mysql Statement
      Statement stmt2 = null; // Oracle Statement
      TransactionStatus status = txManager
          .getTransaction(new DefaultTransactionDefinition());

      boolean success = false;
      try {
        logger.info("begin to delete itemtbl data.");
        con1 = DS1.getConnection();
        con2 = DS2.getConnection();
        stmt1 = con1.createStatement();
        stmt1.execute("DELETE FROM " + getTableName());
        stmt2 = con2.createStatement();
        stmt2.execute("DELETE FROM " + getTableName());
        logger.info("data of itemtbl table is deleted.");
        testQueryForSuccessInsertOracle();
        testQueryForSuccessInsertMysql();
        success = true;
      } finally {
        finalize(success, status, stmt1, stmt2, con1, con2);
      }

      testQueryForDeleteMysql();
      testQueryForDeleteOracle();
    }

    @Test(dependsOnMethods = "testDelete", groups = { "mysql", "oracle", "insert" })
    public void
    testFailureInsert()
      throws SQLException 
    {
      Connection con1 = null; // Mysql Connection
      Connection con2 = null; // Oracle Connection
      PreparedStatement pstm1 = null; // Mysql Statement
      PreparedStatement pstm2 = null; // Oracle Statement
      TransactionStatus status = txManager
          .getTransaction(new DefaultTransactionDefinition());

      boolean success = false;
      try {
        logger.info("begin to insert itemtbl data.");
        con1 = DS1.getConnection();
        con2 = DS2.getConnection();

        pstm2 = con2.prepareStatement("INSERT INTO " + getTableName()
            + " VALUES(?)");
        pstm2.setString(1, "HelloWorld");
        pstm2.executeUpdate();

        testQueryForFailureInsertMysql();
        testQueryForFailureInsertOracle();

        pstm1 = con1.prepareStatement("INSERT INTO " + getTableName()
            + " VALUES(?)");
        pstm1.setString(1, "HelloWorld!");
        pstm1.executeUpdate();

        txManager.commit(status);
        logger.info("itemtbl data are inserted.");
        success = true;
        fail();
      } catch (com.mysql.jdbc.MysqlDataTruncation e) {
        txManager.rollback(status);
        success = true;
      } finally {
        close(success, pstm1, pstm2, con1, con2);
      }
      testQueryForFailureInsertMysql();
      testQueryForFailureInsertOracle();
    }

    @Test(dependsOnMethods = "testFailureInsert", groups = { "mysql", "oracle", "drop" })

    public void
    testDrop() 
      throws SQLException 
    {
      try {
        logger.info("begin to drop itemtbl table.");
        pureTemplate1.dropTableIfExists(getTableName());
        logger.info("itemtbl table is dropped.");
      } finally {
        logger.info("begin to drop itemtbl table.");
        pureTemplate2.dropTableIfExists(getTableName());
        logger.info("itemtbl table is dropped.");
      }

      testQueryForDropMysql();
      testQueryForDropOracle();
    }
}
