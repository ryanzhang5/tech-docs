package com.wm.dal.jdbc.mysql;

import java.io.StringReader;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.wm.dal.jdbc.DALBlob;
import com.wm.dal.jdbc.DALClob;

/**
 * Copyright 2009 walmart.com. All rights reserved
 */

/**
 * @author Martin Ma
 * @since 2009-5-5
 * @version 1.0 Test JDBC Large Format on mysql with DALConnection
 */
//@Test(sequential=true)
public class TestDALLargeFormatMysqlLob extends BaseMysqlTest {

	@Test(groups = { "mysql", "create" })
	public void testCreate() {

		Connection con = null;
		Statement stmt = null;

		String dropTablSql = "DROP TABLE IF EXISTS itemtbl_dallargeformatlob;";
		String creaTablSql = "CREATE TABLE itemtbl_dallargeformatlob ("
				+ "var_longtext longtext," 
				+ "var_longblob longblob,"
				+ "var_charstrm longtext"
				+ ") ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		try {
			logger.info("begin to create itemtbl_dallargeformatlob table.");
			con = pureDataSource.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate(dropTablSql);
			stmt.executeUpdate(creaTablSql);
			logger.info("itemtbl_dallargeformatlob table is created.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForCreate();
	}

	@Test(dependsOnMethods = "testCreate", groups = { "mysql", "insert" })
	public void testInsert() {

		Connection con = null;
		PreparedStatement pstm = null;

		String insrSql = "INSERT INTO itemtbl_dallargeformatlob"
				+ " (var_longtext,var_longblob,var_charstrm) " 
				+ " VALUES (?,?,?)";

		try {
			logger.info("begin to insert itemtbl_dallargeformatlob data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(insrSql);

			Clob orclClob = new DALClob("Hello World");
			pstm.setClob(1, orclClob);

			Blob orclBlob = new DALBlob("Hello World".getBytes());
			pstm.setBlob(2, orclBlob);
			
			String sample = "Hello World";
			StringReader inpuRead = new StringReader(sample);
			pstm.setCharacterStream(3, inpuRead, sample.length());

			pstm.executeUpdate();
			con.commit();

			logger.info("itemtbl_dallargeformatlob data are inserted.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForInsert();
	}

	@Test(dependsOnMethods = "testInsert", groups = { "mysql", "update" })
	public void testUpdate() {

		Connection con = null;
		PreparedStatement pstm = null;

		String insrSql = "UPDATE itemtbl_dallargeformatlob "
				+ " SET var_longtext=?,var_longblob=?,var_charstrm=?";

		try {
			logger.info("begin to update itemtbl_dallargeformatlob data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(insrSql);

			Clob orclClob = new DALClob("Hello World");
			pstm.setClob(1, orclClob);

			Blob orclBlob = new DALBlob("Hello World".getBytes());
			pstm.setBlob(2, orclBlob);

			String sample = "Hello World";
			StringReader inpuRead = new StringReader(sample);
			pstm.setCharacterStream(3, inpuRead, sample.length());
			
			pstm.executeUpdate();
			con.commit();

			logger.info("itemtbl_dallargeformatlob data are updated.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForUpdate();
	}

	@Test(dependsOnMethods = "testUpdate", groups = { "mysql", "delete" })
	public void testDelete() {

		Connection con = null;
		Statement stmt = null;

		String dropTablSql = "DELETE FROM itemtbl_dallargeformatlob;";
		try {
			logger.info("begin to delete itemtbl_dallargeformatlob data.");
			con = dataSource.getConnection();
			stmt = con.createStatement();
			stmt.execute(dropTablSql);
			logger.info("data of itemtbl_dallargeformatlob table is deleted.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForDelete();
	}

	@Test(dependsOnMethods = "testDelete", groups = { "mysql", "drop" })
	public void testDrop() {

		Statement stmt = null;
		Connection con = null;
		String dropTablSql = "DROP TABLE itemtbl_dallargeformatlob;";
		try {
			logger.info("begin to drop itemtbl_dallargeformatlob table.");
			con = pureDataSource.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate(dropTablSql);
			logger.info("itemtbl_dallargeformatlob table is dropped.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForDrop();
	}

	public void testQueryForCreate() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = " select count(*) as table_num "
				+ " from information_schema.tables "
				+ " where table_name='itemtbl_dallargeformatlob' and table_schema='test'";

		try {
			logger.info("begin to retrieve user_table data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				// int num = rs.getInt("table_num");
				int num = rs.getInt(1);
				Assert.assertEquals(num, 1);
			}
			logger.info("user_table data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForInsert() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT "
				+ " var_longtext,var_longblob,var_charstrm "
				+ " FROM itemtbl_dallargeformatlob";

		try {
			logger.info("begin to retrieve itemtbl_dallargeformatlob data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			while (rs.next()) {

				Clob textval = rs.getClob(1);
				byte[] buff1 = new byte[(int)textval.length()];
				textval.getAsciiStream().read(buff1);
				String sourceClob = new String(buff1);
				Assert.assertEquals(sourceClob, "Hello World");

				Blob blobval = rs.getBlob(2);
				byte[] buff2 = new byte[(int)blobval.length()];
				blobval.getBinaryStream().read(buff2);
				String sourceBlob = new String(buff2);
				Assert.assertEquals(sourceBlob, "Hello World");
				
//				Reader read = rs.getCharacterStream(3);
//				char[] charBuff = new char[1024];
//				read.read(charBuff);
//				String chars = new String(charBuff);
//				Assert.assertEquals(chars, "Hello World");
//				Reader reader = rs.getCharacterStream(3);
//				StringBuilder strBuild = new StringBuilder();
//				int c;
//				while ((c=reader.read())>-1) {
//					strBuild.append(c);
//				}
//				String chars = strBuild.toString();
//				Assert.assertEquals(chars, "Hello World");
		
//				String charStr = rs.getString(3);
//				Assert.assertEquals(charStr, "Hello World");
				String sample = "Hello World";
				Clob clobval = rs.getClob(1);
				char[] clobBuff = new char[sample.length()];
				clobval.getCharacterStream().read(clobBuff);
				String clobStr = new String(clobBuff);
				Assert.assertEquals(clobStr, "Hello World");
			}
			logger
					.info("itemtbl_dallargeformatlob data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForUpdate() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT "
				+ " var_longtext,var_longblob,var_charstrm "
				+ " FROM itemtbl_dallargeformatlob";

		try {
			logger.info("begin to retrieve itemtbl_dallargeformatlob data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			while (rs.next()) {

				Clob textval = rs.getClob(1);
				byte[] buff1 = new byte[(int)textval.length()];
				textval.getAsciiStream().read(buff1);
				String sourceClob = new String(buff1);
				Assert.assertEquals(sourceClob, "Hello World");

				Blob blobval = rs.getBlob(2);
				byte[] buff2 = new byte[(int)blobval.length()];
				blobval.getBinaryStream().read(buff2);
				String sourceBlob = new String(buff2);
				Assert.assertEquals(sourceBlob, "Hello World");
				
//				Reader reader = rs.getCharacterStream(3);
//				StringBuilder strBuild = new StringBuilder();
//				int c;
//				while ((c=reader.read())>-1) {
//					strBuild.append(c);
//				}
//				String chars = strBuild.toString();
//				Assert.assertEquals(chars, "Hello World");
//				String charStr = rs.getString(3);
//				Assert.assertEquals(charStr, "Hello World");
				String sample = "Hello World";
				Clob clobval = rs.getClob(3);
				char[] clobBuff = new char[sample.length()];
				clobval.getCharacterStream().read(clobBuff);
				String clobStr = new String(clobBuff);
				Assert.assertEquals(clobStr, "Hello World");
			}
			logger
					.info("itemtbl_dallargeformatlob data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForDelete() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT "
				+ " var_longtext,var_longblob "
				+ " FROM itemtbl_dallargeformatlob";

		try {
			logger.info("begin to retrieve itemtbl_dallargeformatlob data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			int rowNum = rs.getRow();
			Assert.assertEquals(rowNum, 0);
			logger
					.info("itemtbl_dallargeformatlob data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForDrop() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = " select count(*) as table_num "
				+ " from information_schema.tables "
				+ " where table_name='itemtbl_dallargeformatlob' and table_schema='test'";

		try {
			logger.info("begin to retrieve user_table data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				// int num = rs.getInt("table_num");
				int num = rs.getInt(1);
				Assert.assertEquals(num, 0);
			}
			logger.info("user_table data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
