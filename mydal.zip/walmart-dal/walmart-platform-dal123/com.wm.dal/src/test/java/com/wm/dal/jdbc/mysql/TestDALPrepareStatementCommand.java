package com.wm.dal.jdbc.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.Test;

/**
 * Copyright 2009 walmart.com. All rights reserved
 */

/**
 * @author Martin Ma
 * @since 2009-5-5
 * @version 1.0 Test JDBC Date Format on mysql with DALConnection
 */
@Test(sequential = true)
public class TestDALPrepareStatementCommand extends BaseMysqlTest {

	private static final String TABLENAME = "ABC";

	@Test(groups = { "mysql", "create" })
	public void testCreate() {

		Connection con = null;
		Statement stmt = null;

		String dropTablSql = "DROP TABLE IF EXISTS " + TABLENAME + ";";
		String creaTablSql = "CREATE TABLE " + TABLENAME + " (" + "`id` bigint(20) NOT NULL"
			+ ") ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		try {
			logger.info("begin to create " + TABLENAME + " table.");
			con = dataSource.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate(dropTablSql);
			stmt.executeUpdate(creaTablSql);
			logger.info("" + TABLENAME + " table is created.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// @Test(dependsOnMethods = "testCreate", groups = { "mysql", "insert" })
	public void testInsert() {
		// prepare execute
		Connection con = null;
		PreparedStatement pstm = null;

		String insrSql = "INSERT INTO " + TABLENAME + " " + " (id)" + " VALUES " + " (?)";

		try {
			logger.info("begin to insert " + TABLENAME + " data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(insrSql);

			pstm.setInt(1, 12);

			pstm.execute();
			con.commit();

			logger.info("" + TABLENAME + " data are inserted.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		// testQueryForInsert();
	}

	// @Test(dependsOnMethods = "testInsert", groups = { "mysql", "update" })
	public void testUpdate() {
		// prepare update
		Connection con = null;
		PreparedStatement pstm = null;

		String insrSql = "UPDATE " + TABLENAME + " " + " SET id=?";

		try {
			logger.info("begin to update " + TABLENAME + " data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(insrSql);

			pstm.setInt(1, 13);
			pstm.executeUpdate();
			con.commit();

			logger.info("" + TABLENAME + " data are updated.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		// this.testQueryForUpdate();
	}

	// @Test(dependsOnMethods = "testUpdate", groups = { "mysql", "delete" })
	public void testDelete() {

		Connection con = null;
		Statement stmt = null;
		String dropTablSql = "DELETE FROM " + TABLENAME + ";";
		try {
			logger.info("begin to delete " + TABLENAME + " data.");
			con = dataSource.getConnection();
			stmt = con.createStatement();
			stmt.execute(dropTablSql);
			logger.info("data of " + TABLENAME + " table is deleted.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	// @Test(dependsOnMethods = "testDelete", groups = { "mysql", "drop" })
	public void testBatch() {
		// prepare execute
		Connection con = null;
		PreparedStatement pstm = null;

		String insrSql = "INSERT INTO " + TABLENAME + " " + " (id)" + " VALUES " + " (?)";

		try {
			logger.info("begin to insert " + TABLENAME + " data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(insrSql);
			System.out.println("GO");
			pstm.clearBatch();
			System.out.println("GO");
			for (int i = 0; i < 10; i++) {
				pstm.setInt(1, i);
				pstm.addBatch();
			}

			int[] is = pstm.executeBatch();
			con.commit();

			logger.info("" + TABLENAME + " data are inserted.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		// testQueryForInsert();
	}

	public void testClearWarnings() {
		Connection con = null;
		PreparedStatement stmt = null;

		String insrSql = "INSERT INTO " + TABLENAME + " " + " (id)" + " VALUES " + " (?)";

		try {
			con = dataSource.getConnection();
			stmt = con.prepareStatement(insrSql);
			stmt.clearWarnings();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQuery() {
		Connection con = null;
		PreparedStatement pstm = null;

		String insrSql = "SELECT * FROM " + TABLENAME +" where id > ?";
		try {
		
			con = dataSource.getConnection();
			pstm = con.prepareStatement(insrSql);
			pstm.setInt(1, 0);
			ResultSet rs=pstm.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
