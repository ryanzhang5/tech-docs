package com.wm.dal.jdbc.oracle;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Struct;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.wm.dal.jdbc.DALStruct;
import com.wm.dal.jdbc.DALStructDescriptor;

/**
 * Copyright 2009 walmart.com. All rights reserved
 */

/**
 * @author Martin Ma
 * @since 2009-5-5
 * @version 1.0 Test JDBC Large Format on oracle with DALConnection
 */
//@Test(sequential = true)
public class TestDALLargeFormatOracleStruct extends BaseOracleTest {

	private static final String TABLE_NAME = "itemtbl_dallargeformatstruct";	
	
	@Test(groups = { "oracle", "create" })
	public void testCreate() {

		Connection con = null;
		Statement stmt = null;

		String creaTypeSql = "CREATE TYPE TEST_STRUCT AS OBJECT(s VARCHAR2(30), i NUMBER(10), j NUMBER(10), d NUMBER(12,2))";
		String creaTablSql = "CREATE TABLE " + TABLE_NAME + "("
				+ "var_struct TEST_STRUCT " 
				+ ")";
		try {
			logger.info("begin to create itemtbl_dallargeformatarray table.");
			con = pureDataSource.getConnection();
			stmt = con.createStatement();
			stmt.execute(creaTypeSql);
			logger.info("test_struct type is created.");
			stmt.execute(creaTablSql);
			logger.info("itemtbl_dallargeformatstruct table is created.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForCreate();
	}

	@Test(dependsOnMethods = "testCreate", groups = { "oracle", "insert" })
	public void testInsert() {

		Connection con = null;
		PreparedStatement pstm = null;

		String insrSql = "INSERT INTO " + TABLE_NAME
				+ " (var_struct) " + " VALUES " + " (?) ";

		try {
			logger.info("begin to insert itemtbl_dallargeformatarray data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(insrSql);
			
			DALStructDescriptor descStr = DALStructDescriptor.createDescriptor(
					"TEST_STRUCT", con);
			Object[] values = new Object[]{"Walmart", new Long(2009), new Integer(200), new Double(10.2)};
			DALStruct structVal = new DALStruct(descStr, "TEST_STRUCT", values);
			pstm.setObject(1, structVal);
			
			pstm.executeUpdate();
			con.commit();

			logger.info("itemtbl_dallargeformatarray data are inserted.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForInsert();
	}

	@Test(dependsOnMethods = "testInsert", groups = { "oracle", "update" })
	public void testUpdate() {

		Connection con = null;
		PreparedStatement pstm = null;

		String updaSql = "UPDATE " + TABLE_NAME
				+ " SET var_struct=?";

		try {
			logger.info("begin to update itemtbl_dallargeformatarray data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(updaSql);

			DALStructDescriptor descStr = DALStructDescriptor.createDescriptor(
					"TEST_STRUCT", con);
			Object[] values = new Object[]{"Trustmart", new Long(2010), new Integer(300), new Double(10.3)};
			DALStruct structVal = new DALStruct(descStr, "TEST_STRUCT", values);
			pstm.setObject(1, structVal);

			pstm.executeUpdate();
			con.commit();

			logger.info("itemtbl_dallargeformatarray data are updated.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForUpdate();
	}

	@Test(dependsOnMethods = "testUpdate", groups = { "oracle", "delete" })
	public void testDelete() {

		Connection con = null;
		Statement stmt = null;

		String dropTablSql = "DELETE FROM " + TABLE_NAME;
		try {
			logger.info("begin to delete itemtbl_dallargeformatarray data.");
			con = dataSource.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate(dropTablSql);
			con.commit();
			logger.info("data of itemtbl_dallargeformatarray table is deleted.");
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForDelete();
	}

	@Test(dependsOnMethods = "testDelete", groups = { "oracle", "drop" })
	public void testDrop() {

		Statement stmt = null;
		Connection con = null;
		String dropTypeSql1 = "DROP TYPE TEST_STRUCT";
		String dropTablSql = "DROP TABLE " + TABLE_NAME;
		try {
			logger.info("begin to drop itemtbl_dallargeformatarray table.");
			con = pureDataSource.getConnection();
			
			stmt = con.createStatement();
			stmt.execute(dropTablSql);
			logger.info("itemtbl_dallargeformatarray table is dropped.");
			stmt.execute(dropTypeSql1);
			logger.info("TEST_STRUCT type is dropped.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForDrop();
	}

	public void testQueryForCreate() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT count(*) as table_num FROM user_tables WHERE lower(table_name)='" + TABLE_NAME + "'";

		try {
			logger.info("begin to retrieve user_table data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				// int num = rs.getInt("table_num");
				int num = rs.getInt(1);
				Assert.assertEquals(num, 1);
			}
			logger.info("user_table data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForInsert() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " var_struct "
				+ " FROM " + TABLE_NAME;

		try {
			logger.info("begin to retrieve itemtbl_dallargeformatarray data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			while (rs.next()) {

				Struct structVal = (Struct)rs.getObject(1);
				Object[] values = structVal.getAttributes();
				String str = (String)values[0];
				Long i = (Long)values[1];
				Integer j = (Integer)values[2];
				Double d = (Double)values[3];
				Assert.assertEquals(str, "Walmart");
				Assert.assertEquals(i, new Long(2009));
				Assert.assertEquals(j, new Integer(200));
				Assert.assertEquals(d, new Double(10.2));
			}
			logger
					.info("itemtbl_dallargeformatarray data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForUpdate() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " var_struct "
			+ " FROM " + TABLE_NAME;

		try {
			logger.info("begin to retrieve itemtbl_dallargeformatarray data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			while (rs.next()) {

				Struct structVal = (Struct)rs.getObject(1);
				Object[] values = structVal.getAttributes();
				String str = (String)values[0];
				Long i = (Long)values[1];
				Integer j = (Integer)values[2];
				Double d = (Double)values[3];
				Assert.assertEquals(str, "Trustmart");
				Assert.assertEquals(i, new Long(2010));
				Assert.assertEquals(j, new Integer(300));
				Assert.assertEquals(d, new Double(10.3));
			}
			logger.info("itemtbl_dallargeformatarray data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForDelete() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " count(*) "
				+ " FROM " + TABLE_NAME;

		try {
			logger.info("begin to retrieve itemtbl_dallargeformatarray data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			while (rs.next()) {

				int num = rs.getInt(1);
				Assert.assertEquals(num, 0);
			}
			logger.info("itemtbl_dallargeformatarray data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForDrop() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT count(*) as table_num FROM user_tables WHERE lower(table_name)='" + TABLE_NAME + "'";

		try {
			logger.info("begin to retrieve user_table data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				// int num = rs.getInt("table_num");
				int num = rs.getInt(1);
				Assert.assertEquals(num, 0);
			}
			logger.info("user_table data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
