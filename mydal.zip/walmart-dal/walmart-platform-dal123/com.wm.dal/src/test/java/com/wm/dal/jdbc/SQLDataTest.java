/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.jdbc;

import com.wm.dal.jdbc.DALArrayDescriptor;
import com.wm.dal.jdbc.DALFactory;
import com.wm.dal.jdbc.sqldata.OfferElementName;
import com.wm.dal.jdbc.sqldata.QuickScreenOfferArrayData;
import com.wm.dal.jdbc.BaseJdbcTest;
import com.wm.sql.DataAccess;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import java.io.IOException;
import java.sql.*;
import java.util.Arrays;

/**
 * SQLDataTest
 *
 * @author mkishore
 * @since TODO
 */
public class SQLDataTest {
    private static final String POOL = "jdbcpool_oracle";

    @BeforeClass
    public void initialize() {
        try {
            BaseJdbcTest.load(SQLDataTest.class, "/system.properties");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private interface offerArrayConstants {
        public static final String offerTab = "CUSTOMER.T_INSTANT_CREDIT_OFFER_TAB";
    }

    private enum getOfferCall implements offerArrayConstants {
        colZero,
        colcustomerId,
        colIndicateViewed,
        colQuickScreenId,
        colQuickScreenStatus,
        colFinderFileNumber,
        colArrayOfferElements;
        public static final String call = "{call wcu_mohan(?,?,?,?,?,?)}";

    }

    public void getOffer(long customerId, boolean indicateViewed) {
        Connection conn = null;
        CallableStatement stmt = null;
        String DB_TRUE = "Y";
        String DB_FALSE = "N";

        try {
            conn = DataAccess.getInstance().getConnection(POOL);
            stmt = conn.prepareCall(getOfferCall.call);

            stmt.setLong(getOfferCall.colcustomerId.ordinal(), customerId);
            stmt.setString(getOfferCall.colIndicateViewed.ordinal(), (indicateViewed) ? DB_TRUE : DB_FALSE);

            Connection oraConn = conn; //((PooledConnection) conn).getNativeConnection();
            DALArrayDescriptor descriptor = DALArrayDescriptor.createDescriptor(getOfferCall.offerTab, oraConn);
            //ArrayDescriptor descriptor = ArrayDescriptor.createDescriptor(getOfferCall.offerTab, oraConn);

            int noOfElements = OfferElementName.values().length;
            QuickScreenOfferArrayData[] offerElementObjects = new QuickScreenOfferArrayData[noOfElements];
            for (int i = 0; i < offerElementObjects.length; i++) {
                offerElementObjects[i] = new QuickScreenOfferArrayData();
            }
            Array offerElements = DALFactory.newArray(descriptor, Types.STRUCT, descriptor.getDescriptorName(), offerElementObjects);
            //Array offerElements = new ARRAY(descriptor, oraConn, offerElementObjects);

            stmt.registerOutParameter(getOfferCall.colQuickScreenId.ordinal(), Types.NUMERIC);
            stmt.registerOutParameter(getOfferCall.colQuickScreenStatus.ordinal(), Types.NUMERIC);
            stmt.registerOutParameter(getOfferCall.colFinderFileNumber.ordinal(), Types.VARCHAR);
            stmt.registerOutParameter(getOfferCall.colArrayOfferElements.ordinal(), Types.ARRAY, getOfferCall.offerTab);

            stmt.setArray(getOfferCall.colArrayOfferElements.ordinal(), offerElements);

            stmt.execute();

            stmt.getLong(getOfferCall.colQuickScreenId.ordinal());
            int qsOfferStatusCode = stmt.getInt(getOfferCall.colQuickScreenStatus.ordinal());

            stmt.getString(getOfferCall.colFinderFileNumber.ordinal());

            //This line may not be required because we have the handle to the array
            //offerElementObjects = (QuickScreenOfferArrayData[])stmt.getArray(getOfferCall.colArrayOfferElements.ordinal()).getArray();
            Array offerElementsArray = stmt.getArray(getOfferCall.colArrayOfferElements.ordinal());
            System.out.println("Array item " + offerElementsArray + ":");
            if (offerElementsArray != null) {
                java.util.HashMap<String,Class<?>> typeMap = new java.util.HashMap<String,Class<?>>();
                typeMap.put("CUSTOMER.T_INSTANT_CREDIT_OFFER_REC", QuickScreenOfferArrayData.class);
                Object[] oraArray = (Object[]) offerElementsArray.getArray(typeMap);
                for (Object oraArrayElement : oraArray) {
                    if (oraArrayElement instanceof Struct) {
                        Struct oraStruct = (Struct) oraArrayElement;
                        System.out.println("Value " + Arrays.asList(oraStruct.getAttributes()));
                    } else {
                        System.out.println("Value " + oraArrayElement);
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                stmt.close();
                conn.close();
            } catch (Exception exp) {
            System.currentTimeMillis();}
        }
    }

    @Test
    public void testGetOffers() {
        // grab customer id from jackhammer wcu_customer_quick_screen_t
        getOffer(1553262L, false);
    }

}
