package com.wm.dal.jdbc.oracle;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.Test;

@Test(sequential=true)
public class TestProcedureOracle extends BaseOracleTest {
	
	/**
	 * this method is used to test driver stored procedure supporting functions
	 * via mysql database 
	 * 1) has input  parameter for procedure 
	 * 2) has output parameter for procedure 
	 * 3) may return multi-resultset
	 * 
	 *	"     CREATE OR REPLACE Package pkg_test is                                                                  "
	 *	"         Type myCur is REF CURSOR;                                                                          "
	 *	"         Procedure proc_test(vinput IN INT, voutput OUT INT, curr_out_1 OUT myCur, curr_out_2 OUT myCur);   "
	 *	"     End pkg_test;                                                                                          "
	 * 
	 * 
	 *	"     CREATE OR REPLACE Package Body pkg_test is                                                             "
	 *	"         Procedure proc_test(vinput IN INT, voutput OUT INT, curr_out_1 OUT myCur, curr_out_2 OUT myCur)    "
	 *	"         IS                                                                                                 "
	 *	"         Begin                                                                                              "
	 *	"              voutput := 2 * vinput;                                                                        "
	 *	"              if vinput = 1 then                                                                            "
	 *	"                  OPEN curr_out_1 FOR select vinput,  'only one result' from dual ;                         "
	 *	"              else                                                                                          "
	 *	"                  OPEN curr_out_1 FOR select vinput,  'first result' from dual ;                            "
	 *	"                  OPEN curr_out_2 FOR select vinput, vinput+1,  'second result' from dual ;                 "
	 *	"              end if;                                                                                       "
	 *	"         End proc_test;                                                                                     "
	 *	"     End pkg_test;                                                                                          "
	 */
	@Test(groups = {"oracle", "sp_create"} )
	public void testProcedureCreate() {
		Connection con = null;
		Statement pstm = null;
		ResultSet rs = null;
		String createSP = ""
			+ "     CREATE OR REPLACE Package pkg_test is                                                                  "
			+ "         Type myCur is REF CURSOR;                                                                          "
			+ "         Procedure proc_test(vinput IN INT, voutput OUT INT, curr_out_1 OUT myCur, curr_out_2 OUT myCur);   "
			+ "     End pkg_test;                                                                                          ";

		String createSPBody = ""
			+ "     CREATE OR REPLACE Package Body pkg_test is                                                             "
			+ "         Procedure proc_test(vinput IN INT, voutput OUT INT, curr_out_1 OUT myCur, curr_out_2 OUT myCur)    "
			+ "         IS                                                                                                 "
			+ "         Begin                                                                                              "
			+ "              voutput := 2 * vinput;                                                                        "
			+ "              if vinput = 1 then                                                                            "
			+ "                  OPEN curr_out_1 FOR select vinput,  'only one result' from dual ;                         "
			+ "              else                                                                                          "
			+ "                  OPEN curr_out_1 FOR select vinput,  'first result' from dual ;                            "
			+ "                  OPEN curr_out_2 FOR select vinput, vinput+1,  'second result' from dual ;                 "
			+ "              end if;                                                                                       "
			+ "         End proc_test;                                                                                     "
			+ "     End pkg_test;                                                                                          ";
		
		try {
			logger.info("creating PROCEDURE proc_test" );
//			con = dataSource.getConnection();
			con = pureDataSource.getConnection();
			pstm = con.createStatement();
			pstm.executeUpdate(createSP);
			pstm.executeUpdate(createSPBody);
//			con.commit();
			logger.info("created  PROCEDURE proc_test" );
			
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)		rs.close();
				if (pstm != null)	pstm.close();
				if (con != null)	con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}	

	
	@Test(dependsOnMethods = "testProcedureCreate", groups = {"oracle", "sp_call"} )
	public void testProcedureCall() {
		Connection con = null;
		CallableStatement stmt = null;
		ResultSet rs = null;
		String callSP = "{ call pkg_test.proc_test(?,?,?,?) }";
		
		try {
			logger.info("calling PROCEDURE proc_test" );
			con = dataSource.getConnection();
			stmt = con.prepareCall(callSP);
			stmt.setInt(1, 100);
			stmt.registerOutParameter(2, java.sql.Types.INTEGER);
			stmt.registerOutParameter(3, OracleTypes.CURSOR);
			stmt.registerOutParameter(4, OracleTypes.CURSOR);

			boolean hadResults = stmt.execute();
			rs = (ResultSet) stmt.getObject(3);
			logger.info("ResultSet:");
			while (rs.next()) {
				int columnCount = rs.getMetaData().getColumnCount();
				String oneRow = "[";
				for (int i = 0; i < columnCount; i++) {
					oneRow += rs.getString(i + 1) + " | ";
				}
				logger.info(oneRow + "]");
			}

			rs = (ResultSet) stmt.getObject(4);
			logger.info("ResultSet:");
			while (rs.next()) {
				int columnCount = rs.getMetaData().getColumnCount();
				String oneRow = "[";
				for (int i = 0; i < columnCount; i++) {
					oneRow += rs.getString(i + 1) + " | ";
				}
				logger.info(oneRow + "]");
			}

			int outputValue = stmt.getInt(2);
			logger.info("\nOutParameter [int]: " + outputValue);

			con.commit();
			logger.info("called  PROCEDURE proc_test" );

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)			rs.close();
				if (stmt != null)		stmt.close();
				if (con != null)		con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}	

	
	@Test(dependsOnMethods = "testProcedureCall", groups = {"oracle", "sp_drop"} )
	public void testProcedureDrop() {
		Connection con = null;
		Statement pstm = null;
		String dropSPBody = "DROP Package Body  pkg_test";
		String dropSP = "DROP Package  pkg_test";

		try {
			logger.info("dropping PROCEDURE proc_test" );
//			con = dataSource.getConnection();
			con = pureDataSource.getConnection();
			pstm = con.createStatement();
			pstm.executeUpdate(dropSPBody);
			pstm.executeUpdate(dropSP);
			con.commit();
			logger.info("dropped  PROCEDURE proc_test" );
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstm != null)	pstm.close();
				if (con != null)	con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
}

