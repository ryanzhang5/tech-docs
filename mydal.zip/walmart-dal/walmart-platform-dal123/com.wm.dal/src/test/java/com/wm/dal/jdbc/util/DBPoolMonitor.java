package com.wm.dal.jdbc.util;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Logger;
import java.io.IOException;

import javax.management.NotCompliantMBeanException;
import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.Test;

import com.wm.sql.DBPoolAdmin;
import com.wm.dal.jdbc.BaseJdbcTest;

public class DBPoolMonitor extends TimerTask {

	public static final String DATASOURCETYPE = "jdbcpoolOracleDS";
	public static final String POOLALIAS_NAME = "jdbcpool_oracle";

    static {
        try {
            BaseJdbcTest.load(DBPoolMonitor.class, "/system.properties");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	private static ApplicationContext applicationContext = new ClassPathXmlApplicationContext("/test-context.xml");
	private DataSource dataSource = (DataSource) applicationContext.getBean(DATASOURCETYPE);
	private Logger logger = Logger.getLogger(DBPoolMonitor.class.getName());

	private Timer timer;
	private DBPoolAdmin dbPoolAdmn;

	public DBPoolMonitor() {
		try {
			dbPoolAdmn = new DBPoolAdmin(POOLALIAS_NAME);
		} catch (NotCompliantMBeanException e) {
			e.printStackTrace();
		}
	}

	public DBPoolMonitor(int seconds) {
		timer = new Timer();
		timer.schedule(new DBPoolMonitor(), 0, seconds * 100);
	}

	@Override
	public void run() {
		logger.info("~~~~~+++++~~~~~Connection Size: " + dbPoolAdmn.getPoolSize() + " | Max Size: " + dbPoolAdmn.getMaxConnection());
	}

	public void testOne() {
		
		logger.info("testOne starts");
		try {
			for (int i=0; i<3; i++) {
				Connection con1 = dataSource.getConnection();
				Statement stmt1 = con1.createStatement();
				stmt1.executeQuery("select * from testtable");
				Thread.sleep(4000);

				Connection con2 = dataSource.getConnection();
				Statement stmt2 = con1.createStatement();
				stmt2.executeQuery("select * from testtable");
				Thread.sleep(4000);
				
				Connection con3 = dataSource.getConnection();
				Statement stmt3 = con1.createStatement();
				stmt3.executeQuery("select * from testtable");
				Thread.sleep(4000);
				
				Connection con4 = dataSource.getConnection();
				Statement stmt4 = con1.createStatement();
				stmt4.executeQuery("select * from testtable");
				Thread.sleep(4000);
				
				Connection con5 = dataSource.getConnection();
				Statement stmt5 = con1.createStatement();
				stmt5.executeQuery("select * from testtable");
				Thread.sleep(4000);
				
				stmt1.close();
				con1.close();
				
				stmt2.close();
				con2.close();
				
				stmt3.close();
				con3.close();
				
				stmt4.close();
				con4.close();
				
				stmt5.close();
				con5.close();
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		logger.info("testOne ends");
	}
	
	public void testTwo() {
		
		logger.info("testTwo starts");
		try {
			for (int i=0; i<8; i++) {
				Connection con1 = dataSource.getConnection();
				Statement stmt1 = con1.createStatement();
				stmt1.executeQuery("select * from testtable");
				Thread.sleep(4000);
			}
			//while (true) {
				// Empty
			//}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		logger.info("testTwo ends");
	}
	
	// @Test(groups = { "oracle", "insert" })
	public void testShrink() {
		
		DBPoolMonitor dbMonitor = new DBPoolMonitor(1);
		dbMonitor.testOne();
		dbMonitor.testTwo();
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DBPoolMonitor dbMonitor = new DBPoolMonitor(1);
		dbMonitor.testOne();
		dbMonitor.testTwo();
	}
	
}
