package com.wm.dal.jta;

import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.shrinkwrap.api.spec.EnterpriseArchive;
import org.testng.annotations.Test;

@Test(singleThreaded = true)
public class TestCommitRollbackArquillianJTA2 extends TestCommitRollbackJTA2 {

	@Deployment(testable=true)
	public static EnterpriseArchive createDeployment() throws Exception {
		return BaseTestCase.createDeployment();
	}
}
