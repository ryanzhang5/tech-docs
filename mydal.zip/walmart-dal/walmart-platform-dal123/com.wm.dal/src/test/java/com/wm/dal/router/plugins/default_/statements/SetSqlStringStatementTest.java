/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.statements;

import com.wm.dal.common.DALSession;
import com.wm.dal.router.RouterRequest;
import com.wm.dal.router.RouterResponse;
import com.wm.dal.router.plugins.default_.IStatement;
import com.wm.dal.router.plugins.default_.RouterContext;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * IfConditionTest
 *
 * @author mkishore
 * @since 1.0
 */
@Test
public class SetSqlStringStatementTest {
    private static final RouterContext CONTEXT = new RouterContext(new RouterRequest(new DALSession("session-id", "client-id")), new RouterResponse());

    public void testSimpleReplace() {
        SetSqlStringStatement stmt = new SetSqlStringStatement();
        stmt.setRegex("wca_");
        stmt.setReplace("wcu_");
        stmt.setCaseInsensitive(true);
        stmt.initialize();

        CONTEXT.getRequest().getSession().setSQL("{ call wca_get_customer ( ? ) }");
        IStatement.Status status = stmt.execute(CONTEXT);
        Assert.assertEquals(status, IStatement.Status.CONTINUE);
        Assert.assertEquals(CONTEXT.getRequest().getSession().getSQL(), "{ call wcu_get_customer ( ? ) }");
    }

    public void testRegexReplace() {
        SetSqlStringStatement stmt = new SetSqlStringStatement();
        stmt.setRegex("(.*)call wca_(.*)");
        stmt.setReplace("$1call wcu_$2");
        stmt.setCaseInsensitive(true);
        stmt.initialize();

        CONTEXT.getRequest().getSession().setSQL("{ call wca_get_customer ( ? ) }");
        IStatement.Status status = stmt.execute(CONTEXT);
        Assert.assertEquals(status, IStatement.Status.CONTINUE);
        Assert.assertEquals(CONTEXT.getRequest().getSession().getSQL(), "{ call wcu_get_customer ( ? ) }");
    }

    public void testFirstAndAll() {
        SetSqlStringStatement stmt = new SetSqlStringStatement();
        stmt.setRegex("wca_");
        stmt.setReplace("wcu_");
        stmt.setCaseInsensitive(true);
        stmt.setAll(false);
        stmt.initialize();

        CONTEXT.getRequest().getSession().setSQL("wca_1 wca_2");
        IStatement.Status status = stmt.execute(CONTEXT);
        Assert.assertEquals(status, IStatement.Status.CONTINUE);
        Assert.assertEquals(CONTEXT.getRequest().getSession().getSQL(), "wcu_1 wca_2");

        stmt.setAll(true);
        stmt.initialize();

        CONTEXT.getRequest().getSession().setSQL("wca_1 wca_2");
        status = stmt.execute(CONTEXT);
        Assert.assertEquals(status, IStatement.Status.CONTINUE);
        Assert.assertEquals(CONTEXT.getRequest().getSession().getSQL(), "wcu_1 wcu_2");
    }

}