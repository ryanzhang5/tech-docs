package com.wm.dal.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class BookDAO extends BaseDAO<Book, Integer> implements IBookDAO {
    @PersistenceContext(unitName = "myEMF1")
    public void setEntityManager(EntityManager entityManager) {
        super.setEntityManager(entityManager);
    }
}
