/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.conditions;

import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * XorConditionTest
 *
 * @author mkishore
 * @version $Revision: 1.1 $
 * @since 1.0
 */
@Test
public class XorConditionTest {
    private static final Object CONTEXT = "context";

    public void testMT() {
        XorCondition condition = new XorCondition();
        Assert.assertFalse(condition.evaluate(CONTEXT));
    }

    public void testT() {
        XorCondition condition = new XorCondition();
        condition.getConditions().add(new MockCondition(true));
        Assert.assertTrue(condition.evaluate(CONTEXT));
    }

    public void testF() {
        XorCondition condition = new XorCondition();
        condition.getConditions().add(new MockCondition(false));
        Assert.assertFalse(condition.evaluate(CONTEXT));
    }

    public void testTT() {
        XorCondition condition = new XorCondition();
        condition.getConditions().add(new MockCondition(true));
        condition.getConditions().add(new MockCondition(true));
        Assert.assertFalse(condition.evaluate(CONTEXT));
    }

    public void testTF() {
        XorCondition condition = new XorCondition();
        condition.getConditions().add(new MockCondition(true));
        condition.getConditions().add(new MockCondition(false));
        Assert.assertTrue(condition.evaluate(CONTEXT));
    }

    public void testFT() {
        XorCondition condition = new XorCondition();
        condition.getConditions().add(new MockCondition(false));
        condition.getConditions().add(new MockCondition(true));
        Assert.assertTrue(condition.evaluate(CONTEXT));
    }

    public void testFF() {
        XorCondition condition = new XorCondition();
        condition.getConditions().add(new MockCondition(false));
        condition.getConditions().add(new MockCondition(false));
        Assert.assertFalse(condition.evaluate(CONTEXT));
    }

}