/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.jdbc;

import com.wm.dal.jdbc.BaseJdbcTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

/**
 * BlobTest - depends on the catalog schema - dal_data_type table !!
 *
 * @author mkishore
 * @since 1.0
 */
@Test(sequential=true)
public class BlobTest extends BaseJdbcTest {
    private static final int MAX_SIZE = 2 * 1024;// * 1024;
    private static final String POOL = "jdbcpool_oracle";

    @BeforeClass
    public void initializae() {
        try {
            BaseJdbcTest.load(BlobTest.class, "/system.properties");
            testDelete();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @AfterClass(groups = { "oracle", "create" })
    public void testDelete() {
        execute(POOL, "delete from dal_data_type where test_nbr = 1");
    }

    @Test(groups = { "oracle", "create" })
    public void testCRUD() throws SQLException {
        byte[] data = new byte[MAX_SIZE];
        Arrays.fill(data, (byte)1);
        execute(POOL, "insert into dal_data_type (test_nbr, test_blob) values (1, ?)", new DALBlob(data));

        List list = execute(POOL, "select test_blob from dal_data_type where test_nbr = 1");
        Assert.assertEquals(list.size(), 1);
        Object res = ((List) list.get(0)).get(0);
        Assert.assertTrue(res instanceof Blob);
        Assert.assertEquals(((Blob) res).length(), MAX_SIZE);

        data = new byte[MAX_SIZE];
        Arrays.fill(data, (byte)2);
        execute(POOL, "update dal_data_type set test_blob = ? where test_nbr = 1", new DALBlob(data));
        list = execute(POOL, "select test_blob from dal_data_type where test_nbr = 1");
        Assert.assertEquals(list.size(), 1);
        res = ((List) list.get(0)).get(0);
        Assert.assertTrue(res instanceof Blob);
        Assert.assertEquals(((Blob) res).length(), MAX_SIZE);
        Assert.assertEquals(((Blob) res).getBytes(1, 1)[0], 2);

        execute(POOL, "delete from dal_data_type where test_nbr = 1");
        list = execute(POOL, "select test_blob from dal_data_type where test_nbr = 1");
        Assert.assertEquals(list.size(), 0);
    }
}
