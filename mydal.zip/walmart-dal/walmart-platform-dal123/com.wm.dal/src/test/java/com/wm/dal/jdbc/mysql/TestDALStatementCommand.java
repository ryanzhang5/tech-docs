package com.wm.dal.jdbc.mysql;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.Test;

import com.wm.dal.jdbc.DALStatement;

/**
 * Copyright 2009 walmart.com. All rights reserved
 */

/**
 * @author Martin Ma
 * @since 2009-5-5
 * @version 1.0 Test JDBC Date Format on mysql with DALConnection
 */
public class TestDALStatementCommand extends BaseMysqlTest {

	private static final String TABLENAME = "ABC";

	@Test(groups = { "mysql", "create" })
	public void testCreate() {

		Connection con = null;
		Statement stmt = null;

		String dropTablSql = "DROP TABLE IF EXISTS " + TABLENAME + ";";
		String creaTablSql = "CREATE TABLE " + TABLENAME + " (" + "`id` bigint(20) NOT NULL"
			+ ") ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		try {
			logger.info("begin to create " + TABLENAME + " table.");
			con = dataSource.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate(dropTablSql);
			stmt.executeUpdate(creaTablSql);
			logger.info("" + TABLENAME + " table is created.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Test(groups = { "mysql", "insert" })
	public void testInsert() {

		Connection con = null;
		Statement stm = null;

		String sql = "INSERT INTO " + TABLENAME + " " + " (id)" + " VALUES " + " (12)";

		try {
			logger.info("begin to insert " + TABLENAME + " data.");
			con = dataSource.getConnection();
			stm = con.createStatement();
			stm.execute(sql);
			logger.info("" + TABLENAME + " data are inserted.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (stm != null)
					stm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		// testQueryForInsert();
	}

	@Test(groups = { "mysql", "insert" })
	public void testBatchInsert() {

		Connection con = null;
		Statement stm = null;

		String sql = "INSERT INTO " + TABLENAME + " " + " (id)" + " VALUES " + " (12)";

		try {
			logger.info("begin to insert " + TABLENAME + " data.");
			con = dataSource.getConnection();
			con.setAutoCommit(false);
			stm = con.createStatement();
			
			
			
			stm.addBatch("INSERT INTO " + TABLENAME + " " + " (id)" + " VALUES " + " (14)");
			stm.addBatch("INSERT INTO " + TABLENAME + " " + " (id)" + " VALUES " + " (15)");
			stm.addBatch("INSERT INTO " + TABLENAME + " " + " (id)" + " VALUES " + " (16)");
			stm.clearBatch();
			stm.addBatch("INSERT INTO " + TABLENAME + " " + " (id)" + " VALUES " + " (14)");
			stm.addBatch("INSERT INTO " + TABLENAME + " " + " (id)" + " VALUES " + " (15)");
			stm.addBatch("INSERT INTO " + TABLENAME + " " + " (id)" + " VALUES " + " (16)");

			int[] counts = stm.executeBatch();
			con.commit();
			logger.info("" + TABLENAME + " data are inserted.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (stm != null)
					stm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Test(groups = { "mysql", "update" })
	public void testUpdate() {

		Connection con = null;
		Statement pstm = null;

		String sql = "UPDATE " + TABLENAME + " " + " SET id=13";

		try {
			logger.info("begin to update " + TABLENAME + " data.");

			con = dataSource.getConnection();
			pstm = con.createStatement();

			pstm.executeUpdate(sql);
			con.commit();

			logger.info("" + TABLENAME + " data are updated.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	@Test(groups = { "mysql", "drop" })
	public void testQuery() {
		Statement stmt = null;
		Connection con = null;

		try {

			con = dataSource.getConnection();
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from " + TABLENAME);

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Test(groups = { "mysql", "delete" })
	public void testDelete() {

		Connection con = null;
		Statement stmt = null;
		String dropTablSql = "DELETE FROM " + TABLENAME + ";";
		try {
			logger.info("begin to delete " + TABLENAME + " data.");
			con = dataSource.getConnection();
			stmt = con.createStatement();
			stmt.execute(dropTablSql);
			logger.info("data of " + TABLENAME + " table is deleted.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Test(groups = { "mysql", "drop" })
	public void testDrop() {

		Statement stmt = null;
		Connection con = null;
		String dropTablSql = "DROP TABLE itemtbl_daldateformat;";
		try {
			logger.info("begin to drop itemtbl_daldateformat table.");
			con = dataSource.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate(dropTablSql);
			logger.info("itemtbl_daldateformat table is dropped.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Test(groups = { "mysql", "drop" })
	public void testClearWarnings() {
		DALStatement stmt = null;
		Connection con = null;

		try {

			con = dataSource.getConnection();
			stmt = (DALStatement) con.createStatement();
			stmt.clearWarnings();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Test(groups = { "mysql", "drop" })
	public void testSomething() {
		DALStatement stmt = null;
		Connection con = null;

		try {

			con = dataSource.getConnection();
			stmt = (DALStatement) con.createStatement();
			stmt.isPoolable();
		

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
