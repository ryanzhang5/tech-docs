package com.wm.dal.jdbc.oracle;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.wm.dal.jdbc.DALConnection;
import com.wm.dal.jdbc.util.ExceptionUtil;

/**
 * Copyright 2009 walmart.com. All rights reserved
 */ 

/**
 * @author Martin Ma
 * @since 2009-5-5
 * @version 1.0
 * Test JDBC Meta Data on oracle with DALConnection
 */
@Test(sequential=true)
public class TestDALMetaDataOracle extends BaseOracleTest {
	
	@Test(groups = {"oracle", "metadata"} )
	public void testMetaData() {
		Connection con = null;
		ResultSet rs = null;
		try {
			logger.info("testing oracle metaData." );
			con = dataSource.getConnection();
			
			try{
				String jdbcDrivName = con.getMetaData().getDriverName();
				logger.info("JDBC Driver Name: " + jdbcDrivName);
			}catch(SQLException e){
				ExceptionUtil.handlerMethodNotImp(e, logger, "con.getMetaData().getDriverName()");
			}
			
			try{
				String jdbcDrivVers = con.getMetaData().getDriverVersion();
				logger.info("JDBC Driver Version: " + jdbcDrivVers);
			}catch(SQLException e){
				ExceptionUtil.handlerMethodNotImp(e, logger, "con.getMetaData().getDriverVersion()");
			}
			
			try{
				String dbProdName = con.getMetaData().getDatabaseProductName();
				logger.info("Database Product Name:" + dbProdName);
			}catch(SQLException e){
				ExceptionUtil.handlerMethodNotImp(e, logger, "con.getMetaData().getDatabaseProductName()");
			}
			
			try{
				String dbProdVers = con.getMetaData().getDatabaseProductVersion();
				logger.info("Database Product Version:" + dbProdVers);
			}catch(SQLException e){
				ExceptionUtil.handlerMethodNotImp(e, logger, "con.getMetaData().getDatabaseProductVersion()");
			}

			try{
				rs = con.getMetaData().getTypeInfo();
				while (rs != null && rs.next())   {   
	                String   typeName   =   rs.getString("TYPE_NAME");   
	                short   dataType   =   rs.getShort("DATA_TYPE");   
	                logger.info("typeName " +typeName +  " , java.sql.Types: " + dataType);
				}
			}catch(SQLException e){
				ExceptionUtil.handlerMethodNotImp(e, logger, "con.getMetaData().getTypeInfo()");
			}

			logger.info("tested oracle metaData." );
		} catch (SQLException e) {
			Assert.fail();
		}finally{
			try {
				if (rs != null) rs.close();
				if (con != null) con.close();
			}catch (SQLException e) {
					e.printStackTrace();
			}
		}

	}

	
	@Test(dependsOnMethods = "testMetaData", groups = {"oracle", "metadata"} )
	public void testDALConnectionMetaData() {
		Connection con = null;
		ResultSet rs = null;
		try {
			logger.info("testing dal-oralce metaData." );
			con = dataSource.getConnection();
			
			try{
				String dbProdName = con.getMetaData().getDatabaseProductName();
				logger.info("Database Product Name:" + dbProdName);
			}catch(Exception e){
				ExceptionUtil.handlerMethodNotImp(e, logger, "((DALConnection)con).getMetaData(\"jdbcpool_mysql\").getDatabaseProductName()");
			}

			logger.info("tested dal-oracle metaData." );
		} catch (SQLException e) {
			Assert.fail();
		}finally{
			try {
				if (rs != null) rs.close();
				if (con != null) con.close();
			}catch (SQLException e) {
					e.printStackTrace();
			}
		}

	}
	

	
}
