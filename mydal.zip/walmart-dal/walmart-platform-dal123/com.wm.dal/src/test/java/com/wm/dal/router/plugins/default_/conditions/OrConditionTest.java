/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.conditions;

import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * OrConditionTest
 *
 * @author mkishore
 * @version $Revision: 1.1 $
 * @since 1.0
 */
@Test
public class OrConditionTest {
    private static final Object CONTEXT = "context";

    public void testMT() {
        OrCondition condition = new OrCondition();
        Assert.assertFalse(condition.evaluate(CONTEXT));
    }

    public void testT() {
        OrCondition condition = new OrCondition();
        condition.getConditions().add(new MockCondition(true));
        Assert.assertTrue(condition.evaluate(CONTEXT));
    }

    public void testF() {
        OrCondition condition = new OrCondition();
        condition.getConditions().add(new MockCondition(false));
        Assert.assertFalse(condition.evaluate(CONTEXT));
    }

    public void testTT() {
        OrCondition condition = new OrCondition();
        condition.getConditions().add(new MockCondition(true));
        condition.getConditions().add(new MockCondition(true));
        Assert.assertTrue(condition.evaluate(CONTEXT));
    }

    public void testTF() {
        OrCondition condition = new OrCondition();
        condition.getConditions().add(new MockCondition(true));
        condition.getConditions().add(new MockCondition(false));
        Assert.assertTrue(condition.evaluate(CONTEXT));
    }

    public void testFT() {
        OrCondition condition = new OrCondition();
        condition.getConditions().add(new MockCondition(false));
        condition.getConditions().add(new MockCondition(true));
        Assert.assertTrue(condition.evaluate(CONTEXT));
    }

    public void testFF() {
        OrCondition condition = new OrCondition();
        condition.getConditions().add(new MockCondition(false));
        condition.getConditions().add(new MockCondition(false));
        Assert.assertFalse(condition.evaluate(CONTEXT));
    }

}
