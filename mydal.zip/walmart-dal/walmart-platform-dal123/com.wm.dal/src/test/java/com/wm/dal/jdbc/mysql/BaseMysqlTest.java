/*
 * Copyright 2010 Walmart.com. All rights reserved.
 */
package com.wm.dal.jdbc.mysql;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.sql.DataSource;
import java.util.logging.Logger;
import java.io.IOException;

import com.wm.dal.jdbc.BaseJdbcTest;

/**
 * BaseOracleTest
 *
 * @author mkishore
 * @since 1.1
 */
public class BaseMysqlTest {

    protected static Logger logger = Logger.getLogger(BaseMysqlTest.class.getName());

    public static final String PUREDATASOURCE = "dalpoolMysqlDS";
    public final static String DATASOURCETYPE = "jdbcpoolMysqlDS";

    protected static ApplicationContext applicationContext;
    protected static DataSource dataSource;
    protected static DataSource pureDataSource;

    static {
        try {
            BaseJdbcTest.load(BaseMysqlTest.class, "/system.properties");
            applicationContext = new ClassPathXmlApplicationContext("/test-context.xml");
            dataSource = (DataSource) applicationContext.getBean(DATASOURCETYPE);
            pureDataSource = (DataSource) applicationContext.getBean(PUREDATASOURCE);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}