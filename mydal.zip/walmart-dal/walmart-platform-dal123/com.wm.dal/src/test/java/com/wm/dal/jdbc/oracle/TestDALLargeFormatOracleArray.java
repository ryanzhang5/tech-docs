package com.wm.dal.jdbc.oracle;

import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.wm.dal.jdbc.DALArray;
import com.wm.dal.jdbc.DALArrayDescriptor;
  
import com.wm.corelib.config.AppConfig;

/**
 * Copyright 2009 walmart.com. All rights reserved
 */

/**
 * @author Martin Ma
 * @since 2009-5-5
 * @version 1.0 Test JDBC Large Format on oracle with DALConnection
 */
//@Test(sequential = true)
public class TestDALLargeFormatOracleArray extends BaseOracleTest {

	private static final String USER_DIR_FOLDER = AppConfig.getInstance().getProperty("user.dir");
	private static final String TABLE_NAME = "itemtbl_dallargeformatarray";	
	
	@Test(groups = { "oracle", "create" })
	public void testCreate() {

		Connection con = null;
		Statement stmt = null;

		String creaTypeSql1 = "CREATE TYPE STR_VARRAY AS VARRAY(10) OF VARCHAR2(100)";
//		String creaTypeSql1 = "CREATE TYPE STR_VARRAY AS TABLE OF VARCHAR2(100)";
		String creaTypeSql2 = "CREATE TYPE INT_VARRAY AS VARRAY(10) OF NUMBER(10)";
//		String creaTypeSql2 = "CREATE TYPE INT_VARRAY AS TABLE OF NUMBER(10)";		
		String creaTablSql = "CREATE TABLE " + TABLE_NAME + "("
				+ "var_str_array STR_VARRAY, " 
				+ "var_int_array INT_VARRAY " 
				+ ")";
		try {
			logger.info("begin to create itemtbl_dallargeformatarray table.");
			con = pureDataSource.getConnection();
			stmt = con.createStatement();
			stmt.execute(creaTypeSql1);
			logger.info("str_varray type is created.");
			stmt.execute(creaTypeSql2);
			logger.info("int_varray type is created.");
			stmt.execute(creaTablSql);
			logger.info("itemtbl_dallargeformatarray table is created.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForCreate();
	}

	@Test(dependsOnMethods = "testCreate", groups = { "oracle", "insert" })
	public void testInsert() {

		Connection con = null;
		PreparedStatement pstm = null;

		String insrSql = "INSERT INTO " + TABLE_NAME
				+ " (var_str_array, var_int_array) " + " VALUES " + "(?, ?)";

		try {
			logger.info("begin to insert itemtbl_dallargeformatarray data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(insrSql);

			DALArrayDescriptor descStr = DALArrayDescriptor.createDescriptor(
					"STR_VARRAY", con);
			String[] valsStr = { "aaa", "bbb", "ccc" };
			DALArray arrayStr = new DALArray(descStr, java.sql.Types.VARCHAR, "STR_VARRAY", valsStr);
			pstm.setArray(1, arrayStr);

			DALArrayDescriptor descInt = DALArrayDescriptor.createDescriptor(
					"INT_VARRAY", con);
			Integer[] valsInt = { new Integer(100), new Integer(200), new Integer(300)};
			DALArray arrayInt = new DALArray(descInt, java.sql.Types.INTEGER, "INT_VARRAY", valsInt);
			pstm.setArray(2, arrayInt);
			
			pstm.executeUpdate();
			con.commit();

			logger.info("itemtbl_dallargeformatarray data are inserted.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		//TODO: FixMe testQueryForInsert();
	}

	@Test(dependsOnMethods = "testInsert", groups = { "oracle", "update" })
	public void testUpdate() {

		Connection con = null;
		PreparedStatement pstm = null;

		String updaSql = "UPDATE " + TABLE_NAME
				+ " SET var_str_array=?,var_int_array=?";

		try {
			logger.info("begin to update itemtbl_dallargeformatarray data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(updaSql);

			DALArrayDescriptor descStr = DALArrayDescriptor.createDescriptor(
					"STR_VARRAY", con);
			String[] valsStr = { "ddd", "eee", "fff" };
			DALArray arrayStr = new DALArray(descStr, java.sql.Types.VARCHAR, "STR_VARRAY", valsStr);
			pstm.setArray(1, arrayStr);

			DALArrayDescriptor descInt = DALArrayDescriptor.createDescriptor(
					"INT_VARRAY", con);
			Integer[] valsInt = { new Integer(400), new Integer(500), new Integer(600)};
			DALArray arrayInt = new DALArray(descInt, java.sql.Types.INTEGER, "INT_VARRAY", valsInt);
			pstm.setArray(2, arrayInt);

			pstm.executeUpdate();
			con.commit();

			logger.info("itemtbl_dallargeformatarray data are updated.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForUpdate();
	}

	@Test(dependsOnMethods = "testUpdate", groups = { "oracle", "delete" })
	public void testDelete() {

		Connection con = null;
		Statement stmt = null;

		String dropTablSql = "DELETE FROM " + TABLE_NAME;
		try {
			logger.info("begin to delete itemtbl_dallargeformatarray data.");
			con = dataSource.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate(dropTablSql);
			con.commit();
			logger.info("data of itemtbl_dallargeformatarray table is deleted.");
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForDelete();
	}

	@Test(dependsOnMethods = "testDelete", groups = { "oracle", "drop" })
	public void testDrop() {

		Statement stmt = null;
		Connection con = null;
		String dropTypeSql1 = "DROP TYPE str_varray";
		String dropTypeSql2 = "DROP TYPE int_varray";
		String dropTablSql = "DROP TABLE " + TABLE_NAME;
		try {
			logger.info("begin to drop itemtbl_dallargeformatarray table.");
			con = pureDataSource.getConnection();
			
			stmt = con.createStatement();
			stmt.execute(dropTablSql);
			logger.info("itemtbl_dallargeformatarray table is dropped.");
			stmt.execute(dropTypeSql1);
			logger.info("str_varray type is dropped.");
			stmt.execute(dropTypeSql2);
			logger.info("int_varray type is dropped.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForDrop();
	}

	public void testQueryForCreate() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT count(*) as table_num FROM user_tables WHERE lower(table_name)='" + TABLE_NAME + "'";

		try {
			logger.info("begin to retrieve user_table data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				// int num = rs.getInt("table_num");
				int num = rs.getInt(1);
				Assert.assertEquals(num, 1);
			}
			logger.info("user_table data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForInsert() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " var_str_array,var_int_array "
				+ " FROM " + TABLE_NAME;

		try {
			logger.info("begin to retrieve itemtbl_dallargeformatarray data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			while (rs.next()) {

				Array arrStr = rs.getArray(1);
				Array arrInt = rs.getArray(2);
				System.out.println("++++++++++++++++" + arrStr.toString());
				System.out.println("++++++++++++++++" + arrInt.toString());
//				String[] strs = (String[])arr.getArray();
//				String exptValu = strs[0];
				Object[] strs = (Object[])arrStr.getArray();
				String actuValuStr = (String)strs[0];
				System.out.println("++++++++++++++++" + actuValuStr);
				String exptValuStr = "aaa";
				Assert.assertEquals(actuValuStr, exptValuStr);
				actuValuStr = (String)strs[1];
				System.out.println("++++++++++++++++" + actuValuStr);
				exptValuStr = "bbb";
				Assert.assertEquals(actuValuStr, exptValuStr);
				actuValuStr = (String)strs[2];
				System.out.println("++++++++++++++++" + actuValuStr);
				exptValuStr = "ccc";
				Assert.assertEquals(actuValuStr, exptValuStr);
				
				Object[] ints = (Object[])arrInt.getArray();
				Integer actuValuInt = (Integer)ints[0];
				System.out.println("++++++++++++++++" + actuValuInt);
				Integer exptValuInt = new Integer(100);
				Assert.assertEquals(actuValuInt, exptValuInt);
				actuValuInt = (Integer)ints[1];
				System.out.println("++++++++++++++++" + actuValuInt);
				exptValuInt = new Integer(200);
				Assert.assertEquals(actuValuInt, exptValuInt);
				actuValuInt = (Integer)ints[2];
				System.out.println("++++++++++++++++" + actuValuInt);
				exptValuInt = new Integer(300);
				Assert.assertEquals(actuValuInt, exptValuInt);
			}
			logger
					.info("itemtbl_dallargeformatarray data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForUpdate() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " var_str_array,var_int_array "
				+ " FROM " + TABLE_NAME;

		try {
			logger.info("begin to retrieve itemtbl_dallargeformatarray data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			while (rs.next()) {

				Array arrStr = rs.getArray(1);
				Array arrInt = rs.getArray(2);
				System.out.println("++++++++++++++++" + arrStr.toString());
				System.out.println("++++++++++++++++" + arrInt.toString());
//				String[] strs = (String[])arr.getArray();
//				String exptValu = strs[0];
				Object[] strs = (Object[])arrStr.getArray();
				String actuValuStr = (String)strs[0];
				System.out.println("++++++++++++++++" + actuValuStr);
				String exptValuStr = "ddd";
				Assert.assertEquals(actuValuStr, exptValuStr);
				actuValuStr = (String)strs[1];
				System.out.println("++++++++++++++++" + actuValuStr);
				exptValuStr = "eee";
				Assert.assertEquals(actuValuStr, exptValuStr);
				actuValuStr = (String)strs[2];
				System.out.println("++++++++++++++++" + actuValuStr);
				exptValuStr = "fff";
				Assert.assertEquals(actuValuStr, exptValuStr);
				
				Object[] ints = (Object[])arrInt.getArray();
				Integer actuValuInt = (Integer)ints[0];
				System.out.println("++++++++++++++++" + actuValuInt);
				Integer exptValuInt = new Integer(400);
				Assert.assertEquals(actuValuInt, exptValuInt);
				actuValuInt = (Integer)ints[1];
				System.out.println("++++++++++++++++" + actuValuInt);
				exptValuInt = new Integer(500);
				Assert.assertEquals(actuValuInt, exptValuInt);
				actuValuInt = (Integer)ints[2];
				System.out.println("++++++++++++++++" + actuValuInt);
				exptValuInt = new Integer(600);
				Assert.assertEquals(actuValuInt, exptValuInt);
			}
			logger.info("itemtbl_dallargeformatarray data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForDelete() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " count(*) "
				+ " FROM " + TABLE_NAME;

		try {
			logger.info("begin to retrieve itemtbl_dallargeformatarray data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			while (rs.next()) {

				int num = rs.getInt(1);
				Assert.assertEquals(num, 0);
			}
			logger.info("itemtbl_dallargeformatarray data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForDrop() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT count(*) as table_num FROM user_tables WHERE lower(table_name)='" + TABLE_NAME + "'";

		try {
			logger.info("begin to retrieve user_table data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				// int num = rs.getInt("table_num");
				int num = rs.getInt(1);
				Assert.assertEquals(num, 0);
			}
			logger.info("user_table data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
