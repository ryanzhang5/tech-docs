package com.wm.dal.jdbc.mysql;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Currency;
import java.util.Locale;
import java.util.TimeZone;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.wm.dal.jdbc.data.Item;

/**
 * Copyright 2009 walmart.com. All rights reserved
 */

/**
 * @author Martin Ma
 * @since 2009-4-16
 * @version 1.0 Test program used to test pure mysql jdbc driver.
 */
@Test(sequential=true)
public class TestPureJDBCMysql extends BaseMysqlTest {

//	/**
//	 * @param args
//	 */
//	public static void main(String[] args) {
//
//		TestPureJDBCMysql tester = new TestPureJDBCMysql();
//		tester.initialize();
//		tester.testCleanup();
//		tester.testInsertAllTypeValues();
//		tester.testRetrieveAllTypeValues();
//		tester.testMetaData();
//		tester.testProcedure();
//		tester.tearDown();
//	}

	@BeforeClass(groups = { "mysql" })
	public void initialize() {

		System.out.println("Begin of initialize");
		Connection con = null;
		Statement stmt = null;

		String dropTablSql = "DROP TABLE IF EXISTS itemtbl;";

		String creaTablSql = "CREATE TABLE itemtbl ("
				+ "var_bigint bigint(20) default NULL,"
				+ "var_tinyblob tinyblob," + "var_bit bit(1) default NULL,"
				+ "var_char char(1) default NULL,"
				+ "var_date date default NULL,"
				+ "var_datetime datetime default NULL,"
				+ "var_time time default NULL,"
				+ "var_decimal decimal(19,2) default NULL,"
				+ "var_double double default NULL,"
				+ "var_float float default NULL,"
				+ "var_int int(11) default NULL,"
				+ "var_smallint smallint(6) default NULL,"
				+ "var_longtext longtext," + "var_longblob longblob,"
				+ "var_tinyint tinyint(4) default NULL,"
				+ "var_varchar varchar(20) default NULL,"
				+ "var_calendartimestamp timestamp default CURRENT_TIMESTAMP,"
				+ "var_calendardate date default NULL,"
				+ "var_classvarchar varchar(255) default NULL,"
				+ "var_currency varchar(255) default NULL,"
				+ "var_locale varchar(255) default NULL,"
				+ "var_serializable mediumblob default NULL,"
				+ "var_timezone varchar(255) default NULL,"
				+ "var_truefalse char(1) default NULL,"
				+ "var_yesno char(1) default NULL"
				+ ") ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		try {
			con = dataSource.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate(dropTablSql);
			stmt.executeUpdate(creaTablSql);
			System.out.println("itemtbl table is created.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("End of initialize");

	}

	@Test(groups = { "mysql" })
	public void testCleanup() {

		System.out.println("Begin of cleanup.");
		Connection con = null;
		Statement stmt = null;

		String dropTablSql = "DELETE FROM itemtbl;";
		try {
			con = dataSource.getConnection();
			stmt = con.createStatement();
			stmt.execute(dropTablSql);
			System.out.println("data of itemtbl table is cleaned.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("End of initialize");

	}

	@Test(dependsOnMethods = "testCleanup", groups = { "mysql" })
	public void testInsertAllTypeValues() {

		System.out.println("Begin of insert data.");
		Connection con = null;
		PreparedStatement pstm = null;

		String insrSql = "INSERT INTO itemtbl"
				+ "(var_bigint,var_tinyblob,var_bit,var_char,var_date,"
				+ "var_datetime,var_time,var_decimal,var_double,var_float,"
				+ "var_int,var_smallint,var_longtext,var_longblob,var_tinyint,"
				+ "var_varchar,var_calendartimestamp,var_calendardate,var_classvarchar,var_currency,"
				+ "var_locale,var_serializable,var_timezone,var_truefalse,var_yesno"
				+ ")" + " VALUES "
				+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

		try {
			con = dataSource.getConnection();
			pstm = con.prepareStatement(insrSql);
			pstm.setLong(1, Long.valueOf("9223372036854775807"));
			pstm.setBytes(2, new String("Hello World").getBytes());
			pstm.setBoolean(3, true);
			pstm.setString(4, "A");
			pstm.setDate(5, new java.sql.Date(System.currentTimeMillis()));
			pstm.setTimestamp(6, new java.sql.Timestamp(System
					.currentTimeMillis()));
			pstm.setTime(7, new java.sql.Time(System.currentTimeMillis()));
			pstm.setBigDecimal(8, new BigDecimal("9999999.99"));
			pstm.setDouble(9, 99999.3);
			pstm.setFloat(10, 12.3f);
			pstm.setInt(11, 2147483647);
			pstm.setShort(12, (short) 32767);

			// textval
			File inpuTextFile = new File(TestPureJDBCMysql.class.getResource(
					"/inputtexttest.txt").getPath());
			int inpuTextLeng = (int) inpuTextFile.length();
			InputStream inpuTextStrm = TestPureJDBCMysql.class
					.getResourceAsStream("/inputtexttest.txt");
			pstm.setAsciiStream(13, inpuTextStrm, inpuTextLeng);

			// blobval
			File inpuImagFile = new File(TestPureJDBCMysql.class.getResource(
					"/inputimagetest.jpg").getPath());
			int inpuImagLeng = (int) inpuImagFile.length();
			InputStream inpuImagStrm = TestPureJDBCMysql.class
					.getResourceAsStream("/inputimagetest.jpg");
			pstm.setBinaryStream(14, inpuImagStrm, inpuImagLeng);

			pstm.setByte(15, (byte) 127);
			pstm.setString(16, "Hello World!");

			pstm.setTimestamp(17, new java.sql.Timestamp(System
					.currentTimeMillis()));
			pstm.setDate(18, new java.sql.Date(System.currentTimeMillis()));
			pstm.setString(19, "Hello".getClass().toString());
			pstm.setString(20, Currency.getInstance(Locale.CHINA).toString());
			pstm.setString(21, Locale.CHINA.toString());

			Item item = new Item();
			item.setName("Serialized Object");
			pstm.setObject(22, item);

			pstm.setString(23, getLimitedLengthString(TimeZone.getDefault()
					.toString(), 255));
			pstm.setBoolean(24, new Boolean(true));
			pstm.setBoolean(25, new Boolean(false));

			pstm.execute();

			con.commit();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		// // catch (IOException e) {
		// // e.printStackTrace();
		// }
		catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		System.out.println("End of insert data.");

	}

	@Test(dependsOnMethods = "testInsertAllTypeValues", groups = { "mysql" })
	public void testRetrieveAllTypeValues() {

		System.out.println("Begin of retrieve data.");
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		
		String seleSql = "SELECT "
				+ "var_bigint,var_tinyblob,var_bit,var_char,var_date,"
				+ "var_datetime,var_time,var_decimal,var_double,var_float,"
				+ "var_int,var_smallint,var_longtext,var_longblob,var_tinyint,"
				+ "var_varchar,var_calendartimestamp,var_calendardate,var_classvarchar,var_currency,"
				+ "var_locale,var_serializable,var_timezone,var_truefalse,var_yesno"
				+ " FROM itemtbl";

		try {
			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			while (rs.next()) {
				long bigintVal = rs.getLong("var_bigint");
				System.out.println("var_bigint" + " : " + bigintVal);

				byte[] tinyblobVal = rs.getBytes("var_tinyblob");
				System.out.println("var_tinyblob" + " : "
						+ new String(tinyblobVal));

				boolean bitVal = rs.getBoolean("var_bit");
				System.out.println("var_bit" + " : " + bitVal);

				String charVal = rs.getString("var_char");
				System.out.println("var_char" + " : " + charVal);

				java.sql.Date dateVal = rs.getDate("var_date");
				System.out.println("var_date" + " : " + dateVal);

				java.sql.Timestamp datetimeVal = rs
						.getTimestamp("var_datetime");
				System.out.println("var_datetime" + " : " + datetimeVal);

				java.sql.Time timeVal = rs.getTime("var_time");
				System.out.println("var_time" + " : " + timeVal);

				BigDecimal decimalVal = rs.getBigDecimal("var_decimal");
				System.out.println("var_decimal" + " : " + decimalVal);

				double doubleVal = rs.getDouble("var_double");
				System.out.println("var_double" + " : " + doubleVal);

				float floatVal = rs.getFloat("var_float");
				System.out.println("var_float" + " : " + floatVal);

				int intVal = rs.getInt("var_int");
				System.out.println("var_int" + " : " + intVal);

				short smallintVal = rs.getShort("var_smallint");
				System.out.println("var_smallint" + " : " + smallintVal);

				System.out
						.println("Clob" + ":" + "creating outputtexttest.txt");
				try {
					Clob textval = rs.getClob("var_longtext");
					InputStream is = textval.getAsciiStream();
					FileOutputStream fos = new FileOutputStream(
							"outputtexttest.txt");
					byte[] buf = new byte[102400];
					int len;
					while ((len = is.read(buf)) != -1) {
						fos.write(buf, 0, len);
					}
					fos.close();
					is.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				System.out.println("Clob" + ":" + "created outputtexttest.txt");

				System.out.println("\nBlob" + ":"
						+ "creating outputimagetest.jpg");
				try {
					Blob blobval = rs.getBlob("var_longblob");
					InputStream is = blobval.getBinaryStream();
					FileOutputStream fos = new FileOutputStream(
							"outputimagetest.jpg");
					byte[] buf = new byte[102400];
					int len;
					while ((len = is.read(buf)) != -1) {
						fos.write(buf, 0, len);
					}
					fos.close();
					is.close();
				} catch (SQLException e) {
					e.printStackTrace();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				System.out.println("\nBlob" + ":"
						+ "created outputimagetest.jpg");

				byte tinyintVal = rs.getByte("var_tinyint");
				System.out.println("var_tinyint" + " : " + tinyintVal);

				String varcharVal = rs.getString("var_varchar");
				System.out.println("var_varchar" + " : " + varcharVal);

				java.sql.Timestamp calendarTimestampVal = rs
						.getTimestamp("var_calendartimestamp");
				System.out.println("var_calendartimestamp" + " : "
						+ calendarTimestampVal);

				java.sql.Date calendardateVal = rs.getDate("var_calendardate");
				System.out
						.println("var_calendardate" + " : " + calendardateVal);

				String classvarcharVal = rs.getString("var_classvarchar");
				System.out
						.println("var_classvarchar" + " : " + classvarcharVal);

				String currencyVal = rs.getString("var_currency");
				System.out.println("var_currency" + " : " + currencyVal);

				String localeVal = rs.getString("var_locale");
				System.out.println("var_locale" + " : " + localeVal);

				ObjectInputStream itemObjStr = new ObjectInputStream(rs
						.getBinaryStream("var_serializable"));
				Object serializableVal = itemObjStr.readObject();
				System.out.println("var_serializable" + " : "
						+ ((Item) serializableVal).getName());

				String timezoneVal = rs.getString("var_timezone");
				System.out.println("var_timezone" + " : " + timezoneVal);

				Boolean truefalseVal = rs.getBoolean("var_truefalse");
				System.out.println("var_truefalse" + " : " + truefalseVal);

				Boolean yesnoVal = rs.getBoolean("var_yesno");
				System.out.println("var_yesno" + " : " + yesnoVal);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {				
				if (rs != null)
				rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		System.out.println("End of retrieve data.");

	}

	@Test( groups = { "mysql" } )
	public void testMetaData() {
		Connection con = null;
		try {
			con = dataSource.getConnection();
			String jdbcDrivName = con.getMetaData().getDriverName();
			String jdbcDrivVers = con.getMetaData().getDriverVersion();
			String dbProdName = con.getMetaData().getDatabaseProductName();
			String dbProdVers = con.getMetaData().getDatabaseProductVersion();

			System.out.println("JDBC Driver Name: " + jdbcDrivName);
			System.out.println("JDBC Driver Version: " + jdbcDrivVers);
			System.out.println("Database Product Name:" + dbProdName);
			System.out.println("Database Product Version:" + dbProdVers);

		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if (con != null)
					con.close();
			}catch (SQLException e) {
					e.printStackTrace();
			}
		}

	}

	@Test(groups = { "mysql" })
	public void testProcedure() {
		Connection con = null;
		CallableStatement stmt = null;
		Statement pstm = null;
		ResultSet rs = null;
		String dropSP = "DROP PROCEDURE IF EXISTS proc_test;";
		String createSP = "CREATE PROCEDURE proc_test(in input INT, out output INT) "
				+ " begin "
				+ "     set output = 2 * input; "
				+ "     if input = 1 then "
				+ "         select input,  'only one result' ; "
				+ "     else "
				+ "         select input,  'first result' ; "
				+ "         select input, input+1,  'second result' ;    "
				+ "     end if; " + " end;";
		String callSP = "{ call proc_test(?,?) }";

		try {
			con = dataSource.getConnection();
			pstm = con.createStatement();
			pstm.executeUpdate(dropSP);
			pstm.executeUpdate(createSP);

			stmt = con.prepareCall(callSP);
			stmt.setInt(1, 100);
			stmt.registerOutParameter(2, java.sql.Types.INTEGER);

			boolean hadResults = stmt.execute();
			while (hadResults) {
				rs = stmt.getResultSet();
				System.out.println("ResultSet:");
				while (rs.next()) {
					int columnCount = rs.getMetaData().getColumnCount();
					String oneRow = "[";
					for (int i = 0; i < columnCount; i++) {
						oneRow += rs.getString(i + 1) + " | ";
					}
					System.out.println(oneRow + "]");
				}
				hadResults = stmt.getMoreResults();
			}

			int outputValue = stmt.getInt(2);
			System.out.println("\nOutParameter [int]: " + outputValue);

			pstm.executeUpdate(dropSP);
			con.commit();

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@AfterClass(groups = { "mysql" })
	public void tearDown() {

		System.out.println("Begin of drop table.");
		Statement stmt = null;
		Connection con = null;
		String dropTablSql = "DROP TABLE itemtbl;";
		try {
                        con = dataSource.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate(dropTablSql);
			System.out.println("itemtbl table is dropped.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("End of drop table.");

	}

	private String getLimitedLengthString(String source, int lengthLimit) {

		String target = null;
		target = source.length() > lengthLimit ? source.substring(0,
				lengthLimit) : source;
		return target;
	}
}

