package com.wm.dal.jta.support;

import java.sql.SQLException;

import javax.sql.DataSource;

public class ExtendedJdbcOracleTemplate extends ExtendedJdbcTemplate 
	implements ExtendedJdbcOperations 
{
	public ExtendedJdbcOracleTemplate(DataSource dataSource) {
		super(dataSource);
	}

	public boolean tableExists(String tableName) throws SQLException {
		return queryForInt("SELECT count(*) as table_num FROM user_tables WHERE lower(table_name)='"
				+ tableName + "'") == 1;
	}

  public void dropTableIfExists(String tableName) throws SQLException {
			if (tableExists(tableName))
					getJdbcOperations().execute("DROP TABLE " + tableName);
	}

}
