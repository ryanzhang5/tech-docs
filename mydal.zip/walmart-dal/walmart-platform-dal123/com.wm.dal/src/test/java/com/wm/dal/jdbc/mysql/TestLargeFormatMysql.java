package com.wm.dal.jdbc.mysql;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.wm.dal.jdbc.data.Item;
  
import com.wm.corelib.config.AppConfig;

//@Test(sequential = true)
public class TestLargeFormatMysql extends BaseMysqlTest {

	private static final String USER_DIR_FOLDER = AppConfig.getInstance().getProperty("user.dir");

	@Test(groups = { "mysql", "create" })
	public void testCreate() {

		Connection con = null;
		Statement stmt = null;

		String dropTablSql = "DROP TABLE IF EXISTS itemtbl_testlargeformat;";
		String creaTablSql = "CREATE TABLE itemtbl_testlargeformat ("
				+ "var_tinyblob tinyblob," + "var_longtext longtext,"
				+ "var_longblob longblob,"
				+ "var_serializable mediumblob default NULL"
				+ ") ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		try {
			logger.info("begin to create itemtbl_testlargeformat table.");
//			con = dataSource.getConnection();
			con = pureDataSource.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate(dropTablSql);
			stmt.executeUpdate(creaTablSql);
			logger.info("itemtbl_testlargeformat table is created.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForCreate();
	}

	@Test(dependsOnMethods = "testCreate", groups = { "mysql", "insert" })
	public void testInsert() {

		Connection con = null;
		PreparedStatement pstm = null;

		String insrSql = "INSERT INTO itemtbl_testlargeformat"
				+ " (var_tinyblob,var_longtext,var_longblob,var_serializable) "
				+ " VALUES " + " (?,?,?,?)";

		try {
			logger.info("begin to insert itemtbl_testlargeformat data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(insrSql);

			pstm.setBytes(1, new String("Hello World").getBytes());

			File inpuTextFile = new File(TestPureJDBCMysql.class.getResource(
					"/inputtexttest.txt").getPath());
			int inpuTextLeng = (int) inpuTextFile.length();
			InputStream inpuTextStrm = TestPureJDBCMysql.class
					.getResourceAsStream("/inputtexttest.txt");
			pstm.setAsciiStream(2, inpuTextStrm, inpuTextLeng);

			File inpuImagFile = new File(TestPureJDBCMysql.class.getResource(
					"/inputimagetest.jpg").getPath());
			int inpuImagLeng = (int) inpuImagFile.length();
			InputStream inpuImagStrm = TestPureJDBCMysql.class
					.getResourceAsStream("/inputimagetest.jpg");
			pstm.setBinaryStream(3, inpuImagStrm, inpuImagLeng);

			Item item = new Item();
			item.setName("Serialized Object");
			pstm.setObject(4, item);

			pstm.execute();
			con.commit();

			logger.info("itemtbl_testlargeformat data are inserted.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForInsert();
	}

	@Test(dependsOnMethods = "testInsert", groups = { "mysql", "update" })
	public void testUpdate() {

		Connection con = null;
		PreparedStatement pstm = null;

		String insrSql = "UPDATE itemtbl_testlargeformat "
				+ " SET var_tinyblob=?,var_longtext=?,var_longblob=?,var_serializable=?";

		try {
			logger.info("begin to update itemtbl_testlargeformat data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(insrSql);

			pstm.setBytes(1, new String("Hi Everybody").getBytes());

			File inpuTextFile = new File(TestPureJDBCMysql.class.getResource(
					"/inputtexttest.txt").getPath());
			int inpuTextLeng = (int) inpuTextFile.length();
			InputStream inpuTextStrm = TestPureJDBCMysql.class
					.getResourceAsStream("/inputtexttest.txt");
			pstm.setAsciiStream(2, inpuTextStrm, inpuTextLeng);

			File inpuImagFile = new File(TestPureJDBCMysql.class.getResource(
					"/inputimagetest.jpg").getPath());
			int inpuImagLeng = (int) inpuImagFile.length();
			InputStream inpuImagStrm = TestPureJDBCMysql.class
					.getResourceAsStream("/inputimagetest.jpg");
			pstm.setBinaryStream(3, inpuImagStrm, inpuImagLeng);

			Item item = new Item();
			item.setName("Updated Serialized Object");
			pstm.setObject(4, item);

			pstm.execute();
			con.commit();

			logger.info("itemtbl_testlargeformat data are updated.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForUpdate();
	}

	@Test(dependsOnMethods = "testUpdate", groups = { "mysql", "delete" })
	public void testDelete() {

		Connection con = null;
		Statement stmt = null;

		String dropTablSql = "DELETE FROM itemtbl_testlargeformat;";
		try {
			logger.info("begin to delete itemtbl_testlargeformat data.");
			con = dataSource.getConnection();
			stmt = con.createStatement();
			stmt.execute(dropTablSql);
			con.commit();
			
			logger.info("data of itemtbl_testlargeformat table is deleted.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForDelete();
	}

	@Test(dependsOnMethods = "testDelete", groups = { "mysql", "drop" })
	public void testDrop() {

		Statement stmt = null;
		Connection con = null;
		String dropTablSql = "DROP TABLE itemtbl_testlargeformat;";
		try {
			logger.info("begin to drop itemtbl_testlargeformat table.");
//			con = dataSource.getConnection();
			con = pureDataSource.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate(dropTablSql);
			logger.info("itemtbl_testlargeformat table is dropped.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForDrop();
	}

	public void testQueryForCreate() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = " select count(*) as table_num "
				+ " from information_schema.tables "
				+ " where table_name='itemtbl_testlargeformat' and table_schema='test'";

		try {
			logger.info("begin to retrieve user_table data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				int num = rs.getInt(1);
				Assert.assertEquals(num, 1);
			}
			logger.info("user_table data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForInsert() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT "
				+ " var_tinyblob,var_longtext,var_longblob,var_serializable "
				+ " FROM itemtbl_testlargeformat";

		try {
			logger.info("begin to retrieve itemtbl_testlargeformat data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			while (rs.next()) {

				byte[] tinyblobVal = rs.getBytes(1);
				logger.info("var_tinyblob" + " : " + new String(tinyblobVal));
				Assert.assertEquals(new String(tinyblobVal), "Hello World");

				logger.info("\nClob" + ":" + "creating outputtexttest.txt");
				try {
					Clob textval = rs.getClob(2);
					InputStream is = textval.getAsciiStream();
					FileOutputStream fos = new FileOutputStream(USER_DIR_FOLDER
							+ "/outputtexttest.txt");
					byte[] buf = new byte[102400];
					int len;
					while ((len = is.read(buf)) != -1) {
						fos.write(buf, 0, len);
					}
					fos.close();
					is.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				logger.info("Clob" + ":" + "created outputtexttest.txt");
				File inpuTextFile = new File(this.getClass().getResource("/inputtexttest.txt").getPath());
				int inpuTextLeng = (int) inpuTextFile.length();
				File outpTextFile = new File(USER_DIR_FOLDER
						+ "/outputtexttest.txt");
				int outpTextLeng = (int) outpTextFile.length();
				Assert.assertEquals(outpTextLeng, inpuTextLeng);

				logger.info("\nBlob" + ":" + "creating outputimagetest.jpg");
				try {
					Blob blobval = rs.getBlob(3);
					InputStream is = blobval.getBinaryStream();
					FileOutputStream fos = new FileOutputStream(USER_DIR_FOLDER
							+ "/outputimagetest.jpg");
					byte[] buf = new byte[102400];
					int len;
					while ((len = is.read(buf)) != -1) {
						fos.write(buf, 0, len);
					}
					fos.close();
					is.close();
				} catch (SQLException e) {
					e.printStackTrace();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				logger.info("Blob" + ":" + "created outputimagetest.jpg");
				File inpuStreFile = new File(this.getClass().getResource("/inputimagetest.jpg").getPath());
				int inpuStreLeng = (int) inpuStreFile.length();
				File outpStreFile = new File(USER_DIR_FOLDER
						+ "/outputimagetest.jpg");
				int outpStreLeng = (int) outpStreFile.length();
				Assert.assertEquals(outpStreLeng, inpuStreLeng);

				byte[] itemBytes = rs.getBytes(4);
				ByteArrayInputStream bi = new ByteArrayInputStream(itemBytes);
				ObjectInputStream oi = new ObjectInputStream(bi);
				Object seriVal = oi.readObject();
				logger.info("var_serializable" + " : "
						+ ((Item) seriVal).getName());
				Assert.assertEquals(((Item) seriVal).getName(),
						"Serialized Object");
			}
			logger.info("itemtbl_testlargeformat data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForUpdate() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT "
				+ " var_tinyblob,var_longtext,var_longblob,var_serializable "
				+ " FROM itemtbl_testlargeformat";

		try {
			logger.info("begin to retrieve itemtbl_testlargeformat data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			while (rs.next()) {

				byte[] tinyblobVal = rs.getBytes(1);
				logger.info("var_tinyblob" + " : " + new String(tinyblobVal));
				Assert.assertEquals(new String(tinyblobVal), "Hi Everybody");

				logger.info("\nClob" + ":" + "creating outputtexttest.txt");
				try {
					Clob textval = rs.getClob(2);
					InputStream is = textval.getAsciiStream();
					FileOutputStream fos = new FileOutputStream(USER_DIR_FOLDER
							+ "/outputtexttest.txt");
					byte[] buf = new byte[102400];
					int len;
					while ((len = is.read(buf)) != -1) {
						fos.write(buf, 0, len);
					}
					fos.close();
					is.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				logger.info("Clob" + ":" + "created outputtexttest.txt");
				File inpuTextFile = new File(this.getClass().getResource("/inputtexttest.txt").getPath());
				int inpuTextLeng = (int) inpuTextFile.length();
				File outpTextFile = new File(USER_DIR_FOLDER
						+ "/outputtexttest.txt");
				int outpTextLeng = (int) outpTextFile.length();
				Assert.assertEquals(outpTextLeng, inpuTextLeng);

				logger.info("\nBlob" + ":" + "creating outputimagetest.jpg");
				try {
					Blob blobval = rs.getBlob(3);
					InputStream is = blobval.getBinaryStream();
					FileOutputStream fos = new FileOutputStream(USER_DIR_FOLDER
							+ "/outputimagetest.jpg");
					byte[] buf = new byte[102400];
					int len;
					while ((len = is.read(buf)) != -1) {
						fos.write(buf, 0, len);
					}
					fos.close();
					is.close();
				} catch (SQLException e) {
					e.printStackTrace();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				logger.info("Blob" + ":" + "created outputimagetest.jpg");
				File inpuStreFile = new File(this.getClass().getResource("/inputimagetest.jpg").getPath());
				int inpuStreLeng = (int) inpuStreFile.length();
				File outpStreFile = new File(USER_DIR_FOLDER
						+ "/outputimagetest.jpg");
				int outpStreLeng = (int) outpStreFile.length();
				Assert.assertEquals(outpStreLeng, inpuStreLeng);

				byte[] itemBytes = rs.getBytes(4);
				ByteArrayInputStream bi = new ByteArrayInputStream(itemBytes);
				ObjectInputStream oi = new ObjectInputStream(bi);
				Object seriVal = oi.readObject();
				logger.info("var_serializable" + " : "
						+ ((Item) seriVal).getName());
				Assert.assertEquals(((Item) seriVal).getName(),
						"Updated Serialized Object");
			}
			logger.info("itemtbl_testlargeformat data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForDelete() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT "
				+ " var_tinyblob,var_longtext,var_longblob,var_serializable "
				+ " FROM itemtbl_testlargeformat";

		try {
			logger.info("begin to retrieve itemtbl_testlargeformat data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			int rowNum = rs.getRow();
			Assert.assertEquals(rowNum, 0);
			logger.info("itemtbl_testlargeformat data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForDrop() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = " select count(*) as table_num "
				+ " from information_schema.tables "
				+ " where table_name='itemtbl_testlargeformat' and table_schema='test'";

		try {
			logger.info("begin to retrieve user_table data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				int num = rs.getInt(1);
				Assert.assertEquals(num, 0);
			}
			logger.info("user_table data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
