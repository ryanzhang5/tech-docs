package com.wm.dal.jta;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.assertNotNull;

import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.sql.DataSource;

import org.jboss.shrinkwrap.api.ArchivePaths;
import org.jboss.shrinkwrap.api.Filters;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.StringAsset;
import org.jboss.shrinkwrap.api.exporter.ZipExporter;
import org.jboss.shrinkwrap.api.spec.EnterpriseArchive;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.jboss.shrinkwrap.descriptor.api.Descriptors;
import org.jboss.shrinkwrap.descriptor.api.spec.ee.application.ApplicationDescriptor;
import org.jboss.shrinkwrap.resolver.api.DependencyResolvers;
import org.jboss.shrinkwrap.resolver.api.maven.MavenDependencyResolver;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;

import com.wm.dal.jdbc.BaseJdbcTest;
import com.wm.dal.jta.support.ExtendedJdbcMySQLTemplate;
import com.wm.dal.jta.support.ExtendedJdbcOperations;
import com.wm.dal.jta.support.ExtendedJdbcOracleTemplate;
import com.wm.org.jboss.arquillian.testng.Arquillian;

@ContextConfiguration(locations = "test-jta-beans.xml")
public abstract class BaseTestCase extends Arquillian {
	protected static final String MYSQL_SCHEMA_NAME = "test";

	protected final Logger logger = Logger.getLogger(getClass().getName());

	@Resource(name = "dalpoolMysqlDS")
	protected DataSource pureDataSource1;
	@Resource(name = "dalpoolOracleDS")
	protected DataSource pureDataSource2;

	@Resource(name = "jdbcpoolMysqlDS")
	protected DataSource DS1;
	@Resource(name = "jdbcpoolOracleDS")
	protected DataSource DS2;

	@Resource(name = "txManager")
	protected PlatformTransactionManager txManager;

	ExtendedJdbcOperations pureTemplate1;
	ExtendedJdbcOperations pureTemplate2;

	static {
		try {
			BaseJdbcTest.load(BaseTestCase.class, "/system.properties");
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
	}

	@PostConstruct
	private void doInit() {
		pureTemplate1 = new ExtendedJdbcMySQLTemplate(pureDataSource1, MYSQL_SCHEMA_NAME);
		pureTemplate2 = new ExtendedJdbcOracleTemplate(pureDataSource2);
	}

	protected String getTableName() {
		throw new UnsupportedOperationException();
	}

	protected void 
	finalize(boolean commit, TransactionStatus status, Object... objects) 
			throws SQLException 
			{
		boolean success = false;
		try {
			if (commit)
				txManager.commit(status);
			else
				txManager.rollback(status);
			success = true;
		} finally {
			close(success, objects);
		}
			}

	protected boolean 
	close(boolean rethrow, Object... objects)
			throws SQLException 
			{
		try {
			close(objects);
		} catch (SQLException e) {
			if (rethrow)
				throw e;
			return false;
		}
		return true;
			}

	protected void close(Object... objects) throws SQLException {
		SQLException exception = null;
		for (Object ooo : objects) {
			if (ooo == null)
				;
			else if (ooo instanceof Connection) {
				try {
					((Connection) ooo).close();
				} catch (SQLException e) {
					if (exception == null)
						exception = e;
				}
			} else if (ooo instanceof Statement) {
				try {
					((Statement) ooo).close();
				} catch (SQLException e) {
					if (exception == null)
						exception = e;
				}
			} else if (ooo instanceof ResultSet) {
				try {
					((ResultSet) ooo).close();
				} catch (SQLException e) {
					if (exception == null)
						exception = e;
				}
			} else
				throw new UnsupportedOperationException("Unsupported Type: "
						+ ooo.getClass().getName());
		}

		if (exception != null)
			throw exception;
	}

	@Deprecated
	protected void safeClose(Connection con) {
		try {
			if (con != null) {
				con.close();
			}
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	protected void
	compare(ResultSet rs1, ResultSet rs2) throws SQLException
	{
	  assertNotNull(rs1);
	  assertNotNull(rs2);
	  
	  while (rs1.next())
	  {
	    assertTrue(rs2.next());
	    assertEquals(rs1.getMetaData().getColumnCount(), rs2.getMetaData().getColumnCount());
	    for (int nn = 1 ; nn <= rs1.getMetaData().getColumnCount() ; nn++)
	      assertEquals(rs1.getObject(nn), rs2.getObject(nn));
	  }
	  
	  assertFalse(rs2.next());
	}
	
	protected void testQueryForSuccessInsertMysql() throws SQLException {
		assertEquals(pureTemplate1.count(getTableName()), 1);
	}

	protected void testQueryForSuccessInsertOracle() throws SQLException {
		assertEquals(pureTemplate2.count(getTableName()), 1);
	}

	protected void testQueryForFailureInsertMysql() throws SQLException {
		assertEquals(pureTemplate1.count(getTableName()), 0);
	}

	protected void testQueryForFailureInsertOracle() throws SQLException {
		assertEquals(pureTemplate2.count(getTableName()), 0);
	}

	protected void testQueryForDeleteMysql() throws SQLException {
		assertEquals(pureTemplate1.count(getTableName()), 0);
	}

	protected void testQueryForDeleteOracle() throws SQLException {
		assertEquals(pureTemplate2.count(getTableName()), 0);
	}

	protected void testQueryForCreateMysql() throws SQLException {
		assertTrue(pureTemplate1.tableExists(getTableName()));
	}

	protected void testQueryForCreateOracle() throws SQLException {
		assertTrue(pureTemplate2.tableExists(getTableName()));
	}

	protected void testQueryForDropMysql() throws SQLException {
		assertFalse(pureTemplate1.tableExists(getTableName()));
	}

	protected void testQueryForDropOracle() throws SQLException {
		assertFalse(pureTemplate2.tableExists(getTableName()));
	}

	public static EnterpriseArchive createDeployment() throws Exception {
	 String applicationXml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><application/>";
	  
	 ApplicationDescriptor application = Descriptors.
	     importAs(ApplicationDescriptor.class)
	     .from(applicationXml)
	     .ejbModule("test.jar")
	     ;

		JavaArchive test;

		EnterpriseArchive ear = ShrinkWrap
				.create(EnterpriseArchive.class, "test.ear")
				.addAsModule(
						test = ShrinkWrap
						.create(JavaArchive.class, "test.jar")
						.addPackages(true, "com.wm.dal")
						.merge(ShrinkWrap.create(JavaArchive.class)
								.addAsResource(
										new File("src/test/resources"),
										"/"),
										Filters.exclude(".*/\\.svn.*")))
										.addAsLibraries(
												DependencyResolvers
												.use(MavenDependencyResolver.class)
												.goOffline()
												.loadMetadataFromPom("pom.xml")
												.artifact("org.springframework:spring")
												.artifact("mysql:mysql-connector-java")
												.artifact("walmart-platform:com.wm.sql")
													.exclusion("ant:*")
													.exclusion("org.apache.ant:*")
													.exclusion("org.jboss.jbossts:*")
												.artifact("org.jboss.netty:netty")
												.artifact("walmart-thirdparty.oracle:ojdbc6")
												.artifact("walmart-platform:com.wm.org.jboss.arquillian")
												.artifact("org.springframework:spring-test")
												.resolveAs(JavaArchive.class))
												.setApplicationXML(new StringAsset(application.exportAsString()));

		test.delete(ArchivePaths.create("test-context.xml"));
		test.delete(ArchivePaths.create("system.properties"));
		
		test.delete(ArchivePaths.create("META-INF/persistence.xml"));

		test.addAsResource(new File("src/test/resources/test-context-server.xml"), 
				ArchivePaths.create("test-context.xml"));
		
		test.addAsResource(new File("src/test/resources/system.server.properties"), 
				ArchivePaths.create("system.properties"));

		if (System.getProperty("export.ear") != null)
			ear.as(ZipExporter.class).exportTo(new File(System.getProperty("export.ear")), true);

		return ear;
	}
}
