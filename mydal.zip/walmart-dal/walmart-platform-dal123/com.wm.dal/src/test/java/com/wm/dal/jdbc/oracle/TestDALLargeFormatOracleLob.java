package com.wm.dal.jdbc.oracle;

import java.io.File;
import java.io.InputStream;
import java.io.StringReader;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.wm.dal.jdbc.DALBlob;
import com.wm.dal.jdbc.DALClob;

/**
 * Copyright 2009 walmart.com. All rights reserved
 */

/**
 * @author Martin Ma
 * @since 2009-5-5
 * @version 1.0 Test JDBC Large Format on oracle with DALConnection
 */
//@Test(sequential=true)
public class TestDALLargeFormatOracleLob extends BaseOracleTest {

	@Test(groups = { "oracle", "create" })
	public void testCreate() {

		Connection con = null;
		Statement stmt = null;

		String creaTablSql = "CREATE TABLE itemtbl_dallargeformatlob ("
				+ "var_longtext CLOB default NULL,"
				+ "var_longblob BLOB default NULL,"
				+ "var_charstrm CLOB"
				+ ")";
		try {
			logger.info("begin to create itemtbl_dallargeformatlob table.");
			con = pureDataSource.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate(creaTablSql);
			logger.info("itemtbl_dallargeformatlob table is created.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForCreate();
	}

	@Test(dependsOnMethods = "testCreate", groups = { "oracle", "insert" })
	public void testInsert() {

		Connection con = null;
		PreparedStatement pstm = null;

		String insrSql = "INSERT INTO itemtbl_dallargeformatlob"
				+ "(" 
				+ "var_longtext,"
				+ "var_longblob," 
				+ "var_charstrm" 
				+ ") " 
				+ " VALUES (?,?,?)";

		try {
			logger.info("begin to insert itemtbl_dallargeformatdal data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(insrSql);

			File inpuTextFile = new File(TestDALLargeFormatOracle.class
					.getResource("/inputtexttest.txt").getPath());
			int inpuTextLeng = (int) inpuTextFile.length();
			InputStream inpuTextStrm = TestDALLargeFormatOracle.class
					.getResourceAsStream("/inputtexttest.txt");
//			Clob orclClob = new DALClob("Hello World");
			byte[] buffer1 = new byte[inpuTextLeng];
			inpuTextStrm.read(buffer1);
			Clob orclClob = new DALClob(buffer1);
			inpuTextStrm.close();
			pstm.setClob(1, orclClob);

			File inpuImagFile = new File(TestDALLargeFormatOracle.class
					.getResource("/inputimagetest.jpg").getPath());
			int inpuImagLeng = (int) inpuImagFile.length();
			InputStream inpuImagStrm = TestDALLargeFormatOracle.class
					.getResourceAsStream("/inputimagetest.jpg");
//			Blob orclBlob = new DALBlob("Hello World".getBytes());
			byte[] buffer2 = new byte[inpuImagLeng];
			inpuImagStrm.read(buffer2);
			Blob orclBlob = new DALBlob(buffer2);
			inpuImagStrm.close();
			pstm.setBlob(2, orclBlob);
			
			String sample = "Hello World";
			StringReader inpuRead = new StringReader(sample);
			pstm.setCharacterStream(3, inpuRead, sample.length());

			pstm.executeUpdate();
			con.commit();

			logger.info("itemtbl_dallargeformatlob data are inserted.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		 //TODO: FixMe testQueryForInsert();
	}

	@Test(dependsOnMethods = "testInsert", groups = { "oracle", "update" })
	public void testUpdate() {

		Connection con = null;
		PreparedStatement pstm = null;

		String updtSql = "UPDATE itemtbl_dallargeformatlob "
				+ " SET var_longtext=?,var_longblob=?,var_charstrm=?";
//				+ " SET var_charstrm=?";

		try {
			logger.info("begin to update itemtbl_dallargeformatlob data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(updtSql);

			Clob orclClob = new DALClob("Hello World");
			pstm.setClob(1, orclClob);

			Blob orclBlob = new DALBlob("Hello World".getBytes());
			pstm.setBlob(2, orclBlob);
			
			String sample = "Hello World";
			StringReader inpuRead = new StringReader(sample);
			pstm.setCharacterStream(3, inpuRead, sample.length());

			pstm.executeUpdate();
			con.commit();

			logger.info("itemtbl_dallargeformatlob data are updated.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		 testQueryForUpdate();
	}

	@Test(dependsOnMethods = "testUpdate", groups = { "oracle", "delete" })
	public void testDelete() {

		Connection con = null;
		Statement stmt = null;

		String dropTablSql = "DELETE FROM itemtbl_dallargeformatlob";
		try {
			logger.info("begin to delete itemtbl_dallargeformatlob data.");
			con = dataSource.getConnection();
			stmt = con.createStatement();
			stmt.execute(dropTablSql);
			con.commit();
			logger.info("data of itemtbl_dallargeformatlob table is deleted.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForDelete();
	}

	@Test(dependsOnMethods = "testDelete", groups = { "oracle", "drop" })
	public void testDrop() {

		Statement stmt = null;
		Connection con = null;
		String dropTablSql = "DROP TABLE itemtbl_dallargeformatlob";
		try {
			logger.info("begin to drop itemtbl_dallargeformatlob table.");
			con = pureDataSource.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate(dropTablSql);
			logger.info("itemtbl_dallargeformatlob table is dropped.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForDrop();
	}

	public void testQueryForCreate() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT count(*) as table_num FROM user_tables WHERE lower(table_name)='itemtbl_dallargeformatlob'";

		try {
			logger.info("begin to retrieve user_table data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				// int num = rs.getInt("table_num");
				int num = rs.getInt(1);
				Assert.assertEquals(num, 1);
			}
			logger.info("user_table data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForInsert() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " 
				+ " var_longtext,var_longblob, "
			    + " var_charstrm"
				+ " FROM itemtbl_dallargeformatlob";

		try {
			logger.info("begin to retrieve itemtbl_dallargeformatlob data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			while (rs.next()) {

				Clob textval = rs.getClob(1);
				byte[] buff1 = new byte[(int) textval.length()];
				textval.getAsciiStream().read(buff1);
				
				File inpuTextFile = new File(TestDALLargeFormatOracle.class
						.getResource("/inputtexttest.txt").getPath());
				int inpuTextLeng = (int) inpuTextFile.length();
				InputStream inpuTextStrm = TestDALLargeFormatOracle.class
						.getResourceAsStream("/inputtexttest.txt");
//				Clob orclClob = new DALClob("Hello World");
				byte[] buffer1 = new byte[inpuTextLeng];
				inpuTextStrm.read(buffer1);
				
				Assert.assertEquals(buff1, buffer1);
				inpuTextStrm.close();
//				String sourceClob = new String(buff1);
//				Assert.assertEquals(sourceClob, "Hello World");

				Blob blobval = rs.getBlob(2);
				byte[] buff2 = new byte[(int) blobval.length()];
				blobval.getBinaryStream().read(buff2);
				
				File inpuImagFile = new File(TestDALLargeFormatOracle.class
						.getResource("/inputimagetest.jpg").getPath());
				int inpuImagLeng = (int) inpuImagFile.length();
				InputStream inpuImagStrm = TestDALLargeFormatOracle.class
						.getResourceAsStream("/inputimagetest.jpg");
//				Blob orclBlob = new DALBlob("Hello World".getBytes());
				byte[] buffer2 = new byte[inpuImagLeng];
				inpuImagStrm.read(buffer2);
				
				Assert.assertEquals(buff2, buffer2);
				inpuImagStrm.close();
//				String sourceBlob = new String(buff2);
//				Assert.assertEquals(sourceBlob, "Hello World");
				
				String sample = "Hello World";
				Clob clobval = rs.getClob(3);
				char[] clobBuff = new char[sample.length()];
				clobval.getCharacterStream().read(clobBuff);
				String clobStr = new String(clobBuff);
				Assert.assertEquals(clobStr, "Hello World");

			}
			logger
					.info("itemtbl_dallargeformatlob data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForUpdate() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " 
				+ " var_longtext,var_longblob, "
			    + " var_charstrm"
				+ " FROM itemtbl_dallargeformatlob";

		try {
			logger.info("begin to retrieve itemtbl_dallargeformatlob data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			while (rs.next()) {
				
				Clob textval = rs.getClob(1);
				byte[] buff1 = new byte[(int) textval.length()];
				textval.getAsciiStream().read(buff1);
				String sourceClob = new String(buff1);
				Assert.assertEquals(sourceClob, "Hello World");

				Blob blobval = rs.getBlob(2);
				byte[] buff2 = new byte[(int) blobval.length()];
				blobval.getBinaryStream().read(buff2);
				String sourceBlob = new String(buff2);
				Assert.assertEquals(sourceBlob, "Hello World");
				
				String sample = "Hello World";
				Clob clobval = rs.getClob(3);
				char[] clobBuff = new char[sample.length()];
				clobval.getCharacterStream().read(clobBuff);
				String clobStr = new String(clobBuff);
				Assert.assertEquals(clobStr, "Hello World");

			}
			logger
					.info("itemtbl_dallargeformatlob data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForDelete() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT * "
				+ " FROM itemtbl_dallargeformatlob";

		try {
			logger.info("begin to retrieve itemtbl_dallargeformatlob data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			while (rs.next()) {
				int rowNum = rs.getRow();
				Assert.assertEquals(rowNum, 0);
			}
			logger
					.info("itemtbl_dallargeformatlob data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForDrop() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT count(*) as table_num FROM user_tables WHERE lower(table_name)='itemtbl_dallargeformatlob'";

		try {
			logger.info("begin to retrieve user_table data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				// int num = rs.getInt("table_num");
				int num = rs.getInt(1);
				Assert.assertEquals(num, 0);
			}
			logger.info("user_table data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
