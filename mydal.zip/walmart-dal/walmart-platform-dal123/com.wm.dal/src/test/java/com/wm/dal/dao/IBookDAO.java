package com.wm.dal.dao;

public interface IBookDAO extends IBaseDAO<Book, Integer> {
}
