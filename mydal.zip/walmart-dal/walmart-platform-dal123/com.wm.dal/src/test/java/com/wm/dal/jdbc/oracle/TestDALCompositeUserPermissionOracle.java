package com.wm.dal.jdbc.oracle;

import java.io.Serializable;
import java.sql.Array;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.wm.dal.jdbc.DALArrayDescriptor;
import com.wm.dal.jdbc.DALFactory;

/**
 * Copyright 2009 walmart.com. All rights reserved
 */

/**
 * @author Martin Ma
 * @since 2009-5-5
 * @version 1.0 Test JDBC Large Format on oracle with DALConnection
 */
// @Test(sequential = true)
public class TestDALCompositeUserPermissionOracle extends BaseOracleTest {

	@Test(groups = { "oracle", "insert" })
	public void testAddUser() {

		/*
		 * Suppose we have made CREATE OR REPLACE TYPE ITEMTBL_REC AS
		 * OBJECT(TEST_ELEM_NAME VARCHAR2(50), TEST_ELEM_VALUE NUMBER(10,2),
		 * TEST_ELEM_DATE DATE); CREATE OR REPLACE TYPE ITEMTBL_TAB AS TABLE OF
		 * ITEMTBL_REC; CREATE OR REPLACE PROCEDURE
		 * ITEMTBL_DEPTH_PROC(ITEMTBL_NUMB OUT NUMBER, ITEMTBL_DATA OUT
		 * ITEMTBL_TAB) IS v_ctr NUMBER := 0 ; BEGIN itemtbl_data :=
		 * itemtbl_tab(); for off_rec in (select
		 * TEST_ELEM_NAME,TEST_ELEM_VALUE,TEST_ELEM_DATE from ITEMTBL_DATA) loop
		 * v_ctr := v_ctr + 1; itemtbl_data.EXTEND; itemtbl_data(v_ctr) :=
		 * ITEMTBL_REC
		 * (off_rec.TEST_ELEM_NAME,off_rec.TEST_ELEM_VALUE,off_rec.TEST_ELEM_DATE
		 * ); end loop; itemtbl_numb := v_ctr; END ITEMTBL_DEPTH_PROC;
		 */

//		Connection pureConn = null;
//		Statement pureStmt = null;

		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = dataSource.getConnection();
			stmt = conn.prepareCall(AddUserSQL.call);
			
			stmt.setString(AddUserSQL.colLoginEmail, "test@walmart.com");
            stmt.setString(AddUserSQL.colPassword, "pass");
            stmt.setString(AddUserSQL.colFirstName, "f");
            stmt.setString(AddUserSQL.colLastName, "l");
            stmt.setString(AddUserSQL.colJobTitle, "j");
            stmt.setString(AddUserSQL.colPhoneNumber, "123");
            stmt.setString(AddUserSQL.colPhoneExtn, "123");
            stmt.setLong(AddUserSQL.colPartnerId, Long.valueOf(100));

//            String isActive = user.isActive() ? "Y" : "N";
            stmt.setString(AddUserSQL.colIsActive, "Y");

            stmt.setLong(AddUserSQL.colCreatedBy, Long.valueOf(100));
            stmt.setInt(AddUserSQL.colApplicationId,100);
            stmt.setString(AddUserSQL.colHasOtherPartnerAccess, "a");

            Long walmartPartnerId = Long.valueOf(100);
            Map<String, String> walmartPermissions = new HashMap<String, String>();
            walmartPermissions.put("MANAGE_USERS", "VIEW");
            walmartPermissions.put("SITE_CONTENT", "VIEW");
            walmartPermissions.put("FULFILLMENT_MESSAGES", "VIEW");
            walmartPermissions.put("ORDERS_OPEN_LINE_ITEMS", "VIEW");
            walmartPermissions.put("MESSAGE_ALERT_EMAIL", "VIEW");
            walmartPermissions.put("MARKETPLACE_ACCOUNT", "VIEW");
            walmartPermissions.put("REVIEWS_AND_RATINGS", "VIEW");
            walmartPermissions.put("TAX_SETTINGS", "VIEW");
            walmartPermissions.put("SERVICE_SETTINGS", "VIEW");
            walmartPermissions.put("FULFILLMENT_SETTINGS", "VIEW");
            
            String[] partnerIds = {"100","200","300"};
            
            Map<String, String> partnerPermissions = new HashMap<String, String>();
            partnerPermissions.put("MANAGE_USERS", "VIEW");
            partnerPermissions.put("SITE_CONTENT", "VIEW");
            partnerPermissions.put("FULFILLMENT_MESSAGES", "VIEW");
            partnerPermissions.put("ORDERS_OPEN_LINE_ITEMS", "VIEW");
            partnerPermissions.put("MESSAGE_ALERT_EMAIL", "VIEW");
            partnerPermissions.put("MARKETPLACE_ACCOUNT", "VIEW");
            partnerPermissions.put("REVIEWS_AND_RATINGS", "VIEW");
            partnerPermissions.put("TAX_SETTINGS", "VIEW");
            partnerPermissions.put("SERVICE_SETTINGS", "VIEW");
            partnerPermissions.put("FULFILLMENT_SETTINGS", "VIEW");
            
            savePermissions(conn,stmt,AddUserSQL.colPartnerPermissionTab,walmartPartnerId,walmartPermissions,partnerIds,partnerPermissions);

            stmt.registerOutParameter(AddUserSQL.colUserId_OUT, Types.INTEGER);
            stmt.registerOutParameter(AddUserSQL.colResultCode_OUT, Types.INTEGER);

            stmt.execute();

            long userId = stmt.getLong(AddUserSQL.colUserId_OUT);
            System.out.println("++++++++++++++++++++++" + userId);
            int resultCode = stmt.getInt(AddUserSQL.colResultCode_OUT);
            System.out.println("++++++++++++++++++++++" + resultCode);
                        
			Assert.assertTrue(resultCode > 0);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {

			try {

//				if (pureStmt != null) {
//					pureStmt.close();
//				}
//				if (pureConn != null) {
//					pureConn.close();
//				}
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public void savePermissions(Connection conn, CallableStatement stmt,
			int api, Long walmartPartnerId, Map<String, String> wmPermissions,
			String[] partnerIds, Map<String, String> prPermissions) {

		// create walmart arrays
		List walmartPartners = new ArrayList<PartnerRecord>();
		walmartPartners.add(new PartnerRecord(walmartPartnerId));
		PartnerRecord[] walmartPartnersArr = (PartnerRecord[]) walmartPartners
				.toArray(new PartnerRecord[0]);

		List walmartPermissions = buildPermissionHelper(wmPermissions);
		PermissionRecord[] walmartPermissionArr = (PermissionRecord[]) walmartPermissions
				.toArray(new PermissionRecord[0]);

		// create partner arrays
		List partners = new ArrayList<PartnerRecord>();

		for (String sPartnerId : partnerIds) {
			Long partnerId = Long.valueOf(sPartnerId);
			partners.add(new PartnerRecord(partnerId));
		}
		PartnerRecord[] partnersArr = (PartnerRecord[]) partners
				.toArray(new PartnerRecord[0]);

		List partnerPermissions = buildPermissionHelper(prPermissions);
		PermissionRecord[] partnerPermissionArr = (PermissionRecord[]) partnerPermissions
				.toArray(new PermissionRecord[0]);

		saveUserPermissions(conn, stmt, api, walmartPartnersArr,
				walmartPermissionArr, partnersArr, partnerPermissionArr);
	}

	private List<PermissionRecord> buildPermissionHelper(
			Map<String, String> selectedPermissions) {
		List<PermissionRecord> permissions = new ArrayList<PermissionRecord>();
		for (String permission : selectedPermissions.keySet()) {
			String depth = selectedPermissions.get(permission);
			String isReadOnly;
			if (depth.equals(PermissionDepth.READ.toString())) {
				isReadOnly = "Y";
			} else if (depth.equals(PermissionDepth.WRITE.toString())) {
				isReadOnly = "N";
			} else {
				continue;
			}
			permissions.add(new PermissionRecord(Permission.get(permission)
					.getId(), isReadOnly));
		}
		return permissions;
	}

	private void saveUserPermissions(Connection conn,
			CallableStatement stmt, int api, PartnerRecord[] walmartPartners,
			PermissionRecord[] walmartPermissions,
			PartnerRecord[] partnerPartners,
			PermissionRecord[] partnerPermissions) {

		try {
			
			DALArrayDescriptor descPrtn = DALArrayDescriptor.createDescriptor(PartnerRecord.ARRAY_TYPE, conn);
			DALArrayDescriptor descPerm = DALArrayDescriptor.createDescriptor(PermissionRecord.ARRAY_TYPE, conn);
			
			Array prtnWalmArry = DALFactory.newArray(descPrtn, Types.STRUCT, descPrtn.getDescriptorName(), walmartPartners);
			Array permWalmArry = DALFactory.newArray(descPerm, Types.STRUCT, descPerm.getDescriptorName(), walmartPermissions);
			MultiPartnerPermissions walmartPartnerPermissions = new MultiPartnerPermissions(prtnWalmArry, permWalmArry);
			
			Array prtnPrtnArry = DALFactory.newArray(descPrtn, Types.STRUCT, descPrtn.getDescriptorName(), partnerPartners);
			Array permPrtnArry = DALFactory.newArray(descPerm, Types.STRUCT, descPerm.getDescriptorName(), partnerPermissions);
			MultiPartnerPermissions partnerPartnerPermissions = new MultiPartnerPermissions(prtnPrtnArry, permPrtnArry);
			
            List<MultiPartnerPermissions> aList = new ArrayList<MultiPartnerPermissions>();
            if(walmartPermissions.length!=0){
                aList.add(walmartPartnerPermissions);
            }
            if(partnerPermissions.length!=0){
                aList.add(partnerPartnerPermissions);
            }
            MultiPartnerPermissions[] ppAr= aList.toArray(new MultiPartnerPermissions[0]);
            
            DALArrayDescriptor descMult = DALArrayDescriptor.createDescriptor(MultiPartnerPermissions.ARRAY_TYPE, conn);
            Array multPermPrtnArry = DALFactory.newArray(descMult, Types.STRUCT, descMult.getDescriptorName(), ppAr);
            
            stmt.setArray(api, multPermPrtnArry);
			
		}catch (Exception sqle) {
			logger.log(Level.SEVERE, "Caught exception saving permissions.",sqle);
//            throw new XRuntimeSQL(sqle);
		}

	}

	/**
	 * This API will be used to add a user and his permissions.
	 */
	private interface AddUserSQL {
		public static final String call = "{ call wcs_security2_pkg.AddUserAndPermission(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }";
		public static final int colLoginEmail = 1;
		public static final int colPassword = 2;
		public static final int colFirstName = 3;
		public static final int colLastName = 4;
		public static final int colJobTitle = 5;
		public static final int colPhoneNumber = 6;
		public static final int colPhoneExtn = 7;
		public static final int colPartnerId = 8;
		public static final int colIsActive = 9;
		public static final int colCreatedBy = 10;
		public static final int colApplicationId = 11;
		public static final int colHasOtherPartnerAccess = 12;
		public static final int colPartnerPermissionTab = 13; // wcs_partner_permission_typ
																// AS OBJECT
																// (wcs_partner_tab,
																// wcs_permission_tab)
		public static final int colUserId_OUT = 14;
		public static final int colResultCode_OUT = 15;
	}

	/**
	 * This API will be used to update a user and his permissions.
	 */
	private interface UpdateUserSQL {
		public static final String call = "{ call wcs_security2_pkg.UpdateUserAndPermission(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) }";
		public static final int colUserId = 1;
		public static final int colFirstName = 2;
		public static final int colLastName = 3;
		public static final int colJobTitle = 4;
		public static final int colPhoneNumber = 5;
		public static final int colPhoneExtn = 6;
		public static final int colIsActive = 7;
		public static final int colPasswordTemp = 8;
		public static final int colModifiedBy = 9;
		public static final int colPassword = 10;
		public static final int colLoginEmail = 11;
		public static final int colApplicationId = 12;
		public static final int colHasOtherPartnerAccess = 13;
		public static final int colPartnerPermissionTab = 14; // wcs_partner_permission_typ
																// AS OBJECT
																// (wcs_partner_tab,
																// wcs_permission_tab)
		public static final int colResult_OUT = 15;
	}
	
	// TYPE security.wcs_partner_permission_tab IS TABLE OF
	// security.wcs_partner_permission_typ
//	class MultiPartnerPermissions implements java.sql.SQLData {
//		private static final String SQL_TYPE = "SECURITY.WCS_PARTNER_PERMISSION_TYP";
//		private static final String ARRAY_TYPE = "SECURITY.WCS_PARTNER_PERMISSION_TAB";
//
//		private oracle.sql.ARRAY partners;
//		private oracle.sql.ARRAY permissions;
//
//		public MultiPartnerPermissions(oracle.sql.ARRAY partners,
//				oracle.sql.ARRAY permissions) {
//			this.partners = partners;
//			this.permissions = permissions;
//		}
//
//		public String getSQLTypeName() throws SQLException {
//			return SQL_TYPE;
//		}
//
//		public void readSQL(SQLInput stream, String typeName)
//				throws SQLException {
//			throw new RuntimeException(
//					"Not implemented because for now we don't need to read these.");
//		}
//
//		public void writeSQL(SQLOutput stream) throws SQLException {
//			stream.writeArray(partners);
//			stream.writeArray(permissions);
//		}
//	}
	
	class MultiPartnerPermissions implements java.sql.SQLData {
		private static final String SQL_TYPE = "SECURITY.WCS_PARTNER_PERMISSION_TYP";
		private static final String ARRAY_TYPE = "SECURITY.WCS_PARTNER_PERMISSION_TAB";

		private Array partners;
		private Array permissions;

		public MultiPartnerPermissions(Array partners, Array permissions) {
			this.partners = partners;
			this.permissions = permissions;
		}

		public String getSQLTypeName() throws SQLException {
			return SQL_TYPE;
		}

		public void readSQL(SQLInput stream, String typeName)
				throws SQLException {
			throw new RuntimeException(
					"Not implemented because for now we don't need to read these.");
		}

		public void writeSQL(SQLOutput stream) throws SQLException {
			stream.writeArray(partners);
			stream.writeArray(permissions);
		}
	}

	// TYPE security.wcs_partner_tab AS TABLE OF security.wcs_partner_typ
	class PartnerRecord implements java.sql.SQLData {
		private static final String SQL_TYPE = "SECURITY.WCS_PARTNER_TYP";
		private static final String ARRAY_TYPE = "SECURITY.WCS_PARTNER_TAB";

		private long partnerId;

		public PartnerRecord(long partnerId) {
			this.partnerId = partnerId;
		}

		public String getSQLTypeName() throws SQLException {
			return SQL_TYPE;
		}

		public void readSQL(SQLInput stream, String typeName)
				throws SQLException {
			throw new RuntimeException(
					"Not implemented because for now we don't need to read these.");
		}

		public void writeSQL(SQLOutput stream) throws SQLException {
			stream.writeLong(partnerId);
		}
	}

	// TYPE security.wcs_permmission_tab AS TABLE OF security.wcs_permission_typ
	class PermissionRecord implements java.sql.SQLData {
		private static final String SQL_TYPE = "SECURITY.WCS_PERMISSION_TYP";
		private static final String ARRAY_TYPE = "SECURITY.WCS_PERMISSION_TAB";

		private long permissionId;
		private String isReadOnly;

		public PermissionRecord(long permissionId, String isReadOnly) {
			this.permissionId = permissionId;
			this.isReadOnly = isReadOnly;
		}

		public String getSQLTypeName() throws SQLException {
			return SQL_TYPE;
		}

		public void readSQL(SQLInput stream, String typeName)
				throws SQLException {
			throw new RuntimeException(
					"Not implemented because for now we don't need to read these.");
		}

		public void writeSQL(SQLOutput stream) throws SQLException {
			stream.writeLong(permissionId);
			stream.writeString(isReadOnly);
		}
	}
	
	public enum PermissionDepth implements Serializable {
	    READ("VIEW"),
	    WRITE("EDIT");
	    private String depthName;
	    PermissionDepth(String aDepth){
	        depthName = aDepth;
	    }

	    public String getNameStr(){
	        return depthName;
	    }
	    
	    public String toString(){
	        return depthName;
	    }
	}

	public enum Permission implements Serializable {
	    //settings
	    MANAGE_USERS("MANAGE_USERS",1),
	    SITE_CONTENT("SITE_CONTENT",2),
	    FULFILLMENT_MESSAGES("FULFILLMENT_MESSAGES",3),
	    ORDERS_OPEN_LINE_ITEMS("ORDERS_OPEN_LINE_ITEMS",5),
	    MESSAGE_ALERT_EMAIL("MESSAGE_ALERT_EMAIL",6),
	    ORDER_ALERT_EMAIL("ORDER_ALERT_EMAIL",7),
	    MARKETPLACE_ACCOUNT("MARKETPLACE_ACCOUNT",8),
	    REVIEWS_AND_RATINGS("REVIEWS_AND_RATINGS",9),
	    TAX_SETTINGS("TAX_SETTINGS",10),
	    SERVICE_SETTINGS("SERVICE_SETTINGS",11),
	    //ORDERS_CUSTOMER_SERVICE_ESCALATIONS("ORDERS_CUSTOMER_SERVICE_ESCALATIONS",12),
	    FULFILLMENT_SETTINGS("FULFILLMENT_SETTINGS",4);

	    //enum implementation
	    private String name;
	    private long id;

	    Permission(String name, long id) {
	        this.name = name;
	        this.id = id;
	    }

	    public static Permission get(String name) {
	        Permission aPermission = null;
	        for (Permission permission : Permission.values()) {
	            if (permission.getName().equalsIgnoreCase(name)){
	                aPermission = permission;
	            }
	        }
	        return aPermission;
	    }

	     public static Permission get(long id) {
	        Permission aPermission = null;
	        for (Permission permission : Permission.values()) {
	            if (permission.getId() == id){
	                aPermission = permission;
	            }
	        }
	        return aPermission;
	    }

	    public String getName() {
	        return name;
	    }

	    public String toString() {
	        return name;
	    }

	    public long getId() {
	        return id;
	    }

	    public void setId(long id) {
	        this.id = id;
	    }
	}
}
