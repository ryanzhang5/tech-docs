package com.wm.dal.common;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class LoggingProxy<T> implements InvocationHandler {
    private T delegate;
    private Class<T> intf;
    private Class[] outputs;

    protected LoggingProxy(T delegate, Class<T> intf, Class... outputs) {
        this.intf = intf;
        this.delegate = delegate;
        this.outputs = outputs; //(outputs != null) ?outputs :new Class[0];
        System.out.println("Created a proxy for: "+delegate.getClass().getSimpleName()+"[@"+delegate.hashCode()+"]");
    }

    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        Object ret = method.invoke(delegate, args);

        String str = intf.getSimpleName() + "[@" + delegate.hashCode() + "]";
        str += "." + method.getName() + "(";
        for (int i=0; args != null && i < args.length; i++) {
            if (i != 0) str += ",";
            str += args[i];
        }
        str += ") = " + ret;
        if (ret != null) str += "[@" + ret.hashCode() + "]";
        System.out.println(str);

        for (Class c : outputs) {
            if (c.isInstance(ret)) {
                ret = getProxy(ret, c, outputs);
                break;
            }
        }
        return ret;
    }

    public static <T> T getProxy(T delegate, Class<T> intf, Class... outputs) {
        return (T) Proxy.newProxyInstance(
                intf.getClassLoader(),
                new Class[] {intf},
                new LoggingProxy<T>(delegate, intf, outputs)
        );
    }
}
