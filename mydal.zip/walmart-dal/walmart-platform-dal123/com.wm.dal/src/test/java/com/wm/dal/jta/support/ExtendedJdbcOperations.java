package com.wm.dal.jta.support;

import java.sql.SQLException;

import org.springframework.jdbc.core.simple.SimpleJdbcOperations;

public interface ExtendedJdbcOperations extends SimpleJdbcOperations
{
    public boolean tableExists(String tableName) throws SQLException;
    public void    dropTableIfExists(String tableName) throws SQLException;
    public int count(String tableName) throws SQLException;
}

