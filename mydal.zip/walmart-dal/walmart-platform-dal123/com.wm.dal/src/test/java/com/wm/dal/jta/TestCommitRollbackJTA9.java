package com.wm.dal.jta;

import com.wm.dal.jdbc.DALConnection;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.sql.*;
import java.util.logging.Logger;

//@Test(sequential = true)
public class TestCommitRollbackJTA9 extends BaseTestCase {

	private Logger logger = Logger.getLogger(TestCommitRollbackJTA9.class
			.getName());

	private static String TABLE_NAME = "itemtbl_testcommitrollback9";

	@Test(groups = { "mysql", "create" })
	public void testCreate() {

		Connection con1 = null;
		Statement stmt1 = null;
		ResultSet rs1 = null;

		String dropTablSql = "DROP TABLE IF EXISTS " + TABLE_NAME;
		String creaTablSql = "CREATE TABLE " + TABLE_NAME + "("
				+ "var_string varchar(10) default NULL"
				+ ") ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		try {
			logger.info("begin to create itemtbl table.");
			con1 = pureDataSource1.getConnection();
			stmt1 = con1.createStatement();
			stmt1.execute(dropTablSql);
			stmt1.execute(creaTablSql);
			logger.info("itemtbl table is created.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt1 != null)
					stmt1.close();
				if (con1 != null)
					con1.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		testQueryForCreateMysql();
	}

	@Test(dependsOnMethods = "testCreate", groups = { "mysql", "insert" })
	public void testFailureInsert() {

		Connection con1 = null; // Mysql Connection
		PreparedStatement pstm1 = null; // Mysql Statement
		DefaultTransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = txManager.getTransaction(def);

		String mysqInsrSql = "INSERT INTO " + TABLE_NAME + " (var_string) "
				+ " VALUES " + " (?)";

		try {
			logger.info("begin to insert itemtbl data.");

			con1 = this.DS1.getConnection();
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~"
					+ (con1 instanceof DALConnection));
			
			pstm1 = con1.prepareStatement(mysqInsrSql);

			pstm1.setString(1, "HelloWorld!");
			pstm1.executeUpdate();

			txManager.commit(status);
			logger.info("itemtbl data are inserted.");
		} catch (Exception e) {
			e.printStackTrace();
			txManager.rollback(status);
		} finally {
			try {
				if (pstm1 != null)
					pstm1.close();
				this.safeClose(con1);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForFailureInsertMysql();
	}

	@Test(dependsOnMethods = "testFailureInsert", groups = { "mysql", "insert" })
	public void testSuccessInsert() {

		Connection con1 = null; // Mysql Connection
		PreparedStatement pstm1 = null; // Mysql Statement
		DefaultTransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = txManager.getTransaction(def);

		String mysqInsrSql = "INSERT INTO " + TABLE_NAME + " (var_string) "
				+ " VALUES " + " (?)";

		try {
			logger.info("begin to insert itemtbl data.");

			con1 = this.DS1.getConnection();

			pstm1 = con1.prepareStatement(mysqInsrSql);

			pstm1.setString(1, "HelloWorld");

			pstm1.executeUpdate();

			txManager.commit(status);

			logger.info("itemtbl data are inserted.");
		} catch (Exception e) {
			e.printStackTrace();
			txManager.rollback(status);
		} finally {
			try {
				if (pstm1 != null)
					pstm1.close();
				this.safeClose(con1);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		testQueryForSuccessInsertMysql();
	}

	@Test(dependsOnMethods = "testSuccessInsert", groups = { "mysql", "delete" })
	public void testDelete() {

		Connection con1 = null; // Mysql Connection
		Statement stmt1 = null; // Mysql Statement
		DefaultTransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = txManager.getTransaction(def);

		String dropTablSql = "DELETE FROM " + TABLE_NAME;
		try {
			logger.info("begin to delete itemtbl data.");
			con1 = this.DS1.getConnection();
			stmt1 = con1.createStatement();
			stmt1.execute(dropTablSql);
			
			txManager.commit(status);

			logger.info("data of itemtbl table is deleted.");

		} catch (Exception e) {
			e.printStackTrace();
			txManager.rollback(status);
		} finally {
			try {
				if (stmt1 != null)
					stmt1.close();
				this.safeClose(con1);
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		this.testQueryForDeleteMysql();
	}

	@Test(dependsOnMethods = "testDelete", groups = { "mysql", "drop" })
	public void testDrop() {

		Connection con1 = null; // Mysql Connection
		Statement stmt1 = null; // Mysql Statement
		String dropTablSqlMysql = "DROP TABLE " + TABLE_NAME;

		try {
			logger.info("begin to drop itemtbl table.");

			con1 = pureDataSource1.getConnection();
			stmt1 = con1.createStatement();
			stmt1.execute(dropTablSqlMysql);
			logger.info("itemtbl table is dropped.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt1 != null)
					stmt1.close();
				if (con1 != null)
					con1.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		testQueryForDropMysql();
	}

	public void testQueryForSuccessInsertMysql() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " count(*) " + " FROM " + TABLE_NAME;

		try {
			logger.info("begin to retrieve itemtbl data.");

			con = pureDataSource1.getConnection();

			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();

			int rowNum = 0;
			if (rs.next()) {
				rowNum = rs.getInt(1);
			}
			Assert.assertEquals(rowNum, 1);

			logger.info("itemtbl data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForFailureInsertMysql() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " count(*) " + " FROM " + TABLE_NAME;

		try {
			logger.info("begin to retrieve itemtbl data.");

			con = pureDataSource1.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();

			int rowNum = 0;
			if (rs.next()) {
				rowNum = rs.getInt(1);
			}
			Assert.assertEquals(rowNum, 0);

			logger.info("itemtbl data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForDeleteMysql() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " count(*) " + " FROM " + TABLE_NAME;

		try {
			logger.info("begin to retrieve itemtbl data.");

			con = pureDataSource1.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			int rowNum = 0;
			if (rs.next()) {
				rowNum = rs.getInt(1);
			}
			Assert.assertEquals(rowNum, 0);
			logger.info("itemtbl data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForCreateMysql() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = " select count(*) as table_num "
				+ " from information_schema.tables " + " where table_name='"
				+ TABLE_NAME + "' and table_schema='" + MYSQL_SCHEMA_NAME + "'";

		try {
			logger.info("begin to retrieve table existence data.");

			con = pureDataSource1.getConnection();
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~"
					+ (con instanceof DALConnection));
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				int num = rs.getInt(1);
				Assert.assertEquals(num, 1);
			}
			logger.info("table existence data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForDropMysql() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = " select count(*) as table_num "
				+ " from information_schema.tables " + " where table_name='"
				+ TABLE_NAME + "' and table_schema='" + MYSQL_SCHEMA_NAME + "'";

		try {
			logger.info("begin to retrieve table existence data.");

			con = pureDataSource1.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				int num = rs.getInt(1);
				Assert.assertEquals(num, 0);
			}
			logger.info("table existence data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestCommitRollbackJTA9 a = new TestCommitRollbackJTA9();
		a.testCreate();
		a.testFailureInsert();
		a.testSuccessInsert();
		a.testDelete();
	}

}
