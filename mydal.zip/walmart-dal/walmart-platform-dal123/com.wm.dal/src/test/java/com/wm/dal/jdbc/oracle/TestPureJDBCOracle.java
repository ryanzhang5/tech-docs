package com.wm.dal.jdbc.oracle;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Currency;
import java.util.Locale;
import java.util.TimeZone;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.wm.dal.jdbc.data.Item;

/**
 * Copyright 2009 walmart.com. All rights reserved
 */

/**
 * @author Martin Ma
 * @since 2009-4-13
 * @version 1.0 Test program used to test oracle jdbc driver.
 */
@Test(sequential=true)
public class TestPureJDBCOracle extends BaseOracleTest {

//	/**
//	 * @param args
//	 */
//	public static void main(String[] args) {
//
//		TestPureJDBCOracle tester = new TestPureJDBCOracle();
//		tester.initialize();
//		tester.testCleanup();
//		tester.testInsertAllTypeValues();
//		tester.testRetrieveAllTypeValues();
//		tester.testMetaData();
//		tester.testProcedure();
//		tester.tearDown();
//	}

	@BeforeClass(groups = { "oracle" })
	public void initialize() {

		System.out.println("Begin of initialize");
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;

		String seleTablSql = "select count(*) as numb from all_tables where table_name = 'ITEMTBL'";
		

		String creaTablSql = "CREATE TABLE itemtbl ("
				+ "var_bigint NUMBER(19) default NULL,"
				+ "var_tinyblob RAW(255)," + "var_bit NUMBER(1) default NULL,"
				+ "var_char CHAR(1) default NULL,"
				+ "var_date DATE default NULL,"
				+ "var_datetime DATE default NULL,"
				+ "var_time DATE default NULL,"
				+ "var_decimal NUMBER(19,2) default NULL,"
				+ "var_double FLOAT default NULL,"
				+ "var_float FLOAT default NULL,"
				+ "var_int NUMBER(10) default NULL,"
				+ "var_smallint NUMBER(5) default NULL," + "var_longtext CLOB,"
				+ "var_longblob BLOB," + "var_tinyint NUMBER(5) default NULL,"
				+ "var_varchar VARCHAR2(20) default NULL,"
				+ "var_calendartimestamp DATE default NULL,"
				+ "var_calendardate DATE default NULL,"
				+ "var_classvarchar VARCHAR2(255) default NULL,"
				+ "var_currency VARCHAR2(255) default NULL,"
				+ "var_locale VARCHAR2(255) default NULL,"
				+ "var_serializable RAW(1000) default NULL,"
				+ "var_timezone VARCHAR2(255) default NULL,"
				+ "var_truefalse CHAR(1) default NULL,"
				+ "var_yesno CHAR(1) default NULL" + ")";
		try {
			con = dataSource.getConnection();
			stmt = con.createStatement();
			int tablNumb = 0;
			rs = stmt.executeQuery(seleTablSql);
			while (rs.next()) {
				tablNumb = rs.getInt("numb");
			}
			// stmt.executeUpdate(dropTablSql);
			if (tablNumb == 0) {
				stmt.executeUpdate(creaTablSql);
				System.out.println("itemtbl table is created.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("End of initialize");

	}

	@Test(groups = { "oracle" })
	public void testCleanup() {

		System.out.println("Begin of cleanup.");
		Connection con = null;
		Statement stmt = null;

		String dropTablSql = "DELETE FROM itemtbl";
		try {
			con = dataSource.getConnection();
			stmt = con.createStatement();
			stmt.execute(dropTablSql);
			System.out.println("data of itemtbl table is cleaned.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		System.out.println("End of initialize");

	}

	@Test(dependsOnMethods = "testCleanup", groups = { "oracle" })
	public void testInsertAllTypeValues() {

		System.out.println("Begin of insert data.");
		Connection con = null;
		PreparedStatement pstm = null;

		String insrSql = "INSERT INTO itemtbl"
				+ "(var_bigint,var_tinyblob,var_bit,var_char,var_date,"
				+ "var_datetime,var_time,var_decimal,var_double,var_float,"
				+ "var_int,var_smallint,var_longtext,var_longblob,var_tinyint,"
				+ "var_varchar,var_calendartimestamp,var_calendardate,var_classvarchar,var_currency,"
				+ "var_locale,var_serializable,var_timezone,var_truefalse,var_yesno"
				+ ")" + " VALUES "
				+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

		try {
			con = dataSource.getConnection();
			pstm = con.prepareStatement(insrSql);
			pstm.setLong(1, Long.valueOf("9223372036854775807"));
			pstm.setBytes(2, new String("Hello World").getBytes());
			pstm.setBoolean(3, true);
			pstm.setString(4, "A");
			pstm.setDate(5, new java.sql.Date(System.currentTimeMillis()));
			pstm.setTimestamp(6, new java.sql.Timestamp(System
					.currentTimeMillis()));
			pstm.setTime(7, new java.sql.Time(System.currentTimeMillis()));
			pstm.setBigDecimal(8, new BigDecimal("9999999.99"));
			pstm.setDouble(9, 99999.3);
			pstm.setFloat(10, 12.3f);
			pstm.setInt(11, 2147483647);
			pstm.setShort(12, (short) 32767);

			// textval
			File inpuTextFile = new File(TestPureJDBCOracle.class.getResource(
					"/inputtexttest.txt").getPath());
			int inpuTextLeng = (int) inpuTextFile.length();
			InputStream inpuTextStrm = TestPureJDBCOracle.class
					.getResourceAsStream("/inputtexttest.txt");
			pstm.setAsciiStream(13, inpuTextStrm, inpuTextLeng);

			// blobval
			File inpuImagFile = new File(TestPureJDBCOracle.class.getResource(
					"/inputimagetest.jpg").getPath());
			int inpuImagLeng = (int) inpuImagFile.length();
			InputStream inpuImagStrm = TestPureJDBCOracle.class
					.getResourceAsStream("/inputimagetest.jpg");
			pstm.setBinaryStream(14, inpuImagStrm, inpuImagLeng);

			pstm.setByte(15, (byte) 127);
			pstm.setString(16, "Hello World!");

			pstm.setTimestamp(17, new java.sql.Timestamp(System
					.currentTimeMillis()));
			pstm.setDate(18, new java.sql.Date(System.currentTimeMillis()));
			pstm.setString(19, "Hello".getClass().toString());
			pstm.setString(20, Currency.getInstance(Locale.CHINA).toString());
			pstm.setString(21, Locale.CHINA.toString());

			try {
				Item item = new Item();
				item.setName("Serialized Object");
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				ObjectOutputStream oos = new ObjectOutputStream(bos);
				oos.writeObject(item);
				oos.flush();
				oos.close();
				bos.close();
				byte[] itemBytes = bos.toByteArray();
				pstm.setBytes(22, itemBytes);
			} catch (Exception e) {
				e.printStackTrace();
			}

			pstm.setString(23, getLimitedLengthString(TimeZone.getDefault()
					.toString(), 255));
			pstm.setBoolean(24, new Boolean(true));
			pstm.setBoolean(25, new Boolean(false));

			pstm.execute();

			con.commit();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		// // catch (IOException e) {
		// // e.printStackTrace();
		// }
		catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		System.out.println("End of insert data.");

	}

	@Test(dependsOnMethods = "testInsertAllTypeValues", groups = { "oracle" })
	public void testRetrieveAllTypeValues() {

		System.out.println("Begin of retrieve data.");
		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT "
				+ "var_bigint,var_tinyblob,var_bit,var_char,var_date,"
				+ "var_datetime,var_time,var_decimal,var_double,var_float,"
				+ "var_int,var_smallint,var_longtext,var_longblob,var_tinyint,"
				+ "var_varchar,var_calendartimestamp,var_calendardate,var_classvarchar,var_currency,"
				+ "var_locale,var_serializable,var_timezone,var_truefalse,var_yesno"
				+ " FROM itemtbl";

		try {
			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			while (rs.next()) {
				long bigintVal = rs.getLong("var_bigint");
				System.out.println("var_bigint" + " : " + bigintVal);

				byte[] tinyblobVal = rs.getBytes("var_tinyblob");
				System.out.println("var_tinyblob" + " : "
						+ new String(tinyblobVal));

				boolean bitVal = rs.getBoolean("var_bit");
				System.out.println("var_bit" + " : " + bitVal);

				String charVal = rs.getString("var_char");
				System.out.println("var_char" + " : " + charVal);

				java.sql.Date dateVal = rs.getDate("var_date");
				System.out.println("var_date" + " : " + dateVal);

				java.sql.Timestamp datetimeVal = rs
						.getTimestamp("var_datetime");
				System.out.println("var_datetime" + " : " + datetimeVal);

				java.sql.Time timeVal = rs.getTime("var_time");
				System.out.println("var_time" + " : " + timeVal);

				BigDecimal decimalVal = rs.getBigDecimal("var_decimal");
				System.out.println("var_decimal" + " : " + decimalVal);

				double doubleVal = rs.getDouble("var_double");
				System.out.println("var_double" + " : " + doubleVal);

				float floatVal = rs.getFloat("var_float");
				System.out.println("var_float" + " : " + floatVal);

				int intVal = rs.getInt("var_int");
				System.out.println("var_int" + " : " + intVal);

				short smallintVal = rs.getShort("var_smallint");
				System.out.println("var_smallint" + " : " + smallintVal);

				System.out.println("\nClob" + ":"
						+ "creating outputtexttest.txt");
				try {
					Clob textval = rs.getClob("var_longtext");
					InputStream is = textval.getAsciiStream();
					FileOutputStream fos = new FileOutputStream(
							"outputtexttest.txt");
					byte[] buf = new byte[102400];
					int len;
					while ((len = is.read(buf)) != -1) {
						fos.write(buf, 0, len);
					}
					fos.close();
					is.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				System.out.println("Clob" + ":" + "created outputtexttest.txt");

				System.out.println("\nBlob" + ":"
						+ "creating outputimagetest.jpg");
				try {
					Blob blobval = rs.getBlob("var_longblob");
					InputStream is = blobval.getBinaryStream();
					FileOutputStream fos = new FileOutputStream(
							"outputimagetest.jpg");
					byte[] buf = new byte[102400];
					int len;
					while ((len = is.read(buf)) != -1) {
						fos.write(buf, 0, len);
					}
					fos.close();
					is.close();
				} catch (SQLException e) {
					e.printStackTrace();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				System.out
						.println("Blob" + ":" + "created outputimagetest.jpg");

				byte tinyintVal = rs.getByte("var_tinyint");
				System.out.println("var_tinyint" + " : " + tinyintVal);

				String varcharVal = rs.getString("var_varchar");
				System.out.println("var_varchar" + " : " + varcharVal);

				java.sql.Timestamp calendarTimestampVal = rs
						.getTimestamp("var_calendartimestamp");
				System.out.println("var_calendartimestamp" + " : "
						+ calendarTimestampVal);

				java.sql.Date calendardateVal = rs.getDate("var_calendardate");
				System.out
						.println("var_calendardate" + " : " + calendardateVal);

				String classvarcharVal = rs.getString("var_classvarchar");
				System.out
						.println("var_classvarchar" + " : " + classvarcharVal);

				String currencyVal = rs.getString("var_currency");
				System.out.println("var_currency" + " : " + currencyVal);

				String localeVal = rs.getString("var_locale");
				System.out.println("var_locale" + " : " + localeVal);

				// ObjectInputStream itemObjStr = new ObjectInputStream(rs
				// .getBinaryStream("var_serializable"));
				// Object serializableVal = itemObjStr.readObject();
				// System.out.println("var_serializable" + " : "
				// + ((Item) serializableVal).getName());
				byte[] itemBytes = rs.getBytes("var_serializable");
				ByteArrayInputStream bi = new ByteArrayInputStream(itemBytes);
				ObjectInputStream oi = new ObjectInputStream(bi);
				Object seriVal = oi.readObject();
				System.out.println("var_serializable" + " : "
						+ ((Item) seriVal).getName());

				String timezoneVal = rs.getString("var_timezone");
				System.out.println("var_timezone" + " : " + timezoneVal);

				Boolean truefalseVal = rs.getBoolean("var_truefalse");
				System.out.println("var_truefalse" + " : " + truefalseVal);

				Boolean yesnoVal = rs.getBoolean("var_yesno");
				System.out.println("var_yesno" + " : " + yesnoVal);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		System.out.println("End of retrieve data.");

	}

	@Test(groups = { "oracle" })
	public void testMetaData() {

		Connection con = null;
		System.out.println("\nBegin of test meta data.");
		try {
			con = dataSource.getConnection();
			String jdbcDrivName = con.getMetaData().getDriverName();
			String jdbcDrivVers = con.getMetaData().getDriverVersion();
			String dbProdName = con.getMetaData().getDatabaseProductName();
			String dbProdVers = con.getMetaData().getDatabaseProductVersion();

			System.out.println("JDBC Driver Name: " + jdbcDrivName);
			System.out.println("JDBC Driver Version: " + jdbcDrivVers);
			System.out.println("Database Product Name:" + dbProdName);
			System.out.println("Database Product Version:" + dbProdVers);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("End of test meta data.");

	}

	/**
	 * this method is used to test driver stored procedure supporting functions
	 * via oracle database 1) has input parameter for procedure 2) has output
	 * parameter for procedure 3) may return multi-resultset
	 * 
	 * CREATE OR REPLACE Package pkg_test is Type myCur is REF CURSOR; Procedure
	 * proc_test(vinput IN INT, voutput OUT INT, curr_out_1 OUT myCur,
	 * curr_out_2 OUT myCur); End pkg_test;
	 * 
	 * CREATE OR REPLACE Package Body pkg_test is Procedure proc_test(vinput IN
	 * INT, voutput OUT INT, curr_out_1 OUT myCur, curr_out_2 OUT myCur) IS
	 * Begin voutput := 2 * vinput; if vinput = 1 then OPEN curr_out_1 FOR
	 * select vinput, 'only one result' from dual ; else OPEN curr_out_1 FOR
	 * select vinput, 'first result' from dual ; OPEN curr_out_2 FOR select
	 * vinput, vinput+1, 'second result' from dual ; end if; End proc_test; End
	 * pkg_test;
	 */
	@Test(groups = { "oracle" })
	public void testProcedure() {

		System.out.println("\nTesting procedure............................");
		Connection con = null;
		CallableStatement stmt = null;
		Statement pstm = null;
		ResultSet rs = null;

		String dropSPBody = "DROP Package Body  pkg_test";
		String dropSP = "DROP Package  pkg_test";

		String createSP = ""
				+ "     CREATE OR REPLACE Package pkg_test is                                                                  "
				+ "         Type myCur is REF CURSOR;                                                                          "
				+ "         Procedure proc_test(vinput IN INT, voutput OUT INT, curr_out_1 OUT myCur, curr_out_2 OUT myCur);   "
				+ "     End pkg_test;                                                                                          ";

		String createSPBody = ""
				+ "     CREATE OR REPLACE Package Body pkg_test is                                                             "
				+ "         Procedure proc_test(vinput IN INT, voutput OUT INT, curr_out_1 OUT myCur, curr_out_2 OUT myCur)    "
				+ "         IS                                                                                                 "
				+ "         Begin                                                                                              "
				+ "              voutput := 2 * vinput;                                                                        "
				+ "              if vinput = 1 then                                                                            "
				+ "                  OPEN curr_out_1 FOR select vinput,  'only one result' from dual ;                         "
				+ "              else                                                                                          "
				+ "                  OPEN curr_out_1 FOR select vinput,  'first result' from dual ;                            "
				+ "                  OPEN curr_out_2 FOR select vinput, vinput+1,  'second result' from dual ;                 "
				+ "              end if;                                                                                       "
				+ "         End proc_test;                                                                                     "
				+ "     End pkg_test;                                                                                          ";

		String callSP = "{ call pkg_test.proc_test(?,?,?,?) }";

		try {
			con = dataSource.getConnection();
			pstm = con.createStatement();
			pstm.executeUpdate(createSP);
			pstm.executeUpdate(createSPBody);
			System.out.println("procedure created");

			stmt = con.prepareCall(callSP);
			stmt.setInt(1, 100);
			stmt.registerOutParameter(2, java.sql.Types.INTEGER);
			stmt.registerOutParameter(3, OracleTypes.CURSOR);
			stmt.registerOutParameter(4, OracleTypes.CURSOR);

			boolean hadResults = stmt.execute();
			rs = (ResultSet) stmt.getObject(3);
			System.out.println("ResultSet:");
			while (rs.next()) {
				int columnCount = rs.getMetaData().getColumnCount();
				String oneRow = "[";
				for (int i = 0; i < columnCount; i++) {
					oneRow += rs.getString(i + 1) + " | ";
				}
				System.out.println(oneRow + "]");
			}

			rs = (ResultSet) stmt.getObject(4);
			System.out.println("ResultSet:");
			while (rs.next()) {
				int columnCount = rs.getMetaData().getColumnCount();
				String oneRow = "[";
				for (int i = 0; i < columnCount; i++) {
					oneRow += rs.getString(i + 1) + " | ";
				}
				System.out.println(oneRow + "]");
			}

			int outputValue = stmt.getInt(2);
			System.out.println("\nOutParameter [int]: " + outputValue);
			try {
				pstm.executeUpdate(dropSPBody);
				pstm.executeUpdate(dropSP);
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("No procedure found warning after calling");
			}

			con.commit();
			System.out
					.println("Finishing testing procedure........................");

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@AfterClass(groups = { "oracle" })
	public void tearDown() {

		System.out.println("\nBegin of drop table.");
		Statement stmt = null;
		Connection con = null;
		String dropTablSql = "DROP TABLE itemtbl";
		try {
			con = dataSource.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate(dropTablSql);
			System.out.println("itemtbl table is dropped.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("End of drop table.");

	}

	private String getLimitedLengthString(String source, int lengthLimit) {

		String target = null;
		target = source.length() > lengthLimit ? source.substring(0,
				lengthLimit) : source;
		return target;
	}
}
