package com.wm.dal.dao;

import org.springframework.orm.jpa.EntityManagerFactoryUtils;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import javax.persistence.EntityManagerFactory;

public class PublishingService {
    private IBookDAO bookDAO;
    private IAuthorDAO authorDAO;

    @Transactional
    public void deleteBookAndAuthor(int bookId, int authorId) {
        Book book = bookDAO.findById(bookId);
        if (book != null) bookDAO.delete(book);
        Author author = authorDAO.findById(authorId);
        if (author != null) authorDAO.delete(author);
    }

    @Transactional
    public void insertBookAndAuthor(int bookId, int authorId) {
        Book book = new Book(bookId, "book");
        bookDAO.insert(book);
        Author author = new Author(authorId, "author");
        authorDAO.insert(author);
    }

    @Transactional
    public Book getBook(int bookId) {
        return bookDAO.findById(bookId);
    }

    // TODO: need to provide convenience methods to access EntityManager and Connection

    public void testUpdate(PlatformTransactionManager txManager, EntityManagerFactory emf, int bookId) {
        TransactionStatus status = txManager.getTransaction(new DefaultTransactionDefinition());
        try {
            BookDAO dao = new BookDAO();
            dao.setEntityManager(EntityManagerFactoryUtils.getTransactionalEntityManager(emf));
            Book book = dao.findById(bookId);
            book.setName("updated");
            txManager.commit(status);
        } catch (RuntimeException ex) {
            txManager.rollback(status);
            throw ex;
        }
    }

    // GETTERS and SETTERS

    public void setBookDAO(IBookDAO bookDAO) {
        this.bookDAO = bookDAO;
    }

    public void setAuthorDAO(IAuthorDAO authorDAO) {
        this.authorDAO = authorDAO;
    }
}
