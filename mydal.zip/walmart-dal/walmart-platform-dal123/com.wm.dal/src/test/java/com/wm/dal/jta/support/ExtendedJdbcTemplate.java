package com.wm.dal.jta.support;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;

public abstract class ExtendedJdbcTemplate extends SimpleJdbcTemplate 
	implements ExtendedJdbcOperations
{

	public ExtendedJdbcTemplate(DataSource dataSource) {
		super(dataSource);
	}

	@Override
	public int count(String tableName) throws SQLException {
		return queryForInt("SELECT count(*) FROM " + tableName);
	}
}
