/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.rulesproviders;

import org.testng.annotations.Test;
import org.testng.Assert;
import com.wm.dal.router.plugins.default_.DefaultRouter;
import com.wm.dal.router.plugins.default_.IRoutingRulesProvider;
import com.wm.dal.jdbc.BaseJdbcTest;

import java.util.Collections;

/**
 * DBBasedRulesProviderTest
 *
 * @author mkishore
 * @since 1.1
 */
public class DBBasedRulesProviderTest {
    static {
        try {
            BaseJdbcTest.load(DBBasedRulesProviderTest.class, "/system.properties");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @Test
    public void testRefresh() {
        DBBasedRulesProvider provider = new DBBasedRulesProvider();
        provider.setConfigPools("dalpool_oracle");

        DefaultRouter router = new DefaultRouter();
        router.setName("HostBasedRouter");
        router.setRoutingRulesProviders(Collections.singletonList((IRoutingRulesProvider)provider));

        if (provider.needsRefresh()) {
            byte[] rules = provider.getRoutingRules();
            Assert.assertNotNull(rules);
            //System.out.println(new String(rules));
        }
    }
}
