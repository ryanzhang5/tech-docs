package com.wm.dal.dao;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.transaction.PlatformTransactionManager;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import javax.persistence.EntityManagerFactory;

import com.wm.dal.jdbc.BaseJdbcTest;

public class PublishingServiceTest {
    private static ApplicationContext applicationContext = null;

    private PublishingService svc;

    @BeforeClass
    public void initialize() {
        try {
            // load the system properties before spring-config - needed by dbpool
            BaseJdbcTest.load(PublishingServiceTest.class, "/system.properties");
            applicationContext = new ClassPathXmlApplicationContext("/com/wm/dal/dao/test-dao-beans.xml");
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        svc = (PublishingService) applicationContext.getBean("publishingService");
    }

    @Test
    public void testCleanup() {
        svc.deleteBookAndAuthor(1, 1);
    }

    @Test(dependsOnMethods = "testCleanup")
    public void testDualInserts() {
        try {
            svc.insertBookAndAuthor(1, 1);
            svc.insertBookAndAuthor(1, 1);
            Assert.fail("Should throw a PK violation");
        } catch (Exception e) {
            System.out.println("Errored out as expected: " + e.getMessage());
        } finally {
            testCleanup();
        }
    }

    @Test(dependsOnMethods = "testCleanup")
    public void testProgrammaticTxManagement() {
        PlatformTransactionManager txManager = (PlatformTransactionManager) applicationContext.getBean("txManager");
        EntityManagerFactory emf = (EntityManagerFactory) applicationContext.getBean("myEMF1");
        try {
            svc.insertBookAndAuthor(1, 1);
            svc.testUpdate(txManager, emf, 1);
            Book book = svc.getBook(1);
            Assert.assertEquals(book.getName(), "updated", "The name should have been updated");
        } catch (Exception e) {
            Assert.fail("Errored out", e);
        } finally {
            testCleanup();
        }
    }

}
