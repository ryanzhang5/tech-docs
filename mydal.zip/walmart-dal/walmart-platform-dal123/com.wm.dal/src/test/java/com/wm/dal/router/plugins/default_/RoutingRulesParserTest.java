/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_;

import org.testng.annotations.Test;
import org.testng.Assert;

import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;

/**
 * RoutingRulesParserTest
 *
 * @author mkishore
 * @since 1.0
 */
@Test
public class RoutingRulesParserTest {

    public void testParse() {
        try {
            RoutingRulesParser parser = new RoutingRulesParser();
            InputStream stream = parser.getClass().getResourceAsStream("routing-rules.xml");
            List<RoutingRule> routingRules = parser.parse(stream);
            Assert.assertEquals(routingRules.size(), 1);
            RoutingRule rule = routingRules.get(0);
            Assert.assertEquals(rule.getName(), "rule-1");
            Assert.assertNotNull(rule.getCondition());
            Assert.assertEquals(rule.getThenStatements().size(), 3);
            Assert.assertEquals(rule.getElseStatements().size(), 1);
        } catch (Exception e) {
            Assert.fail("Failed to parse the routing-rules.xml", e);
        }
    }
}
