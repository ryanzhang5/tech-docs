/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.jta;

import com.wm.dal.jdbc.BaseJdbcTest;
import com.wm.sql.DataAccess;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.sql.Connection;

/**
 * JtaTest - tests the integration of following frameworks:
 * <li> Spring
 * <li> JBoss JTA
 * <li> XAPool
 * <li> MySQL XA DataSource
 * <p/>
 * Assumes that you ran the following DDLs on a mysql database:
 * -- create user 'clm_user'@'%' identified by 'clm_user';
 * -- grant all privileges on *.* to 'clm_user'@'%' with grant option;
 * -- show databases;
 * -- create database test;
 * -- use test;
 * -- create table dal_xa (tx_nbr int(11), tx_value int(11)) engine=InnoDB;
 * <p/>
 * Do the same for on another database or user-schema
 *
 * Note: the routing rules are setup to send all SQL with "(2" to mysql
 *
 * @author mkishore
 * @since 2.0.1
 */
public class JtaTest extends BaseJdbcTest {
    // routing rules set it up to point to MySQL for SQL containing "(2"
    private static final String POOLNAME = "jdbcpool_oracle";

    static {
        try {
            // load the system properties before spring-config - needed by dbpool
            BaseJdbcTest.load(JtaTest.class, "/system.properties");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testCleanup() {
        Connection con = null;
        try {
            con = DataAccess.getInstance().getConnection(POOLNAME);
            execute(con, "delete from dal_xa");
            execute(con, "delete from dal_xa where (2 = 2)");
            con.commit();
        } catch (Exception e) {
            try {
                con.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
            Assert.fail("Unexpected error", e);
        } finally {
            log("Closing connection");
            safeClose(con);
        }

    }

    @Test(dependsOnMethods = "testCleanup")
    public void testSuccessfulTx() {
        Connection con = null;
        try {
            con = DataAccess.getInstance().getConnection(POOLNAME);
            execute(con, "insert into dal_xa values(10, 10)");
            execute(con, "insert into dal_xa values(20, 10)");
            execute(con, "insert into dal_xa values(11, 20)");
            execute(con, "insert into dal_xa values(21, 20)");
            con.commit();
        } catch (Exception e) {
            try {
                con.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
            Assert.fail("Unexpected error", e);
        } finally {
            log("Closing connection");
            safeClose(con);
        }

        try {
            con = DataAccess.getInstance().getConnection(POOLNAME);
            execute(con, "select * from dal_xa");
            Assert.assertEquals(toInt(execute(con, "select count(*) from dal_xa")), 2);
            con.commit();
        } catch (Exception e) {
            try {
                con.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
            Assert.fail("Unexpected error", e);
        } finally {
            log("Closing connection");
            safeClose(con);
        }
    }

    @Test(dependsOnMethods = "testSuccessfulTx")
    public void testRollbackTx() {
        Connection con = null;
        try {
            con = DataAccess.getInstance().getConnection(POOLNAME);
            execute(con, "insert into dal_xa values(12, 10)");
            execute(con, "insert into dal_xa values(22, 10)");
            execute(con, "insert into dal_xa values(13, 20)");
            execute(con, "insert into dal_xa values(23, 'a')");
            con.commit();
        } catch (Exception e) {
            try {
                con.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
            log("Errored out as expected: " + e.getMessage());
        } finally {
            log("Closing connection");
            safeClose(con);
        }

        try {
            con = DataAccess.getInstance().getConnection(POOLNAME);
            execute(con, "select * from dal_xa");
            Assert.assertEquals(toInt(execute(con, "select count(*) from dal_xa")), 2);
            con.commit();
        } catch (Exception e) {
            try {
                con.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
            Assert.fail("Unexpected error", e);
        } finally {
            log("Closing connection");
            safeClose(con);
        }
    }

}
