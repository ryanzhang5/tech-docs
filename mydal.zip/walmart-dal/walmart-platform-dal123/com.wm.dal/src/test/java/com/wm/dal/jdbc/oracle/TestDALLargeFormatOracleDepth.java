package com.wm.dal.jdbc.oracle;

import java.sql.Array;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Struct;
import java.sql.Types;
import java.util.Arrays;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.wm.dal.jdbc.DALArrayDescriptor;
import com.wm.dal.jdbc.DALFactory;
import com.wm.dal.jdbc.data.ItemElement;
import com.wm.dal.jdbc.data.MapSearchRecord;
import com.wm.dal.jdbc.sqldata.OfferElementName;
import com.wm.dal.jdbc.sqldata.QuickScreenOfferArrayData;

/**
 * Copyright 2009 walmart.com. All rights reserved
 */

/**
 * @author Martin Ma
 * @since 2009-5-5
 * @version 1.0 Test JDBC Large Format on oracle with DALConnection
 */
/**
 * Suppose we have CREATE TABLE ITEMTBL_DATA(TEST_ELEM_NAME VARCHAR2(50), TEST_ELEM_VALUE NUMBER(10,2), TEST_ELEM_DATE DATE);
 * And we have insert into itemtbl_data values('TestNameA',1.1,TO_DATE('2009-01-01','YYYY-MM-DD'));
 * 			   insert into itemtbl_data values('TestNameB',2.2,TO_DATE('2009-01-01','YYYY-MM-DD'));
 * 			   insert into itemtbl_data values('TestNameC',3.3,TO_DATE('2009-01-01','YYYY-MM-DD'));
 */
//@Test(sequential = true)
public class TestDALLargeFormatOracleDepth extends BaseOracleTest {

	private interface offerArrayConstants {
        public static final String offerTab = "CUSTOMER.T_INSTANT_CREDIT_OFFER_TAB";
    }
	
	private interface itemArrayConstants {
        public static final String itemTab = "WEB_USER.ITEMTBL_TAB";
        public static final String itemRec = "WEB_USER.ITEMTBL_REC";
    }

    private enum getOfferCall implements offerArrayConstants {
        colZero,
        colcustomerId,
        colIndicateViewed,
        colQuickScreenId,
        colQuickScreenStatus,
        colFinderFileNumber,
        colArrayOfferElements;
        public static final String call = "{call wcu_mohan(?,?,?,?,?,?)}";

    }
    
    private enum getItemCall implements itemArrayConstants {
        colZero,
        colNumber,
        colValues;
        public static final String call = "{call itemtbl_depth_proc(?,?)}";

    }
	
    public void getOffer(long customerId, boolean indicateViewed) {
        Connection conn = null;
        CallableStatement stmt = null;
        String DB_TRUE = "Y";
        String DB_FALSE = "N";

        try {
//            conn = DataAccess.getInstance().getConnection(POOL);
        	conn = dataSource.getConnection();
            stmt = conn.prepareCall(getOfferCall.call);

            stmt.setLong(getOfferCall.colcustomerId.ordinal(), customerId);
            stmt.setString(getOfferCall.colIndicateViewed.ordinal(), (indicateViewed) ? DB_TRUE : DB_FALSE);

            Connection oraConn = conn; //((PooledConnection) conn).getNativeConnection();
            DALArrayDescriptor descriptor = DALArrayDescriptor.createDescriptor(getOfferCall.offerTab, oraConn);
            //ArrayDescriptor descriptor = ArrayDescriptor.createDescriptor(getOfferCall.offerTab, oraConn);

            int noOfElements = OfferElementName.values().length;
            QuickScreenOfferArrayData[] offerElementObjects = new QuickScreenOfferArrayData[noOfElements];
            for (int i = 0; i < offerElementObjects.length; i++) {
                offerElementObjects[i] = new QuickScreenOfferArrayData();
            }
            Array offerElements = DALFactory.newArray(descriptor, Types.STRUCT, descriptor.getDescriptorName(), offerElementObjects);
            //Array offerElements = new ARRAY(descriptor, oraConn, offerElementObjects);

            stmt.registerOutParameter(getOfferCall.colQuickScreenId.ordinal(), Types.NUMERIC);
            stmt.registerOutParameter(getOfferCall.colQuickScreenStatus.ordinal(), Types.NUMERIC);
            stmt.registerOutParameter(getOfferCall.colFinderFileNumber.ordinal(), Types.VARCHAR);
            stmt.registerOutParameter(getOfferCall.colArrayOfferElements.ordinal(), Types.ARRAY, getOfferCall.offerTab);

            stmt.setArray(getOfferCall.colArrayOfferElements.ordinal(), offerElements);

            stmt.execute();

            stmt.getLong(getOfferCall.colQuickScreenId.ordinal());
            int qsOfferStatusCode = stmt.getInt(getOfferCall.colQuickScreenStatus.ordinal());

            stmt.getString(getOfferCall.colFinderFileNumber.ordinal());

            //This line may not be required because we have the handle to the array
            //offerElementObjects = (QuickScreenOfferArrayData[])stmt.getArray(getOfferCall.colArrayOfferElements.ordinal()).getArray();
            Array offerElementsArray = stmt.getArray(getOfferCall.colArrayOfferElements.ordinal());
            System.out.println("Array item " + offerElementsArray + ":");
            if (offerElementsArray != null) {
                java.util.HashMap<String,Class<?>> typeMap = new java.util.HashMap<String,Class<?>>();
                typeMap.put("CUSTOMER.T_INSTANT_CREDIT_OFFER_REC", QuickScreenOfferArrayData.class);
                Object[] oraArray = (Object[]) offerElementsArray.getArray(typeMap);
                for (Object oraArrayElement : oraArray) {
                    if (oraArrayElement instanceof Struct) {
                        Struct oraStruct = (Struct) oraArrayElement;
                        System.out.println("Value " + Arrays.asList(oraStruct.getAttributes()));
                    } else {
                        System.out.println("Value " + oraArrayElement);
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                stmt.close();
                conn.close();
            } catch (Exception exp) {
            System.currentTimeMillis();}
        }
    }
    
    @Test(groups = { "oracle", "insert" })
    public void testInsert() {
    	
    	/*
    	 * Suppose we have made
    	 * CREATE OR REPLACE TYPE ITEMTBL_REC AS OBJECT(TEST_ELEM_NAME VARCHAR2(50), TEST_ELEM_VALUE NUMBER(10,2), TEST_ELEM_DATE DATE);
		 * CREATE OR REPLACE TYPE ITEMTBL_TAB AS TABLE OF ITEMTBL_REC;
		 * CREATE OR REPLACE PROCEDURE ITEMTBL_DEPTH_PROC(ITEMTBL_NUMB OUT NUMBER, ITEMTBL_DATA OUT ITEMTBL_TAB) IS 
 		 *	v_ctr NUMBER := 0 ;
 		 *	BEGIN
   		 *	itemtbl_data := itemtbl_tab();
      	 *	for off_rec in (select TEST_ELEM_NAME,TEST_ELEM_VALUE,TEST_ELEM_DATE from ITEMTBL_DATA)
		 *	loop
    	 *		v_ctr := v_ctr + 1;
		 *		itemtbl_data.EXTEND;
		 *		itemtbl_data(v_ctr) := ITEMTBL_REC(off_rec.TEST_ELEM_NAME,off_rec.TEST_ELEM_VALUE,off_rec.TEST_ELEM_DATE);
		 *	end loop;
   		 *	itemtbl_numb := v_ctr;
		 *	END ITEMTBL_DEPTH_PROC;
    	 */
    	
    	Connection pureConn = null;
    	Statement smt = null;
    	
        Connection conn = null;
        CallableStatement stmt = null;
    	
    	try {   		
			conn = dataSource.getConnection();
			stmt = conn.prepareCall(getItemCall.call);
			DALArrayDescriptor descriptor = DALArrayDescriptor.createDescriptor(ItemElement.ARRAY_TYPE, conn);
			
			int noOfElements = 10;
            ItemElement[] itemElementObjects = new ItemElement[noOfElements];
            for (int i = 0; i < itemElementObjects.length; i++) {
                itemElementObjects[i] = new ItemElement();
            }
            Array itemElements = DALFactory.newArray(descriptor, Types.STRUCT, descriptor.getDescriptorName(), itemElementObjects);
            
            stmt.registerOutParameter(getItemCall.colNumber.ordinal(), Types.NUMERIC);
            stmt.registerOutParameter(getItemCall.colValues.ordinal(), Types.ARRAY, ItemElement.ARRAY_TYPE);
            stmt.setArray(2, itemElements);
            
            stmt.execute();
            int itemNumber = stmt.getInt(1);
            Assert.assertEquals(itemNumber, 3);
            
            Array itemElementsArray = stmt.getArray(2);
//            System.out.println("++++++++++++++ Array item " + itemElementsArray + ":");
            if (itemElementsArray != null) {
                java.util.HashMap<String,Class<?>> typeMap = new java.util.HashMap<String,Class<?>>();
                typeMap.put(ItemElement.SQL_TYPE, ItemElement.class);
                Object[] oraArray = (Object[]) itemElementsArray.getArray(typeMap);
//                for (Object oraArrayElement : oraArray) {
//                    if (oraArrayElement instanceof Struct) {
//                        Struct oraStruct = (Struct) oraArrayElement;
//                        System.out.println("Value " + Arrays.asList(oraStruct.getAttributes()));
//                    } else {
//                        System.out.println("Value " + oraArrayElement);
//                    }
//                }
                ItemElement structVal = (ItemElement)oraArray[0];
//                Object[] values = structVal.getAttributes();
//				String str = (String)values[0];
//				BigDecimal dec = (BigDecimal)values[1];
//				Date dat = new Date(((Timestamp)values[2]).getTime());
				Assert.assertEquals(structVal.getTestElemName(), "TestNameA");
				Assert.assertEquals(structVal.getTestElemValue(), 1.1);
				Assert.assertEquals(structVal.getTestElemDate(), Date.valueOf("2009-01-01"));
				
				structVal = (ItemElement)oraArray[1];
//				values = structVal.getAttributes();
//				str = (String)values[0];
//				dec = (BigDecimal)values[1];
//				dat = new Date(((Timestamp)values[2]).getTime());
				Assert.assertEquals(structVal.getTestElemName(), "TestNameB");
				Assert.assertEquals(structVal.getTestElemValue(), 2.2);
				Assert.assertEquals(structVal.getTestElemDate(), Date.valueOf("2009-02-02"));
				
				structVal = (ItemElement)oraArray[2];
//				values = structVal.getAttributes();
//				str = (String)values[0];
//				dec = (BigDecimal)values[1];
//				dat = new Date(((Timestamp)values[2]).getTime());
				Assert.assertEquals(structVal.getTestElemName(), "TestNameC");
				Assert.assertEquals(structVal.getTestElemValue(), 3.3);
				Assert.assertEquals(structVal.getTestElemDate(), Date.valueOf("2009-03-03"));
            }
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			
			try {
				
				if (smt != null) {
					smt.close();
				}
				if (pureConn != null) {
					pureConn.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
    	
    }

//    @Test(groups = { "oracle", "insert" })
    public void testGetStoreInfo() {
    	
        Connection conn = null;
        CallableStatement stmt = null;
        
        try {
        	conn = dataSource.getConnection();
			stmt = conn.prepareCall(MapRequestSearchSQL.call);
			DALArrayDescriptor descriptor = DALArrayDescriptor.createDescriptor(MapSearchRecord.ARRAY_TYPE, conn);
			int noOfElements = 10;
			MapSearchRecord[] itemElementObjects = new MapSearchRecord[noOfElements];
            for (int i = 0; i < itemElementObjects.length; i++) {
                itemElementObjects[i] = new MapSearchRecord();
            }
            Array storeArry = DALFactory.newArray(descriptor, Types.STRUCT, descriptor.getDescriptorName(), itemElementObjects);
			
            stmt.setLong(MapRequestSearchSQL.colSearchLatIn,Long.valueOf(363228));
            stmt.setLong(MapRequestSearchSQL.colSearchLongIn,Long.valueOf(-941838));
            stmt.setNull(MapRequestSearchSQL.colAtrributeListIn, Types.VARCHAR);
            stmt.setLong(MapRequestSearchSQL.colSearchRadiusIn, Long.valueOf(150));
            stmt.setLong(MapRequestSearchSQL.colMaxRecordsIn, Long.valueOf(1000000));
            stmt.setNull(MapRequestSearchSQL.colStoreTypeIn, Types.NUMERIC);       
            stmt.registerOutParameter(MapRequestSearchSQL.colStoreOut, Types.ARRAY, MapSearchRecord.ARRAY_TYPE);
            stmt.setArray(MapRequestSearchSQL.colStoreOut, storeArry);
            stmt.execute();
            
            Array stores = stmt.getArray(MapRequestSearchSQL.colStoreOut);
            System.out.println(stores == null);
	        if (stores != null) {
                java.util.HashMap<String,Class<?>> typeMap = new java.util.HashMap<String,Class<?>>();
                typeMap.put(MapSearchRecord.SQL_TYPE, MapSearchRecord.class);
                Object[] oraArray = (Object[]) stores.getArray(typeMap);
                System.out.println(oraArray.length);
                for (int i=0; i<oraArray.length; i++) {
                		MapSearchRecord searRecd = (MapSearchRecord)oraArray[i];
                		System.out.println("~~~~" + searRecd);
                }
	        }
            
        }catch (Exception ex) {
        	ex.printStackTrace();
        }
        
    }
    
//    @Test
    public void testGetOffers() {
        // grab customer id from jackhammer wcu_customer_quick_screen_t
        getOffer(1553262L, false);
    }
    
	private interface MapRequestSearchSQL {
		public static final String call = "{ call wcu_mapquest_search_pkg.get_stores_by_search_new(?,?,?,?,?,?,?) }";
		public static final int colSearchLatIn = 1;
		public static final int colSearchLongIn = 2;
		public static final int colAtrributeListIn = 3;
		public static final int colSearchRadiusIn = 4;
		public static final int colMaxRecordsIn = 5;
		public static final int colStoreTypeIn = 6;
		public static final int colStoreOut = 7;	// wcu_store_tab
	}
	
	// TYPE CUSTOMER.wcu_store_tab AS TABLE OF CUSTOMER.wcu_store_rec
}
