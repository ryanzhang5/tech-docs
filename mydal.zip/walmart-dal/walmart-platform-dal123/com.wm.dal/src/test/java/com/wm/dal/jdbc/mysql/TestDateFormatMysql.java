package com.wm.dal.jdbc.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

// @Test(sequential=true)
public class TestDateFormatMysql extends BaseMysqlTest {

	@Test(groups = { "mysql", "create" })
	public void testCreate() {

		Connection con = null;
		Statement stmt = null;

		String dropTablSql = "DROP TABLE IF EXISTS itemtbl_testdateformat;";
		String creaTablSql = "CREATE TABLE itemtbl_testdateformat ("
				+ "var_date date default NULL,"
				+ "var_timestamp_dt datetime default NULL,"
				+ "var_timestamp_ms int default NULL,"
				+ "var_time time default NULL"
				+ ") ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		try {
			logger.info("begin to create itemtbl_testdateformat table.");
//			con = dataSource.getConnection();
			con = pureDataSource.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate(dropTablSql);
			stmt.executeUpdate(creaTablSql);
			logger.info("itemtbl_testdateformat table is created.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Test(dependsOnMethods = "testCreate", groups = { "mysql", "insert" })
	public void testInsert() {

		Connection con = null;
		PreparedStatement pstm = null;

		String insrSql = "INSERT INTO itemtbl_testdateformat "
				+ " (var_date,var_timestamp_dt,var_timestamp_ms,var_time)" 
				+ " VALUES " 
				+ " (?,?,?,?)";

		try {
			logger.info("begin to insert itemtbl_testdateformat data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(insrSql);

			DateFormat dateFormat;
			dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date tDate = dateFormat.parse("2008-11-12");
			pstm.setDate(1, new java.sql.Date(tDate.getTime()));

			DateFormat timestampFormat;
			timestampFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			java.util.Date tTimestamp = timestampFormat
					.parse("2008-11-12 09:10:20.200");
			java.sql.Timestamp ts = new java.sql.Timestamp(tTimestamp.getTime());
			pstm.setTimestamp(2, ts);
			logger.info("+++++++++++++++++++++++" + ts.getNanos());
			pstm.setInt(3, ts.getNanos());
			
			DateFormat timeFormat;
			timeFormat = new SimpleDateFormat("HH:mm:ss");
			java.util.Date tTime = timeFormat.parse("09:10:20");
			pstm.setTime(4, new java.sql.Time(tTime.getTime()));

			pstm.execute();
			con.commit();

			logger.info("itemtbl_testdateformat data are inserted.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForInsert();
	}

	@Test(dependsOnMethods = "testInsert", groups = { "mysql", "update" })
	public void testUpdate() {

		Connection con = null;
		PreparedStatement pstm = null;

		String insrSql = "UPDATE itemtbl_testdateformat "
				+ " SET var_date=?,var_timestamp_dt=?,var_timestamp_ms=?,var_time=?";

		try {
			logger.info("begin to update itemtbl_testdateformat data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(insrSql);

			DateFormat dateFormat;
			dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date tDate = dateFormat.parse("2008-12-10");
			pstm.setDate(1, new java.sql.Date(tDate.getTime()));

			DateFormat timestampFormat;
			timestampFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			java.util.Date tTimestamp = timestampFormat
					.parse("2008-12-10 11:09:21.300");
			java.sql.Timestamp ts = new java.sql.Timestamp(tTimestamp.getTime());
			pstm.setTimestamp(2, ts);
			pstm.setInt(3, ts.getNanos());

			DateFormat timeFormat;
			timeFormat = new SimpleDateFormat("HH:mm:ss");
			java.util.Date tTime = timeFormat.parse("11:09:21");
			pstm.setTime(4, new java.sql.Time(tTime.getTime()));

			pstm.execute();
			con.commit();

			logger.info("itemtbl_testdateformat data are updated.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		this.testQueryForUpdate();
	}

	@Test(dependsOnMethods = "testUpdate", groups = { "mysql", "delete" })
	public void testDelete() {

		Connection con = null;
		Statement stmt = null;

		String dropTablSql = "DELETE FROM itemtbl_testdateformat;";
		try {
			logger.info("begin to delete itemtbl_testdateformat data.");
			con = dataSource.getConnection();
			stmt = con.createStatement();
			stmt.execute(dropTablSql);
			logger.info("data of itemtbl_testdateformat table is deleted.");
			con.commit();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Test(dependsOnMethods = "testDelete", groups = { "mysql", "drop" })
	public void testDrop() {

		Statement stmt = null;
		Connection con = null;
		String dropTablSql = "DROP TABLE itemtbl_testdateformat;";
		try {
			logger.info("begin to drop itemtbl_testdateformat table.");
//			con = dataSource.getConnection();
			con = pureDataSource.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate(dropTablSql);
			logger.info("itemtbl_testdateformat table is dropped.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void testQueryForInsert() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " var_date,var_timestamp_dt,var_timestamp_ms,var_time "
				+ " FROM itemtbl_testdateformat";

		try {
			logger.info("begin to retrieve itemtbl_testdateformat data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {

				DateFormat dateFormat;
				dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date tDate = dateFormat.parse("2008-11-12");
				java.sql.Date dateVal = rs.getDate(1);
				logger.info("var_date" + " : " + dateVal);
				logger.info("" + tDate.equals(new java.sql.Date(tDate.getTime())));
				Assert.assertEquals(dateVal, new java.sql.Date(tDate.getTime()));

				DateFormat timestampFormat;
				timestampFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
				java.util.Date tTimestamp = timestampFormat
						.parse("2008-11-12 09:10:20.200");
				java.sql.Timestamp datetimeVal = rs
						.getTimestamp(2);
				int milisecond = rs.getInt(3);
				logger.info("var_timestamp_dt" + " : " + datetimeVal);
				logger.info("var_timestamp_ms" + " : " + milisecond);
				java.sql.Timestamp exactTimestamp = new java.sql.Timestamp(datetimeVal.getTime());
				exactTimestamp.setNanos(milisecond);
				logger.info("" + tTimestamp.equals(exactTimestamp));
				Assert.assertEquals(exactTimestamp, 
									new java.sql.Timestamp(tTimestamp.getTime()));
				
				DateFormat timeFormat;
				timeFormat = new SimpleDateFormat("HH:mm:ss");
				java.util.Date tTime = timeFormat.parse("09:10:20");
				java.sql.Time timeVal = rs.getTime(4);
				logger.info("var_time" + " : " + timeVal);
				logger.info("" + tTime.equals(new java.sql.Time(tTime.getTime())));
				Assert.assertEquals(timeVal, new java.sql.Time(tTime.getTime()));

			}
			logger.info("itemtbl_testdateformat data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForUpdate() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " var_date,var_timestamp_dt,var_timestamp_ms,var_time "
				+ " FROM itemtbl_testdateformat";

		try {
			logger.info("begin to retrieve itemtbl_testdateformat data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {

				DateFormat dateFormat;
				dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date tDate = dateFormat.parse("2008-12-10");
				java.sql.Date dateVal = rs.getDate(1);
				logger.info("var_date" + " : " + dateVal);
				logger.info("" + tDate.equals(new java.sql.Date(tDate.getTime())));
				Assert.assertEquals(dateVal, new java.sql.Date(tDate.getTime()));

				DateFormat timestampFormat;
				timestampFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
				java.util.Date tTimestamp = timestampFormat
						.parse("2008-12-10 11:09:21.300");
				java.sql.Timestamp datetimeVal = rs
						.getTimestamp(2);
				int milisecond = rs.getInt(3);
				logger.info("var_timestamp_dt" + " : " + datetimeVal);
				logger.info("var_timestamp_ms" + " : " + milisecond);
				java.sql.Timestamp exactTimestamp = new java.sql.Timestamp(datetimeVal.getTime());
				exactTimestamp.setNanos(milisecond);
				logger.info("" + tTimestamp.equals(exactTimestamp));
				Assert.assertEquals(exactTimestamp, 
									new java.sql.Timestamp(tTimestamp.getTime()));
				
				DateFormat timeFormat;
				timeFormat = new SimpleDateFormat("HH:mm:ss");
				java.util.Date tTime = timeFormat.parse("11:09:21");
				java.sql.Time timeVal = rs.getTime(4);
				logger.info("var_time" + " : " + timeVal);
				logger.info("" + tTime.equals(new java.sql.Time(tTime.getTime())));
				Assert.assertEquals(timeVal, new java.sql.Time(tTime.getTime()));
				
			}
			logger.info("itemtbl_testdateformat data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void testQueryForDelete() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " var_date,var_timestamp_dt,var_timestamp_ms,var_time "
				+ " FROM itemtbl_testdateformat";

		try {
			logger.info("begin to retrieve itemtbl_testdateformat data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			int rowNum = rs.getRow();
			Assert.assertEquals(rowNum, 0);
			logger.info("itemtbl_testdateformat data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void testQueryForCreate() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = " select count(*) as table_num " +
				" from information_schema.tables " +
				" where table_name='itemtbl_testdateformat' and table_schema='test'";

		try {
			logger.info("begin to retrieve table existence data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				int num = rs.getInt(1);
				Assert.assertEquals(num, 1);
			}
			logger.info("table existence data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void testQueryForDrop() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = " select count(*) as table_num " +
				" from information_schema.tables " +
				" where table_name='itemtbl_testdateformat' and table_schema='test'";

		try {
			logger.info("begin to retrieve table existence data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				int num = rs.getInt(1);
				Assert.assertEquals(num, 0);
			}
			logger.info("table existence data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}


}
