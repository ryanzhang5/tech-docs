/*
 * Copyright 2010 Walmart.com. All rights reserved.
 */
package com.wm.dal.jdbc;

import org.testng.Assert;

import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Caller
 *
 * @author mkishore
 * @since TODO
 */
class Caller implements Runnable{
	private String name;
	private Connection conn;
	private int parameter;

	public Caller(String name, Connection conn, int parameter){
		this.name = name;
		this.conn = conn;
		this.parameter = parameter;
	}
	public void run(){
		CallableStatement stmt = null;
		ResultSet rs = null;
		String callSP = "{ call proc_test(?,?) }";
		int count = 0;
		long start = System.currentTimeMillis();
		long end = System.currentTimeMillis();

		try {
			do {
				System.out.println("============= " + name+ " calling PROCEDURE proc_test :" + (++count)+ " :" + start + ", " + end);

				stmt = conn.prepareCall(callSP);
				stmt.setInt(1, parameter);
				stmt.registerOutParameter(2, java.sql.Types.INTEGER);

				boolean hadResults = stmt.execute();
				while (hadResults) {
					rs = stmt.getResultSet();
//					System.out.println("============= " + name + " ResultSet:");
					while (rs.next()) {
						int columnCount = rs.getMetaData().getColumnCount();
						String oneRow = "============= " + name + " [";
						for (int i = 0; i < columnCount; i++) {
							oneRow += rs.getString(i + 1) + " | ";
						}
						System.out.println(oneRow + "]");
					}
					hadResults = stmt.getMoreResults();
				}

				int outputValue = stmt.getInt(2);
				Assert.assertEquals(outputValue, parameter*2);
				System.out.println("\n============= " + name+ " OutParameter [in:" + parameter + "]: "+ outputValue);
				if (count==1) start = System.currentTimeMillis();
				end = System.currentTimeMillis();
				conn.commit();
				System.out.println("============= " + name+ " called  PROCEDURE proc_test :" + (count)+ " :" + start + ", " + end);
			} while (end - start < 10 * 1000);

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
				e.printStackTrace();
		} finally {
			try {
				if (rs != null)			rs.close();
				if (stmt != null)		stmt.close();
			} catch (SQLException e) {
					e.printStackTrace();
			}
		}


	}
}
