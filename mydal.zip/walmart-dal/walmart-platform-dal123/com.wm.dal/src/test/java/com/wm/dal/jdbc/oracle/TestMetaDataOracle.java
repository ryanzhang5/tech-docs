package com.wm.dal.jdbc.oracle;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;
import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.Test;

@Test(sequential=true)
public class TestMetaDataOracle extends BaseOracleTest {
	
	@Test(groups = {"oracle", "metadata"} )
	public void testMetaData() {
		Connection con = null;
		ResultSet rs = null;
		try {
			logger.info("testing oracle metaData." );
			con = dataSource.getConnection();
//			con = pureDataSource.getConnection();
			String jdbcDrivName = con.getMetaData().getDriverName();
			String jdbcDrivVers = con.getMetaData().getDriverVersion();
			String dbProdName = con.getMetaData().getDatabaseProductName();
			String dbProdVers = con.getMetaData().getDatabaseProductVersion();

			logger.info("JDBC Driver Name: " + jdbcDrivName);
			logger.info("JDBC Driver Version: " + jdbcDrivVers);
			logger.info("Database Product Name:" + dbProdName);
			logger.info("Database Product Version:" + dbProdVers);
			
			rs = con.getMetaData().getTypeInfo();
			while (rs != null && rs.next())   {   
                String   typeName   =   rs.getString(1);   
                short   dataType   =   rs.getShort(2);   
                logger.info("typeName " +typeName +  " , java.sql.Types: " + dataType);
			}			
			logger.info("tested oralce metaData." );
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if (rs != null)   rs.close();
				if (con != null)  con.close();
			}catch (SQLException e) {
					e.printStackTrace();
			}
		}

	}
	
}


