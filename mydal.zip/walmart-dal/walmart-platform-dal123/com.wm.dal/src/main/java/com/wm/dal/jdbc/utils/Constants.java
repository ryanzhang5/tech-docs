/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc.utils;

import java.net.InetAddress;

import java.sql.SQLException;

import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;


/**
 * 
 * @author cshah
 * @version 1.0
 */
public final class Constants {
    private static final int MAJOR_VERSION = 1;
    private static final int MINOR_VERSION = 0;
    public static final String URL_PREFIX = "jdbc:walmart:@";
    private static final String COLON_DELIM = ":";
    private static String clientID;
    private static final Object gate = new Object();

    private static final Map<Integer,String> descMap = new HashMap<Integer, String>();
    
    //USED to send object type to DAL TCP Server
    public static final int CONNECTION              = 101;
    public static final int STATEMENT               = 102;
    public static final int PREPARED_STATEMENT      = 103;
    public static final int CALLABLE_STATEMENT      = 104;
    public static final int RESULTSET               = 105;
    public static final int RESULTSET_METADATA      = 106;
    public static final int PARAMETER_METADATA      = 107;
    public static final int DATABASE_METADATA       = 108;
    public static final int XA_RESOURCE				= 109;
    
    public static final int EXECUTE                 = 200;
    public static final int EXECUTE_QUERY           = 201;
    public static final int EXECUTE_UPDATE          = 202;
    public static final int EXECUTE_W_AUTOGENKEYS   = 203;
    public static final int EXECUTE_UPDATE_W_AUTOGENKEYS = 204;
    public static final int EXECUTE_UPDATE_W_COLUMNINDEXES = 205;
    public static final int EXECUTE_UPDATE_W_COLUMNNAMES = 206;
    public static final int EXECUTE_W_COLUMNINDEXES = 207;
    public static final int EXECUTE_W_COLUMNNAMES   = 208;
    public static final int EXECUTE_BATCH           = 209;
    public static final int CLEAR_PARAMETERS        = 210;
    public static final int COMMIT                  = 211;
    public static final int ROLLBACK                = 212;
    public static final int CLEAR_WARNINGS          = 213;
    public static final int CLEAR_BATCH             = 214;
    public static final int GET_UPDATE_COUNT        = 215;
    public static final int GET_RESULT_SET          = 216;
    public static final int GET_WARNINGS            = 217;
    public static final int GET_GENERATED_KEYS      = 218;
    public static final int GET_MORE_RESULTS        = 219;
    public static final int READ_MORE_RESULTS       = 220;
    public static final int GET_PROCEDURES          = 221;
    public static final int GET_PROCEDURES_COLUMNS  = 222;
    public static final int SUPPORTS_RS_TYPE        = 223;
    public static final int GET_COLUMNS             = 224;
    public static final int GET_PRIMARY_KEYS        = 225;
    
    public static final int CLOSE_CONNECTION        = 300;
    public static final int CLOSE_STATEMENT         = 301;
    public static final int CLOSE_RESULTSET         = 302;
    public static final int RESET_CONNECTION        = 303;
    public static final int PING_CONNECTION         = 304;
    
    public static final int XA_ROLLBACK				= 401;
    public static final int XA_PREPARE				= 402;
    public static final int XA_COMMIT				= 403;
    public static final int XA_COMMIT_ONEPHASE		= 404;
    public static final int XA_FORGET				= 405;
    public static final int XA_RECOVER				= 406;
    public static final int XA_START_FLAG     = 408;
//    public static final int XA_START				= 407;
//    public static final int XA_START_TMJOIN			= 408;
//    public static final int XA_START_TMRESUME		= 409;
    
    public static final String RESPONSE = "RESPONSE";
    public static final String STATUS = "STATUS";
    public static final String WARNING = "WARNING";


    private static int DEFAULT_FETCH_SIZE = 64;
    public static final int BUFFER_SIZE = 8196;
    
    public static final String METHOD_NOT_SUPPORTED = "Method not implemented...";
    public static final String UNSUPPORTED_EXCEPTION = "Unsupported Operation/Method";

    static {

        descMap.put(CONNECTION,"Connection");
        descMap.put(STATEMENT,"Statement");
        descMap.put(PREPARED_STATEMENT,"Prepared Statement");
        descMap.put(CALLABLE_STATEMENT,"Callable Statement");
        descMap.put(RESULTSET,"Resultset");
        descMap.put(RESULTSET_METADATA,"Resultset Metadata");
        descMap.put(PARAMETER_METADATA,"Parameter Metadata");
        descMap.put(DATABASE_METADATA,"Database Metadata");
            
        descMap.put(EXECUTE,"Execute");
        descMap.put(EXECUTE_QUERY,"Execute Query");
        descMap.put(EXECUTE_UPDATE,"Execute Update");
        descMap.put(EXECUTE_W_AUTOGENKEYS,"Execute With Auto Generated Keys");
        descMap.put(EXECUTE_UPDATE_W_AUTOGENKEYS,"Execute Update With Autogenkeys");
        descMap.put(EXECUTE_UPDATE_W_COLUMNINDEXES,"Execute Update With Columnindexes");
        descMap.put(EXECUTE_UPDATE_W_COLUMNNAMES,"Execute Update With Columnnames");
        descMap.put(EXECUTE_W_COLUMNINDEXES,"Execute With Columnindexes");
        descMap.put(EXECUTE_W_COLUMNNAMES,"Execute With Columnnames");
        descMap.put(CLEAR_BATCH,"Clear Batch");
        descMap.put(CLEAR_PARAMETERS,"Clear Parameters");
        descMap.put(COMMIT,"Commit");
        descMap.put(ROLLBACK,"Rollback");
        descMap.put(CLEAR_WARNINGS,"Clear Warnings");
        descMap.put(EXECUTE_BATCH,"Execute Batch");
        descMap.put(GET_UPDATE_COUNT,"Get Update Count");
        descMap.put(GET_RESULT_SET,"Get Result Set");
        descMap.put(GET_WARNINGS,"Get Warnings");
        descMap.put(GET_GENERATED_KEYS,"Get Generated Keys");
        descMap.put(GET_MORE_RESULTS,"Get More Results");
        descMap.put(READ_MORE_RESULTS,"Read More Results");
        descMap.put(GET_PROCEDURES,"Get Procedures");
        descMap.put(GET_PROCEDURES_COLUMNS,"Get Procedures Columns");
        descMap.put(SUPPORTS_RS_TYPE, "Supports Resultset Type");
        
        descMap.put(CLOSE_CONNECTION,"Close Connection");
        descMap.put(CLOSE_STATEMENT,"Close Statement");
        descMap.put(CLOSE_RESULTSET,"Close Resultset");
        descMap.put(RESET_CONNECTION,"Reset Connection");
        descMap.put(PING_CONNECTION,"Ping Connection");
    }    
    
    /**
     * 
     * @return
     */
    public static final int getMajorVersion() {
        return MAJOR_VERSION;
    }

    /**
     * 
     * @return
     */
    public static final int getMinorVersion() {
        return MINOR_VERSION;
    }    

    /**
     * 
     * @param url
     * @throws SQLException
     */
    private static void validateURL(String url) throws SQLException {
        if (!isValidURL(url))
            throw new SQLException("Bad URL {"+url+"}: URL must start with " + URL_PREFIX);
    }

    public static boolean
    isValidURL(String url)
    {
      return  url != null && url.startsWith(URL_PREFIX);
    }
    /**
     * 
     * @param url
     * @return
     * @throws SQLException
     */
    public static String[] validateHostNPort(String url) throws SQLException {
        String hostNport = url.substring(url.lastIndexOf("@")+1, url.length());
        StringTokenizer st = new StringTokenizer(hostNport,COLON_DELIM);
        if ( st.countTokens() != 3 ) {
            throw new SQLException("URL is not valid..."  + url);
        }
        
        String[] prop = new String[3];
        prop[0] = st.nextToken();
        prop[1] = st.nextToken();
        prop[2] = st.nextToken();
        return prop;
    }
    
    /**
     * 
     * @param url
     * @return
     * @throws SQLException
     */
    public static String getHost(String url) throws SQLException {
            validateURL(url);
            return validateHostNPort(url)[0];
    }

    /**
     * 
     * @param url
     * @return
     * @throws SQLException
     */
    public static int getPort(String url) throws SQLException {
        String sPort = validateHostNPort(url)[1];
        int port = -1;
        try {
            port =Integer.parseInt(sPort);
        } catch (Exception exp) {
            throw new SQLException("Port is not valid..." + sPort,exp );
        }
        return port;
    }

    /**
     * 
     * @param url
     * @return
     * @throws SQLException
     */
    public static String getAliasName(String url) throws SQLException {
            validateURL(url);
            return validateHostNPort(url)[2];
    }

    /**
     * 
     * @return
     */
    public static final String getSessionId() {
        String sid = null;
        synchronized (gate) {
            int cID = getClientID().hashCode() < 0 ? getClientID().hashCode() * -1 : getClientID().hashCode();
            sid = String.valueOf(cID) + System.currentTimeMillis();
        }
        return sid;
    }     
    
    /**
     * 
     * @return
     */
    public static final String getClientID() {
        try {
            if (clientID == null) {
                clientID =  InetAddress.getLocalHost().getCanonicalHostName();
            }
        } catch (Exception exp) {
            exp.printStackTrace();
            try {
                clientID = InetAddress.getLocalHost().toString();
            } catch (Exception ignore) {;}
        }
        return clientID;
    }

    /**
     * 
     * @return
     */
    public static final int getFetchSize() {
        //TODO 
        return DEFAULT_FETCH_SIZE;
    }    

    /**
     * 
     * @param key
     * @return
     */
    public static String getDescription(int key)  {
        return descMap.get(key);
    }
}
