package com.wm.dal.jms.apps;

import java.util.logging.Logger;
import java.util.Date;
import java.util.List;

import com.wm.syslog.Syslog;

import com.wm.weblib.jms.WMMessageHandler;
import com.wm.weblib.jms.WMMessage;
import com.wm.weblib.jms.WMMessageType;
import com.wm.weblib.jms.WMMessageHandlerStatus;
import com.wm.weblib.jms.WMJMSListenerManager;
import com.wm.weblib.jms.WMJMSReceiveMessages;

/**
 * Concrete implementation of a WMMessageHandler.  This handler deals
 * with ping messages from the database.  This is to ensure that the
 * jms system is working properly.
 * <p>
 * This handler will updates a status class which is exposed via
 * GSP.  A perl script knows how to retrieve the status page and report
 * on the health of the system to Netsaint.
 */
public class WMMessageHandlerPing extends WMMessageHandler {
    private static final Logger logger = Logger.getLogger(WMMessageHandlerPing.class.getName());
    public static final long QUEUE_EXPIRATION_TIME = 45 * 60 * 1000; //45 minutes
    public static final long PING_INTERVAL = 15 * 60 * 1000; //15 minutes
    public static final long MAX_PING_DELAY = QUEUE_EXPIRATION_TIME +
                                              PING_INTERVAL;

    /**************************************************************
     * Protected methods.
     */

	/**
	 * returns true if this message can be handled
	 * @param message WMMessage
	 */
	protected boolean canHandle(WMMessage message) {
		return message.getMessageType().equals(WMMessageType.MSG_TYPE_PING);
	}


    /**************************************************************
     * Private methods.
     */
    /**************************************************************
     * Instance variables.
     */
    private Date _lastPingSentTimestamp = new Date();
    private String _originatingServer;
    private String _randomId;
    private Date _lastPingReceivedTimestamp = new Date();
    private boolean _queueAlert = false;
    private boolean _isAlertSet;
    private boolean _isCriticalSet;

    /**************************************************************
     * Public methods.
     */
    /**
     * Updates the last ping sent and received timestamps.
     */
    public WMMessageHandlerStatus handleMessage(WMMessage m) {
        Date now = new Date();
        WMMessageHandlerStatus rv = _defaultStatus;

        if (m.getMessageType().equals(WMMessageType.MSG_TYPE_PING)) {
            _lastPingSentTimestamp = m.getTimestamp();
            _lastPingReceivedTimestamp = now;
            _originatingServer = m.getOriginServer();
            if(m instanceof WMMessageAdminPing){
            WMMessageAdminPing msg = (WMMessageAdminPing)m;
            _randomId = msg.getRandomId();
            }
            //
            // Handle the clock skew case.
            //
            if (getLastPingReceivedTimestamp().before(getLastPingSentTimestamp())) {
                rv = new Status(WMMessageHandlerStatus.CODE_FAILURE, m,
                                "Ping timestamp is in the future.  Beware of clock skew.");

                //no need to set alert: messages are being delivered very FAST :-)
                clearQueueAlert();
            }
            //
            //check if it takes too long to deliver ping message
            //
            else if ((getLastPingReceivedTimestamp().getTime() -
                         getLastPingSentTimestamp().getTime()) > QUEUE_EXPIRATION_TIME) {
                setQueueAlert();
                rv = new Status(WMMessageHandlerStatus.CODE_FAILURE, m,
                                "Ping was delayed in the Queue. Setting up Alert.");
            } else {
                clearQueueAlert();
                rv = new Status(WMMessageHandlerStatus.CODE_SUCCESS, m, "Ok.");
            }
        }
        return rv;
    }

    /**
     * Returns a Date which corresponds to the timestamp (i.e.,
     * the time it was enqueued on the message stack in Oracle) of the
     * last message this handler handled.
     */
    public  Date getLastPingSentTimestamp() {
        return _lastPingSentTimestamp;
    }

    /**
     * Returns a Date at which the last message was handled by this
     * handler.
     */
    public  Date getLastPingReceivedTimestamp() {
        return _lastPingReceivedTimestamp;
    }

   /**
     * Returns message originating server of the
     * last message this handler handled.
     */
    public String getOriginatingServer() {
        return _originatingServer;
    }


    /**
     * Returns message random ID set
     * last message this handler handled.
     */
    public String getRandomId() {
        return _randomId;
    }

    /**
     * Check if queue has alert status.
     * There could be two cases:
     * 1. it took too long to deliver last ping (receiveTime - sendTime)
     * 2. last ping was received too long ago: we are not getting any messages
     *    for a while (now - lastPingReceiveTime)
     * First one is calculated on each message receival, second one is calcualted right
     * here in this method.
     */
    public  boolean isQueueAlert() {
        if (!getQueueAlert()) {
            Date now = new Date();

            //check if it didn't receive ping for a while
            long timeSinceLastPing = now.getTime() -
                                     getLastPingReceivedTimestamp().getTime();

            if ((timeSinceLastPing > QUEUE_EXPIRATION_TIME) &&
                    (timeSinceLastPing < MAX_PING_DELAY) && !_isAlertSet ) {

                _isAlertSet = true;  //display this message once only
                Syslog.PROD.info("com.wm.weblib.jms.WMMessageHandlerPing",
                                 "isQueueAlert",
                                 "Didn't received ping for " +
                                 (timeSinceLastPing / 1000 / 60) +
                                 " minutes; setting up alert.");
                logger.warning("com.wm.weblib.jms.WMMessageHandlerPing: Alert - Didn't received ping for " +
                                   (timeSinceLastPing / 1000 / 60) +
                                   " minutes; setting up alert.");
            }

            if (timeSinceLastPing > MAX_PING_DELAY  && !_isCriticalSet ) {

                _isCriticalSet = true; //display this message once only
                setQueueAlert();
                Syslog.PROD.info("com.wm.weblib.jms.WMMessageHandlerPing",
                                 "isQueueAlert",
                                 "Didn't received ping for " +
                                 (timeSinceLastPing / 1000 / 60) +
                                 " minutes; setting up critical alert.");
                logger.warning("com.wm.weblib.jms.WMMessageHandlerPing: Critical - Didn't received ping for " +
                                   (timeSinceLastPing / 1000 / 60) +
                                   " minutes; critical alert.");
            }
        }

        return getQueueAlert();
    }

    private  void setQueueAlert() {
        setQueueAlert(true);
    }

    private  void clearQueueAlert() {
        setQueueAlert(false);
        //reset the message flags since all is well now
        _isAlertSet = false;
        _isCriticalSet = false;
    }

    private  void setQueueAlert(boolean queueAlert) {
        synchronized (WMMessageType.MSG_TYPE_PING) {
            _queueAlert = queueAlert;
        }
    }

    private  boolean getQueueAlert() {
        synchronized (WMMessageType.MSG_TYPE_PING) {
            return _queueAlert;
        }
    }

    public  String getStats() {
        return "WMMessageHandlerPing{" + "\n  isQueueAlert: " + isQueueAlert() +
               "\n  lastPingReceivedTimestamp: " +
               getLastPingReceivedTimestamp() + "\n  lastPingSentTimestamp: " +
               getLastPingSentTimestamp() + "\n}";
    }


    public static boolean isNonAdminQueueAlert() {
	WMJMSReceiveMessages receiver = WMJMSListenerManager.getInstance().getReceiver("WMJMSNonAdminListener");

	if (receiver == null) { //there is no such configuration
	    logger.warning("JMS Non Admin Listener is not found, check your configuration.");
	    return false;
	}

	List handlers = receiver.getHandler();

	if (handlers != null) {
	    for (int i=0; i<handlers.size(); i++) {
		Object aObject = handlers.get(i);
		if (aObject instanceof WMMessageHandlerPing) {
		    return ((WMMessageHandlerPing)aObject).isQueueAlert();
		}
	    }
	}
	return false;
    }


/**
     * Subclass of WMMessageHandlerStatus specific to the ping handler.
     */
static class Status extends WMMessageHandlerStatus {
        /**************************************************************
         * Instance variables.
         */
        private String _statusMessage;
        private WMMessage _message;

        /**************************************************************
         * Protected methods.
         */
        protected Status(int code, WMMessage message, String statusMessage) {
            setCode(code);
            _message = message;
            _statusMessage = statusMessage;
        }

        /**************************************************************
         * Public methods.
         */
        public String toString() {
            return getStatusMessage();
        }

        /**************************************************************
         * Private methods.
         */
        private String getStatusMessage() {
            switch (getCode()) {
            case CODE_SUCCESS:
                return "<WMMessageHandlerPing>: Successfully handled timestamp message.";

            case CODE_WARNING:
                return "<WMMessageHandlerPing>: Warning -- " + _statusMessage +
                       "; " + _message;

            case CODE_FAILURE:
                return "<WMMessageHandlerPing>: Error   -- " + _statusMessage +
                       "; " + _message;

            default:
                return "<WMMessageHandlerPing>: noop";
            }
        }

  }}
