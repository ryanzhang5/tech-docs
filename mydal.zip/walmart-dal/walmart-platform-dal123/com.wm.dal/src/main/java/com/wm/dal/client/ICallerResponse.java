/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.client;

import java.io.Serializable;

/**
 * @author cshah
 * @version 1.0
 */
public interface ICallerResponse {

    /**
     * @param key
     * @param object
     */
    public void set(String key, Serializable object) ;

    /**
     * @param key
     * @return
     */
    public Serializable get(String key);

    /**
     * @param key
     * @return
     */
    public boolean containsKey(String key);

    /**
     * @return
     */
    public int getID();

    /**
     * @param ID
     */
    public void setID(int ID);
}
