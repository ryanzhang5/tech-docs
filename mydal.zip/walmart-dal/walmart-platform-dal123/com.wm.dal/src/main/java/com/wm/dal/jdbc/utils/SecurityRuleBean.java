package com.wm.dal.jdbc.utils;

import java.io.Serializable;

public class SecurityRuleBean implements Serializable {

	public SecurityRuleBean() {
		
	}
	
	public SecurityRuleBean(int ruleId, String ruleFile) {
		
		this.ruleId = ruleId;
		this.ruleFile = ruleFile;
	}
	
	public int getRuleId() {
		return ruleId;
	}

	public void setRuleId(int ruleId) {
		this.ruleId = ruleId;
	}

	public String getRuleFile() {
		return ruleFile;
	}

	public void setRuleFile(String ruleFile) {
		this.ruleFile = ruleFile;
	}

	public int packKey() {

		return ruleId;
	}

	public void unpackKey(int key) {

		ruleId = key;
	}

	private int ruleId;
	private String ruleFile;
}
