/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.router;

import com.wm.dal.common.DALSession;

/**
 * Router Request Interface to get the DAL Session
 * DAL Session will provide an API, Parameters, Client ID, Session ID and other parameters
 */
public interface IRouterRequest {
    /**
     * Method return DALsession, Application router can
     * use this DALSession to get API, Parameters, Client Host Name
     * to specify the Pool Name and send the Pool Name back to the router
     * @return -- DALSession
     */
    public DALSession getSession();
}
