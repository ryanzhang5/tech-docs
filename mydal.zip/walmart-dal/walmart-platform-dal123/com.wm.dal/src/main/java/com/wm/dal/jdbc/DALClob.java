/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc;

import com.wm.dal.jdbc.utils.DALUtil;

import java.io.ByteArrayInputStream;
import java.io.Reader;
import java.io.Serializable;
import java.io.StringReader;

import java.sql.Clob;
import java.sql.SQLException;


/**
 * The mapping in the Java<sup><font size=-2>TM</font></sup> programming language 
 * for the SQL <code>CLOB</code> type.
 * An SQL <code>CLOB</code> is a built-in type
 * that stores a Character Large Object as a column value in a row of
 * a database table.
 * By default drivers implement a <code>Clob</code> object using an SQL
 * <code>locator(CLOB)</code>, which means that a <code>Clob</code> object 
 * contains a logical pointer to the SQL <code>CLOB</code> data rather than
 * the data itself. A <code>Clob</code> object is valid for the duration
 * of the transaction in which it was created.
 * <P>The <code>Clob</code> interface provides methods for getting the
 * length of an SQL <code>CLOB</code> (Character Large Object) value,
 * for materializing a <code>CLOB</code> value on the client, and for
 * searching for a substring or <code>CLOB</code> object within a
 * <code>CLOB</code> value.
 * Methods in the interfaces {@link ResultSet},
 * {@link CallableStatement}, and {@link PreparedStatement}, such as
 * <code>getClob</code> and <code>setClob</code> allow a programmer to
 * access an SQL <code>CLOB</code> value.  In addition, this interface
 * has methods for updating a <code>CLOB</code> value.
 * 
 * @since 1.2
 */

public final class DALClob implements java.sql.Clob, Serializable {
    volatile String data;

    /**
     * @param data
     * @throws SQLException
     */
    public DALClob(final String data) throws SQLException {

        if (data == null) {
            throw DALUtil.sqlException("Invalid Argument");
        }

        this.data = data;
    }

    /**
     * @param data
     * @throws SQLException
     */
    public DALClob(final char[] data) throws SQLException {

        if (data == null) {
            throw DALUtil.sqlException("Invalid Argument");
        }

        this.data = new String(data);
    }

    /**
     * @param data
     * @throws SQLException
     */
    public DALClob(final byte[] data) throws SQLException {

        if (data == null) {
            throw DALUtil.sqlException("Invalid Argument");
        }

        this.data = new String(data);
    }
    
    /**
     * Returns the underlying character array
     *
     * @return the underlying character array
     */
    public char[] getData() {
        return data.toCharArray();
    }


      /**
       * Retrieves the number of characters 
       * in the <code>CLOB</code> value
       * designated by this <code>Clob</code> object.
       *
       * @return length of the <code>CLOB</code> in characters
       * @exception SQLException if there is an error accessing the
       *            length of the <code>CLOB</code> value
       * @since 1.2
       */
      public long length() throws SQLException { 
        final String ldata = data;
        return ldata.length();
    }

      /**
       * Retrieves a copy of the specified substring 
       * in the <code>CLOB</code> value
       * designated by this <code>Clob</code> object.
       * The substring begins at position
       * <code>pos</code> and has up to <code>length</code> consecutive
       * characters.
       *
       * @param pos the first character of the substring to be extracted.
       *            The first character is at position 1.
       * @param length the number of consecutive characters to be copied
       * @return a <code>String</code> that is the specified substring in
       *         the <code>CLOB</code> value designated by this <code>Clob</code> object
       * @exception SQLException if there is an error accessing the
       *            <code>CLOB</code> value
       * @since 1.2
       */
    public String getSubString(long pos, int length) throws SQLException { 
        final String ldata = data;
        final int    dlen  = ldata.length();

        pos--;

        if (pos < 0 || pos > dlen) {
            DALUtil.sqlException("Invalid Argument pos: " + (pos + 1L));
        }

        if (length < 0 || length > dlen - pos) {
            throw DALUtil.sqlException("Invalid Argument length: " + length);
        }

        if (pos == 0 && length == dlen) {
            return ldata;
        }

        return ldata.substring((int) pos, (int) pos + length);

    }

      /**
       * Retrieves the <code>CLOB</code> value designated by this <code>Clob</code>
       * object as a <code>java.io.Reader</code> object (or as a stream of
       * characters).
       *
       * @return a <code>java.io.Reader</code> object containing the 
       *         <code>CLOB</code> data
       * @exception SQLException if there is an error accessing the 
       *            <code>CLOB</code> value
       * @see #setCharacterStream
       * @since 1.2
       */
    public java.io.Reader getCharacterStream() throws SQLException { 
        final String ldata = data;
        return new StringReader(ldata);
    }

      /**
       * Retrieves the <code>CLOB</code> value designated by this <code>Clob</code>
       * object as an ascii stream.
       *
       * @return a <code>java.io.InputStream</code> object containing the 
       *         <code>CLOB</code> data
       * @exception SQLException if there is an error accessing the 
       *            <code>CLOB</code> value
       * @see #setAsciiStream
       * @since 1.2
       */
    public java.io.InputStream getAsciiStream() throws SQLException { 
        final String ldata = data;
        return new ByteArrayInputStream(ldata.getBytes());
    }

      /** 
       * Retrieves the character position at which the specified substring 
       * <code>searchstr</code> appears in the SQL <code>CLOB</code> value
       * represented by this <code>Clob</code> object.  The search 
       * begins at position <code>start</code>.
       *
       * @param searchstr the substring for which to search 
       * @param start the position at which to begin searching; the first position
       *              is 1
       * @return the position at which the substring appears or -1 if it is not
       *         present; the first position is 1
       * @exception SQLException if there is an error accessing the       
       *            <code>CLOB</code> value
       * @since 1.2
       */
    public long position(String searchstr, long start) throws SQLException { 
        if (searchstr == null || start > Integer.MAX_VALUE) {
            return -1;
        }

        final String ldata = data;
        final int    pos   = ldata.indexOf(searchstr, (int) --start);

        return (pos < 0) ? -1 : pos + 1;
    }

      /** 
       * Retrieves the character position at which the specified  
       * <code>Clob</code> object <code>searchstr</code> appears in this 
       * <code>Clob</code> object.  The search begins at position 
       * <code>start</code>.
       *
       * @param searchstr the <code>Clob</code> object for which to search
       * @param start the position at which to begin searching; the first
       *              position is 1
       * @return the position at which the <code>Clob</code> object appears 
       *              or -1 if it is not present; the first position is 1
       * @exception SQLException if there is an error accessing the 
       *            <code>CLOB</code> value
       * @since 1.2
       */
    public long position(Clob searchstr, long start) throws SQLException { 
        if (searchstr == null) {
            return -1;
        }

        final String ldata = data;
        final long   dlen  = ldata.length();
        final long   sslen = searchstr.length();

        start--;    

        // This is potentially much less expensive than materializing a large
        // substring from some other vendor's CLOB.  Indeed, we should probably
        // do the comparison piecewise, using an in-memory buffer (or temp-files
        // when available), if it is detected that the input CLOB is very long.
        if (start > dlen - sslen) {
            return -1;
        }

        // by now, we know sslen and start are both < Integer.MAX_VALUE
        String s;

        if (searchstr instanceof DALClob) {
            s = ((DALClob) searchstr).data;
        } else {
            s = searchstr.getSubString(1L, (int) sslen);
        }

        final int pos = ldata.indexOf(s, (int) start);

        return (pos < 0) ? -1 : pos + 1;
    }

        //---------------------------- jdbc 3.0 -----------------------------------

        /**
         * Writes the given Java <code>String</code> to the <code>CLOB</code>
         * value that this <code>Clob</code> object designates at the position 
         * <code>pos</code>.
         *
         * @param pos the position at which to start writing to the <code>CLOB</code>
         *         value that this <code>Clob</code> object represents
         * @param str the string to be written to the <code>CLOB</code>
         *        value that this <code>Clob</code> designates
         * @return the number of characters written
         * @exception SQLException if there is an error accessing the 
         *            <code>CLOB</code> value
         *
         * @since 1.4
         */
        public int setString(long pos, String str) throws SQLException { throw new SQLException("Method not implemented"); }

        /**
         * Writes <code>len</code> characters of <code>str</code>, starting 
         * at character <code>offset</code>, to the <code>CLOB</code> value
         * that this <code>Clob</code> represents.
         *
         * @param pos the position at which to start writing to this
         *        <code>CLOB</code> object
         * @param str the string to be written to the <code>CLOB</code> 
         *        value that this <code>Clob</code> object represents
         * @param offset the offset into <code>str</code> to start reading
         *        the characters to be written
         * @param len the number of characters to be written
         * @return the number of characters written
         * @exception SQLException if there is an error accessing the 
         *            <code>CLOB</code> value
         *
         * @since 1.4
         */
        public int setString(long pos, String str, int offset, int len) throws SQLException { throw new SQLException("Method not implemented"); }

        /**
         * Retrieves a stream to be used to write Ascii characters to the
         * <code>CLOB</code> value that this <code>Clob</code> object represents, 
         * starting at position <code>pos</code>.
         *
         * @param pos the position at which to start writing to this
         *        <code>CLOB</code> object
         * @return the stream to which ASCII encoded characters can be written
         * @exception SQLException if there is an error accessing the 
         *            <code>CLOB</code> value
         * @see #getAsciiStream
         *
         * @since 1.4
         */
        public java.io.OutputStream setAsciiStream(long pos) throws SQLException { throw new SQLException("Method not implemented"); }

        /**
         * Retrieves a stream to be used to write a stream of Unicode characters 
         * to the <code>CLOB</code> value that this <code>Clob</code> object
         * represents, at position <code>pos</code>.
         *
         * @param  pos the position at which to start writing to the
         *        <code>CLOB</code> value
         *
         * @return a stream to which Unicode encoded characters can be written
         * @exception SQLException if there is an error accessing the 
         *            <code>CLOB</code> value
         * @see #getCharacterStream
         *
         * @since 1.4
         */
        public java.io.Writer setCharacterStream(long pos) throws SQLException { throw new SQLException("Method not implemented"); }

        /**
         * Truncates the <code>CLOB</code> value that this <code>Clob</code> 
         * designates to have a length of <code>len</code> 
         * characters.
         * @param len the length, in bytes, to which the <code>CLOB</code> value
         *        should be truncated
         * @exception SQLException if there is an error accessing the 
         *            <code>CLOB</code> value
         *
         * @since 1.4
         */
        public void truncate(long len) throws SQLException { 
            final String ldata = data;
            final long   dlen  = ldata.length();
            final long   chars = len >> 1;

            if (chars == dlen) {
                 System.currentTimeMillis();
                // nothing has changed, so there's nothing to be done
            } else if (len < 0 || chars > dlen) {
                throw DALUtil.sqlException("Invalid Argument " + Long.toString(len));
            } else {

                // use new String() to ensure we get rid of slack
                data = new String(ldata.substring(0, (int) chars));
            }
        }

    /**
     * This method frees the <code>Clob</code> object and releases the resources the resources
     * that it holds.  The object is invalid once the <code>free</code> method
     * is called. 
     * <p>
     * After <code>free</code> has been called, any attempt to invoke a
     * method other than <code>free</code> will result in a <code>SQLException</code> 
     * being thrown.  If <code>free</code> is called multiple times, the subsequent
     * calls to <code>free</code> are treated as a no-op.
     * <p>
     * @throws SQLException if an error occurs releasing
     * the Clob's resources
     *
     * @exception SQLFeatureNotSupportedException if the JDBC driver does not support
     * this method
     * @since 1.6
     */
    public void free() throws SQLException {
        data = null;
    }

    /**
     * Returns a <code>Reader</code> object that contains a partial <code>Clob</code> value, starting
     * with the character specified by pos, which is length characters in length.
     *
     * @param pos the offset to the first character of the partial value to
     * be retrieved.  The first character in the Clob is at position 1.
     * @param length the length in characters of the partial value to be retrieved.
     * @return <code>Reader</code> through which the partial <code>Clob</code> value can be read.
     * @throws SQLException if pos is less than 1 or if pos is greater than the number of
     * characters in the <code>Clob</code> or if pos + length is greater than the number of
     * characters in the <code>Clob</code>
     *
     * @exception SQLFeatureNotSupportedException if the JDBC driver does not support
     * this method
     * @since 1.6
     */
    public Reader getCharacterStream(long pos, long length) throws SQLException {
        throw new SQLException("Method not implemented");
    }

}
