/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.statements;

import com.wm.dal.router.plugins.default_.IStatement;
import com.wm.dal.router.plugins.default_.RouterContext;

import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.logging.Logger;
import java.util.logging.Level;

/**
 * SetSqlStringAction - performs a java string replacement on the sql string. 
 *
 * @author mkishore
 * @version $Revision: 1.5 $
 * @since 1.0
 */
public class SetSqlStringStatement implements IStatement<RouterContext> {
    private static final Logger logger = Logger.getLogger(SetSqlStringStatement.class.getName());

    private String regex;
    private boolean caseInsensitive;
    private String replace;
    private boolean all = true;
    
    private Pattern pattern;

    /**
     * This method should be called after creating the action and injecting
     * all its dependencies. The implmentations can use this method to validate
     * that the instance has been configured correctly.
     *
     * @throws IllegalStateException - if there are errors in the configuration
     */
    public void initialize() throws IllegalStateException {
        if (regex == null) {
            throw new IllegalStateException("The regex is null");
        }
        if (replace == null) {
            throw new IllegalStateException("The replace is null");
        }

        try {
            int flags = (caseInsensitive) ? Pattern.CASE_INSENSITIVE :0;
            pattern = Pattern.compile(regex, flags);
        } catch (Exception e) {
            throw new IllegalStateException("Error compiling the regex pattern", e);
        }
    }

    /**
     * Performs a java string replacement on the sql string.
     *
     * @param context - the execution context
     */
    public Status execute(RouterContext context) {
        String sqlString = context.getRequest().getSession().getSQL();
        if (sqlString == null) {
            if (logger.isLoggable(Level.FINE)) {
                logger.fine(this.getClass().getSimpleName() + " - Executed. sqlString [null]");
            }
            return Status.CONTINUE;
        }

        String ret = null;
        Matcher matcher = pattern.matcher(sqlString);
        if (all) {
            ret = matcher.replaceAll(replace);
        } else {
            ret = matcher.replaceFirst(replace);
        }
        context.getRequest().getSession().setSQL(ret);
        if (logger.isLoggable(Level.FINE)) {
            logger.fine(this.getClass().getSimpleName() + " - Executed. Replaced " + ((all) ?"ALL" :"FIRST") + " occurrances of"
                    + " regex [" + regex + "] in sqlString [" + sqlString + "] with pattern [" + replace + "]"
                    + " to get the result [" + ret + "]"
            );
        }
        return Status.CONTINUE;
    }

    // GETTERS and SETTERS

    public String getRegex() {
        return regex;
    }

    public void setRegex(String regex) {
        this.regex = regex;
    }

    public boolean isCaseInsensitive() {
        return caseInsensitive;
    }

    public void setCaseInsensitive(boolean caseInsensitive) {
        this.caseInsensitive = caseInsensitive;
    }

    public String getReplace() {
        return replace;
    }

    public void setReplace(String replace) {
        this.replace = replace;
    }

    public boolean isAll() {
        return all;
    }

    public void setAll(boolean all) {
        this.all = all;
    }
}