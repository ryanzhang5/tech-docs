package com.wm.dal.jdbc.utils;

import java.io.Serializable;

public class SecurityEnvPoolBean implements Serializable{

	public final static String SEPERATOR = "|";
	
	public SecurityEnvPoolBean() {
		
	}
	
	public SecurityEnvPoolBean(String environment, String poolName, int ruleId) {
		
		this.environment = environment;
		this.poolName = poolName;
		this.ruleId = ruleId;
	}
	
	public String getEnvironment() {
		return environment;
	}
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	public String getPoolName() {
		return poolName;
	}
	public void setPoolName(String poolName) {
		this.poolName = poolName;
	}
	public int getRuleId() {
		return ruleId;
	}
	public void setRuleId(int ruleId) {
		this.ruleId = ruleId;
	}
	
	public String packKey() {
		
		return environment + SEPERATOR + poolName;
	}
	
	public void unpackKey(String key) {
		
		if (key != null && !"".equals(key)) {
			String[] keyStr = key.split(SEPERATOR);
			environment = keyStr[0];
			poolName = keyStr[1];
		}
	}
	
	private String environment;
	private String poolName;
	private int ruleId;
}
