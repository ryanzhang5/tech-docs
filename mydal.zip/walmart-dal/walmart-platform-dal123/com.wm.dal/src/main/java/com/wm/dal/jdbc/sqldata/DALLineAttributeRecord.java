package com.wm.dal.jdbc.sqldata;

import java.io.Serializable;

import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

public class DALLineAttributeRecord implements java.sql.SQLData, Serializable {
        private String  attributeName;
        private String  attributeValue;

        private static final String SQL_TYPE = "T_LI_ATTRIBUTE_REC";

        public String getAttributeName() { return attributeName; }
        public void setAttributeName(String attributeName) { this.attributeName = attributeName; }

        public String getAttributeValue() { return attributeValue; }
        public void setAttributeValue(String attributeValue) { this.attributeValue = attributeValue; }

       //O fulfill contract of interface SQLData w/ these methods
        public String getSQLTypeName() throws SQLException {
            return SQL_TYPE;
        }

        public void readSQL(SQLInput stream, String typeName) throws SQLException {
            throw new RuntimeException("Not implemented because for now we don't need to read these.");
        }

        public void writeSQL(SQLOutput stream) throws SQLException {
            stream.writeString(attributeName);
            stream.writeString(attributeValue);
        }
    }
