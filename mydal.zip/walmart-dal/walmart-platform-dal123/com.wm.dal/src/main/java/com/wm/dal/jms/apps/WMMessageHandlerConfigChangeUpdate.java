package com.wm.dal.jms.apps;

import com.wm.configmgmt.client.jms.WMMessageHandlerConfigChangeNotification;
import com.wm.dal.util.ServerConf;
import com.wm.dal.util.DALException;

import java.util.logging.Logger;
import java.util.logging.Level;
  
import com.wm.corelib.config.AppConfig;

/**
 * Created by IntelliJ IDEA.
 * User: Nagesh Cherukuri
 * Date: Jan 11, 2010
 * Time: 8:08:47 PM
 * To change this template use File | Settings | File Templates.
 */
public class WMMessageHandlerConfigChangeUpdate extends WMMessageHandlerConfigChangeNotification {

    private static final Logger logger = Logger.getLogger(WMMessageHandlerConfigChangeUpdate.class.getName());
    protected void updateVM() {

         String jvmConfigFile =  AppConfig.getInstance().getProperty("com.wm.conf");
            try {
                ServerConf.loadConfig(jvmConfigFile);
            } catch(DALException e) {
                logger.log(Level.SEVERE, WMMessageHandlerConfigChangeUpdate.class.getName()+": Failed to load "+jvmConfigFile+" exiting..", e);
            }

    }

}

