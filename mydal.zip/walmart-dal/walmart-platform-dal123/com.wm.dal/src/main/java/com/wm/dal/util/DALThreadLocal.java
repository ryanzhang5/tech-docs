package com.wm.dal.util;

/**
 * @auther cshah
 * @since 10.9
 * @version 1.0
 */
public class DALThreadLocal {
  private static ThreadLocal<String> threadLocal = new ThreadLocal<String>();

    /**
     *
     * @return
     */
    public static String getSessionID() {
        return threadLocal.get();
    }
  
    /**
     *
     * @param sessionID
     */
    public static void setSessionID(String sessionID) {
        threadLocal.set(sessionID);
    }
  
  }
  
