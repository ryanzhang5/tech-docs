package com.wm.dal.util.beans;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.wm.dal.server.DALServer;
  
import com.wm.corelib.config.AppConfig;

public class DALConfigure {

	protected static final Logger logger = Logger.getLogger(DALConfigure.class.getName());
	
	private static final String DEFAULT_CONFIG_FILE = "/dal.conf";
	private static final String KEY_HEAD  = "com.wm.sql.dataaccess";
	
	public static void loadConfig(DALConfigProperties configProperties) {
		try {
			configProperties.load(DALConfigure.class.getResourceAsStream(DEFAULT_CONFIG_FILE));
		} catch (Exception e) {
			logger.log(Level.ALL, DALServer.class.getName()+": Failed to load "+DEFAULT_CONFIG_FILE+" Exiting", e);
		}
	}
	
	public static DALConfigDisplayBean getAllConfiguration() {
		
		final String ALIAS_KEY = "com.wm.sql.dataaccess.aliases";
		final String SEPER_KEY = ",";
		//final String[] KEY_SEQ = {"class","url","user","passwd","minconn","maxconn",
		//		"maxcheckout","maxcheckouttimeout","maxidletimeout","retryinterval",
		//		"locktimeout","maxwaitclient","maxwaittimeout","useXA"};
		
		DALConfigDisplayBean confDispBean = new DALConfigDisplayBean();

		List<DALConfigBean> confList = new ArrayList<DALConfigBean>();
		
		DALConfigProperties props = new DALConfigProperties();
		loadConfig(props);
		
		String aliasStr = props.getProperty(ALIAS_KEY);
		String[] aliasVals = aliasStr.split(SEPER_KEY);
		
		List confBeanList = props.getConfigList();
		Iterator confBeanIter = confBeanList.iterator();
		while (confBeanIter.hasNext()) {
			DALConfigBean confBean = (DALConfigBean)confBeanIter.next();
			String key = confBean.getKey();
			if (validateKey(key)) {
				String value = confBean.getValue();
				DALConfigBean confb = new DALConfigBean(key,value);
				confList.add(confb);
			}
		}
		//for (int i=0; i<aliasVals.length; i++) {
		//	for (int j=0; j<KEY_SEQ.length; j++) {
		//		String key = KEY_HEAD + "." + aliasVals[i] + "." + KEY_SEQ[j];
		//		if (validateKey(key)) {
		//			String value = AppConfig.getInstance().getProperty(key);
		//			DALConfigBean confBean = new DALConfigBean(key,value);
		//			confList.add(confBean);
		//		}
		//	}
		//}
		confDispBean.setAlias(aliasVals);
		confDispBean.setConfigBeans(confList);
		return confDispBean;
	}
	
	private static boolean validateKey(String key) {

		final String INVALID_CONF_GROUP = "groups";
		final String INVALID_CONF_ALIAS = "aliases";
		final String INVALID_CONF_DISABLEXA = "disableXA";
		final String INVALID_CONF_DISABLERC = "disableXARecovery";
		final String INVALID_PASSWORD_1 = "PASSWORD";
		final String INVALID_PASSWORD_2 = "password";
		final String INVALID_PASSWORD_3 = "passwd";
		
		boolean valid = false;
		if (key.endsWith(INVALID_PASSWORD_1) || key.endsWith(INVALID_PASSWORD_2) || key.endsWith(INVALID_PASSWORD_3)) {
			valid = false;
			return valid;
		}
		if (key.endsWith(INVALID_CONF_GROUP) || key.endsWith(INVALID_CONF_ALIAS) ||
			key.endsWith(INVALID_CONF_DISABLEXA) || key.endsWith(INVALID_CONF_DISABLERC)) {
			valid = false;
			return valid;
		}		
		if (key.startsWith(KEY_HEAD)) {
			valid = true;
			return valid;
		}
		return valid;
	}
}
