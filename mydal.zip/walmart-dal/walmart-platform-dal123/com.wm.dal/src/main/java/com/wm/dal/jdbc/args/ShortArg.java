/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc.args;

import java.math.BigDecimal;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Types;

/**
 * @author cshah
 * @version 1.0
 */
public class ShortArg extends DALArgs {
    private short value;

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    public ShortArg(int position, boolean isOut, boolean isNull, short value) {
        init(position, isOut, isNull, value);
    }

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    protected void init(int position, boolean isOut, boolean isNull, short value) {
        super.init(position, isOut, isNull, Types.SMALLINT);
        this.value = value;
    }

    /**
     * @return
     */
    public short getValue() {
        return value;
    }

    /**
     * @return
     */
    public Object getValueObject() {
        return new Short(getValue());
    }

    /**
     * @param value
     * @throws SQLException
     */
    public void setValueObject(Object value) throws SQLException {
        if (value != null && value instanceof Double) {
            this.value = ((Double)value).shortValue();
        } else if (value != null && value instanceof Long) {
            this.value = ((Long)value).shortValue();
        } else if (value != null && value instanceof Float) {
            this.value = ((Float)value).shortValue();
        } else if (value != null && value instanceof Short) {
            this.value = ((Short)value).shortValue();
        } else if (value != null && value instanceof Integer) {
            this.value = ((Integer)value).shortValue();
        } else if (value != null && value instanceof BigDecimal) {
            this.value = ((BigDecimal)value).shortValue();
        } else if (value != null && value instanceof Date) {
            this.value = (short)((Date)value).getTime();
        } else if (value != null && value instanceof Time) {
            this.value = (short)((Time)value).getTime();
        } else if (value != null && value instanceof Timestamp) {
            this.value = (short)((Timestamp)value).getTime();
        }

    }

    /**
     * @return
     */
    public String toString() {
        return super.toString() + ", value = |" + value + "|";
    }
}
