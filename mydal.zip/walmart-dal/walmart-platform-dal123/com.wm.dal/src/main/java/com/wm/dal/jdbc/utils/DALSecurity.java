package com.wm.dal.jdbc.utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DALSecurity {

	public static final String DATASOURCETYPE = "oracleDAL";

	private static ApplicationContext applicationContext = new ClassPathXmlApplicationContext(
			"/com/wm/dal/jdbc/utils/test-nojta-beans.xml");
	private DataSource dataSource = (DataSource) applicationContext
			.getBean(DATASOURCETYPE);

	private Logger logger = Logger.getLogger(DALSecurity.class.getName());

	public static final String ENVPOOLCONFTABNAME = "SECURITY.DAL_ENV_POOL_CONFIG";
	public static final String RULECONFTABNAME = "SECURITY.DAL_RULE_CONFIG";
	public static final String RULEFIELDCONFTABNAME = "SECURITY.DAL_RULE_FIELD_CONFIG";

	public boolean addDalEnvPoolConfig(SecurityEnvPoolBean bean) {

		return this.addDalEnvPoolConfig(bean.getEnvironment(), bean
				.getPoolName(), bean.getRuleId());
	}

	public boolean addDalEnvPoolConfig(String environment, String poolName,
			int ruleId) {

		boolean success = false;
		Connection conn = null;
		PreparedStatement stmt = null;
		String sql = " insert into " + ENVPOOLCONFTABNAME
				+ " (environment,pool_name,rule_id) " + " values(?,?,?) ";
		try {
			conn = dataSource.getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, environment);
			stmt.setString(2, poolName);
			stmt.setInt(3, ruleId);
			stmt.executeUpdate();
			conn.commit();
			success = true;

		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			ex.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return success;

	}

	public boolean updateDalEnvPoolConfig(SecurityEnvPoolBean bean) {

		return this.updateDalEnvPoolConfig(bean.getEnvironment(), bean
				.getPoolName(), bean.getRuleId());
	}

	public boolean updateDalEnvPoolConfig(String environment, String poolName,
			int ruleId) {

		boolean success = false;
		Connection conn = null;
		PreparedStatement stmt = null;
		String sql = " update " + ENVPOOLCONFTABNAME + " set rule_id=? "
				+ " where environment=? and pool_name=?";
		try {
			conn = dataSource.getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, ruleId);
			stmt.setString(2, environment);
			stmt.setString(3, poolName);
			stmt.executeUpdate();
			conn.commit();
			success = true;

		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			ex.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return success;
	}

	public boolean deleteDalEnvPoolConfig(SecurityEnvPoolBean bean) {

		return this.deleteDalEnvPoolConfig(bean.getEnvironment(), bean
				.getPoolName());

	}

	public boolean deleteDalEnvPoolConfig(String environment, String poolName) {

		boolean success = false;
		Connection conn = null;
		PreparedStatement stmt = null;
		String sql = " delete from " + ENVPOOLCONFTABNAME
				+ " where environment=? and pool_name=?";
		try {
			conn = dataSource.getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, environment);
			stmt.setString(2, poolName);
			stmt.executeUpdate();
			conn.commit();
			success = true;

		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			ex.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return success;

	}

	public List searchAllDalEnvPoolConfig() {

		List result = new ArrayList();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = " select environment,pool_name,rule_id from "
				+ ENVPOOLCONFTABNAME;
		try {
			conn = dataSource.getConnection();
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			while (rs.next()) {
				SecurityEnvPoolBean bean = new SecurityEnvPoolBean();
				bean.setEnvironment(rs.getString(1));
				bean.setPoolName(rs.getString(2));
				bean.setRuleId(rs.getInt(3));
				result.add(bean);
			}

		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			ex.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return result;
	}

	public SecurityEnvPoolBean searchDalEnvPoolConfig(SecurityEnvPoolBean bean) {

		return this.searchDalEnvPoolConfig(bean.getEnvironment(), bean
				.getPoolName());
	}

	public SecurityEnvPoolBean searchDalEnvPoolConfig(String environment,
			String poolName) {

		SecurityEnvPoolBean result = null;
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = " select environment,pool_name,rule_id from "
				+ ENVPOOLCONFTABNAME + " where environment=? and pool_name=?";
		try {
			conn = dataSource.getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, environment);
			stmt.setString(2, poolName);
			rs = stmt.executeQuery();
			while (rs.next()) {
				SecurityEnvPoolBean bean = new SecurityEnvPoolBean();
				bean.setEnvironment(rs.getString(1));
				bean.setPoolName(rs.getString(2));
				bean.setRuleId(rs.getInt(3));
				result = bean;
			}

		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			ex.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return result;
	}
	
	public boolean addDalRuleConfig(SecurityRuleBean bean) {
		
		return this.addDalRuleConfig(bean.getRuleId(), bean.getRuleFile());
	}

	public boolean addDalRuleConfig(int ruleId, String ruleFile) {

		boolean success = false;
		Connection conn = null;
		PreparedStatement stmt = null;
		String sql = " insert into " + RULECONFTABNAME
				+ " (rule_id,rule_file) " + " values(?,?) ";
		try {
			conn = dataSource.getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, ruleId);
			stmt.setString(2, ruleFile);
			stmt.executeUpdate();
			conn.commit();
			success = true;

		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			ex.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return success;

	}

	public boolean updateDalRuleConfig(SecurityRuleBean bean) {
		
		return this.updateDalRuleConfig(bean.getRuleId(), bean.getRuleFile());
	}
	
	public boolean updateDalRuleConfig(int ruleId, String ruleFile) {

		boolean success = false;
		Connection conn = null;
		PreparedStatement stmt = null;
		String sql = " update " + RULECONFTABNAME + " set rule_file=? "
				+ " where rule_id=? ";
		try {
			conn = dataSource.getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, ruleFile);
			stmt.setInt(2, ruleId);
			stmt.executeUpdate();
			conn.commit();
			success = true;

		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			ex.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return success;
	}

	public boolean deleteDalRuleConfig(SecurityRuleBean bean) {
		
		return this.deleteDalRuleConfig(bean.getRuleId());
	}
	
	public boolean deleteDalRuleConfig(int ruleId) {

		boolean success = false;
		Connection conn = null;
		PreparedStatement stmt = null;
		String sql = " delete from " + RULECONFTABNAME + " where rule_id=?";
		try {
			conn = dataSource.getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, ruleId);
			stmt.executeUpdate();
			conn.commit();
			success = true;

		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			ex.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return success;

	}

	public List searchAllDalRuleConfig() {

		List result = new ArrayList();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = " select rule_id,rule_file from " + RULECONFTABNAME;
		try {
			conn = dataSource.getConnection();
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			while (rs.next()) {
				SecurityRuleBean bean = new SecurityRuleBean();
				bean.setRuleId(rs.getInt(1));
				bean.setRuleFile(rs.getString(2));
				result.add(bean);
			}

		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			ex.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return result;
	}

	public SecurityRuleBean searchDalRuleConfig(SecurityRuleBean bean) {

		return this.searchDalRuleConfig(bean.getRuleId());
	}

	public SecurityRuleBean searchDalRuleConfig(int ruleId) {

		SecurityRuleBean result = null;
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = " select rule_id,rule_file from "
				+ RULECONFTABNAME + " where rule_id=?";
		try {
			conn = dataSource.getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, ruleId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				SecurityRuleBean bean = new SecurityRuleBean();
				bean.setRuleId(rs.getInt(1));
				bean.setRuleFile(rs.getString(2));
				result = bean;
			}

		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			ex.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return result;
	}

	public boolean addDalRuleFieldConfig(SecurityRuleFieldBean bean) {
		
		return this.addDalRuleFieldConfig(bean.getRuleId(), bean.getFieldId(), 
				bean.getFieldValue());
	}
	
	public boolean addDalRuleFieldConfig(int ruleId, String fieldId,
			String fieldValue) {

		boolean success = false;
		Connection conn = null;
		PreparedStatement stmt = null;
		String sql = " insert into " + RULEFIELDCONFTABNAME
				+ " (rule_id,field_id,field_value) " + " values(?,?,?) ";
		try {
			conn = dataSource.getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, ruleId);
			stmt.setString(2, fieldId);
			stmt.setString(3, fieldValue);
			stmt.executeUpdate();
			conn.commit();
			success = true;

		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			ex.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return success;

	}

	public boolean updateDalRuleFieldConfig(SecurityRuleFieldBean bean) {
		
		return this.updateDalRuleFieldConfig(bean.getRuleId(), 
				bean.getFieldId(), bean.getFieldValue());
	}
	
	public boolean updateDalRuleFieldConfig(int ruleId, String fieldId,
			String fieldValue) {

		boolean success = false;
		Connection conn = null;
		PreparedStatement stmt = null;
		String sql = " update " + RULEFIELDCONFTABNAME + " set field_value=? "
				+ " where rule_id=? and field_id=?";
		try {
			conn = dataSource.getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, fieldValue);
			stmt.setInt(2, ruleId);
			stmt.setString(3, fieldId);
			stmt.executeUpdate();
			conn.commit();
			success = true;

		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			ex.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return success;
	}

	public boolean deleteDalRuleFieldConfig(SecurityRuleFieldBean bean) {
		
		return this.deleteDalRuleFieldConfig(bean.getRuleId(), bean.getFieldId());
	}
	
	public boolean deleteDalRuleFieldConfig(int ruleId, String fieldId) {

		boolean success = false;
		Connection conn = null;
		PreparedStatement stmt = null;
		String sql = " delete from " + RULEFIELDCONFTABNAME
				+ " where rule_id=? and field_id=?";
		try {
			conn = dataSource.getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, ruleId);
			stmt.setString(2, fieldId);
			stmt.executeUpdate();
			conn.commit();
			success = true;

		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			ex.printStackTrace();
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return success;
	}
	
	public List searchAllDalRuleFieldConfig() {

		List result = new ArrayList();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = " select rule_id,field_id,field_value from " + RULEFIELDCONFTABNAME;
		try {
			conn = dataSource.getConnection();
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			while (rs.next()) {
				SecurityRuleFieldBean bean = new SecurityRuleFieldBean();
				bean.setRuleId(rs.getInt(1));
				bean.setFieldId(rs.getString(2));
				bean.setFieldValue(rs.getString(3));
				result.add(bean);
			}

		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			ex.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return result;
	}
	
	public SecurityRuleFieldBean searchDalRuleFieldConfig(SecurityRuleFieldBean bean) {

		return this.searchDalRuleFieldConfig(bean.getRuleId(), bean.getFieldId());
	}

	public SecurityRuleFieldBean searchDalRuleFieldConfig(int ruleId, String fieldId) {

		SecurityRuleFieldBean result = null;
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		String sql = " select rule_id,field_id,field_value from "
				+ RULEFIELDCONFTABNAME + " where rule_id=? and field_id=?";
		try {
			conn = dataSource.getConnection();
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, ruleId);
			stmt.setString(2, fieldId);
			rs = stmt.executeQuery();
			while (rs.next()) {
				SecurityRuleFieldBean bean = new SecurityRuleFieldBean();
				bean.setRuleId(rs.getInt(1));
				bean.setFieldId(rs.getString(2));
				bean.setFieldValue(rs.getString(3));
				result = bean;
			}

		} catch (Exception ex) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			ex.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return result;
	}
	
}
