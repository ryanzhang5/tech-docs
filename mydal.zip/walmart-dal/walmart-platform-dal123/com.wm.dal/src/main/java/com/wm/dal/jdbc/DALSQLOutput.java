/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.jdbc;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DALSQLOutput - wraps a List{Object} and can be passed into SQLData.writeSQL() method.
 * Please note that this class does not perform any type conversions - it is left to the
 * caller to convert the attributes collected from the SQLData.writeSQL() method.
 *
 * @author mkishore
 * @since 1.1
 */
public class DALSQLOutput implements SQLOutput {
    private List<Object> attributes = new ArrayList<Object>();

    public Object[] getAttributes() {
        return attributes.toArray(new Object[attributes.size()]);
    }

    public void writeBoolean(boolean x) throws SQLException {
        attributes.add(x);
    }

    public void writeByte(byte x) throws SQLException {
        attributes.add(x);
    }

    public void writeShort(short x) throws SQLException {
        attributes.add(x);
    }

    public void writeInt(int x) throws SQLException {
        attributes.add(x);
    }

    public void writeLong(long x) throws SQLException {
        attributes.add(x);
    }

    public void writeFloat(float x) throws SQLException {
        attributes.add(x);
    }

    public void writeDouble(double x) throws SQLException {
        attributes.add(x);
    }

    public void writeBigDecimal(BigDecimal x) throws SQLException {
        attributes.add(x);
    }

    public void writeString(String x) throws SQLException {
        attributes.add(x);
    }

    public void writeBytes(byte[] x) throws SQLException {
        attributes.add(x);
    }

    public void writeDate(Date x) throws SQLException {
        attributes.add(x);
    }

    public void writeTime(Time x) throws SQLException {
        attributes.add(x);
    }

    public void writeTimestamp(Timestamp x) throws SQLException {
        attributes.add(x);
    }

    public void writeURL(URL x) throws SQLException {
        attributes.add(x);
    }

    public void writeObject(SQLData x) throws SQLException {
        attributes.add(x);
    }

    public void writeBlob(Blob x) throws SQLException {
        attributes.add(x);
    }

    public void writeClob(Clob x) throws SQLException {
        attributes.add(x);
    }

    public void writeStruct(Struct x) throws SQLException {
        attributes.add(x);
    }

    public void writeArray(Array x) throws SQLException {
        attributes.add(x);
    }

    // the following methods are not supported

    public void writeCharacterStream(Reader x) throws SQLException {
        throw new SQLException("Method not implemented");
    }

    public void writeAsciiStream(InputStream x) throws SQLException {
        throw new SQLException("Method not implemented");
    }

    public void writeBinaryStream(InputStream x) throws SQLException {
        throw new SQLException("Method not implemented");
    }

    public void writeRef(Ref x) throws SQLException {
        throw new SQLException("Method not implemented");
    }

    public void writeNString(String x) throws SQLException {
        throw new SQLException("Method not implemented");
    }

    public void writeNClob(NClob x) throws SQLException {
        throw new SQLException("Method not implemented");
    }

    public void writeRowId(RowId x) throws SQLException {
        throw new SQLException("Method not implemented");
    }

    public void writeSQLXML(SQLXML x) throws SQLException {
        throw new SQLException("Method not implemented");
    }

}
