/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 */

package com.wm.dal.server.nio;

import java.nio.channels.SelectionKey;

/**
 * 
 * @author cshah
 */
public interface Handler {
    /**
     * 
     * @param sk
     * @throws Exception
     */
    void handle(SelectionKey sk) throws Exception;
}

