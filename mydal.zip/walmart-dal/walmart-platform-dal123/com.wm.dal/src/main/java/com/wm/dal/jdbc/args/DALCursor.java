/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc.args;


import com.wm.dal.jdbc.DALRow;
import com.wm.dal.jdbc.DALResultSetMetaData;

import com.wm.dal.util.DALLogger;

import java.io.Serializable;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.List;


/**
 * @author cshah
 * @version 1.0
 */
public class DALCursor extends DALArgs implements Serializable {
    private int currRowIndex  = 0;
    private int curSorID;
    private List<DALRow> rowList = null;
    //private Iterator<DALRow> rsIterator = null;
    private DALResultSetMetaData rsmd = null;
    private boolean rsFullyRead = false;
    private int resultSetType = ResultSet.TYPE_FORWARD_ONLY;
    private int concurrency = ResultSet.CONCUR_READ_ONLY;
    static final DALLogger logger = DALLogger.getInstance();    
    
    /**
     * 
     * @param position
     * @param type
     */
    public DALCursor(int position, int type) {
        init( position ,type);
    }
    
    /**
     * 
     * @param cursorID
     * @param position
     * @param type
     * @param row
     * @param rsmd
     * @param resultSetType
     * @param concurrency
     */
    public DALCursor(int cursorID, int position, int type, List<DALRow> row, DALResultSetMetaData rsmd, int resultSetType, int concurrency) {
        init( position ,type);
        this.curSorID = cursorID;
        this.currRowIndex  = 0;
        this.rowList = row;
        this.rsmd = rsmd;
        //rsIterator = rowList.iterator();
        this.resultSetType = resultSetType;
        this.concurrency = concurrency;
    }

    /**
     * 
     * @param position
     * @param type
     */
    protected void init( int position, int type ) {
        super.init( position, true, false, type );
        //super.init( position, true, false, oracle.jdbc.OracleTypes.CURSOR );
        currRowIndex  = 0;
    }

    /**
     * 
     * @return
     * @throws SQLException
     */
    public boolean hasNext()  throws SQLException {
        return (currRowIndex+1 <= rowList.size());
    }

    /**
     * 
     * @return
     * @throws SQLException
     */
    public boolean next()  throws SQLException {
        if ( hasNext() ) {
            currRowIndex++;
            return true;
        }
        return false;    
    }
    
    /**
     * 
     * @return
     * @throws SQLException
     */
    public int getRowIndex()  throws SQLException {
        return this.currRowIndex;
    }

    /**
     * 
     * @return
     * @throws SQLException
     */
    public DALRow getRow()  throws SQLException {
        return rowList.get(currRowIndex-1);
    }

    /**
     * 
     * @return
     */
    public DALResultSetMetaData getMetaData() throws SQLException {
        if (rsmd == null) {
            throw new SQLException("No ResultSetMetaData found");
        } else {
            return this.rsmd;
        }
    }    


    /**
     * 
     * @return
     */
    public String toString() { 
        String retString = "";
        try {
            retString = super.toString() + 
            ", colCount = " + ( rsmd != null ? rsmd.getColumnCount() : null) + 
            ", rowCount = " + (rowList != null ?rowList.size() : null); 
        } catch (Exception exp) {
            exp.printStackTrace();
        }
        return retString ;
    }

    /**
     * 
     * @param value
     * @throws SQLException
     */
    public void setValueObject(Object value) throws SQLException {
        if (value != null && value instanceof List)
            rowList = (List<DALRow>)value;
    }
    
    /**
     * 
     * @return
     */
    public Object getValueObject() { 
        return rowList; 
    }

    /**
     * 
     * @param cursor
     * @throws SQLException
     */
    public void addRows(DALCursor cursor) throws SQLException {
        if (cursor != null)
            rowList.addAll(cursor.getRows());
        logger.info("TOTAL RECORD SIZE : " + rowList.size() );   
    }

    /**
     * 
     * @return
     */
    private List<DALRow> getRows() {
        return this.rowList;
    }

    /**
     * 
     * @param rsFullyRead
     */
    public void setRsFullyRead(boolean rsFullyRead) {
        this.rsFullyRead = rsFullyRead;
    }

    /**
     * 
     * @return
     */
    public boolean isRsFullyRead() {
        return rsFullyRead;
    }

    /**
     * 
     * @return
     */
    public int getResultSetType() {
        return resultSetType;
    }

    /**
     * 
     * @return
     */
    public int getConcurrency() {
        return concurrency;
    }

    /**
     * 
     * @return
     */
    public int getCurSorID() {
        return curSorID;
    }

    /**
     * 
     */
    public void clearALL() {
        currRowIndex  = 0;
        rsmd = null;
        rowList.clear();
        rowList = null;
    }    
}


