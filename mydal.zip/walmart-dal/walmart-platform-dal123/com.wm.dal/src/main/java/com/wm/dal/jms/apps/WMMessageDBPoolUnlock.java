package com.wm.dal.jms.apps;

import java.util.HashMap;

import com.wm.weblib.jms.WMMessageType;
import com.wm.weblib.jms.WMMessageException;

public class WMMessageDBPoolUnlock extends WMMessageDBPool {

	public WMMessageDBPoolUnlock(String target, String poolType)
	{
		super(WMMessageType.MSG_TYPE_UNLOCK_DB_POOL, target, poolType);
	}

	public WMMessageDBPoolUnlock(HashMap valueMap)
		throws WMMessageException
	{
		super(WMMessageType.MSG_TYPE_UNLOCK_DB_POOL, valueMap);
	}


}
