/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther Chirag Shah
 * @since 9.6
 */

package com.wm.dal.server;

import com.wm.corelib.concurrent.WMThreadPoolExecutor;
import com.wm.corelib.concurrent.WMThreadPoolManager;
import com.wm.corelib.concurrent.WMThreadPoolExecutor.PoolType;

import com.wm.dal.util.DALLogger;

/**
 * 
 * @author cshah
 * @version 1.0
 */
public class ThreadPoolManager {
    private static final DALLogger logger = DALLogger.getInstance();
    private static final ThreadPoolManager instance = new ThreadPoolManager();
    private static WMThreadPoolManager wmthreadPoolManager;
    private static WMThreadPoolExecutor wmthreadPoolExecutor;
    private static WMThreadPoolExecutor jmxthreadPoolExecutor;
  
    /**
     * 
     */
    private ThreadPoolManager() {
        try {
            wmthreadPoolManager = new WMThreadPoolManager();
            logger.log( DALLogger.LEVEL_SEVERE, "WMThread Pool Manager Created...");
            wmthreadPoolManager.init();
            logger.log( DALLogger.LEVEL_SEVERE, "WMThread Pool Manager init() Method Called...");
            wmthreadPoolExecutor = WMThreadPoolManager.getPool(); 
            jmxthreadPoolExecutor = WMThreadPoolManager.getPool(PoolType.CPU_BOUND);
            logger.log( DALLogger.LEVEL_SEVERE, "WM Thread Pool Executor getPool() Method Called...");
        } catch (Exception exp) {
            logger.log( DALLogger.LEVEL_SEVERE,  getClass().getName() + "/ThreadPoolManager(): caught exception while creating  ThreadPoolManager." + exp.getMessage() );
            exp.printStackTrace();
        }
    }

    /**
     * 
     * @return
     */
    public static ThreadPoolManager getInstance() {
        return instance;
    }


    /**
     * @return
     */
    public WMThreadPoolManager getWMThreadPoolManager() {
        return wmthreadPoolManager;
    }

    /**
     * @return
     */
    public WMThreadPoolExecutor getWMThreadPoolExecutor() {
        return wmthreadPoolExecutor;
    }

    /**
     * @return
     */
    public WMThreadPoolExecutor getJMXThreadPoolExecutor() {
        return jmxthreadPoolExecutor;
    }

}

