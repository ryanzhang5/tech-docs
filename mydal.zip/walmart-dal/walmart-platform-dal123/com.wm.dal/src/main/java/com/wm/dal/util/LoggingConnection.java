package com.wm.dal.util;

import java.lang.reflect.Method;
import java.sql.*;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * Wraps a java.sql.Connection inside a decorator which logs all the
 * activities of that connection (including data passed in/out of the
 * prepared statements and result sets).
 *
 * This class is just a convenience wrapper for @see LoggingDecorator
 * (which is a general-purpose decorator which can wrap around *any*
 * interface to provide logging) which helps you by declaring a logging
 * policy appropriate to most common uses of Connection.
 *
 * ASSUMPTIONS AND LIMITATIONS --- IMPORTANT:
 *
 * This utility makes the assumption that the return values of the getObject() methods
 * of CallableStatement are being cast to a ResultSet.  If this is not true, this utility
 * may fail to log your data, and/or you may obtain a ClassCastException.  In this
 * case, you should use a different policy which does not use "WRAP_RESULT" for
 * the getObject() calls.
 *
 */
public class LoggingConnection {
    private static final Logger logger = Logger.getLogger(LoggingConnection.class.getName());
    /**
     * A LoggingDecorator.PolicySet with the following features:
     *  -- Flushing of the log buffer is delayed until the connection is closed
     *     so that you only get one log entry instead of dozens
     *  -- Statements obtained by "prepareCall()" will also be wrapped in a
     *     LoggingDecorator
     *  -- ResultSets obtained by "getObject()" will also be wrapped in a LoggingDecorator.
     */
    private static LoggingDecoratorPolicy CONNECTION_POLICY_SET;

    static {
        CONNECTION_POLICY_SET = new LoggingDecoratorPolicy();

        try {
            CONNECTION_POLICY_SET.addPolicy(Connection.class,
                                            LoggingDecoratorPolicy.NO_FLUSH +
                                            LoggingDecoratorPolicy.LOG_RESULT);
            CONNECTION_POLICY_SET.addPolicy(Statement.class,
                                            LoggingDecoratorPolicy.NO_FLUSH +
                                            LoggingDecoratorPolicy.LOG_RESULT);
            CONNECTION_POLICY_SET.addPolicy(CallableStatement.class,
                                            LoggingDecoratorPolicy.NO_FLUSH +
                                            LoggingDecoratorPolicy.LOG_RESULT);
            CONNECTION_POLICY_SET.addPolicy(PreparedStatement.class,
                                            LoggingDecoratorPolicy.NO_FLUSH +
                                            LoggingDecoratorPolicy.LOG_RESULT);
            CONNECTION_POLICY_SET.addPolicy(ResultSet.class,
                                            LoggingDecoratorPolicy.NO_FLUSH +
                                            LoggingDecoratorPolicy.LOG_RESULT);
            CONNECTION_POLICY_SET.addPolicy(Connection.class.getMethod("close",
                                                                       new Class[0]),
                                            LoggingDecoratorPolicy.LOG_RESULT);
            CONNECTION_POLICY_SET.addPolicy(CallableStatement.class.getMethod("getObject",
                                                                              new Class[] {
                                                                                  Integer.TYPE
                                                                              }),
                                            LoggingDecoratorPolicy.NO_FLUSH +
                                            LoggingDecoratorPolicy.LOG_RESULT +
                                            LoggingDecoratorPolicy.WRAP_RESULT);
            CONNECTION_POLICY_SET.addPolicy(CallableStatement.class.getMethod("getObject",
                                                                              new Class[] {
                                                                                  Integer.TYPE,
                                                                                  Map.class
                                                                              }),
                                            LoggingDecoratorPolicy.NO_FLUSH +
                                            LoggingDecoratorPolicy.LOG_RESULT +
                                            LoggingDecoratorPolicy.WRAP_RESULT);
            CONNECTION_POLICY_SET.addPolicy(CallableStatement.class.getMethod("getObject",
                                                                              new Class[] {
                                                                                  String.class
                                                                              }),
                                            LoggingDecoratorPolicy.NO_FLUSH +
                                            LoggingDecoratorPolicy.LOG_RESULT +
                                            LoggingDecoratorPolicy.WRAP_RESULT);
            CONNECTION_POLICY_SET.addPolicy(CallableStatement.class.getMethod("getObject",
                                                                              new Class[] {
                                                                                  String.class,
                                                                                  Map.class
                                                                              }),
                                            LoggingDecoratorPolicy.NO_FLUSH +
                                            LoggingDecoratorPolicy.LOG_RESULT +
                                            LoggingDecoratorPolicy.WRAP_RESULT);
            CONNECTION_POLICY_SET.addPolicy(CallableStatement.class.getMethod("getResultSet",
                                                                              new Class[] {
                                                                                  
                                                                              }),
                                            LoggingDecoratorPolicy.NO_FLUSH +
                                            LoggingDecoratorPolicy.LOG_RESULT +
                                            LoggingDecoratorPolicy.WRAP_RESULT);
            CONNECTION_POLICY_SET.addPolicy(Statement.class.getMethod("getResultSet",
                                                                      new Class[] {
                                                                          
                                                                      }),
                                            LoggingDecoratorPolicy.NO_FLUSH +
                                            LoggingDecoratorPolicy.LOG_RESULT +
                                            LoggingDecoratorPolicy.WRAP_RESULT);
            CONNECTION_POLICY_SET.addPolicy(PreparedStatement.class.getMethod("getResultSet",
                                                                              new Class[] {
                                                                                  
                                                                              }),
                                            LoggingDecoratorPolicy.NO_FLUSH +
                                            LoggingDecoratorPolicy.LOG_RESULT +
                                            LoggingDecoratorPolicy.WRAP_RESULT);
            CONNECTION_POLICY_SET.addPolicy(Connection.class.getMethod("prepareCall",
                                                                       new Class[] {
                                                                           String.class
                                                                       }),
                                            LoggingDecoratorPolicy.NO_FLUSH +
                                            LoggingDecoratorPolicy.LOG_RESULT +
                                            LoggingDecoratorPolicy.WRAP_RESULT);
            CONNECTION_POLICY_SET.addPolicy(Connection.class.getMethod("prepareStatement",
                                                                       new Class[] {
                                                                           String.class
                                                                       }),
                                            LoggingDecoratorPolicy.NO_FLUSH +
                                            LoggingDecoratorPolicy.LOG_RESULT +
                                            LoggingDecoratorPolicy.WRAP_RESULT);
        } catch (Exception e) {
            // Should never happen.  But let's not allow this exception to crash the class initialization.
            logger.log(Level.WARNING, "DEFAULT ERROR MSG", e);
            CONNECTION_POLICY_SET = new LoggingDecoratorPolicy();
        }
    }

    /**
     * Wrap the given connection in a decorator which will cause method calls (and input/output values)
     * of the given Connection and its Statements and ResultSets to be logged to the given logger.
     *
     * @param conn    The connection to be wrapped
     * @param logger  The logger to which method calls will be reported
     * @param level   The log level at which method calls will be reported
     * @return  A Connection which enhances the original Connection by performing logging
     */
    public static Connection getInstance(Connection conn, Logger logger,
                                         Level level) {
        return (Connection) LoggingDecorator.newInstance(conn, logger, level,
                                                         CONNECTION_POLICY_SET);
    }
}
