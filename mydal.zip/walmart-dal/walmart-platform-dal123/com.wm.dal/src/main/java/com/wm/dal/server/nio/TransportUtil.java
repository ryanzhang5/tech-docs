/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 */

package com.wm.dal.server.nio;

import com.wm.dal.client.IDALRequest;
import com.wm.dal.client.IDALResponse;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import java.nio.ByteBuffer;

/**
 * 
 * @author cshah
 */
public class TransportUtil {
    private static final String POSTFIX = "DAL";
    private static final char POSTFIX_CARRAY[] = POSTFIX.toCharArray();
    
    /**
     * 
     * @param bb
     * @return
     */
    public static boolean isComplete(ByteBuffer bb) {
        if (bb == null)
            return false;
            
        boolean requestcomplete = false;
        int p = bb.position() - POSTFIX.length();
        
        if (p < 0) {
            requestcomplete = false;
            return requestcomplete ;
        }
        
        requestcomplete  = false;

        for (int i=0 ; i<POSTFIX.length(); i++) {
            if (bb.get(p+i) == POSTFIX_CARRAY[i]) {
                requestcomplete = true;
            } else {
                requestcomplete = false;
                break;
            }
        }
        return requestcomplete ;
    }

    /**
     * 
     * @param bb
     * @return
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public static IDALRequest readDALRequest(ByteBuffer bb) throws IOException,ClassNotFoundException {
        int limit = bb.limit();
        byte[] barray = new byte[limit-POSTFIX.length()];
        bb.get(barray,0,limit-POSTFIX.length());
        bb.clear();
        InputStream is = new ByteArrayInputStream(barray);
        ObjectInputStream ois = new ObjectInputStream(is);
        Object obj = ois.readObject();
        if (obj instanceof IDALRequest) {
            return (IDALRequest)obj;
        } else {
            System.out.println("Error loading another class");
            obj.toString();
        }

        return null;        
    }    

    /**
     * 
     * @param bb
     * @return
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public static IDALResponse readDALResponse(ByteBuffer bb) throws IOException, ClassNotFoundException {   
        int limit= bb.limit();
        byte[] barray = new byte[limit-POSTFIX.length()];
        bb.get(barray,0,limit-POSTFIX.length());
        ByteArrayInputStream bis = new ByteArrayInputStream(barray);
        ObjectInputStream ois = new ObjectInputStream(bis) ;
        Object obj = ois.readObject();
        if (obj instanceof IDALResponse) {
            return (IDALResponse)obj;
        } else {
            System.out.println("Error loading another class");
            obj.toString();
        }
        
        return null;            
    }

    /**
     * 
     * @param response
     * @return
     * @throws IOException
     */
    public static ByteBuffer createResponseAsByteBuffer(IDALResponse response) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos =  new ObjectOutputStream(baos);
        oos.writeObject(response);
        oos.close();
        baos.write(POSTFIX.getBytes());
        
        ByteBuffer bb = ByteBuffer.wrap(baos.toByteArray());
        return bb;
    }    

    /**
     * 
     * @param request
     * @return
     * @throws Exception
     */
    public static ByteBuffer createRequestAsByteBuffer(IDALRequest request) throws Exception {
        ByteArrayOutputStream bb =new ByteArrayOutputStream();
        ObjectOutputStream objs = new ObjectOutputStream(bb);
        objs.writeObject(request);

        ByteBuffer bytebuffer = ByteBuffer.allocate(bb.size() + POSTFIX.length());
        //bytebuffer.putInt(bb.size());
        bytebuffer.put(bb.toByteArray());
        bytebuffer.put(POSTFIX.getBytes());
        bytebuffer.flip();
                
        bb.close();
        objs.close();
        
        return bytebuffer;
    }
}