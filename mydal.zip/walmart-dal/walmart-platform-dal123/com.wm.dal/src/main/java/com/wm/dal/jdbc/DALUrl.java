/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc;

import com.wm.dal.jdbc.utils.Constants;

import java.sql.SQLException;
import java.util.StringTokenizer;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 * 
 * @author cshah
 * @version 1.0
 */
public class DALUrl {
    private static final Logger logger = Logger.getLogger(DALUrl.class.getName());

    private static final String HOSTNAME_DELIM = ",";

    private String rawUrl;
    private String[] urls;
    private String aliasName;
    private String user;
    private String password;
    private int urlIndex;

    /**
     * 
     * @param url
     * @param aliasName
     * @param user
     * @param password
     * @throws SQLException
     */
    public DALUrl(String url, String aliasName, String user, String password) throws SQLException {
        List<String> list = new ArrayList<String>();
        StringTokenizer tokenizer = new StringTokenizer(url, HOSTNAME_DELIM);
        while (tokenizer.hasMoreTokens()) {
            list.add(tokenizer.nextToken().trim());
        }
        this.rawUrl = url;
        this.urls = list.toArray(new String[list.size()]);
        this.urlIndex = 0;
        this.aliasName = aliasName;
        this.user = user;
        this.password = password;
    }

    /**
     * Returns the raw (unmodified) url
     */
    public String getRawUrl() {
        return rawUrl;
    }

    /**
     * Returns the "active" url
     */
    public String getUrl() {
        if (urlIndex >=0 && urlIndex < urls.length) {
            return urls[urlIndex];
        } else {
            return null;
        }
    }

    /**
     * Allows a client to mark the "active" url as un-reachable, and try the next URL
     * - if one is available.
     * NOTE:
     * - current implementation does not need hooks to reset the counter - its a one pass impl.
     * - there is no fail-back for a given connection. we assume that the pool will gradually failback
     *   as new Connections will use new DALUrl instances.
     */
    public boolean failover() {
        if (urlIndex+1 < urls.length) {
            logger.warning("Failing over DAL from [" + urls[urlIndex] + "] to [" + urls[urlIndex+1] + "]");
            urlIndex++;
            return true;
        } else {
            return false;
        }
    }

    /**
     * Returns the target hostname - based on the "active" url
     */
    public String getHost() throws SQLException {
        return Constants.getHost(getUrl());
    }

    /**
     * Returns the target port number - based on the "active" url
     */
    public int getPort() throws SQLException {
        return Constants.getPort(getUrl());
    }

    /**
     * 
     * @return
     */
    public String getUser() {
        return user;
    }

    /**
     * 
     * @return
     */
    public String getPassword() {
        return password;
    }

    /**
     * 
     * @return
     */
    public String[] getUrls() {
        return urls;
    }

    /**
     * 
     * @return
     */
    public String getAliasName() {
        return aliasName;
    }
    
    public String
    toString() {
    	return aliasName+" --> "+rawUrl;
    }
}
