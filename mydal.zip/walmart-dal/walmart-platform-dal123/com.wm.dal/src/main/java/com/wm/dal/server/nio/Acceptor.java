/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 */

package com.wm.dal.server.nio;

import java.io.*;
import java.nio.channels.*;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * 
 * @author cshah
 */
public class Acceptor implements Runnable {
    private ServerSocketChannel serverSocketChannel;
    protected static final DispatcherPool readDispatcherPool = new DispatcherPool(NIOConf.getReadSelector(), "Read Dispatcher");
    private static final int TIMEOUT = NIOConf.getConnectionTimeout();
    private static final boolean ISBLOCKING = false;
    private static final BlockingQueue<SocketChannel> socketQueue = new LinkedBlockingQueue<SocketChannel>();
    
    /**
     * Acceptor
     * @param ssc -- ServerSocketChannel
     */
    public Acceptor(ServerSocketChannel ssc) {
        this.serverSocketChannel = ssc;
        Runnable runnable = new Runnable() {
                public void run() {
                try {
                        while (true) {
                            try {
                                SocketChannel sc = socketQueue.take();
                                ChannelIO cio = ChannelIO.getInstance(sc, ISBLOCKING);
                                RequestHandler rh = new RequestHandler(cio);
                                readDispatcherPool.nextDispatcher().register(cio.getSocketChannel(), SelectionKey.OP_READ, rh);
                            } catch (Exception exp) {exp.printStackTrace();}
                        }
                } catch (Exception exp) {
                    exp.printStackTrace();
                }//catch
            }//run
        };

        Thread requestDispatcherThread = new Thread(runnable);
        requestDispatcherThread.setName("request-dispatcher-thread");
        requestDispatcherThread.start();
    }

    /**
     * Run method
     */
    public void run() {
        for (;;) {
            try {
                SocketChannel sc = serverSocketChannel.accept();
                sc.socket().setSoTimeout(TIMEOUT);
                socketQueue.offer(sc);
            } catch (IOException x) {
                System.err.println("DAL/NIO Server Terminated with following exception...");
                x.printStackTrace();
                System.exit(1);
            } catch (Exception x) {
                System.err.println("DAL/NIO Server Terminated with following exception...");
                x.printStackTrace();
                System.exit(1);
            }            
        }
    }
}
