package com.wm.dal.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * A class which wraps an arbitrary object, exposes the same interfaces
 * as the original object, and causes the object's method calls
 * (or, more accurately, the interfaces' method calls) to be logged.
 *
 * IMPORTANT LIMITATION:
 * This wrapper is implemented using Java's Dynamic Proxy mechanism to
 * expose all the same interfaces as the original object.  The wrapper can be
 * cast to any of these interfaces.  However, the wrapper cannot be cast
 * to the *class* of the original object --- only to one of its interfaces.
 *
 * SAMPLE USAGE:
 *
 *    interface Animal {
 *       public Animal createOffspring(Animal mate);
 *    }
 *
 *    Animal dog = new Dog();
 *
 *    // Wrap in a LoggingDecorator to make method calls logged
 *    dog = LoggingDecorator.newInstance(dog, logger, Level.INFO);
 *
 *    // This method call will now be logged.
 *    Animal puppy = dog.createOffspring(mate);
 *
 * OPTIONS
 *
 * You can modify the logging behavior by specifying a @see LoggingDecoratorPolicy.
 * Options include:
 *
 *    * Logging / not logging certain methods
 *    * Not flushing the log after each method call, so that several method
 *      calls can be combined into one log entry
 *    * Wrapping the output of certain methods in their own LoggingDecorator
 *    * Logging / not logging the return values of methods.
 *
 * By default, the LoggingDecoratorPolicy.DEFAULT will be used, which specifies:
 *
 *    * All methods are logged
 *    * A separate log entry will be created for each method call
 *    * Return values are not logged
 *    * The output objects of methods do not get wrapped in their own LoggingDecorators.
 */
public class LoggingDecorator implements java.lang.reflect.InvocationHandler {
    /** the object being wrapped */
    private Object obj;

    /** the logger to which data will be sent */
    private Logger logger;

    /** the log level; if the logger is not loggable at this level, then nothing will be logged */
    private Level level;

    /** A StringBuffer to cache the results if we are combining multiple method calls into a single log entry */
    private StringBuffer sb;

    /** The policies which may affect our behavior */
    private LoggingDecoratorPolicy policy;

    /**
     * Clients never use this constructor (or any other) directly.  This class
     * is meant to be used with Java's dynamic proxy mechanism, so the
     * Proxy.newProxyInstance() method needs to be used.
     * @see newInstance(Object, Logger,Level,LoggingDecoratorPolicy,StringBuffer)
     */
    private LoggingDecorator(Object obj, Logger logger, Level level,
                             LoggingDecoratorPolicy policy, StringBuffer sb) {
        if (policy == null) {
            policy = LoggingDecoratorPolicy.DEFAULT;
        }

        this.obj = obj;
        this.logger = logger;
        this.level = level;
        this.policy = policy;
        this.sb = sb;
    }

    /**
     * Wrap the given object inside a decorator which will log all its
     * method calls to the given logger at the given log level.
     * The returned object implements all the same interfaces as the
     * original (but is not of the same class).  The default LoggingDecoratorPolicy
     * is used.
     *
     * @param obj    The original object being wrapped.
     * @param logger The logger to which method calls will be logged.
     * @param level  The logging level at which we will log the method calls.
     * @return       The decorator object which wraps the original object and
     *               provides logging behavior; this object implements all
     *               the same interfaces as the original (but is not of the same class).
     */
    public static Object newInstance(Object obj, Logger logger, Level level) {
        return LoggingDecorator.newInstance(obj, logger, level,
                                            LoggingDecoratorPolicy.DEFAULT);
    }

    /**
     * Wrap the given object inside a decorator which will log all its
     * method calls to the given logger at the given log level with the given policy.
     * The returned object implements all the same interfaces as the
     * original (but is not of the same class).
     *
     * @param obj    The original object being wrapped.
     * @param logger The logger to which method calls will be logged.
     * @param level  The logging level at which we will log the method calls.
     * @param policy The LoggingDecoratorPolicy which determines which methods are logged, etc.
     * @return       The decorator object which wraps the original object and
     *               provides logging behavior; this object implements all
     *               the same interfaces as the original (but is not of the same class).
     */
    public static Object newInstance(Object obj, Logger logger, Level level,
                                     LoggingDecoratorPolicy policy) {
        return LoggingDecorator.newInstance(obj, logger, level, policy,
                                            new StringBuffer());
    }

    /**
     * Wrap the given object inside a decorator which will log all its
     * method calls to the given logger at the given log level with the given policy.
     * The given StringBuffer is used to cache the results between method calls.
     * The returned object implements all the same interfaces as the
     * original (but is not of the same class).
     *
     * @param obj    The original object being wrapped.
     * @param logger The logger to which method calls will be logged.
     * @param level  The logging level at which we will log the method calls.
     * @param policy The LoggingDecoratorPolicy which determines which methods are logged, etc.
     * @return       The decorator object which wraps the original object and
     *               provides logging behavior; this object implements all
     *               the same interfaces as the original (but is not of the same class).
     */
    private static Object newInstance(Object obj, Logger logger, Level level,
                                      LoggingDecoratorPolicy policy,
                                      StringBuffer sb) {
        Object rv = java.lang.reflect.Proxy.newProxyInstance(obj.getClass()
                                                                .getClassLoader(),
                                                             
        //obj.getClass().getInterfaces(),
        get_ALL_Interfaces(obj.getClass()),
                                                             new LoggingDecorator(obj,
                                                                                  logger,
                                                                                  level,
                                                                                  policy,
                                                                                  sb));

        return rv;
    }

    /**
     * Find all interfaces exposed by the given class.
     *
     * Unfortunately Class.getInterfaces() only returns the interfaces that
     * the given class declares, not the interfaces which the superclasses
     * also declare.  Fix this by examining the superclasses too.
     * @param c   Class to examine
     * @return    All interfaces implemented by the class
     */
    private static Class[] get_ALL_Interfaces(Class c) {
        HashSet v = new HashSet();

        while (c != null) {
            v.addAll(Arrays.asList(c.getInterfaces()));
            c = c.getSuperclass();
        }

        return (Class[]) v.toArray(new Class[v.size()]);
    }

    /**
     * Handle an invocation of one of this proxy's methods.
     * Because the purpose of this proxy is to log method calls,
     * we will (1) record the method inputs, (2) invoke the original
     * method, (3) record the method outputs, (4) if necessary,
     * wrap the output in its own proxy, (5) send the method
     * inputs/outputs to the logger, (6) pass the method's return
     * value back to the client.
     *
     * @param proxy    Ignored; the proxy object.
     * @param m        The method being called.
     * @param args     The arguments of the method being called.
     * @return         The return value of the original method.
     * @throws Throwable
     */
    public Object invoke(Object proxy, Method m, Object[] args)
                  throws Throwable
    {
        Object result;

        try {
            log(m, args);

            result = m.invoke(obj, args);

            logResult(m, result);

            if (policy.isWrapResult(m)) {
                result = newInstance(result, logger, level, policy, sb);
            }
        } catch (InvocationTargetException e) {
            throw e.getTargetException();
        } catch (Exception e) {
            throw new RuntimeException("unexpected invocation exception: " +
                                       e.getMessage(),e);
        } finally {
        System.currentTimeMillis();}

        return result;
    }

    private void log(Method m, Object[] args) {
        if (!logger.isLoggable(level)) {
            return;
        }

        try {
            String methodName = m.getName();

            if (policy.isLog(m)) {
                sb.append("\n");
                sb.append(m.getDeclaringClass().getName());
                sb.append(".");
                sb.append(methodName);
                sb.append("(");

                if (args != null) {
                    for (int i = 0; i < args.length; i++) {
                        if (i > 0) {
                            sb.append(",");
                        }

                        Object arg = args[i];
                        boolean isString = ((arg != null) &&
                                           arg instanceof String);

                        if (isString) {
                            sb.append("\"");
                        }

                        sb.append(args[i]);

                        if (isString) {
                            sb.append("\"");
                        }
                    }
                }

                sb.append(")");
            }
        } catch (Exception e) {
            sb.append("?????exception thrown during logging??????");
        }
    }

    private void logResult(Method m, Object result) {
        if (!logger.isLoggable(level)) {
            return;
        }

        try {
            if (policy.isLogResult(m) && !Void.TYPE.equals(m.getReturnType())) {
                sb.append(" -> ");
                sb.append(result);
            }

            if (policy.isFlush(m)) {
                sb.append("\n");
                logger.log(level, sb.toString());
                sb.setLength(0);
            }
        } catch (Exception e) {
            sb.append("?????exception thrown during logging??????");
        }
    }
}
