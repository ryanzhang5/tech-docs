/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.rulesproviders;

import com.wm.dal.router.IRouter;
import com.wm.dal.router.plugins.default_.IRoutingRulesProvider;
import com.wm.sql.DataAccess;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Map;
import java.util.HashMap;
  
import com.wm.corelib.config.AppConfig;

/**
 * DBBasedRulesProvider - fetches the routing rules from the database.
 * The database needs to have the following tables in it:
 * <p/>
 * create table dal_rule_config (
 *   rule_id numeric(3) not null,
 *   rule_file varchar2(4000) not null,
 *   modified_dtm date not null,
 *   constraint rule_id_pk PRIMARY KEY(rule_id)
 * );
 *
 * create table dal_env_router_config (
 *   env_router_id numeric(3) not null,
 *   environment varchar2(10) not null,
 *   router_name varchar2(50) not null,
 *   rule_id numeric(3) not null,
 *   constraint env_router_pk PRIMARY KEY(env_router_id),
 *   constraint rule_id_fk FOREIGN KEY(rule_id) references dal_rule_config (rule_id)
 * );
 *
 * create table dal_rule_field_config (
 *   env_router_id numeric(3) not null,
 *   field_name varchar2(50) not null,
 *   field_value varchar2(100),
 *   constraint rule_field_pk PRIMARY KEY(env_router_id,field_name),
 *   constraint rule_field_fk FOREIGN KEY(env_router_id) references dal_env_router_config (env_router_id)
 * );
 *
 *  * @author mkishore
 * @since 1.1
 */
public class DBBasedRulesProvider implements IRoutingRulesProvider {
    private static final Logger logger = Logger.getLogger(DBBasedRulesProvider.class.getName());

    private static final String RULE_SQL = " select derc.env_router_id, drc.rule_file, drc.modified_dtm" +
            " from dal_env_router_config derc, dal_rule_config drc" +
            " where derc.rule_id = drc.rule_id" +
            " and derc.env_name = ?" +
            " and derc.router_name = ?"
            ;
    private static final String FIELD_SQL = "select field_name, field_value" +
            " from dal_rule_field_config" +
            " where env_router_id = ?"
            ;

    private String name = "DBBasedRulesProvider";
    private String configPools;
    private IRouter router;
    private long configLastModified = -1;

    private byte[] routingRules;
    private static final String PROP_ENV = "com.wm.ApplicationEnvironment";
    private static final String DEFAULT_ENV = "PROD";

    /**
     * Returns the name of this provider.
     *
     * @return the name of the provider
     */
    public String getName() {
        return name;
    }

    /**
     * It is upto the implementing class to decide if the rules need to be re-fetched
     * from the persistent store.
     *
     * @return true, if the implementation detects that the rules have changed in the
     *         persistent store.
     */
    public boolean needsRefresh() {
        if (configPools == null) {
            throw new IllegalStateException("The provider points to null configPools");
        }

        String[] pools = configPools.split(",");
        for (String pool : pools) {
            Connection conn = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;
            try {
                pool = pool.trim();
                conn = DataAccess.getInstance().getConnection(pool);
                if (conn == null) throw new RuntimeException("Could not get a connection from the pool [" + pool + "]");
                stmt = conn.prepareStatement(RULE_SQL);
                stmt.setString(1, AppConfig.getInstance().getProperty(PROP_ENV, DEFAULT_ENV));
                stmt.setString(2, getRouter().getName());
                rs = stmt.executeQuery();
                if (rs.next()) {
                    Timestamp modifiedDTM = rs.getTimestamp(3);
                    long time =  (modifiedDTM != null) ?modifiedDTM.getTime() :0;
                    if (configLastModified == time) {
                        logger.info("Verified up-to-date routing-rules from pool [" + pool + "]");
                        return false;
                    } else {
                        logger.info("Refreshing the routing-rules from pool [" + pool + "]");
                        int envRouterId = rs.getInt(1);
                        String ruleFile = rs.getString(2);
                        routingRules = replaceFields(conn, envRouterId, ruleFile);
                        configLastModified = time;
                        return true;
                    }
                }
            } catch (Exception e) {
                logger.log(Level.WARNING, "Error trying to refresh the routing-rules from pool [" + pool + "]" + e.getMessage());
                logger.log(Level.FINE, "", e);
            } finally {
                safeClose(conn, stmt, rs);
            }
        }
        throw new RuntimeException("Error trying to refresh the routing-rules from any of the pool(s) [" + configPools + "]");
    }

    private byte[] replaceFields(Connection conn, int envRouterId, String ruleFile) {
        if (ruleFile == null) {
            throw new RuntimeException("Found a null where a routing-rule string was expected");
        } else if (ruleFile.indexOf("${") == -1) {
            return ruleFile.getBytes();
        }

        Map<String, String> fields = doGetFields(conn, envRouterId);
        String ret = doReplaceFields(ruleFile, fields, envRouterId);

        return ret.getBytes();
    }

    private Map<String, String> doGetFields(Connection conn, int envRouterId) {
        Map<String,String> fields = new HashMap<String,String>();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.prepareStatement(FIELD_SQL);
            stmt.setInt(1, envRouterId);
            rs = stmt.executeQuery();
            while (rs.next()) {
                fields.put(rs.getString(1), rs.getString(2));
            }
        } catch (Exception e) {
            throw new RuntimeException("Error trying to replace field values", e);
        } finally {
            safeClose(null, stmt, rs);
        }
        return fields;
    }

    private String doReplaceFields(String ruleFile, Map<String, String> fields, int envRouterId) {
        StringBuffer buffer = new StringBuffer();
        int n1 = 0, n2 = 0;
        while ((n1 = ruleFile.indexOf("${", n2)) != -1) {
            if (n1 != n2) {
                buffer.append(ruleFile.substring(n2, n1));
            }
            n2 = ruleFile.indexOf("}", n1);
            if (n2 != -1) {
                String name = ruleFile.substring(n1 + 2, n2);
                if (!fields.containsKey(name)) {
                    throw new RuntimeException("The rule [" + envRouterId + "] contains an undefined field [" + name + "]");
                }
                String value = fields.get(name);
                buffer.append( (value != null) ? value : "" );
                n2++;
            } else {
                throw new RuntimeException("The rule [" + envRouterId + "] contains an unterminated ${ ... } expression - i.e. a missing '}'");
            }
        }
        if (n2 < ruleFile.length()) {
            buffer.append(ruleFile.substring(n2));
        }
        return buffer.toString();
    }

    private void safeClose(Connection conn, PreparedStatement stmt, ResultSet rs) {
        try {
            if (rs != null) rs.close();
        } catch (Exception e) {
            logger.warning(e.getMessage());
        }
        try {
            if (stmt != null) stmt.close();
        } catch (Exception e) {
            logger.warning(e.getMessage());            
        }
        try {
            if (conn != null) conn.close();
        } catch (Exception e) {
            logger.warning(e.getMessage());
        }
    }

    /**
     * The implementation needs to fetch the routing-rules from the persistent store
     * and return it as a byte[].
     *
     * @return the bytes corresponding to an XML string representing the routing-rules.
     */
    public byte[] getRoutingRules() {
        return routingRules;
    }

    /**
     * Returns a comma-separated list of pool names for loading the routing-rules.
     *
     * @return a comma-separated list of pool names for loading the routing-rules
     */
    public String getConfigPools() {
        return configPools;
    }

    /**
     * Sets the comma-separated list of pool names for loading the routing-rules.
     *
     * @param configPools - a comma-separated list of pool names for loading the routing-rules
     */
    public void setConfigPools(String configPools) {
        this.configPools = configPools;
    }

    /**
     * Returns the router instance for which this provider is fetching the routing-rules.
     *
     * @return - the router instance for which this provider is fetching the routing-rules
     */
    public IRouter getRouter() {
        return router;
    }

    /**
     * Sets the router instance for which this provider is fetching the routing-rules.
     *
     * @param router - the router instance for which this provider is fetching the routing-rules
     */
    public void setRouter(IRouter router) {
        this.router = router;
    }

}
