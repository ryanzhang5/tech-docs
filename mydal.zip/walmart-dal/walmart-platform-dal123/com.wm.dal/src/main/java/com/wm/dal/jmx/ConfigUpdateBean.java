package com.wm.dal.jmx;

import com.wm.dal.util.DALException;
import com.wm.dal.util.ServerConf;

import com.wm.configmgmt.client.jmx.ConfigMgmt;
import javax.management.NotCompliantMBeanException;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
  
import com.wm.corelib.config.AppConfig;

/**
 * ConfigUpdateBean which loads all the dynamic runtime properties at app startup into JMX as an MBean.
 *
 * @author ncherukuri
 * @version $Revision: 1.3 $
 * @since 1/2010
 */
public class ConfigUpdateBean extends ConfigMgmt {

    private static final Logger logger = Logger.getLogger(ConfigUpdateBean.class.getName());

    public ConfigUpdateBean() throws NotCompliantMBeanException {
        super();
    }

    /**
     * This method will save the props and load the new props into the JVM or app contextr based on app requiremnents.
     * This method should be overridden by the appropriate app team
     */
    public void save() throws IOException {
        logger.log(Level.INFO, " Save and load " + propertyFileName);
        String newPropertyFileName = propertyFileName + "##mod";
        File file = new File(newPropertyFileName);
        OutputStream output = new FileOutputStream(file);
        String comment = "Modified by " + this.getClass().getName();
        properties.store(output, comment);
        output.close();
        if (!file.renameTo(new File(propertyFileName))) {
            throw new IOException("Rename " + newPropertyFileName + " to " +
                    propertyFileName + " failed");
        }
        //String jvmConfigFile =  AppConfig.getInstance().getProperty("com.wm.conf");
        try {
            ServerConf.loadConfig(propertyFileName);
        } catch (DALException e) {
            e.printStackTrace();
        }
    }

    /*
   * This method is used to load the properties by the JMX bean. This is specifically loading the runtime props into the Config Bean.
    */
    public void load() throws IOException {
        logger.log(Level.INFO, "ConfigUpdateBean Loading Props from " + propertyFileName);
        InputStream input = new FileInputStream(propertyFileName);
        properties.load(input);
        input.close();
    }


}
