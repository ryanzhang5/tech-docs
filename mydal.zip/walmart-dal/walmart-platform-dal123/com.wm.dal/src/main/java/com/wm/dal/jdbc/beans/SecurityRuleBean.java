package com.wm.dal.jdbc.beans;

import java.io.Serializable;
import java.sql.Timestamp;

public class SecurityRuleBean implements Serializable {

	public SecurityRuleBean() {

		this.modifiedDtm = new Timestamp(System.currentTimeMillis());
	}

	public SecurityRuleBean(int ruleId, String ruleFile) {

		this.ruleId = ruleId;
		this.ruleFile = ruleFile;
		this.modifiedDtm = new Timestamp(System.currentTimeMillis());
	}

	public int getRuleId() {
		return ruleId;
	}

	public void setRuleId(int ruleId) {
		this.ruleId = ruleId;
	}

	public String getRuleFile() {
		return ruleFile;
	}

	public void setRuleFile(String ruleFile) {
		this.ruleFile = ruleFile;
	}

	public Timestamp getModifiedDtm() {
		return modifiedDtm;
	}

	public void setModifiedDtm(Timestamp modifiedDtm) {
		if (modifiedDtm == null) {
			this.modifiedDtm = new Timestamp(System.currentTimeMillis());
		} else {
			this.modifiedDtm = modifiedDtm;
		}
	}

	private int ruleId;
	private String ruleFile;
	private Timestamp modifiedDtm;

}
