/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.statements;

import com.wm.dal.router.plugins.default_.IStatement;
import com.wm.dal.router.plugins.default_.RouterContext;

import java.util.logging.Logger;
import java.util.logging.Level;

/**
 * SetPoolNameStatement - sets the pool name in the router response.
 *
 * @author mkishore
 * @version $Revision: 1.4 $
 * @since 1.0
 */
public class SetPoolNameStatement implements IStatement<RouterContext> {
    private static final Logger logger = Logger.getLogger(SetPoolNameStatement.class.getName());

    private String value;

    /**
     * This method should be called after creating the action and injecting
     * all its dependencies. The implmentations can use this method to validate
     * that the instance has been configured correctly.
     *
     * @throws IllegalStateException - if there are errors in the configuration
     */
    public void initialize() throws IllegalStateException {
        if (value == null) {
            throw new IllegalStateException("The value is null");
        }
    }

    /**
     * Sets the pool name in the router response.
     *
     * @param context - the execution context
     */
    public Status execute(RouterContext context) {
        context.getResponse().setPoolName(value);
        if (logger.isLoggable(Level.FINE)) {
            logger.fine(this.getClass().getSimpleName() + " - Executed. poolName [" + value + "]");
        }
        return Status.CONTINUE;
    }

    // GETTERS and SETTERS

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
