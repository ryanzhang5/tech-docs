package com.wm.dal.jms.apps;

import com.bitmechanic.sql.*;
import com.wm.sql.DataAccess;
import com.wm.sql.XRuntimeSQL;

import java.sql.*;

public class DBPool {

    private static DBPool _theInstance = null;

    private static final String SER_POOL = "jdbcpool_ser";
    private static final String OMS_POOL = "jdbcpool_oms";
    private static final String OMS_FF_POOL = "jdbcpool_oms_ff";
    private static final String CARRIER_POOL = "jdbcpool_carrier";
    private static final String PPROD_POOL = "jdbcpool_pprod";
    private static final String FULFILLMENT_POOL = "jdbcpool_fulfillment";

  ///////////////////////////////////////////////////
    // private interface
    ///////////////////////////////////////////////////

    /**
       This is a singlton class, so mask out Ctors
     **/
    private DBPool() {
//        // bootstrap properties...
//        Main.getProperty("...");
    }

    ////////////////////////////////////////////////////
    // public interface
    ///////////////////////////////////////////////////
    public static DBPool getInstance() {
        if (_theInstance == null) {
            _theInstance = new DBPool();
        }

        return _theInstance;
    }


    public Connection getConnection() throws XRuntimeSQL {
        return getConnection(DataAccess.ALIAS_CATALOG);
    }


    /**
     *
     */
    public Connection getSearchConnection() throws XRuntimeSQL {
        return getConnection(DataAccess.ALIAS_SEARCH);
    }

    public Connection getBMMConnection() throws XRuntimeSQL {
        return getConnection(DataAccess.ALIAS_BMM);
    }

    /** get connection for credit card database
     */
    public Connection getCCConnection() throws XRuntimeSQL {
        return getConnection(DataAccess.ALIAS_CC);
    }


    public Connection getSerConnection() throws XRuntimeSQL {
        return getConnection(SER_POOL);
    }

    public Connection getOMSConnection() throws XRuntimeSQL {
        return getConnection(OMS_POOL);
    }

     public Connection getFulfillmentConnection() throws XRuntimeSQL {
        return getConnection(FULFILLMENT_POOL);
    }

    public Connection getOMSFulfConnection() throws XRuntimeSQL {
        return getConnection(OMS_FF_POOL);
    }

    public Connection getCarrierConnection() throws XRuntimeSQL {
        return getConnection(CARRIER_POOL);
    }

    public Connection getPPRODConnection() throws XRuntimeSQL {
          return DataAccess.getInstance().getConnection(PPROD_POOL);
    }

    /**
     * Returns a connection to the session database.  Direct access to the
     * session table is not encouraged here.  This is exposed in order to
     * get at the property sheet table, not the session table.
     */
    public Connection getSessionConnection() throws XRuntimeSQL {
        return getConnection(DataAccess.ALIAS_SESSION);
    }

    /*public Connection getSessionConnection() throws XRuntimeSQL
       {
         return getConnection(DataAccess.ALIAS_BMM);
       } */
    public Connection getConnection(String alias) throws XRuntimeSQL {
        return DataAccess.getInstance().getConnection(alias);
    }

    public static void flushGetConnectionErrorLog() {
        DataAccess.getInstance().flushGetConnectionErrorLog(DataAccess.ALIAS_CATALOG);
    }

    /**
     * Returns the default (catalog) pool.
     */
    public ConnectionPool[] getConnectionPool() throws XRuntimeSQL {
        return getConnectionPool(DataAccess.ALIAS_CATALOG);
    }

    public ConnectionPool[] getCCConnectionPool() throws XRuntimeSQL {
        return getConnectionPool(DataAccess.ALIAS_CC);
    }

    public ConnectionPool[] getSearchConnectionPool() throws XRuntimeSQL {
        return getConnectionPool(DataAccess.ALIAS_SEARCH);
    }

    private ConnectionPool[] getConnectionPool(String alias)
                                        throws XRuntimeSQL
    {
        return DataAccess.getInstance().getConnectionPool(alias);
    }

    public void setCatalogTracing(boolean tracing) throws XRuntimeSQL {
        setTracing(DataAccess.ALIAS_CATALOG, tracing);
    }

    public void setSearchTracing(boolean tracing) throws XRuntimeSQL {
        setTracing(DataAccess.ALIAS_SEARCH, tracing);
    }

    public void setSessionTracing(boolean tracing) throws XRuntimeSQL {
        setTracing(DataAccess.ALIAS_SESSION, tracing);
    }

    private void setTracing(String alias, boolean tracing)
                     throws XRuntimeSQL
    {
        DataAccess.getInstance().setTracing(alias, tracing);
    }

    public static void close(ResultSet rs, Statement stmt, Connection conn) {
        DataAccess.close(rs, stmt, conn);
    }

    public static void close(Statement stmt, Connection conn) {
        close(null, stmt, conn);
    }

    public static void close(Connection conn) {
        close(null, null, conn);
    }

    public static void close(Statement stmt) {
        close(null, stmt, null);
    }

    public static void close(ResultSet rs) {
        close(rs, null, null);
    }
}
