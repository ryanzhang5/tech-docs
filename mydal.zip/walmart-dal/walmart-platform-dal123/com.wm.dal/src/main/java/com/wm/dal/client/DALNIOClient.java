/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.client;

import com.wm.dal.server.nio.Handler;
import com.wm.dal.server.nio.TransportUtil;

import com.wm.dal.util.ClientUtil;

import java.io.IOException;

import java.net.InetSocketAddress;

import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.SocketChannel;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * 
 * @author cshah
 * @version 1.0
 */
public class DALNIOClient implements IDALClient, Handler { 
    private String host;
    private int port;
    private SocketChannel sc;
    private static int responseBBSize = 8124;
    private ByteBuffer responseBB = ByteBuffer.allocate(responseBBSize) ;    
    private ByteBuffer requestBB;
    private final BlockingQueue<IDALResponse> responseQueue = new LinkedBlockingQueue<IDALResponse>();

    /**
     * 
     * @param host
     * @param port
     * @throws Exception
     */
    public DALNIOClient(String host, int port) throws Exception{
        this.host = host;
        this.port = port;
        sc = SocketChannel.open(new InetSocketAddress(host, port));
        sc.configureBlocking(false);
    }

    /**
     * 
     * @param request
     * @return
     * @throws Exception
     */
    public IDALResponse execute(IDALRequest request) throws Exception {
        send(request);
        IDALResponse response = responseQueue.take();
        return response;
    }
    
    /**
     * 
     * @param request
     * @throws Exception
     */
    private synchronized void send(IDALRequest request) throws Exception {
        this.requestBB = TransportUtil.createRequestAsByteBuffer(request);
        ClientUtil.getWriteDispatcher().register(sc, SelectionKey.OP_WRITE, this);
    }

    /**
     * 
     * @param remaining
     */
    private void resizeResponseBB(int remaining) {
        if (responseBB.remaining() < remaining) {
            ByteBuffer bb =  ByteBuffer.allocate(responseBB.capacity() * 2) ;
            responseBB.flip();
            bb.put(responseBB);
            responseBB = bb;
        }
    }

    /**
     * 
     * @param sk
     * @throws Exception
     */
    private synchronized void receive(SelectionKey sk) throws Exception {
        resizeResponseBB(responseBBSize/20);
        if (sc.isOpen() && sk.isValid() ) {
            sc.read(responseBB);
        } else {
            sk.cancel();
            sk.attach(null);
            close();
            return;
        }

        boolean requestcomplete = TransportUtil.isComplete(responseBB);

        if (requestcomplete) {
            try {
                responseBB.flip();
                IDALResponse dalResponse = TransportUtil.readDALResponse(responseBB);
                sk.attach(null);
                sk.cancel();
                responseQueue.offer(dalResponse);
                /*
                if (sc.isOpen()) {
                    ClientUtil.getWriteDispatcher().register(sc, SelectionKey.OP_WRITE, this);
                }
                */
            } catch (ClassNotFoundException cnfe) {
                cnfe.printStackTrace();
            } catch (IOException ioe) {
                ioe.printStackTrace();
            } catch (Exception e) {
                throw e;
            } finally {
                responseBB.clear();
            }
        }//if
    }

    /**
     * 
     * @param sk
     * @throws Exception
     */
    public void handle(SelectionKey sk) throws Exception {
        if (!sk.isValid())         {
            close();
            return;
        }
        
        if (sk.interestOps() == SelectionKey.OP_WRITE && sk.isWritable()) {
            while (requestBB.hasRemaining()) {
              sc.write(requestBB);
            }
            sk.cancel();
            sk.attach(null);
            requestBB.clear();

            ClientUtil.getReadDispatcher().register(sc, SelectionKey.OP_READ, this);
        } else if (sk.interestOps() == SelectionKey.OP_READ && sk.isReadable()) {
            receive(sk);
        }
    }
    
    public void close() throws Exception {
        sc.close();
    }

/*
    public void run() {
        while (isRunning) {
            try {
            selector.select();
                for (Iterator i = selector.selectedKeys().iterator(); i.hasNext(); ) {
                    SelectionKey sk = (SelectionKey)i.next();
                    //System.out.println("Key in dispatcher:" + sk + ":" + sk.interestOps());
                    i.remove();
                    Handler h = (Handler)sk.attachment();
                    if (h != null)
                        h.handle(sk);
                }
            } catch (Exception exp) {
                exp.printStackTrace();
            }
            synchronized (_gate) { }
        }
    }
*/
}
