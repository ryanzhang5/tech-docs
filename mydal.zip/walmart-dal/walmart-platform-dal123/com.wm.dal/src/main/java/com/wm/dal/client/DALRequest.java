/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.client;

import java.io.Serializable;

import javax.transaction.xa.Xid;

import com.wm.dal.common.DALSession;

/**
 * @author cshah
 * @version 1.0
 */
public class DALRequest implements Serializable, IDALRequest {
    private final byte version = 1;
	private int ID = 0;
    private DALSession session;
    private int command = 0;
    private int caller = 0;
    private Xid xid;
    
    /**
     * @param command
     * @param caller
     */
    public DALRequest(int command, int caller) {
        this.command = command;
        this.caller = caller;
    }

    public void
    setXid(Xid xid)
    {
    	this.xid = xid;
    }
    
    public Xid
    getXid()
    {
    	return this.xid;
    }
    
    /**
     * @return
     */
    public int getCommand() {
        return command;
    }

    /**
     * @param command
     */
    public void setCommand(int command) {
        this.command = command;
    }

    /**
     * @return
     */
    public int getCaller() {
        return caller;
    }

    /**
     * @param caller
     */
    public void setCaller(int caller) {
        this.caller = caller;
    }

    /**
     * @param session
     */
    public void setSession(DALSession session) {
        this.session = session;
    }

    /**
     * @return
     */
    public DALSession getSession() {
        return session;
    }

    /**
     * @param cursorID
     */
    public void setID(int cursorID) {
        this.ID = cursorID;
    }

    /**
     * @return
     */
    public int getID() {
        return ID;
    }    

    public String toString() {
        return "Command :" + this.command + ", Caller : " + this.caller + ", ID : " + this.ID + "\n" + session.toString();
    }
}
