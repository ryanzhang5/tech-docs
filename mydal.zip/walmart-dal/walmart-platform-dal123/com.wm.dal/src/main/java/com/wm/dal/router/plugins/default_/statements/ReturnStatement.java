/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.statements;

import com.wm.dal.router.plugins.default_.IStatement;
import com.wm.dal.router.plugins.default_.RouterContext;

import java.util.logging.Logger;
import java.util.logging.Level;

/**
 * ReturnStatement - allows the control flow to be interrupted. The execution proceeds
 * to the next Router - unless the optional attribute "chain-through" is set to false.
 *
 * @author mkishore
 * @since 1.0
 */
public class ReturnStatement implements IStatement<RouterContext> {
    private static final Logger logger = Logger.getLogger(ReturnStatement.class.getName());

    private boolean chainThrough;

    /**
     * No-op
     */
    public void initialize() throws IllegalStateException {
        // no-op
    }

    /**
     * Returns a suitable status to result in a "return"
     *
     * @param context - the execution context
     * @return the status controlling further execution path
     */
    public Status execute(RouterContext context) {
        context.getResponse().setShouldChainThroughNextRouter(chainThrough);
        if (logger.isLoggable(Level.FINE)) {
            logger.fine(this.getClass().getSimpleName() + " - Executed. chainThrough [" + chainThrough + "]");
        }
        return Status.RETURN;
    }

    // GETTERS and SETTERS

    public boolean getChainThrough() {
        return chainThrough;
    }

    public void setChainThrough(boolean chainThrough) {
        this.chainThrough = chainThrough;
    }
}