/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.common;

import com.wm.dal.client.DALResponse;
import com.wm.dal.client.ICallerResponse;
import com.wm.dal.client.IDALRequest;
import com.wm.dal.client.IDALResponse;
import com.wm.dal.jdbc.args.DALCursor;
import com.wm.dal.jdbc.utils.Constants;

import com.wm.dal.jdbc.utils.DALUtil;
import com.wm.dal.util.DALLogger;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * 
 * @author cshah
 * @version 1.0
 */
public class ResultSetCommand implements ICommand {
    protected ConnectionDelegate delegate = null;
    static final DALLogger logger = DALLogger.getInstance();
    
    /**
     * 
     * @param delegate
     */
    public ResultSetCommand(ConnectionDelegate delegate) {
        this.delegate = delegate;
    }

    /**
     * 
     * @param request
     * @return
     * @throws SQLException
     */
    public IDALResponse execute(IDALRequest request) throws SQLException {
        int command = request.getCommand();
        IDALResponse response = new DALResponse();
        ICallerResponse rsResponse = response.getResultSetResponse();

        switch (command) {
            case Constants.CLOSE_RESULTSET : {
                try {
                    logger.info("ResultSet close Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    delegate.closeResultSet(request);
                } catch (SQLException sqle) {
                    response.setException(sqle);
                    sqle.printStackTrace();
                } catch (Exception e) {
                    response.setException(e);
                    e.printStackTrace();
                }
                break;
            }            
            case Constants.READ_MORE_RESULTS : {
                try {
                    logger.info("ResultSet read more results Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    if (delegate.containsResultSet(request.getID()) ) {
                        ResultSet resultSet = delegate.getResultSet(request.getID());
                        Statement stmt = delegate.getStatementForResultSet(request.getID());
                        DALCursor cursor =  (DALCursor)DALUtil.getResultSet(stmt,resultSet); 
                        //rsResponse.setID(cursor.getCurSorID());
                        rsResponse.set(Constants.RESPONSE,cursor);
                        
                    }
                } catch (SQLException sqle) {
                    response.setException(sqle);
                    sqle.printStackTrace();
                } catch (Exception e) {
                    response.setException(e);
                    e.printStackTrace();
                }
                break;
            }
            default : {
                response.setException(new UnsupportedOperationException(Constants.UNSUPPORTED_EXCEPTION));
                //throw sqle;
            }
        }
        return response;
    }
        
}
