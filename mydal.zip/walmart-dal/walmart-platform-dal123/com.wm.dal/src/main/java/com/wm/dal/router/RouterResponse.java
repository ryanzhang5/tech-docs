/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.router;

/**
 * Sample implementation class for IRouterResponse Interface
 */
public class RouterResponse implements IRouterResponse {
    private String poolName = null;
    private boolean shouldChainThroughNextRouter;
    
    /**
     * Constructor
     */
    public RouterResponse() {
    }
    
    /**
     * Method returns the pool name 
     * @return - Connection Pool Name
     */
    public void setPoolName(String poolName) {
        this.poolName = poolName;
    }

    /**
     * Method returns the pool name 
     * @return - Connection Pool Name
     */
    public String getPoolName() {
        return poolName;
    }
    
    /**
     * true if next router should be executed in sequence, 
     * false to stop executing next router
     * @return - true/false
     */
    public boolean getShouldChainThroughNextRouter(){
        return shouldChainThroughNextRouter;
    }

    /**
     * Method sets the value controlling the execution of next router.
     *
     * @param shouldChainThroughNextRouter - true, if we wish to execute the next router
     */
    public void setShouldChainThroughNextRouter(boolean shouldChainThroughNextRouter) {
        this.shouldChainThroughNextRouter = shouldChainThroughNextRouter;
    }
}
