/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.common;

import com.wm.dal.client.DALResponse;

import com.wm.dal.client.ICallerResponse;
import com.wm.dal.client.IDALRequest;
import com.wm.dal.client.IDALResponse;
import com.wm.dal.jdbc.DALBatch;
import com.wm.dal.jdbc.args.DALArgs;
import com.wm.dal.jdbc.args.DALCursor;
import com.wm.dal.jdbc.utils.Constants;

import com.wm.dal.jdbc.utils.DALUtil;
import com.wm.dal.jdbc.utils.MethodAttribute;

import com.wm.dal.util.DALLogger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;

import java.util.LinkedList;
import java.util.List;

/**
 * 
 */
public class StatementCommand implements ICommand {
    protected ConnectionDelegate delegate = null;
    static final DALLogger logger = DALLogger.getInstance();
    private String sql = null;
    
    /**
     * 
     * @param delegate
     */
    public StatementCommand(ConnectionDelegate delegate) {
        this.delegate = delegate;
    }
    
    /**
     * 
     * @param request
     * @return
     * @throws SQLException
     */
    public IDALResponse execute(IDALRequest request) throws SQLException {
        int command = request.getCommand();
        IDALResponse response = new DALResponse();
        setSQL(request);
        ICallerResponse statementResponse = response.getStatementResponse();
        ICallerResponse rsResponse = response.getResultSetResponse();
        
        switch (command) {
            case Constants.EXECUTE :{
                try {
                    Connection conn = delegate.getConnection(request, response);
                    Statement stmt = null;
                    logger.info("Creating Statement Execute Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    stmt = createStatement(request, response, conn);
                    sql = (String)request.getSession().getStatementAttribute(MethodAttribute.SQL).getAttribute();
                    logger.warning("Executing Query : "     + sql);
                    boolean retValue = stmt.execute(sql);
                    int updCount = stmt.getUpdateCount();
                    
                    statementResponse.set(Constants.STATUS,Boolean.valueOf(retValue));

                     if (retValue) {
                         ResultSet rs = stmt.getResultSet();
                         readResultSetAndcreateResponse(stmt,rs,rsResponse);
                     } else if ( updCount != -1){ //if 
                         statementResponse.set(Constants.RESPONSE,Integer.valueOf(updCount));
                     } 
                 } catch (SQLException sqle) {
                        response.setException(sqle);
                        sqle.printStackTrace();
                 } catch (Exception e) {
                        response.setException(e);
                        e.printStackTrace();
                 }
                break;
            }
            case Constants.EXECUTE_QUERY : {
                try {
                    Connection conn = delegate.getConnection(request, response);
                    Statement stmt = null;
                    logger.info("Creating Statement Execute Query Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    stmt = createStatement(request, response, conn);

                    ResultSet resultSet = stmt.executeQuery(sql);
                    readResultSetAndcreateResponse(stmt,resultSet,rsResponse);

                } catch (SQLException sqle) {
                        response.setException(sqle);
                        sqle.printStackTrace();
                } catch (Exception e) {
                        response.setException(e);
                        e.printStackTrace();
                }
                break;
            }
            case Constants.EXECUTE_UPDATE : {
                try {
                    Connection conn = delegate.getConnection(request, response);
                    Statement stmt = null;
                    logger.info("Creating Statement Execute Update Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    stmt = createStatement(request, response, conn);
    
                    int retValue = stmt.executeUpdate(sql);
        
                    statementResponse.set(Constants.STATUS,Integer.valueOf(retValue));
                    statementResponse.set(Constants.RESPONSE,Integer.valueOf(retValue));
                } catch (SQLException sqle) {
                        response.setException(sqle);
                        sqle.printStackTrace();
                } catch (Exception e) {
                        response.setException(e);
                        e.printStackTrace();
                }
                break;
            }
            case Constants.EXECUTE_UPDATE_W_AUTOGENKEYS : {
                try {
                    int autoGeneratedKeys = 0;
                    MethodAttribute prop = request.getSession().getStatementAttribute(MethodAttribute.AUTO_GENERATED_KEYS);
                    if (prop != null && prop.getAttribute() instanceof Integer) {
                        autoGeneratedKeys = ((Integer)prop.getAttribute()).intValue();
                    }
                    Connection conn = delegate.getConnection(request, response);
                    Statement stmt = null;
                    logger.info("Creating Statement Execute Update W AutoGenKeys Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    stmt = createStatement(request, response, conn);
                    
                    int retValue = stmt.executeUpdate(sql,autoGeneratedKeys);
                
                    statementResponse.set(Constants.RESPONSE,Integer.valueOf(retValue));

                } catch (SQLException sqle) {
                        response.setException(sqle);
                        sqle.printStackTrace();
                } catch (Exception e) {
                        response.setException(e);
                        e.printStackTrace();
                }
                break;
            }
            case Constants.EXECUTE_UPDATE_W_COLUMNINDEXES : {
                try {
                    int columnIndexes[] = null;
                    MethodAttribute prop = request.getSession().getStatementAttribute(MethodAttribute.COLUMN_INDEXES);

                    if (prop != null && prop.getAttribute() instanceof int[]) {
                        columnIndexes = (int[])prop.getAttribute();
                    }
                    Connection conn = delegate.getConnection(request, response);
                    Statement stmt = null;
                    logger.info("Creating Statement Execute Update W Column Indexes Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    stmt = createStatement(request, response, conn);
    
                    int retValue = stmt.executeUpdate(sql,columnIndexes);
                
                    statementResponse.set(Constants.RESPONSE,Integer.valueOf(retValue));
                    
                } catch (SQLException sqle) {
                        response.setException(sqle);
                        sqle.printStackTrace();
                } catch (Exception e) {
                        response.setException(e);
                        e.printStackTrace();
                }
                break;
            }
            case Constants.EXECUTE_UPDATE_W_COLUMNNAMES : {
                try {
                    String columnNames[] = null;
                    MethodAttribute prop = request.getSession().getStatementAttribute(MethodAttribute.COLUMN_NAMES);
                    if (prop != null && prop.getAttribute() instanceof String[]) {
                        columnNames = (String[])prop.getAttribute();
                    }

                    Connection conn = delegate.getConnection(request, response);
                    Statement stmt = null;
                    logger.info("Creating Statement Execute Update W Column Names Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    stmt = createStatement(request, response, conn);
    
                    int retValue = stmt.executeUpdate(sql,columnNames);
                
                    statementResponse.set(Constants.RESPONSE,Integer.valueOf(retValue));

                } catch (SQLException sqle) {
                        response.setException(sqle);
                        sqle.printStackTrace();
                } catch (Exception e) {
                        response.setException(e);
                        e.printStackTrace();
                }
                break;
            }
            case Constants.EXECUTE_W_AUTOGENKEYS :{
                try {
                    //TODO for callable or prepared needs to define each statement here 
                    int autoGeneratedKeys = 0;
                    MethodAttribute prop = request.getSession().getStatementAttribute(MethodAttribute.AUTO_GENERATED_KEYS);
                    if (prop != null && prop.getAttribute() instanceof Integer) {
                        autoGeneratedKeys = ((Integer)prop.getAttribute()).intValue();
                    }
    
                    Connection conn = delegate.getConnection(request, response);
                    Statement stmt = null;
                    logger.info("Creating Statement Execute W Augo Gen Keys Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    stmt = createStatement(request, response, conn);

                    Boolean retValue = stmt.execute(sql, autoGeneratedKeys);
            
                    statementResponse.set(Constants.STATUS,retValue);
                    
                    if (retValue.booleanValue()) {
                        ResultSet resultSet = stmt.getResultSet();
                        readResultSetAndcreateResponse(stmt,resultSet,rsResponse);
                    } else { //if 
                        int updCount = stmt.getUpdateCount();
                        statementResponse.set(Constants.RESPONSE,Integer.valueOf(updCount));    
                    }
                } catch (SQLException sqle) {
                        response.setException(sqle);
                        sqle.printStackTrace();
                } catch (Exception e) {
                        response.setException(e);
                        e.printStackTrace();
                }
                break;
            }
            case Constants.EXECUTE_W_COLUMNINDEXES : {
                try {
                    int columnIndexes[] = null;
                    MethodAttribute prop = request.getSession().getStatementAttribute(MethodAttribute.COLUMN_INDEXES);
                    if (prop != null && prop.getAttribute() instanceof int[]) {
                        columnIndexes = (int[])prop.getAttribute();
                    }
    
                    Connection conn = delegate.getConnection(request, response);
                    Statement stmt = null;
                    logger.info("Creating Statement Execute W Column Indexes Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    stmt = createStatement(request, response, conn);
    
                    Boolean retValue = stmt.execute(sql,columnIndexes);
                    
                    statementResponse.set(Constants.STATUS,retValue);
                    if (retValue.booleanValue()) {
                        ResultSet resultSet = stmt.getResultSet();
                        readResultSetAndcreateResponse(stmt,resultSet,rsResponse);
                    } else { //if 
                        int updCount = stmt.getUpdateCount();
                        statementResponse.set(Constants.RESPONSE,Integer.valueOf(updCount));
                    }
                } catch (SQLException sqle) {
                        response.setException(sqle);
                        sqle.printStackTrace();
                } catch (Exception e) {
                        response.setException(e);
                        e.printStackTrace();
                }
                break;
            }
            case Constants.EXECUTE_W_COLUMNNAMES : {
                try {
                    String columnNames[] = null;
                    MethodAttribute prop = request.getSession().getStatementAttribute(MethodAttribute.COLUMN_NAMES);
                    if (prop != null && prop.getAttribute() instanceof String[]) {
                        columnNames = (String[])prop.getAttribute();
                    }
    
                    Connection conn = delegate.getConnection(request, response);
                    Statement stmt = null;
                    logger.info("Creating Statement Execute W Column Names Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    stmt = createStatement(request, response, conn);
    
                    Boolean retValue = stmt.execute(sql,columnNames);
                    statementResponse.setID(stmt.hashCode());
                    statementResponse.set(Constants.STATUS,retValue);
                    if (retValue.booleanValue()) {
                        ResultSet resultSet = stmt.getResultSet();
                        readResultSetAndcreateResponse(stmt,resultSet,rsResponse);
                    } else { //if 
                        int updCount = stmt.getUpdateCount();
                        statementResponse.set(Constants.RESPONSE,Integer.valueOf(updCount));    
                    }
                } catch (SQLException sqle) {
                        response.setException(sqle);
                        sqle.printStackTrace();
                } catch (Exception e) {
                        response.setException(e);
                        e.printStackTrace();
                }
                break;
            }
            case Constants.EXECUTE_BATCH : {
                try {
                    LinkedList<DALBatch> batch = new LinkedList<DALBatch>();
                    MethodAttribute prop = request.getSession().getStatementAttribute(MethodAttribute.BATCH);
                    if (prop != null && prop.getAttribute() instanceof LinkedList) {
                        batch = (LinkedList<DALBatch>)prop.getAttribute();
                    }
                    
                    Connection conn = delegate.getConnection(request, response);
                    Statement stmt = null;
                    logger.info("Creating Statement Execute Batch Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    stmt = createStatement(request, response, conn);
                    
                    for (int i=0; i < batch.size(); i++) {
                        stmt.addBatch(batch.get(i).getSql());
                    }
                    
                    int[] retValue = new int[0];
                    try {
                        retValue = stmt.executeBatch();
                    } catch (SQLException sqle) {
                        response.setException(sqle);
                    }
                    statementResponse.setID(stmt.hashCode());
                    statementResponse.set(Constants.STATUS,retValue);
                    
                } catch (SQLException sqle) {
                        response.setException(sqle);
                        sqle.printStackTrace();
                } catch (Exception e) {
                        response.setException(e);
                        e.printStackTrace();
                }
                break;
            }
            case Constants.CLOSE_STATEMENT : {
                try {
                        logger.info("Close Statement Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                        delegate.closeStatement(request);
                    } catch (SQLException sqle) {
                            response.setException(sqle);
                            sqle.printStackTrace();
                    } catch (Exception e) {
                            response.setException(e);
                            e.printStackTrace();
                    }
                    break;
                }
            case Constants.CLEAR_BATCH : {
                try {
                    logger.info("Clear Batch Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    if (delegate.containsStatement(request.getID()) ) {
                        delegate.getStatement(request.getID()).clearBatch();
                    }
                } catch (SQLException sqle) {
                        response.setException(sqle);
                        sqle.printStackTrace();
                } catch (Exception e) {
                        response.setException(e);
                        e.printStackTrace();
                }
                break;
            }
            case Constants.CLEAR_WARNINGS : {
                try {
                    logger.info("Clear Warning Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    if (delegate.containsStatement(request.getID()) ) {
                        delegate.getStatement(request.getID()).clearWarnings();
                    }
                } catch (SQLException sqle) {
                        response.setException(sqle);
                        sqle.printStackTrace();
                } catch (Exception e) {
                        response.setException(e);
                        e.printStackTrace();
                }
                break;
            }
            case Constants.GET_WARNINGS : {
                    try {
                        logger.info("Get Warnings Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                        if (delegate.containsStatement(request.getID()) ) {
                            SQLWarning warning = delegate.getStatement(request.getID()).getWarnings();
                            statementResponse.set(Constants.RESPONSE,warning);
                        }
                    } catch (SQLException sqle) {
                            response.setException(sqle);
                            sqle.printStackTrace();
                    } catch (Exception e) {
                            response.setException(e);
                            e.printStackTrace();
                    }
                break;                    
            }
            case Constants.GET_GENERATED_KEYS : {
                    try {
                        logger.info("Get Generated Keys Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());                    
                        if (delegate.containsStatement(request.getID()) ) {
                            Statement stmt = delegate.getStatement(request.getID());

                            ResultSet resultSet = stmt.getGeneratedKeys();
                            readResultSetAndcreateResponse(stmt,resultSet,rsResponse);
                        }
                    } catch (SQLException sqle) {
                            response.setException(sqle);
                            sqle.printStackTrace();
                    } catch (Exception e) {
                            response.setException(e);
                            e.printStackTrace();
                    }
                break;
            }
            case Constants.GET_MORE_RESULTS :{
                try {
                    int requestID = request.getID();
                     logger.info("Get more results Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    if (delegate.containsStatement(requestID) ) {
                        Statement stmt = delegate.getStatement(requestID);
                        boolean retValue = stmt.getMoreResults();
                        int updCount = stmt.getUpdateCount();
                            
                        //statementResponse.setID(stmt.hashCode());
                        statementResponse.set(Constants.STATUS,Boolean.valueOf(retValue));
        
                        if (retValue) {
                            ResultSet resultSet = stmt.getResultSet();
                            readResultSetAndcreateResponse(stmt,resultSet,rsResponse);
                        }
                            statementResponse.set(Constants.RESPONSE,Integer.valueOf(updCount));
                    }//if
                 } catch (SQLException sqle) {
                         response.setException(sqle);
                         sqle.printStackTrace();
                 } catch (Exception e) {
                        response.setException(e);
                        e.printStackTrace();
                 }
                break;                 
            }
/*                 
            case Constants.GET_UPDATE_COUNT : {
                int ID = request.getID();
                Integer updcount = Integer.valueOf(-1);
                if (delegate.getStmtMap().containsKey(ID) ) {
                    updcount = delegate.getStmtMap().get(ID).getUpdateCount();
                }
                response.getStatementResponse().set(Constants.RESPONSE,updcount);
            }
                 break;
            case Constants.GET_RESULT_SET : {
                int ID = request.getID();
                if (delegate.getStmtMap().containsKey(ID) ) {
                    Statement stmt = delegate.getStmtMap().get(ID);
                    ResultSet rs = stmt.getResultSet();
                    delegate.registerResultSet(stmt,rs);
                    DALCursor cursor =  (DALCursor)DALUtil.getResultSet(stmt,rs);
                    response.getResultSetResponse().setID(cursor.getCurSorID());
                    response.getResultSetResponse().set(Constants.RESPONSE,cursor);
                } else {
                    logger.warning("Result set not found for get result set " );
                }
            }
                 break;
*/                 
            default : {
                response.setException(new UnsupportedOperationException(Constants.UNSUPPORTED_EXCEPTION));
            }
        }    
        return response;        
    }

    /**
     * 
     * @param request
     * @param response
     * @param conn
     * @return
     * @throws SQLException
     */
    protected Statement createStatement(IDALRequest request, IDALResponse response, Connection conn) throws SQLException {
        Statement stmt = null;
        try {
            DALSession session = request.getSession();
            setSQL(request);
            MethodAttribute paramProp = session.getStatementAttribute(MethodAttribute.SQL_PARAMETERS);
            MethodAttribute constructorProp = session.getStatementAttribute(MethodAttribute.CONSTRUCTOR);
    
            int constructor = MethodAttribute.CONSTRUCTOR_DEFAULT;
            if (constructorProp != null && constructorProp.getAttribute() instanceof Integer) {
                constructor = ((Integer)constructorProp.getAttribute()).intValue();
            }
            
            List<DALArgs> param = paramProp != null ? (List<DALArgs>)paramProp.getAttribute() : null ;
    
            ICallerResponse statementResponse = response.getStatementResponse();
            try {
                if (request.getCaller() == Constants.STATEMENT) {
                    switch (constructor) {
                        case MethodAttribute.CONSTRUCTOR_DEFAULT : {
                            logger.info("Creating Statement");
                            stmt = conn.createStatement();
                            break;
                        }
                        case MethodAttribute.CONST_W_RS_TYPE_CONCURRENCY : {
                            MethodAttribute rsType = session.getStatementAttribute(MethodAttribute.RESULTSET_TYPE);
                            MethodAttribute rsConc = session.getStatementAttribute(MethodAttribute.RESULTSET_CONCURRENCY);
                            logger.info("Creating Statement with RS TYPE and CONCURRENCY");
                            stmt = conn.createStatement( ((Integer)rsType.getAttribute()).intValue(), ((Integer)rsConc.getAttribute()).intValue());
                            break;
                        }
                        case MethodAttribute.CONST_W_RS_TYPE_CONCURRENCY_HOLDABILITY : {
                            MethodAttribute rsType = session.getStatementAttribute(MethodAttribute.RESULTSET_TYPE);
                            MethodAttribute rsConc = session.getStatementAttribute(MethodAttribute.RESULTSET_CONCURRENCY);
                            MethodAttribute holdability = session.getConnecitonAttribute(MethodAttribute.SET_HOLDABILITY);
                            logger.info("Creating Statement with RS TYPE, CONCURRENCY and HOLDABILITY");
                            stmt = conn.createStatement( ((Integer)rsType.getAttribute()).intValue(), ((Integer)rsConc.getAttribute()).intValue(), ((Integer)holdability.getAttribute()).intValue());
                            break;
                        }
                        default : {
                            logger.info("Creating Default Statement");
                            stmt = conn.createStatement();
                            break;
                        }
                    }//switch
                } else if (request.getCaller() == Constants.PREPARED_STATEMENT) {
                    switch (constructor) {
                        case MethodAttribute.CONSTRUCTOR_DEFAULT : {
                            logger.info("Creating Prepared Statement");
                            stmt = conn.prepareStatement(sql);
                            break;
                        }
                        case MethodAttribute.CONST_W_RS_TYPE_CONCURRENCY : {
                            MethodAttribute rsType = session.getStatementAttribute(MethodAttribute.RESULTSET_TYPE);
                            MethodAttribute rsConc = session.getStatementAttribute(MethodAttribute.RESULTSET_CONCURRENCY);
                            logger.info("Creating Prepared Statement with RS TYPE and CONCURRENCY");
                            stmt = conn.prepareStatement(sql, ((Integer)rsType.getAttribute()).intValue(), ((Integer)rsConc.getAttribute()).intValue());
                            break;
                        }
                        case MethodAttribute.CONST_W_RS_TYPE_CONCURRENCY_HOLDABILITY : {
                            MethodAttribute rsType = session.getStatementAttribute(MethodAttribute.RESULTSET_TYPE);
                            MethodAttribute rsConc = session.getStatementAttribute(MethodAttribute.RESULTSET_CONCURRENCY);
                            MethodAttribute holdability = session.getConnecitonAttribute(MethodAttribute.SET_HOLDABILITY);
                            logger.info("Creating Prepared Statement with RS TYPE, CONCURRENCY and HOLDABILITY");
                            stmt = conn.prepareStatement(sql, ((Integer)rsType.getAttribute()).intValue(), ((Integer)rsConc.getAttribute()).intValue(), ((Integer)holdability.getAttribute()).intValue());
                            break;
                        }
                        case MethodAttribute.CONST_W_AUTO_GEN_KEY : {
                            MethodAttribute autoGenKeys = session.getStatementAttribute(MethodAttribute.AUTO_GENERATED_KEYS);
                            logger.info("Creating Prepared Statement with Auto Gen Keys");
                            stmt = conn.prepareStatement(sql, ((Integer)autoGenKeys.getAttribute()).intValue());
                            break;
                        }
                        
                        default : {
                            logger.info("Creating Default Prepared Statement");
                            stmt = conn.prepareStatement(sql);
                            break;
                        }
                    }//switch
                } else if (request.getCaller() == Constants.CALLABLE_STATEMENT) {
                    switch (constructor) {
                        case MethodAttribute.CONSTRUCTOR_DEFAULT : {
                            logger.info("Creating Callable Statement");
                            stmt = conn.prepareCall(sql);
                            break;
                        }
                        case MethodAttribute.CONST_W_RS_TYPE_CONCURRENCY : {
                            MethodAttribute rsType = session.getStatementAttribute(MethodAttribute.RESULTSET_TYPE);
                            MethodAttribute rsConc = session.getStatementAttribute(MethodAttribute.RESULTSET_CONCURRENCY);
                            logger.info("Creating Callable Statement with RS TYPE and CONCURRENCY");
                            stmt = conn.prepareCall(sql, ((Integer)rsType.getAttribute()).intValue(), ((Integer)rsConc.getAttribute()).intValue());
                            break;
                        }
                        case MethodAttribute.CONST_W_RS_TYPE_CONCURRENCY_HOLDABILITY : {
                            MethodAttribute rsType = session.getStatementAttribute(MethodAttribute.RESULTSET_TYPE);
                            MethodAttribute rsConc = session.getStatementAttribute(MethodAttribute.RESULTSET_CONCURRENCY);
                            MethodAttribute holdability = session.getConnecitonAttribute(MethodAttribute.SET_HOLDABILITY);
                            logger.info("Creating Callable Statement with RS TYPE, CONCURRENCY and HOLDABILITY");
                            stmt = conn.prepareCall(sql, ((Integer)rsType.getAttribute()).intValue(), ((Integer)rsConc.getAttribute()).intValue(), ((Integer)holdability.getAttribute()).intValue());
                            break;
                        }
                        default : {
                            logger.info("Creating Default Callable Statement");
                            stmt = conn.prepareCall(sql);
                            break;
                        }
                    }//switch
                }
            } catch (SQLException sqle) {
                response.setException(sqle);
                sqle.printStackTrace();
            } catch (Exception e) {
                response.setException(e);
                e.printStackTrace();
            } finally {
                if (stmt != null) {
                    statementResponse.setID(stmt.hashCode());
                    delegate.registerStmt(conn,stmt);
                }
            }
    
            if (param != null && request.getCommand() != Constants.EXECUTE_BATCH) {
                for (DALArgs arg : param ) {
                    DALUtil.setStmtParameter(conn,(PreparedStatement)stmt,arg);
                }//for
            }//if
            
        } catch (SQLException sqle) {
            response.setException(sqle);
            sqle.printStackTrace();
        } catch (Exception e) {
            response.setException(e);
            e.printStackTrace();
        }

        return stmt;
    }

    /**
     * 
     * @param stmt
     * @param resultSet
     * @param rsResponse
     * @throws SQLException
     */
    protected void readResultSetAndcreateResponse(Statement stmt, ResultSet resultSet, ICallerResponse rsResponse) throws SQLException, Exception {
        delegate.registerResultSet(stmt,resultSet);

        DALCursor cursor =  (DALCursor)DALUtil.getResultSet(stmt,resultSet);

        rsResponse.setID(cursor.getCurSorID());
        rsResponse.set(Constants.RESPONSE,cursor);
    }

    /**
     * 
     * @param request
     */
    private void setSQL(IDALRequest request) {
        sql = (String)request.getSession().getStatementAttribute(MethodAttribute.SQL).getAttribute();    
    }    
}
