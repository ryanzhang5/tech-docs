package com.wm.dal.jms.apps;

import com.wm.weblib.jms.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.wm.configmgmt.common.jms.WMMessageConfigChangeNotification;

/**
 * Factory class to generate admin queue related message.
 */

public class WMMessageAdminFactory extends MessageFactory {
    private static final Logger logger = Logger.getLogger(WMMessageAdminFactory.class.getName());

    /**
     * parses JMS text message and generates list of WMMessages.
     *
     * @param m JMS text message
     * @return list of WMMessages
     * @throws WMMessageException
     */
    public List<WMMessage> parseJMSTextMessage(javax.jms.TextMessage m) throws WMMessageException {

        try {
            String textMessage = m.getText();
            List<WMMessage> msgs = createMessage(textMessage);

            for (int i = 0; i < msgs.size(); i++) {
                WMMessage msg = msgs.get(i);

                //createMessage doesn't have time stamp,
                //so set it from JMS message time stamp
                msg.setTimestamp(new Date(m.getJMSTimestamp()));
                int indx = ((m.getText()).lastIndexOf("origin="));
                msg.setOriginServer(m.getText().substring(indx + 7));
            }

            return msgs;

        } catch (javax.jms.JMSException e) {
            throw new WMMessageException(e.getMessage());
        }

    }

    public List<WMMessage> parseJMSObjectMessage(WMJMSObjectMessage message) throws WMMessageException {
        List<WMMessage> msgs = new ArrayList();

        HashMap<String, String> valueMap = new HashMap<String, String>();
        valueMap.put(WMMessage.MSG_TYPE_KEY, message.getMsgType());
        valueMap.put(WMMessage.ORIGIN, message.getOrigin());
        valueMap.put(WMMessage.TARGET, message.getTarget());

        WMMessage msg = getMessage(valueMap);

        //msg.setOriginServer(message.getOrigin());
        msg.setObjectMessage(message.getObjectMessage());

        msgs.add(msg);

        return msgs;
    }


    /**
     * parses text message and generates list of WMMessages.
     *
     * @param textMessage text message
     * @param targetRegex target host name if any
     * @return list of WMMessages
     * @throws WMMessageException
     */
    public List<WMMessage> createMessage(String textMessage, String targetRegex) throws WMMessageException {

        ArrayList msgs = new ArrayList();

        List<HashMap> valueMaps = WMMessageParser.parse(textMessage, targetRegex);

        for (int i = 0; i < valueMaps.size(); i++) {
            WMMessage msg = createMessage(valueMaps.get(i));
            msgs.add(msg);
        }

        return msgs;
    }


    /**
     * parses text message and generates list of WMMessages.
     *
     * @param textMessage text message
     * @return list of WMMessages
     * @throws WMMessageException
     */
    public List<WMMessage> createMessage(String textMessage) throws WMMessageException {

        ArrayList msgs = new ArrayList();

        List<HashMap> valueMaps = WMMessageParser.parse(textMessage, null);

        for (int i = 0; i < valueMaps.size(); i++) {
            WMMessage msg = createMessage(valueMaps.get(i));
            msgs.add(msg);
        }

        return msgs;
    }


    private WMMessage createMessage(HashMap valueMap) throws WMMessageException {

        return getMessage(valueMap);
    }


    /**
     * method to create WMMessage object
     *
     * @param valueMap map containing message information after parsing.
     * @return WMMessage a WMMessage object.
     * @throws WMMessageException
     */
    private WMMessage getMessage(HashMap<String, String> valueMap) throws WMMessageException {
        WMMessage msg = super.newInstance(valueMap);
        if (msg != null) {
            return msg;
        }

        String msgType = valueMap.get(WMMessage.MSG_TYPE_KEY);

        if (_qName == null || _qName.trim().length() == 0 || _qSchema == null || _qSchema.trim().length() == 0) {
            throw new WMMessageException("JMS queue name is null");
        }

        if (msgType.equals(WMMessageType.MSG_TYPE_PING.toString())) {
            msg = new WMMessageAdminPing();
        }

        if (msgType.equals(WMMessageType.MSG_TYPE_CONFIG_MGMT_NOTIFICATION.toString())) {
            msg = new WMMessageConfigChangeNotification(valueMap);
        }

        if (msg != null) {
            msg.setQueueInfo(_qName, _qSchema);
            return msg;
        } else {
            throw new WMMessageException("Invalid Message received " + msgType);
        }

    }


    public static void main(String[] argvs) {
        if (argvs.length == 0) {
            logger.info("java WMMessageAdminFactory message");
        } else {
            try {
                List<WMMessage> msgs = (new WMMessageAdminFactory()).createMessage(argvs[0]);
            } catch (Exception e) {
                logger.log(Level.WARNING, "DEFAULT ERROR MSG", e);
            }
        }
    }
}

