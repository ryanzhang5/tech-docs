/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.conditions;

import com.wm.dal.router.plugins.default_.ICondition;

import java.util.logging.Logger;
import java.util.logging.Level;

/**
 * AndCondition - evaluates a list of child conditions and returns true if
 * all of them return true. If the list of child conditions is empty,
 * this class returns a true - aligned with commons-collection's AllPredicate
 *
 * @author mkishore
 * @since 1.0
 */
public class AndCondition<T> extends AbstractCompositeCondition<T> {
    private static final Logger logger = Logger.getLogger(AndCondition.class.getName());

    /**
     * Returns true if all of the child conditions evaluate to true.
     *
     * @param context the context that is passed into the child conditions
     * @return true if all of the child conditions evaluate to true.
     */
    public boolean evaluate(T context) {
        for (ICondition<T> condition : conditions) {
            if (!condition.evaluate(context)) {
                logger.fine(this.getClass().getSimpleName() + " - Evaluated: " + false);
                return false;
            }
        }
        if (logger.isLoggable(Level.FINE)) {
            logger.fine(this.getClass().getSimpleName() + " - Evaluated: " + true);
        }
        return true;
    }

}