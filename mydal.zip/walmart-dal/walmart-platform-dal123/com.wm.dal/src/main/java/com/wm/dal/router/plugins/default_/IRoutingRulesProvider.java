/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_;

import com.wm.dal.router.IRouter;

import java.io.IOException;

/**
 * IRoutingRulesProvider - the interface responsible for fetching the routing-rules
 * from some persistent store.
 *
 * @author mkishore
 * @since 1.1
 */
public interface IRoutingRulesProvider {
    /**
     * Returns the name of this provider.
     *
     * @return the name of the provider
     */
    public String getName();

    /**
     * It is upto the implementing class to decide if the rules need to be re-fetched
     * from the persistent store. 
     *
     * @return true, if the implementation detects that the rules have changed in the
     * persistent store.
     */
    public boolean needsRefresh() throws IOException;

    /**
     * The implementation needs to fetch the routing-rules from the persistent store
     * and return it as a byte[].
     *
     * @return the bytes corresponding to an XML string representing the routing-rules.
     */
    public byte[] getRoutingRules() throws IOException;

    /**
     * Allows the implementation to use the router's name etc. to lookup the rules.
     *
     * @param router - The parent Router object
     */
    public void setRouter(IRouter router);
}
