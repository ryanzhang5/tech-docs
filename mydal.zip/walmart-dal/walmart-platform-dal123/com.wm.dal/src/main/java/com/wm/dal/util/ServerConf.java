/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 */


package com.wm.dal.util;

import javassist.bytecode.Descriptor.Iterator;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.MalformedObjectNameException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.logging.LogManager;
import java.io.IOException;
import java.io.FileInputStream;
import java.lang.management.ManagementFactory;
  
import com.wm.corelib.config.AppConfig;

/**
 * @author cshah
 */
public class ServerConf {
    private static final String DAL_CONF_PORT = "dal.port";
    private static final String DAL_SERVER_MODE_ENABLED = "dal.server.mode.enabled";
    private static final String DAL_SERVER_TYPE = "dal.server.type";
    private static final String MAX_OBJECT_SIZE = "dal.max.object.size";
    private static final String HTTP_PORT = "dal.http.server.port";
    private static final String RESOURCE_BASE = "dal.http.server.resourcebase";
    private static final String HOST_NAME = "com.wm.hostname.real";

    public static final String SESSION_ADMIN_USER = "com.wm.dal.admin.user";
    public static final String SESSION_ADMIN_PASSWORD = "com.wm.dal.admin.password";
    public static final String LOG_LEVEL = "dal.loglevel";

    public static final String MAX_IO_WORKER_THREAD = "dal.max.io.worker.thread";
    public static final String EXECUTOR_THREAD = "dal.executor.thread";

    private static boolean reuseAddress = true;
    private static boolean tcpNoDelay = true;
    private static boolean keepAlive = true;
    private static int soLinger = -1;
    private static int BACK_LOG = 1024;

    public static final int MAX_IO_WORKER_THREAD_COUNT = 500;
    public static final int EXECUTOR_THREAD_COUNT = 10;
    public static final int MB = 1024 * 1024;
    public static final int MAX_CHANNEL_MEM_SIZE = 10 * MB;
    public static final int MAX_TOTAL_MEM_SIZE = 50 * MB;


    private static final DALLogger logger = DALLogger.getInstance();
    private static final String IGNORABLE_EXCEPTION = "Cursor is closed.;";
    private static final int[] IGNORABLE_ERROR_CODE = new int[]{0};

    private static String hostName = null;

    public static final String WALMARTDOTCOM = ".walmart.com";
    private static boolean inServerVM = false;

    /**
     * @return port number integer
     */
    public static synchronized final int getPort() {
        int rv = 1729;
        try {
            String str = AppConfig.getInstance().getProperty(DAL_CONF_PORT);
            rv = Integer.parseInt(str);
        } catch (NumberFormatException e) {
            logger.log(DALLogger.LEVEL_SEVERE, "Failed to read port number. Using default");
        }
        return rv;
    }

    /**
     * Loads the configuration file
     *
     * @param confFile configuration file path
     */
    public static synchronized final void loadConfig(String confFile) throws DALException {
        try {
            if (!confFile.startsWith("/")) {
                confFile = "/" + confFile;
            }
            logger.warning(" * loadConfig in ServerConf: config file is [" + confFile + "]");
            AppConfig.getInstance().getProperties().load(new FileInputStream(confFile));
        } catch (Exception fne) {
            throw new DALException("ERROR: Failed to load configuration file: " + confFile, fne);
        }

        if (!validateVitalProperties()) {
            System.err.println("Error: conf file (" + confFile + ") is missing vital information. Exiting...");
            System.exit(1);
        }

        try {
            // Java Logging Framework from SDKv1.4
            String logProp = AppConfig.getInstance().getProperty("java.util.logging.config.file");
            if ((logProp != null) && (logProp.length() > 0)) {
                logger.warning("LOGGING SETUP: config file is [" + logProp + "]");
                LogManager.getLogManager().readConfiguration();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        //Update the JMX Mbean for properties.HardCoded the ConfigMgmtAdmin.Can be passed in as an aragument from props.
        try {
            MBeanServerConnection mbsc = null;
            mbsc = ManagementFactory.getPlatformMBeanServer();
            ObjectName configMgmtBean = new ObjectName("ConfigMgmtAdmin:name=ConfigMgmt");
            //for (ObjectName mbean : mbsc.queryNames(configMgmtBean, null)) {
            java.util.Iterator iter = mbsc.queryNames(configMgmtBean, null).iterator();
            while(iter.hasNext())
                mbsc.invoke((ObjectName) iter.next(), "load", null, null);
        }
        catch (MalformedObjectNameException mone) {
            mone.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * @return
     */
    private static synchronized boolean validateVitalProperties() {
        boolean result = true;
        if (AppConfig.getInstance().getProperty(DAL_CONF_PORT) == null) {
            System.err.println(DAL_CONF_PORT + " must be defined in the conf file");
            result = false;
        }
        return result;
    }

    /**
     * @return
     */
    public static boolean isServerModeEnabled() {
        boolean rv = false;
        try {
            if (AppConfig.getInstance().getProperty(DAL_SERVER_MODE_ENABLED) != null)
                rv = Boolean.parseBoolean(AppConfig.getInstance().getProperty(DAL_SERVER_MODE_ENABLED));
        } catch (Exception e) {
            rv = true;
            System.err.println("Using default mode: " + rv);
            e.printStackTrace();
        }
        return rv;
    }

    /**
     * @return
     */
    public static int getExecutorThreadCount() {
        int rv = EXECUTOR_THREAD_COUNT;
        try {
            String str = AppConfig.getInstance().getProperty(EXECUTOR_THREAD);
            rv = Integer.parseInt(str);
        } catch (NumberFormatException e) {
            logger.log(DALLogger.LEVEL_SEVERE, "Failed to read executor threads number. Using default " + EXECUTOR_THREAD_COUNT);
        }
        return rv;
    }

    /**
     * @return
     */
    public static int getMaxChannelMemorySize() {
        return MAX_CHANNEL_MEM_SIZE;
    }

    /**
     * @return
     */
    public static int getTotalMemorySize() {
        return MAX_TOTAL_MEM_SIZE;
    }

    /**
     * @return
     */
    public static int getMaxIOWorkerThreadCount() {
        int rv = MAX_IO_WORKER_THREAD_COUNT;
        try {
            String str = AppConfig.getInstance().getProperty(MAX_IO_WORKER_THREAD);
            rv = Integer.parseInt(str);
        } catch (NumberFormatException e) {
            logger.log(DALLogger.LEVEL_SEVERE, "Failed to read max IO worker threads number. Using default " + MAX_IO_WORKER_THREAD_COUNT);
        }
        return rv;
    }

    /**
     * @return
     */
    public static int getSOLinger() {
        return soLinger;
    }

    /**
     * @return
     */
    public static boolean getKeepAlive() {
        return keepAlive;
    }

    /**
     * @return
     */
    public static boolean getReuseAddress() {
        return reuseAddress;
    }

    /**
     * @return
     */
    public static boolean getTCPNoDely() {
        return tcpNoDelay;
    }

    /**
     * @return
     */
    public static int getBackLog() {
        return BACK_LOG;
    }

    /**
     * @return
     */
    public static final int getLogLevel() {
        int rv = DALLogger.LEVEL_WARNING;
        try {
            rv = Integer.parseInt(AppConfig.getInstance().getProperty(LOG_LEVEL));
        } catch (Exception e) {
            System.err.println("Using default logging level: " + rv);
        }
        return rv;
    }

    /**
     * @param logLevel
     * @param prefix
     */
    public static final void setLogParameters(int logLevel, String prefix) {
        logger.setLevel(logLevel);
        logger.setPrefix(prefix);
    }

    /**
     * @return
     */
    public static final String getServerType() {
        String serverType = "netty";
        if (AppConfig.getInstance().getProperty(DAL_SERVER_TYPE) != null) {
            serverType = AppConfig.getInstance().getProperty(DAL_SERVER_TYPE);
            if (serverType == null) {
                serverType = "netty";
            }
        } else {
            logger.warning("Using default server type " + serverType);
        }
        return serverType.toLowerCase();
    }

    /**
     *
     */
    public static boolean shouldIgnoreException(String message, int errorCode) {
        boolean isIgnorable = false;
        logger.info("In Ignorable Exception " + message + ":" + errorCode);
        if (message != null && IGNORABLE_EXCEPTION.indexOf(message) >= 0) {
            isIgnorable = true;
        }

        if (message == null) {
            for (int iCode : IGNORABLE_ERROR_CODE) {
                if (errorCode == iCode) {
                    isIgnorable = true;
                }
            }
        }

        return isIgnorable;
    }

    /**
     * @return
     */
    public static int getMaxObjectSize() {
        int objectSize = 5 * 1024 * 1024;

        if (AppConfig.getInstance().getProperty(MAX_OBJECT_SIZE) != null) {
            String objSize = AppConfig.getInstance().getProperty(DAL_SERVER_TYPE);
            if (objSize != null) {
                try {
                    objectSize = Integer.parseInt(objSize);
                    if (objectSize < MB) {
                        objectSize = MB;
                    }
                } catch (Exception e) {
                    logger.warning("Using default Max Object Size " + objectSize);
                }
            }
        }
        return objectSize;
    }

    /**
     * @return
     */
    public static int getHttpPort() {
        int port = 1730;

        if (AppConfig.getInstance().getProperty(HTTP_PORT) != null) {
            String sPort = AppConfig.getInstance().getProperty(HTTP_PORT);
            if (sPort != null) {
                try {
                    port = Integer.parseInt(sPort);
                } catch (Exception e) {
                    logger.warning("Using default Max Object Size " + port);
                }
            }
        }
        return port;
    }

    /**
     * @return
     */
    public static String getResourceBase() {
        String resourceBase = ".";
        if (AppConfig.getInstance().getProperty(RESOURCE_BASE) != null) {
            String resBase = AppConfig.getInstance().getProperty(RESOURCE_BASE);
            if (resBase != null && resBase.length() > 0) {
                resourceBase = resBase;
            }
        }
        return resourceBase;
    }

    /**
     * @return
     */
    public static synchronized String getHostName() {
        if (hostName == null || hostName.length() == 0) {
            try {
                hostName = AppConfig.getInstance().getProperty(HOST_NAME);
                if (hostName == null || hostName.length() == 0) {
                    InetAddress addr = InetAddress.getLocalHost();
                    hostName = addr.getHostName();
                }

                if (hostName != null) {
                    hostName = ServerUtil.getHostName(hostName);
                }

            } catch (UnknownHostException e) {
                ;
            }
        }

        return hostName;
    }

    /**
     * @return
     */
    public static String getConfigUserName() {
        return AppConfig.getInstance().getProperty(SESSION_ADMIN_USER);
    }

    /**
     * @return
     */
    public static String getConfigPassword() {
        return AppConfig.getInstance().getProperty(SESSION_ADMIN_PASSWORD);
    }

    /**
     * @param pInServerVM
     */
    public static void setInServerVM(boolean pInServerVM) {
        inServerVM = pInServerVM;
    }

    /**
     * @return
     */
    public static boolean inServerVM() {
        return inServerVM;
    }

    public static String getPROP_JMS_TIMEOUT() {
        return AppConfig.getInstance().getProperty("PROP_JMS_TIMEOUT");
    }

}
