/* *
 * Copyright 2009 walmart.com. All rights reserved.
 */

package com.wm.dal.jdbc;

import com.wm.dal.jdbc.utils.DALUtil;

import java.io.Serializable;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.*;


/* *
 * Acts as a container for a single data element - and provides some basic
 * type conversion encapsulation.
 *
 * @author cshah
 * @since 1.0
 */
public class Datum implements Serializable {
    private Object value;
    private int type;

    /**
     * This is equivalent to calling new Datum(value, type, false);
     *
     * @param value - the raw value from native result set
     * @param type  - the type as per the result set metadata
     * @throws SQLException - in case of any errors
     */
    public Datum(Object value, int type) throws SQLException {
        this(value, type, false);
    }

    /**
     * Creates a Datum based on the input value. If suppressConversion is set to
     * false, then it will use DALUtil.convertToDALObject() method to convert the
     * raw data into DAL compatible Serializable equivalents.
     *  
     * @param value - the raw value from native result set
     * @param type  - the type as per the result set metadata
     * @param suppressConversion - if true, suppresses the conversion
     * @throws SQLException - in case of any errors
     */
    public Datum(Object value, int type, boolean suppressConversion) throws SQLException {
        this.value = (suppressConversion) ? value : DALUtil.convertToDALObject(value);
        this.type = type;
    }

    public boolean isNull() {
        return value == null;
    }

    public String toString() {
        return getClass().getName() + ", isNull: " + isNull() + ", type: " + type + ", value: " + value;
    }

    public boolean getBoolean() throws SQLException {
        if (value == null) return false;

        if (value instanceof Boolean) {
            return ((Boolean) value);
        }

        return Boolean.valueOf(value.toString());
    }

    public byte getByte() throws SQLException {
        if (value == null) return 0;

        if (value instanceof Byte) {
            return ((Byte) value);
        } else if (value instanceof Short) {
            return ((Short) value).byteValue();
        } else if (value instanceof Integer) {
            return ((Integer) value).byteValue();
        } else if (value instanceof Long) {
            return ((Long) value).byteValue();
        } else if (value instanceof Float) {
            return ((Float) value).byteValue();
        } else if (value instanceof Double) {
            return ((Double) value).byteValue();
        } else if (value instanceof BigDecimal) {
            return ((BigDecimal) value).byteValue();
        }

        return Byte.valueOf(value.toString());
    }

    public short getShort() throws SQLException {
        if (value == null) return 0;

        if (value instanceof Short) {
            return ((Short) value);
        } else if (value instanceof Byte) {
            return ((Byte) value).shortValue();
        } else if (value instanceof Integer) {
            return ((Integer) value).shortValue();
        } else if (value instanceof Long) {
            return ((Long) value).shortValue();
        } else if (value instanceof Float) {
            return ((Float) value).shortValue();
        } else if (value instanceof Double) {
            return ((Double) value).shortValue();
        } else if (value instanceof BigDecimal) {
            return ((BigDecimal) value).shortValue();
        }

        return Short.valueOf(value.toString());
    }

    public int getInt() throws SQLException {
        if (value == null) return 0;

        if (value instanceof Integer) {
            return ((Integer) value);
        } else if (value instanceof Byte) {
            return ((Byte) value).intValue();
        } else if (value instanceof Short) {
            return ((Short) value).intValue();
        } else if (value instanceof Long) {
            return ((Long) value).intValue();
        } else if (value instanceof Float) {
            return ((Float) value).intValue();
        } else if (value instanceof Double) {
            return ((Double) value).intValue();
        } else if (value instanceof BigDecimal) {
            return ((BigDecimal) value).intValue();
        }

        return Integer.valueOf(value.toString());
    }

    public long getLong() throws SQLException {
        if (value == null) return 0;

        if (value instanceof Long) {
            return ((Long) value);
        } else if (value instanceof Byte) {
            return ((Byte) value).longValue();
        } else if (value instanceof Short) {
            return ((Short) value).longValue();
        } else if (value instanceof Integer) {
            return ((Integer) value).longValue();
        } else if (value instanceof Float) {
            return ((Float) value).longValue();
        } else if (value instanceof Double) {
            return ((Double) value).longValue();
        } else if (value instanceof BigDecimal) {
            return ((BigDecimal) value).longValue();
        }

        return Long.valueOf(value.toString());
    }

    public float getFloat() throws SQLException {
        if (value == null) return 0;

        if (value instanceof Float) {
            return ((Float) value);
        } else if (value instanceof Byte) {
            return ((Byte) value).floatValue();
        } else if (value instanceof Short) {
            return ((Short) value).floatValue();
        } else if (value instanceof Integer) {
            return ((Integer) value).floatValue();
        } else if (value instanceof Long) {
            return ((Long) value).floatValue();
        } else if (value instanceof Double) {
            return ((Double) value).floatValue();
        } else if (value instanceof BigDecimal) {
            return ((BigDecimal) value).floatValue();
        }

        return Float.valueOf(value.toString());

    }

    public double getDouble() throws SQLException {
        if (value == null) return 0;

        if (value instanceof Double) {
            return ((Double) value);
        } else if (value instanceof Byte) {
            return ((Byte) value).doubleValue();
        } else if (value instanceof Short) {
            return ((Short) value).doubleValue();
        } else if (value instanceof Integer) {
            return ((Integer) value).doubleValue();
        } else if (value instanceof Long) {
            return ((Long) value).doubleValue();
        } else if (value instanceof Float) {
            return ((Float) value).doubleValue();
        } else if (value instanceof BigDecimal) {
            return ((BigDecimal) value).doubleValue();
        }

        return Double.valueOf(value.toString());
    }

    public java.math.BigDecimal getBigDecimal() {
        if (value == null) return null;

        if (value instanceof BigDecimal) {
            return (BigDecimal) value;
        }

        return BigDecimal.valueOf(Double.valueOf(value.toString()));
    }

    public String getString() throws SQLException {
        if (value == null) return null;

        if (value instanceof BigDecimal) {
            BigDecimal bigDecimal = (BigDecimal) value;
            if (bigDecimal.scale() == 0) {
                return String.valueOf(bigDecimal.longValue());
            } else {
                return String.valueOf(bigDecimal.doubleValue());
            }
        } else if (value instanceof String) {
            return (String) value;
        } else if (value instanceof char[]) {
            return new String((char[]) value);
        } else if (value instanceof byte[]) {
            return new String((byte[]) value);
        } else if (value instanceof DALClob) {
            return new String(((DALClob)value).getData());
        } else if (value instanceof DALBlob) {
            return new String(((DALBlob)value).getData());
        }
        return value.toString();
    }

    public byte[] getBytes() throws SQLException {
        if (value == null) return null;

        if (value instanceof byte[]) {
            return (byte[]) value;
        } else if (value instanceof String) {
            return ((String) value).getBytes();
        } else if (value instanceof DALBlob) {
            return ((DALBlob) value).getData();
        }

        return value.toString().getBytes();
    }

    public java.sql.Date getDate() throws SQLException {
        if (value == null) return null;

        if (value instanceof Date) {
            return (Date) value;
        } else if (value instanceof Long) {
            return new Date((Long) value);
        } else if (value instanceof Time) {
            return new Date(((Time) value).getTime());
        } else if (value instanceof Timestamp) {
            return new Date(((Timestamp) value).getTime());
        }

        return new Date(Long.valueOf(value.toString()));

    }

    public Time getTime() throws SQLException {
        if (value == null) return null;

        if (value instanceof Time) {
            return (Time) value;
        } else if (value instanceof Long) {
            return new Time((Long) value);
        } else if (value instanceof Timestamp) {
            return new Time(((Timestamp) value).getTime());
        } else if (value instanceof Date) {
            return new Time(((Date) value).getTime());
        }

        return new Time(Long.valueOf(value.toString()));

    }

    public Timestamp getTimestamp() throws SQLException {
        if (value == null) return null;

        if (value instanceof Timestamp) {
            return (Timestamp) value;
        } else if (value instanceof Long) {
            return new Timestamp((Long) value);
        } else if (value instanceof Time) {
            return new Timestamp(((Time) value).getTime());
        } else if (value instanceof Date) {
            return new Timestamp(((Date) value).getTime());
        }

        return new Timestamp(Long.valueOf(value.toString()));
    }

    public URL getURL() throws SQLException {
        if (value == null) return null;

        if (value instanceof URL) {
            return (URL) value;
        }

        try {
            return new URL(value.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
            throw new SQLException("Error converting the value to a URL: " + e.getMessage(),e);
        }
    }

    public Blob getBlob() throws SQLException {
        if (value == null) return null;

        if (value instanceof Blob) {
            return (Blob) value;
        } else if (value instanceof byte[]) {
            return new DALBlob((byte[]) value);
        } else if (value instanceof String) {
            return new DALBlob(((String) value).getBytes());
        }

        throw new SQLException("Could not convert the value into a Blob: " + value);
    }

    public Clob getClob() throws SQLException {
        if (value == null) return null;

        if (value instanceof Clob) {
            return (Clob) value;
        } else if (value instanceof byte[]) {
            return new DALClob((byte[]) value);
        } else if (value instanceof char[]) {
            return new DALClob((char[]) value);
        } else if (value instanceof String) {
            return new DALClob((String) value);
        }

        throw new SQLException("Could not convert the value into a Clob: " + value);
    }

    /**
     * Please note that this method does not perform any conversions. The caller is
     * responsible for using java.sql.Array#getArray() method and pass in a suitable
     * TypeMap - for converting the Structs to SQLData elements.
     *
     * @return an Array instance
     * @throws SQLException - in case of any errors
     */
    public Array getArray() throws SQLException {
        if (value == null) return null;

        if (value instanceof Array) {
            return (Array) value;
        }

        throw new SQLException("Could not convert the value into an Array: " + value);
    }

    /**
     * Please note that this method does not perform any conversions. The caller is
     * responsible for using DALUtil.processGetObject() method and pass in a suitable
     * TypeMap - for converting the Struct to SQLData element.
     *
     * @return an Object
     * @throws SQLException - in case of any errors
     */
    public Object getObject() throws SQLException {
        return value;
    }

}
