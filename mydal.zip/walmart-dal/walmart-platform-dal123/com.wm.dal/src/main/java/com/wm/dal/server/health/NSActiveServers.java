package com.wm.dal.server.health;

import NSConfig.GetlbvserverResult;
import NSConfig.Lbvserver;
import NSConfig.NSConfigBindingStub;

import NSConfig.SimpleResult;

import java.net.URL;

import java.util.logging.Logger;
  
import com.wm.corelib.config.AppConfig;

public class NSActiveServers implements IActiveServers {
    private static final Logger logger = Logger.getLogger(NSActiveServers.class.getName());
    private static final String NS_URL = "dal.ns.url";
    private static final String NS_USER = "dal.ns.user";
    private static final String NS_PASSWORD = "dal.ns.password";
    private static final String NS_LBSERVER = "dal.ns.lbserver";
    
    /**
     * 
     */
    public NSActiveServers() {
    }
    
    /**
     *
     * @return
     */
    public float getAndCheckServerCount() {
        String  soap_server;
        NSConfigBindingStub client ;
        SimpleResult result;
        GetlbvserverResult getlbvserverresult = null;
        int totalUPServers = 0;
        int totalDOWNServers = 0;
        float totalPercentile = 0;
        try {
            if (getURL() == null || getURL().trim().length() == 0)  {
                    return totalPercentile;
            }
            // Initialized the client stub
            soap_server = "http://"+ getURL() +"/soap";
            client  = new NSConfigBindingStub(new URL(soap_server),null);
            client.setMaintainSession(true);

            result = client.login(getUser(),getPassword());
            getlbvserverresult = client.getlbvserver(getLBServer());

            for(int i =0 ; i < getlbvserverresult.getList().length;i++) {
                Lbvserver  obj;
                obj = getlbvserverresult.getList()[i];
                            
                for (int k=0; obj.getSvcstate() != null && k < obj.getSvcstate().length; k++) {
                    if ("UP".equals(obj.getSvcstate()[k])) {
                        totalUPServers++;    
                    } else if ("DOWN".equals(obj.getSvcstate()[k])) {
                        totalDOWNServers++;    
                    }
                    
                    logger.info("Server Info : " + obj.getSvcstate()[k] + ":" + obj.getServicename()[k] + ":" +
                        obj.getSvcipaddress()[k] + ":" + obj.getSvcport()[k] + ":" + obj.getSvctype()[k]);    
                }//for
            }//for
                result = client.logout();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        logger.warning("Netscalar total UP servers:" + totalUPServers + ", total DOWN servers:" + totalDOWNServers);
        
        if (totalUPServers == 0) {
            return totalPercentile;
        }
        
        totalPercentile = (float) (totalUPServers + totalDOWNServers )/ totalUPServers;
        return totalPercentile;
    }

    /**
     *
     * @return
     */
    private String getURL() {
        return AppConfig.getInstance().getProperty(NS_URL,"");    
    }
    
    /**
     *
     * @return
     */
    private String getUser() {
        return AppConfig.getInstance().getProperty(NS_USER,"");    
    }

    /**
     *
     * @return
     */
    private String getPassword() {
        return AppConfig.getInstance().getProperty(NS_PASSWORD,"");    
    }

    /**
     *
     * @return
     */
    private String getLBServer() {
        return AppConfig.getInstance().getProperty(NS_LBSERVER,"");    
    }

}
