/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.jdbc.sqldata;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DALWriteOnlySQLData - wrapper to support creation of simple serializable of SQLData instances
 *
 * @author mkishore
 * @since 1.0
 */
public class DALWriteOnlySQLData implements SerializableSQLData {
    private String SQLTypeName;
    private List<Object> data = new ArrayList<Object>();

    public DALWriteOnlySQLData(String SQLTypeName) {
        this.SQLTypeName = SQLTypeName;
    }

    public String getSQLTypeName() throws SQLException {
        return SQLTypeName;
    }

    public void readSQL(SQLInput stream, String typeName) throws SQLException {
        throw new SQLException("Method not implemented");
    }

    public void writeSQL(SQLOutput stream) throws SQLException {
        for (Object x : data) {
            if (x instanceof String) {
                stream.writeString((String) x);
            } else if (x instanceof Boolean) {
                stream.writeBoolean((Boolean) x);
            } else if (x instanceof Byte) {
                stream.writeByte((Byte) x);
            } else if (x instanceof Short) {
                stream.writeShort((Short) x);
            } else if (x instanceof Integer) {
                stream.writeInt((Integer) x);
            } else if (x instanceof Long) {
                stream.writeLong((Long) x);
            } else if (x instanceof Float) {
                stream.writeFloat((Float) x);
            } else if (x instanceof Double) {
                stream.writeDouble((Double) x);
            } else if (x instanceof BigDecimal) {
                stream.writeBigDecimal((BigDecimal) x);
            } else if (x instanceof byte[]) {
                stream.writeBytes((byte[]) x);
            } else if (x instanceof Timestamp) {
                stream.writeTimestamp((Timestamp) x);
            } else if (x instanceof Time) {
                stream.writeTime((Time) x);
            } else if (x instanceof Date) {
                stream.writeDate((Date) x);
            } else if (x instanceof URL) {
                stream.writeURL((URL) x);
            } else if (x instanceof SQLData) {
                ((SQLData) x).writeSQL(stream);
            } else if (x instanceof Blob) {
                // TODO: need a ThreadLocal connection to convert this into Oracle
                // not used in 9.6
                stream.writeBlob((Blob)x);
            } else if (x instanceof Clob) {
                // TODO: need a ThreadLocal connection to convert this into Oracle
                // not used in 9.6
                stream.writeClob((Clob)x);
            } else if (x instanceof NullObject) {
                try {
                    ((NullObject) x).getMethod().invoke(stream, NULL_ARG);
                } catch (Exception e) {
                    e.printStackTrace();
                    throw new SQLException(e);
                }
            }
        }
    }

    public void writeString(String x) throws SQLException {
        data.add(x != null ? x : new NullObject("writeString", String.class));
    }

    public void writeBoolean(boolean x) throws SQLException {
        data.add(x);
    }

    public void writeByte(byte x) throws SQLException {
        data.add(x);
    }

    public void writeShort(short x) throws SQLException {
        data.add(x);
    }

    public void writeInt(int x) throws SQLException {
        data.add(x);
    }

    public void writeLong(long x) throws SQLException {
        data.add(x);
    }

    public void writeFloat(float x) throws SQLException {
        data.add(x);
    }

    public void writeDouble(double x) throws SQLException {
        data.add(x);
    }

    public void writeBigDecimal(BigDecimal x) throws SQLException {
        data.add(x != null ? x : new NullObject("writeBigDecimal", BigDecimal.class));
    }

    public void writeBytes(byte[] x) throws SQLException {
        data.add(x != null ? x : new NullObject("writeBytes", byte[].class));
    }

    public void writeDate(Date x) throws SQLException {
        data.add(x != null ? x : new NullObject("writeDate", Date.class));
    }

    public void writeTime(Time x) throws SQLException {
        data.add(x != null ? x : new NullObject("writeTime", Time.class));
    }

    public void writeTimestamp(Timestamp x) throws SQLException {
        data.add(x != null ? x : new NullObject("writeTimestamp", Timestamp.class));
    }

    public void writeURL(URL x) throws SQLException {
        data.add(x != null ? x : new NullObject("writeURL", URL.class));
    }

    // The following inputs do not implement the Serializable interface
    // It is upto the clients to ensure that they pass in a Serializable implementation

    public void writeObject(SQLData x) throws SQLException {
        data.add(x != null ? (Object)x : new NullObject("writeObject", SQLData.class));
    }

    public void writeBlob(Blob x) throws SQLException {
        data.add(x != null ? (Object)x : new NullObject("writeBlob", Blob.class));
    }

    public void writeClob(Clob x) throws SQLException {
        data.add(x != null ? (Object)x : new NullObject("writeClob", Clob.class));
    }

    /*

    public void writeCharacterStream(Reader x) throws SQLException {
        data.add(x);
    }

    public void writeAsciiStream(InputStream x) throws SQLException {
        data.add(x);
    }

    public void writeBinaryStream(InputStream x) throws SQLException {
        data.add(x);
    }

    public void writeRef(Ref x) throws SQLException {
        data.add(x);
    }

    public void writeStruct(Struct x) throws SQLException {
        data.add(x);
    }

    public void writeArray(Array x) throws SQLException {
        data.add(x);
    }

    public void writeNString(String x) throws SQLException {
        data.add(x);
    }

    public void writeNClob(NClob x) throws SQLException {
        data.add(x);
    }

    public void writeRowId(RowId x) throws SQLException {
        data.add(x);
    }

    public void writeSQLXML(SQLXML x) throws SQLException {
        data.add(x);
    }

    */
    private static final Object[] NULL_ARG = {null};

    private static class NullObject implements Serializable {
        private String method;
        private Class<?>[] params;

        private NullObject(String method, Class<?>... params) {
            this.method = method;
            this.params = params;
        }

        public Method getMethod() throws NoSuchMethodException {
            return SQLOutput.class.getMethod(method, params);
        }
    }
}
