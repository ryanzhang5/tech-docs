/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.client;

import java.io.Serializable;

/**
 * @author cshah
 * @version 1.0
 */
public interface IDALResponse extends Serializable {
    /**
     * @return
     */
    public Exception getException();

    /**
     * @param exp
     */
    public void setException(Exception exp);

    public Object getResult();
    public void setResult(Object result);
    
    /**
     * @return
     */
    public ICallerResponse getConnectionResponse() ;

    /**
     * @return
     */
    public ICallerResponse getStatementResponse() ;

    /**
     * @return
     */
    public ICallerResponse getResultSetResponse() ;

    /**
     * 
     * @param serverHost
     */
    public void setServerEndPoint(String serverEndPoint) ;

    /**
     * 
     * @return
     */
    public String getServerEndPoint() ;

    /**
     * Set the name of the pool that ultimately served the request.
     *
     * @param poolName - name of a database connection pool
     */
    public void setPoolName(String poolName);

    /**
     * Return the name of the pool that ultimately served the request.
     *
     * @return the name of the pool that ultimately served the request
     */
    public String getPoolName();
    
}

