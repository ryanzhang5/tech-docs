/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.server;

import com.wm.dal.util.DALLogger;

/**
 * 
 * @author cshah
 * @version 1.0
 */
public abstract class AbstractDALServer implements Runnable {
    private int port = 1729;
    protected static final DALLogger logger = DALLogger.getInstance();
    
    private static AbstractDALServer instance;
    /**
     * 
     * @param port
     */

    public AbstractDALServer(int port) {
         if ( port <= 0 ) {
             logger.severe(this.getClass().getName() + "/setPort(): Port is not Valid...");
             shutdownNow();
             System.exit(-1);
         }
            
        this.port = port;
        instance = this;
    }
    
    /**
     * 
     */
    public abstract void run() ;

    /**
     * 
     */
    public abstract void shutdownNow();

    /**
     * 
     * @return
     */
    public int getPort() {
        return this.port;
    }

    /**
     * 
     * @return
     */
    public static AbstractDALServer getInstance() {
        return instance;
    }
}
