/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.conditions;

import com.wm.dal.router.plugins.default_.RouterContext;

/**
 * ClientHostCondition - evaluates a condition based on the client making a
 * DAL request.
 *
 * @author mkishore
 * @since 1.0
 */
public class ClientHostCondition extends AbstractStringNumericCondition<RouterContext> {

    /**
     * Returns the string that needs to be tested.
     *
     * @param context - the context object
     * @return the string that needs to be tested
     */
    protected String getStringToTest(RouterContext context) {
        return context.getRequest().getSession().getClientHost();
    }
}
