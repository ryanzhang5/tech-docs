package com.wm.dal.common;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.resource.spi.XATerminator;
import javax.transaction.InvalidTransactionException;
import javax.transaction.Status;
import javax.transaction.SystemException;
import javax.transaction.Transaction;
import javax.transaction.xa.XAException;
import javax.transaction.xa.XAResource;
import javax.transaction.xa.Xid;

import com.arjuna.ats.internal.jta.transaction.arjunacore.jca.SubordinationManager;
import javax.transaction.TransactionManager;
import com.wm.dal.client.DALResponse;
import com.wm.dal.client.IDALRequest;
import com.wm.dal.client.IDALResponse;
import com.wm.dal.jdbc.utils.Constants;
import com.wm.dal.jdbc.utils.MethodAttribute;

public class XAResourceCommand implements ICommand {
	private static final Logger m_logger = Logger.getLogger(XAResourceCommand.class.getName());
  
	@Override
	public IDALResponse execute(IDALRequest request) throws XAException {
		int command = request.getCommand();
		IDALResponse response = new DALResponse();
		XATerminator xaTerminator = SubordinationManager.getXATerminator();
		if (xaTerminator == null)
			throw new NullPointerException(
					"No XATerminator Initialized -- XA Not Enabled!");

		switch (command) {
		case Constants.XA_COMMIT:
		case Constants.XA_COMMIT_ONEPHASE:
			xaTerminator.commit(request.getXid(),
					command == Constants.XA_COMMIT_ONEPHASE);
			break;

		case Constants.XA_FORGET:
			xaTerminator.forget(request.getXid());
			break;

		case Constants.XA_PREPARE:
			response.setResult(xaTerminator.prepare(request.getXid()));
			break;

		case Constants.XA_RECOVER:
			throw new UnsupportedOperationException();

		case Constants.XA_ROLLBACK:
			xaTerminator.rollback(request.getXid());
			break;

		default:
			response.setException(new UnsupportedOperationException(
					Constants.UNSUPPORTED_EXCEPTION + ": Constans." + command));
		}
		return response;
	}

	private Transaction start(Xid externalTxId, Integer flags) throws XAException {
		Transaction tx = SubordinationManager.getTransactionImporter()
				.getImportedTransaction(externalTxId);

		if (flags == null)
		  return tx;
		
		if ((flags & (XAResource.TMRESUME | XAResource.TMJOIN)) != 0) 
		{
			if (tx == null)
				throw new XAException(XAException.XAER_NOTA);
		} 
		else if (tx != null)
			throw new XAException(XAException.XAER_DUPID);
		else
			tx = SubordinationManager.getTransactionImporter().importTransaction(
					externalTxId);
		
		return tx;
	}

	/**
	 * Associate the JTA transaction to the current Thread. 
	 * Typically used by a server side inbound handler.
	 */
	public void maybeResume(Xid externalTxId, DALSession session) 
	    throws InvalidTransactionException, SystemException, XAException 
	{
    if (m_logger.isLoggable(Level.FINE))
      m_logger.fine("XAResourceCommand.resume(Xid=" + externalTxId + ")");
    
	  Integer flags = null;
		if (session.getXAAttribute(MethodAttribute.XA_FLAGS) != null)
				flags = (Integer)(session.getXAAttribute(MethodAttribute.XA_FLAGS).getAttribute());
	  
	  Transaction tx = start(externalTxId, flags);
	  
		if (tx == null)
			throw new XAException(XAException.XAER_NOTA);

		switch (tx.getStatus()) {
		// TODO: other cases?

		  case Status.STATUS_ACTIVE:
		  case Status.STATUS_MARKED_ROLLBACK:
		  case Status.STATUS_COMMITTING:
		    break;
		  default:
		    throw new IllegalStateException("Transaction not in state ACTIVE");
		}

		TransactionManager txManager = com.arjuna.ats.jta.TransactionManager.transactionManager();

		if (session.getXAAttribute(MethodAttribute.XA_TRANSACTION_TIMEOUT) != null)
      txManager.setTransactionTimeout((Integer) session.getXAAttribute(MethodAttribute.XA_TRANSACTION_TIMEOUT).getAttribute());
      
		txManager.resume(tx);
	}

	/**
	 * Disassociate the JTA transaction from the current Thread. Typically used
	 * by a server side outbound handler.
	 * 
	 * @throws SystemException
	 */
	public void suspend() throws SystemException {
		m_logger.fine("XAResourceCommand.suspend()");
		TransactionManager txManager = com.arjuna.ats.jta.TransactionManager.transactionManager();
		txManager.suspend();
	}
}
