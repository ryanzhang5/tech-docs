/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc.args;

import java.math.BigDecimal;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;

/**
 * @author cshah
 * @version 1.0
 */
public class IntArg extends DALArgs {
    private int value;

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    public IntArg( int position, boolean isOut, boolean isNull, int value ) {
        init( position, isOut, isNull, value );
    }

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    protected void init( int position, boolean isOut, boolean isNull, int value ) {
        super.init( position, isOut, isNull, java.sql.Types.INTEGER );
        this.value = value;
    }

    /**
     * @return
     */
    public int getValue() { return value; }

    /**
     * @return
     */
    public Object getValueObject() { return new Integer( getValue() ); }

    /**
     * @param value
     * @throws SQLException
     */
    public void setValueObject(Object value) throws SQLException {
        if (value != null && value instanceof Double) {
            this.value = ((Double)value).intValue();
        } else if (value != null && value instanceof Long) {
            this.value = ((Long)value).intValue();
        } else if (value != null && value instanceof Float) {
            this.value = ((Float)value).intValue();
        } else if (value != null && value instanceof Short) {
            this.value = ((Short)value).shortValue();
        } else if (value != null && value instanceof Integer) {
            this.value = ((Integer)value).intValue();
        } else if (value != null && value instanceof BigDecimal) {
            this.value = ((BigDecimal)value).intValue();
        } else if (value != null && value instanceof Date) {
            this.value = (int)((Date)value).getTime();
        } else if (value != null && value instanceof Time) {
            this.value = (int)((Time)value).getTime();
        } else if (value != null && value instanceof Timestamp) {
            this.value = (int)((Timestamp)value).getTime();
        }

    }

    /**
     * @return
     */
    public String toString() { return super.toString() + ", value = |" + value + "|"; }

}
