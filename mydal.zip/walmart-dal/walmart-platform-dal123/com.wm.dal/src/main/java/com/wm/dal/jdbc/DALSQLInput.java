/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.jdbc;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.*;

/**
 * DALSQLInput - wraps an Object[] and can be passed into SQLData.readSQL() method.
 * Please note that this class does not perform any type-conversions - the constructor
 * expects an array of "converted" objects. 
 *
 * @author mkishore
 * @since 1.1
 */
public class DALSQLInput implements SQLInput {
    private Datum[] attributes;

    private int index;
    private boolean wasNull;

    public DALSQLInput(Object[] attributes) throws SQLException {
        if (attributes != null) {
            this.attributes = new Datum[attributes.length];
            for (int i = 0; i < attributes.length; i++) {
                // pass in "true" to suppress further conversions here
                this.attributes[i] = new Datum(attributes[i], Types.OTHER, true);
            }
        }
    }

    private Datum getDatum() throws SQLException {
        if (attributes == null) {
            throw new SQLException("Trying to read from an null attribute array.");
        }
        if (index >= attributes.length) {
            throw new SQLException("Trying to read past the end of attribute array. Length: " + attributes.length + ", index: " + index);
        }
        Datum ret = attributes[index++];
        wasNull = (ret == null);
        return ret;
    }

    public boolean readBoolean() throws SQLException {
        return getDatum().getBoolean();
    }

    public byte readByte() throws SQLException {
        return getDatum().getByte();
    }

    public short readShort() throws SQLException {
        return getDatum().getShort();
    }

    public int readInt() throws SQLException {
        return getDatum().getInt();
    }

    public long readLong() throws SQLException {
        return getDatum().getLong();
    }

    public float readFloat() throws SQLException {
        return getDatum().getFloat();
    }

    public double readDouble() throws SQLException {
        return getDatum().getDouble();
    }

    public BigDecimal readBigDecimal() throws SQLException {
        return getDatum().getBigDecimal();
    }

    public String readString() throws SQLException {
        return getDatum().getString();
    }

    public byte[] readBytes() throws SQLException {
        return getDatum().getBytes();
    }

    public Date readDate() throws SQLException {
        return getDatum().getDate();
    }

    public Time readTime() throws SQLException {
        return getDatum().getTime();
    }

    public Timestamp readTimestamp() throws SQLException {
        return getDatum().getTimestamp();
    }

    public URL readURL() throws SQLException {
        return getDatum().getURL();
    }

    public Blob readBlob() throws SQLException {
        return getDatum().getBlob();
    }

    public Clob readClob() throws SQLException {
        return getDatum().getClob();
    }

    // NOTE: we do not perform any type-conversions - the caller needs to do that.
    public Array readArray() throws SQLException {
        return getDatum().getArray();
    }

    // NOTE: we do not perform any type-conversions - the caller needs to do that.
    public Object readObject() throws SQLException {
        return getDatum().getObject();
    }

    public boolean wasNull() throws SQLException {
        return wasNull;
    }


    public Reader readCharacterStream() throws SQLException {
        throw new SQLException("Method not implemented");
    }

    public InputStream readAsciiStream() throws SQLException {
        throw new SQLException("Method not implemented");
    }

    public InputStream readBinaryStream() throws SQLException {
        throw new SQLException("Method not implemented");
    }

    public Ref readRef() throws SQLException {
        throw new SQLException("Method not implemented");
    }

    public NClob readNClob() throws SQLException {
        throw new SQLException("Method not implemented");
    }

    public String readNString() throws SQLException {
        throw new SQLException("Method not implemented");
    }

    public SQLXML readSQLXML() throws SQLException {
        throw new SQLException("Method not implemented");
    }

    public RowId readRowId() throws SQLException {
        throw new SQLException("Method not implemented");
    }
}
