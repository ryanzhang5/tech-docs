/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.client;

import com.wm.dal.util.ClientConf;

import com.wm.dal.util.DALLogger;

import com.wm.dal.util.ServerConf;

import java.net.InetAddress;
import java.net.InetSocketAddress;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import java.util.concurrent.LinkedBlockingQueue;

import org.jboss.netty.bootstrap.ClientBootstrap;
import org.jboss.netty.channel.ChannelFactory;
import org.jboss.netty.channel.ChannelFuture;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.channel.ChannelPipeline;
import org.jboss.netty.channel.ChannelPipelineCoverage;
import org.jboss.netty.channel.Channels;
import org.jboss.netty.channel.ExceptionEvent;
import org.jboss.netty.channel.MessageEvent;
import org.jboss.netty.channel.SimpleChannelHandler;
import org.jboss.netty.channel.socket.nio.NioClientSocketChannelFactory;
import org.jboss.netty.handler.codec.serialization.ObjectDecoder;
import org.jboss.netty.handler.codec.serialization.ObjectEncoder;

/**
 * 
 * @author cshah
 * @version 1.0
 */
@ChannelPipelineCoverage("one")
public class DALNettyClient extends SimpleChannelHandler implements IDALClient {

    private ChannelFuture future;
    private ChannelFactory factory;
    private final BlockingQueue<IDALResponse> responseQueue = new LinkedBlockingQueue<IDALResponse>();
    private static final DALLogger logger = DALLogger.getInstance();
    private static final IDALResponse nullResp = new DALResponse();
    private ExecutorService bossTPE, workerTPE;
    
    /**
     * 
     * @param addr
     * @param port
     * @throws Exception
     */
    public DALNettyClient(InetAddress addr, int port) throws Exception {
    
        nullResp.setException(new Exception("Could not get response back from server, this is symptom not a bug, probably the request took long time or the connection to the server broke!!!"));
        
        factory =
                new NioClientSocketChannelFactory(
                        bossTPE =  Executors.newFixedThreadPool(ClientConf.getNettyClientBossThreadPoolSize()),
                        workerTPE = Executors.newFixedThreadPool(ClientConf.getNettyClientWorkerThreadPoolSize()));
        ClientBootstrap bootstrap = new ClientBootstrap(factory);

        ChannelPipeline pipeline = bootstrap.getPipeline();
        pipeline.addLast("decoder", new ObjectDecoder(ServerConf.getMaxObjectSize()));
        pipeline.addLast("encoder", new ObjectEncoder());
        pipeline.addLast("handler", this);

        bootstrap.setOption("connectTimeoutMillis", ClientConf.getConnectionTimeout());
        bootstrap.setOption("keepAlive", ClientConf.getKeepAlive());
        bootstrap.setOption("reuseAddress", ClientConf.getReuseAddress());
        bootstrap.setOption("soLinger", ClientConf.getSOLinger());
        bootstrap.setOption("tcpNoDelay", ClientConf.getTCPNoDely());

        future = bootstrap.connect(new InetSocketAddress(addr, port));
        future.awaitUninterruptibly();

        if (!future.isSuccess()) {
            try {
                future.cancel();
            } catch (Exception exp) {
                exp.printStackTrace();
            }
            
            if (!ServerConf.inServerVM()) {
                throw new Exception("DAL Server not available " + addr + ":" + port);
            }
        }
        
    }

    /**
     * 
     * @param request
     * @return
     * @throws Exception
     */
    public IDALResponse execute(IDALRequest request) throws Exception {
        return send(request);
    }

    /**
     * 
     * @throws Exception
     */
    public void close() throws Exception {
        responseQueue.offer(nullResp);
        try {
            future.getChannel().close();
        } catch (Exception exp) { 
        	System.currentTimeMillis();//exp.printStackTrace();
        }
        try {        
            if (bossTPE != null) {
                bossTPE.shutdownNow();
            }
        } catch (Exception exp) {exp.printStackTrace();}
        try {        
            if (workerTPE != null) {
                workerTPE.shutdownNow();
            }
        } catch (Exception exp) {exp.printStackTrace();}
        try {        
            future.cancel();
        } catch (Exception exp) {exp.printStackTrace();}
        //try {
            //TODO
            //factory.releaseExternalResources();
        //} catch (Exception exp) {exp.printStackTrace();}
    }  
    
    /**
     * 
     * @param request
     * @return
     * @throws Exception
     */
    public IDALResponse send(IDALRequest request) throws Exception {
        if (logger.isLoggable(DALLogger.LEVEL_INFO))
          logger.info("in send " + request);
        future.getChannel().write(request);

        IDALResponse resp = null;
        try {
            logger.info("in take " );
            resp = responseQueue.take();
        } catch (InterruptedException ie) {
            throw new Exception("Interrupted by another thread, this is symptom not a bug, probably the request took long time or the connection to the server broke!!!",ie);
        }
        
        if (resp == null) {
            throw new Exception("Did not receive any response back from the server");
        }

        return resp;
    }

    /**
     * 
     * @param ctx
     * @param e
     */
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, ExceptionEvent e) {
        Channels.close(e.getChannel());
        try {
            DALResponse resp = new DALResponse();
            String str = (e.getCause() != null) ?e.getCause().toString() :"unknown root cause";
            resp.setException(new Exception("Encountered network exception: " + str));
            responseQueue.offer(resp);
            close();
        } catch (Exception exp) {exp.printStackTrace();}
    }

    /**
     * 
     * @param channelHandlerContext
     * @param me
     * @throws Exception
     */
    public void messageReceived(ChannelHandlerContext channelHandlerContext, MessageEvent me) throws Exception {
        Object message = me.getMessage();
        if (message instanceof IDALResponse) {
            responseQueue.offer((IDALResponse)message);
        } else {
            DALResponse resp = new DALResponse();
            resp.setException(new Exception("Received unknown message type: " + message));
            responseQueue.offer(resp);
        }
    }

}
