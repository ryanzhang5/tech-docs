package com.wm.dal.util;
import java.lang.reflect.Method;
import java.util.HashMap;


/**
 * A policy which modifies the behavior of @see LoggingDecorator.
 *
 *
 *
 */
public class LoggingDecoratorPolicy {

    public static final LoggingDecoratorPolicy DEFAULT = new LoggingDecoratorPolicy(true);

    /**
     * An input to addPolicy(Method,int) or addPolicy(Class,int) which indicates
     * the the given method (or all methods of the given class) should not be
     * logged.   (By default all methods are logged.)
     *
     * Method-level policies override class-level policies.
     */
    public static final int NO_LOG = 1;

    /**
     * An input to addPolicy(Method,int) or addPolicy(Class,int) which indicates
     * the the given method (or all methods of the given class) should not be immediately
     * logged; rather, the log info for this method invocation should be cached
     * until a method without this flag is called, at which point all cached
     * log info will be put into a single log entry.  By default a flush happens
     * on each method call.
     *
     * Method-level policies override class-level policies.
     */
    public static final int NO_FLUSH = 2;

    /**
     * An input to addPolicy(Method,int) or addPolicy(Class,int) which indicates
     * the the given method (or all methods of the given class) should wrap
     * its return value into in another LoggingDecorator.  By default,
     * this does not happen.
     *
     * IMPORTANT:
     * LoggingDecorator works with interfaces, not classes.  If the method's
     * return value needs to be of a class type (rather than an interface type)
     * then this flag can result in a ClassCastException.
     *
     * Method-level policies override class-level policies.
     */
    public static final int WRAP_RESULT = 4;

    /**
     * An input to addPolicy(Method,int) or addPolicy(Class,int) which indicates
     * the the given method should log its return values.  By default
     * this is not true.
     *
     * Method-level policies override class-level policies.
     */
    public static final int LOG_RESULT = 8;
    private HashMap classes = new HashMap();
    private HashMap methods = new HashMap();
    private boolean unmodifiable = false;

    /**
     * Returns a policy with the default values.
     */
    public LoggingDecoratorPolicy() {
    }

    private LoggingDecoratorPolicy(boolean unmodifiable) {
        this.unmodifiable = unmodifiable;
    }

    /**
     * Specify policy flags for the given method.  The flags can be
     * any combination of NO_FLUSH, NO_LOG, WRAP_RESULT, and LOG_RESULT
     * added together.
     *
     * @param m     The method to which the flags should be applied
     * @param flags Any combination of NO_FLUSH, NO_LOG, WRAP_RESULT, and LOG_RESULT
     */
    public void addPolicy(Method m, int flags) {
        if (unmodifiable) {
            throw new IllegalStateException("this policy may not be modified");
        }

        methods.put(m, new Policy(flags));
    }

    /**
     * Specify policy flags for the given class.  The flags can be
     * any combination of NO_FLUSH, NO_LOG, WRAP_RESULT, and LOG_RESULT
     * added together.
     *
     * Note that per-method policies set with addPolicy(Method,int) override
     * per-class policies.
     *
     * @param c The Class to which the flags should be applied
     * @param i Any combination of NO_FLUSH, NO_LOG, WRAP_RESULT, and LOG_RESULT
     */
    public void addPolicy(Class c, int i) {
        if (unmodifiable) {
            throw new IllegalStateException("this policy may not be modified");
        }

        classes.put(c, new Policy(i));
    }

    protected boolean isFlush(Method m) {
        return (getPolicy(m).i & NO_FLUSH) == 0;
    }

    protected boolean isLog(Method m) {
        return (getPolicy(m).i & NO_LOG) == 0;
    }

    protected boolean isWrapResult(Method m) {
        return (getPolicy(m).i & WRAP_RESULT) != 0;
    }

    protected boolean isLogResult(Method m) {
        return (getPolicy(m).i & LOG_RESULT) != 0;
    }

    private Policy getPolicy(Method m) {
        Policy p = (Policy) methods.get(m);

        if (p == null) {
            p = (Policy) classes.get(m.getDeclaringClass());
        }

        if (p == null) {
            p = Policy.DEFAULT;
        }

        return p;
    }

    private static class Policy {
        public static final Policy DEFAULT = new Policy((0 * NO_LOG) +
                                                        (0 * NO_FLUSH) +
                                                        (0 * WRAP_RESULT) +
                                                        (0 * LOG_RESULT));
        public int i;

        public Policy(int i) {
            this.i = i;
        }
    }
}
