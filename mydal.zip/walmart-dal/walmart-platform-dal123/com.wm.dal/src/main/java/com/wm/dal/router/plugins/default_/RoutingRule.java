/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_;

/**
 * RoutingRule
 *
 * @author mkishore
 * @since 1.0
 */
public class RoutingRule extends AbstractConditionalStatement<RouterContext> {
    private String name;

    // GETTERS and SETTERS

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
