/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_;

import java.util.List;
import java.util.ArrayList;
import java.util.logging.Logger;
import java.util.logging.Level;

/**
 * AbstractConditionalStatement - base class for if-then-else statements
 *
 * @author mkishore
 * @since 1.0
 */
public class AbstractConditionalStatement<T> implements IStatement<T> {
    private static final Logger logger = Logger.getLogger(AbstractConditionalStatement.class.getName());

    private ICondition<T> condition;
    private List<IStatement<T>> thenStatements = new ArrayList<IStatement<T>>();
    private List<IStatement<T>> elseStatements = new ArrayList<IStatement<T>>();

    /**
     * No-op
     */
    public void initialize() throws IllegalStateException {
        // no-op
    }

    /**
     * Simple command interface - the implementing classes will add
     * appropriate logic in this method.
     *
     * @param context - the execution context
     */
    public Status execute(T context) {
        boolean bool = condition.evaluate(context);
        if (logger.isLoggable(Level.FINE)) {
            logger.fine(this.getClass().getSimpleName() + " - Executing " + ((bool) ?"then" :"else") + " statements");
        }
        List<IStatement<T>> stmts = bool ? thenStatements : elseStatements;
        for (IStatement<T> stmt : stmts) {
            Status status = stmt.execute(context);
            if (!status.equals(Status.CONTINUE)) {
                if (logger.isLoggable(Level.FINE)) {
                    logger.fine(this.getClass().getSimpleName() + " - Executed. status [" + status + "]");
                }
                return status;
            }
        }
        if (logger.isLoggable(Level.FINE)) {
            logger.fine(this.getClass().getSimpleName() + " - Executed. status [" + Status.CONTINUE + "]");
        }
        return Status.CONTINUE;
    }

    // GETTERS and SETTERS

    public ICondition<T> getCondition() {
        return condition;
    }

    public void setCondition(ICondition<T> condition) {
        this.condition = condition;
    }

    public List<IStatement<T>> getThenStatements() {
        return thenStatements;
    }

    public void setThenStatements(List<IStatement<T>> thenStatements) {
        this.thenStatements = thenStatements;
    }

    public List<IStatement<T>> getElseStatements() {
        return elseStatements;
    }

    public void setElseStatements(List<IStatement<T>> elseStatements) {
        this.elseStatements = elseStatements;
    }
}
