/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther Chirag Shah
 * @since 9.6
 */

package com.wm.dal.server;

import com.wm.corelib.jmxadmin.JmxUtil;
import com.wm.dal.server.http.HttpServer;
import com.wm.dal.server.netty.DALNettyServer;
import com.wm.dal.server.netty.DALOIONettyServer;
import com.wm.dal.server.nio.DALNIOServer;
import com.wm.dal.util.DALException;
import com.wm.dal.util.ServerConf;

import java.text.SimpleDateFormat;

import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.wm.dal.server.health.ConnectionDistributor;
  
import com.wm.corelib.config.AppConfig;

/**
 * @author cshah
 */
public class DALServer extends Thread {
    // Create an instance of a logger object for dal logging.
    protected static final Logger logger = Logger.getLogger(DALServer.class.getName());

    // Default configuration file
    private static final String DEFAULT_CONFIG_FILE = "/dal.conf";
    private static final String JVM_CONFIG_FILE_PARAM = "com.wm.conf";
    private static AbstractDALServer server = null;
    private int port  = 1729;

    /**
     * 
     */
    public DALServer() {
        port = ServerConf.getPort();
        try {
            //calling JmxUtil to initialize Management Bean
            JmxUtil.getInstance();        
        } catch (Exception exp) { 
              logger.log(Level.SEVERE,  getClass().getName() + "/WMQLRequestBroker(): caught Exception while calling JmxUtil.getInstance() " + exp.getMessage() );
              exp.printStackTrace();
          }     

    }

    /**
     * 
     */
    public void run() {
        try {
            String serverType = ServerConf.getServerType();
            if (serverType.equals("nio")) {
                server = new DALNIOServer(port);
            } else if (serverType.equals("oionetty")) {
                server = new DALOIONettyServer(port);
            } else {
                server = new DALNettyServer(port);
            }
            Thread thread = new Thread(server,"dal-server-thread");
            thread.start();
            
            ServerConf.setInServerVM(true);
            
        } catch (Exception exp) {
            exp.printStackTrace();
            System.exit(1);
        }

        try {
        	String base = ServerConf.getResourceBase();
        	base = base == null ? null : base.startsWith("/") ? base : DALServer.class.getResource("/"+base).toExternalForm(); 
        			
        	
            HttpServer server = new HttpServer(ServerConf.getHttpPort(), base);
            server.startServer();
        } catch (Exception exp) {
            exp.printStackTrace();
        }
        
        try {
            //start JMS connection with 60 sec timeout
            com.wm.weblib.jms.WMJMSListenerManager.getInstance().start(2 * Integer.parseInt(AppConfig.getInstance().getProperty("PROP_JMS_TIMEOUT")) );
        } catch (Exception e) {
            e.printStackTrace();
        }

        
        Timer timer = new Timer("timestamp-timer", true);
        timer.schedule(new TimerTask() {
            SimpleDateFormat s = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy");
            public void run() {
                try {
                    logger.warning("TIMESTAMP: " + s.format(System.currentTimeMillis()));
                } catch (Exception exp) {
                    exp.printStackTrace();
                }
            }
        }, 0, 5000);

        String sRefreshInterval = AppConfig.getInstance().getProperty("com.wm.dal.conn.lb.refresh.interval", "300");
        Integer refreshInterval = 300;
        try {
        	refreshInterval = Integer.parseInt(sRefreshInterval);
        } catch (Exception exp) {
            logger.severe(exp.getMessage());
        }
        
        	if (refreshInterval <= 0) {
        		refreshInterval = 300;
        	}

        logger.warning("Setting Interval " + refreshInterval + " seconds");
        Timer lbtimer = new Timer("connection-lb-timer", true);
        lbtimer.schedule(new ConnectionDistributor(), refreshInterval * 1000, refreshInterval * 1000);        

    }

    /**
     * 
     * @param args
     */
    public static void main(String[] args) {

        if (args.length > 1) {
        	logger.log(Level.ALL,"main(): Usage com.wm.dal.server.DALServer <conf_file>");
			System.exit(-1);
		}

            if (args.length == 1) {
                try {
                    ServerConf.loadConfig(args[0]);
                } catch (DALException e) {
                    logger.log(Level.ALL, DALServer.class.getName()+": Failed to load "+args[0]+" exiting..", e);
                    System.exit(-1);
                }
                logger.log(Level.ALL, DALServer.class.getName()+ "/main(): Loaded config: " + args[0]);
        } else if( AppConfig.getInstance().getProperty(JVM_CONFIG_FILE_PARAM)!=null ) {

                String jvmConfigFile =  AppConfig.getInstance().getProperty(JVM_CONFIG_FILE_PARAM);

                logger.log(Level.ALL, DALServer.class.getName()
                                + "main(): Using the jvm configuration file: "
                                + jvmConfigFile);
            try {
                ServerConf.loadConfig(jvmConfigFile);
            } catch(DALException e) {
                logger.log(Level.ALL, DALServer.class.getName()+": Failed to load "+jvmConfigFile, e);
                System.exit(-1);
            }
        } else {
                logger.log(Level.ALL, DALServer.class.getName()
                                + "main(): Using the default configuration file: "
                                + DEFAULT_CONFIG_FILE);
            try {
                ServerConf.loadConfig(DEFAULT_CONFIG_FILE);
            } catch(DALException e) {
                logger.log(Level.ALL, DALServer.class.getName()+": Failed to load "+DEFAULT_CONFIG_FILE+" Exiting", e);
                System.exit(-1);
            }
        }

        ServerConf.setLogParameters(ServerConf.getLogLevel(),"DAL Log:");
        
        DALServer dALServer = new DALServer();
        if (!"false".equals(AppConfig.getInstance().getProperty("dal.server.daemon")))
        	dALServer.setDaemon(true);
        dALServer.start();
    }
}

