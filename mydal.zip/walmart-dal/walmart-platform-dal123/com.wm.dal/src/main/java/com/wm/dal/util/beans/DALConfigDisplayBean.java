package com.wm.dal.util.beans;

import java.util.List;


public class DALConfigDisplayBean {

	private String[] alias;
	private List<DALConfigBean> configBeans;
	
	public String[] getAlias() {
		return alias;
	}
	public void setAlias(String[] alias) {
		this.alias = alias;
	}
	public List<DALConfigBean> getConfigBeans() {
		return configBeans;
	}
	public void setConfigBeans(List<DALConfigBean> configBeans) {
		this.configBeans = configBeans;
	}
}
