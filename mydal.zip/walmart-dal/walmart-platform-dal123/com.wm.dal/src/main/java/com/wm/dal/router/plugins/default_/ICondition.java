/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_;

/**
 * ICondition - base interface for classes that evaluate a condition.
 *
 * @author mkishore
 * @version $Revision: 1.1 $
 * @since 1.0
 */
public interface ICondition<T> {
    /**
     * This method should be called after creating the condition and injecting
     * all its dependencies. The implmentations can use this method to validate
     * that the instance has been configured correctly.
     *
     * @throws IllegalStateException - if there are errors in the configuration
     */
    public void initialize() throws IllegalStateException;

    /**
     * Returns true/false - based on the context and the implementation's internal state.
     *
     * @param context the context in which this condition needs to be evaluated
     * @return true/false - based on the context and the implementation's internal state
     */
    public boolean evaluate(T context);
}
