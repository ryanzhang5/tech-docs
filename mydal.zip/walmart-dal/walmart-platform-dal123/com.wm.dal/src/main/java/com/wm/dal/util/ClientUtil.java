/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther Chirag Shah
 * @since 9.6
 */

package com.wm.dal.util;

import com.wm.dal.server.nio.Dispatcher;
import com.wm.dal.server.nio.DispatcherPool;

/**
 * 
 * @author cshah
 */
public class ClientUtil {
    private static final DispatcherPool writeDispatcherPool = new DispatcherPool(ClientConf.getWriteSelector(), "write-dispatcher-client");
    private static final DispatcherPool readDispatcherPool = new DispatcherPool(ClientConf.getReadSelector(), "read-dispatcher-client");

    /**
     * 
     * @return
     */
    public static Dispatcher getReadDispatcher() {
        return readDispatcherPool.nextDispatcher();
    }

    /**
     * 
     * @return
     */
    public static Dispatcher getWriteDispatcher() {
        return writeDispatcherPool.nextDispatcher();
    }
    
}
