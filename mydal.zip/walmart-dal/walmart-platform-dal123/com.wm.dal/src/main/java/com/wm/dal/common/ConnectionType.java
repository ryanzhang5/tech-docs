/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.common;

import com.wm.dal.router.IRouter;
import com.wm.dal.util.DALLogger;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * 
 */
public class ConnectionType {
    private String name;
    private String defaultPoolName;
    private boolean enabled;
    private List<? extends IRouter> routerList;
    private String userName;
    private String password;
    static final DALLogger logger = DALLogger.getInstance();
    private static final int MIN_REFRESH_INTERVAL = 60000;

    /**
     * Constructor
     */
    public ConnectionType() {
    }

    /**
     * Set Name
     * @param name -- return name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Get Name
     * @return -- Name 
     */
    public String getName() {
        return name;
    }

    /**
     * set Default connection pool alias
     * @param defaultConnection -- String JDBC Alias
     */
    public void setDefaultPoolName(String defaultConnection) {
        this.defaultPoolName = defaultConnection;
    }

    /**
     * Get Default connection pool alias
     * @return -- String JDBC Alias
     */
    public String getDefaultPoolName() {
        return defaultPoolName;
    }

    /**
     * Is Connection Type enabled
     * @param enabled -- boolean
     */
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    /**
     * Return true if connection type is enabled
     * @return -- boolean
     */
    public boolean isEnabled() {
        return enabled;
    }

    /**
     * Set Router List
     * @param routerList -- List of Routers
     */
    public void setRouterList(List<? extends IRouter> routerList) {
        this.routerList = routerList;
        
        if (routerList != null && routerList.size() > 0) {
            for (final IRouter router : routerList) {
                long refreshInterval = router.getRefreshInterval();
                if (refreshInterval < MIN_REFRESH_INTERVAL) {
                    logger.info("The refresh interval ["+refreshInterval+"] for the router ["+router.getName()+"] is too small! Increasing it to 60 seconds.");
                    refreshInterval = MIN_REFRESH_INTERVAL;
                }

                Timer timer = new Timer(getName() + "-" + router.getName() + "-timer", true);
                timer.schedule(new TimerTask() {
                    public void run() {
                        if (router.isEnabled()) {
                            router.refresh();
                        }
                    }
                }, refreshInterval, refreshInterval);
            }
        }
    }

    /**
     * Get router list
     * @return -- List
     */
    public List<? extends IRouter> getRouterList() {
        return routerList;
    }

    /**
     * Set User name
     * @param userName -- String
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * Get User name
     * @return -- String
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Set Password
     * @param password -- String
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Get Password
     * @return -- Password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @return String
     */
    public String toString() {
        return "Name : " + name +  ", Default Connection: " + defaultPoolName  +", User : " + userName + ",Password : " + password;
    }  
}
