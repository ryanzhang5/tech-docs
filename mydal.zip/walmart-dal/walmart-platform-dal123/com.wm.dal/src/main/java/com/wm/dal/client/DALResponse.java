/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.client;

import java.io.Serializable;

/**
 * @author cshah
 * @version 1.0
 */
public class DALResponse implements IDALResponse,Serializable {
    private Object result = null;
    private ICallerResponse connectionResponse;
    private ICallerResponse statementResponse;
    private ICallerResponse resultSetResponse;
    private String serverEndPoint = null;
    private String poolName = null;

    /**
     * @return
     */
    public Exception getException(){
        return (Exception) (Exception.class.isInstance(result) ? result : null);
    }

    /**
     * @param exp
     */
    public void setException(Exception exception){
        this.result = exception;
    }

    /**
     * @return
     */
    public Object getResult(){
        return Exception.class.isInstance(result) ? null : result;
    }

    /**
     * @param exp
     */
    public void setResult(Object result){
        this.result = result;
    }
    
    /**
     * @return
     */
    public ICallerResponse getConnectionResponse() {
      if (connectionResponse == null)
        connectionResponse = new CallerResponse();
      return connectionResponse;
    }

    /**
     * @return
     */
    public ICallerResponse getStatementResponse() {
      if (statementResponse == null)
        statementResponse = new CallerResponse();
      return statementResponse;
    }

    /**
     * @return
     */
    public ICallerResponse getResultSetResponse() {
      if (resultSetResponse == null)
        resultSetResponse = new CallerResponse();
        return resultSetResponse;
    }

    /**
     * 
     * @param serverHost
     */
    public void setServerEndPoint(String serverEndPoint) {
        this.serverEndPoint = serverEndPoint;
    }

    /**
     * 
     * @return
     */
    public String getServerEndPoint() {
        return serverEndPoint;
    }

    /**
     * Set the name of the pool that ultimately served the request.
     *
     * @param poolName - name of a database connection pool
     */
    public void setPoolName(String poolName) {
        this.poolName = poolName;
    }

    /**
     * Return the name of the pool that ultimately served the request.
     *
     * @return the name of the pool that ultimately served the request
     */
    public String getPoolName() {
        return poolName;
    }
}
