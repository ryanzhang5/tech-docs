/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc.args;

import java.sql.SQLException;
import java.sql.Types;

/**
 * 
 * @author cshah
 * @version 1.0
 */
public class BooleanArg extends DALArgs {
    private boolean value;

    /**
     * @param position
     * @param isOut
     * @param isNull
     */
    public BooleanArg(int position, boolean isOut, boolean isNull) {
        super.init(position, isOut, isNull, Types.BIT);
    }

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    public BooleanArg(int position, boolean isOut, boolean isNull, boolean value) {
        init(position, isOut, isNull, value);
    }

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    protected void init(int position, boolean isOut, boolean isNull, boolean value) {
        super.init(position, isOut, isNull, Types.BIT);
        this.value = value;
    }

    /**
     * @return
     */
    public boolean getValue() {
        return value;
    }

    /**
     * @param value
     * @throws SQLException
     */
    public void setValueObject(Object value) throws SQLException {
        if (value != null && value instanceof Boolean)
            this.value = ((Boolean)value).booleanValue();
    }

    /**
     * @return
     */
    public Object getValueObject() {
        return Boolean.valueOf(getValue());
    }

    /**
     * @return
     */
    public String toString() {
        return super.toString() + ", value = |" + value + "|";
    }

}
