/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 */
package com.wm.dal.server.netty;

import com.wm.dal.client.DALResponse;
import com.wm.dal.client.IDALRequest;
import com.wm.dal.client.IDALResponse;
import com.wm.dal.common.ConnectionDelegate;
import com.wm.dal.server.ThreadPoolManager;
import com.wm.dal.util.DALLogger;
import com.wm.dal.util.ServerUtil;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.channel.ChannelPipelineCoverage;
import org.jboss.netty.channel.ChannelStateEvent;
import org.jboss.netty.channel.Channels;
import org.jboss.netty.channel.ExceptionEvent;
import org.jboss.netty.channel.MessageEvent;
import org.jboss.netty.channel.SimpleChannelHandler;
  
import com.wm.corelib.config.AppConfig;
//import org.jboss.netty.channel.group.ChannelGroup;


/**
 * 
 * @author cshah
 */
@ChannelPipelineCoverage("one")
public class DALNettyRequestHandler extends SimpleChannelHandler implements Callable {

    private ConnectionDelegate delegate = new ConnectionDelegate();
    private static final DALLogger logger = DALLogger.getInstance();

    private IDALRequest dalRequest;
    //private IDALResponse dalResponse;
    private final BlockingQueue<IDALResponse> responseQueue = new LinkedBlockingQueue<IDALResponse>();
    private long startTime = System.currentTimeMillis();
    private int WAIT_TIME = 60;
    //private final ExecutorService executorService = Executors.newSingleThreadExecutor();
    private boolean checkResponseQueueCond = true;
    private static final String CONF_CHECK_RESP_QUEUE = "com.wm.dal.check.resp.queue";
    /**
     * 
     */
    public DALNettyRequestHandler() {
      if (logger.isLoggable(DALLogger.LEVEL_INFO))
        logger.info( this.getClass().getName() +  " new instance");
        try {
            checkResponseQueueCond = "true".equals(AppConfig.getInstance().getProperty(CONF_CHECK_RESP_QUEUE, "true"));
        } catch (Exception ignore) {;
            }
    }

    /**
     * Constructor
     * @param channelGroup
     */
/*     
    public DALNettyRequestHandler(ChannelGroup channelGroup) {
        this.channelGroup = channelGroup;
    }
*/
/*
    @Override
    public void channelConnected(ChannelHandlerContext ctx, ChannelStateEvent e)
            throws Exception {
        channelGroup.add(ctx.getChannel());
    }
*/
    /**
     * 
     * @param ctx
     * @param e
     */
    @Override
    public void channelInterestChanged(ChannelHandlerContext ctx,
            ChannelStateEvent e) {
      if (logger.isLoggable(DALLogger.LEVEL_INFO))
        logger.info("channel interest " + e);   
        generateDALResponse(e);
    }
    
    @Override
    public void channelDisconnected(ChannelHandlerContext ctx, ChannelStateEvent se) { 
      if (logger.isLoggable(DALLogger.LEVEL_INFO))  
        logger.info("channel disconnected " + ctx );   
    }

    @Override
    public void channelUnbound(ChannelHandlerContext ctx, ChannelStateEvent se) { 
      if (logger.isLoggable(DALLogger.LEVEL_INFO))  
        logger.info("channel unbound " + ctx + ":" );   
    }
    
    @Override
    public void channelClosed(ChannelHandlerContext ctx, ChannelStateEvent se) { 
        IDALResponse resp = new DALResponse();
        resp.setException(new Exception("Client disconnected"));
        responseQueue.offer(resp);
        delegate.forceClose();
        if (logger.isLoggable(DALLogger.LEVEL_INFO))
          logger.info("channel closed " + ctx );   
    }

    /**
     * 
     * @param ctx
     * @param e
     */
    @Override
    public void messageReceived(ChannelHandlerContext ctx, MessageEvent e) {
        if (logger.isLoggable(DALLogger.LEVEL_INFO))
          logger.info("message received " + e);   
        startTime = System.currentTimeMillis();
        IDALRequest req = (IDALRequest) e.getMessage();
        //if (req != null) {
            dalRequest = req;
            generateDALResponse(e);
        //}
    }

    /**
     * 
     * @param ctx
     * @param e
     */
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, ExceptionEvent e) {
        logger.log(DALLogger.LEVEL_WARNING, "Remote channel closed by client");
        //logger.log(DALLogger.LEVEL_WARNING, "Unexpected error occured.", e.getCause());
        //e.getCause().printStackTrace();
        delegate.forceClose();
        Channels.close(e.getChannel());
    }

    /**
     * Used when write is possible
     * @param e
     */
    private void generateDALResponse(ChannelStateEvent e) {
        if (logger.isLoggable(DALLogger.LEVEL_INFO))
          logger.info("generate DAL response " + e);   
        Channel channel = e.getChannel();
        sendDALResponse(channel);
    }

    /**
     *
     * @param e
     */
    private void generateDALResponse(MessageEvent e) {
        try {
            if (logger.isLoggable(DALLogger.LEVEL_INFO))
              logger.info("generate DAL response message event " + e);   
            Channel channel = e.getChannel();
/*
            FutureTask ft = new FutureTask(this);
            ThreadPoolManager.getInstance().getWMThreadPoolExecutor().execute(ft);
            //executorService.execute(ft);
            try {
                //just maximum waiting for 60 minutes, incase anything goes wrong
                ft.get(WAIT_TIME,TimeUnit.MINUTES);
            } catch (Exception ex) {
                IDALResponse resp = new DALResponse();
                resp.setException(ex);
                responseQueue.offer(resp);
            } finally {
                if (!ft.isDone()) {
                    IDALResponse resp = new DALResponse();
                    resp.setException(new Exception("Response not generated..."));
                    responseQueue.offer(resp);
                }
                ft.cancel(true);
            }
*/            
            
            try {
            IDALResponse  dalResponse = delegate.execute(dalRequest);
            responseQueue.offer(dalResponse);
            } catch (Exception exp) {
                exp.printStackTrace();
                IDALResponse resp = new DALResponse();
                resp.setException(exp);
                responseQueue.offer(resp);
            }
            
            sendDALResponse(channel);
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }

    /**
     * 
     * @param channel
     */
    private void sendDALResponse(Channel channel) {
      if (logger.isLoggable(DALLogger.LEVEL_INFO))
        logger.info("send dal response " + channel + ", is connected : " + channel.isConnected() 
                    + " Interest Ops : " + (channel.getInterestOps() & Channel.OP_WRITE)
                    + " Response Queue isEmpty : " + responseQueue.isEmpty());   
        
        if ((channel.getInterestOps() & Channel.OP_WRITE) == 0) {
        /*
            if (dalResponse == null) {
                dalResponse = new DALResponse();
                dalResponse.setException(new Exception("data not received"));
            }
            */
            //Channels.write(channel, dalResponse);
            try {
                if ( channel.isConnected() ) {
                    if (checkResponseQueueCond) {
                        if ( responseQueue.peek() != null ) {
                            Channels.write(channel, responseQueue.take());
                        }
                    } else {
                        Channels.write(channel, responseQueue.take());
                        }
                }            
            } catch (Exception exp) {
                exp.printStackTrace();
            } finally {
                //channel.setInterestOps(Channel.OP_READ_WRITE);
                ServerUtil.printDALBench(dalRequest, startTime);
            }
        }
    }

    /**
     * 
     */
    public Object call() {
        IDALResponse dalResponse = null;
        try {
            dalResponse = delegate.execute(dalRequest);
            responseQueue.offer(dalResponse);
            //sendDALResponse(channel);
        } catch (Exception exp) {
            exp.printStackTrace();
            IDALResponse resp = new DALResponse();
            resp.setException(exp);
            responseQueue.offer(resp);
        }
        return dalResponse;
    }    

}
