package com.wm.dal.jdbc.sqldata;


import java.io.Serializable;

import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;
import java.util.Date;

/**
 * Data record of an array for an item to be added/updated in the cart
 *
 * This class implements SQlData which is required to pass arrays
 * to SQL procs.
 *
 * User: skumar
 * Date: May 9, 2007
 * Time: 3:34:18 PM
 */
public class DALShoppingCartItemUpdateData implements SQLData, Serializable {

    private long itemId;
    private int quantity;
    private String externalXmlBlob;
    private Date expirationDate;
    private String internalXmlBlob;
    private int itemType;
    private int domainCode;
    private long sellerId;
    private String sqlType;

    public DALShoppingCartItemUpdateData(long itemId, int quantity, String externalXmlBlob, 
        Date expirationDate, String internalXmlBlob, 
        int itemType, int domainCode,long sellerId, String sqlType){
        
        this.itemId = itemId;
        this.quantity = quantity;
        this.externalXmlBlob = externalXmlBlob;// XMLUtil.toXMLString(item.getExternalProperties());
        this.expirationDate = expirationDate;//item.getExpirationDate() != null ? item.getExpirationDate().getTime() : null;
        this.internalXmlBlob = internalXmlBlob;//XMLUtil.toXMLString(item.getInternalProperties());
        this.itemType = itemType;//item.getItemType();
        this.domainCode = domainCode;//item.getCatalogDomain().getCode();
        this.sellerId = sellerId;
        this.sqlType = sqlType;
    }

    /**
     *
     * @return Oracle record type of the element in the array
     * @throws SQLException
     */
    public String getSQLTypeName() throws SQLException {
        return this.sqlType;
    }

    /**
     *  Not implementeed because this calss is only used to write into BD not the other way
     * @param stream
     * @param typeName
     * @throws SQLException
     */
    public void readSQL(SQLInput stream, String typeName) throws SQLException {
        throw new RuntimeException("This structure is only used to pass data from to the store procedure not the other way");
    }

    /**
     * This method is called by the oracle driver to write record into DB
     *
     * @param stream
     * @throws SQLException
     */
    public void writeSQL(SQLOutput stream) throws SQLException {
        stream.writeLong(this.itemId);
        stream.writeInt(this.quantity);
        stream.writeString(this.externalXmlBlob);
        if (this.expirationDate != null) {
            stream.writeTimestamp(new java.sql.Timestamp(this.expirationDate.getTime()));
        } else {
            stream.writeTimestamp(null);
        }
        stream.writeString(this.internalXmlBlob);
        stream.writeLong(this.itemType);
        stream.writeInt(this.domainCode);
        stream.writeLong(this.sellerId);
    }
}

