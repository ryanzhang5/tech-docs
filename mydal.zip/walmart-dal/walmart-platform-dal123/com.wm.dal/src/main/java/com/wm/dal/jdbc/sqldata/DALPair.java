package com.wm.dal.jdbc.sqldata;

import java.io.Serializable;

import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

public class DALPair implements SQLData, Serializable {

    /** the default sql type */
    public static final String SQL_TYPE = "CUSTOMER.PAIR";   // upper-case the type name or it won't work.
    
    /** name of sql type */
    private String sqlTypeName;
    /** number data member */
    private long number;
    /** string data member */
    private String string;
    
    /**
     * constructor that fills in data members
     */
    public DALPair(long number, String string, String sqlType) {
        this.number = number;
        this.string = string;
        this.sqlTypeName = sqlType;
    }
    
    /**
     * gets the number data member
     */
    public long getNumber() {
        return number;
    }

    /**
     * sets the number data member
     */
    public void setNumber(long number) {
        this.number = number;
    }
    
    /**
     * gets the string data member
     */
    public String getString() {
        return string;
    }
    
    /**
     * sets the string data member
     */
    public void setString(String string) {
        this.string = string;
    }
    
    /**
     * dump contents
     */
    public String toString() {
        return "[" + number + ", " + string + ", " + sqlTypeName + "]";
    }
    
    /**
     * returns type name as set by readSQL (SQLData)
     */
    public String getSQLTypeName() throws SQLException { 
        return sqlTypeName; 
    } 
    
    /**
     * read data from sql stream (SQLData)
     */
    public void readSQL(SQLInput stream, String typeName) throws SQLException {
        sqlTypeName = typeName;
        number = stream.readLong();
        string = stream.readString();
    }

    /**
     * write data to sql stream (SQLData)
     */
    public void writeSQL(SQLOutput stream) throws SQLException { 
        stream.writeLong(number);
        stream.writeString(string);
    }
}
