/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.util;

/**
 *
 * @author cshah
 * @version 1.0
 */
public class ClientConf {
    private static int connectionTimeout = 1000;
    private static int soLinger = -1;
    private static int bossThreadPoolSize = 1;
    private static int workerThreadPoolSize = 1;
    private static boolean keepAlive = true;
    private static boolean reuseAddress = true;
    private static boolean tcpNoDelay = true;
    
    private static int readSelector = 2;
    private static int writeSelector = 2;
    /**
     * 
     * @return
     */
    public static int getConnectionTimeout() {
        return connectionTimeout;
    }

    /**
     * 
     * @return
     */
    public static int getSOLinger() {
        return soLinger;
    }

    /**
     * 
     * @return
     */
    public static boolean getKeepAlive() {
        return keepAlive;
    }    

    /**
     * 
     * @return
     */
    public static boolean getReuseAddress() {
        return reuseAddress;
    }    

    /**
     * 
     * @return
     */
    public static boolean getTCPNoDely() {
        return tcpNoDelay;
    }    


    /**
     * 
     * @return
     */
    public static int getNettyClientBossThreadPoolSize() {
        return bossThreadPoolSize;
    }

    /**
     * 
     * @return
     */
    public static int getNettyClientWorkerThreadPoolSize() {
        return workerThreadPoolSize;
    }

    /**
     * 
     * @return
     */
    public static int getWriteSelector() {
        return writeSelector;
    }

    /**
     * 
     * @return
     */
    public static int getReadSelector() {
        return readSelector;
    }

    /**
     *
     * @param sessionID
     */
    public static void setThreadSessionID(String sessionID) {
      DALThreadLocal.setSessionID(sessionID);
      //threadSession.put(Thread.currentThread().getName(), sessionID);
    }

    /**
     *
     * @return
     */
     public static String getThreadSessionID() {
       return DALThreadLocal.getSessionID();
    }

    /**
     *
     */
    public static void removeThreadSessionID() {
        DALThreadLocal.setSessionID(null);
        //threadSession.remove(Thread.currentThread().getName());
    }

}
