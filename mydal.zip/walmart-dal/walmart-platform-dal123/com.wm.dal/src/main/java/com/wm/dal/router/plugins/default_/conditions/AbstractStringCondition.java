/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.conditions;

import com.wm.dal.router.plugins.default_.ICondition;

import java.util.regex.Pattern;
import java.util.logging.Logger;
import java.util.logging.Level;

/**
 * AbstractStringValueCondition - base class for doing string comparisons.
 *
 * @author mkishore
 * @since 1.0
 */
public abstract class AbstractStringCondition<T> implements ICondition<T> {
    private static final Logger logger = Logger.getLogger(AbstractStringCondition.class.getName());

    private String regex;
    private boolean caseInsensitive;
    private Pattern pattern;

    /**
     * This method should be called after creating the condition and injecting
     * all its dependencies. The implmentations can use this method to validate
     * that the instance has been configured correctly.
     *
     * @throws IllegalStateException - if there are errors in the configuration
     */
    public void initialize() throws IllegalStateException {
        if (regex == null) {
            throw new IllegalStateException("The regex is null");
        }

        try {
            int flags = (caseInsensitive) ? Pattern.CASE_INSENSITIVE : 0;
            pattern = Pattern.compile(regex, flags);
        } catch (Exception e) {
            throw new IllegalStateException("Error compiling the regex pattern", e);
        }
    }

    /**
     * Returns true if the string value matches the regex pattern.
     *
     * @param context - the context object
     * @return true if the string value matches the regex pattern.
     */
    public boolean evaluate(T context) {
        boolean ret = false;
        String stringToTest = getStringToTest(context);
        if (stringToTest == null) {
            ret = false;
        } else if (pattern != null) {
            ret = pattern.matcher(stringToTest).matches();
        }
        if (logger.isLoggable(Level.FINE)) {
            logger.fine(this.getClass().getSimpleName() + " - Evaluated string [" + stringToTest + "] against regex [" + regex + "]: " + ret);
        }
        return ret;
    }

    /**
     * Returns the string that needs to be tested with the regex pattern.
     *
     * @param context - the context object
     * @return the string that needs to be tested with the regex pattern
     */
    protected abstract String getStringToTest(T context);

    // GETTERS and SETTERS

    public String getRegex() {
        return regex;
    }

    public void setRegex(String regex) {
        this.regex = regex;
    }

    public boolean isCaseInsensitive() {
        return caseInsensitive;
    }

    public void setCaseInsensitive(boolean caseInsensitive) {
        this.caseInsensitive = caseInsensitive;
    }
}
