/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 */

package com.wm.dal.jdbc;

import com.wm.dal.client.DALNIOClient;
import com.wm.dal.client.DALNettyClient;
import com.wm.dal.client.DALOIONettyClient;
import com.wm.dal.client.IDALClient;
import com.wm.dal.client.IDALRequest;
import com.wm.dal.client.IDALResponse;
import com.wm.dal.common.ConnectionDelegate;
import com.wm.dal.common.DALSession;
import com.wm.dal.jdbc.utils.Constants;
import com.wm.dal.jdbc.utils.MethodAttribute;
import com.wm.dal.util.DALLogger;
import com.wm.dal.util.ServerConf;

import java.io.Serializable;

import java.net.InetAddress;

import java.sql.SQLException;

import javax.transaction.xa.XAException;


/**
 * @author cshah
 */
public class Processor {
    private boolean isServerEnabled = true;
    private ConnectionDelegate delegate = new ConnectionDelegate();
    private DALUrl url = null;
    private DALSession dalSession = null; 
    private static final DALLogger logger = DALLogger.getInstance();
    private IDALClient client;
    private int retryCount = 3;
    
    /** 
     * 
     * @param pUrl
     */
    public Processor(DALUrl pUrl) {
        this.url = pUrl;
        isServerEnabled = ServerConf.isServerModeEnabled();
        validateSession();
            if (isServerEnabled) {
                do {
                    for (int i=1; i<=retryCount; i++) {
                        try {
                            newClient(ServerConf.getServerType());
                            break;
                        } catch (Exception exp) {
                            exp.printStackTrace();
                        }
                    }
                } while (client == null && url.failover());

                if (client == null) {
                    logger.severe("Could not connect to " + url.getRawUrl() + ", DAL is running in client mode");
                    isServerEnabled = false;
                }
            }
            
            
            
    }

    private void newClient(String serverType) throws Exception {
        if (serverType.equals("nio")) {
            client = new DALNIOClient(url.getHost(), url.getPort());
        } else if (serverType.equals("oionetty")) {
            client = new DALOIONettyClient(InetAddress.getByName(url.getHost()), url.getPort());
        } else {
            client = new DALNettyClient(InetAddress.getByName(url.getHost()), url.getPort());
        }
    }

    /**
     * 
     * @param conn
     * @param request
     * @return
     * @throws SQLException
     */
    public IDALResponse execute(IDALRequest request) throws SQLException {
        return executeInternal(request);
    }

    /**
     * 
     * @param stmt
     * @param request
     * @return
     * @throws SQLException
     */
    public IDALResponse execute(DALStatement stmt, 
                               IDALRequest request) throws SQLException {
        getSession().setStatementAttribute(MethodAttribute.SQL,new MethodAttribute(stmt.sql));
        //removed because of AVO problem
        //getSession().setStatementAttribute(MethodAttribute.SQL,new MethodAttribute(stmt.sql.toLowerCase()));
        getSession().setStatementAttribute(MethodAttribute.SQL_PARAMETERS,new MethodAttribute((Serializable)stmt.parameterMetaData.getArguments()));
        request.setID(stmt.ID);
        return executeInternal(request);
    }

    /**
     * 
     * @param resultSet
     * @param request
     * @return
     * @throws SQLException
     */
    public IDALResponse execute(DALResultSet resultSet, 
                               IDALRequest request) throws SQLException {
        request.setID(resultSet.cursor.getCurSorID());
        return executeInternal(request);
    }

    /**
     * 
     * @param request
     * @return
     * @throws SQLException
     */
    protected IDALResponse executeInternal(IDALRequest request) throws SQLException {
        IDALResponse response = null;
        request.setSession(dalSession);
        long startTime = System.currentTimeMillis();
        String execution = "SERVER";
        if (logger.isLoggable(DALLogger.LEVEL_INFO))
          logger.info("in execute internal " + request + ":" + execution);        
        try {
        if (isServerEnabled) {
            response = serverExecute(request);
        } else {
            execution = "CLIENT";
            response = clientExecute(request);
        }
        } catch (SQLException sqle) {
        	logger.log(DALLogger.LEVEL_WARNING, "Unexpected SQLException", sqle);
            throw sqle;
        } catch (Exception e) {
        	logger.log(DALLogger.LEVEL_WARNING, "Unexpeted Exception", e);
            throw new SQLException(e);
        } finally {
            getSession().setServerEndPoint(response != null ? response.getServerEndPoint() : "");
            String poolName = (response != null) ? response.getPoolName() : null;
            long elapsedTime = System.currentTimeMillis() - startTime;
            int levelinfo = DALLogger.LEVEL_INFO;
            String sql = "";
            switch (request.getCommand()) {
                case Constants.EXECUTE :
                case Constants.EXECUTE_QUERY :
                case Constants.EXECUTE_UPDATE :
                case Constants.EXECUTE_W_AUTOGENKEYS :
                case Constants.EXECUTE_UPDATE_W_AUTOGENKEYS :
                case Constants.EXECUTE_UPDATE_W_COLUMNINDEXES :
                case Constants.EXECUTE_UPDATE_W_COLUMNNAMES :
                case Constants.EXECUTE_W_COLUMNINDEXES :
                case Constants.EXECUTE_W_COLUMNNAMES :
                case Constants.EXECUTE_BATCH : {
                    levelinfo = DALLogger.LEVEL_WARNING;
                    MethodAttribute meSQL = request.getSession().getStatementAttribute(MethodAttribute.SQL);
                    if (meSQL != null && meSQL.getAttribute() != null) {
                        sql = meSQL.getAttribute().toString();
                    }
                        break;
                }
                default :        
                        levelinfo = DALLogger.LEVEL_INFO;
                        break;
            }
            if (logger.isLoggable(levelinfo))
              logger.log(levelinfo, "DAL " + execution + " BENCH: { " +
                                    //"  Client = " + request.getSession().getClientHost() +
                                    "  Server= " + request.getSession().getServerEndPoint() +
                                    ", Session= " + request.getSession().getSessionID() + 
                                    ", Caller= " + Constants.getDescription(request.getCaller()) + 
                                    ", Command= " + Constants.getDescription(request.getCommand()) +
                                    ", Pool= " + poolName +
                                    ", Sql=[" + sql +  "]" +
                                    " } -> millis = " + elapsedTime ); 
        }
        
           if (SQLException.class.isInstance(response.getException())) {
                throw (SQLException)response.getException();
//           } else if (XAException.class.isInstance(response.getException())) {
//                throw (XAException)response.getException();
           }  else if ( response.getException() != null ) {
                Exception ee = response.getException();
                if (ee.toString() != null ) {
                    throw new SQLException(ee.toString(), ee);
                } else {
                    throw new SQLException("Unknown exception", ee);
                }
           }
           
           request.getSession().incrementCounter();
           return response;
    }
    
    /**
     * 
     * @param request
     * @return
     * @throws SQLException
     */
    private IDALResponse clientExecute(IDALRequest request) throws Exception {
        try {
            return delegate.execute(request);
        } catch (Exception exp) {
        	logger.log(DALLogger.LEVEL_WARNING, "Unexpeted Exception", exp);
            throw new SQLException(exp);
        }
    }

    /**
     * 
     * @param request
     * @return
     * @throws SQLException
     */
    private IDALResponse serverExecute(IDALRequest request) throws Exception {
        return client.execute(request);
    }

    /**
     * 
     * @throws SQLException
     */
    private void validateSession() {
        if (dalSession == null ) {
            dalSession = new DALSession(Constants.getSessionId(), Constants.getClientID());
            if (logger.isLoggable(DALLogger.LEVEL_FINE))
              logger.fine("Creating new DAL Session " + dalSession);
        }

        dalSession.setConnectionAttribute(MethodAttribute.SERVER_MODE,new MethodAttribute(isServerEnabled));
    }

    /**
     * 
     */
    protected void releaseResources() {
        dalSession.invalidate();
        dalSession.setConnectionAttribute(MethodAttribute.SERVER_MODE,new MethodAttribute(isServerEnabled));
    }

    /**
     * 
     * @return
     */
    public DALSession getSession() {
        return dalSession;
    }

    /**
     * 
     */
    protected void close() {
        try {
            releaseResources();
            if (client != null)
            	client.close();
        } catch (Exception exp) {exp.printStackTrace();}
    }    
}
