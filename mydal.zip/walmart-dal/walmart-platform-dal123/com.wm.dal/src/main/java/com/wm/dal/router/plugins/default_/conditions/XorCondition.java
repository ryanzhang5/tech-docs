/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.conditions;

import com.wm.dal.router.plugins.default_.ICondition;

import java.util.logging.Logger;
import java.util.logging.Level;

/**
 * XorCondition - evaluates a list of child conditions and returns true if
 * exactly one of them returns true. If the list of child conditions is empty,
 * this class returns a false - aligned with commons-collection's OnePredicate
 *
 * @author mkishore
 * @since 1.0
 */
public class XorCondition<T> extends AbstractCompositeCondition<T> {
    private static final Logger logger = Logger.getLogger(XorCondition.class.getName());

    /**
     * Returns true if exactly one of the child conditions evaluate to true.
     *
     * @param context the context that is passed into the child conditions
     * @return true if exactly one of the child conditions evaluate to true.
     */
    public boolean evaluate(T context) {
        int i = 0;
        for (ICondition<T> condition : conditions) {
            if (condition.evaluate(context)) {
                if (++i == 2) {
                    if (logger.isLoggable(Level.FINE)) {
                        logger.fine(this.getClass().getSimpleName() + " - Evaluated: false");
                    }
                    return false;
                }
            }
        }
        boolean ret = i == 1;
        if (logger.isLoggable(Level.FINE)) {
            logger.fine(this.getClass().getSimpleName() + " - Evaluated: " + ret);
        }
        return ret;
    }

}