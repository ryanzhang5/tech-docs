/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.server.netty;

import com.wm.dal.server.DALThreadFactory;
import com.wm.dal.util.DALLogger;
import com.wm.dal.util.ServerConf;

import java.util.concurrent.TimeUnit;

import org.jboss.netty.channel.ChannelPipeline;
import org.jboss.netty.channel.ChannelPipelineFactory;
import org.jboss.netty.channel.Channels;
import org.jboss.netty.handler.codec.serialization.ObjectDecoder;
import org.jboss.netty.handler.codec.serialization.ObjectEncoder;
import org.jboss.netty.handler.execution.ExecutionHandler;
import org.jboss.netty.handler.execution.OrderedMemoryAwareThreadPoolExecutor;

/**
 * 
 * @author cshah
 * @version 1.0
 */
public class DALPipelineFactory implements ChannelPipelineFactory  {
    private static final DALLogger logger = DALLogger.getInstance();
/*
    private static final ExecutionHandler executionHandler = new ExecutionHandler(
                new OrderedMemoryAwareThreadPoolExecutor
                    (   ServerConf.getExecutorThreadCount(), 
                        ServerConf.getMaxChannelMemorySize(), 
                        ServerConf.getTotalMemorySize()));
*/
    private static final ExecutionHandler executionHandler = new ExecutionHandler(
                new OrderedMemoryAwareThreadPoolExecutor
                    (   ServerConf.getMaxIOWorkerThreadCount(), 
                        0, 
                        0,
                        5,
                        TimeUnit.MINUTES,
                        new DALThreadFactory("worker")
                        )
                    );


    /**
     * 
     * @return
     * @throws Exception
     */
    public ChannelPipeline getPipeline() throws Exception {
        logger.info("Getting DAL Pipeline Factory.............");
        
        ChannelPipeline pipeline = Channels.pipeline();
        pipeline.addLast("decoder", new ObjectDecoder(ServerConf.getMaxObjectSize()));
        pipeline.addLast("encoder", new ObjectEncoder());
        pipeline.addLast("executor", executionHandler);
        pipeline.addLast("handler", new DALNettyRequestHandler());

        return pipeline;
    }
}
