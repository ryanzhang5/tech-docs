/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc.args;

import com.wm.dal.jdbc.DALArray;
import com.wm.dal.jdbc.utils.DALUtil;

import java.sql.Array;
import java.sql.SQLException;
import java.sql.Types;

/**
 * @author cshah
 * @version 1.0
 */
public class ArrayArg extends DALArgs {
    private Array value;

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    public ArrayArg(int position, boolean isOut, boolean isNull, Array value  ) throws SQLException {
        init(position, isOut, isNull, value, null);
    }

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     * @param typeName
     */
    public ArrayArg(int position, boolean isOut, boolean isNull, Array value, String typeName ) throws SQLException {
        init(position, isOut, isNull, value, typeName);
    }

    /**
     *
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     * @param typeName
     */
    protected void init(int position, boolean isOut, boolean isNull, Array value, String typeName) throws SQLException {
        super.init(position, isOut, isNull, Types.ARRAY, typeName);
        this.value = (Array) DALUtil.convertToDALObject(value);
    }

    /**
     * @param obj
     * @return
     */
    public boolean equals(Object obj) {
        ArrayArg arg = (ArrayArg)obj;
        return super.equals(arg) && value == arg.value;
    }

    /**
     * @return
     */
    public Array getValue() {
        return value;
    }

    /**
     * @return
     */
    public Object getValueObject() {
        return getValue();
    }

    /**
     * @param value
     * @throws SQLException
     */
    public void setValueObject(Object value) throws SQLException {
        if (value == null) {
            this.value = null;
            this.isNull(true);
        } else if (value instanceof Array) {
            this.value = (Array) DALUtil.convertToDALObject(value);
        }
    }

    /**
     * @return
     */
    public String toString() {
        StringBuffer sb = new StringBuffer();
        try {
            Object obj[] = (value!=null) ?(Object[])value.getArray() :DALUtil.EMPTY_OBJECT_ARRAY;
            for (Object o : obj) {
                sb.append(o.toString());
                sb.append("\n");
            }
            
        } catch (Exception e) { e.printStackTrace();;}
        return super.toString() + ", value = |" + sb.toString()+ "|";
    }

}
