/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.jdbc.sqldata;

import java.io.Serializable;

import java.sql.SQLData;

/**
 * SerializableSQLData - marker interface for serializable SQLData implementations.
 *
 * @author mkishore
 * @since 1.0
 */
public interface SerializableSQLData extends SQLData, Serializable {
    // no-op marker interface
}
