/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 */

package com.wm.dal.server.nio;

import com.wm.dal.server.AbstractDALServer;
import com.wm.dal.util.DALLogger;
import com.wm.dal.util.ServerConf;

import java.net.InetSocketAddress;

import java.nio.channels.ServerSocketChannel;


/**
 * 
 * @author cshah
 */
public class DALNIOServer extends AbstractDALServer {
    private static ServerSocketChannel listenSocketChannel;

    /**
     * 
     * @param port
     * @throws Exception
     */
    public DALNIOServer(int port) {
        super(port);
    }

    /**
     * 
     */
    public void shutdownNow() {
        try {
            logger.severe(DALNIOServer.class.getName() + "DALNIOServer/shutdown(): Shutting down NOW!!!");
            if (listenSocketChannel != null && listenSocketChannel.isOpen()) {
                listenSocketChannel.close();
            }
        } catch (Exception exp) {
            exp.printStackTrace();
        } finally {
            System.currentTimeMillis();//System.exit(-1);
        }
    }

    /**
     * 
     */
    public void run() {
        try {
            listenSocketChannel = ServerSocketChannel.open();
            listenSocketChannel.socket().setReuseAddress(ServerConf.getReuseAddress());
            listenSocketChannel.socket().bind(new InetSocketAddress(ServerConf.getHostName(),getPort()), ServerConf.getBackLog());
            //listenSocketChannel.socket().bind(new InetSocketAddress(getPort()), ServerConf.getBackLog());
        }
        catch ( Exception e ) { 
          logger.log( DALLogger.LEVEL_SEVERE, 
              getClass().getName() + "/DALNIOServer(): caught Exception while setting up a listening socket." );
          shutdownNow();
        }     
    
        logger.warning("DAL NIO Server is listining on port : " + getPort());
        try {
            Acceptor acceptor = new Acceptor(listenSocketChannel);
            Thread tt = new Thread(acceptor);
            tt.setName( "acceptor-thread-0");
            tt.start();

        } catch (Exception exp) {
            logger.severe("Caught Exception while starting Server Socket ");
            exp.printStackTrace();
            shutdownNow();
        }

    }
}
