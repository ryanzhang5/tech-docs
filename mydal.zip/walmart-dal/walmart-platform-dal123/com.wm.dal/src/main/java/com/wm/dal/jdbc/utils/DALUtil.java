/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc.utils;

import com.wm.dal.common.ConnectionDelegate;
import com.wm.dal.jdbc.*;
import com.wm.dal.jdbc.Datum;
import com.wm.dal.jdbc.args.*;
import com.wm.dal.util.DALLogger;
import com.wm.dal.util.ServerConf;
import oracle.jdbc.OracleConnection;
import oracle.sql.*;

import java.io.*;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * @author cshah
 * @version 1.0
 */
public class DALUtil {
    private static final DALLogger logger = DALLogger.getInstance();

    public static final char[] EMPTY_CHAR_ARRAY = new char[0];
    public static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
    public static final Object[] EMPTY_OBJECT_ARRAY = new Object[0];

    /**
     * This method is invoked on the "server" side and is meant to pull values from
     * the native resultSet into the DAL resultSet.
     * <p/>
     * This method does not explicitly transform the objects into DAL compatible Serializable
     * objects. However, the Datum class has the appropriate logic inside its constructor to
     * do the necessary conversion.
     *
     * @param rs       - the native resultSet
     * @param row      - a row in the DAL resultSet
     * @param colIndex - the column index
     * @param type     - the SQL type code from the resultSEt metadata
     * @throws SQLException
     */
    public static void setResultSetRowDatumValue(ResultSet rs, DALRow row, int colIndex, int type) throws SQLException {
        if (rs == null) {
            return;
        }

        try {
            // ref: http://java.sun.com/javase/6/docs/technotes/guides/jdbc/getstart/mapping.html#996857
            Object value;
            switch (type) {
                case java.sql.Types.CHAR:
                case java.sql.Types.VARCHAR:
                case java.sql.Types.LONGVARCHAR:
                    value = rs.getString(colIndex);
                    break;
                case java.sql.Types.TIMESTAMP:
                    value = rs.getTimestamp(colIndex);
                    break;
                case java.sql.Types.TIME:
                    value = rs.getTime(colIndex);
                    break;
                case java.sql.Types.DATE:
                    value = rs.getDate(colIndex);
                    break;
                case java.sql.Types.BOOLEAN:
                case java.sql.Types.BIT:
                    //value = rs.getBoolean(colIndex);
                    //break;
                case java.sql.Types.BIGINT:
                    //value = rs.getLong(colIndex);
                    //break;
                case java.sql.Types.INTEGER:
                    //value = rs.getInt(colIndex);
                    //break;
                case java.sql.Types.SMALLINT:
                    //value = rs.getShort(colIndex);
                    //break;
                case java.sql.Types.TINYINT:
                    //value = rs.getByte(colIndex);
                    //break;
                case java.sql.Types.DOUBLE:
                    //value = rs.getDouble(colIndex);
                    //break;
                case java.sql.Types.REAL:
                case java.sql.Types.FLOAT:
                    //value = rs.getFloat(colIndex);
                    //break;
                case Types.JAVA_OBJECT:
                    value = rs.getObject(colIndex);
                    break;
                case java.sql.Types.DECIMAL:
                case java.sql.Types.NUMERIC:
                    value = rs.getBigDecimal(colIndex);
                    break;
                case java.sql.Types.VARBINARY:
                case java.sql.Types.BINARY:
                case Types.LONGVARBINARY:
                    value = rs.getBytes(colIndex);
                    break;
                case java.sql.Types.CLOB:
                    value = rs.getClob(colIndex);
                    break;
                case java.sql.Types.BLOB:
                    value = rs.getBlob(colIndex);
                    break;
                case Types.STRUCT:
                    value = rs.getObject(colIndex);
                    break;
                case Types.ARRAY:
                    value = rs.getArray(colIndex);
                    break;
                case DALTypes.ORACLE_CURSOR:
                case java.sql.Types.OTHER:
                default:
                    throw new SQLException("Unsupported type " + type + " at index " + colIndex);
            }

            row.setDatum(colIndex, new Datum(value, type));

        } catch (SQLException sqle) {
            sqle.printStackTrace();
            throw sqle;
        } catch (Exception e) {
            e.printStackTrace();
            throw new SQLException(e);
        }
    }

    /**
     * Similar to the above method, but instead of moving the value from ResultSet into a Datum,
     * this method moves the value from a CallableStatement into a DALArgs subclass.
     * <p/>
     * This method does not explicitly transform the objects into DAL compatible Serializable
     * objects. However, the appropriate DALArgs subclasses have the logic inside their
     * setValueObject() method to do the nexessary conversion.
     *
     * @param stmt     - the callable statement
     * @param inputArg - the input Arg
     * @param delegate - the connection delegate to "register" ORACLE_CURSOR
     * @return the OUT parameter value encapsulated inside a DALArgs subclass
     * @throws SQLException - in case of any errors
     */
    public static DALArgs getStatementOutParameterValue(PreparedStatement stmt, DALArgs inputArg, ConnectionDelegate delegate) throws SQLException {
        logger.info("Getting Argument : " + inputArg.toString());
        if (stmt == null || inputArg == null || !inputArg.isOutParameter()) return null;

        int type = inputArg.getDataType();
        int position = inputArg.getPosition();

        DALArgs returnArg = inputArg;
        switch (type) {
            case java.sql.Types.LONGVARCHAR:
            case java.sql.Types.CHAR:
            case java.sql.Types.VARCHAR: {
                String value = ((CallableStatement) stmt).getString(position);
                returnArg.setValueObject(value);
                break;
            }
            case java.sql.Types.BOOLEAN:
            case java.sql.Types.BIT: {
                Boolean value = ((CallableStatement) stmt).getBoolean(position);
                returnArg.setValueObject(value);
                break;
            }
            case java.sql.Types.TIMESTAMP: {
                Timestamp value = ((CallableStatement) stmt).getTimestamp(position);
                returnArg.setValueObject(value);
                break;
            }
            case java.sql.Types.TIME: {
                Time value = ((CallableStatement) stmt).getTime(position);
                returnArg.setValueObject(value);
                break;
            }
            case java.sql.Types.DATE: {
                Date value = ((CallableStatement) stmt).getDate(position);
                returnArg.setValueObject(value);
                break;
            }
            case java.sql.Types.BIGINT: {
                Long value = ((CallableStatement) stmt).getLong(position);
                returnArg.setValueObject(value);
                break;
            }
            case java.sql.Types.SMALLINT: {
                Short value = ((CallableStatement) stmt).getShort(position);
                returnArg.setValueObject(value);
                break;
            }
            case java.sql.Types.TINYINT: {
                Byte value = ((CallableStatement) stmt).getByte(position);
                returnArg.setValueObject(value);
                break;
            }
            case java.sql.Types.DECIMAL:
            case java.sql.Types.NUMERIC: {
                Double value = ((CallableStatement) stmt).getDouble(position);
                returnArg.setValueObject(value);
                break;
            }
            case java.sql.Types.DOUBLE: {
                Double value = ((CallableStatement) stmt).getDouble(position);
                returnArg.setValueObject(value);
                break;
            }
            case java.sql.Types.REAL:
            case java.sql.Types.FLOAT: {
                Float value = ((CallableStatement) stmt).getFloat(position);
                returnArg.setValueObject(value);
                break;
            }
            case java.sql.Types.INTEGER: {
                Integer value = ((CallableStatement) stmt).getInt(position);
                returnArg.setValueObject(value);
                break;
            }
            case java.sql.Types.CLOB: {
                Clob value = ((CallableStatement) stmt).getClob(position);
                returnArg.setValueObject(value);
                break;
            }
            case java.sql.Types.BLOB: {
                Blob value = ((CallableStatement) stmt).getBlob(position);
                returnArg.setValueObject(value);
                break;
            }
            case Types.JAVA_OBJECT: {
                Object value = ((CallableStatement) stmt).getObject(position);
                returnArg.setValueObject(value);
                break;
            }
            case Types.LONGVARBINARY: {
                Object value = ((CallableStatement) stmt).getBytes(position);
                returnArg.setValueObject(value);
                break;
            }
            case Types.ARRAY: {
                Array value = ((CallableStatement) stmt).getArray(position);
                returnArg.setValueObject(value);
                break;
            }
            case DALTypes.ORACLE_CURSOR: {
                ResultSet rs = null;
                try {
                    rs = (ResultSet) ((CallableStatement) stmt).getObject(position);
                } catch (SQLException exp) {
                    if (!ServerConf.shouldIgnoreException(exp.getMessage(), exp.getErrorCode())) {
                        throw exp;
                    }
                } catch (Exception exp) {
                    if (!ServerConf.shouldIgnoreException(exp.getMessage(), -1)) {
                        throw new SQLException(exp);
                    }
                }
                delegate.registerResultSet(stmt, rs);
                returnArg = getResultSetCursor(stmt, rs, position, type);
                break;
            }
            case java.sql.Types.VARBINARY:
            case java.sql.Types.BINARY: {
                Object value = ((CallableStatement) stmt).getBytes(position);
                returnArg.setValueObject(value);
                break;
            }
            // unsupported as yet...
            case java.sql.Types.OTHER:
            default:
                throw new SQLException("Unsupported type " + type);
        }
        returnArg.isNull(((CallableStatement) stmt).wasNull());
        return returnArg;
    }

    /**
     * This method is invoked on the server-side to "set" all the input parameters the caller
     * had set on the client-side. The PreparedStatementCommand calls this method to set on
     * argument at a time.
     *
     * The method has embedded default values for cases where the "arg" says its not null, but
     * the underlying valueObject is null..
     *
     * @param stmt - the native prepared/callable statement
     * @param arg  - the input argument that needs to be set
     * @throws SQLException - in case of any errors
     */
    public static void setStmtParameter(Connection conn, PreparedStatement stmt, DALArgs arg) throws SQLException {
        logger.info("Setting Argument : " + String.valueOf(arg));
        if (stmt == null || arg == null) return;

        Object valueObject = arg.getValueObject();
        int type = arg.getDataType();
        int position = arg.getPosition();

        if (arg.isNull()) {
            stmt.setNull(position, type);
            return;
        }

        if (arg.isOutParameter() && stmt instanceof CallableStatement) {
            if (arg.getTypeName() != null) {
                ((CallableStatement) stmt).registerOutParameter(position, type, arg.getTypeName());
            } else {
                ((CallableStatement) stmt).registerOutParameter(position, type);
            }
            if (valueObject == null) {
                // its a pure OUT param, not an IN_OUT
                return;
            }
        }

        switch (type) {
            case java.sql.Types.LONGVARCHAR: {
                if (arg instanceof AsciiStreamArg) {
                    AsciiStreamArg aarg = (AsciiStreamArg) arg;
                    InputStream istream = new ByteArrayInputStream(aarg.getValue());
                    stmt.setBinaryStream(position, istream, aarg.getLength());
                } else if (arg instanceof CharStreamArg) {
                    CharStreamArg carg = (CharStreamArg) arg;
                    Reader reader = new CharArrayReader(carg.getValue());
                    stmt.setCharacterStream(position, reader, carg.getLength());
                }
                break;
            }
            case java.sql.Types.CHAR:
            case java.sql.Types.VARCHAR: {
                if (valueObject == null) {
                    stmt.setString(position, null);
                } else {
                    stmt.setString(position, valueObject.toString());
                }
                break;
            }
            case java.sql.Types.BOOLEAN:
            case java.sql.Types.BIT: {
                if (valueObject == null) {
                    stmt.setBoolean(position, false);
                } else {
                    stmt.setBoolean(position, (Boolean) valueObject);
                }
                break;
            }
            case java.sql.Types.TIMESTAMP: {
                if (valueObject == null) {
                    stmt.setTimestamp(position, null);
                } else {
                    stmt.setTimestamp(position, (Timestamp) valueObject);
                }
                break;
            }
            case java.sql.Types.TIME: {
                if (valueObject == null) {
                    stmt.setTime(position, null);
                } else {
                    stmt.setTime(position, (Time) valueObject);
                }
                break;
            }
            case java.sql.Types.DATE: {
                if (valueObject == null) {
                    stmt.setDate(position, null);
                } else {
                    stmt.setDate(position, (Date) valueObject);
                }
                break;
            }
            case java.sql.Types.BIGINT: {
                if (valueObject == null) {
                    stmt.setLong(position, 0);
                } else {
                    stmt.setLong(position, (Long) valueObject);
                }
                break;
            }
            case java.sql.Types.SMALLINT: {
                if (valueObject == null) {
                    stmt.setShort(position, Short.valueOf("0"));
                } else {
                    stmt.setShort(position, (Short) valueObject);
                }
                break;
            }
            case java.sql.Types.TINYINT: {
                if (valueObject == null) {
                    stmt.setByte(position, Byte.valueOf((byte) 0));
                } else {
                    stmt.setByte(position, (Byte) valueObject);
                }
                break;
            }
            case java.sql.Types.DECIMAL:
            case java.sql.Types.NUMERIC: {
                if (valueObject == null) {
                    stmt.setBigDecimal(position, BigDecimal.valueOf(0));
                } else {
                    stmt.setBigDecimal(position, (BigDecimal) valueObject);
                }
                break;
            }
            case java.sql.Types.DOUBLE: {
                if (valueObject == null) {
                    stmt.setDouble(position, 0);
                } else {
                    stmt.setDouble(position, (Double) valueObject);
                }
                break;
            }
            case java.sql.Types.REAL:
            case java.sql.Types.FLOAT: {
                if (valueObject == null) {
                    stmt.setFloat(position, 0);
                } else {
                    stmt.setFloat(position, (Float) valueObject);
                }
                break;
            }
            case java.sql.Types.INTEGER: {
                if (valueObject == null) {
                    stmt.setInt(position, 0);
                } else {
                    stmt.setInt(position, (Integer) valueObject);
                }
                break;
            }
            case java.sql.Types.CLOB: {
                Clob clob = (Clob) valueObject;
                if (conn.isWrapperFor(OracleConnection.class)) {
                    clob = DALUtil.convertToORAClob(clob, conn);
                }
                stmt.setClob(position, clob);
                break;
            }
            case java.sql.Types.BLOB: {
                Blob blob = (Blob) valueObject;
                if (conn.isWrapperFor(OracleConnection.class)) {
                    blob = DALUtil.convertToORABlob(blob, conn);
                }
                stmt.setBlob(position, blob);
                break;
            }
            case Types.JAVA_OBJECT: {
                if (conn.isWrapperFor(OracleConnection.class)) {
                    valueObject = DALUtil.convertToORAObject(valueObject, conn);
                }
                stmt.setObject(position, valueObject);
                break;
            }
            case Types.LONGVARBINARY: {
                BinaryStreamArg barg = (BinaryStreamArg) arg;
                InputStream istream = new ByteArrayInputStream(barg.getValue());
                stmt.setBinaryStream(position, istream, barg.getLength());
                break;
            }
            case Types.ARRAY: {
                Array array = (Array) valueObject;
                if (conn.isWrapperFor(OracleConnection.class)) {
                    array = DALUtil.convertToORAArray(array, conn);
                }
                stmt.setArray(position, array);
                break;
            }
            case java.sql.Types.VARBINARY:
            case java.sql.Types.BINARY: {
                if (valueObject == null) {
                    stmt.setBytes(position, null);
                } else {
                    stmt.setBytes(position, ((ByteArrayArg) arg).getValueObject());
                }
                break;
            }

            case DALTypes.ORACLE_CURSOR:
            case java.sql.Types.OTHER:
            default:
                throw new SQLException("Unsupported type " + type);
        }
    }


    /**
     * @param rs
     * @return
     * @throws SQLException
     */
    public static DALResultSetMetaData getResultSetMetaData(ResultSet rs) throws SQLException {

        //changed due to AVO but again changed due to L2 RSMD
        if (rs == null) {
            logger.warning("ResultSet found null....");
            return new DALResultSetMetaData(0, new int[0], new String[0], new String[0]);
        }

        //callable statement was calling executeQuery
        if (rs != null) {
            try {
                rs.getMetaData();
            } catch (Exception exp) {
                logger.warning("ResultSet Metadata throwing an error....");
                //exp.printStackTrace();
                return new DALResultSetMetaData(1, new int[1], new String[1], new String[1]);
            }
        }

        ResultSetMetaData rsmd = rs.getMetaData();
        int colCount = rsmd.getColumnCount();
        int colType[] = new int[colCount];
        String colLabel[] = new String[colCount];
        String colName[] = new String[colCount];
        String colTypeName[] = new String[colCount];

        for (int i = 1; i <= colCount; i++) {
            colType[i - 1] = rsmd.getColumnType(i);
            colLabel[i - 1] = rsmd.getColumnLabel(i);
            colName[i - 1] = rsmd.getColumnName(i);
            colTypeName[i - 1] = rsmd.getColumnTypeName(i);
        }

        return new DALResultSetMetaData(colCount, colType, colLabel, colName);
    }

    public static DALArgs getResultSetCursor(Statement stmt, ResultSet rs, int position, int type) throws SQLException {
    	return getResultSetCursor(stmt, rs, position, type, -1);
    }
    /**
     * @param stmt
     * @param rs
     * @param position
     * @param type
     * @return
     * @throws SQLException
     */
    public static DALArgs getResultSetCursor(Statement stmt, ResultSet rs, int position, int type, int maxRow) throws SQLException {
        List<DALRow> list = new ArrayList<DALRow>();
        logger.info("in get result set cursor " + (rs != null ? rs.hashCode() : -1));

        DALResultSetMetaData dalrsmd = DALUtil.getResultSetMetaData(rs);

        if (rs == null) {
            DALCursor cursor = new DALCursor(-1, position, type, list, dalrsmd, DALTypes.ORACLE_CURSOR, ResultSet.CONCUR_READ_ONLY);
            cursor.setRsFullyRead(true);
            return cursor;
        }

        //callable statement was calling executeQuery
        if (rs != null) {
            try {
                rs.getMetaData(); 
            } catch (Exception exp) {
                DALCursor cursor = new DALCursor(-1, position, type, list, dalrsmd, DALTypes.ORACLE_CURSOR, ResultSet.CONCUR_READ_ONLY);
                cursor.setRsFullyRead(true);
                return cursor;
            }
        }

        int colCount = dalrsmd.getColumnCount();

        if (stmt != null) 
        	maxRow = (maxRow < 0) ? stmt.getMaxRows() : Math.min(maxRow, stmt.getMaxRows());

        int fetchSize = rs.getFetchSize();

        logger.info("Fetch size " + fetchSize);

        if (fetchSize <= 0) {
            fetchSize = Constants.getFetchSize();
            //rs.setFetchSize(fetchSize);
            //logger.info("set fetch size " + fetchSize);
        }

        int endLoop = (maxRow > 0 ? maxRow : fetchSize);

        int counter = 1;
        boolean rsFullyRead = false;

        while (counter <= endLoop) {
            if (rs.next()) {
                //logger.info("Counter " + counter + ":" + fetchSize + ":" + colCount);
                counter++;
                DALRow row = new DALRow(colCount);
                for (int i = 1; i <= colCount; i++) {
                    //logger.warning("For loop : " + i + ": " + DALUtil.getTypeName(dalrsmd.getColumnType(i)));
                    DALUtil.setResultSetRowDatumValue(rs, row, i, dalrsmd.getColumnType(i));
                }
                list.add(row);
                //logger.warning("TOTAL Count " + list.size());
            } else {
                rsFullyRead = true;
                break;
            }
        }//while

        DALCursor cursor = new DALCursor(rs.hashCode(), position, type, list, dalrsmd, rs.getType(), rs.getConcurrency());

        if (list.size() == 0 || rsFullyRead) {
            logger.info("no more records in the resultset " + rs.hashCode());
            cursor.setRsFullyRead(true);
        }

        return cursor;
    }

    /**
     * @param stmt
     * @param rs
     * @return
     * @throws SQLException
     */
    public static DALArgs getResultSet(Statement stmt, ResultSet rs) throws SQLException, Exception {
        //TODO -- check for DAL Types Oracle or My SQL
        return getResultSetCursor(stmt, rs, 1, DALTypes.ORACLE_CURSOR);
    }

    /**
     * @param position
     * @param value
     * @return
     * @throws SQLException
     */
    public static DALArgs makeInArg(int position, long value) throws SQLException {
        return new LongArg(position, false, false, value);
    }

    /**
     * @param position
     * @param value
     * @return
     * @throws SQLException
     */
    public static DALArgs makeInArg(int position, double value) throws SQLException {
        return new DoubleArg(position, false, false, value);
    }

    /**
     * @param position
     * @param value
     * @return
     * @throws SQLException
     */
    public static DALArgs makeInArg(int position, float value) throws SQLException {
        return new FloatArg(position, false, false, value);
    }

    /**
     * @param position
     * @param value
     * @return
     * @throws SQLException
     */
    public static DALArgs makeInArg(int position, int value) throws SQLException {
        return new IntArg(position, false, false, value);
    }

    /**
     * @param position
     * @param value
     * @return
     * @throws SQLException
     */
    public static DALArgs makeInArg(int position, byte[] value) throws SQLException {
        if (value == null)
            throw new SQLException("Null value is not allowed" + position + ":" + java.sql.Types.VARCHAR);
        return new ByteArrayArg(position, false, false, value);
    }

    /**
     * @param position
     * @param value
     * @return
     * @throws SQLException
     */
    public static DALArgs makeInArg(int position, String value) throws SQLException {
        if (value == null) {
            return makeNullArg(position, java.sql.Types.VARCHAR);
        }
        return new StringArg(position, false, false, value);
    }

    /**
     * @param position
     * @param value
     * @return
     * @throws SQLException
     */
    public static DALArgs makeOutArg(int position, String value) throws SQLException {
        if (value == null) {
            return makeNullArg(position, java.sql.Types.VARCHAR);
        }
        return new StringArg(position, true, false, value);
    }

    /**
     * @param position
     * @param type
     * @return
     * @throws SQLException
     */
    public static DALArgs makeNullArg(int position, int type) throws SQLException {
        return makeArg(position, type, false, true, null);
    }

    /**
     * @param position
     * @param type
     * @return
     * @throws SQLException
     */
    public static DALArgs makeOutArg(int position, int type) throws SQLException {
        return makeArg(position, type, true, false, null);
    }

    /**
     * @param position
     * @param type
     * @return
     * @throws SQLException
     */
    public static DALArgs makeOutArg(int position, int type, String typeName) throws SQLException {
        return makeArg(position, type, true, false, typeName);
    }

/*******************************************************************************/
    /**
     * @param position
     * @param type
     * @param isOut
     * @param isNull
     * @return
     * @throws SQLException
     */
    public static DALArgs makeArg(int position, int type, boolean isOut, boolean isNull) throws SQLException {
        return makeArg(position, type, isOut, isNull, null);
    }

    /**
     * @param position
     * @param type
     * @param isOut
     * @param isNull
     * @param typeName
     * @return
     * @throws SQLException
     */
    public static DALArgs makeArg(int position, int type, boolean isOut, boolean isNull, String typeName) throws SQLException {
        switch (type) {
            // supported types...
            case java.sql.Types.LONGVARCHAR:
                return new CharStreamArg(position, isOut, isNull, null, 0);
            case java.sql.Types.VARCHAR:
                return new StringArg(position, isOut, isNull, null);
            case java.sql.Types.BOOLEAN:
            case java.sql.Types.BIT:
                return new BooleanArg(position, isOut, isNull);
            case java.sql.Types.TIMESTAMP:
                return new TimestampArg(position, isOut, isNull, 0);
            case java.sql.Types.TIME:
                return new TimeArg(position, isOut, isNull, 0);
            case java.sql.Types.DATE:
                return new DateArg(position, isOut, isNull, 0);
            case java.sql.Types.BIGINT:
                return new LongArg(position, isOut, isNull, 0);
            case java.sql.Types.INTEGER:
                return new IntArg(position, isOut, isNull, 0);
            case java.sql.Types.SMALLINT:
                return new ShortArg(position, isOut, isNull, (short) 0);
            case java.sql.Types.TINYINT:
                return new ByteArg(position, isOut, isNull);
            case java.sql.Types.DOUBLE:
                return new DoubleArg(position, isOut, isNull, 0.0);
            case java.sql.Types.REAL:
            case java.sql.Types.FLOAT:
                return new FloatArg(position, isOut, isNull, 0);
            case java.sql.Types.DECIMAL:
            case java.sql.Types.NUMERIC:
                return new DoubleArg(position, isOut, isNull, 0);
            case java.sql.Types.CHAR:
                return new StringArg(position, isOut, isNull, null);
            case java.sql.Types.CLOB:
                return new ClobArg(position, isOut, isNull, null);
            case java.sql.Types.BLOB:
                return new BlobArg(position, isOut, isNull, null);
            case java.sql.Types.JAVA_OBJECT:
                return new ObjectArg(position, isOut, isNull, null);
            case java.sql.Types.LONGVARBINARY:
                return new BinaryStreamArg(position, isOut, isNull, null, 0);
            case java.sql.Types.ARRAY:
                return new ArrayArg(position, isOut, isNull, null, typeName);
            case DALTypes.ORACLE_CURSOR:
                return new DALCursor(position, type);
            case java.sql.Types.VARBINARY:
            case java.sql.Types.BINARY:
                return new ByteArrayArg(position, isOut, isNull, null);

                // unsupported as yet...
            case java.sql.Types.OTHER:
            default:
                throw new SQLException("Unsupported type " + position + ":" + type);
        }
    }
/*******************************************************************************/
    /**
     * @param type
     * @return
     * @throws SQLException
     */
    public static String getTypeName(int type) throws SQLException {
        switch (type) {
            // supported types...
            case java.sql.Types.LONGVARCHAR:
                return "java.sql.Types.LONGVARCHAR";
            case java.sql.Types.VARCHAR:
                return "java.sql.Types.VARCHAR";
            case java.sql.Types.BOOLEAN:
                return "java.sql.Types.BOOLEAN";
            case java.sql.Types.BIT:
                return "java.sql.Types.BIT";
            case java.sql.Types.TIMESTAMP:
                return "java.sql.Types.TIMESTAMP";
            case java.sql.Types.TIME:
                return "java.sql.Types.TIME";
            case java.sql.Types.DATE:
                return "java.sql.Types.DATE";
            case java.sql.Types.BIGINT:
                return "java.sql.Types.BIGINT";
            case java.sql.Types.SMALLINT:
                return "java.sql.Types.SMALLINT";
            case java.sql.Types.TINYINT:
                return "java.sql.Types.TINYINT";
            case java.sql.Types.NUMERIC:
                return "java.sql.Types.NUMERIC";
            case java.sql.Types.DECIMAL:
                return "java.sql.Types.DECIMAL";
            case java.sql.Types.DOUBLE:
                return "java.sql.Types.DOUBLE";
            case java.sql.Types.REAL:
                return "java.sql.Types.REAL";
            case java.sql.Types.FLOAT:
                return "java.sql.Types.FLOAT";
            case java.sql.Types.INTEGER:
                return "java.sql.Types.INTEGER";
            case java.sql.Types.CHAR:
                return "java.sql.Types.CHAR";
            case java.sql.Types.CLOB:
                return "java.sql.Types.CLOB";
            case java.sql.Types.BLOB:
                return "java.sql.Types.BLOB";
            case java.sql.Types.JAVA_OBJECT:
                return "java.sql.Types.JAVA_OBJECT";
            case java.sql.Types.LONGVARBINARY:
                return "java.sql.Types.LONGVARBINARY";
            case java.sql.Types.ARRAY:
                return "java.sql.Types.ARRAY";
            case DALTypes.ORACLE_CURSOR:
                return "oracle.jdbc.OracleTypes.CURSOR";
            case java.sql.Types.VARBINARY:
                return "java.sql.Types.VARBINARY";
            case java.sql.Types.BINARY:
                return "java.sql.Types.BINARY";
            case java.sql.Types.REF:
                return "java.sql.Types.REF";
                // unsupported as yet...
            case java.sql.Types.OTHER:
            default:
                throw new SQLException("Unsupported type " + ":" + type);
        }
    }

    /**
     * @param message
     * @return
     */
    public static final SQLException sqlException(String message) {
        return new SQLException(message);
    }

    /**
     * @param clob
     * @return
     * @throws SQLException
     */
    public static char[] readClob(Clob clob) throws SQLException {
        if (clob == null) {
            return EMPTY_CHAR_ARRAY;
        } else if (clob instanceof DALClob) {
            return ((DALClob) clob).getData();
        }

        StringBuffer sb = new StringBuffer();
        try {
            int len = 0;
            Reader reader = clob.getCharacterStream();
            char carray[] = new char[Constants.BUFFER_SIZE];
            while ((len = reader.read(carray)) != -1) {
                sb.append(carray, 0, len);
            }
            reader.close();
        } catch (Exception exp) {
            exp.printStackTrace();
            throw new SQLException(exp);
        }
        return sb.toString().toCharArray();
    }

    /**
     * @param blob
     * @return
     * @throws SQLException
     */
    public static byte[] readBlob(Blob blob) throws SQLException {
        if (blob == null) {
            return EMPTY_BYTE_ARRAY;
        } else if (blob instanceof DALBlob) {
            return ((DALBlob) blob).getData();
        }

        byte barray[] = new byte[Constants.BUFFER_SIZE];
        try {
            int len = 0;
            BufferedInputStream bis = new BufferedInputStream(blob.getBinaryStream());
            ByteArrayOutputStream bos = new ByteArrayOutputStream(Constants.BUFFER_SIZE);
            while ((len = bis.read(barray)) != -1) {
                bos.write(barray, 0, len);
            }
            barray = bos.toByteArray();
            bos.close();
            bis.close();
        } catch (Exception exp) {
            exp.printStackTrace();
            throw new SQLException(exp);
        }
        return barray;
    }

    /**
     * @param dbmd
     * @return
     * @throws SQLException
     */
    public static Map<String, Serializable> getDatabaseMetaDataMethodAttribute(DatabaseMetaData dbmd) throws SQLException {
        Map<String, Serializable> map = new HashMap<String, Serializable>();
        if (dbmd == null) return map;

        try {
            Method[] marray = dbmd.getClass().getMethods();
            for (Method methodName : marray) {
                Class parametertype[] = methodName.getParameterTypes();
                String returnType = methodName.getReturnType().toString();

                if (parametertype.length == 0 && Modifier.toString(methodName.getModifiers()).contains("public") && (returnType.equals("int") || returnType.contains("java.lang.String") || returnType.contains("boolean"))) {
                    // || returnType.contains("ResultSet")  ) ) {
                    try {
                        Object retValue = methodName.invoke(dbmd, new Object[0]);

                        if (returnType.contains("ResultSet") && retValue != null && retValue instanceof ResultSet) {
                            ResultSet resultSet = (ResultSet) retValue;
                            resultSet.setFetchSize(Integer.MAX_VALUE - 1);
                            DALArgs arg = DALUtil.getResultSetCursor(null, resultSet, 1, resultSet.getType());
                            resultSet.close();
                            map.put(methodName.getName(), arg);
                        } else if (retValue != null) {
                            map.put(methodName.getName(), (Serializable) retValue);
                        }
                    } catch (Exception exp) {
                        exp.printStackTrace();
                    }
                }
            }
        } catch (Exception exp) {
            exp.printStackTrace();
        }
        return map;
    }

    /**
     * This method can be used to convert composite objects into their (Serializable)
     * DAL representations. It is meant primarily to convert from vendor/native format
     * to DAL format, but can also be used to convert caller specific format (e.g.
     * SQLData) into DAL format.
     *
     * @param obj - the object to be converted
     * @return a suitable "converted" object
     * @throws SQLException - in case of any errors
     */
    public static Object convertToDALObject(Object obj) throws SQLException {
        Object ret = obj;
        if (obj == null) {
            ret = obj;
        } else if (obj instanceof Array) {
            ret = convertToDALArray((Array) obj);
        } else if (obj instanceof Struct) {
            ret = convertToDALStruct((Struct) obj);
        } else if (obj instanceof SQLData) {
            ret = convertToDALStruct((SQLData) obj);
        } else if (obj instanceof Clob) {
            ret = convertToDALClob((Clob) obj);
        } else if (obj instanceof Blob) {
            ret = convertToDALBlob((Blob) obj);
        }
        return ret;
    }

    private static Array convertToDALArray(Array array) throws SQLException {
        if (array == null) {
            return null;
        }

        int baseType = array.getBaseType();
        String baseTypeName = array.getBaseTypeName();
        Object[] elements = (Object[]) array.getArray();

        int length = (elements != null) ? elements.length : 0;
        Object[] converted = new Object[length];
        for (int i = 0; i < length; i++) {
            converted[i] = DALUtil.convertToDALObject(elements[i]);
        }

        Array ret = array;
        if (array instanceof DALArray) {
            ((DALArray) array).setArray(converted);
        } else if (array instanceof ARRAY) {
            ARRAY oraArray = (ARRAY) array;
            DALArrayDescriptor desc = DALArrayDescriptor.createDescriptor(oraArray.getDescriptor().getName(), null);
            ret = new DALArray(desc, baseType, baseTypeName, converted);
        } else {
            DALArrayDescriptor desc = DALArrayDescriptor.createDescriptor(null, null);
            ret = new DALArray(desc, baseType, baseTypeName, converted);
        }
        return ret;
    }

    private static Struct convertToDALStruct(Struct struct) throws SQLException {
        if (struct == null) {
            return null;
        }

        String sqlTypeName = struct.getSQLTypeName();
        Object[] attributes = struct.getAttributes();

        int length = (attributes != null) ? attributes.length : 0;
        Object[] converted = new Object[length];
        for (int i = 0; i < length; i++) {
            converted[i] = DALUtil.convertToDALObject(attributes[i]);
        }

        Struct ret = struct;
        if (struct instanceof DALStruct) {
            ((DALStruct) struct).setAttributes(converted);
        } else {
            ret = new DALStruct(null, sqlTypeName, converted);
        }
        return ret;
    }

    private static DALStruct convertToDALStruct(SQLData sqlData) throws SQLException {
        if (sqlData == null) {
            return null;
        }

        String sqlTypeName = sqlData.getSQLTypeName();
        DALSQLOutput stream = new DALSQLOutput();
        sqlData.writeSQL(stream);
        Object[] attributes = stream.getAttributes();

        int length = (attributes != null) ? attributes.length : 0;
        Object[] converted = new Object[length];
        for (int i = 0; i < length; i++) {
            converted[i] = DALUtil.convertToDALObject(attributes[i]);
        }
        return new DALStruct(null, sqlTypeName, converted);
    }

    private static DALClob convertToDALClob(Clob clob) throws SQLException {
        if (clob == null || clob instanceof DALClob) {
            return (DALClob) clob;
        }

        char[] chars = DALUtil.readClob(clob);
        return new DALClob(chars);
    }

    private static DALBlob convertToDALBlob(Blob blob) throws SQLException {
        if (blob == null || blob instanceof DALBlob) {
            return (DALBlob) blob;
        }

        byte[] bytes = DALUtil.readBlob(blob);
        return new DALBlob(bytes);
    }


    /**
     * This method can be used to convert composite objects into their (native)
     * ORA representations. It will be invoked just before setting the input "args"
     * on a prepared/callable statement.
     *
     * @param obj - the object to be converted
     * @return a suitable "converted" object
     * @throws SQLException - in case of any errors
     */
    public static Object convertToORAObject(Object obj, Connection conn) throws SQLException {
        Object ret = obj;
        if (obj == null) {
           ret = obj; 
        } else if (obj instanceof Array) {
            ret = convertToORAArray((Array) obj, conn);
        } else if (obj instanceof Struct) {
            ret = convertToORAStruct((Struct) obj, conn);
        } else if (obj instanceof Clob) {
            ret = convertToORAClob((Clob) obj, conn);
        } else if (obj instanceof Blob) {
            ret = convertToORABlob((Blob) obj, conn);
        }
        return ret;
    }

    private static ARRAY convertToORAArray(Array array, Connection conn) throws SQLException {
        if (array == null || array instanceof ARRAY) {
            return (ARRAY) array;
        } else if (conn == null || !conn.isWrapperFor(OracleConnection.class)) {
            throw new SQLException("Cannot create an Oracle ARRAY without an OracleConnection: " + conn);
        } else if (!(array instanceof DALArray)) {
            throw new SQLException("Cannot create an Oracle ARRAY from an arbitrary Array object: " + array);
        } else if (((DALArray)array).getArrayDescriptor() == null) {
            throw new SQLException("Cannot create an Oracle ARRAY without an DALArrayDescriptor");
        }

        int baseType = array.getBaseType();
        String baseTypeName = array.getBaseTypeName();
        Object[] elements = (Object[]) array.getArray();

        int length = (elements != null) ? elements.length : 0;
        Object[] converted = new Object[length];
        for (int i = 0; i < length; i++) {
            converted[i] = DALUtil.convertToORAObject(elements[i], conn);
        }

        String arrayType = ((DALArray)array).getArrayDescriptor().getDescriptorName();
        DALArrayDescriptor desc = DALArrayDescriptor.createDescriptor(arrayType, conn);
        return (ARRAY) DALFactory.newArray(desc, baseType, baseTypeName, converted);
    }

    private static STRUCT convertToORAStruct(Struct struct, Connection conn) throws SQLException {
        if (struct == null || struct instanceof STRUCT) {
            return (STRUCT) struct;
        } else if (conn == null || !conn.isWrapperFor(OracleConnection.class)) {
            throw new SQLException("Cannot create an Oracle STRUCT without an OracleConnection: " + conn);
        }

        String sqlTypeName = struct.getSQLTypeName();
        Object[] attributes = struct.getAttributes();

        int length = (attributes != null) ? attributes.length : 0;
        Object[] converted = new Object[length];
        for (int i = 0; i < length; i++) {
            converted[i] = DALUtil.convertToORAObject(attributes[i], conn);
        }

        DALStructDescriptor desc = DALStructDescriptor.createDescriptor(sqlTypeName, conn);
        Struct struct1 = DALFactory.newStruct(desc, sqlTypeName, converted);
        return (STRUCT) struct1;
    }

    private static CLOB convertToORAClob(Clob clob, Connection conn) throws SQLException {
        if (clob == null || clob instanceof CLOB) {
            return (CLOB) clob;
        } else if (conn == null || !conn.isWrapperFor(OracleConnection.class)) {
            throw new SQLException("Cannot create an Oracle CLOB without an OracleConnection: " + conn);
        }

        char[] chars = DALUtil.readClob(clob);
        return (CLOB) DALFactory.newClob(conn, chars);
    }

    private static BLOB convertToORABlob(Blob blob, Connection conn) throws SQLException {
        if (blob == null || blob instanceof BLOB) {
            return (BLOB) blob;
        } else if (conn == null || !conn.isWrapperFor(OracleConnection.class)) {
            throw new SQLException("Cannot create an Oracle BLOB without an OracleConnection: " + conn);
        }

        byte[] bytes = DALUtil.readBlob(blob);
        return (BLOB) DALFactory.newBlob(conn, bytes);
    }


    /**
     * This method should be called by all getObject() methods in the DAL client codebase.
     * The method make sure that all Structs are converted into corresponding SQLData
     * objects - as per the input TypeMap. If the input object is a Struct, the method
     * can return a Struct or a SQLData object. If the input object is an Array, the method
     * will always return an Array. In all cases, the method will ensure that the nested
     * objects have been appropriately processed.
     * <p/>
     * Please note that for Arrays and Structs, this method creates (and returns) new objects
     * - without modifying the input objects whatsoever.
     *
     * @param obj     - the root object
     * @param typeMap - the input TypeMap - typically part of the caller method's parameter list,
     *                or defaulted to the connection's TypeMap
     * @return the "converted" root object
     * @throws SQLException - in case of any errors
     */
    public static Object processGetObject(Object obj, Map<String, Class<?>> typeMap) throws SQLException {
        Object ret = obj;
        if (obj == null || typeMap == null || typeMap.isEmpty()) {
           ret = obj; 
        } else if (obj instanceof DALStruct) {
            ret = processGetObjectOnStruct((DALStruct) obj, typeMap);
        } else if (obj instanceof DALArray) {
            ret = processGetObjectOnArray((DALArray) obj, typeMap);
        }
        return ret;
    }

    private static Object processGetObjectOnStruct(DALStruct struct, Map<String, Class<?>> typeMap) throws SQLException {
        if (struct == null || typeMap == null || typeMap.isEmpty()) return struct;

        DALStructDescriptor desc = struct.getStructDescriptor();
        String typeName = struct.getSQLTypeName();
        Object[] attributes = struct.getAttributes(typeMap);

        Object ret;
        Class<?> clazz = typeMap.get(typeName);
        if (clazz != null && SQLData.class.isAssignableFrom(clazz)) {
            try {
                SQLData sqlData = (SQLData) clazz.newInstance();
                SQLInput sqlInput = new DALSQLInput(attributes);
                sqlData.readSQL(sqlInput, typeName);
                ret = sqlData;
            } catch (InstantiationException e) {
                e.printStackTrace();
                throw new SQLException(e);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
                throw new SQLException(e);
            }
        } else {
            ret = new DALStruct(desc, typeName, attributes);
        }
        return ret;
    }

    private static Object processGetObjectOnArray(DALArray array, Map<String, Class<?>> typeMap) throws SQLException {
        if (array == null || typeMap == null || typeMap.isEmpty()) return array;

        DALArrayDescriptor desc = array.getArrayDescriptor();
        int baseType = array.getBaseType();
        String baseTypeName = array.getBaseTypeName();
        Object[] elements = (Object[]) array.getArray(typeMap);
        return new DALArray(desc, baseType, baseTypeName, elements);
    }


    /**
     * This method is only meant to associate the Struct/Array (and nested elements) with the
     * valid descriptor - pointing to the current connection. Note: this does an in-place
     * replacement of objects (and their nested values).
     *
     * @param obj  - the object that needs to be associated with a descriptor
     * @param conn - the current connection object
     * @throws SQLException - in case of any errors
     */
    public static void ensureDescriptor(Object obj, Connection conn) throws SQLException {
        if (obj == null || conn == null) {
            obj = null;
        } else if (obj instanceof DALStruct) {
            ensureDescriptorOnStruct((DALStruct) obj, conn);
        } else if (obj instanceof DALArray) {
            ensureDescriptorOnArray((DALArray) obj, conn);
        }
    }

    private static void ensureDescriptorOnStruct(DALStruct struct, Connection conn) throws SQLException {
        if (struct == null || conn == null) return;

        DALStructDescriptor desc = struct.getStructDescriptor();
        if (desc == null || desc.getConnection() == null) {
            if (desc == null) desc = DALStructDescriptor.createDescriptor(struct.getSQLTypeName(), conn);
            struct.setStructDescriptor(desc);

            // pass in a null typeMap to suppress any type conversion at this point
            Object[] attributes = struct.getAttributes(null);
            int length = (attributes != null) ? attributes.length : 0;
            for (int i = 0; i < length; i++) {
                ensureDescriptor(attributes[i], conn);
            }
            struct.setAttributes(attributes);
        }
    }

    private static void ensureDescriptorOnArray(DALArray array, Connection conn) throws SQLException {
        if (array == null || conn == null) return;

        DALArrayDescriptor desc = array.getArrayDescriptor();
        if (desc == null || desc.getConnection() == null) {
            if (desc == null) desc = DALArrayDescriptor.createDescriptor(null, conn);
            array.setArrayDescriptor(desc);

            // pass in a null typeMap to suppress any type conversion at this point
            Object[] elements = (Object[]) array.getArray(null);
            int length = (elements != null) ? elements.length : 0;
            for (int i = 0; i < length; i++) {
                DALUtil.ensureDescriptor(elements[i], conn);
            }
            array.setArray(elements);
        }
    }

}
