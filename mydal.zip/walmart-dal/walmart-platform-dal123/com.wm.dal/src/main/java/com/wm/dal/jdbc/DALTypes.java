/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc;

import oracle.jdbc.OracleTypes;

/**
 * 
 * @author cshah
 * @version 1.0
 */
public final class DALTypes {
    public static final int ORACLE_ARRAY = OracleTypes.ARRAY;
    public static final int ORACLE_CURSOR = OracleTypes.CURSOR;
    //public static final int ORACLE_REF = OracleTypes.REF;
    //public static final int ORACLE_ROWID = OracleTypes.ROWID;
    public static final int ORACLE_BIGINT = OracleTypes.BIGINT;
    public static final int ORACLE_NUMBER = OracleTypes.NUMBER;
    public static final int ORACLE_TIMESTAMP = OracleTypes.TIMESTAMP;
    public static final int ORACLE_INTEGER = OracleTypes.INTEGER;
    public static final int ORACLE_VARCHAR = OracleTypes.VARCHAR;
    public static final int ORACLE_DATE = OracleTypes.DATE;
    public static final int ORACLE_BLOB = OracleTypes.BLOB;
    public static final int ORACLE_CLOB = OracleTypes.CLOB;
}
