package com.wm.dal.client;

import java.io.Serializable;

import javax.transaction.xa.Xid;

public class DALXid implements Xid, Serializable {
  private final int m_formatId;
  private final byte[] m_globalTransactionId;
  private final byte[] m_branchQualifier;

  public DALXid(Xid xid) {
    m_formatId = xid.getFormatId();

    byte[] gtx = xid.getGlobalTransactionId();
    byte[] bql = xid.getBranchQualifier();

    if (gtx != null)
      System.arraycopy(gtx, 0, m_globalTransactionId = new byte[gtx.length], 0, gtx.length);
    else
      m_globalTransactionId = null;
    
    if (bql != null)
      System.arraycopy(bql, 0, m_branchQualifier = new byte[bql.length], 0, bql.length);
    else
      m_branchQualifier = null;
  }

  @Override
  public int getFormatId() {
    return m_formatId;
  }

  @Override
  public byte[] getGlobalTransactionId() {
    return m_globalTransactionId;
  }

  @Override
  public byte[] getBranchQualifier() {
    return m_branchQualifier;
  }
}
