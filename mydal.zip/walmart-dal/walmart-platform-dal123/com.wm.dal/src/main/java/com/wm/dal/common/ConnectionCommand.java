/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 */

package com.wm.dal.common;

import com.wm.dal.client.DALResponse;
import com.wm.dal.client.IDALRequest;
import com.wm.dal.client.IDALResponse;
import com.wm.dal.jdbc.args.DALArgs;
import com.wm.dal.jdbc.utils.Constants;
import com.wm.dal.jdbc.utils.DALUtil;
import com.wm.dal.jdbc.utils.MethodAttribute;
import com.wm.dal.util.DALLogger;

import com.wm.dal.util.ServerUtil;

import java.io.Serializable;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.Map;


/**
 * 
 */
public class ConnectionCommand implements ICommand {
    private ConnectionDelegate delegate = null;
    static final DALLogger logger = DALLogger.getInstance();
    
    /**
     * 
     * @param delegate
     */
    public ConnectionCommand(ConnectionDelegate delegate) {
        this.delegate = delegate;
    }

    /**
     * 
     * @param request
     * @return
     * @throws SQLException
     */
    public IDALResponse execute(IDALRequest request) throws SQLException {
        IDALResponse response = new DALResponse();
        int command = request.getCommand();
        switch (command) {
            case Constants.DATABASE_METADATA : {
                try {
                    logger.info("Database metadata Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    MethodAttribute poolName = request.getSession().getConnecitonAttribute(MethodAttribute.DATABASE_METADATA);
                    if (poolName != null && poolName.getAttribute() != null) {
                        String sPoolName = poolName.getAttribute().toString();
                        logger.info("Getting Database metatdata for pool " + sPoolName);
                        Connection conn = delegate.getConnectionMap().get(sPoolName);
                        if (conn != null) {
                            DatabaseMetaData dbmd = conn.getMetaData();
                            Map map = DALUtil.getDatabaseMetaDataMethodAttribute(dbmd);
                            response.getConnectionResponse().set(Constants.RESPONSE,(Serializable)map);
                        }
                    } else {
                        //get default pool
                        Connection conn = delegate.getDefaultConnection(request);
                        DatabaseMetaData dbmd = conn.getMetaData();
                        Map map = DALUtil.getDatabaseMetaDataMethodAttribute(dbmd);
                        response.getConnectionResponse().set(Constants.RESPONSE,(Serializable)map);
                    }
                } catch (Exception e) {
                    response.setException(e);
                    e.printStackTrace();
                }
                break;
            }
            case Constants.GET_PROCEDURES : {
                try {
                    MethodAttribute catalog = request.getSession().getConnecitonAttribute(MethodAttribute.CATALOG);
                    MethodAttribute schemapattern = request.getSession().getConnecitonAttribute(MethodAttribute.SCHEMA_PATTERN);
                    MethodAttribute procedurenamepattern = request.getSession().getConnecitonAttribute(MethodAttribute.PROCEDURE_NAME_PATTERN);
                    
                    logger.info("Database metadata,get Procedure Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    MethodAttribute poolName = request.getSession().getConnecitonAttribute(MethodAttribute.DATABASE_METADATA);
                    DatabaseMetaData dbmd = null;
                    if (poolName != null) {
                        String sPoolName = poolName.getAttribute().toString();
                        logger.info("Getting Database metatdata for pool " + sPoolName);
                        Connection conn = delegate.getConnectionMap().get(sPoolName);
                        if (conn != null ) {
                            dbmd = conn.getMetaData();
                        }
                    } else {
                        //get default pool
                        Connection conn = delegate.getDefaultConnection(request);
                        dbmd = conn.getMetaData();
                    }
                    if (dbmd != null) {
                        ResultSet resultSet = dbmd.getProcedures(catalog.getAttribute().toString(),schemapattern.getAttribute().toString(), procedurenamepattern.getAttribute().toString());
                        try { 
                        	resultSet.setFetchSize(Integer.MAX_VALUE-1);
                        	DALArgs arg = DALUtil.getResultSetCursor(null,resultSet, 1, resultSet.getType(), Integer.MAX_VALUE-1);
                        	response.getConnectionResponse().set(Constants.RESPONSE,arg);
                        } finally {
                      	  if (resultSet != null)
                      		  resultSet.close();
                        }
                    }
                } catch (Exception e) {
                    response.setException(e);
                    e.printStackTrace();
                }
                break;
            }
            case Constants.GET_PROCEDURES_COLUMNS : {
                try {
                    MethodAttribute catalog = request.getSession().getConnecitonAttribute(MethodAttribute.CATALOG);
                    MethodAttribute schemapattern = request.getSession().getConnecitonAttribute(MethodAttribute.SCHEMA_PATTERN);
                    MethodAttribute procedurenamepattern = request.getSession().getConnecitonAttribute(MethodAttribute.PROCEDURE_NAME_PATTERN);
                    MethodAttribute columnnamepattern = request.getSession().getConnecitonAttribute(MethodAttribute.COLUMN_NAME_PATTERN);
                    
                    logger.info("Database metadata,get Procedure columns Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    MethodAttribute poolName = request.getSession().getConnecitonAttribute(MethodAttribute.DATABASE_METADATA);
                    DatabaseMetaData dbmd = null;
                    if (poolName != null) {
                        String sPoolName = poolName.getAttribute().toString();
                        logger.info("Getting Database metatdata for pool " + sPoolName);
                        Connection conn = delegate.getConnectionMap().get(sPoolName);
                        if (conn != null) {
                            dbmd = conn.getMetaData();
                        }
                    } else {
                        //get default pool
                        Connection conn = delegate.getDefaultConnection(request);
                        dbmd = conn.getMetaData();
                    }
                    if (dbmd != null) {
                        ResultSet resultSet = dbmd.getProcedureColumns(catalog.getAttribute().toString(),schemapattern.getAttribute().toString(), 
                                    procedurenamepattern.getAttribute().toString(),columnnamepattern.getAttribute().toString() );
                        try {
                        	resultSet.setFetchSize(Integer.MAX_VALUE-1);
                        	DALArgs arg = DALUtil.getResultSetCursor(null,resultSet, 1, resultSet.getType(), Integer.MAX_VALUE-1);
                        	response.getConnectionResponse().set(Constants.RESPONSE,arg); 
                        } finally {
                        	if (resultSet != null)
                        		resultSet.close();
                        }
                    }
                } catch (Exception e) {
                    response.setException(e);
                    e.printStackTrace();
                }
                break;
            }
            
            case Constants.GET_COLUMNS : {
              try {
                  MethodAttribute catalog = request.getSession().getConnecitonAttribute(MethodAttribute.CATALOG);
                  MethodAttribute schemapattern = request.getSession().getConnecitonAttribute(MethodAttribute.SCHEMA_PATTERN);
                  MethodAttribute tablenamepattern = request.getSession().getConnecitonAttribute(MethodAttribute.TABLE_NAME_PATTERN);
                  MethodAttribute columnnamepattern = request.getSession().getConnecitonAttribute(MethodAttribute.COLUMN_NAME_PATTERN);
                  
                  logger.info("Database metadata,get Tab;le columns Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                  MethodAttribute poolName = request.getSession().getConnecitonAttribute(MethodAttribute.DATABASE_METADATA);
                  DatabaseMetaData dbmd = null;
                  if (poolName != null) {
                      String sPoolName = poolName.getAttribute().toString();
                      logger.info("Getting Database metatdata for pool " + sPoolName);
                      Connection conn = delegate.getConnectionMap().get(sPoolName);
                      if (conn != null) {
                          dbmd = conn.getMetaData();
                      }
                  } else {
                      //get default pool
                      Connection conn = delegate.getDefaultConnection(request);
                      dbmd = conn.getMetaData();
                  }
                  if (dbmd != null) {
                      ResultSet resultSet = dbmd.getColumns(catalog == null ? null : catalog.getAttribute().toString(),schemapattern == null ? null : schemapattern.getAttribute().toString(), 
                          tablenamepattern.getAttribute().toString(), columnnamepattern == null ? null : columnnamepattern.getAttribute().toString() );
                      try {
                    	  resultSet.setFetchSize(Integer.MAX_VALUE-1);
                    	  DALArgs arg = DALUtil.getResultSetCursor(null,resultSet, 1, resultSet.getType(), Integer.MAX_VALUE-1);
                    	  response.getConnectionResponse().set(Constants.RESPONSE,arg); 
                      } finally {
                    	  if (resultSet != null)
                    		  resultSet.close();
                      }
                  }
              } catch (Exception e) {
                  response.setException(e);
                  e.printStackTrace();
              }
              break;
          }

            case Constants.GET_PRIMARY_KEYS : {
              try {
                  MethodAttribute catalog = request.getSession().getConnecitonAttribute(MethodAttribute.CATALOG);
                  MethodAttribute schema = request.getSession().getConnecitonAttribute(MethodAttribute.SCHEMA_NAME);
                  MethodAttribute tablename = request.getSession().getConnecitonAttribute(MethodAttribute.TABLE_NAME);
                  
                  logger.info("Database metadata,get Primary Keys Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                  MethodAttribute poolName = request.getSession().getConnecitonAttribute(MethodAttribute.DATABASE_METADATA);
                  DatabaseMetaData dbmd = null;
                  if (poolName != null) {
                      String sPoolName = poolName.getAttribute().toString();
                      logger.info("Getting Database metatdata for pool " + sPoolName);
                      Connection conn = delegate.getConnectionMap().get(sPoolName);
                      if (conn != null) {
                          dbmd = conn.getMetaData();
                      }
                  } else {
                      //get default pool
                      Connection conn = delegate.getDefaultConnection(request);
                      dbmd = conn.getMetaData();
                  }
                  if (dbmd != null) {
                      ResultSet resultSet = dbmd.getPrimaryKeys(catalog == null ? null : catalog.getAttribute().toString(),schema == null ? null : schema.getAttribute().toString(), 
                          tablename.getAttribute().toString() );
                      try {
                    	  resultSet.setFetchSize(Integer.MAX_VALUE-1);
                    	  DALArgs arg = DALUtil.getResultSetCursor(null,resultSet, 1, resultSet.getType(), Integer.MAX_VALUE-1);
                    	  response.getConnectionResponse().set(Constants.RESPONSE,arg); 
                      } finally {
                    	  if (resultSet != null)
                    		  resultSet.close();
                      }
                  }
              } catch (Exception e) {
                  response.setException(e);
                  e.printStackTrace();
              }
              break;
          }
            case Constants.SUPPORTS_RS_TYPE : {
                try {
                    MethodAttribute rsType = request.getSession().getConnecitonAttribute(MethodAttribute.RS_TYPE);
                    logger.info("Database metadata,get Procedure columns Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    MethodAttribute poolName = request.getSession().getConnecitonAttribute(MethodAttribute.DATABASE_METADATA);
                    DatabaseMetaData dbmd = null;
                    if (poolName != null) {
                        String sPoolName = poolName.getAttribute().toString();
                        logger.info("Getting Database metatdata for pool " + sPoolName);
                        Connection conn = delegate.getConnectionMap().get(sPoolName);
                        if (conn != null ) {
                            dbmd = conn.getMetaData();
                        }
                    } else {
                        //get default pool
                        Connection conn = delegate.getDefaultConnection(request);
                        dbmd = conn.getMetaData();
                    }
                    if (dbmd != null) {
                        boolean returnValue = dbmd.supportsResultSetType( ((Integer)rsType.getAttribute()).intValue());
                        response.getConnectionResponse().set(Constants.RESPONSE,(Serializable)Boolean.valueOf(returnValue)); 
                    }
                } catch (Exception e) {
                    response.setException(e);
                    e.printStackTrace();
                }
                break;
            }
            case Constants.CLEAR_WARNINGS : {
                try {
                    logger.info("Connection clear warnings Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    logger.info("Clear All Warning for Connection ");
                    delegate.clearALLWarningForConnections();
                } catch (SQLException sqle) {
                    response.setException(sqle);
                    sqle.printStackTrace();
                } catch (Exception e) {
                    response.setException(e);
                    e.printStackTrace();
                }
                break;                
            }
            case Constants.CLOSE_CONNECTION : {
                try {
                    logger.info("Connection Closing connection Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    delegate.closeAll();
                    response.getConnectionResponse().set(Constants.STATUS, Integer.valueOf(1));
                    } catch (SQLException sqle) {
                        response.setException(sqle);
                        sqle.printStackTrace();
                    } catch (Exception e) {
                        response.setException(e);
                        e.printStackTrace();
                    }
                break;
            }
            case Constants.COMMIT : {
                try {
                        logger.info("Connection commit Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                        delegate.commitORrollbackAllConnections(true);
                    } catch (SQLException sqle) {
                        response.setException(sqle);
                        sqle.printStackTrace();
                    } catch (Exception e) {
                        response.setException(e);
                        e.printStackTrace();
                    }
                break;                    
            }
            case Constants.ROLLBACK : {
                try {
                        logger.info("Connection rollback Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                        delegate.commitORrollbackAllConnections(false);
                    } catch (SQLException sqle) {
                        response.setException(sqle);
                        sqle.printStackTrace();
                    } catch (Exception e) {
                        response.setException(e);
                        e.printStackTrace();
                    }
                break;                    
            }
            case Constants.RESET_CONNECTION : {
                try {
                    logger.info("Connection Reset Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    delegate.closeAll();
                    } catch (SQLException sqle) {
                        response.setException(sqle);
                        sqle.printStackTrace();
                    } catch (Exception e) {
                        response.setException(e);
                        e.printStackTrace();
                    }
                break;
            }
            case Constants.PING_CONNECTION : {
                try {
                    logger.info("Connection ping Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    if (ServerUtil.isGracefulShutdown()) {
                        response.getConnectionResponse().set(Constants.STATUS,Integer.valueOf(-1));
                    } else {
                        response.getConnectionResponse().set(Constants.STATUS,Integer.valueOf(1));
                    }
                    } catch (Exception e) {
                        response.setException(e);
                        response.getConnectionResponse().set(Constants.STATUS,Integer.valueOf(-1));
                        e.printStackTrace();
                    }
                break;
            }
            default : {
                response.setException(new UnsupportedOperationException(Constants.UNSUPPORTED_EXCEPTION));
                //throw sqle;
            }
        }
        return response;
    }
}
