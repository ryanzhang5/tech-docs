/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 */

package com.wm.dal.server.netty;

import com.wm.dal.server.AbstractDALServer;
import com.wm.dal.server.ThreadPoolManager;
import com.wm.dal.util.ClientConf;
import com.wm.dal.util.ServerConf;

import java.net.InetSocketAddress;

import org.jboss.netty.bootstrap.ServerBootstrap;
import org.jboss.netty.channel.Channel;
import org.jboss.netty.channel.ChannelFactory;
import org.jboss.netty.channel.socket.nio.NioServerSocketChannelFactory;


/**
 * 
 * @author cshah
 */
public class DALNettyServer extends AbstractDALServer {
    private Channel channel;
    private ChannelFactory factory ;
    /**
     * 
     * @param port
     * @throws Exception
     */
    public DALNettyServer(int port) {
        super(port);
    }

    /**
     * 
     */
    public void run() {
        try {
            factory = new NioServerSocketChannelFactory(
                ThreadPoolManager.getInstance().getJMXThreadPoolExecutor(),
                ThreadPoolManager.getInstance().getWMThreadPoolExecutor()
                //,ServerConf.getMaxIOWorkerThreadCount()
            );

            ServerBootstrap bootstrap = new ServerBootstrap(factory);
            bootstrap.setOption("backlog", ServerConf.getBackLog());
            bootstrap.setOption("reuseAddress", ServerConf.getReuseAddress());
            
            bootstrap.setOption("child.keepAlive", ClientConf.getKeepAlive());
            bootstrap.setOption("child.reuseAddress", ClientConf.getReuseAddress());
            bootstrap.setOption("child.soLinger", ClientConf.getSOLinger());
            bootstrap.setOption("child.tcpNoDelay", ClientConf.getTCPNoDely());

            bootstrap.setPipelineFactory(new DALPipelineFactory());

            channel = bootstrap.bind(new InetSocketAddress(ServerConf.getHostName(), getPort()));
            //channel = bootstrap.bind(new InetSocketAddress(getPort()));

            logger.warning("DAL Netty Server is listening on port : " + getPort());
        } catch (Exception exp) {
            exp.printStackTrace();
            shutdownNow();
        }
    }

    /**
     * 
     */
    public void shutdownNow() {
        try {
            logger.severe(DALNettyServer.class.getName() + "DALNettyServer/shutdownNow(): Shutting down NOW!!!");
            if (channel != null) {
                channel.close();
            }
            //TODO
            //factory.releaseExternalResources();
        } catch (Exception exp) {
            exp.printStackTrace();
        } finally {
            System.currentTimeMillis();
            //System.exit(-1);
        }
    }

    
}
