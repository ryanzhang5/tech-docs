/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.common;

import com.wm.dal.client.DALResponse;
import com.wm.dal.client.ICallerResponse;
import com.wm.dal.client.IDALRequest;
import com.wm.dal.client.IDALResponse;
import com.wm.dal.jdbc.DALBatch;
import com.wm.dal.jdbc.args.DALArgs;
import com.wm.dal.jdbc.utils.Constants;
import com.wm.dal.jdbc.utils.DALUtil;
import com.wm.dal.jdbc.utils.MethodAttribute;
import com.wm.dal.util.DALLogger;

import java.io.Serializable;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * 
 * @author cshah
 * @version 1.0
 */
public class PreparedStatementCommand extends StatementCommand implements ICommand {

    /**
     * 
     * @param delegate
     */
    public PreparedStatementCommand(ConnectionDelegate delegate) {
        super(delegate);
    }

    /**
     * 
     * @param request
     * @return
     * @throws SQLException
     */
    public IDALResponse execute(IDALRequest request) throws SQLException {
        IDALResponse response = new DALResponse();                             
        int command = request.getCommand();
        MethodAttribute paramProp = request.getSession().getStatementAttribute(MethodAttribute.SQL_PARAMETERS);
        List<DALArgs> param = paramProp != null ? (List<DALArgs>)paramProp.getAttribute() : null ;
        ICallerResponse statementResponse = response.getStatementResponse();
        ICallerResponse rsResponse = response.getResultSetResponse();

        switch (command) {
            case Constants.EXECUTE :{
                try {
                    Connection conn = delegate.getConnection(request, response);
                    PreparedStatement stmt = null;
                    logger.info("Creating P/C Statement Execute Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    stmt = (PreparedStatement)createStatement(request, response, conn);
                    
                    boolean retValue = stmt.execute();
                    int updCount = stmt.getUpdateCount();
            
                    statementResponse.set(Constants.STATUS,Boolean.valueOf(retValue));
                    
                    List<DALArgs> retList = new ArrayList<DALArgs>();
                    if (param != null) {
                        for (DALArgs arg : param ) {
                            DALArgs retArg = DALUtil.getStatementOutParameterValue(stmt,arg,delegate);
                            if (retArg != null) 
                                retList.add(retArg);
                        }
                    }
                    if (retValue) {
                        ResultSet resultSet = stmt.getResultSet();
                        readResultSetAndcreateResponse(stmt,resultSet,rsResponse);
                    } else if ( updCount != -1){ //if 
                        statementResponse.set(Constants.RESPONSE,Integer.valueOf(updCount));
                    } 
            
                    if (retList.size() > 0)
                         statementResponse.set(Constants.RESPONSE,(Serializable)retList);
                
                } catch (SQLException sqle) {
                        response.setException(sqle);
                        sqle.printStackTrace();
                } catch (Exception e) {
                        response.setException(e);
                        e.printStackTrace();
                }
                break;
            } //case
            case Constants.EXECUTE_QUERY : {
                try {
                    Connection conn = delegate.getConnection(request, response);
                    PreparedStatement stmt = null;
                    logger.info("Creating P/C Statement Execute Query Session ID: " 
                                            + request.getSession().getSessionID() 
                                            + ", Client ID:" + request.getSession().getClientHost());
                    stmt = (PreparedStatement)createStatement(request, response, conn);
                    
                    ResultSet resultSet = stmt.executeQuery();

                    List<DALArgs> retList = new ArrayList<DALArgs>();
                    if (param != null) {
                        for (DALArgs arg : param ) {
                            DALArgs retArg = DALUtil.getStatementOutParameterValue(stmt,arg,delegate);
                            if (retArg != null) 
                                retList.add(retArg);
                        }
                    }

                    if (retList.size() > 0)
                         statementResponse.set(Constants.RESPONSE,(Serializable)retList);
                    
                    readResultSetAndcreateResponse(stmt,resultSet,rsResponse);
                } catch (SQLException sqle) {
                        response.setException(sqle);
                        sqle.printStackTrace();
                } catch (Exception e) {
                        response.setException(e);
                        e.printStackTrace();
                }
                break;
            }
            case Constants.EXECUTE_BATCH : {
                try {
                    LinkedList<DALBatch> batch = new LinkedList<DALBatch>();
                    MethodAttribute prop = request.getSession().getStatementAttribute(MethodAttribute.BATCH);
                
                    if (prop != null && prop.getAttribute() instanceof LinkedList) {
                        batch = (LinkedList<DALBatch>)prop.getAttribute();
                    }
                
                    Connection conn = delegate.getConnection(request, response);
                    PreparedStatement stmt = null;
                    logger.info("Creating P/C Statement Execute Batch Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    stmt = (PreparedStatement)createStatement(request, response, conn);
                    
                    for (int i=0; i < batch.size(); i++) {
                        List<DALArgs> list = batch.get(i).getArgList();
                        if (list != null && list.size() > 0) {
                            for (DALArgs arg : list) {
                                if (arg.isOutParameter()) 
                                    throw new SQLException("Callable statement batch will not work with OUT parameters");
                                DALUtil.setStmtParameter(conn, stmt,arg);
                            }//for
                        }//for
                        stmt.addBatch();
                    }
                    
                    int[] retValue = new int[0];
                    try {
                        retValue = stmt.executeBatch();
                    } catch (SQLException sqle) {
                        sqle.printStackTrace();
                        response.setException(sqle);
                    }
                    
                    statementResponse.set(Constants.STATUS,retValue);
                    
                } catch (SQLException exp) {
                    response.setException(exp);
                    exp.printStackTrace();
                } catch (Exception e) {
                    response.setException(e);
                    e.printStackTrace();
                }
                break;
            }
            case Constants.CLEAR_PARAMETERS : {
                try {
                    logger.info("Creating P/C Clear parameters Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    int requestID = request.getID();
                    if (delegate.containsStatement(requestID) ){
                        ((PreparedStatement)delegate.getStatement(requestID)).clearParameters();
                    }
                } catch (Exception e) {
                    response.setException(new SQLException(e.getMessage()));
                    e.printStackTrace();
                }
                break;
            }
            case Constants.EXECUTE_UPDATE : {
                try {
                    Connection conn = delegate.getConnection(request, response);
                    PreparedStatement stmt = null;

                    stmt = (PreparedStatement)createStatement(request, response, conn);
                    if (logger.isLoggable(DALLogger.LEVEL_INFO))
                      logger.info("Creating P/C Statement Execute Update Session ID: " + request.getSession().getSessionID() + ", Client ID:" + request.getSession().getClientHost());
                    int retValue = stmt.executeUpdate();
            
                    statementResponse.set(Constants.STATUS,Integer.valueOf(retValue));
                    statementResponse.set(Constants.RESPONSE,Integer.valueOf(retValue));
                } catch (SQLException sqle) {
                        response.setException(sqle);
                    	logger.log(DALLogger.LEVEL_WARNING, "Unexpeted SQLException", sqle);

                } catch (Exception e) {
                        response.setException(e);
                    	logger.log(DALLogger.LEVEL_WARNING, "Unexpeted Exception", e);
                }
                break;
            }
            default :
                response = super.execute(request);
                break;
        }
                      
        return response;
    }//method

}
