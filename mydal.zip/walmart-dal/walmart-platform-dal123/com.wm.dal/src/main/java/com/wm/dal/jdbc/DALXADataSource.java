package com.wm.dal.jdbc;

import java.io.PrintWriter;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.sql.ConnectionEvent;
import javax.sql.ConnectionEventListener;
import javax.sql.StatementEventListener;
import javax.sql.XAConnection;
import javax.sql.XADataSource;
import javax.transaction.xa.XAException;
import javax.transaction.xa.XAResource;
import javax.transaction.xa.Xid;

import com.wm.corelib.config.AppConfig;
import com.wm.dal.client.DALRequest;
import com.wm.dal.client.DALXid;
import com.wm.dal.client.IDALRequest;
import com.wm.dal.client.IDALResponse;
import com.wm.dal.jdbc.utils.Constants;
import com.wm.dal.jdbc.utils.MethodAttribute;
import static com.wm.dal.jdbc.utils.Constants.isValidURL;

public class DALXADataSource implements XADataSource {
  private String m_url;
  private String m_user;
  private String m_password;

  public void setURL(String url) {
    m_url = url;
  }
  
  public void setUser(String user) {
    m_user = user;
  }

  public void setPassword(String password) {
    m_password = password;
  }

  // Jboss 4.0.5...
  public void setuser(String user) {
    m_user = user;
  }

  // Jboss 4.0.5...
  public void setpassword(String password) {
    m_password = password;
  }
  
  @Override
  public PrintWriter getLogWriter() throws SQLException {
    throw new UnsupportedOperationException();
  }

  @Override
  public void setLogWriter(PrintWriter out) throws SQLException {
    throw new UnsupportedOperationException();
  }

  @Override
  public void setLoginTimeout(int seconds) throws SQLException {
    throw new UnsupportedOperationException();
  }

  @Override
  public int getLoginTimeout() throws SQLException {
    throw new UnsupportedOperationException();
  }

  @Override
  public XAConnection getXAConnection() throws SQLException {
    return m_user == null ? new DALXAConnection(m_url) : new DALXAConnection(m_url, m_user, m_password);
  }

  @Override
  public XAConnection getXAConnection(String user, String password)
      throws SQLException {
    return new DALXAConnection(m_url, user, password);
  }
}

class DALXAConnection implements XAConnection, XAResource {
  private static final Logger logger = Logger.getLogger(DALXAConnection.class.getName());
  private static final int CALLER_ID = Constants.XA_RESOURCE;  

  private Connection m_connection;
  private Connection m_connectionProxy;
  private String m_url;
  private Processor m_processor;
  private DALUrl m_dalurl;
  private Xid m_xid;
  private int m_transactionTimeout;
  private List<ConnectionEventListener> m_connectionListeners = new ArrayList<ConnectionEventListener>();
  
  DALXAConnection(String alias) 
        throws SQLException 
  {
    this(alias,
        isValidURL(alias) ? null : AppConfig.getInstance().getProperty("com.wm.sql.dataaccess."+alias+".user"),
        isValidURL(alias) ? null : AppConfig.getInstance().getProperty("com.wm.sql.dataaccess."+alias+".passwd"));
  }
  
  DALXAConnection(String alias, String user, String password)
      throws SQLException 
  {
    if (isValidURL(alias))
      m_url = alias;
    else
      m_url = AppConfig.getInstance().getProperty("com.wm.sql.dataaccess."+alias+".rurl");
    
    m_dalurl = new DALUrl(m_url, Constants.getAliasName(m_url), user, password);
    
    m_processor = new Processor(m_dalurl) {
      protected IDALResponse executeInternal(IDALRequest request) throws SQLException {
        {
          if (request.getXid() == null)
            request.setXid(m_xid);
          try {
            return super.executeInternal(request);
          } finally {
            m_processor.getSession().invalidateXA();
          }
        }
      }};
      m_connection = new DALConnection(m_dalurl, m_processor);
      m_connectionProxy =  (Connection) Proxy.newProxyInstance(getClass().getClassLoader(),
          new Class[]{java.sql.Connection.class},
          new InvocationHandler() {

        @Override
        public Object 
        invoke(Object proxy, Method method,	Object[] args) 
            throws Throwable {
          if (!"close".equals(method.getName()))
            return method.invoke(m_connection, args);
          return null;
        }
      });
  }

  ///////////////////////// XAConnection //////////////////////
  @Override
  public Connection getConnection() throws SQLException {
    return m_connectionProxy;
  }

  @Override
  public void close() throws SQLException {
    m_connection.close();
    m_processor = null;
    ConnectionEvent event = new ConnectionEvent(this);
    for (ConnectionEventListener listener : m_connectionListeners)
      listener.connectionClosed(event);
  }

  //TODO: notify listeners on Exception
  
  @Override
  public void addConnectionEventListener(ConnectionEventListener listener) {
    m_connectionListeners.add(listener);
  }

  @Override
  public void removeConnectionEventListener(ConnectionEventListener listener) {
    m_connectionListeners.remove(listener);
  }

  //@Override
  public void addStatementEventListener(StatementEventListener listener) {
    throw new UnsupportedOperationException();
  }

  //@Override
  public void removeStatementEventListener(StatementEventListener listener) {
    throw new UnsupportedOperationException();
  }

  @Override
  public XAResource getXAResource() throws SQLException {
    return this;
  }

  ///////////////// XAResource //////////////////////////

  @Override
  public void commit(Xid xid, boolean onePhase) throws XAException {
      execute(createDALRequest(onePhase ? Constants.XA_COMMIT_ONEPHASE :  Constants.XA_COMMIT, xid));
  }

  @Override
  public void end(Xid xid, int flags) throws XAException {
    if (logger.isLoggable(Level.INFO))
      logger.info("DALXAResource.end(" + xid + ", " + flags + ")");
    m_xid = null;
  }

  @Override
  public void forget(Xid xid) throws XAException {
      execute(createDALRequest(Constants.XA_FORGET, xid));
  }

  @Override
  public int getTransactionTimeout() throws XAException {
      return m_transactionTimeout;
  }

  @Override
  public boolean isSameRM(XAResource xares) throws XAException {
	  return false;
  }

  @Override
  public int prepare(Xid xid) throws XAException {
      return (Integer) execute(createDALRequest(Constants.XA_PREPARE, xid));
  }

  @Override
  public Xid[] recover(int flag) throws XAException {
	  throw new UnsupportedOperationException();
	  //return (Xid[]) execute(createDALRequest(Constants.XA_RECOVER, null, flag));
  }

  @Override
  public void rollback(Xid xid) throws XAException {
      execute(createDALRequest(Constants.XA_ROLLBACK, xid));
  }

  @Override
  public boolean setTransactionTimeout(int seconds) throws XAException {
      m_transactionTimeout = seconds;
      m_processor.getSession().setXAAttribute(MethodAttribute.XA_TRANSACTION_TIMEOUT, new MethodAttribute(seconds));
      return true;
  }

  @Override
  public void start(Xid xid, int flags) throws XAException {
    if (logger.isLoggable(Level.INFO))
      logger.info("DALXAResource.start(" + xid + ", " + flags + ")");
    m_processor.getSession().setXAAttribute(MethodAttribute.XA_FLAGS, new MethodAttribute(flags));
    m_xid = new DALXid(xid);
  }

  private Object execute(IDALRequest request) throws XAException {
    try {
        return m_processor.execute(request).getResult();
      } catch(SQLException ex) {
        if (XAException.class.isInstance(ex.getCause()))
          throw ((XAException)ex.getCause());
        if (logger.isLoggable(Level.INFO))
          logger.log(Level.INFO, "Server Exception: ", ex);
        throw new XAException(ex.getMessage());
      }
  }
  
  private IDALRequest createDALRequest(int operation, Xid xid) throws XAException {
    IDALRequest request = new DALRequest(operation,CALLER_ID);
    request.setXid(xid == null ? null : new DALXid(xid));
    return request;
  }
}
