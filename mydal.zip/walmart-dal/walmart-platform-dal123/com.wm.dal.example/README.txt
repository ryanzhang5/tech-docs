
To run the DAL XA example from the command line:

0. It is assume that a suitable version of:
   subversion, JDK are installed 

     http://subversion.apache.org/packages.html
     http://www.oracle.com/technetwork/java/javase/downloads/jdk-6u27-download-440405.html

1. Install maven 3.0.3 from http://maven.apache.org/download.html

   curl -O http://www.carfab.com/apachesoftware//maven/binaries/apache-maven-3.0.3-bin.tar.gz
   tar xf apache-maven-3.0.3-bin.tar.gz
   export PATH=${PWD}/apache-maven-3.0.3/bin:${PATH}

2. Check out the example

   svn co svn://172.29.64.24/walmart-platform-dal/trunk/com.wml.dal.example
   cd dal-example

3. Compile, Deploy, Run Example

     mvn 

   Note: This exeuctions does the following:
    - downloads JBoss 5.0.1
    - unpacks JBoss into target/cargo/...
    - starts JBoss
    - starts DAL
    - builds Integration Test Cases
    - Builds, Packages and Deploys a Testable Ear to JBoss
    - Executes Integration Tests
    - Generate Reports into target/failsafe-reports

3.a. To Run with JBoss 4.0.5:
    
   mvn -P!jboss-5.0.1,jboss-4.0.5

4. Inspect the Results:
 
   firefox target/failsafe-reports/index.html 
