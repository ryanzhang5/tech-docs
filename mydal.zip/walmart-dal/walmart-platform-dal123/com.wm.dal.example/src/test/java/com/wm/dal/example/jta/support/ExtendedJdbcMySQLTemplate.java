package com.wm.dal.example.jta.support;

import java.sql.SQLException;

import javax.sql.DataSource;

public class ExtendedJdbcMySQLTemplate extends ExtendedJdbcTemplate implements
		ExtendedJdbcOperations {
	public String m_schemaName;

	public ExtendedJdbcMySQLTemplate(DataSource dataSource) {
		super(dataSource);
	}

	public ExtendedJdbcMySQLTemplate(DataSource dataSource, String schemaName) {
		super(dataSource);
		m_schemaName = schemaName;
	}
	
	public void setSchemaName(String schemaName) {
		m_schemaName = schemaName;
	}

	public boolean tableExists(String tableName) throws SQLException {
		return queryForInt("select count(*) as table_num  from information_schema.tables where table_name='"
				+ tableName + "' and table_schema='" + m_schemaName + "'") == 1;
	}

  public void dropTableIfExists(String tableName) throws SQLException {
			getJdbcOperations().execute("DROP TABLE IF EXISTS " + tableName);
	}
}
