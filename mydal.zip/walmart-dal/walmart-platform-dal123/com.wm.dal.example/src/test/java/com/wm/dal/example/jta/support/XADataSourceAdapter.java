
package com.wm.dal.example.jta.support;

import java.io.PrintWriter;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.Connection;
import java.sql.SQLException;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.sql.DataSource;
import javax.sql.XAConnection;
import javax.sql.XADataSource;
import javax.transaction.RollbackException;
import javax.transaction.Synchronization;
import javax.transaction.SystemException;

import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.jta.JtaTransactionManager;

import com.wm.dal.client.DALRequest;

public class XADataSourceAdapter implements DataSource
{
  private XADataSource m_xaDataSource;
  @Resource(name="txManager") protected JtaTransactionManager txManager;

  public void
  setXADataSource(XADataSource xaDataSource)
  {
    m_xaDataSource = xaDataSource;
  }

  @Override
  public PrintWriter getLogWriter() throws SQLException {
    throw new UnsupportedOperationException();
  }

  @Override
  public void setLogWriter(PrintWriter out) throws SQLException {
    throw new UnsupportedOperationException();
  }

  @Override
  public void setLoginTimeout(int seconds) throws SQLException {
    throw new UnsupportedOperationException();
  }

  @Override
  public int getLoginTimeout() throws SQLException {
    throw new UnsupportedOperationException();
  }

  @Override
  public <T> T unwrap(Class<T> iface) throws SQLException {
    throw new UnsupportedOperationException();
  }

  @Override
  public boolean isWrapperFor(Class<?> iface) throws SQLException {
    throw new UnsupportedOperationException();
  }

  @Override
  public Connection getConnection() throws SQLException {
    final XAConnection xac = m_xaDataSource.getXAConnection();
    final Connection cnx = xac.getConnection();
    try {
      txManager.getTransactionManager().getTransaction().enlistResource(xac.getXAResource());
    } catch (IllegalStateException e) {
      e.printStackTrace();
      throw new SQLException(e);
    } catch (RollbackException e) {
      e.printStackTrace();
      throw new SQLException(e);
    } catch (SystemException e) {
      e.printStackTrace();
      throw new SQLException(e);
    }

    return (Connection) Proxy.newProxyInstance(getClass().getClassLoader(),
        new Class[]{java.sql.Connection.class},
        new InvocationHandler() {

      @Override
      public Object invoke(Object proxy, Method method,
          Object[] args) throws Throwable {
        if (!"close".equals(method.getName()))
          return method.invoke(cnx, args);
        xac.close();
        return null;
      }
    });
  }

  @Override
  public Connection getConnection(String username, String password)
      throws SQLException {
    throw new UnsupportedOperationException();
  }

}
