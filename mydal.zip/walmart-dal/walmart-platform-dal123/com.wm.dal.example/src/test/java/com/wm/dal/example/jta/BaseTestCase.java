package com.wm.dal.example.jta;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;

import com.bitmechanic.sql.GenericPool;
import com.wm.corelib.config.AppConfig;
import com.wm.dal.common.ConnectionTypeManager;
import com.wm.dal.example.jta.support.ExtendedJdbcMySQLTemplate;
import com.wm.dal.example.jta.support.ExtendedJdbcOperations;
import com.wm.dal.example.jta.support.ExtendedJdbcOracleTemplate;
import com.wm.org.jboss.arquillian.testng.Arquillian;
import com.wm.sql.DataAccess;

@ContextConfiguration(locations = "classpath*:/META-INF/spring/test-context.xml")
public abstract class BaseTestCase extends Arquillian {
	protected static final String MYSQL_SCHEMA_NAME = "test";

	protected final Logger logger = Logger.getLogger(getClass().getName());

	@Resource(name = "directMysqlDS")
	protected DataSource pureDataSource1;
	@Resource(name = "directOracleDS")
	protected DataSource pureDataSource2;

	@Resource(name = "xadalMysqlDS")
	protected DataSource DS1;
	@Resource(name = "xadalOracleDS")
	protected DataSource DS2;

	@Resource(name = "txManager")
	protected PlatformTransactionManager txManager;

	ExtendedJdbcOperations pureTemplate1;
	ExtendedJdbcOperations pureTemplate2;

	static {
		try {
			BaseTestCase.load(BaseTestCase.class, "/system.properties");
		} catch (Exception e) {
			e.printStackTrace(System.out);
		}
	}
	private static URL lastURL = null;
    public static void load(Class clazz, String file) throws IOException {
        URL url = clazz.getResource(file);
        if (url == null || url.equals(lastURL)) return;
        lastURL = url;
        
        String[] aliases = AppConfig.getInstance().getProperty("com.wm.sql.dataaccess.aliases", "").trim().split(",");
        for (String alias : aliases) {
            if (!"".equals(alias)) for (GenericPool pool : DataAccess.getInstance().getGenericPool(alias)) {
                pool.setLocked(true);
                pool.removeAll();
            }
        }
        AppConfig.getInstance().getProperties().load(clazz.getResourceAsStream(file));
        DataAccess.setInstance(null);
        ConnectionTypeManager.setInstance(null);
    }
	@PostConstruct
	private void doInit() {
		pureTemplate1 = new ExtendedJdbcMySQLTemplate(pureDataSource1, MYSQL_SCHEMA_NAME);
		pureTemplate2 = new ExtendedJdbcOracleTemplate(pureDataSource2);
	}

	protected abstract String getTableName();

	protected void 
	finalize(boolean commit, TransactionStatus status, Object... objects) 
		throws SQLException 
	{
		boolean success = false;
		try {
			if (commit)
				txManager.commit(status);
			else
				txManager.rollback(status);
			success = true;
		} finally {
			close(success, objects);
		}
	}

	protected boolean 
	close(boolean rethrow, Object... objects)
		throws SQLException 
	{
		try {
			close(objects);
		} catch (SQLException e) {
			if (rethrow)
				throw e;
			return false;
		}
		return true;
	}

	protected void close(Object... objects) throws SQLException {
		SQLException exception = null;
		for (Object ooo : objects) {
			if (ooo == null)
				;
			else if (ooo instanceof Connection) {
				try {
					((Connection) ooo).close();
				} catch (SQLException e) {
					if (exception == null)
						exception = e;
				}
			} else if (ooo instanceof Statement) {
				try {
					((Statement) ooo).close();
				} catch (SQLException e) {
					if (exception == null)
						exception = e;
				}
			} else if (ooo instanceof ResultSet) {
				try {
					((ResultSet) ooo).close();
				} catch (SQLException e) {
					if (exception == null)
						exception = e;
				}
			} else
				throw new UnsupportedOperationException("Unsupported Type: "
						+ ooo.getClass().getName());
		}

		if (exception != null)
			throw exception;
	}

	protected void testQueryForSuccessInsertMysql() throws SQLException {
		assertEquals(pureTemplate1.count(getTableName()), 1);
	}

	protected void testQueryForSuccessInsertOracle() throws SQLException {
		assertEquals(pureTemplate2.count(getTableName()), 1);
	}

	protected void testQueryForFailureInsertMysql() throws SQLException {
		assertEquals(pureTemplate1.count(getTableName()), 0);
	}

	protected void testQueryForFailureInsertOracle() throws SQLException {
		assertEquals(pureTemplate2.count(getTableName()), 0);
	}

	protected void testQueryForDeleteMysql() throws SQLException {
		assertEquals(pureTemplate1.count(getTableName()), 0);
	}

	protected void testQueryForDeleteOracle() throws SQLException {
		assertEquals(pureTemplate2.count(getTableName()), 0);
	}

	protected void testQueryForCreateMysql() throws SQLException {
		assertTrue(pureTemplate1.tableExists(getTableName()));
	}

	protected void testQueryForCreateOracle() throws SQLException {
		assertTrue(pureTemplate2.tableExists(getTableName()));
	}

	protected void testQueryForDropMysql() throws SQLException {
		assertFalse(pureTemplate1.tableExists(getTableName()));
	}

	protected void testQueryForDropOracle() throws SQLException {
		assertFalse(pureTemplate2.tableExists(getTableName()));
	}
}
