package com.wm.dal.example.jta.support;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;

public abstract class ExtendedJdbcTemplate extends SimpleJdbcTemplate 
	implements ExtendedJdbcOperations
{

	public ExtendedJdbcTemplate(DataSource dataSource) {
		super(dataSource);
	}

	public int count(String tableName) throws SQLException {
		return queryForInt("SELECT count(*) FROM " + tableName);
	}
}
