package com.wm.dal.example.jta;

import static org.testng.Assert.fail;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.shrinkwrap.api.ArchivePaths;
import org.jboss.shrinkwrap.api.Filters;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.StringAsset;
import org.jboss.shrinkwrap.api.exporter.ZipExporter;
import org.jboss.shrinkwrap.api.spec.EnterpriseArchive;
import org.jboss.shrinkwrap.api.spec.JavaArchive;
import org.jboss.shrinkwrap.descriptor.api.Descriptors;
import org.jboss.shrinkwrap.descriptor.api.spec.ee.application.ApplicationDescriptor;
import org.jboss.shrinkwrap.resolver.api.DependencyResolvers;
import org.jboss.shrinkwrap.resolver.api.maven.MavenDependencyResolver;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.testng.annotations.Test;

@Test(singleThreaded = true)
public class TestCommitRollbackJTA0 extends BaseTestCase 
{
    protected String 
    getTableName() 
    {
        return "itemtbl_testcommitrollback0";
    }

		@Deployment(testable = true)
		public static EnterpriseArchive createDeployment() throws Exception
		{
				String applicationXml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><application/>";
				
				ApplicationDescriptor application = Descriptors.
						importAs(ApplicationDescriptor.class).from(applicationXml);

				JavaArchive test;

    EnterpriseArchive ear = ShrinkWrap
      .create(EnterpriseArchive.class, "test.ear")
      .addAsModule(
        test = ShrinkWrap
          .create(JavaArchive.class, "lib/test.jar")
          .addPackages(true, "com.wm.dal.example.jta")
          .merge(ShrinkWrap.create(JavaArchive.class)
            .addAsResource(new File("src/test/resources"), "/"), Filters.exclude(".*/\\.svn.*")))
          .addAsLibraries(
            DependencyResolvers
              .use(MavenDependencyResolver.class)
              .goOffline()
              .loadMetadataFromPom("pom.xml")
              .artifact("walmart-platform-dal:com.wm.dal")
              	.exclusion("*:*")
              .artifact("walmart-platform:com.wm.sql")
              .artifact("org.springframework:spring")
              .artifact("org.springframework:spring-test")
              .artifact("mysql:mysql-connector-java")
              .artifact("walmart-thirdparty.oracle:ojdbc6")
              .artifact("org.jboss.netty:netty")
              .artifact("walmart-platform:com.wm.org.jboss.arquillian")
              .resolveAs(JavaArchive.class))
        .setApplicationXML(new StringAsset(application.exportAsString()));

    test.delete(ArchivePaths.create("META-INF/spring/test-context.xml"));
    test.delete(ArchivePaths.create("system.properties"));

    test.addAsResource(new File(
        "src/test/resources/META-INF/spring/test-context-server.xml"), ArchivePaths
        .create("META-INF/spring/test-context.xml"));
    test.addAsResource(new File(
        "src/test/resources/system.server.properties"), ArchivePaths
        .create("system.properties"));

    if (System.getProperty("export.ear") != null)
	ear.as(ZipExporter.class).exportTo(new File(System.getProperty("export.ear")), true);

    return ear;
  }

  @Test(groups = { "mysql", "oracle", "create" })
  public void
      testCreate()
          throws SQLException
  {
    String creaTablMySql = "CREATE TABLE " + getTableName() + "("
        + "var_string varchar(10) default NULL"
        + ") ENGINE=InnoDB DEFAULT CHARSET=utf8;";

    logger.info("begin to create itemtbl table.");
    pureTemplate1.dropTableIfExists(getTableName());
    pureTemplate1.getJdbcOperations().execute(creaTablMySql);
    logger.info("itemtbl table is created.");

    logger.info("begin to create itemtbl table.");
    pureTemplate2.dropTableIfExists(getTableName());
    pureTemplate2.getJdbcOperations().execute(
        "CREATE TABLE "+getTableName()+"(var_string VARCHAR2(10) default NULL)");
    logger.info("itemtbl table is created.");

    testQueryForCreateMysql();
    testQueryForCreateOracle();
  }

  @Test(dependsOnMethods = "testCreate", groups = { "mysql", "oracle", "insert" })
  public void
  testSuccessInsert()
    throws SQLException
  {
    Connection con1 = null; // Mysql Connection
    Connection con2 = null; // Oracle Connection
    PreparedStatement pstm1 = null; // Mysql Statement
    PreparedStatement pstm2 = null; // Oracle Statement
    TransactionStatus status = txManager.getTransaction(new DefaultTransactionDefinition());

    boolean success = false;
    try
    {
      logger.info("begin to insert itemtbl data.");
      con1 = DS1.getConnection();
      con2 = DS2.getConnection();
      pstm1 = con1.prepareStatement("INSERT INTO "+getTableName()+" VALUES(?)");
      pstm2 = con2.prepareStatement("INSERT INTO "+ getTableName()+" VALUES(?)");
      pstm1.setString(1, "HelloWorld");
      pstm2.setString(1, "HelloWorld");
      pstm1.executeUpdate();
      pstm2.executeUpdate();
      logger.info("itemtbl data are inserted.");
      testQueryForFailureInsertMysql();
      testQueryForFailureInsertOracle();
      success = true;
    } 
    finally
    {
      finalize(success, status, pstm1, pstm2, con1, con2);
    }
    testQueryForSuccessInsertOracle();
    testQueryForSuccessInsertMysql();
  }

  @Test(dependsOnMethods = "testSuccessInsert", groups = { "mysql", "oracle", "insert" })
  public void
  testDelete()
    throws SQLException
  {
    Connection con1 = null; // Mysql Connection
    Connection con2 = null; // Oracle Connection
    Statement stmt1 = null; // Mysql Statement
    Statement stmt2 = null; // Oracle Statement
    TransactionStatus status = txManager.getTransaction(new DefaultTransactionDefinition());

    boolean success = false;
    try
    {
      logger.info("begin to delete itemtbl data.");
      con1 = DS1.getConnection();
      con2 = DS2.getConnection();
      stmt1 = con1.createStatement();
      stmt1.execute("DELETE FROM " + getTableName());
      stmt2 = con2.createStatement();
      stmt2.execute("DELETE FROM " + getTableName());
      logger.info("data of itemtbl table is deleted.");
      testQueryForSuccessInsertOracle();
      testQueryForSuccessInsertMysql();
      success = true;
    } 
    finally
    {
      finalize(success, status, stmt1, stmt2, con1, con2);
    }

    testQueryForDeleteMysql();
    testQueryForDeleteOracle();
  }

  @Test(dependsOnMethods = "testDelete", groups = { "mysql", "oracle", "insert" })
  public void
  testFailureInsert()
    throws SQLException
  {
    Connection con1 = null; // Mysql Connection
    Connection con2 = null; // Oracle Connection
    PreparedStatement pstm1 = null; // Mysql Statement
    PreparedStatement pstm2 = null; // Oracle Statement
    TransactionStatus status = txManager.getTransaction(new DefaultTransactionDefinition());

    boolean success = false;
    try
    {
      logger.info("begin to insert itemtbl data.");
      con1 = DS1.getConnection();
      con2 = DS2.getConnection();

      pstm2 = con2.prepareStatement("INSERT INTO "+getTableName()+" VALUES(?)");
      pstm2.setString(1, "HelloWorld");
      pstm2.executeUpdate();

      testQueryForFailureInsertMysql();
      testQueryForFailureInsertOracle();

      pstm1 = con1.prepareStatement("INSERT INTO "+getTableName()+" VALUES(?)");
      pstm1.setString(1, "HelloWorld!");
      pstm1.executeUpdate();

      txManager.commit(status);
      logger.info("itemtbl data are inserted.");
      success = true;
      fail();
    } 
    catch (com.mysql.jdbc.MysqlDataTruncation e)
    {
      txManager.rollback(status);
      success = true;
    } 
    finally
    {
      close(success, pstm1, pstm2, con1, con2);
    }
    testQueryForFailureInsertMysql();
    testQueryForFailureInsertOracle();
  }
  
  @Test(dependsOnMethods = "testFailureInsert", groups = { "mysql", "oracle", "drop" })
  public void
  testDrop()
    throws SQLException
  {
    try
    {
      logger.info("begin to drop itemtbl table.");
      pureTemplate1.dropTableIfExists(getTableName());
      logger.info("itemtbl table is dropped.");
    }
    finally
    {
      logger.info("begin to drop itemtbl table.");
      pureTemplate2.dropTableIfExists(getTableName());
      logger.info("itemtbl table is dropped.");
    }

    testQueryForDropMysql();
    testQueryForDropOracle();
  }
}
