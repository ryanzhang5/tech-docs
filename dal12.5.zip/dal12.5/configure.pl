#!./perl/bin/perl -I./perl/lib/5.8.7 -I./perl/lib/site_perl/5.8.7/ActivePerl -I./perl/lib/5.8.7/arch -I./perl/lib/5.8.7 -I./perl/lib/site_perl/5.8.7/arch -I./perl/lib/site_perl/5.8.7 -I./perl/lib/site_perl -I./perl/lib/5.8.7/x86-solaris-thread-multi

use FindBin qw($Bin);

eval 'use XML::Simple qw(:strict);';
eval qq{
    use lib "$Bin/lib/perl5";
    use XML::Simple qw(:strict);
} if $@;

use Sys::Hostname;
use Getopt::Long;
use Data::Dumper;
use Socket;
use strict;

$Data::Dumper::Sortkeys = 1;

my $VERBOSITY = undef;          # verbosity level
my $DB = undef;                    # The database

&main();
exit(0);

sub main 
{
  my %context   = ();         # The context
    my %config    = ();         # The actual configuration set
    my %overrides = ();         # Values from the configuration file   
    my %keyset    = ();         # The required keys

    my %cmdline = ();

  print "\nconfigure - walmart.com\n";
# print "Usage: configure --app=APPLICATION --env=ENVIRONMENT\n";
# print "Type configure --help for a list of all command options\n";
# print "Check http://techdocs.walmart.com/twiki/bin/view/SWeng/ConfigureProject for more info\n";
 print "\n";

  if (! GetOptions(\%cmdline, 
        'configdb=s', 'env=s', 'app=s', 'host=s', 'like-host=s', 'help',
        'groups=s', 'overridesfile=s', 'v+', 'interactive', 'silent',
        'test', 'user=s', 'os=s', 'cpu=s', 'arch=s', 'root=s')) 
  {
    exit(1);
  }

  &usage() if $cmdline{help};

  $VERBOSITY = $cmdline{v} || 0;

  &log("command line args:\n".Dumper(\%cmdline), 3);

  my $configdb = $FindBin::Bin. "/configure.xml";
  if ( exists($cmdline{configdb}) )
  {
    $configdb = $cmdline{configdb};
  }
  &log( "using confgdb = $configdb", 1 );

  $DB = &loadDatabase(file => $configdb );

  &validateDatabase();        # XXX: exit if --test switch present

  %overrides = &loadConfigFile(file => $cmdline{overridesfile}, search => $DB->{'overrides-file-search-path'});

  %context = &resolveContext(cmdline => \%cmdline,  overrides => \%overrides);
  &validateContext(context => \%context);

  print "Configuring:\n";
  print "APPLICATION = $context{APPLICATION}\n";
  print "ENVIRONMENT = $context{ENVIRONMENT}\n";
  print "ROOT        = $context{ROOT}\n";

  %keyset = &resolveKeySet(app => $context{APPLICATION});
  &validateKeySet( context => \%context, keyset => \%keyset );

  %config = &resolveValues(keyset => \%keyset, overrides => \%overrides, context => \%context, cmdline => \%cmdline );

  my @missing = &findMissingValues( values => \%config, keyset => \%keyset);
  if (@missing) 
  {
    &error("missing values for key(s): " . join(",", @missing));
  }

  &doSubstitutions(values => \%config, context => \%context);

  &writeConfiguration( values => \%config );
  &log( "final key-values: \n" . Dumper(\%config), 2 );

  &executeEpilogue( values => \%config );

  print "\nDone\n";

  return;
}

sub executeEpilogue
{
  my %args = (@_);
  my $values = $args{values};

  my $epilogue = $DB->{'epilogue'};
  my $cmds     = $epilogue->{cmd};
  foreach my $cmd ( @$cmds )
  {
    my $cmdStr = $cmd->{content};
    $cmdStr = &doSubsInString( string => $cmdStr, values => $values ); 
    if ( $cmd->{type} eq 'shell' )
    {
      system $cmdStr;
    }
    elsif ( $cmd->{type} eq 'perl' )
    {
      eval( $cmdStr );
    }
    else
    {
      &error( "CMD ERROR: unknown cmd type " . $cmd->{type} );
    }
  }
}

sub writeConfiguration
{
  my %args    = @_;
  my $keys    = $args{values};
  my $outputs  = $DB->{output};

  foreach my $output (@$outputs)
  {
    my $out     = $output->{filename};
    my $formats = $output->{format};

    if ( !defined( $out ) )
    {
      die "filename must be specified for each output element!";
    }

    $out = $keys->{ROOT} . '/' . $out;

    open (CONF, ">$out") or die "Can't open $out for writing\n";
    foreach my $format ( @$formats )
    {
      if ( exists( $format->{prefix} ) )
      {
        print CONF &expandStdEscapes( $format->{prefix});
      }

      my $pattern = $format->{content};

      foreach my $key ( sort keys %$keys )
      {
        my $val = $keys->{$key};
        if ( ref( $val ) eq 'ARRAY' )
        {
          $val = join( ',', (@$val) );
        }
        my $tmp = $pattern;
        $tmp =~ s/\%n/$key/g;
        $tmp =~ s/\%v/$val/g;
        $tmp = &expandStdEscapes( $tmp );

        print CONF $tmp;
      }

      if ( exists( $format->{suffix} ) )
      {
        print CONF &expandStdEscapes( $format->{suffix});
      }
    }
  }
}

sub expandStdEscapes
{
  my ($rv) = @_;
  $rv =~ s/\\t/\t/;
  $rv =~ s/\\n/\n/;
  return $rv;
}

sub validateKeySet 
{
  my %args    = (@_);
  my $keyset  = $args{keyset};
  my $context = $args{context};

  &log( "Validating KEYSET", 2 );
  foreach my $key ( keys %$keyset )
  {
    if ( defined( $context->{$key} ) )
    {
      &error( "KEYSET ERROR: invalid key name '$key'! '$key' is reserved for context variable." );
    }
  }
  &log( "KEYSET is valid", 2 );
}

sub doSubstitutions 
{
  my %args    = (@_);
  my $values  = $args{values};
  my $context = $args{context};

  my $done = 0;
  while (! $done) 
  {
    my $need = 0;
    my $replaced = 0;
    foreach my $key (keys %$values) {
      if (my $s = &findSubstitution($values->{$key})) {
        $need++;

        my $lookup = $s->{lookup};
        if (! defined($values->{$lookup})) 
        {
          &error("no such config variable named $lookup (for substitute in $key=" . $values->{$key} . ")");
        }
        elsif (defined(&findSubstitution($values->{$lookup}))) {
          next;
        }

        my $search = $s->{search};                
        my $replace = $values->{$lookup};
        &log("BEFORE: replace $search with $replace in $key=" . $values->{$key}, 2);
        $search = quotemeta($search);
        $values->{$key} =~ s/$search/$replace/;
        &log("AFTER: $key=" . $values->{$key}, 2);
        $replaced++;
      }
    }

    &error("can not resolve all substitutions") if (($need > 0) && (0 == $replaced));
    $done = (0 == $need);
  }
}

sub doSubsInString
{
  my %args = (@_);
  my $values = $args{'values'};
  my $string = $args{'string'};

  my $done = 0;
  my $need = 0;
  my $replaced = 0;
  while ( ! $done )
  {
    if (my $s = &findSubstitution($string)) 
    {
      $need++;

      my $lookup = $s->{lookup};
      if (! defined($values->{$lookup})) 
      {
        &error("no such config variable named $lookup (for substitute in string=" . $string . ")");
      }
      elsif (defined(&findSubstitution($values->{$lookup}))) 
      {
        &error("Unexpanded value $lookup (for substitute in string=" . $string . ")");
      }

      my $search = $s->{search};                
      my $replace = $values->{$lookup};
      &log("BEFORE: replace $search with $replace in string=" . $string, 2);
      $search = quotemeta($search);
      $string =~ s/$search/$replace/;
      &log("AFTER: string=" . $string, 2);
      $replaced++;
    }
    else
    {
      $done = 1;
    }

  }
  return $string;
}

sub findSubstitution 
{
  my $str = shift;
  my %rv = ();

  if ($str =~ m/[^\\]?\$\{([A-Z_0-9]+)\}/i) 
  {
    my $search = $&;
    my $lookup = $1;

    $search =~ s/^[^\$]//;
    $rv{search} = $search;
    $rv{lookup} = $lookup;

    return \%rv;
  }

  return undef;
}



sub error {
  print STDERR "\nERROR: $_[0]\n\n";
  exit(1);
}

sub findMissingValues 
{
  my %args = (@_);
  my $keyset = $args{'keyset'};
  my $values = $args{'values'};

  my %missing = ();

  foreach my $key ( keys %$keyset ) 
  {
    &log( "check for missing value of key $key", 2 );
    if (! exists $values->{$key}) {
      $missing{$key} = undef;
    }
  }
  return(sort keys %missing);
}


sub resolveKeySet 
{
  my %args = (@_);   
  my %rv = ();

  my $groups = $DB->{keys}->{keygroup};    

  foreach my $group (@$groups) 
  {
    my $groupName = $group->{name};
    my $keys      = $group->{key};
    foreach my $key (@$keys) 
    {
      my $keyName = $key->{name};
      if (exists $key->{apps} && !($key->{apps} =~ /\b$args{app}\b/) )
      {
        next;
      }
      $rv{$keyName} = undef;
    }
  }

  &log("resolved key set is: " . join(", ", (sort keys %rv)), 2);

  return %rv;
}

sub resolveValues
{
  my %args = (@_);
  my $overrides = $args{overrides};
  my $keyset    = $args{keyset};
  my $context   = $args{context};
  my $cmdline   = $args{cmdline};
  my $ui        = $cmdline->{interactive};
  my $keyUi     = $ui;

  my %rv = ();

  %rv = %$context;

  my $groups = $DB->{keys}->{keygroup};    

  foreach my $group (@$groups) 
  {
    my $groupName = $group->{name};
    &log( "resolving values for groupName={$groupName}\n", 2 );
    &log( "Group{$groupName} = \n" . Dumper( $group ), 4 ); 

    if ( $ui )
    {
      $keyUi = promptGroup( $groupName, $keyUi );
    }

    my $keys      = $group->{key};
    &log( "groupKeys = " . Dumper( $keys ), 4 );
    foreach my $key (@$keys) 
    {
      my $keyName = $key->{name};
      &log( "processing key $keyName", 2 ); 
      if ( ! exists( $keyset->{$keyName} ) )
      {
        &log( "key $keyName is not in the current keyset", 2 ); 
        next;
      }

      &log( "resolving value for keyName $keyName", 2 ); 
      &log( "Key = \n" . Dumper( $key ), 4 ); 
     
      # 1 - default value
      if ( exists $key->{default} )
      {
        $rv{$keyName} = $key->{default};
        &log( "key $keyName: default value = " . $rv{$keyName}, 2 );
      }
      # 2 - eval rules
      if ( exists $key->{rule} )
      {
        my $rules = $key->{rule};
        foreach my $rule ( @$rules )
        {
          my $tmp = &evaluateRule( $rule, \%rv );
          if ( defined( $tmp ) )
          {
            $rv{$keyName} = $tmp;
            &log( "key $keyName: rule value = " . $rv{$keyName}, 2 );
          }
        }    
      }

      # 3 - overrides (.overrides.config file)
      if ( exists $overrides->{$keyName} )
      {
        $rv{$keyName} = $overrides->{$keyName};
        &log( "key $keyName: override value = " . $rv{$keyName}, 2 );
      }

      if ( $keyUi && defined( $key->{prompt} ) )
      {
        $rv{$keyName} = &promptKey( keyname => $keyName, keytype => $key->{type}, prompt => $key->{prompt}, keyval => $rv{$keyName} );
      }
    }
  }

  &log( "Resolved Key Values = \n" . Dumper( \%rv ) . "\n", 2 );

  return %rv;
}

sub promptKey
{
  my %args = (@_);
  my $keyName = $args{keyname};
  my $keyType = $args{keytype};
  my $keyVal  = $args{keyval};
  my $prompt  = $args{prompt};

  my %keyTypes  = ( 'bool' => 'true',
                    'num'  => 'true', );

  my %boolTypes = ( 'true'  => 'true' ,
                    'y'     => 'true' ,
                    't'     => 'true' ,
                    '1'     => 'true' ,
                    'false' => 'false',
                    'n'     => 'false',
                    'f'     => 'false',
                    '0'     => 'false', );

  # validate keyType
  if ( !defined($keyType) || !exists( $keyTypes{$keyType} ) )
  {
    $keyType = 'string';
  }
  while ( 1 )
  {
    print "$prompt [$keyVal]: ";
    my $input = getInput( $keyVal );
    if ( "bool" eq $keyType )
    {
      $input = lc $input;
      # check type
      if ( exists( $boolTypes{$input} ) )
      {
        return $boolTypes{$input};
      }
    }
    elsif ( $keyType eq "num" )
    {
      if ( $input =~ /[-0-9.]+/ )
      {
        return $input;
      }
    }
    else
    {
      return $input;
    }
  }
}

sub getInput 
{
  my ($keyVal) = @_;

  my $input = <STDIN>;
  chomp($input);

  return $input ? $input : $keyVal;
}

sub promptGroup
{
  my ($grpName, $keyUi) = @_;
  my $keyVal = ($keyUi) ? 'true' : 'false';

  print "\n";
  print "====================================================================\n";
  my $rv = &promptKey( keyname => $grpName, keytype => 'bool', prompt => "Manually Configure group: $grpName?", keyval => $keyVal );
  print "====================================================================\n";
  return ($rv eq 'true');
}

sub validateContext 
{
  my %args = (@_);
  my $isGoodApp = 0;
  my $context = $args{context};

  &log( "Validating CONTEXT...", 2 );

  # make sure root directory exists and is an absolute path
  my $root = $context->{ROOT};
  if ( defined( $root ) && match( $root, '^/', 1, 'regex' ) && -e $root )
  {
    &log( "ROOT is ok", 2 );
  }
  else
  {
    &error( "CONTEXT ERROR: ROOT value is invalid! [$root]" );
  }

  # make sure host contains no '.' (period) characters
  my $host = $context->{HOSTNAME};
  if ( defined( $host ) && !match( $host, '\.', 1, 'regex' ) )
  {
    &log( "HOSTNAME is ok", 2 );
  }
  else
  {
    &error( "CONTEXT ERROR: HOSTNAME value is invalid (must not contain '.')! [$host]" );
  }

  # make sure app is valid
  my $app = $context->{APPLICATION};
  my $allApps = $DB->{applications};
  if ( $allApps =~ /\b$app\b/ )
  {
    &log( "APPLICATION is ok", 2 );
  }
  else
  {
    &error( "CONTEXT ERROR: APPLICATION value is invalid (must be on of the following: $allApps)! [$app]" );
  }

  # validate environment is one that is defined in DB
  my $env = $context->{ENVIRONMENT};
  my $allEnvs = $DB->{environments};
  if ( $allEnvs =~ /\b$env\b/ )
  {
    &log( "ENVIRONMENT is ok", 2 );
  }
  else
  {
    &error( "CONTEXT ERROR: ENVIRONMENT value is invalid (must be on of the following: $allEnvs)! [$env]" );
  }

  # check that all values are present
  foreach my $key ( keys %$context )
  {
    if ( ! defined( $context->{$key} ) )
    {
      &error( "CONTEXT ERROR: $key value is missing!" );
    }
  }
  &log( "CONTEXT is valid", 2 );
}

sub validateDatabase 
{
    # XXX: verify that all required data is available (eg. config-search-path)
    # XXX: do referential integrity checks
    # XXX: check for key names that collide with context namespace
    # XXX: check that apps listed on keys are valid apps listed in database
    # XXX: check that key names only contain [a-z0-9_]/i
}


sub loadConfigFile {
    my %args = (@_);

    my %rv = ();

    my $here = $FindBin::Bin;
    my $file = $args{file};
    
    if (! defined($file)) {
        foreach my $search (split(":", $args{search} || "")) {
            if ($search =~ m!^\$!) {
               eval{$search =~ s/(\$\w+\{\w+\})/$1/eeg};
            }
            elsif ($search !~ m!^/!) {
                $search = "$here/$search";
            }
            &log("looking for config file: $search", 2);
            
            if (-f $search) {
                &log("found overrides file: $search", 1);
                $file = $search;
                last;
            }
            else {
                &log("file not found or cannot read: $search", 2);
            }
        }
        
        if (! defined($file)) {
            &log("no configuration file found and/or specified", 1);
            return;
        }
    }
    
    open (CONF, "< $file") || die "cannot read overrides file: $file";
    while (my $line = <CONF>) {
        chomp($line);
        &log("read line from overrides file: $line", 4);

        $line =~ s/^\s+//; $line =~ s/\s+$//;
        next if $line eq "";
        next if $line =~ m/^\#/;
        
        my $equal = index($line, "=");
        if (-1 == $equal) {
            &error("malformed overrides entry on line $.: $line");
        }
        
        my $key = substr($line, 0, $equal);
        my $value = substr($line, $equal + 1);
        
        if (exists $rv{$key}) {
            &log("WARNING: value for $key redefined on line $.");
        }
        
        $rv{$key} = $value;               
    }
    close CONF;
            
    return %rv;
}

sub resolveContext 
{
  my %args = (@_);
  my $cmdline = $args{cmdline};
  my $cf      = $args{overrides};

  my %rv = ();

  # ORDER MATTERS!
  # Resolve host and like-host
  $rv{HOSTNAME}    = &resolveHost       ( cmdline => $cmdline, overrides => $cf, context => \%rv ); 
  $rv{LIKE_HOST}   = &resolveLikeHost   ( cmdline => $cmdline, overrides => $cf, context => \%rv ); 
  $rv{USER}        = &resolveUser       ( cmdline => $cmdline, overrides => $cf, context => \%rv ); 
  $rv{ROOT}        = &resolveRootDir    ( cmdline => $cmdline, overrides => $cf, context => \%rv ); 
  $rv{OS}          = &resolveOS         ( cmdline => $cmdline, overrides => $cf, context => \%rv ); 
  $rv{ARCH}        = &resolveARCH       ( cmdline => $cmdline, overrides => $cf, context => \%rv ); 
  $rv{CPU}         = &resolveCPU        ( cmdline => $cmdline, overrides => $cf, context => \%rv ); 

  # Application, Environment, and Groups must be resolved in the context of LIKE_HOST
  my $host      = $rv{HOSTNAME};
  $rv{HOSTNAME} = $rv{LIKE_HOST};

  $rv{APPLICATION} = &resolveApplication( cmdline => $cmdline, overrides => $cf, context => \%rv ); 
  $rv{ENVIRONMENT} = &resolveEnvironment( cmdline => $cmdline, overrides => $cf, context => \%rv ); 
  $rv{GROUPS}      = &resolveGroups     ( cmdline => $cmdline, overrides => $cf, context => \%rv ); 

  # the rest should work using the real host
  $rv{HOSTNAME} = $host;
  $rv{HOSTIP} = inet_ntoa(inet_aton($host));
  &log( "Resolved Context = \n" . Dumper( \%rv ) . "\n", 1 );

  return %rv;
}

sub resolveHost
{  
  my %args = (@_);
  my %cmdline = %{$args{cmdline  } || die};
  my %cf      = %{$args{overrides} || die};
  my %context = %{$args{context  } || die};

  my $rv = undef;

  ###############    
  # figure out the hostname
  ###############
  if (exists($cmdline{host})) 
  {
    $rv = $cmdline{host};
    &log("using hostname specified on command line: " . $rv, 1);
  }
  elsif (exists($cf{HOSTNAME})) 
  {
    $rv = $cf{HOSTNAME};
    &log("using hostname specified in file: " . $rv, 1);
  }
  else 
  {
    $rv = (split(/\./, &hostname()))[0];
    &log("using locally determined hostname: " . $rv, 1);
  }

  if ( !defined( $rv ) )
  {
    &error( "Cannot determine host" );
  }
  return $rv;
}

sub resolveUser
{  
  my %args = (@_);
  my %cmdline = %{$args{cmdline  } || die};
  my %cf      = %{$args{overrides} || die};
  my %context = %{$args{context  } || die};

  my $rv = undef;
  ###############    
  # determine username 
  ###############
  if (exists($cmdline{user})) 
  {
    $rv = $cmdline{user};
    &log("using user specified on command line: " . $rv, 1);
  }
  elsif (exists($cf{USER})) 
  {
    $rv = $cf{USER};
    &log("using user specified in file: " . $rv, 1);
  }
  else 
  {
    $rv = getpwuid($<) || $ENV{LOGNAME} || $ENV{USER} || die "cannot determine the current user";
    &log("using locally determined user: " . $rv, 1);
  }    

  if ( !defined( $rv ) )
  {
    &error( "Cannot determine USER" );
  }
  return $rv;
}

sub resolveRootDir
{  
  my %args = (@_);
  my %cmdline = %{$args{cmdline  } || die};
  my %cf      = %{$args{overrides} || die};
  my %context = %{$args{context  } || die};

  my $rv = undef;

  ###############
  # determine application root directory
  ###############
  if (exists($cmdline{root})) 
  {
    $rv = $cmdline{root};
    &log("using root directory specified on command line: " . $rv, 1);
  }
  elsif (exists($cf{ROOT})) 
  {
    $rv = $cf{ROOT};
    &log("using root directory specified in file: " . $rv, 1);
  }
  else 
  {
    $rv = $FindBin::Bin || die "cannot determine the root directory";
    &log("using locally determined root directory: " . $rv, 1);
  }    

  if ( !defined( $rv ) )
  {
    &error( "Cannot determine ROOT" );
  }
  return $rv;
}

sub resolveOS
{  
  my %args = (@_);
  my %cmdline = %{$args{cmdline  } || die};
  my %cf      = %{$args{overrides} || die};
  my %context = %{$args{context  } || die};

  my $rv = undef;
  if (exists $cmdline{os}) 
  {
    $rv = $cmdline{os};
    &log("using OS from command line: " . $rv, 1);
  }
  elsif (exists $cf{OS}) 
  {
    $rv = $cf{OS};
    &log("using OS from overrides file: " . $rv, 1);
  }
  else 
  {
    my $out = `uname -s`;
    chomp($out);
    $rv = $out;
    &log("using locally determined OS: " . $rv, 1);
  }

  if ( !defined( $rv ) )
  {
    &error( "Cannot determine OS" );
  }
  return $rv;
}

sub resolveARCH
{  
  my %args = (@_);
  my %cmdline = %{$args{cmdline  } || die};
  my %cf      = %{$args{overrides} || die};
  my %context = %{$args{context  } || die};

  my $rv = undef;
  if (exists $cmdline{arch}) 
  {
    $rv = $cmdline{arch};
    &log("using ARCH from command line: " . $rv, 1);
  }
  elsif (exists $cf{ARCH}) 
  {
    $rv = $cf{ARCH};
    &log("using ARCH from overrides file: " . $rv, 1);
  }
  else 
  {
    my $out = `uname -m`;
    chomp($out);
    $rv = $out;
    &log("using locally determined ARCH: " . $rv, 1);
  }

  if ( !defined( $rv ) )
  {
    &error( "Cannot determine ARCH" );
  }
  return $rv;
}


sub resolveCPU
{  
  my %args = (@_);
  my %cmdline = %{$args{cmdline  } || die};
  my %cf      = %{$args{overrides} || die};
  my %context = %{$args{context  } || die};

  my $rv = undef;
  if (exists $cmdline{cpu}) 
  {
    $rv = $cmdline{cpu};
    &log("using CPU from command line: " . $rv, 1);
  }
  elsif (exists $cf{CPU}) 
  {
    $rv = $cf{CPU};
    &log("using CPU from overrides file: " . $rv, 1);
  }
  else 
  {
    $rv = `uname -p`;
    chomp($rv);
    &log("using locally determined CPU: " . $rv, 1);
  }
  my ($os, $arch) = ($context{OS} || die, $context{ARCH} || die);

  # Hack for uname on linux boxes that actually works
  if ( $os eq "Linux" && $arch =~ /^i[3456]86$/ && ( $rv =~ /Pentium/ || $rv =~ /^i[3456]86$/ || $rv eq "" ) ) 
  {
    $rv = "unknown";
  }

  if ( !defined( $rv ) )
  {
    &error( "Cannot determine CPU" );
  }
  return $rv;
}

sub resolveLikeHost
{
  my %args = (@_);
  my %cmdline = %{$args{cmdline  } || die};
  my %cf      = %{$args{overrides} || die};
  my %context = %{$args{context  } || die};

  my $rv = undef;

  # setup the LIKE_HOST context
  if (exists($cmdline{'like-host'})) 
  {
    $rv = $cmdline{'like-host'};
    &log("using like_host specified on command line: " . $rv, 1);
  }
  else 
  {
    $rv = $context{HOSTNAME};
  }

  if ( !defined( $rv ) )
  {
    &error( "Cannot determine like_host" );
  }
  return $rv;
}

sub resolveApplication
{
  my %args = (@_);
  my %cmdline = %{$args{cmdline  } || die};
  my %cf      = %{$args{overrides} || die};
  my %context = %{$args{context  } || die};

  my $rv = undef;
  ###############
  # determine the application
  ###############
  if (exists($cmdline{app})) 
  {
    $rv = $cmdline{app};
    &log("using application specified on command line: " . $rv, 1);
  }
  elsif (exists($cf{APPLICATION})) 
  {
    $rv = $cf{APPLICATION};
    &log("using application specified in file: " . $rv, 1);
  }
  else 
  {
    $rv = &lookupMapping(map => 'app-map', data => \%context);
    &error("cannot determine application") if (! defined($rv));
    &log( "using application defined in database: " . $rv, 1);
  }

  if ( !defined( $rv ) )
  {
    &error( "Cannot determine APPLICATION" );
  }
  return $rv;
}

sub resolveEnvironment
{
  my %args = (@_);
  my %cmdline = %{$args{cmdline  } || die};
  my %cf      = %{$args{overrides} || die};
  my %context = %{$args{context  } || die};

  my $rv = undef;
  ###############    
  # determine the environment
  ###############
  if (exists($cmdline{env})) 
  {
    $rv = $cmdline{env};
    &log("using environment specified on command line: " . $rv, 1);
  }
  elsif (exists($cf{ENVIRONMENT})) 
  {
    $rv = $cf{ENVIRONMENT};
    &log("using environment specified in file: " . $rv, 1);
  }
  else 
  {
    $rv = &lookupMapping(map => "env-map", data => \%context );
    if ($rv) 
    {
      &log("using environment defined in database: " . $rv, 1);
    }
    else 
    {
      &log("not using any environmental context", 1);
    }     
  }
  if ( !defined( $rv ) )
  {
    &error( "Cannot determine ENVIRONMENT" );
  }
  return $rv;
}

sub resolveGroups
{
  my %args = (@_);
  my %cmdline = %{$args{cmdline  } || die};
  my %cf      = %{$args{overrides} || die};
  my %context = %{$args{context  } || die};

  my @rv = undef;
  ###############
  # determine configuration group(s)
  ###############
  my $exclusive = 0;
  my %groupSet = ();
  my $groups = exists($cmdline{groups}) ? $cmdline{groups} : "";
  if ($groups =~ m/^\:/) {
    $exclusive = 1;
    $groups =~ s/^\://;
  }

  my %add = ();
  my %remove = ();
  foreach my $group (split(",", $groups)) {
    if ($group =~ m/^([\+\-])?(.+)$/) {
      if (defined($1) && ($1 eq "-")) {
        $remove{$2} = undef;
        &log("not using configuration for group: $2", 2);
      }
      else {
        $add{$2} = undef;
        &log("including configuration for group: $2", 2);
      }                
    }
  }

  if (! $exclusive) {
    foreach my $match (&lookupMapping(map => 'group-map', data => \%context, mult => 1)) {
      $groupSet{$match} = undef;
    }
  }

  foreach my $add (keys %add) {
    $groupSet{$add} = undef;
  }

  foreach my $remove (keys %remove) {
    delete $groupSet{$remove};
  }

  my @glist = sort keys %groupSet;
  @rv = @glist;
  if (@rv) 
  {
    &log("using configuration from group(s): " . join(",",@rv), 1);
  }
  else 
  {
    &log("not using configuration from any groups", 1);
  }
  return \@rv;
}

#####################################################################
sub lookupMapping 
{
  my %args = (@_);

  my $map = $args{map} || die "must specify map name";
  my $data = $args{data};
  my $mult = $args{mult} || 0;

  &log( "looking up mapping: map = $map, mult = $mult", 2 );

  my @rv = ();

  if (! exists $DB->{$map}) 
  {
    &log("no map exists for name: $map", 2);
    $mult ? (return @rv) : (return undef);
  }

  my $result = $DB->{$map}->{default};
  my @rules = @{$DB->{$map}->{rule}};

  &log( "default value = $result", 3 );

  foreach my $rule (@rules) 
  {
    my $tmp = &evaluateRule($rule, $data);
    if (defined($tmp)) 
    {
      if ( $mult )
      {
        (push(@rv, $tmp));
      }
      else
      {
        $result = $tmp;
      }
    }
  }    

  $mult ? (return @rv) : (return $result);

  die "internal error - unreachable code";
}
#####################################################################


#####################################################################
# rule - xml rule
# data - a hash table of lookup variables
sub evaluateRule 
{
  my ($rule, $data) = (@_);

  my $type     = $rule->{type}   || &error("missing rule type" );
  my $val      = $rule->{val}    || &error("missing rule val"  );
  my $var      = $rule->{var}    || &error("missing rule var"  );
  my $value    = $rule->{keyval}->{val};
  my $subRules = $rule->{rule};
  my $case     = $rule->{'case-sensitive'} || "true";



  # some syntax error checking
  if ( defined( $subRules ) && defined( $value ) )
  {
    &error( "Both <keyval> and <rule> elements cannot be specified within <rule> element" );
  }
  if ( !defined( $subRules ) && !defined( $value ) )
  {
    &error( "Either <keyval> or <rule> element must be specified within <rule> element" );
  }

  $case = lc($case) eq "false" ? 0 : 1;

  my $potential = undef;    
  if ( &match( $data->{$var}, $val, $case, $type ) )
  {
    if ( defined( $subRules ) )
    {
      my $tmp = undef;
      foreach my $subRule ( @$subRules )
      {
        $tmp = &evaluateRule( $subRule, $data );
        if ( defined( $tmp ) )
        {
          $potential = $tmp;
        }
      }
    }
    elsif ( defined( $value ) )
    {
      $potential = $value;
    }
  }

  return $potential;
}
#####################################################################

#####################################################################
sub match
{
  my ( $string, $pattern, $case, $type ) = @_;
  if ( !defined( $string ) || !defined( $pattern ) )
  {
    return 0;
  }
  if ( ref( $string ) eq 'ARRAY' )
  {
    foreach my $str (@$string)
    {
      if ( &match( $str, $pattern, $case, $type ) )
      {
        return 1;
      }
    }
    return 0;
  }

  if ( $type eq "exact" )
  {
    return ( ($case && ("$string" eq "$pattern")) || (lc("$string") eq lc("$pattern")) ) ;
  }
  elsif ( $type eq "regex" )
  {
    return ( ($case && ($string =~ m/$pattern/)) || ($string =~ m/$pattern/i) );
  }
  else
  {
    &error( "Unknown rule type: " . $type );
  }
}
#####################################################################


sub log 
{
  my ($msg, $level) = @_;

  if (! defined($level)) { $level = 0; }

  die "internal error" if ! defined($VERBOSITY);

  if ($level <= $VERBOSITY) {        
    my $f = (caller(1))[3];
    $f =~ s/main:://;
    my $line = (caller(0))[2];

    print STDERR "$f($line): $msg\n";
  }

  return;
}



sub loadDatabase {
    my %args = (@_);
    my $data = &XMLin($args{file}, forcearray => [ qw(keygroup key rule output format) ],
                                   keyattr    => [] );
    
    &log(Dumper($data), 4);
    
    return $data;
}


sub usage {
    print "\n".
        "usage: " . $FindBin::Script . "\n".
        "  --env=<environment>     environmental context to use\n" .
        "  --app=<applicaton>      application context to use\n".
        "  --host=<hostname>       hostname to use\n".
        "  --like-host=<hostname>  produce a configuration that is \"like\" this host\n".
        "  --os=<os name>          use this explicity operating system name\n".
        "  --cpu=<cpu name>        use this explicit cpu name\n".
        "  --arch=<arch name>      use this explicit architecture name\n".
        "  --user=<user>           use this explicit user name\n".
        "  --root=<root dir>       use this as the root directory\n".
        "\n".
        "  --groups=[:][+-]group1,[+-]group2,...\n".
        "      include(+) or exclude(-) configuration for the named group(s)\n".
        "      leading ':' to force group list to be absolute (vs. relative to list in database)\n".
        "\n".
        "  --configdb=<path to file>      Use this configuration database file\n" .
        "  --overridesfile=<path to file>    Use this explicit configuration overrides file\n".
        "                                                                    \n".
        "  --interactive           run in interactive mode\n".
        "  -v                      increase logging verbosity (use multiple times for greater effect)\n".
        "  --test                  XXX: ??? what will this do again?\n".
        "  --help                  this usage message\n".
        "\n";    
    exit(1);
}


END {
    # XXX: Do any special cleanup here
}





