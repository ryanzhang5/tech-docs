#! /bin/bash

###---------------------------------------------------------------------------
### safeCertDelete.sh  - bash script - 
### 
### Mike Shimer 8-2006
### 
### Checks to see if a certificate exists in a keystore
### If the certificate alias exists it is removed
### 
### Trying to remove a alias that does not exist can break the make process
###
### See PharmacyTechNotes wiki for keystore/SSL info
### 
###---------------------------------------------------------------------------

    keyStore=$1
    certAlias=$2

    # make alias all lower case or grep might not work (keytool -list outputs all in lowercase)
    certAlias=`echo $certAlias | tr A-Z a-z`
    #echo cert alias to be removed is $certAlias

    result=`keytool -list -noprompt -storepass changeit -keystore $keyStore | egrep $certAlias`

    # remove the existing certificate by it's alias if it's there
    # otherwise it will throw an error that the alias already exists inthe keystore

    if [[ ${#result} != 0 ]]
	then
	chmod 0644 $keyStore
        keytool -delete -noprompt -storepass changeit -keystore $keyStore -alias $certAlias
	chmod 04440 $keyStore     
	#echo removing $certAlias certificate from keystore
	result=`keytool -list -noprompt -storepass changeit -keystore $keyStore | egrep $certAlias`

	if [[ ${#result} == 0 ]]
	    then
	    echo "removed $certAlias from keystore"
	fi
    else
	echo "alias $certAlias was not in keystore"
    fi


    exit 0;

### eof
