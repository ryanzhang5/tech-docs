/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.common;

import com.wm.dal.router.IRouter;
import com.wm.dal.router.IRouterRequest;
import com.wm.dal.router.IRouterResponse;

import java.util.Properties;

/**
 * MockRouter
 *
 * @author mkishore
 * @version $Revision: 1.3 $
 * @since 4/2009
 */
public class MockRouter implements IRouter {
    private String name;
    private boolean enabled;
    private long refreshInterval;

    public void refresh() {
        // no-op
    }

    public void route(IRouterRequest req, IRouterResponse res) {
        // no-op
    }

    // GETTERS and SETTERS

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean routerEnabled) {
        this.enabled = routerEnabled;
    }

    public long getRefreshInterval() {
        return refreshInterval;
    }

    public void setRefreshInterval(long refreshInterval) {
        this.refreshInterval = refreshInterval;
    }

}
