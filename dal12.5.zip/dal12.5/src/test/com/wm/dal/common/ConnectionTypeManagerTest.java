/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.common;

import org.testng.annotations.Test;
import org.testng.Assert;
import com.wm.dal.common.ConnectionTypeManager;
import com.wm.dal.router.IRouter;
import com.wm.dal.router.plugins.default_.DefaultRouter;
import com.wm.dal.router.plugins.default_.RoutingRule;

import java.util.List;
import java.sql.SQLException;

/**
 * ConnectionTypeManagerTest
 *
 * @author mkishore
 * @version $Revision: 1.6 $
 * @since 4/2009
 */
public class ConnectionTypeManagerTest {
    @Test
    public void testConfigFileLoading() {
        ConnectionTypeManager mgr = new ConnectionTypeManager("/com/wm/dal/common/test-connection-types.xml");
        ConnectionType ctype = null;
        try {
            ctype = mgr.getConnectionType("catalog-2", "web_user", "web_user");
        } catch (SQLException e) {
            Assert.fail("error while getting connection type", e);
        }
        Assert.assertNotNull(ctype);
        List<? extends IRouter> routers = ctype.getRouterList();
        Assert.assertNotNull(routers);
        Assert.assertEquals(routers.size(), 1);
        IRouter router = routers.get(0);
        Assert.assertNotNull(router);
        Assert.assertEquals(router.getRefreshInterval(), 100);

        try {
            ctype = mgr.getConnectionType("catalog-3", "web_user", "web_user");
        } catch (SQLException e) {
            Assert.fail("error while getting connection type", e);
        }
        Assert.assertNotNull(ctype);
        routers = ctype.getRouterList();
        Assert.assertNotNull(routers);
        Assert.assertEquals(routers.size(), 1);
        router = routers.get(0);
        Assert.assertNotNull(router);
        Assert.assertEquals(router.getName(), "default-router");
        Assert.assertEquals(router.isEnabled(), true);
        Assert.assertTrue(router instanceof DefaultRouter);
        router.refresh();
    }
}
