package com.wm.dal.jta;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public abstract class BaseTestCase {

    public static final String PUREDATASOURCE1 = "dalpoolMysqlDS";
    public static final String PUREDATASOURCE2 = "dalpoolOracleDS";

    protected static ApplicationContext applicationContext2 = null;
    protected static DataSource pureDataSource1 = null;
    protected static DataSource pureDataSource2 = null;

    protected static String MYSQL_SCHEMA_NAME = "test";

    static {
        try {
            if (applicationContext2 == null) {
                applicationContext2 = new ClassPathXmlApplicationContext("/com/wm/dal/jta/test-jta-beans.xml");
            }
            if (pureDataSource1 == null) {
                pureDataSource1 = (DataSource) applicationContext2.getBean(PUREDATASOURCE1);
            }
            if (pureDataSource2 == null) {
                pureDataSource2 = (DataSource) applicationContext2.getBean(PUREDATASOURCE2);
            }
        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
    }

    public BaseTestCase() {
        if (applicationContext2 != null) {
            initialize((BaseTestCase) applicationContext2.getBean("jta" + this.getClass().getSimpleName()));
        }
    }

    protected List<Connection> conList = new ArrayList<Connection>();

    protected void initialize(BaseTestCase copy) {
        this.setDS1(copy.getDS1());
        this.setDS2(copy.getDS2());
        this.setTxManager(copy.getTxManager());
    }

    protected void addConnections(Connection con) {
        conList.add(con);
    }

    protected void safeClose(Connection con) {
        try {
            if (con != null) {
                con.close();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    protected void clearConnections() {

        for (Connection aConList : conList) {
            safeClose(aConList);
        }
        conList.clear();
    }

    protected DataSource DS1;
    protected DataSource DS2;

    protected PlatformTransactionManager txManager;

    public DataSource getDS1() {
        return DS1;
    }

    public void setDS1(DataSource DS1) {
        this.DS1 = DS1;
    }

    public DataSource getDS2() {
        return DS2;
    }

    public void setDS2(DataSource DS2) {
        this.DS2 = DS2;
    }

    public PlatformTransactionManager getTxManager() {
        return txManager;
    }

    public void setTxManager(PlatformTransactionManager txManager) {
        this.txManager = txManager;
    }


}
