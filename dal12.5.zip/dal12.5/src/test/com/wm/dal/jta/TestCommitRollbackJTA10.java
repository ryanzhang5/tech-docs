package com.wm.dal.jta;

import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.sql.*;
import java.util.logging.Logger;

//@Test(sequential = true)
public class TestCommitRollbackJTA10 extends BaseTestCase {

	private Logger logger = Logger.getLogger(TestCommitRollbackJTA10.class
			.getName());

	private static String TABLE_NAME = "itemtbl_testcommitrollback10";

	@Test(groups = { "oracle", "create" })
	public void testCreate() {

		Connection con2 = null;
		Statement stmt2 = null;
		ResultSet rs2 = null;

		String seleSql = "SELECT count(*) as table_num FROM user_tables WHERE lower(table_name)='"
				+ TABLE_NAME + "'";
		String dropTablSql = "DROP TABLE " + TABLE_NAME;
		String creaTablSql = "CREATE TABLE " + TABLE_NAME + "("
				+ "var_string VARCHAR2(10) default NULL" + ")";
		try {
			logger.info("begin to create itemtbl table.");
			con2 = pureDataSource2.getConnection();
			stmt2 = con2.createStatement();
			int num = 0;
			rs2 = stmt2.executeQuery(seleSql);
			while (rs2.next()) {
				num = rs2.getInt(1);
			}
			if (num > 0) {
				stmt2.execute(dropTablSql);
			}
			stmt2.execute(creaTablSql);
			logger.info("itemtbl table is created.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt2 != null)
					stmt2.close();
				if (con2 != null)
					con2.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForCreateOracle();
	}

	@Test(dependsOnMethods = "testCreate", groups = { "oracle", "insert" })
	public void testFailureInsert() {

		Connection con2 = null; // Oracle Connection
		PreparedStatement pstm2 = null; // Oracle Statement
		DefaultTransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = txManager.getTransaction(def);

		String oracInsrSql = "INSERT INTO " + TABLE_NAME + " (var_string) "
				+ " VALUES " + " (?)";

		try {
			logger.info("begin to insert itemtbl data.");

			con2 = this.DS2.getConnection();

			pstm2 = con2.prepareStatement(oracInsrSql);

			pstm2.setString(1, "HelloWorld!");
			pstm2.executeUpdate();

			txManager.commit(status);
			logger.info("itemtbl data are inserted.");
		} catch (Exception e) {
			e.printStackTrace();
			txManager.rollback(status);

		} finally {
			try {
				if (pstm2 != null)
					pstm2.close();
				this.safeClose(con2);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForFailureInsertOracle();
	}

	@Test(dependsOnMethods = "testFailureInsert", groups = { "oracle", "insert" })
	public void testSuccessInsert() {

		Connection con2 = null; // Oracle Connection
		PreparedStatement pstm2 = null; // Oracle Statement
		DefaultTransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = txManager.getTransaction(def);

		String oracInsrSql = "INSERT INTO " + TABLE_NAME + " (var_string) "
				+ " VALUES " + " (?)";

		try {
			logger.info("begin to insert itemtbl data.");

			con2 = this.DS2.getConnection();

			pstm2 = con2.prepareStatement(oracInsrSql);

			pstm2.setString(1, "HelloWorld");

			pstm2.executeUpdate();

			txManager.commit(status);

			logger.info("itemtbl data are inserted.");
		} catch (Exception e) {
			e.printStackTrace();
			txManager.rollback(status);

		} finally {
			try {
				if (pstm2 != null)
					pstm2.close();
				this.safeClose(con2);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		testQueryForSuccessInsertOracle();
	}

	@Test(dependsOnMethods = "testSuccessInsert", groups = { "oracle", "delete" })
	public void testDelete() {

		Connection con2 = null; // Oracle Connection
		Statement stmt2 = null; // Oracle Statement
		TransactionStatus status = txManager
				.getTransaction(new DefaultTransactionDefinition());

		String dropTablSql = "DELETE FROM " + TABLE_NAME;
		try {
			logger.info("begin to delete itemtbl data.");
			con2 = this.DS2.getConnection();

			stmt2 = con2.createStatement();
			stmt2.execute(dropTablSql);

			txManager.commit(status);

			logger.info("data of itemtbl table is deleted.");

		} catch (Exception e) {
			e.printStackTrace();
			txManager.rollback(status);
		} finally {
			try {
				if (stmt2 != null)
					stmt2.close();
				this.safeClose(con2);
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		this.testQueryForDeleteOracle();
	}

	@Test(dependsOnMethods = "testDelete", groups = { "oracle", "drop" })
	public void testDrop() {

		Connection con2 = null; // Oracle Connection
		Statement stmt2 = null; // Oracle Statement
		String dropTablSqlOracle = "DROP TABLE " + TABLE_NAME;

		try {
			logger.info("begin to drop itemtbl table.");

			con2 = pureDataSource2.getConnection();
			stmt2 = con2.createStatement();
			stmt2.execute(dropTablSqlOracle);
			logger.info("itemtbl table is dropped.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt2 != null)
					stmt2.close();
				if (con2 != null)
					con2.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForDropOracle();
	}

	public void testQueryForSuccessInsertOracle() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " count(*) " + " FROM " + TABLE_NAME;

		try {
			logger.info("begin to retrieve itemtbl data.");

			con = this.DS2.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();

			int rowNum = 0;
			if (rs.next()) {
				rowNum = rs.getInt(1);
			}
			Assert.assertEquals(rowNum, 1);

			logger.info("itemtbl data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForFailureInsertOracle() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " count(*) " + " FROM " + TABLE_NAME;

		try {
			logger.info("begin to retrieve itemtbl data.");

			con = this.DS2.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();

			int rowNum = 0;
			if (rs.next()) {
				rowNum = rs.getInt(1);
			}
			Assert.assertEquals(rowNum, 0);

			logger.info("itemtbl data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForDeleteOracle() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " count(*) " + " FROM " + TABLE_NAME;

		try {
			logger.info("begin to retrieve itemtbl data.");

			con = this.DS2.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			int rowNum = 0;
			if (rs.next()) {
				rowNum = rs.getInt(1);
			}
			Assert.assertEquals(rowNum, 0);
			logger.info("itemtbl data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForCreateOracle() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT count(*) as table_num FROM user_tables WHERE lower(table_name)='"
				+ TABLE_NAME + "'";

		try {
			logger.info("begin to retrieve user_table data.");

			con = this.DS2.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				int num = rs.getInt(1);
				Assert.assertEquals(num, 1);
			}
			logger.info("user_table data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void testQueryForDropOracle() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT count(*) as table_num FROM user_tables WHERE lower(table_name)='"
				+ TABLE_NAME + "'";

		try {
			logger.info("begin to retrieve user_table data.");

			con = this.DS2.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				int num = rs.getInt(1);
				Assert.assertEquals(num, 0);
			}
			logger.info("user_table data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
