package com.wm.dal.jta;

import com.wm.dal.jdbc.DALConnection;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.sql.*;
import java.util.logging.Logger;

//@Test(sequential = true)
public class TestCommitRollbackJTA2 extends BaseTestCase {

	private Logger logger = Logger.getLogger(TestCommitRollbackJTA1.class
			.getName());

	private static String TABLE_NAME = "itemtbl_testcommitrollback2";

	@Test(groups = { "mysql", "oracle", "create" })
	public void testCreate() {

		Connection con1 = null;
		Connection con2 = null;
		Statement stmt1 = null;
		Statement stmt2 = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;

		String dropTablSql = "DROP TABLE IF EXISTS " + TABLE_NAME;
		String creaTablSql = "CREATE TABLE " + TABLE_NAME + "("
				+ "var_string varchar(10) default NULL"
				+ ") ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		try {
			logger.info("begin to create itemtbl table.");
			con1 = pureDataSource1.getConnection();
			stmt1 = con1.createStatement();
			stmt1.execute(dropTablSql);
			stmt1.execute(creaTablSql);
			logger.info("itemtbl table is created.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt1 != null)
					stmt1.close();
				if (con1 != null)
					con1.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		String seleSql = "SELECT count(*) as table_num FROM user_tables WHERE lower(table_name)='"
				+ TABLE_NAME + "'";
		dropTablSql = "DROP TABLE " + TABLE_NAME;
		creaTablSql = "CREATE TABLE " + TABLE_NAME + "("
				+ "var_string VARCHAR2(10) default NULL" + ")";
		try {
			logger.info("begin to create itemtbl table.");
			con2 = pureDataSource2.getConnection();
			stmt2 = con2.createStatement();
			int num = 0;
			rs2 = stmt2.executeQuery(seleSql);
			while (rs2.next()) {
				num = rs2.getInt(1);
			}
			if (num > 0) {
				stmt2.execute(dropTablSql);
			}
			stmt2.execute(creaTablSql);
			logger.info("itemtbl table is created.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt2 != null)
					stmt2.close();
				if (con2 != null)
					con2.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		testQueryForCreateMysql();
		testQueryForCreateOracle();
	}

	@Test(dependsOnMethods = "testCreate", groups = { "mysql", "oracle",
			"insert" })
	public void testFailureInsert() {

		Connection con1 = null; // Mysql Connection
		Connection con2 = null; // Oracle Connection
		PreparedStatement pstm1 = null; // Mysql Statement
		PreparedStatement pstm2 = null; // Oracle Statement
		TransactionStatus status = txManager
				.getTransaction(new DefaultTransactionDefinition());

		String mysqInsrSql = "INSERT INTO " + TABLE_NAME + " (var_string) "
				+ " VALUES " + " (?)";

		String oracInsrSql = "INSERT INTO " + TABLE_NAME + " (var_string) "
				+ " VALUES " + " (?)";

		try {
			logger.info("begin to insert itemtbl data.");

			con1 = this.DS1.getConnection();
			con2 = this.DS2.getConnection();

			pstm1 = con1.prepareStatement(mysqInsrSql);
			pstm2 = con2.prepareStatement(oracInsrSql);

			pstm1.setString(1, "HelloWorld!");
			pstm1.executeUpdate();

			pstm2.setString(1, "HelloWorld!");
			pstm2.executeUpdate();

			txManager.commit(status);

			logger.info("itemtbl data are inserted.");
		} catch (Exception e) {
			e.printStackTrace();
			txManager.rollback(status);
		} finally {
			try {
				if (pstm1 != null)
					pstm1.close();
				if (pstm2 != null)
					pstm2.close();
				this.safeClose(con1);
				this.safeClose(con2);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForFailureInsertMysql();
		testQueryForFailureInsertOracle();
	}

	@Test(dependsOnMethods = "testFailureInsert", groups = { "mysql", "oracle",
			"insert" })
	public void testSuccessInsert() {

		Connection con1 = null; // Mysql Connection
		Connection con2 = null; // Oracle Connection
		PreparedStatement pstm1 = null; // Mysql Statement
		PreparedStatement pstm2 = null; // Oracle Statement
		TransactionStatus status = txManager
				.getTransaction(new DefaultTransactionDefinition());

		String mysqInsrSql = "INSERT INTO " + TABLE_NAME + " (var_string) "
				+ " VALUES " + " (?)";

		String oracInsrSql = "INSERT INTO " + TABLE_NAME + " (var_string) "
				+ " VALUES " + " (?)";

		try {
			logger.info("begin to insert itemtbl data.");

			con1 = this.DS1.getConnection();
			con2 = this.DS2.getConnection();

			pstm1 = con1.prepareStatement(mysqInsrSql);
			pstm2 = con2.prepareStatement(oracInsrSql);

			pstm1.setString(1, "HelloWorld");
			pstm1.executeUpdate();

			pstm2.setString(1, "HelloWorld");
			pstm2.executeUpdate();

			txManager.commit(status);

			logger.info("itemtbl data are inserted.");
		} catch (Exception e) {
			e.printStackTrace();
			txManager.rollback(status);
		} finally {
			try {
				if (pstm1 != null)
					pstm1.close();
				if (pstm2 != null)
					pstm2.close();
				this.safeClose(con1);
				this.safeClose(con2);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		testQueryForSuccessInsertMysql();
		testQueryForSuccessInsertOracle();
	}

	@Test(dependsOnMethods = "testSuccessInsert", groups = { "mysql", "oracle",
			"drop" })
	public void testDrop() {

		Connection con1 = null; // Mysql Connection
		Connection con2 = null; // Oracle Connection
		Statement stmt1 = null; // Mysql Statement
		Statement stmt2 = null; // Oracle Statement
		String dropTablSqlMysql = "DROP TABLE " + TABLE_NAME;
		String dropTablSqlOracle = "DROP TABLE " + TABLE_NAME;

		try {
			logger.info("begin to drop itemtbl table.");

			con1 = pureDataSource1.getConnection();
			stmt1 = con1.createStatement();
			stmt1.execute(dropTablSqlMysql);
			logger.info("itemtbl table is dropped.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt1 != null)
					stmt1.close();
				if (con1 != null)
					con1.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		try {
			logger.info("begin to drop itemtbl table.");

			con2 = pureDataSource2.getConnection();
			stmt2 = con2.createStatement();
			stmt2.execute(dropTablSqlOracle);
			logger.info("itemtbl table is dropped.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt2 != null)
					stmt2.close();
				if (con2 != null)
					con2.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForDropMysql();
		testQueryForDropOracle();
	}

	public void testQueryForSuccessInsertMysql() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " count(*) " + " FROM " + TABLE_NAME;

		try {
			logger.info("begin to retrieve itemtbl data.");

			con = pureDataSource1.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();

			int rowNum = 0;
			if (rs.next()) {
				rowNum = rs.getInt(1);
			}
			Assert.assertEquals(rowNum, 1);

			logger.info("itemtbl data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForSuccessInsertOracle() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " count(*) " + " FROM " + TABLE_NAME;

		try {
			logger.info("begin to retrieve itemtbl data.");

			con = pureDataSource2.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();

			int rowNum = 0;
			if (rs.next()) {
				rowNum = rs.getInt(1);
			}
			Assert.assertEquals(rowNum, 1);

			logger.info("itemtbl data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForFailureInsertMysql() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " count(*) " + " FROM " + TABLE_NAME;

		try {
			logger.info("begin to retrieve itemtbl data.");

			con = pureDataSource1.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();

			int rowNum = 0;
			if (rs.next()) {
				rowNum = rs.getInt(1);
			}
			Assert.assertEquals(rowNum, 0);

			logger.info("itemtbl data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForFailureInsertOracle() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " count(*) " + " FROM " + TABLE_NAME;

		try {
			logger.info("begin to retrieve itemtbl data.");

			con = pureDataSource2.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();

			int rowNum = 0;
			if (rs.next()) {
				rowNum = rs.getInt(1);
			}
			Assert.assertEquals(rowNum, 0);

			logger.info("itemtbl data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForDeleteMysql() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " count(*) " + " FROM " + TABLE_NAME;

		try {
			logger.info("begin to retrieve itemtbl data.");

			con = pureDataSource1.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			int rowNum = 0;
			if (rs.next()) {
				rowNum = rs.getInt(1);
			}
			Assert.assertEquals(rowNum, 0);
			logger.info("itemtbl data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForDeleteOracle() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " count(*) " + " FROM " + TABLE_NAME;

		try {
			logger.info("begin to retrieve itemtbl data.");

			con = pureDataSource2.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			int rowNum = 0;
			if (rs.next()) {
				rowNum = rs.getInt(1);
			}
			Assert.assertEquals(rowNum, 0);
			logger.info("itemtbl data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForCreateMysql() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = " select count(*) as table_num "
				+ " from information_schema.tables " + " where table_name='"
				+ TABLE_NAME + "' and table_schema='" + MYSQL_SCHEMA_NAME + "'";

		try {
			logger.info("begin to retrieve table existence data.");

			con = pureDataSource1.getConnection();
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~"
					+ (con instanceof DALConnection));
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				int num = rs.getInt(1);
				Assert.assertEquals(num, 1);
			}
			logger.info("table existence data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForCreateOracle() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT count(*) as table_num FROM user_tables WHERE lower(table_name)='"
				+ TABLE_NAME + "'";

		try {
			logger.info("begin to retrieve user_table data.");

			con = pureDataSource2.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				int num = rs.getInt(1);
				Assert.assertEquals(num, 1);
			}
			logger.info("user_table data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForDropMysql() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = " select count(*) as table_num "
				+ " from information_schema.tables " + " where table_name='"
				+ TABLE_NAME + "' and table_schema='" + MYSQL_SCHEMA_NAME + "'";

		try {
			logger.info("begin to retrieve table existence data.");

			con = pureDataSource1.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				int num = rs.getInt(1);
				Assert.assertEquals(num, 0);
			}
			logger.info("table existence data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForDropOracle() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT count(*) as table_num FROM user_tables WHERE lower(table_name)='"
				+ TABLE_NAME + "'";

		try {
			logger.info("begin to retrieve user_table data.");

			con = pureDataSource2.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				int num = rs.getInt(1);
				Assert.assertEquals(num, 0);
			}
			logger.info("user_table data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
