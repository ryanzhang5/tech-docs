/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.conditions;

import org.testng.annotations.Test;
import org.testng.Assert;
import com.wm.dal.router.plugins.default_.RouterContext;
import com.wm.dal.router.RouterRequest;
import com.wm.dal.router.RouterResponse;
import com.wm.dal.common.DALSession;

/**
 * ClientHostConditionTest
 *
 * @author mkishore
 * @since 1.0
 */
@Test
public class ClientHostConditionTest {

    private RouterContext getRouterContext(String sessionId, String clientId) {
        return new RouterContext(new RouterRequest(new DALSession(sessionId, clientId)), new RouterResponse());
    }

    public void testRegex() {
        ClientHostCondition condition = new ClientHostCondition();
        condition.setRegex("ndc.*");
        condition.initialize();

        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "ndc-www1")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "edc-www1")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "myndctest")));
    }

    public void testMax() {
        ClientHostCondition condition = new ClientHostCondition();
        condition.setMax(20);
        condition.initialize();

        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "10")));
        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "20")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "21")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "edc-www1")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "edc-www11")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "edc-www21")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "ndc-www15-test")));
    }

    public void testPrefixMax() {
        ClientHostCondition condition = new ClientHostCondition();
        condition.setPrefix("(?:n|e)dc-www"); // using non-capturing group
        condition.setMax(20);
        condition.initialize();

        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "ndc-www10")));
        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "ndc-www15")));
        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "ndc-www20")));
        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "ndc-www9")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "ndc-www21")));
        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "edc-www1")));
        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "edc-www11")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "edc-www21")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "ndc-www15-test")));
    }

    public void testPrefixMinMax() {
        ClientHostCondition condition = new ClientHostCondition();
        condition.setPrefix("ndc-www");
        condition.setMin(10);
        condition.setMax(20);
        condition.initialize();

        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "ndc-www10")));
        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "ndc-www15")));
        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "ndc-www20")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "ndc-www9")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "ndc-www21")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "edc-www1")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "edc-www11")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "edc-www21")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "ndc-www15-test")));
    }

    public void testMinSuffix() {
        ClientHostCondition condition = new ClientHostCondition();
        condition.setMin(10);
        condition.setSuffix("-[tr]est.*"); // using character group
        condition.initialize();

        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "10-test")));
        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "15-test")));
        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "20-test")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "9-test")));
        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "2000-test")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "1-rest")));
        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "11-rest")));
        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "2000-rest")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "ndc-www15-test")));
        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "15-test-long-string")));
    }

    public void testMinMaxSuffix() {
        ClientHostCondition condition = new ClientHostCondition();
        condition.setMin(10);
        condition.setMax(20);
        condition.setSuffix("-test");
        condition.initialize();

        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "10-test")));
        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "15-test")));
        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "20-test")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "9-test")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "21-test")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "1-rest")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "11-rest")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "21-rest")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "ndc-www15-test")));
    }

    public void testPrefixMinMaxSuffix() {
        ClientHostCondition condition = new ClientHostCondition();
        condition.setPrefix("ndc-www");
        condition.setMin(10);
        condition.setMax(20);
        condition.setSuffix(".walmart.com");
        condition.initialize();

        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "ndc-www10.walmart.com")));
        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "ndc-www15.walmart.com")));
        Assert.assertTrue(condition.evaluate(getRouterContext("sid", "ndc-www20.walmart.com")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "ndc-www9.walmart.com")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "ndc-www21.walmart.com")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "edc-www1.walmart.com")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "edc-www11.walmart.com")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "edc-www21.walmart.com")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "ndc-www15.yahoo.com")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "ndc-www15")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "15.walmart.com")));
        Assert.assertFalse(condition.evaluate(getRouterContext("sid", "15")));
    }

}
