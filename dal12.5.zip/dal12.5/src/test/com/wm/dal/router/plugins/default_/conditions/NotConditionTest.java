/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.conditions;

import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * NotConditionTest
 *
 * @author mkishore
 * @version $Revision: 1.1 $
 * @since 1.0
 */
@Test
public class NotConditionTest {
    private static final Object CONTEXT = "context";

    public void testMT() {
        NotCondition condition = new NotCondition();
        Assert.assertTrue(condition.evaluate(CONTEXT));
    }

    public void testT() {
        NotCondition condition = new NotCondition();
        condition.getConditions().add(new MockCondition(true));
        Assert.assertFalse(condition.evaluate(CONTEXT));
    }

    public void testF() {
        NotCondition condition = new NotCondition();
        condition.getConditions().add(new MockCondition(false));
        Assert.assertTrue(condition.evaluate(CONTEXT));
    }

    public void testTT() {
        NotCondition condition = new NotCondition();
        condition.getConditions().add(new MockCondition(true));
        condition.getConditions().add(new MockCondition(true));
        Assert.assertFalse(condition.evaluate(CONTEXT));
    }

    public void testTF() {
        NotCondition condition = new NotCondition();
        condition.getConditions().add(new MockCondition(true));
        condition.getConditions().add(new MockCondition(false));
        Assert.assertFalse(condition.evaluate(CONTEXT));
    }

    public void testFT() {
        NotCondition condition = new NotCondition();
        condition.getConditions().add(new MockCondition(false));
        condition.getConditions().add(new MockCondition(true));
        Assert.assertFalse(condition.evaluate(CONTEXT));
    }

    public void testFF() {
        NotCondition condition = new NotCondition();
        condition.getConditions().add(new MockCondition(false));
        condition.getConditions().add(new MockCondition(false));
        Assert.assertTrue(condition.evaluate(CONTEXT));
    }

}