/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.conditions;

import com.wm.dal.router.plugins.default_.ICondition;

/**
 * MockCondition
 *
 * @author mkishore
 * @version $Revision: 1.1 $
 * @since 1.0
 */
public class MockCondition<T> implements ICondition<T> {
    private boolean value;

    public MockCondition(boolean value) {
        this.value = value;
    }

    public void initialize() throws IllegalStateException {
        // no-op
    }

    public boolean evaluate(T context) {
        return value;
    }
}
