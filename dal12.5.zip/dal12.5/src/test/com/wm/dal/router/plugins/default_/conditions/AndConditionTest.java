/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.conditions;

import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * AndConditionTest
 *
 * @author mkishore
 * @version $Revision: 1.1 $
 * @since 1.0
 */
@Test
public class AndConditionTest {
    private static final Object CONTEXT = "context";

    public void testMT() {
        AndCondition condition = new AndCondition();
        Assert.assertTrue(condition.evaluate(CONTEXT));
    }

    public void testT() {
        AndCondition condition = new AndCondition();
        condition.getConditions().add(new MockCondition(true));
        Assert.assertTrue(condition.evaluate(CONTEXT));
    }

    public void testF() {
        AndCondition condition = new AndCondition();
        condition.getConditions().add(new MockCondition(false));
        Assert.assertFalse(condition.evaluate(CONTEXT));
    }

    public void testTT() {
        AndCondition condition = new AndCondition();
        condition.getConditions().add(new MockCondition(true));
        condition.getConditions().add(new MockCondition(true));
        Assert.assertTrue(condition.evaluate(CONTEXT));
    }

    public void testTF() {
        AndCondition condition = new AndCondition();
        condition.getConditions().add(new MockCondition(true));
        condition.getConditions().add(new MockCondition(false));
        Assert.assertFalse(condition.evaluate(CONTEXT));
    }

    public void testFT() {
        AndCondition condition = new AndCondition();
        condition.getConditions().add(new MockCondition(false));
        condition.getConditions().add(new MockCondition(true));
        Assert.assertFalse(condition.evaluate(CONTEXT));
    }

    public void testFF() {
        AndCondition condition = new AndCondition();
        condition.getConditions().add(new MockCondition(false));
        condition.getConditions().add(new MockCondition(false));
        Assert.assertFalse(condition.evaluate(CONTEXT));
    }

}