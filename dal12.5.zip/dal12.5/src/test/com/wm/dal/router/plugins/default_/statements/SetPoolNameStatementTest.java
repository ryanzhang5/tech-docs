/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.statements;

import com.wm.dal.common.DALSession;
import com.wm.dal.router.RouterRequest;
import com.wm.dal.router.RouterResponse;
import com.wm.dal.router.plugins.default_.IStatement;
import com.wm.dal.router.plugins.default_.RouterContext;
import com.wm.dal.router.plugins.default_.conditions.MockCondition;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * IfConditionTest
 *
 * @author mkishore
 * @since 1.0
 */
@Test
public class SetPoolNameStatementTest {
    private static final RouterContext CONTEXT = new RouterContext(new RouterRequest(new DALSession("session-id", "client-id")), new RouterResponse());

    public void testSetValue() {
        SetPoolNameStatement stmt = new SetPoolNameStatement();
        stmt.setValue("s1");
        stmt.initialize();
        
        IStatement.Status status = stmt.execute(CONTEXT);
        Assert.assertEquals(status, IStatement.Status.CONTINUE);
        Assert.assertEquals(CONTEXT.getResponse().getPoolName(), "s1");
    }

}