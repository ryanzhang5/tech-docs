/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_;

import com.wm.dal.common.ConnectionType;
import com.wm.dal.router.plugins.default_.rulesproviders.FileBasedRulesProvider;
import org.springframework.core.io.ClassPathResource;
import org.testng.annotations.Test;
import org.testng.Assert;

import java.util.Collections;
import java.util.List;

/**
 * RoutingRulesParserTest
 *
 * @author mkishore
 * @since 1.0
 */
@Test
public class DefaultRouterTest {

    public void testRefresh() {
        DefaultRouter router = new DefaultRouter();
        router.setName("router");
        router.setEnabled(true);
        // you need to change the MIN_REFRESH_INTERVAL in the ConnectionType!!
        router.setRefreshInterval(5000);
        FileBasedRulesProvider provider = new FileBasedRulesProvider();
        provider.setConfigFile(new ClassPathResource("routing-rules.xml", DefaultRouterTest.class));
        router.setRoutingRulesProviders(Collections.singletonList((IRoutingRulesProvider)provider));
        router.refresh();
        List<RoutingRule> routingRuleList = router.getRoutingRules();
        Assert.assertNotNull(routingRuleList);
        Assert.assertFalse(routingRuleList.isEmpty());

        /*
        try {
            System.out.println("The thread will sleep for 5 minutes. Please copy/touch the file and verify that it gets refreshed");
            Thread.sleep(5*60*1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        */
    }
}