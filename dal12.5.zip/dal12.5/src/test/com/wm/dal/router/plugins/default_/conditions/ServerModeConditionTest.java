/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.conditions;

import org.testng.annotations.Test;
import org.testng.Assert;
import com.wm.dal.router.plugins.default_.RouterContext;
import com.wm.dal.router.RouterRequest;
import com.wm.dal.router.RouterResponse;
import com.wm.dal.common.DALSession;
import com.wm.dal.jdbc.utils.MethodAttribute;

/**
 * ServerModeConditionTest
 *
 * @author mkishore
 * @since 1.0
 */
@Test
public class ServerModeConditionTest {

    private RouterContext getRouterContext(String sessionId, String clientId) {
        return new RouterContext(new RouterRequest(new DALSession(sessionId, clientId)), new RouterResponse());
    }

    public void testServerMode() {
        ServerModeCondition condition = new ServerModeCondition();
        condition.initialize();

        RouterContext context = getRouterContext("sid", "ndc-www1");
        context.getRequest().getSession().setConnectionAttribute(MethodAttribute.SERVER_MODE, new MethodAttribute(Boolean.TRUE));
        Assert.assertTrue(condition.evaluate(context));
    }

    public void testClientMode() {
        ServerModeCondition condition = new ServerModeCondition();
        condition.initialize();

        RouterContext context = getRouterContext("sid", "ndc-www1");
        context.getRequest().getSession().setConnectionAttribute(MethodAttribute.SERVER_MODE, new MethodAttribute(Boolean.FALSE));
        Assert.assertFalse(condition.evaluate(context));
    }

    public void testNull() {
        ServerModeCondition condition = new ServerModeCondition();
        condition.initialize();

        RouterContext context = getRouterContext("sid", "ndc-www1");
        Assert.assertFalse(condition.evaluate(context));
    }


}