/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.statements;

import com.wm.dal.common.DALSession;
import com.wm.dal.router.RouterRequest;
import com.wm.dal.router.RouterResponse;
import com.wm.dal.router.plugins.default_.IStatement;
import com.wm.dal.router.plugins.default_.RouterContext;
import com.wm.dal.router.plugins.default_.conditions.MockCondition;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * IfConditionTest
 *
 * @author mkishore
 * @since 1.0
 */
@Test
public class IfStatementTest {
    private static final RouterContext CONTEXT = new RouterContext(new RouterRequest(new DALSession("session-id", "client-id")), new RouterResponse());

    public void testThen() {
        IfStatement<RouterContext> stmt = new IfStatement<RouterContext>();
        stmt.setCondition(new MockCondition<RouterContext>(true));
        SetPoolNameStatement thenStmt = new SetPoolNameStatement();
        thenStmt.setValue("then");
        stmt.getThenStatements().add(thenStmt);
        SetPoolNameStatement elseStmt = new SetPoolNameStatement();
        elseStmt.setValue("else");
        stmt.getElseStatements().add(elseStmt);
        IStatement.Status status = stmt.execute(CONTEXT);
        Assert.assertEquals(status, IStatement.Status.CONTINUE);
        Assert.assertEquals(CONTEXT.getResponse().getPoolName(), "then");
    }

    public void testElse() {
        IfStatement<RouterContext> stmt = new IfStatement<RouterContext>();
        stmt.setCondition(new MockCondition<RouterContext>(false));
        SetPoolNameStatement thenStmt = new SetPoolNameStatement();
        thenStmt.setValue("then");
        stmt.getThenStatements().add(thenStmt);
        SetPoolNameStatement elseStmt = new SetPoolNameStatement();
        elseStmt.setValue("else");
        stmt.getElseStatements().add(elseStmt);
        IStatement.Status status = stmt.execute(CONTEXT);
        Assert.assertEquals(status, IStatement.Status.CONTINUE);
        Assert.assertEquals(CONTEXT.getResponse().getPoolName(), "else");
    }

    public void testBreak() {
        IfStatement<RouterContext> stmt = new IfStatement<RouterContext>();
        stmt.setCondition(new MockCondition<RouterContext>(true));
        SetPoolNameStatement s1 = new SetPoolNameStatement();
        s1.setValue("s1");
        BreakStatement br = new BreakStatement();
        SetPoolNameStatement s2 = new SetPoolNameStatement();
        s2.setValue("s2");
        stmt.getThenStatements().add(s1);
        stmt.getThenStatements().add(br);
        stmt.getElseStatements().add(s2);
        IStatement.Status status = stmt.execute(CONTEXT);
        Assert.assertEquals(status, IStatement.Status.BREAK);
        Assert.assertEquals(CONTEXT.getResponse().getPoolName(), "s1");
    }

    public void testReturn() {
        IfStatement<RouterContext> stmt = new IfStatement<RouterContext>();
        stmt.setCondition(new MockCondition<RouterContext>(true));
        SetPoolNameStatement s1 = new SetPoolNameStatement();
        s1.setValue("s1");
        ReturnStatement rt = new ReturnStatement();
        SetPoolNameStatement s2 = new SetPoolNameStatement();
        s2.setValue("s2");
        stmt.getThenStatements().add(s1);
        stmt.getThenStatements().add(rt);
        stmt.getElseStatements().add(s2);
        IStatement.Status status = stmt.execute(CONTEXT);
        Assert.assertEquals(status, IStatement.Status.RETURN);
        Assert.assertEquals(CONTEXT.getResponse().getPoolName(), "s1");
    }

}