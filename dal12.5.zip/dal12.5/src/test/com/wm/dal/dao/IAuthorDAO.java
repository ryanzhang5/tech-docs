package com.wm.dal.dao;

public interface IAuthorDAO extends IBaseDAO<Author, Integer> {
}