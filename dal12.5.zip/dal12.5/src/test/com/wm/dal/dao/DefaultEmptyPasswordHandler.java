package com.wm.dal.dao;

import com.wm.sql.EmptyPasswordHandler;

/**
 * Default handler that just returns a blank string - useful for testing
 * against in-memory hsql database (which has no password).
 */
public class DefaultEmptyPasswordHandler implements EmptyPasswordHandler {
    public String getPassword(String url, String username) {
        return "";
    }
}
