/*
 * Copyright 2010 Walmart.com. All rights reserved.
 */
package com.wm.dal.dao;

import com.bitmechanic.sql.adapters.DefaultConnectionPoolAdapter;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * HSQLConnectionPoolAdapter
 *
 * @author mkishore
 * @since 1.2.0
 */
public class HSQLConnectionPoolAdapter extends DefaultConnectionPoolAdapter {
    @Override
    public boolean isValid(Connection connection) throws SQLException {
        return connection != null && !connection.isClosed();
    }
}
