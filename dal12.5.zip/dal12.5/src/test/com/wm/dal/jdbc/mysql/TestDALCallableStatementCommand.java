package com.wm.dal.jdbc.mysql;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Copyright 2009 walmart.com. All rights reserved
 */

/**
 * @author Martin Ma
 * @since 2009-5-5
 * @version 1.0 Test JDBC Date Format on mysql with DALConnection
 */
//@Test(sequential = true)
public class TestDALCallableStatementCommand extends BaseMysqlTest {

	//@Test(groups = { "mysql" })
	public void testProcedureCreate() {
		Connection con = null;
		Statement pstm = null;
		ResultSet rs = null;
		String createSP = "" + "CREATE PROCEDURE proc_test(in input INT, out output INT) "
			+ "begin                                                    "
			+ "     set output = 2 * input;                             "
			+ "     if input = 1 then                                   "
			+ "         select input,  'only one result' ;              "
			+ "     else                                                "
			+ "         select input,  'first result' ;                 "
			+ "         select input, input+1,  'second result' ;       "
			+ "     end if;                                             "
			+ "end;                                                     ";

		try {
			String dropSP = "DROP PROCEDURE IF EXISTS proc_test;";
			con = dataSource.getConnection();
			pstm = con.createStatement();
			pstm.executeUpdate(dropSP);
			con.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		try {
			logger.info("creating PROCEDURE proc_test");
			con = dataSource.getConnection();
			pstm = con.createStatement();
			pstm.executeUpdate(createSP);
			con.commit();
			logger.info("created  PROCEDURE proc_test");

		} catch (SQLException sqle) {
			sqle.printStackTrace();
			Assert.fail();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	//@Test(groups = { "mysql" })
	public void testProcedureCall() {
		Connection con = null;
		CallableStatement stmt = null;
		ResultSet rs = null;
		String callSP = "{ call proc_test(?,?) }";

		try {
			logger.info("calling PROCEDURE proc_test");
			con = dataSource.getConnection();
			stmt = con.prepareCall(callSP);
			stmt.setInt(1, 100);
			stmt.registerOutParameter(2, java.sql.Types.INTEGER);

			boolean hadResults = stmt.execute();
			while (hadResults) {
				rs = stmt.getResultSet();
				logger.info("ResultSet:");
				while (rs.next()) {
					int columnCount = rs.getMetaData().getColumnCount();
					String oneRow = "[";
					for (int i = 0; i < columnCount; i++) {
						oneRow += rs.getString(i + 1) + " | ";
					}
					logger.info(oneRow + "]");
				}
				hadResults = stmt.getMoreResults();
			}

			int outputValue = stmt.getInt(2);
			logger.info("\nOutParameter [int]: " + outputValue);
			Assert.assertEquals(outputValue, 200);

			con.commit();
			logger.info("called  PROCEDURE proc_test");

		} catch (SQLException sqle) {
			sqle.printStackTrace();
			Assert.fail();
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	

	// public void testCallableOthers() {
	// Connection con = null;
	// CallableStatement stmt = null;
	// ResultSet rs = null;
	// String callSP = "{ call proc_test(?,?) }";
	//
	// try {
	// logger.info("calling PROCEDURE proc_test");
	// con = dataSource.getConnection();
	// stmt = con.prepareCall(callSP);
	//			
	// logger.info("called PROCEDURE proc_test");
	//
	// } catch (SQLException sqle) {
	// sqle.printStackTrace();
	// Assert.fail();
	// } catch (Exception e) {
	// e.printStackTrace();
	// Assert.fail();
	// } finally {
	// try {
	// if (rs != null)
	// rs.close();
	// if (stmt != null)
	// stmt.close();
	// if (con != null)
	// con.close();
	// } catch (SQLException e) {
	// e.printStackTrace();
	//			}
	//		}
	//	}

}
