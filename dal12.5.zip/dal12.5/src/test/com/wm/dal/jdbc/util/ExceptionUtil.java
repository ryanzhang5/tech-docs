package com.wm.dal.jdbc.util;

import java.util.logging.Logger;

import org.testng.Assert;

public class ExceptionUtil {

	public static void handlerMethodNotImp(Exception e, Logger logger, String testingWhichMethod){
		String msg = e.getMessage();
		if(msg == null || !(e.getMessage().startsWith("Method not implemented")) ){
			e.printStackTrace();
		}else{
			logger.warning("Method not implemented -- ["+testingWhichMethod+"]");
		}
		Assert.assertEquals(true, e.getMessage().startsWith("Method not implemented")) ;		
	}
}

