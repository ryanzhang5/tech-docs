package com.wm.dal.jdbc.data;

/*
 * Created on 2006-2-5
 * @author icerain
 */

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Clob;
import java.util.Calendar;
import java.util.Currency;
import java.util.Locale;
import java.util.TimeZone;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;

import org.hibernate.annotations.Type;

@Entity(name = "Item")
// @SqlResultSetMapping(name = "getItem", entities =
// @EntityResult(name = "org.hibernate.ejb.test.Item", fields = {
// @FieldResult(name = "name", column = "itemname"),
// @FieldResult(name = "descr", column = "itemdescription")
// })
// )
// @Cache(region="Item", usage=NONSTRICT_READ_WRITE)
public class Item implements Serializable {

	private String name;
	private String descr;
	// private Set distributors;
	private Byte tinyintval; // tinyint
	private Short smallintval; // smallint
	private Integer mediumintval; // mediumint
	private Integer integerval; // integer
	private Long bigintval; // bigint
	private Float floatval; // float
	private Double doubleval; // double
	private BigDecimal decimalval; // decimal
	private Boolean bitval; // bit
	private java.sql.Date dateval; // date
	private java.util.Date datetimeval; // datetime
	private java.sql.Time timeval; // time
	private java.sql.Timestamp timestampval; // timestamp
	private Byte yearval;	// year
	private Character charval; // char
	private String varcharval; // varchar
	private byte[] binaryval; // binary, varbinary
//	private String tinytext; // tinytext
	private Clob textval; // text, mediumtext, longtext
//	private byte[] tinyblob; // tinyblob
	private Blob blobval; // blob, mediumblob, longblob
	private Calendar calendarval;
	private Calendar calendardateval;
	private Class classval;
	private Currency currencyval;
	private Locale localeval;
	private Serializable serializableval;
	private TimeZone timezoneval;
	private Boolean truefalseval;
	private Boolean yesnoval;
	
	public Item() {

	}

	public Item(String name, String desc) {
		this.name = name;
		this.descr = desc;
	}
	
	@Column
	@Type(type="byte")
	public Byte getTinyintval() {
		return tinyintval;
	}

	public void setTinyintval(Byte tinyintval) {
		this.tinyintval = tinyintval;
	}

	@Column
	@Type(type="short")
	public Short getSmallintval() {
		return smallintval;
	}

	public void setSmallintval(Short smallintval) {
		this.smallintval = smallintval;
	}

	@Column
	@Type(type="int")
	public Integer getMediumintval() {
		return mediumintval;
	}

	public void setMediumintval(Integer mediumintval) {
		this.mediumintval = mediumintval;
	}

	@Column
	@Type(type="int")
	public Integer getIntegerval() {
		return integerval;
	}

	public void setIntegerval(Integer integerval) {
		this.integerval = integerval;
	}

	@Column
	@Type(type="long")
	public Long getBigintval() {
		return bigintval;
	}

	public void setBigintval(Long bigintval) {
		this.bigintval = bigintval;
	}

	@Column
	@Type(type="float")
	public Float getFloatval() {
		return floatval;
	}

	public void setFloatval(Float floatval) {
		this.floatval = floatval;
	}

	@Column
	@Type(type="double")
	public Double getDoubleval() {
		return doubleval;
	}

	public void setDoubleval(Double doubleval) {
		this.doubleval = doubleval;
	}

	@Column
	@Type(type="big_decimal")
	public BigDecimal getDecimalval() {
		return decimalval;
	}

	public void setDecimalval(BigDecimal decimalval) {
		this.decimalval = decimalval;
	}

	@Column
	@Type(type="boolean")
	public Boolean getBitval() {
		return bitval;
	}

	public void setBitval(Boolean bitval) {
		this.bitval = bitval;
	}

	@Column
	@Type(type="date")
	public java.sql.Date getDateval() {
		return dateval;
	}

	public void setDateval(java.sql.Date dateval) {
		this.dateval = dateval;
	}

	@Column
	@Type(type="date")
	public java.util.Date getDatetimeval() {
		return datetimeval;
	}

	public void setDatetimeval(java.util.Date datetimeval) {
		this.datetimeval = datetimeval;
	}

	@Column
	@Type(type="time")
	public java.sql.Time getTimeval() {
		return timeval;
	}

	public void setTimeval(java.sql.Time timeval) {
		this.timeval = timeval;
	}

	@Column
	@Type(type="timestamp")
	public java.sql.Timestamp getTimestampval() {
		return timestampval;
	}

	public void setTimestampval(java.sql.Timestamp timestampval) {
		this.timestampval = timestampval;
	}

	@Column
	@Type(type="byte")
	public Byte getYearval() {
		return yearval;
	}

	public void setYearval(Byte yearval) {
		this.yearval = yearval;
	}	

	@Column
	@Type(type="binary")
	public byte[] getBinaryval() {
		return binaryval;
	}

	public void setBinaryval(byte[] binaryval) {
		this.binaryval = binaryval;
	}

	@Column
	@Type(type="character")
	public Character getCharval() {
		return charval;
	}

	public void setCharval(Character charval) {
		this.charval = charval;
	}

	@Column(length=20)
	@Type(type="string")
	public String getVarcharval() {
		return varcharval;
	}

	public void setVarcharval(String varcharval) {
		this.varcharval = varcharval;
	}

	@Lob
	@Column
	@Type(type="clob")
	public Clob getTextval() {
		return textval;
	}

	public void setTextval(Clob textval) {
		this.textval = textval;
	}
	
//	public String getTinytext() {
//		return tinytext;
//	}
//
//	public void setTinytext(String tinytext) {
//		this.tinytext = tinytext;
//	}
//
//	public byte[] getTinyblob() {
//		return tinyblob;
//	}
//
//	public void setTinyblob(byte[] tinyblob) {
//		this.tinyblob = tinyblob;
//	}

	@Lob
	@Column
	@Type(type="blob")
	public Blob getBlobval() {
		return blobval;
	}

	public void setBlobval(Blob blobval) {
		this.blobval = blobval;
	}
	
	@Column
	@Type(type="calendar")
	public Calendar getCalendarval() {
		return calendarval;
	}

	public void setCalendarval(Calendar calendarval) {
		this.calendarval = calendarval;
	}

	@Column
	@Type(type="calendar_date")
	public Calendar getCalendardateval() {
		return calendardateval;
	}

	public void setCalendardateval(Calendar calendardateval) {
		this.calendardateval = calendardateval;
	}

	@Column
	@Type(type="class")
	public Class getClassval() {
		return classval;
	}

	public void setClassval(Class classval) {
		this.classval = classval;
	}

	@Column
	@Type(type="currency")
	public Currency getCurrencyval() {
		return currencyval;
	}

	public void setCurrencyval(Currency currencyval) {
		this.currencyval = currencyval;
	}

	@Column
	@Type(type="locale")
	public Locale getLocaleval() {
		return localeval;
	}

	public void setLocaleval(Locale localeval) {
		this.localeval = localeval;
	}

	@Column
	@Type(type="serializable")
	public Serializable getSerializableval() {
		return serializableval;
	}

	public void setSerializableval(Serializable serializableval) {
		this.serializableval = serializableval;
	}

	@Column
	@Type(type="timezone")
	public TimeZone getTimezoneval() {
		return timezoneval;
	}

	public void setTimezoneval(TimeZone timezoneval) {
		this.timezoneval = timezoneval;
	}

	@Column
	@Type(type="true_false")
	public Boolean getTruefalseval() {
		return truefalseval;
	}

	public void setTruefalseval(Boolean truefalseval) {
		this.truefalseval = truefalseval;
	}

	@Column
	@Type(type="yes_no")
	public Boolean getYesnoval() {
		return yesnoval;
	}

	public void setYesnoval(Boolean yesnoval) {
		this.yesnoval = yesnoval;
	}
	
	@Column(length = 200)
	public String getDescr() {
		return descr;
	}

	public void setDescr(String desc) {
		this.descr = desc;
	}

	@Id
	@Column(length = 30)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	// @OneToMany
	// public Set getDistributors() {
	// return distributors;
	// }
	//
	// public void setDistributors(Set distributors) {
	// this.distributors = distributors;
	// }
	//
	// public void addDistributor(Distributor d) {
	// if ( distributors == null ) distributors = new HashSet();
	// distributors.add( d );
	// }
}
