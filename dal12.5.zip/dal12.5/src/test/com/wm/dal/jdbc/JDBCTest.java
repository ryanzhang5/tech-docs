package com.wm.dal.jdbc;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Currency;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import org.hibernate.Hibernate;
import org.hibernate.cfg.Environment;
import org.hibernate.ejb.HibernatePersistence;
import com.wm.dal.jdbc.data.Item;
  
import com.wm.corelib.config.AppConfig;

public class JDBCTest {
	private EntityManagerFactory emf = null;

	public JDBCTest() {
		this(null);
	}

	public JDBCTest(String fileName) {
		getConfig();
		System.out.println("Create EMF:::::");
		emf = new HibernatePersistence()
				.createEntityManagerFactory(getConfig());
	}

	public Properties loadProperties() {

		Properties props = new Properties();
		try {
			props.load(JDBCTest.class
					.getResourceAsStream("/jdbcdriver.mysql.properties"));
			System.out.println(Environment.HBM2DDL_AUTO);
			// props.setProperty( Environment.HBM2DDL_AUTO, "create-drop" );
			props.putAll(AppConfig.getInstance().getProperties());
			AppConfig.getInstance().setProperties(props);
		} catch (Exception e) {
			throw new RuntimeException("could not load hibernate.properties",e);
		}

		return props;
	}

	private Map getConfig() {
		Map config = loadProperties();
		ArrayList classes = new ArrayList();

		classes.add(Item.class);
		config.put(HibernatePersistence.LOADED_CLASSES, classes);

		return config;
	}

	public void testEntityManager() {

		Item item = new Item("Mouse1", "Micro$oft mouse");
		// Begin to set values
		item.setTinyintval(Byte.valueOf("127"));
		item.setSmallintval(Short.valueOf("32767"));
		item.setMediumintval(Integer.valueOf("8388607"));
		item.setIntegerval(Integer.valueOf("2147483647"));
		item.setBigintval(Long.valueOf("9223372036854775807"));

		item.setFloatval(Float.valueOf("12.3"));
		item.setDoubleval(Double.valueOf("99999.3"));
		item.setDecimalval(new BigDecimal("9999999.99"));
		item.setBitval(new Boolean(true));

		item.setDateval(new java.sql.Date(System.currentTimeMillis()));
		item.setDatetimeval(new java.util.Date(System.currentTimeMillis()));
		item.setTimeval(new java.sql.Time(System.currentTimeMillis()));
		item
				.setTimestampval(new java.sql.Timestamp(System
						.currentTimeMillis()));
		item.setYearval(Byte.valueOf("09"));

		item.setCharval(Character.valueOf('A'));
		item.setVarcharval(new String("Hello"));

		InputStream inpuTextStrm = JDBCTest.class
				.getResourceAsStream("/inputtexttest.txt");
		Clob inpuTextClob = Hibernate.createClob(new InputStreamReader(
				inpuTextStrm), 102400);
		item.setTextval(inpuTextClob);

		try {
			InputStream inpuImagStrm = JDBCTest.class
					.getResourceAsStream("/inputimagetest.jpg");
			Blob inpuImagBlob = Hibernate.createBlob(inpuImagStrm);
			item.setBlobval(inpuImagBlob);
		} catch (IOException e) {
			e.printStackTrace();
		}

		item.setBinaryval(new String("Hello World").getBytes());

		item.setCalendarval(Calendar.getInstance());
		item.setCalendardateval(Calendar.getInstance());
		item.setClassval("Hello".getClass());
		item.setCurrencyval(Currency.getInstance(Locale.CHINA));
		item.setLocaleval(Locale.CHINA);
		
		item.setSerializableval(new String("Hello World"));
		
		item.setTimezoneval(TimeZone.getDefault());
		item.setTruefalseval(new Boolean(true));
		item.setYesnoval(new Boolean(true));

		// End of setting values

		EntityManager em = emf.createEntityManager();
		EntityManager em2 = emf.createEntityManager();

		em.getTransaction().begin();
		em.persist(item);
		em.flush();
		em.refresh(item);
		System.out.println(em.contains(item));
		em.getTransaction().commit();

		// em.close();

		// System.out.println(em.contains(item));

		em.getTransaction().begin();
		item = (Item) em.createQuery("from Item where descr like 'M%'")
				.getSingleResult();

		// System.out.println(item.getDescr() + ":" + item.getName());
		//    
		// item.setDescr( "Micro$oft wireless mouse" );
		// em.getTransaction().commit();
		//    
		// System.out.println(item.getDescr() + ":" + item.getName());

		// Begin to retrieve values
		System.out.println("TinyInt" + ":" + item.getTinyintval());
		System.out.println("SmallInt" + ":" + item.getSmallintval());
		System.out.println("MediumInt" + ":" + item.getMediumintval());
		System.out.println("Integer" + ":" + item.getIntegerval());
		System.out.println("BigInt" + ":" + item.getBigintval());

		System.out.println("Float" + ":" + item.getFloatval());
		System.out.println("Double" + ":" + item.getDoubleval());
		System.out.println("Decimal" + ":" + item.getDecimalval());
		System.out.println("Bit" + ":" + item.getBitval());

		System.out.println("Date" + ":" + item.getDateval());
		System.out.println("DateTime" + ":" + item.getDatetimeval());
		System.out.println("Time" + ":" + item.getTimeval());
		System.out.println("Timestamp" + ":" + item.getTimestampval());
		System.out.println("Year" + ":" + item.getYearval());

		System.out.println("Character" + ":" + item.getCharval());
		System.out.println("Varchar" + ":" + item.getVarcharval());

		System.out.println("Clob" + ":" + "creating outputtexttest.txt");
		try {
			Clob textval = item.getTextval();
			InputStream is = textval.getAsciiStream();
			FileOutputStream fos = new FileOutputStream("outputtexttest.txt");
			byte[] buf = new byte[102400];
			int len;
			while ((len = is.read(buf)) != -1) {
				fos.write(buf, 0, len);
			}
			fos.close();
			is.close();
//			System.out.println(textval.getSubString(1, (int) textval.length()));
		} catch (SQLException e1) {
			e1.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Clob" + ":" + "created outputtexttest.txt");

		// System.out.println("\nBlob" + ":" + "creating outputimagetest.jpg");
		//    
		// try {
		// Blob blobval = item.getBlobval();
		// byte[] blobbytes = blobval.getBytes(0, (int)blobval.length());
		// String a = "";
		// } catch (SQLException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }
		//    
		// System.out.println("\nBlob" + ":" + "created outputimagetest.jpg");
		System.out.println("\nBlob" + ":" + "creating outputimagetest.jpg");
		try {
			Blob blobval = item.getBlobval();
			InputStream is = blobval.getBinaryStream();
			FileOutputStream fos = new FileOutputStream("outputimagetest.jpg");
			byte[] buf = new byte[102400];
			int len;
			while ((len = is.read(buf)) != -1) {
				fos.write(buf, 0, len);
			}
			fos.close();
			is.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("\nBlob" + ":" + "created outputimagetest.jpg");
		// End of retrieving values

		System.out.println("\nBinary" + ":" + new String(item.getBinaryval()));
		System.out.println("Calendar" + ":" + item.getCalendarval());
		System.out.println("Calendar Date" + ":" + item.getCalendardateval());
		System.out.println("Class" + ":" + item.getClassval());
		System.out.println("Currency" + ":" + item.getCurrencyval());
		System.out.println("Locale" + ":" + item.getLocaleval());
		System.out.println("Serializable" + ":" + (String)item.getSerializableval());
		System.out.println("Timezon" + ":" + item.getTimezoneval());
		System.out.println("TrueFalse" + ":" + item.getTruefalseval());
		System.out.println("YesNo" + ":" + item.getYesnoval());
		
		em.close();
		closeEMF();

	}

	public void closeEMF() {
		emf.close();
		System.out.println("EMF is closed..");
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new JDBCTest().testEntityManager();
	}

	private String getLimitedLengthString(String source, int lengthLimit) {

		String target = null;
		target = source.length() > lengthLimit ? source.substring(0,
				lengthLimit) : source;
		return target;
	}

}
