/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.jdbc;

import com.wm.dal.jdbc.BaseJdbcTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

import java.io.IOException;
import java.sql.Clob;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

/**
 * ClobTest - depends on the catalog schema - dal_data_type table !!
 *
 * @author mkishore
 * @since 1.0
 */
@Test(sequential=true)
public class ClobTest extends BaseJdbcTest {
    private static final int MAX_SIZE = 2 * 1024;// * 1024;
    private static final String POOL = "jdbcpool_oracle";

    @BeforeClass
    public void initialize() {
        try {
            BaseJdbcTest.load(ClobTest.class, "/system.properties");
            testDelete();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @AfterClass(groups = { "oracle", "create" })
    public void testDelete() {
        execute(POOL, "delete from dal_data_type where test_nbr = 1");
    }

    @Test(groups = { "oracle", "create" })
    public void testCRUD() throws SQLException {
        char[] data = new char[MAX_SIZE];
        Arrays.fill(data, 'x');
        execute(POOL, "insert into dal_data_type (test_nbr, test_clob) values (1, ?)", new DALClob(data));

        List list = execute(POOL, "select test_clob from dal_data_type where test_nbr = 1");
        Assert.assertEquals(list.size(), 1);
        Object res = ((List) list.get(0)).get(0);
        Assert.assertTrue(res instanceof Clob);
        Assert.assertEquals(((Clob) res).length(), MAX_SIZE);

        data = new char[MAX_SIZE];
        Arrays.fill(data, 'y');
        execute(POOL, "update dal_data_type set test_clob = ? where test_nbr = 1", new DALClob(data));
        list = execute(POOL, "select test_clob from dal_data_type where test_nbr = 1");
        Assert.assertEquals(list.size(), 1);
        res = ((List) list.get(0)).get(0);
        Assert.assertTrue(res instanceof Clob);
        Assert.assertEquals(((Clob) res).length(), MAX_SIZE);
        Assert.assertEquals(((Clob) res).getSubString(1, 1), "y");

        execute(POOL, "delete from dal_data_type where test_nbr = 1");
        list = execute(POOL, "select test_clob from dal_data_type where test_nbr = 1");
        Assert.assertEquals(list.size(), 0);
    }
}
