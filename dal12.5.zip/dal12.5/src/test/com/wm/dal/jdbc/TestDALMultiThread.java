package com.wm.dal.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.Test;

import com.wm.dal.JDBCDataSource;

//@Test(sequential = true)
public class TestDALMultiThread {



	private static Logger logger = Logger.getLogger(TestDALMultiThread.class.getName());
	private static ApplicationContext applicationContext = new ClassPathXmlApplicationContext("/test-context.xml");

	public static final String PURE_DRIVER = "mysqlDataSource";
	public static final String DATAACCESS_DRIVER = "jdbcPoolMysql";
	public static final String DAL_DRIVER = "mysqlDAL";

	private static DataSource pureSource = (DataSource) applicationContext.getBean(PURE_DRIVER);
	private static DataSource dataAccess_Source = (DataSource) applicationContext.getBean(DATAACCESS_DRIVER);
	private static DataSource dal_Source = (DataSource) applicationContext.getBean(DAL_DRIVER);

	private DataSource source;

	public TestDALMultiThread(String driverName){
		if(driverName.equals(PURE_DRIVER)){
			this.source = pureSource;
		}else if(driverName.equals(DATAACCESS_DRIVER)){
			this.source = dataAccess_Source;
		}else if(driverName.equals(DAL_DRIVER)){
			this.source = dal_Source;
		}

	}

	/**
	 * this method is used to test driver stored procedure supporting functions
	 * via mysql database
	 * 1) has input  parameter for procedure
	 * 2) has output parameter for procedure
	 * 3) may return multi-resultset
	 *
	 *	CREATE PROCEDURE proc_test(in input INT, out output INT)
	 *	begin
	 *	    set output = 2 * input;
	 *	    if input = 1 then
	 *	        select input,  'only one result' ;
	 *	    else
	 *	        select input,  'first result' ;
	 *	        select input, input+1,  'second result' ;
	 *	    end if;
	 *	end;
	 */
	public void testProcedureCreate() {
		Connection con = null;
		Statement pstm = null;
		ResultSet rs = null;
		String createSP = ""
				+ "CREATE PROCEDURE proc_test(in input INT, out output INT) "
				+ "begin                                                    "
				+ "     set output = 2 * input;                             "
				+ "     if input = 1 then                                   "
				+ "         select input,  'only one result' ;              "
				+ "     else                                                "
				+ "         select input,  'first result' ;                 "
				+ "         select input, input+1,  'second result' ;       "
				+ "     end if;                                             "
				+ "end;                                                     ";
		try {
			logger.info("creating PROCEDURE proc_test" );
			con = pureSource.getConnection();
			pstm = con.createStatement();
			pstm.executeUpdate(createSP);
			con.commit();
			logger.info("created  PROCEDURE proc_test" );

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)		rs.close();
				if (pstm != null)	pstm.close();
				if (con != null)	con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}



	public void testProcedureDrop() {
		Connection con = null;
		Statement pstm = null;
		String dropSP = "DROP PROCEDURE IF EXISTS proc_test;";

		try {
			logger.info("dropping PROCEDURE proc_test" );
			con = pureSource.getConnection();
			pstm = con.createStatement();
			pstm.executeUpdate(dropSP);
			con.commit();
			logger.info("dropped  PROCEDURE proc_test" );
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstm != null)	pstm.close();
				if (con != null)	con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public DataSource getDataSource(){
		return source;
	}


	// @Test(groups = { "mysql", "thread" })
	public void testMultiThread(){
//		main( new String[]{PURE_DRIVER});
//		main( new String[]{DATAACCESS_DRIVER});
		main( new String[]{DAL_DRIVER});
	}

	public static void main(String[] args){

		String driverName = "";
		if(args ==null || args.length==0 || args[0].equals("")){
			driverName = PURE_DRIVER;
		}else{
			driverName = args[0];
		}

		TestDALMultiThread test = new TestDALMultiThread(driverName);
		test.testProcedureCreate();
		Connection conn = null;
		try {
			conn = ((JDBCDataSource)test.getDataSource()).getConnection("/multithread-test-dal.conf");
			Thread worker1 = new Thread(new Caller("power-thread-1", conn, 10));
			Thread worker2 = new Thread(new Caller("power-thread-2", conn, 200));

			worker1.start();
			worker2.start();
			worker1.join();
			worker2.join();

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if (conn != null)			conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}


		test.testProcedureDrop();
	}

}

