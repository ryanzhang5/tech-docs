package com.wm.dal.jdbc.oracle;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.logging.Logger;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.Test;

public class TestDALGetCurrSaveCartOracle extends BaseOracleTest {

	@Test(groups = { "oracle", "insert" })
	public void testCallProc() {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet currentCartContents = null;
		ResultSet savedCartContents = null;

		try {

			conn = dataSource.getConnection();
			stmt = conn.prepareCall(GetCurrSaveCartSQL.call);
			stmt.setLong(GetCurrSaveCartSQL.colCustomerIdIn, 53956);
			stmt.setLong(GetCurrSaveCartSQL.colVisitorNoIn, -1);
			stmt.setTimestamp(GetCurrSaveCartSQL.colCurrentCartTimestampIn,
					Timestamp.valueOf("2009-05-26 21:56:41.0"));
			stmt.setTimestamp(GetCurrSaveCartSQL.colSavedCartTimestampIn,
					Timestamp.valueOf("2009-05-19 04:44:04.0"));
			stmt.registerOutParameter(GetCurrSaveCartSQL.colCurrentItemsOut,
					OracleTypes.CURSOR);
			stmt.registerOutParameter(GetCurrSaveCartSQL.colSavedItemsOut,
					OracleTypes.CURSOR);
			stmt.registerOutParameter(GetCurrSaveCartSQL.colCurrentCartDtmOut,
					java.sql.Types.TIMESTAMP);
			stmt.registerOutParameter(GetCurrSaveCartSQL.colSavedCartDtmOut,
					java.sql.Types.TIMESTAMP);
			stmt.registerOutParameter(
					GetCurrSaveCartSQL.colCurrCartUpdateReqdOut,
					java.sql.Types.VARCHAR);
			stmt.registerOutParameter(
					GetCurrSaveCartSQL.colSavedCartUpdateReqdOut,
					java.sql.Types.VARCHAR);
			stmt.registerOutParameter(GetCurrSaveCartSQL.colHasDigitalCartOut,
					java.sql.Types.VARCHAR);
			stmt.execute();

			currentCartContents = (ResultSet) stmt
					.getObject(GetCurrSaveCartSQL.colCurrentItemsOut);
			savedCartContents = (ResultSet) stmt
					.getObject(GetCurrSaveCartSQL.colSavedItemsOut);
			Timestamp currentCartDtmOut = stmt
					.getTimestamp(GetCurrSaveCartSQL.colCurrentCartDtmOut);
			Timestamp savedCartDtmOut = stmt
					.getTimestamp(GetCurrSaveCartSQL.colSavedCartDtmOut);
			String currCartUpdateReqd = stmt
					.getString(GetCurrSaveCartSQL.colCurrCartUpdateReqdOut);
			String savedCartUpdateReqd = stmt
					.getString(GetCurrSaveCartSQL.colSavedCartUpdateReqdOut);
			String hasDigitalCart = stmt
					.getString(GetCurrSaveCartSQL.colHasDigitalCartOut);

			logger.info("~~~~~~~~~~currentCartContents~~~~~~~~~~~~~");
			this.processResultSet(currentCartContents);
			logger.info("~~~~~~~~~~savedCartContents~~~~~~~~~~~~~");
			this.processResultSet(savedCartContents);
			logger.info("~~~~~Other values: " + currentCartDtmOut + " | " + savedCartDtmOut 
					+ " | " + currCartUpdateReqd + " | " + savedCartUpdateReqd
					+ " | " + hasDigitalCart);
			

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (currentCartContents != null)
					currentCartContents.close();
				if (savedCartContents != null)
					savedCartContents.close();
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
			}catch (Exception ex) {
				ex.printStackTrace();
			}
		}

	}

	private void processResultSet(ResultSet rs) {
		try {
			while (rs.next()) {
				long cart_id = rs
						.getLong(itemCursorSQL.colCartID);
				long item_id = rs
						.getLong(itemCursorSQL.colItemID);
				int item_qty = rs
						.getInt(itemCursorSQL.colItemQty);
				String xmlBlob = rs
						.getString(itemCursorSQL.colXMLBlob);
				int db_cd = rs
						.getInt(itemCursorSQL.colCatalogDomain);
				long sellerId = rs
						.getLong(itemCursorSQL.colSellerID);

				java.sql.Timestamp jsd = rs
						.getTimestamp(itemCursorSQL.colExpDate);

				String internalBlob = rs
						.getString(itemCursorSQL.colInternalBlob);
				long cart_item_id = rs
						.getLong(itemCursorSQL.colOutLineID);
				logger.info("+++++CurrentCartContents: " + cart_id + " | "
						+ item_id + " | " + item_qty + " | "
						+ xmlBlob.substring(0, 5) + " | " + db_cd + " | "
						+ sellerId + " | " + jsd + " | " + internalBlob + " | "
						+ cart_item_id);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * This API will be used to get currency and save cart.
	 */
	private interface GetCurrSaveCartSQL {
		public static final String call = "{ call wcu_cart_pkg.get_curr_and_save_cart_content(?,?,?,?,?,?,?,?,?,?,?) }";
		public static final int colCustomerIdIn = 1;
		public static final int colVisitorNoIn = 2;
		public static final int colCurrentCartTimestampIn = 3;
		public static final int colSavedCartTimestampIn = 4;
		public static final int colCurrentItemsOut = 5;
		public static final int colSavedItemsOut = 6;
		public static final int colCurrentCartDtmOut = 7;
		public static final int colSavedCartDtmOut = 8;
		public static final int colCurrCartUpdateReqdOut = 9;
		public static final int colSavedCartUpdateReqdOut = 10;
		public static final int colHasDigitalCartOut = 11;
	}

	private interface itemCursorSQL {
		public static final int colCartID = 1;
		public static final int colItemID = 2;
		public static final int colItemQty = 3;
		public static final int colXMLBlob = 4;
		public static final int colExpDate = 5;
		public static final int colInternalBlob = 6;
		public static final int colOutLineID = 7;
		public static final int colCatalogDomain = 8;
		public static final int colSellerID = 9;
	}
}
