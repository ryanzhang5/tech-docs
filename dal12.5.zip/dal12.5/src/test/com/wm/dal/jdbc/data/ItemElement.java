package com.wm.dal.jdbc.data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;
import java.util.HashMap;
import java.util.Map;

public class ItemElement implements java.sql.SQLData, Serializable {
	
	public static final String SQL_TYPE = "WEB_USER.ITEMTBL_REC";
	public static final String ARRAY_TYPE = "WEB_USER.ITEMTBL_TAB";

	private String testElemName;
	private double testElemValue;
	private Date testElemDate;
	
	public ItemElement() {
		
	}

	public String getSQLTypeName() throws SQLException {
		return SQL_TYPE;
	}

	public void readSQL(SQLInput stream, String typeName)
			throws SQLException {
		
		testElemName = stream.readString();
		testElemValue = stream.readDouble();
		testElemDate = stream.readDate();		
	}

	public void writeSQL(SQLOutput stream) throws SQLException {

		stream.writeString(testElemName);
		stream.writeDouble(testElemValue);
		stream.writeDate(testElemDate);
		return;
		
	}

	
	public String toString() {
		StringBuilder strBuild = new StringBuilder();
		strBuild.append("ItemElement[ ");
		strBuild.append(testElemName + " | ");
		strBuild.append(testElemValue + " | ");
		strBuild.append(testElemDate + " | ");
		strBuild.append("]");
		return strBuild.toString();
	}

	public String getTestElemName() {
		return testElemName;
	}

	public void setTestElemName(String testElemName) {
		this.testElemName = testElemName;
	}

	public double getTestElemValue() {
		return testElemValue;
	}

	public void setTestElemValue(double testElemValue) {
		this.testElemValue = testElemValue;
	}

	public Date getTestElemDate() {
		return testElemDate;
	}

	public void setTestElemDate(Date testElemDate) {
		this.testElemDate = testElemDate;
	}
}
