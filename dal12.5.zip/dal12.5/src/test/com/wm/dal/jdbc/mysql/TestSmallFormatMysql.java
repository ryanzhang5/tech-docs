package com.wm.dal.jdbc.mysql;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Currency;
import java.util.Locale;
import java.util.TimeZone;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.Test;

@Test(sequential=true)
public class TestSmallFormatMysql extends BaseMysqlTest {

	@Test(groups = { "mysql", "create" })
	public void testCreate() {
		logger.info("Begin to create table");
		Connection con = null;
		Statement stmt = null;
		String dropTablSql = "DROP TABLE IF EXISTS itemtbl;";
		String creaTablSql = "CREATE TABLE itemtbl ("
				+ "var_bigint bigint(20) default NULL,"
				+ "var_bit bit(1) default NULL,"
				+ "var_char char(1) default NULL,"
				+ "var_decimal decimal(19,2) default NULL,"
				+ "var_double double default NULL,"
				+ "var_float float default NULL,"
				+ "var_int int(11) default NULL,"
				+ "var_smallint smallint(6) default NULL,"
				+ "var_tinyint tinyint(4) default NULL,"
				+ "var_varchar varchar(20) default NULL,"
				+ "var_classvarchar varchar(255) default NULL,"
				+ "var_currency varchar(255) default NULL,"
				+ "var_locale varchar(255) default NULL,"
				+ "var_timezone varchar(255) default NULL,"
				+ "var_truefalse char(1) default NULL,"
				+ "var_yesno char(1) default NULL"
				+ ") ENGINE=InnoDB DEFAULT CHARSET=utf8;";
		try {
//			con = dataSource.getConnection();
			con = pureDataSource.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate(dropTablSql);
			stmt.executeUpdate(creaTablSql);
			logger.info("itemtbl table is created.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Test(groups = { "mysql", "insert" }, dependsOnMethods = "testCreate")
	public void testInsert() {

		logger.info("Begin of insert data.");

		Connection con = null;
		PreparedStatement pstm = null;

		String insrSql = "INSERT INTO itemtbl"
				+ "(var_bigint,var_bit,var_char,"
				+ "var_decimal,var_double,var_float,"
				+ "var_int,var_smallint,var_tinyint,"
				+ "var_varchar,var_classvarchar,var_currency,"
				+ "var_locale,var_timezone,var_truefalse,var_yesno" + ")"
				+ " VALUES " + "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

		try {
			con = dataSource.getConnection();
			pstm = con.prepareStatement(insrSql);

			pstm.setLong(1, Long.valueOf("9223372036854775807"));
			pstm.setBoolean(2, true);
			pstm.setString(3, "A");
			pstm.setBigDecimal(4, new BigDecimal("9999999.99"));
			pstm.setDouble(5, 99999.3);
			pstm.setFloat(6, 12.3f);
			pstm.setInt(7, 2147483647);
			pstm.setShort(8, (short) 32767);
			pstm.setByte(9, (byte) 127);
			pstm.setString(10, "Hello World!");
			pstm.setString(11, "Hello".getClass().toString());
			pstm.setString(12, Currency.getInstance(Locale.CHINA).toString());
			pstm.setString(13, Locale.CHINA.toString());
			pstm.setString(14, getLimitedLengthString(TimeZone.getDefault()
					.toString(), 255));
			pstm.setBoolean(15, new Boolean(true));
			pstm.setBoolean(16, new Boolean(false));

			pstm.execute();
			con.commit();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		logger.info("End of insert data.");
		this.testQuery();
	}

	@Test(groups = { "mysql", "update" }, dependsOnMethods = "testInsert")
	public void testUpdate() {

		logger.info("Begin of update data.");

		Connection con = null;
		PreparedStatement pstm = null;

		String updateSQL = "UPDATE itemtbl "
				+ "SET var_bigint=?,var_bit=?,var_char=?,"
				+ "var_decimal=?,var_double=?,var_float=?,"
				+ "var_int=?,var_smallint=?,var_tinyint=?,"
				+ "var_varchar=?,var_classvarchar=?,var_currency=?,"
				+ "var_locale=?,var_timezone=?,var_truefalse=?,var_yesno=?";

		try {
			con = dataSource.getConnection();
			pstm = con.prepareStatement(updateSQL);

			pstm.setLong(1, Long.valueOf("9223372036854775806"));
			pstm.setBoolean(2, false);
			pstm.setString(3, "B");
			pstm.setBigDecimal(4, new BigDecimal("9999998.99"));
			pstm.setDouble(5, 99998.3);
			pstm.setFloat(6, 12.3f);
			pstm.setInt(7, 2147483647);
			pstm.setShort(8, (short) 32767);
			pstm.setByte(9, (byte) 127);
			pstm.setString(10, "Hello World!");
			pstm.setString(11, "Hello".getClass().toString());
			pstm.setString(12, Currency.getInstance(Locale.CHINA).toString());
			pstm.setString(13, Locale.CHINA.toString());
			pstm.setString(14, getLimitedLengthString(TimeZone.getDefault()
					.toString(), 255));
			pstm.setBoolean(15, new Boolean(true));
			pstm.setBoolean(16, new Boolean(false));

			pstm.execute();
			con.commit();

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		logger.info("End of update data.");
		this.testQuery();

	}

	private void testQuery() {

		logger.info("Begin of query data.");

		Connection con = null;
		PreparedStatement pstm = null;

		String seleSql = "SELECT " + "var_bigint,var_bit,var_char,"
				+ "var_decimal,var_double,var_float,"
				+ "var_int,var_smallint,var_tinyint,"
				+ "var_varchar,var_classvarchar,var_currency,"
				+ "var_locale,var_timezone,var_truefalse,var_yesno"
				+ " FROM itemtbl";

		try {
			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			ResultSet rs = pstm.executeQuery();
			while (rs.next()) {
				long bigintVal = rs.getLong(1);
				logger.info("var_bigint" + " : " + bigintVal);

				boolean bitVal = rs.getBoolean(2);
				logger.info("var_bit" + " : " + bitVal);

				String charVal = rs.getString(3);
				logger.info("var_char" + " : " + charVal);

				BigDecimal decimalVal = rs.getBigDecimal(4);
				logger.info("var_decimal" + " : " + decimalVal);

				double doubleVal = rs.getDouble(5);
				logger.info("var_double" + " : " + doubleVal);

				float floatVal = rs.getFloat(6);
				logger.info("var_float" + " : " + floatVal);

				int intVal = rs.getInt(7);
				logger.info("var_int" + " : " + intVal);

				short smallintVal = rs.getShort(8);
				logger.info("var_smallint" + " : " + smallintVal);

				byte tinyintVal = rs.getByte(9);
				logger.info("var_tinyint" + " : " + tinyintVal);

				String varcharVal = rs.getString(10);
				logger.info("var_varchar" + " : " + varcharVal);

				String classvarcharVal = rs.getString(11);
				logger.info("var_classvarchar" + " : " + classvarcharVal);

				String currencyVal = rs.getString(12);
				logger.info("var_currency" + " : " + currencyVal);

				String localeVal = rs.getString(13);
				logger.info("var_locale" + " : " + localeVal);

				String timezoneVal = rs.getString(14);
				logger.info("var_timezone" + " : " + timezoneVal);

				Boolean truefalseVal = rs.getBoolean(15);
				logger.info("var_truefalse" + " : " + truefalseVal);

				Boolean yesnoVal = rs.getBoolean(16);
				logger.info("var_yesno" + " : " + yesnoVal);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		logger.info("End of query data.");

	}

	@Test(groups = { "mysql", "delete" }, dependsOnMethods = "testUpdate")
	public void testDelete() {

		logger.info("Begin of delete table.");

		Connection con = null;
		Statement stmt = null;

		String dropTablSql = "DELETE FROM itemtbl;";
		try {
			con = dataSource.getConnection();
			stmt = con.createStatement();
			stmt.execute(dropTablSql);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		logger.info("End of delete table");

	}
	@Test(groups = { "mysql", "drop" }, dependsOnMethods = "testDelete")
	public void testDrop() {

		logger.info("Begin of drop table.");
		Connection con = null;
		Statement stmt = null;

		String dropTablSql = "DROP TABLE itemtbl;";
		try {
//			con = dataSource.getConnection();
			con = pureDataSource.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate(dropTablSql);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		logger.info("End of drop table.");

	}

	private String getLimitedLengthString(String source, int lengthLimit) {

		String target = null;
		target = source.length() > lengthLimit ? source.substring(0,
				lengthLimit) : source;
		return target;
	}
}
