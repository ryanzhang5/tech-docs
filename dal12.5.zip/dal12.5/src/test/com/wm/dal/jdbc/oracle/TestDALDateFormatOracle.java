package com.wm.dal.jdbc.oracle;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Copyright 2009 walmart.com. All rights reserved
 */

/**
 * @author Martin Ma
 * @since 2009-5-5
 * @version 1.0 Test JDBC Date Format on oracle with DALConnection
 */
// @Test(sequential = true)
public class TestDALDateFormatOracle extends BaseOracleTest {

	@Test(groups = { "oracle", "create" })
	public void testCreate() {

		Connection con = null;
		Statement stmt = null;

		String creaTablSql = "CREATE TABLE itemtbl_daldateformat ("
				+ "var_date DATE default NULL,"
				+ "var_datetime TIMESTAMP default NULL,"
				+ "var_time DATE default NULL" + ")";
		try {
			logger.info("begin to create itemtbl_daldateformat table.");
			System.out
					.println("~~~~~~~~~~~~~~~~~~" + "Begin to get connection");
			con = pureDataSource.getConnection();
			System.out.println("~~~~~~~~~~~~~~~~~~"
					+ "End of getting connection");
			System.out.println("~~~~~~~~~~~~~~~~~~"
					+ "Begin to create statement");
			stmt = con.createStatement();
			System.out.println("~~~~~~~~~~~~~~~~~~"
					+ "End of creating statement");
			System.out.println("~~~~~~~~~~~~~~~~~~"
					+ "Begin to execute statement");
			stmt.executeUpdate(creaTablSql);
			System.out.println("~~~~~~~~~~~~~~~~~~"
					+ "End of executing statement");
			logger.info("itemtbl_daldateformat table is created.");

		} catch (SQLException e) {
			System.out.println("~~~~~~~~~~~~~~~~~~" + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("~~~~~~~~~~~~~~~~~~" + e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForCreate();
	}

	@Test(dependsOnMethods = "testCreate", groups = { "oracle", "insert" })
	public void testInsert() {

		Connection con = null;
		PreparedStatement pstm = null;

		String insrSql = "INSERT INTO itemtbl_daldateformat"
				+ "(var_date,var_datetime,var_time) " + " VALUES " + " (?,?,?)";

		try {
			logger.info("begin to insert itemtbl_daldateformat data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(insrSql);

			DateFormat dateFormat;
			dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date tDate = dateFormat.parse("2008-11-12");
			pstm.setDate(1, new java.sql.Date(tDate.getTime()));

			DateFormat timestampFormat;
			timestampFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			java.util.Date tTimestamp = timestampFormat
					.parse("2008-11-12 09:10:20.200");
			java.sql.Timestamp ts = new java.sql.Timestamp(tTimestamp.getTime());
			pstm.setTimestamp(2, ts);

			DateFormat timeFormat;
			timeFormat = new SimpleDateFormat("HH:mm:ss");
			java.util.Date tTime = timeFormat.parse("09:10:20");
			pstm.setTime(3, new java.sql.Time(tTime.getTime()));

			pstm.execute();
			con.commit();

			logger.info("itemtbl_daldateformat data are inserted.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		this.testQueryForInsert();
	}

	@Test(dependsOnMethods = "testInsert", groups = { "oracle", "update" })
	public void testUpdate() {

		Connection con = null;
		PreparedStatement pstm = null;

		String insrSql = "UPDATE itemtbl_daldateformat "
				+ " SET var_date=?,var_datetime=?,var_time=?";

		try {
			logger.info("begin to update itemtbl_daldateformat data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(insrSql);

			DateFormat dateFormat;
			dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date tDate = dateFormat.parse("2008-12-10");
			pstm.setDate(1, new java.sql.Date(tDate.getTime()));

			DateFormat timestampFormat;
			timestampFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			java.util.Date tTimestamp = timestampFormat
					.parse("2008-12-10 11:09:21.300");
			java.sql.Timestamp ts = new java.sql.Timestamp(tTimestamp.getTime());
			pstm.setTimestamp(2, ts);

			DateFormat timeFormat;
			timeFormat = new SimpleDateFormat("HH:mm:ss");
			java.util.Date tTime = timeFormat.parse("11:09:21");
			pstm.setTime(3, new java.sql.Time(tTime.getTime()));

			pstm.execute();
			con.commit();

			logger.info("itemtbl_daldateformat data are updated.");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		this.testQueryForUpdate();
	}

	@Test(dependsOnMethods = "testUpdate", groups = { "oracle", "delete" })
	public void testDelete() {

		Connection con = null;
		Statement stmt = null;

		String dropTablSql = "DELETE FROM itemtbl_daldateformat";
		try {
			logger.info("begin to delete itemtbl_daldateformat data.");
			con = dataSource.getConnection();
			stmt = con.createStatement();
			stmt.execute(dropTablSql);
			logger.info("data of itemtbl_daldateformat table is deleted.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		this.testQueryForDelete();
	}

	@Test(dependsOnMethods = "testDelete", groups = { "oracle", "drop" })
	public void testDrop() {

		Statement stmt = null;
		Connection con = null;
		String dropTablSql = "DROP TABLE itemtbl_daldateformat";
		try {
			logger.info("begin to drop itemtbl_daldateformat table.");
			con = pureDataSource.getConnection();
			stmt = con.createStatement();
			stmt.executeUpdate(dropTablSql);
			logger.info("itemtbl_daldateformat table is dropped.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		testQueryForDrop();
	}

	public void testQueryForCreate() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT count(*) as table_num FROM user_tables WHERE lower(table_name)='itemtbl_daldateformat'";

		try {
			logger.info("begin to retrieve user_table data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				// int num = rs.getInt("table_num");
				int num = rs.getInt(1);
				Assert.assertTrue(num >= 1);
			}
			logger.info("user_table data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForInsert() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " var_date,var_datetime,var_time "
				+ " FROM itemtbl_daldateformat";

		try {
			logger.info("begin to retrieve itemtbl_daldateformat data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {

				DateFormat dateFormat;
				dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date tDate = dateFormat.parse("2008-11-12");
				// java.sql.Date dateVal = rs.getDate("var_date");
				java.sql.Date dateVal = rs.getDate(1);
				logger.info("var_date" + " : " + dateVal);
				logger.info(""
						+ tDate.equals(new java.sql.Date(tDate.getTime())));
				Assert
						.assertEquals(dateVal, new java.sql.Date(tDate
								.getTime()));

				DateFormat timestampFormat;
				timestampFormat = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss.SSS");
				java.util.Date tTimestamp = timestampFormat
						.parse("2008-11-12 09:10:20.200");
				// java.sql.Timestamp datetimeVal = rs
				// .getTimestamp("var_timestamp_dt");
				java.sql.Timestamp datetimeVal = rs.getTimestamp(2);
				// int milisecond = rs.getInt("var_timestamp_ms");
				// int milisecond = rs.getInt(3);
				logger.info("var_timestamp_dt" + " : " + datetimeVal);
				// logger.info("var_timestamp_ms" + " : " + milisecond);
				java.sql.Timestamp exactTimestamp = new java.sql.Timestamp(
						datetimeVal.getTime());
				// exactTimestamp.setNanos(milisecond);
				logger.info("" + tTimestamp.equals(exactTimestamp));
				Assert.assertEquals(exactTimestamp, new java.sql.Timestamp(
						tTimestamp.getTime()));

				DateFormat timeFormat;
				timeFormat = new SimpleDateFormat("HH:mm:ss");
				java.util.Date tTime = timeFormat.parse("09:10:20");
				// java.sql.Time timeVal = rs.getTime("var_time");
				java.sql.Time timeVal = rs.getTime(3);
				logger.info("var_time" + " : " + timeVal);
				logger.info(""
						+ tTime.equals(new java.sql.Time(tTime.getTime())));
				Assert
						.assertEquals(timeVal, new java.sql.Time(tTime
								.getTime()));

			}
			logger
					.info("itemtbl_daldateformat data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForUpdate() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " var_date,var_datetime,var_time "
				+ " FROM itemtbl_daldateformat";

		try {
			logger.info("begin to retrieve itemtbl_daldateformat data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {

				DateFormat dateFormat;
				dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date tDate = dateFormat.parse("2008-12-10");
				// java.sql.Date dateVal = rs.getDate("var_date");
				java.sql.Date dateVal = rs.getDate(1);
				logger.info("var_date" + " : " + dateVal);
				logger.info(""
						+ tDate.equals(new java.sql.Date(tDate.getTime())));
				Assert
						.assertEquals(dateVal, new java.sql.Date(tDate
								.getTime()));

				DateFormat timestampFormat;
				timestampFormat = new SimpleDateFormat(
						"yyyy-MM-dd HH:mm:ss.SSS");
				java.util.Date tTimestamp = timestampFormat
						.parse("2008-12-10 11:09:21.300");
				// java.sql.Timestamp datetimeVal = rs
				// .getTimestamp("var_timestamp_dt");
				java.sql.Timestamp datetimeVal = rs.getTimestamp(2);
				// int milisecond = rs.getInt("var_timestamp_ms");
				// int milisecond = rs.getInt(3);
				logger.info("var_timestamp_dt" + " : " + datetimeVal);
				// logger.info("var_timestamp_ms" + " : " + milisecond);
				java.sql.Timestamp exactTimestamp = new java.sql.Timestamp(
						datetimeVal.getTime());
				// exactTimestamp.setNanos(milisecond);
				logger.info("" + tTimestamp.equals(exactTimestamp));
				Assert.assertEquals(exactTimestamp, new java.sql.Timestamp(
						tTimestamp.getTime()));

				DateFormat timeFormat;
				timeFormat = new SimpleDateFormat("HH:mm:ss");
				java.util.Date tTime = timeFormat.parse("11:09:21");
				// java.sql.Time timeVal = rs.getTime("var_time");
				java.sql.Time timeVal = rs.getTime(3);
				logger.info("var_time" + " : " + timeVal);
				logger.info(""
						+ tTime.equals(new java.sql.Time(tTime.getTime())));
				Assert
						.assertEquals(timeVal, new java.sql.Time(tTime
								.getTime()));
			}
			logger
					.info("itemtbl_daldateformat data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForDelete() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT " + " var_date,var_datetime,var_time "
				+ " FROM itemtbl_daldateformat";

		try {
			logger.info("begin to retrieve itemtbl_daldateformat data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			int rowNum = rs.getRow();
			Assert.assertEquals(rowNum, 0);
			logger
					.info("itemtbl_daldateformat data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void testQueryForDrop() {

		Connection con = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;

		String seleSql = "SELECT count(*) as table_num FROM user_tables WHERE lower(table_name)='itemtbl_daldateformat'";

		try {
			logger.info("begin to retrieve user_table data.");

			con = dataSource.getConnection();
			pstm = con.prepareStatement(seleSql);
			rs = pstm.executeQuery();
			if (rs.next()) {
				// int num = rs.getInt("table_num");
				int num = rs.getInt(1);
				Assert.assertEquals(num, 0);
			}
			logger.info("user_table data are sucessfully retrieved.");

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
