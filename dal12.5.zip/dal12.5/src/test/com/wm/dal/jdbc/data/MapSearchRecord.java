package com.wm.dal.jdbc.data;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

public class MapSearchRecord implements java.sql.SQLData {

	public static final String SQL_TYPE = "CUSTOMER.WCU_STORE_REC";
	public static final String ARRAY_TYPE = "CUSTOMER.WCU_STORE_TAB";

	private long storeId;
	private String wmStoreNo;
	private long storeType;
	private long latitude;
	private long longtitude;
	private String description;
	private String storeAddress1;
	private String storeAddress2;
	private String storeAddress3;
	private String storeCity;
	private String storeState;
	private String storeZip;
	private String storePhone;
	private String storeHours;
	private double squareFeet;
	private String region;
	private String district;
	private String dmEmail;
	private Date reloOpenDate;
	private String isRelocating;
	private String timeZone;
	private long reloNumber;
	private Date openDate;
	
	public MapSearchRecord() {
		
	}

	public String getSQLTypeName() throws SQLException {
		return SQL_TYPE;
	}

	public void readSQL(SQLInput stream, String typeName)
			throws SQLException {
		
		storeId = stream.readLong();
		wmStoreNo = stream.readString();
		storeType = stream.readLong();
		latitude = stream.readLong();
		longtitude = stream.readLong();
		description = stream.readString();
		storeAddress1 = stream.readString();
		storeAddress2 = stream.readString();
		storeAddress3 = stream.readString();
		storeCity = stream.readString();
		storeState = stream.readString();
		storeZip = stream.readString();
		storePhone = stream.readString();
		storeHours = stream.readString();
		squareFeet = stream.readDouble();
		region = stream.readString();
		district = stream.readString();
		dmEmail = stream.readString();
		reloOpenDate = stream.readDate();
		isRelocating = stream.readString();
		timeZone = stream.readString();
		reloNumber = stream.readLong();
		openDate = stream.readDate();
		
	}

	public void writeSQL(SQLOutput stream) throws SQLException {

		stream.writeLong(storeId);
		stream.writeString(wmStoreNo);
		stream.writeLong(storeType);
		stream.writeLong(latitude);
		stream.writeLong(longtitude);
		stream.writeString(description);
		stream.writeString(storeAddress1);
		stream.writeString(storeAddress2);
		stream.writeString(storeAddress3);
		stream.writeString(storeCity);
		stream.writeString(storeState);
		stream.writeString(storeZip);
		stream.writeString(storePhone);
		stream.writeString(storeHours);
		stream.writeDouble(squareFeet);
		stream.writeString(region);
		stream.writeString(district);
		stream.writeString(dmEmail);
		stream.writeDate(reloOpenDate);
		stream.writeString(isRelocating);
		stream.writeString(timeZone);
		stream.writeLong(reloNumber);
		stream.writeDate(openDate);
		return;
		
	}
	
	public long getStoreId() {
		return storeId;
	}

	public void setStoreId(long storeId) {
		this.storeId = storeId;
	}

	public String getWmStoreNo() {
		return wmStoreNo;
	}

	public void setWmStoreNo(String wmStoreNo) {
		this.wmStoreNo = wmStoreNo;
	}

	public long getStoreType() {
		return storeType;
	}

	public void setStoreType(long storeType) {
		this.storeType = storeType;
	}

	public long getLatitude() {
		return latitude;
	}

	public void setLatitude(long latitude) {
		this.latitude = latitude;
	}

	public long getLongtitude() {
		return longtitude;
	}

	public void setLongtitude(long longtitude) {
		this.longtitude = longtitude;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStoreAddress1() {
		return storeAddress1;
	}

	public void setStoreAddress1(String storeAddress1) {
		this.storeAddress1 = storeAddress1;
	}

	public String getStoreAddress2() {
		return storeAddress2;
	}

	public void setStoreAddress2(String storeAddress2) {
		this.storeAddress2 = storeAddress2;
	}

	public String getStoreAddress3() {
		return storeAddress3;
	}

	public void setStoreAddress3(String storeAddress3) {
		this.storeAddress3 = storeAddress3;
	}

	public String getStoreCity() {
		return storeCity;
	}

	public void setStoreCity(String storeCity) {
		this.storeCity = storeCity;
	}

	public String getStoreState() {
		return storeState;
	}

	public void setStoreState(String storeState) {
		this.storeState = storeState;
	}

	public String getStoreZip() {
		return storeZip;
	}

	public void setStoreZip(String storeZip) {
		this.storeZip = storeZip;
	}

	public String getStorePhone() {
		return storePhone;
	}

	public void setStorePhone(String storePhone) {
		this.storePhone = storePhone;
	}

	public String getStoreHours() {
		return storeHours;
	}

	public void setStoreHours(String storeHours) {
		this.storeHours = storeHours;
	}

	public double getSquareFeet() {
		return squareFeet;
	}

	public void setSquareFeet(double squareFeet) {
		this.squareFeet = squareFeet;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getDmEmail() {
		return dmEmail;
	}

	public void setDmEmail(String dmEmail) {
		this.dmEmail = dmEmail;
	}

	public Date getReloOpenDate() {
		return reloOpenDate;
	}

	public void setReloOpenDate(Date reloOpenDate) {
		this.reloOpenDate = reloOpenDate;
	}

	public String getIsRelocating() {
		return isRelocating;
	}

	public void setIsRelocating(String isRelocating) {
		this.isRelocating = isRelocating;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public long getReloNumber() {
		return reloNumber;
	}

	public void setReloNumber(long reloNumber) {
		this.reloNumber = reloNumber;
	}

	public Date getOpenDate() {
		return openDate;
	}

	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}
	
	public String toString() {
		StringBuilder strBuild = new StringBuilder();
		strBuild.append("MapSearchRecord[ ");
		strBuild.append(storeId + " | ");
		strBuild.append(wmStoreNo + " | ");
		strBuild.append(storeType + " | ");
		strBuild.append(latitude + " | ");
		strBuild.append(longtitude + " | ");
		strBuild.append(description + " | ");
		strBuild.append(storeAddress1 + " | ");
		strBuild.append(storeAddress2 + " | ");
		strBuild.append(storeAddress3 + " | ");
		strBuild.append(storeCity + " | ");
		strBuild.append(storeState + " | ");
		strBuild.append(storeZip + " | ");
		strBuild.append(storePhone + " | ");
		strBuild.append(storeHours + " | ");
		strBuild.append(squareFeet + " | ");
		strBuild.append(region + " | ");
		strBuild.append(district + " | ");
		strBuild.append(dmEmail + " | ");
		strBuild.append(reloOpenDate + " | ");
		strBuild.append(isRelocating + " | ");
		strBuild.append(timeZone + " | ");
		strBuild.append(reloNumber + " | ");
		strBuild.append(openDate + " | ");
		strBuild.append("]");
		return strBuild.toString();
	}
}
