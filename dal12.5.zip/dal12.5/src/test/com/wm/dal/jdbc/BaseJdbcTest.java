/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.jdbc;

import com.wm.sql.DataAccess;
import com.wm.dal.common.ConnectionTypeManager;
import com.bitmechanic.sql.ConnectionPoolManager;
import com.bitmechanic.sql.GenericPool;

import java.sql.*;
import java.util.List;
import java.util.ArrayList;
import java.io.IOException;
import java.net.URL;
  
import com.wm.corelib.config.AppConfig;

/**
 * BaseJdbcTest
 *
 * @author mkishore
 * @since 1.0
 */
public class BaseJdbcTest {

    private static URL lastURL = null;
    public static void load(Class clazz, String file) throws IOException {
        URL url = clazz.getResource(file);
        if (url == null || url.equals(lastURL)) return;
        lastURL = url;
        
        String[] aliases = AppConfig.getInstance().getProperty("com.wm.sql.dataaccess.aliases", "").trim().split(",");
        for (String alias : aliases) {
            if (!"".equals(alias)) for (GenericPool pool : DataAccess.getInstance().getGenericPool(alias)) {
                pool.setLocked(true);
                pool.removeAll();
            }
        }
        AppConfig.getInstance().getProperties().load(clazz.getResourceAsStream(file));
        DataAccess.setInstance(null);
        ConnectionTypeManager.setInstance(null);
    }

    protected void log(String msg) {
        System.out.println(msg);
    }

    protected void safeClose(Connection con) {
        try {
            if (con != null) { // && !con.isClosed()) {
                con.close();
            }
        } catch (SQLException e) {
            System.currentTimeMillis();// e.printStackTrace();
        }
    }

    protected List execute(String pool, String sql, Object... args) {
        List list = null;
        Connection conn = null;
        try {
            conn = DataAccess.getInstance().getConnection(pool);
            list = execute(conn, sql, args);
            conn.commit();
        } catch (Exception e) {
            try { conn.rollback(); } catch (Exception ex) {System.currentTimeMillis();}
            throw new RuntimeException(e);
        } finally {
            safeClose(conn);
        }
        return list;
    }

    protected List execute(Connection conn, String sql, Object... args) {
        List<Object> list = new ArrayList<Object>();
        try {
            System.out.println("SQL: " + sql);
            log("Preparing statement");
            PreparedStatement pstmt = conn.prepareStatement(sql);
            log("Setting parameters");
            for (int i = 0; i < args.length; i++) {
                Object arg = args[i];
                if (arg instanceof Clob) {
                    pstmt.setClob(i+1, (Clob) arg);
                } else if (arg instanceof Blob) {
                    pstmt.setBlob(i+1, (Blob) arg);
                } else if (arg instanceof String) {
                    pstmt.setString(i+1, (String) arg);
                } else {
                    pstmt.setObject(i+1, arg);
                }
            }
            log("Executing statement");
            boolean isRS = pstmt.execute();
            if (isRS) {
                ResultSet rs = pstmt.getResultSet();
                int cols = rs.getMetaData().getColumnCount();
                while (rs.next()) {
                    List<Object> row = new ArrayList<Object>();
                    for (int j = 1; j <= cols; j++) {
                        row.add(rs.getObject(j));
                    }
                    list.add(row);
                }
                log("ResultSet: " + list);
            } else {
                int uc = pstmt.getUpdateCount();
                list.add(uc);
                log("UpdateCount: " + list);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }

    protected Object single(List list) {
        Object first = list.get(0);
        return (first instanceof List) ? ((ArrayList) first).get(0) : first;
    }

    protected int toInt(List list) {
        return ((Number) single(list)).intValue();
    }
}
