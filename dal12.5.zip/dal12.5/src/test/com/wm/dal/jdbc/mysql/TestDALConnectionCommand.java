package com.wm.dal.jdbc.mysql;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;
import javax.sql.DataSource;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.wm.dal.jdbc.DALConnection;
import com.wm.dal.jdbc.util.ExceptionUtil;

/**
 * Copyright 2009 walmart.com. All rights reserved
 */

/**
 * @author Martin Ma
 * @since 2009-5-5
 * @version 1.0 Test JDBC Meta Data on mysql with DALConnection
 */
public class TestDALConnectionCommand extends BaseMysqlTest {

	@Test(groups = { "mysql", "connectionCommand" })
	public void testMetaData() {
		Connection con = null;
		ResultSet rs = null;
		try {
			logger.info("BEGIN,TEST CONNECTION COMMAND METADATA.");
			con = dataSource.getConnection();

			try {
				String jdbcDrivName = con.getMetaData().getDriverName();
				logger.info("JDBC Driver Name: " + jdbcDrivName);
			} catch (SQLException e) {
				ExceptionUtil.handlerMethodNotImp(e, logger, "con.getMetaData().getDriverName()");
			}
			logger.info("DONE,TEST CONNECTION COMMAND METADATA.");
		} catch (SQLException e) {
			e.printStackTrace();
			Assert.fail();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Test(groups = { "mysql", "metadata" })
	public void testClose() {
		Connection con = null;
		ResultSet rs = null;
		try {
			logger.info("BEGIN,TEST CONNECTION COMMAND CLOSE.");
			con = dataSource.getConnection();
			try {
				con.close();
			} catch (SQLException e) {
				ExceptionUtil.handlerMethodNotImp(e, logger, "con.getMetaData().getDriverName()");
			}
			logger.info("DONE,TEST CONNECTION COMMAND CLOSE.");
		} catch (SQLException e) {
			Assert.fail();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	@Test(groups = { "mysql", "metadata" })
	public void testClearWarming() {
		Connection con = null;
		ResultSet rs = null;
		try {
			logger.info("BEGIN,TEST CONNECTION COMMAND CLEARWARMING.");
			con = dataSource.getConnection();

			try {
				con.clearWarnings();
			} catch (SQLException e) {
				ExceptionUtil.handlerMethodNotImp(e, logger, "con.getMetaData().getDriverName()");
			}
			logger.info("DONE,TEST CONNECTION COMMAND CLEARWARMING.");
		} catch (SQLException e) {
			Assert.fail();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	@Test(groups = { "mysql", "metadata" })
	public void testReadOnly_Closed() {
		Connection con = null;
		ResultSet rs = null;
		try {
			logger.info("BEGIN,TEST CONNECTION COMMAND IS READONLY CLOSED.");
			con = dataSource.getConnection();

			try {
				boolean isclosed = con.isClosed();
				boolean isreadonly = con.isReadOnly();
				Assert.assertEquals(isclosed, false);
				Assert.assertEquals(isreadonly, false);
			} catch (SQLException e) {
				ExceptionUtil.handlerMethodNotImp(e, logger, "con.getMetaData().getDriverName()");
			}
			logger.info("DONE,TEST CONNECTION COMMAND IS READONLY CLOSED.");
		} catch (SQLException e) {
			Assert.fail();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Test(groups = { "mysql", "metadata" })
	public void testPing() {
		Connection con = null;
		try {
			logger.info("BEGIN,TEST CONNECTION COMMAND IS READONLY CLOSED.");
			con = dataSource.getConnection();
	
			try {
				con.isValid(1);

			} catch (SecurityException e) {
				e.printStackTrace();
			}
			logger.info("DONE,TEST CONNECTION COMMAND IS READONLY CLOSED.");
		} catch (SQLException e) {
			Assert.fail();
		} finally {
			try {
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	@Test(groups = { "mysql", "metadata" })
	public void testRollback() {
		Connection con = null;
		try {
			logger.info("BEGIN,TEST CONNECTION COMMAND IS READONLY CLOSED.");
			con = dataSource.getConnection();
	
			try {
				con.rollback();

			} catch (SecurityException e) {
				e.printStackTrace();
			}
			logger.info("DONE,TEST CONNECTION COMMAND IS READONLY CLOSED.");
		} catch (SQLException e) {
			Assert.fail();
		} finally {
			try {
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}