package com.wm.dal.jdbc.mysql;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.testng.annotations.Test;

//@Test(sequential=true)
public class TestProcedureMysql extends BaseMysqlTest {

	/**
	 * this method is used to test driver stored procedure supporting functions
	 * via mysql database 
	 * 1) has input  parameter for procedure 
	 * 2) has output parameter for procedure 
	 * 3) may return multi-resultset
	 * 
	 *	CREATE PROCEDURE proc_test(in input INT, out output INT) 
	 *	begin 
	 *	    set output = 2 * input; 
	 *	    if input = 1 then
	 *	        select input,  'only one result' ; 
	 *	    else 
	 *	        select input,  'first result' ; 
	 *	        select input, input+1,  'second result' ;    
	 *	    end if; 
	 *	end;
	 */
	//@Test(groups = {"mysql", "sp_create"} )
	public void testProcedureCreate() {
		Connection con = null;
		Statement pstm = null;
		ResultSet rs = null;
		String createSP = ""
				+ "CREATE PROCEDURE proc_test(in input INT, out output INT) "
				+ "begin                                                    "
				+ "     set output = 2 * input;                             "
				+ "     if input = 1 then                                   "
				+ "         select input,  'only one result' ;              "
				+ "     else                                                "
				+ "         select input,  'first result' ;                 "
				+ "         select input, input+1,  'second result' ;       "
				+ "     end if;                                             " 
				+ "end;                                                     ";
		try {
			logger.info("creating PROCEDURE proc_test" );
//			con = dataSource.getConnection();
			con = pureDataSource.getConnection();
			pstm = con.createStatement();
			pstm.executeUpdate(createSP);
//			con.commit();
			logger.info("created  PROCEDURE proc_test" );
			
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)		rs.close();
				if (pstm != null)	pstm.close();
				if (con != null)	con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}	

	
	//@Test(dependsOnMethods = "testProcedureCreate", groups = {"mysql", "sp_call"} )
	public void testProcedureCall() {
		Connection con = null;
		CallableStatement stmt = null;
		ResultSet rs = null;
		String callSP = "{ call proc_test(?,?) }";
		
		try {
			logger.info("calling PROCEDURE proc_test" );
			con = dataSource.getConnection();
			stmt = con.prepareCall(callSP);
			stmt.setInt(1, 100);
			stmt.registerOutParameter(2, java.sql.Types.INTEGER);

			boolean hadResults = stmt.execute();
			while (hadResults) {
				rs = stmt.getResultSet();
				logger.info("ResultSet:");
				while (rs.next()) {
					int columnCount = rs.getMetaData().getColumnCount();
					String oneRow = "[";
					for (int i = 0; i < columnCount; i++) {
						oneRow += rs.getString(i + 1) + " | ";
					}
					logger.info(oneRow + "]");
				}
				hadResults = stmt.getMoreResults();
			}

			int outputValue = stmt.getInt(2);
			logger.info("\nOutParameter [int]: " + outputValue);
			
			con.commit();
			logger.info("called  PROCEDURE proc_test" );

		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)			rs.close();
				if (stmt != null)		stmt.close();
				if (con != null)		con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}	

	
	//@Test(dependsOnMethods = "testProcedureCall", groups = {"mysql", "sp_drop"} )
	public void testProcedureDrop() {
		Connection con = null;
		Statement pstm = null;
		String dropSP = "DROP PROCEDURE IF EXISTS proc_test;";

		try {
			logger.info("dropping PROCEDURE proc_test" );
//			con = dataSource.getConnection();
			con = pureDataSource.getConnection();
			pstm = con.createStatement();
			pstm.executeUpdate(dropSP);
//			con.commit();
			logger.info("dropped  PROCEDURE proc_test" );
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstm != null)	pstm.close();
				if (con != null)	con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
}

