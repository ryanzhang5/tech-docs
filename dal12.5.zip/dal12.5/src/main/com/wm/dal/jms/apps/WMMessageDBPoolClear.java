package com.wm.dal.jms.apps;

import java.util.HashMap;
import com.wm.weblib.jms.WMMessageException;
import com.wm.weblib.jms.WMMessageType;


public class WMMessageDBPoolClear extends WMMessageDBPool {

	public WMMessageDBPoolClear(String target, String poolType)
	{
		super(WMMessageType.MSG_TYPE_CLEAR_DB_POOL, target, poolType);
	}

	public WMMessageDBPoolClear(HashMap valueMap)
		throws WMMessageException
	{
		super(WMMessageType.MSG_TYPE_CLEAR_DB_POOL, valueMap);
	}
}
