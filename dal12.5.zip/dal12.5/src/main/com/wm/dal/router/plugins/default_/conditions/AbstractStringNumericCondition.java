/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.conditions;

import com.wm.dal.router.plugins.default_.ICondition;

import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.logging.Logger;
import java.util.logging.Level;

/**
 * AbstractStringNumericCondition
 *
 * @author mkishore
 * @since 1.1
 */
public abstract class AbstractStringNumericCondition<T> implements ICondition<T> {
    private static final Logger logger = Logger.getLogger(AbstractStringNumericCondition.class.getName());

    private String regex;
    private boolean caseInsensitive;
    private String prefix;
    private int min = -1;
    private int max = -1;
    private String suffix;
    private Pattern pattern;
    private int prefixLength;
    private int suffixLength;

    /**
     * This method should be called after creating the condition and injecting
     * all its dependencies. The implmentations can use this method to validate
     * that the instance has been configured correctly.
     *
     * @throws IllegalStateException - if there are errors in the configuration
     */
    public void initialize() throws IllegalStateException {
        if (regex == null && prefix == null && suffix == null && min == -1 && max == -1) {
            throw new IllegalStateException("One of the following needs to be specified: regex, prefix, suffix, min, max");
        }
        if (regex != null && (prefix != null || suffix != null || min != -1 || max != -1)) {
            throw new IllegalStateException("Only one of the following should be specified: regex or {prefix,min,max,suffix}");
        }
        if ((prefix != null || suffix != null) && (min != -1 && max != -1 && min > max)) {
            throw new IllegalStateException("The min cannot be greater than the max");
        }

        if (prefix != null || suffix != null || min != -1 || max != -1) {
            if (prefix == null) prefix = "";
            if (suffix == null) suffix = "";
            regex = prefix + "(\\d*)" + suffix;
        }
        try {
            int flags = (caseInsensitive) ? Pattern.CASE_INSENSITIVE : 0;
            pattern = Pattern.compile(regex, flags);
        } catch (Exception e) {
            throw new IllegalStateException("Error compiling the regex pattern: " + regex, e);
        }
    }

    /**
     * Returns true if the client's hostname matches the condition represented
     * by this instance.
     *
     * @param context the context object
     * @return true if the client's hostname matches this condition
     */
    public boolean evaluate(T context) {
        boolean ret = false;
        String stringToTest = getStringToTest(context);
        if (stringToTest == null) {
            ret = false;
            if (logger.isLoggable(Level.FINE)) {
                logger.fine(this.getClass().getSimpleName() + " - Evaluated string [null]: " + ret);
            }
        } else if (pattern != null) {
            Matcher matcher = pattern.matcher(stringToTest);
            ret = matcher.matches();
            if (logger.isLoggable(Level.FINE)) {
                logger.fine(this.getClass().getSimpleName() + " - Evaluated string [" + stringToTest + "] against regex [" + regex + "]: " + ret);
            }
            if (ret && (min != -1 || max != -1) && matcher.groupCount() > 0) {
                String str = matcher.group(1);
                if (str == null || "".equals(str)) {
                    ret = false;
                } else {
                    int num = Integer.parseInt(str);
                    if (min != -1) ret = min <= num;
                    if (max != -1) ret = ret && max >= num;
                }
                if (logger.isLoggable(Level.FINE)) {
                    logger.fine(this.getClass().getSimpleName() + " - Evaluated string [" + stringToTest + "] against"
                            + " prefix [" + prefix + "], suffix [" + suffix + "]"
                            + ", min [" + min + "], max [" + max + "]"
                            + ": " + ret);
                }
            }
        }
        return ret;
    }

    /**
     * Returns the string that needs to be tested.
     *
     * @param context - the context object
     * @return the string that needs to be tested
     */
    protected abstract String getStringToTest(T context);

    // GETTERS and SETTERS

    public String getRegex() {
        return regex;
    }

    public void setRegex(String regex) {
        this.regex = regex;
    }

    public boolean isCaseInsensitive() {
        return caseInsensitive;
    }

    public void setCaseInsensitive(boolean caseInsensitive) {
        this.caseInsensitive = caseInsensitive;
    }

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }

    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }
}
