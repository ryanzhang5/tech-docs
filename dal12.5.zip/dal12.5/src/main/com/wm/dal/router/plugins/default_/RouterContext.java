/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_;

import com.wm.dal.router.IRouterRequest;
import com.wm.dal.router.IRouterResponse;

/**
 * RouterContext - wrapper class to provide access to both request and response.
 *
 * @author mkishore
 * @version $Revision: 1.2 $
 * @since 1.0
 */
public class RouterContext {
    private IRouterRequest request;
    private IRouterResponse response;
    // for a named "break"
    private String breakToRuleName;

    /**
     * Creates a context object.
     *
     * @param request - router request
     * @param response - router response
     */
    public RouterContext(IRouterRequest request, IRouterResponse response) {
        this.request = request;
        this.response = response;
    }

    public IRouterRequest getRequest() {
        return request;
    }

    public IRouterResponse getResponse() {
        return response;
    }

    public String getBreakToRuleName() {
        return breakToRuleName;
    }

    public void setBreakToRuleName(String breakToRuleName) {
        this.breakToRuleName = breakToRuleName;
    }
}
