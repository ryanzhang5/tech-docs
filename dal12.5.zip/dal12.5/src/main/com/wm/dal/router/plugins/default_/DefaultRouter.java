/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_;

import com.wm.dal.router.IRouter;
import com.wm.dal.router.IRouterRequest;
import com.wm.dal.router.IRouterResponse;

import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
  
import com.wm.corelib.config.AppConfig;

/**
 * DefaultRouter - is configured using an xml file that satisfies the routing-rules.xsd schema.
 * When loaded via Spring, the location of the configuration file can be specified either
 * - as a classpath resource (default), or
 * - as a file-system path (by prefixing "file:" to the path)
 * Typically, this path will be provided in the connection-types.xml file.
 *
 * @author mkishore
 * @since 1.0
 */
public class DefaultRouter implements IRouter {
    private static final Logger logger = Logger.getLogger(DefaultRouter.class.getName());

    private static final int MAX_BREAK_COUNT = 10;

    private String name;
    private boolean enabled;
    private long refreshInterval;
    private List<IRoutingRulesProvider> routingRulesProviders;
    private IRoutingRulesProvider currentRulesProvider;

    private List<RoutingRule> routingRules = new ArrayList<RoutingRule>();
    private Map<String, Integer> ruleNameToIndex = new HashMap<String, Integer>();

    private boolean initialized = false;
    private volatile boolean isRefreshing = false;
    
    private static File routingRulesDir;
    static {
        try {
            String home= AppConfig.getInstance().getProperty("com.wm.app.home", "/tmp");
            routingRulesDir = new File(home, "dal-routing-rules");
            boolean exists = routingRulesDir.exists();
            if (!exists) {
                exists = routingRulesDir.mkdirs();
            }
            if (!exists) {
                throw new RuntimeException("The directory does not exist: " + routingRulesDir.getAbsolutePath());
            } else if (!routingRulesDir.canRead() || !routingRulesDir.canWrite()) {
                throw new RuntimeException("The directory does not have read/write permissions: " + routingRulesDir.getAbsolutePath());
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error fetching the directory for storing fallback routing-rules", e);
            routingRulesDir = null;
        }
        logger.info("The fallback routing-rules directory is set to: " + (routingRulesDir != null ?routingRulesDir.getAbsolutePath() :"null"));
    }

    /**
     * Returns the name of the router instance.
     *
     * @return the name of the router instance
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the router instance.
     *
     * @param name - the name of the router instance
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns true if the router is enable, otherwise false
     *
     * @return - boolean
     */
    public boolean isEnabled() {
        return enabled;  //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * Method to enable/disable a specific router
     *
     * @param routerEnabled - boolean
     */
    public void setEnabled(boolean routerEnabled) {
        this.enabled = routerEnabled;
    }

    /**
     * Method returns Refresh Interval Period
     *
     * @return - the interval in millis (e.g. 5000 for five seconds)
     */
    public long getRefreshInterval() {
        return refreshInterval;
    }

    /**
     * Method to set the Refresh Interval Period
     *
     * @param refreshInterval - the interval in millis (e.g. 5000 for five seconds)
     */
    public void setRefreshInterval(long refreshInterval) {
        this.refreshInterval = refreshInterval;
    }

    /**
     * Returns the list of routing-rules-provider associated with this router.
     *
     * @return the list of routing-rules-provider associated with this router
     */
    public List<IRoutingRulesProvider> getRoutingRulesProviders() {
        return routingRulesProviders;
    }

    /**
     * Sets the list of routing-rules-provider associated with this router.
     *
     * @param routingRulesProviders the list of routing-rules-provider associated with this router
     */
    public void setRoutingRulesProviders(List<IRoutingRulesProvider> routingRulesProviders) {
        this.routingRulesProviders = routingRulesProviders;
        if (routingRulesProviders != null) {
            for (IRoutingRulesProvider routingRulesProvider : routingRulesProviders) {
                routingRulesProvider.setRouter(this);
            }
        }
    }

    /**
     * Loads the router rules from a configuration file. In case of any errors (e.g. missing file,
     * corrupt file etc.), the router keeps working with the older configuration. Only when a file
     * is read successfully, the router replaces older data-structures with the new one.
     */
    public synchronized void refresh() {
        if (routingRulesProviders == null || routingRulesProviders.isEmpty()) {
            logger.warning("The router [" + getName() + "] does not have a routing-rules-provider!");
            return;
        }
      
        //Adding isRefreshing logic in case if we run DAL in CLIENT mode, it was causing problem
        if (isRefreshing) {
          logger.warning("The router [" + getName() + "] is in process of refreshing!");
          return;
        }
        isRefreshing = true;
        for (IRoutingRulesProvider routingRulesProvider : routingRulesProviders) {
            try {
                // do NOT change the order of clauses in the following IF statement
                if (routingRulesProvider.needsRefresh() || routingRulesProvider != currentRulesProvider) {
                    logger.info("Refreshing the configuration for router [" + getName() + "]");
                    byte[] bytes = routingRulesProvider.getRoutingRules();
                    InputStream stream = new ByteArrayInputStream(bytes);
                    parseRoutingRules(stream);
                    saveFallbackRules(bytes);
                    currentRulesProvider = routingRulesProvider;
                }
                break; // stop as soon as we process a provider successfully
            } catch (Exception e) {
                // logging at INFO level - as we expect the FileBasedRouter to keep failing
                logger.log(Level.INFO, "Error parsing the rules for router [" + getName() + "] from provider [" + routingRulesProvider.getName() + "]: " + e.getMessage());
                logger.log(Level.FINE, "", e);
            }
        }
        // we only use the fallback rules at startup (when all the providers fail)
        // once we have something loaded into memory, we do not use the fallback rules
        if (routingRules == null || routingRules.isEmpty()) {
            loadFallbackRules();
        }
        initialized = true;
        isRefreshing = false;
    }

    private void parseRoutingRules(InputStream stream) throws Exception {
        routingRules = new RoutingRulesParser().parse(stream);
        // and then, clear+update the name->rule mapping
        ruleNameToIndex.clear();
        for (int i = 0; i < routingRules.size(); i++) {
            RoutingRule rule = routingRules.get(i);
            if (rule.getName() != null) {
                ruleNameToIndex.put(rule.getName(), i);
            }
        }
    }

    private File getFallbackFile() {
        return (routingRulesDir != null) ?new File(routingRulesDir, getName() + ".xml") :null;
    }

    private void saveFallbackRules(byte[] bytes) {
        File file = getFallbackFile();
        try {
            if (file == null) {
                logger.warning("Cannot save the fallback routing-rules - due to error in directory configuration");
                return;
            }
            logger.info("Trying to save the fallback routing-rules to [" + file + "]");
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(bytes);
            fos.flush();
            fos.close();
        } catch (Exception e) {
            logger.log(Level.WARNING, "Error trying to save the fallback routing-rules to [" + file + "]", e);
        }
    }

    private void loadFallbackRules() {
        File file = getFallbackFile();
        try {
            if (file == null) {
                logger.severe("Cannot load the fallback routing-rules - due to error in directory configuration");
                return;
            }
            logger.info("Trying to load the fallback routing-rules from [" + file + "]");
            if (file.exists() && file.isFile() && file.canRead()) {
                parseRoutingRules(new FileInputStream(file));
            } else {
                throw new RuntimeException("The file does not exist or has cannot be read");
            }
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error trying to load the fallback routing-rules from [" + file + "]", e);
        }
    }

    /**
     * Route method to route the requst to the router
     * Router response will set the pool name and send it back to the router
     * which will be use by Connection Type to connect to the database
     *
     * @param req - IRouterRequest
     * @param res - IRouterResponse
     */
    public void route(IRouterRequest req, IRouterResponse res) {
        if (!initialized) refresh();
        
        RouterContext context = new RouterContext(req, res);
        int breakCount = 0;
        for (int i = 0; i < routingRules.size();) {
            RoutingRule rule = routingRules.get(i);
            IStatement.Status status = rule.execute(context);
            if (status.equals(IStatement.Status.BREAK)) {
                breakCount++;
                if (breakCount >= MAX_BREAK_COUNT) {
                    throw new RuntimeException("The number of <break> commands exceeded the maximum allowed count: " + MAX_BREAK_COUNT);
                }
                String name = context.getBreakToRuleName();
                context.setBreakToRuleName(null);
                if (name != null && ruleNameToIndex.containsKey(name)) {
                    i = ruleNameToIndex.get(name);
                }
            } else if (status.equals(IStatement.Status.RETURN)) {
                return;
            } else {
                i++;
            }
        }
    }

    /**
     * Accessor for subclasses and/or unit testing.
     *
     * @return the list of routing rules for this router
     */
    protected List<RoutingRule> getRoutingRules() {
        return Collections.unmodifiableList(routingRules);
    }

}
