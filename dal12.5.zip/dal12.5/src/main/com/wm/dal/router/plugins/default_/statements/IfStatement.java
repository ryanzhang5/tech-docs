/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.statements;

import com.wm.dal.router.plugins.default_.AbstractConditionalStatement;

/**
 * IfStatement - basic if-then-else statement
 *
 * @author mkishore
 * @since 1.0
 */
public class IfStatement<T> extends AbstractConditionalStatement<T> {

}
