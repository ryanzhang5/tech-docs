/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.conditions;

import com.wm.dal.router.plugins.default_.ICondition;
import com.wm.dal.router.plugins.default_.RouterContext;
import com.wm.dal.common.DALSession;
import com.wm.dal.jdbc.utils.MethodAttribute;

import java.util.regex.Pattern;
import java.util.logging.Logger;
import java.util.logging.Level;

/**
 * ServerModeCondition - returns true if the router is running on a DAL server.
 *
 * @author mkishore
 * @since 1.1
 */
public class ServerModeCondition implements ICondition<RouterContext> {
    private static final Logger logger = Logger.getLogger(ServerModeCondition.class.getName());

    /**
     * This method should be called after creating the condition and injecting
     * all its dependencies. The implmentations can use this method to validate
     * that the instance has been configured correctly.
     *
     * @throws IllegalStateException - if there are errors in the configuration
     */
    public void initialize() throws IllegalStateException {
        // no-op
    }

    /**
     * Returns true if the the router is running on the DAL server.
     *
     * @param context - the context object
     * @return true if the string value matches the regex pattern.
     */
    public boolean evaluate(RouterContext context) {
        DALSession session = context.getRequest().getSession();
        boolean ret = false;
        if (session != null) {
            MethodAttribute attribute = session.getConnecitonAttribute(MethodAttribute.SERVER_MODE);
            ret = (attribute != null && Boolean.TRUE.equals(attribute.getAttribute()));
        }
        if (logger.isLoggable(Level.FINE)) {
            logger.fine(this.getClass().getSimpleName() + " - Evaluated to: " + ret);
        }
        return ret;
    }

    // GETTERS and SETTERS

}