/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.statements;

import com.wm.dal.router.plugins.default_.IStatement;
import com.wm.dal.router.plugins.default_.RouterContext;

import java.util.logging.Logger;
import java.util.logging.Level;

/**
 * BreakStatement - allows the control flow to be interrupted. By default, the execution
 * proceeds at the next routing-rule. If a rule-name is specficied, then the engine will
 * try to lookup the named rule and proceed from there.
 *
 * @author mkishore
 * @since 1.0
 */
public class BreakStatement implements IStatement<RouterContext> {
    private static final Logger logger = Logger.getLogger(BreakStatement.class.getName());

    private String ruleName;

    /**
     * No-op
     */
    public void initialize() throws IllegalStateException {
        // no-op
    }

    /**
     * Returns a suitable status to result in a "break"
     *
     * @param context - the execution context
     * @return the status controlling further execution path
     */
    public Status execute(RouterContext context) {
        if (ruleName != null) {
            context.setBreakToRuleName(ruleName);
        }
        if (logger.isLoggable(Level.FINE)) {
            logger.fine(this.getClass().getSimpleName() + " - Executed. ruleName [" + ruleName + "]");
        }
        return Status.BREAK;
    }

    // GETTERS and SETTERS

    public String getRuleName() {
        return ruleName;
    }

    public void setRuleName(String ruleName) {
        this.ruleName = ruleName;
    }
}
