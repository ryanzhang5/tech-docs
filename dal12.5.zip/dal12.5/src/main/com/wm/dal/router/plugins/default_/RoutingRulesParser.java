/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_;

import com.wm.dal.router.plugins.default_.conditions.*;
import com.wm.dal.router.plugins.default_.statements.*;
import org.apache.commons.beanutils.BeanUtils;
import org.w3c.dom.*;
import org.xml.sax.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 * RoutingRulesParser - parser for the routing-rules.xml file
 *
 * @author mkishore
 * @since 1.0
 */
public class RoutingRulesParser {
    private static final Logger logger = Logger.getLogger(RoutingRulesParser.class.getName());

    private static final String SYSTEM_ID = "http://www.walmart.com/dal/routing-rules/routing-rules.xsd";

    // ref: http://www.ibm.com/developerworks/xml/library/x-tipvalschm/
    private static final String SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
    private static final String XML_SCHEMA = "http://www.w3.org/2001/XMLSchema";

    public List<RoutingRule> parse(InputStream in) {
        List<RoutingRule> rules = new ArrayList<RoutingRule>();

        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(true);
            factory.setValidating(true);
            try {
                factory.setAttribute(SCHEMA_LANGUAGE, XML_SCHEMA);
                // xerces specific way of validating against a schema
                // factory.setFeature("http://apache.org/xml/features/validation/schema", true);
            } catch (Exception e) {
                logger.info("The logger does not support JAXP 1.2");
            }

            DocumentBuilder builder = factory.newDocumentBuilder();
            builder.setErrorHandler(getErrorHandler());
            builder.setEntityResolver(getEntityResolver());


            Document doc = builder.parse(in);
            NodeList nl = doc.getDocumentElement().getElementsByTagName("routing-rule");
            for (int i = 0; i < nl.getLength(); i++) {
                Element el = (Element) nl.item(i);
                RoutingRule rule = parseRule(el);
                rules.add(rule);
            }

        } catch (Exception e) {
            throw new RuntimeException("Error parsing the routing rules", e);
        }

        return rules;
    }

    protected ErrorHandler getErrorHandler() {
        return new ErrorHandler() {
            public void warning(SAXParseException exception) throws SAXException {
                // no-op
            }

            public void error(SAXParseException exception) throws SAXException {
                throw exception;
            }

            public void fatalError(SAXParseException exception) throws SAXException {
                throw exception;
            }
        };
    }

    protected EntityResolver getEntityResolver() {
        return new EntityResolver() {
            public InputSource resolveEntity(String publicId, String systemId) throws SAXException, IOException {
                if (SYSTEM_ID.equals(systemId)) {
                    return new InputSource(this.getClass().getResourceAsStream("routing-rules.xsd"));
                } else {
                    return new InputSource(new URL(systemId).openStream());
                }
            }
        };
    }

    protected RoutingRule parseRule(Element el) {
        RoutingRule rule = parseElement(el, new RoutingRule());
        parseConditionalStatement(el, rule);
        return rule;
    }

    protected void parseConditionalStatement(Element el, AbstractConditionalStatement statement) {
        statement.setCondition(parseConditions(getEl(el, "condition")).get(0));
        statement.setThenStatements(parseStatements(getEl(el, "then")));
        statement.setElseStatements(parseStatements(getEl(el, "else")));
    }

    protected ICondition parseCondition(Element el) {
        if (el == null) return null;

        ICondition condition = null;
        if (el.getNodeName().equals("and")) {
            condition = parseElement(el, new AndCondition<RouterContext>());
        } else if (el.getNodeName().equals("client-host")) {
            condition = parseElement(el, new ClientHostCondition());
        } else if (el.getNodeName().equals("not")) {
            condition = parseElement(el, new NotCondition<RouterContext>());
        } else if (el.getNodeName().equals("or")) {
            condition = parseElement(el, new OrCondition<RouterContext>());
        } else if (el.getNodeName().equals("pool-name")) {
            condition = parseElement(el, new PoolNameCondition());
        } else if (el.getNodeName().equals("server-mode")) {
            condition = parseElement(el, new ServerModeCondition());
        } else if (el.getNodeName().equals("sql-string")) {
            condition = parseElement(el, new SqlStringCondition());
        } else if (el.getNodeName().equals("session-id")) {
            condition = parseElement(el, new SessionIDCondition());
        } else if (el.getNodeName().equals("xor")) {
            condition = parseElement(el, new XorCondition<RouterContext>());
        }
        if (condition instanceof AbstractCompositeCondition) {
            ((AbstractCompositeCondition) condition).setConditions(parseConditions(el));
        }

        if (condition != null) condition.initialize();
        return condition;
    }

    protected IStatement parseStatement(Element el) {
        if (el == null) return null;

        IStatement statement = null;
        if (el.getNodeName().equals("break")) {
            statement = parseElement(el, new BreakStatement());
        } else if (el.getNodeName().equals("if")) {
            statement = parseElement(el, new IfStatement<RouterContext>());
            parseConditionalStatement(el, (AbstractConditionalStatement) statement);
        } else if (el.getNodeName().equals("return")) {
            statement = parseElement(el, new ReturnStatement());
        } else if (el.getNodeName().equals("set-pool-name")) {
            statement = parseElement(el, new SetPoolNameStatement());
        } else if (el.getNodeName().equals("set-sql-string")) {
            statement = parseElement(el, new SetSqlStringStatement());
        }

        if (statement != null) statement.initialize();
        return statement;
    }

    protected List<ICondition> parseConditions(Element el) {
        List<ICondition> conditions = new ArrayList<ICondition>();
        if (el == null) return conditions;

        NodeList nl = el.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++) {
            Node node = nl.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                conditions.add(parseCondition((Element) node));
            }
        }
        return conditions;
    }

    protected List<IStatement> parseStatements(Element el) {
        List<IStatement> statements = new ArrayList<IStatement>();
        if (el == null) return statements;

        NodeList nl = el.getChildNodes();
        for (int i = 0; i < nl.getLength(); i++) {
            Node node = nl.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                statements.add(parseStatement((Element) node));
            }
        }
        return statements;
    }

    /**
     * Parses an element and converts it into a java-bean (using reflection)
     *
     * @param el       - the element to be read
     * @param javabean - the java-bean instance
     * @return properly initialized java-bean instance
     */
    protected <T> T parseElement(Element el, T javabean) {
        if (el == null) return null;
        try {
            NamedNodeMap attributes = el.getAttributes();
            for (int i = 0; i < attributes.getLength(); i++) {
                Attr attribute = (Attr) attributes.item(i);
                String name = fixAttributeName(attribute.getName());
                String value = attribute.getValue();
                BeanUtils.setProperty(javabean, name, value);
            }
            return javabean;
        } catch (Exception e) {
            throw new RuntimeException("Error parsing element: " + el + " into an object of the class: " + javabean.getClass(), e);
        }
    }

    /**
     * converts strings like "case-insensitive" to "caseInsensitive"
     *
     * @param name - attribute name
     * @return java property name
     */
    protected String fixAttributeName(String name) {
        if (name.indexOf('-') == -1) return name;
        int len = name.length();
        StringBuffer sb = new StringBuffer(len);
        for (int i = 0; i < len; i++) {
            char ch = name.charAt(i);
            if (ch == '-') {
                if (++i < len) {
                    ch = Character.toUpperCase(name.charAt(i));
                }
            }
            sb.append(ch);
        }
        return sb.toString();
    }

    protected Element getEl(Element el, String name) {
        if (el == null) return null;
        NodeList nl = el.getChildNodes();
        for (int i=0; i < nl.getLength(); i++) {
            Node child = nl.item(i);
            if (child != null
                    && child.getNodeType() == Node.ELEMENT_NODE
                    && child.getLocalName().equals(name)) {
                return (Element) child;
            }
        }
        return null;
    }

}
