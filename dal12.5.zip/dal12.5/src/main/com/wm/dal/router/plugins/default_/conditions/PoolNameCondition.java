/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.conditions;

import com.wm.dal.router.plugins.default_.RouterContext;

/**
 * PoolNameCondition - evaluates a condition based on the current value
 * of the pool-name.
 *
 * @author mkishore
 * @since 1.0
 */
public class PoolNameCondition extends AbstractStringCondition<RouterContext> {

    /**
     * Returns the current value of the pool-name
     *
     * @param context - the router context
     * @return the current value of the pool-name
     */
    protected String getStringToTest(RouterContext context) {
        return context.getResponse().getPoolName();
    }

}