/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.conditions;

import com.wm.dal.router.plugins.default_.RouterContext;

/**
 * SqlStringCondition - evaluates a condition based on the value of the SQL
 * string being executed.
 *
 * @author mkishore
 * @since 1.0
 */
public class SqlStringCondition extends AbstractStringCondition<RouterContext> {

    /**
     * Returns the value of the SQL string being executed.
     *
     * @param context - the context object
     * @return the value of the SQL string being executed
     */
    protected String getStringToTest(RouterContext context) {
        return context.getRequest().getSession().getSQL();
    }

}