/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.conditions;

import com.wm.dal.router.plugins.default_.RouterContext;

/**
 * Session ID - return the session ID from the DAL Session
 * 
 *
 * @author cshah
 * @since 1.0
 */
public class SessionIDCondition extends AbstractSessionCondition<RouterContext> {

    /**
     * Returns the value of the Session string.
     *
     * @param context - the context object
     * @return the value of the Session ID 
     */
    protected String getSessionID(RouterContext context) {
        return context.getRequest().getSession().getSessionID();
    }

}