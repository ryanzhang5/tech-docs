/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.conditions;

import com.wm.dal.router.plugins.default_.ICondition;

import java.util.logging.Logger;
import java.util.logging.Level;

/**
 * AbstractSessionCondition.
 *
 * @author cshah
 * @since 1.0
 */
public abstract class AbstractSessionCondition<T> implements ICondition<T> {
    private static final Logger logger = Logger.getLogger(AbstractSessionCondition.class.getName());
    private int mod = -1;
    private int equals = -1;
  
    /**
     * This method should be called after creating the condition and injecting
     * all its dependencies. The implmentations can use this method to validate
     * that the instance has been configured correctly.
     *
     * @throws IllegalStateException - if there are errors in the configuration
     */
    public void initialize() throws IllegalStateException {
    }

    /**
     * Returns true if Session ID hascode mode mod returns equals value.
     *
     * @param context - the context object
     * @return true 
     */
    public boolean evaluate(T context) {
        boolean ret = false;
        String sessionID = getSessionID(context);
        if (sessionID == null || sessionID.isEmpty()) {
            ret = false;
        } else if (mod <= 0 || equals < 0) {
            ret = false;
        } else if (mod > 0 && equals >= 0) {
            int hashCode = sessionID.hashCode() < 0 ? sessionID.hashCode() * -1 : sessionID.hashCode();
              if (hashCode % mod == equals) {
                ret = true;
              }
          }
        if (logger.isLoggable(Level.FINE)) {
            logger.fine(this.getClass().getSimpleName() + " - Evaluated Session ID [" + sessionID + "] hashcode [" + sessionID.hashCode() + 
                                  "] against mod [" + mod  + "] equal condition [" + equals  + "] returned " + ret);
        }
        return ret;
    }

    /**
     * Returns the session ID.
     *
     * @param context - the context object
     * @return the session ID
     */
    protected abstract String getSessionID(T context);


    /**
     *
     * @param mod
     */
    public void setMod(int mod) {
      this.mod = mod;
    }
  
    /**
     *
     * @return
     */
    public int getMod() {
      return mod;
    }
  
    /**
     *
     * @param equals
     */
    public void setEquals(int equals) {
      this.equals = equals;
    }
  
    /**
     *
     * @return
     */
    public int getEquals() {
      return equals;
    }
}
