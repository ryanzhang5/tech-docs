/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.router;

/**
 * Router Response Interface to set the Connection Pool Name and whether should be chain through
 * next router or not?
 */
public interface IRouterResponse {
    /**
     * Method returns the pool name 
     * @return - Connection Pool Name
     */
    public String getPoolName();

    /**
     * Method returns the pool name 
     * @return - Connection Pool Name
     */
    public void setPoolName(String poolName);

    /**
     * true if next router should be executed in sequence, 
     * false to stop executing next router
     * @return - true/false
     */
    public boolean getShouldChainThroughNextRouter();

    /**
     * Method sets the value controlling the execution of next router.
     *
     * @param shouldChainThroughNextRouter - true, if we wish to execute the next router
     */
    public void setShouldChainThroughNextRouter(boolean shouldChainThroughNextRouter);
}
