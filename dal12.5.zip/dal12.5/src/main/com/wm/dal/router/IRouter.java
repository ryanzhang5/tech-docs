/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.router;

/**
 * Router Interface to be implemencted by the Application Developer
 */
public interface IRouter {

    /**
     * Returns true if the router is enable, otherwise false
     *
     * @return - boolean
     */
    public boolean isEnabled();

    /**
     * Method to enable/disable a specific router
     *
     * @param routerEnabled - boolean
     */
    public void setEnabled(boolean routerEnabled);

    /**
     * Method returns Refresh Interval Period
     *
     * @return - the interval in millis (e.g. 5000 for five seconds)
     */
    public long getRefreshInterval();

    /**
     * Method to load/refresh the configuration
     */
    public void refresh();

    /**
     * Route method to route the requst to the router
     * Router response will set the pool name and send it back to the router
     * which will be use by Connection Type to connect to the database
     *
     * @param req - IRouterRequest
     * @param res - IRouterResponse
     */
    public void route(IRouterRequest req, IRouterResponse res);

    /**
     * Returns Router Name
     * @return -- String
     */
    public String getName();
}
