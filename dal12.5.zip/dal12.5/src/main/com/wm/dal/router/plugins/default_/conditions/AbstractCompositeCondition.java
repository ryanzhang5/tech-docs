/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.conditions;

import com.wm.dal.router.plugins.default_.ICondition;

import java.util.List;
import java.util.ArrayList;

/**
 * AbstractConditionHolder - base class for conditions that wrap other conditions
 *
 * @author mkishore
 * @since 1.0
 */
public abstract class AbstractCompositeCondition<T> implements ICondition<T> {
    protected List<ICondition<T>> conditions = new ArrayList<ICondition<T>>();

    /**
     * No-op
     */
    public void initialize() throws IllegalStateException {
        // no-op
    }

    public List<ICondition<T>> getConditions() {
        return conditions;
    }

    public void setConditions(List<ICondition<T>> conditions) {
        this.conditions = conditions;
    }
}
