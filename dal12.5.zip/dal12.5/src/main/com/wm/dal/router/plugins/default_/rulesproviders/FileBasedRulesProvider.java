/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_.rulesproviders;

import com.wm.dal.router.plugins.default_.IRoutingRulesProvider;
import com.wm.dal.router.IRouter;
import org.springframework.core.io.Resource;

import java.io.IOException;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.logging.Logger;
import java.util.logging.Level;

/**
 * FileBasedRulesProvider - fetches the routing rules from the filesystem.
 *
 * @author mkishore
 * @since 1.1
 */
public class FileBasedRulesProvider implements IRoutingRulesProvider {
    private static final Logger logger = Logger.getLogger(FileBasedRulesProvider.class.getName());

    private String name = "FileBasedRulesProvider";
    private Resource configFile;
    private long configLastModified;

    private byte[] routingRules;
    private static final int BYTE_BUFFER_SIZE = 2*1024;

    /**
     * Returns the name of this provider.
     *
     * @return the name of the provider
     */
    public String getName() {
        return name;
    }

    /**
     * Allows the implementation to use the router's name etc. to lookup the rules.
     *
     * @param router - The parent Router object
     */
    public void setRouter(IRouter router) {
        // no-op
    }

    /**
     * Checks the timestamp of the configuration file to reload only when necessary. Please note
     * that the check is a "not equals" i.e. if you replace a newer file with an older one, you will
     * still trigger a refresh. When the configuration file is inside a JAR file, the timestamp of
     * the JAR file is used for the check.
     *
     * @return true, if the implementation detects that the rules have changed in the
     *         persistent store.
     */
    public boolean needsRefresh() {
        if (configFile == null) {
            throw new IllegalStateException("The provider points to a null configFile");
        } else if (!configFile.exists()) {
            throw new IllegalStateException("The provider points to a non-existent configFile: [" + configFile + "]");
        }

        URL url = null;
        try {
            url = configFile.getURL();
            URLConnection urlConnection = url.openConnection();
            long time = urlConnection.getLastModified();
            if (configLastModified == time) {
                logger.info("Verified up-to-date routing-rules from [" + url + "]");
                return false;
            } else {
                logger.info("Refreshing the routing-rules from [" + url + "]");
                routingRules = getBytes(configFile.getInputStream());
                configLastModified = time;
                return true;
            }
        } catch (IOException e) {
            throw new RuntimeException("Error trying to refresh the routing-rules from [" + url + "]",e);
        }
    }

    private byte[] getBytes(InputStream in) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buffer = new byte[BYTE_BUFFER_SIZE];
        int len;
        while ((len = in.read(buffer)) != -1) {
            baos.write(buffer, 0, len);
        }
        in.close();
        return baos.toByteArray();
    }

    /**
     * The implementation needs to fetch the routing-rules from the persistent store
     * and return it as a byte[].
     *
     * @return the bytes corresponding to an XML string representing the routing-rules.
     */
    public byte[] getRoutingRules() {
        return routingRules;
    }

    /**
     * Returns the resource representing the routing-rules configuration file.
     *
     * @return the resource representing the routing-rules configuration file
     */
    public Resource getConfigFile() {
        return configFile;
    }

    /**
     * Sets the resource representing the routing-rules configuration file.
     *
     * @param configFile - the resource representing the routing-rules configuration file.
     */
    public void setConfigFile(Resource configFile) {
        this.configFile = configFile;
    }

}
