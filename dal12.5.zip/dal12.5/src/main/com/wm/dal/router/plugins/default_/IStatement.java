/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.router.plugins.default_;

/**
 * IStatement - simple command interface
 *
 * @author mkishore
 * @version $Revision: 1.1 $
 * @since 1.0
 */
public interface IStatement<T> {
    public enum Status { CONTINUE, BREAK, RETURN };
    /**
     * This method should be called after creating the action and injecting
     * all its dependencies. The implmentations can use this method to validate
     * that the instance has been configured correctly.
     *
     * @throws IllegalStateException - if there are errors in the configuration
     */
    public void initialize() throws IllegalStateException;

    /**
     * Simple command interface - the implementing classes will add
     * appropriate logic in this method.
     *
     * @param context - the execution context
     * @return the status controlling further execution path  
     */
    public Status execute(T context);
}
