/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.util;

import com.wm.corelib.logging.ThreadRequestID;
import com.wm.corelib.logging.ThreadGroupID;

import java.lang.System;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.ConsoleHandler;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

/**
 * Simple class to implement basic logging functions.
 * If a message is logged with a level of getLevel() or
 * lower than the message is printed to the log stream.
 */
public class DALLogger {

    // No logging is output
    public static final int LEVEL_OFF = 0;

    // Logging for major events
    public static final int LEVEL_SEVERE = 1;

    // Logging for major--
    public static final int LEVEL_WARNING = 2;

    // Logging for major/major--/minor events
    public static final int LEVEL_INFO = 3;

    // Logging for nitpicky things
    public static final int LEVEL_ALL = 4;

    // Default timestamp format in 24 hr clock.
    private static String defaultTimestampFormat = "yyyy-MM-dd HH:mm:ss:S - ";

    // Simple date format
    private static SimpleDateFormat timestampFormatter = null;

    // Prefix to prepend to all log messages
    private String prefix;

    // Postfix to append to all log messages
    private String postfix = "\n";

    // Log level
    private int logLevel = LEVEL_WARNING;

    private final Logger logger = Logger.getAnonymousLogger();// Logger.getLogger(getClass().getName());
    
    private final Handler handler = new ConsoleHandler();

    //private final MemoryHandler mhandler = new MemoryHandler(handler, 20, Level.WARNING);
    private static DALLogger instance = null;

    /**
     * Constructor
     */
    private DALLogger() {
      handler.setFormatter(new LogFormatter());
      logger.addHandler(handler);
      //mhandler.setPushLevel(Level.WARNING);
      setLevel(ServerConf.getLogLevel());
      //logger.setLevel(ServerConf.getLogLevel());
      logger.setUseParentHandlers(false);
    }
  
    /**
     * Creates a new WMQLLogger object with DEFAULT_LEVEL
     * and DEFAULT_LOG_STREAM, printing logs with no prefix.
     */
    public static synchronized DALLogger getInstance() {
        return DALLogger.getInstance( defaultTimestampFormat );
    }

    /**
     * Return Instance
     * @param timestampFormat -- String
     * @return -- DALLogger
     */
    public static synchronized DALLogger getInstance( String timestampFormat )  {
        if ( instance == null ) {
            instance = new DALLogger();
            timestampFormatter = new SimpleDateFormat( timestampFormat );
        }//if

        return instance;
    }

   /**
    * Sets the log prefix.
    */
    public final void setPrefix( String logPrefix ) {
        prefix = logPrefix;
    }

    /**
     * @return  current log prefix.
     */
    public final String getPrefix() {
        return prefix;
    }

   /**
    * Sets the log postfix.
    */
    public final void setPostfix( String logPostfix ) {
        postfix = logPostfix;
    }

   /**
    * @return  current log postfix.
    */
    public final String getPostfix() {
        return postfix;
    }

    /**
     * Sets the log level, anything below 0 is set to 0.
     */
    public final void setLevel( int level ) {
    if ( level >= 0 )
      logLevel = level;

      switch (level)   {
          case LEVEL_OFF :
            logger.setLevel(Level.OFF);
            //mhandler.setLevel(Level.OFF);
            break;
          case LEVEL_SEVERE :
            logger.setLevel(Level.SEVERE);
            //mhandler.setLevel(Level.SEVERE);
            break;
          case LEVEL_WARNING :
            logger.setLevel(Level.WARNING);
            //mhandler.setLevel(Level.WARNING);
            break;
          case LEVEL_INFO :
            logger.setLevel(Level.INFO);
            //mhandler.setLevel(Level.INFO);
            break;
          case LEVEL_ALL :
            logger.setLevel(Level.ALL);
            //mhandler.setLevel(Level.ALL);
            break;
      }
    }

   /**
    * @return  current logging level.
    */
    public final int getLevel() {
        return logLevel;
    }

    /**
     * Does the actual logging of a message, if the message is of a level
     * at or below getLevel(). 
     * @param level
     * @param message
     */
    public final void log( int level, String message ) {
        switch (level) {
            case LEVEL_OFF :
                break;
            case LEVEL_SEVERE :
                logger.log(Level.SEVERE, message);
                break;
            case LEVEL_WARNING :
                logger.log(Level.WARNING, message);
                break;
            case LEVEL_INFO :
                logger.log(Level.INFO, message);
                break;
            case LEVEL_ALL :
                logger.log(Level.ALL, message);
                break;
        }
    }

    /**
     * 
     * @param level
     * @param message
     * @param t
     */
    public final void log( int level, String message, Throwable t ) {
      switch (level) {
          case LEVEL_OFF :
              break;
          case LEVEL_SEVERE :
              logger.log(Level.SEVERE, message, t);
              break;
          case LEVEL_WARNING :
              logger.log(Level.WARNING, message,t);
              break;
          case LEVEL_INFO :
              logger.log(Level.INFO, message, t);
              break;
          case LEVEL_ALL :
              logger.log(Level.ALL, message, t);
              break;
      }
    }

    /**
     * 
     * @param message
     */
    public final void fine(String message ) {
        logger.fine(message);
    }

    /**
     * 
     * @param message
     */
    public final void finer(String message ) {
        logger.finer(message);
    }

    /**
     * @param message
     */
    public final void finest(String message ) {
        logger.finest(message);
    }

    /**
     * @param message
     */
    public final void warning(String message ) {
        logger.warning(message);
    }

    /**
     * @param message
     */
    public final void severe(String message ) {
        logger.severe(message);
    }

    /**
     * @param message
     */
    public final void info(String message ) {
        logger.info(message);
    }

    /**
     * @param msec
     * @return
     */
    public static synchronized String formatTimestamp( long msec ) {
    Date d = new Date( msec );
    return timestampFormatter.format( d ); 
  }

/*************************************************************************/
    class LogFormatter extends Formatter {
    
        public String format(LogRecord rec) {

            StringBuffer sb = new StringBuffer();
            long date = System.currentTimeMillis();
            sb.append(formatTimestamp( date ))
                    .append(Thread.currentThread().getName())
                    .append(", ")
                    .append(Thread.currentThread().hashCode())
                    .append(" -> ");
            if ( prefix != null )
              sb.append( prefix );
            String sessionID = ThreadGroupID.get();
            String requestID = ThreadRequestID.get();
            sb.append( formatMessage(rec) )
                    .append(" <SessionID: ").append(sessionID != null ?sessionID :"NULL").append(">")
                    .append(" <RequestID: ").append(requestID != null ?requestID :"NULL").append(">")
                    .append(postfix);

            return sb.toString();
        }
        
        public String getHead(Handler h) {
            return "";
        }
            
        public String getTail(Handler h) {
            return "";
        }
    }
/*************************************************************************/

}
