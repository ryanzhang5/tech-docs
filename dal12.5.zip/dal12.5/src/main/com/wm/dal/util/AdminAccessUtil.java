package com.wm.dal.util;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.net.URLEncoder;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
  
import com.wm.corelib.config.AppConfig;




public class AdminAccessUtil {

    public static final boolean setupSessionUserData(HttpServletRequest request) {
    	String configUser =  ServerConf.getConfigUserName();
    	String configPassword =  ServerConf.getConfigPassword();

    	String requestUser = request.getParameter("username");
    	String requestPassword = request.getParameter("password");

    	HttpSession session = request.getSession();
    	if (configUser != null && !configUser.equals("") && requestUser != null && requestPassword != null){
    		if(requestUser.equals(configUser) && requestPassword.equals(configPassword)){
	    		session.setAttribute(ServerConf.SESSION_ADMIN_USER, requestUser);
	    		session.setAttribute(ServerConf.SESSION_ADMIN_PASSWORD, requestPassword);
	    		return true;
    		}
    	}
    	return false;
    }


    public static final boolean checkSessionUserData(HttpServletRequest request) {
        HttpSession session = request.getSession();
    	String username = (String) session.getAttribute(ServerConf.SESSION_ADMIN_USER);

    	if (username != null && !username.equals("")){
    		return true;
    	}
    	return setupSessionUserData(request);
    }


    public static final String computeReturnUrl(HttpServletRequest hrequest) {
        String ret = "";
        if (hrequest.getMethod().equalsIgnoreCase("GET")) {
            String queryString = hrequest.getQueryString();
            ret=hrequest.getRequestURI()+((queryString!=null && queryString.length()>0) ? "?"+queryString : "");
            ret="?returnUrl="+URLEncoder.encode(ret);
        }
        return ret;
    }

//    private static boolean isAccessingAuth( HttpServletRequest hrequest ) {
//        String userName = hrequest.getParameter( "user" );
//        String passwd  = hrequest.getParameter( "pass" );
//        boolean rv = false;
//        if( userName != null && userName.length() > 0 && passwd != null && passwd.length() > 0 ) {
//            AdminAccessManager manager = new AdminAccessManager();
//            Hashtable userHash = manager.getAdminUserHash();
//            if( userHash.containsKey( userName ) ) {
//                rv = manager.isUserPassValid( userHash, userName, passwd );
//            }
//        }
//        return rv;
//    }
//
//
//    private static boolean skipIt(ServletRequest request) {
//        //only apply filter on when attempting to access /admin dirs and when in PROD environment.
//        boolean isInProdEnvironment = (AppConfig.getInstance().getProperty( Constants.PROP_APPLICATION_ENVIRONMENT ) ).equals( Constants.ENV_PRODUCTION );
//        return ( !isInProdEnvironment ||
//                 ((HttpServletRequest) request).getRequestURI().toLowerCase().startsWith("/admin/login.jsp") ||
//                 isAccessingAuth((HttpServletRequest) request ) );
//    }
}

