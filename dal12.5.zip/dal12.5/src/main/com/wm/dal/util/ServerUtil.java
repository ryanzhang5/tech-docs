/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.util;

import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicBoolean;

import com.wm.dal.client.IDALRequest;
import com.wm.dal.jdbc.utils.Constants;
import com.wm.dal.jdbc.DALDriver;
import com.wm.dal.server.AbstractDALServer;


/**
 * 
 * @author cshah
 * @version 1.0
 */
public class ServerUtil {
    private static final ConcurrentMap<String, String> hostNameLookupTable = new ConcurrentHashMap<String, String>();
    private static final DALLogger  logger = DALLogger.getInstance();
    public static AtomicBoolean gracefullShutdown = new AtomicBoolean(false);

    // force the JVM to load the driver and avoid trying to load it everytime
    private static final DALDriver driver = new DALDriver();
    
    /**
     * Method is used to return Host Name
     * @param _sock -- Socket
     * @return -- Host Name -- String
     */
    public static final String getHostNameFromSocket(Socket _sock) {
     String sHost = null;
     try {
       if (_sock == null)  
          return sHost;

      if (hostNameLookupTable.containsKey(_sock.getInetAddress().getCanonicalHostName()))
         return hostNameLookupTable.get(_sock.getInetAddress().getCanonicalHostName());
      else {   
         sHost = ServerUtil.getHostName(_sock.getInetAddress().getCanonicalHostName());
         hostNameLookupTable.put(_sock.getInetAddress().getCanonicalHostName(), sHost);
      }
     } catch (Exception exp) {
          DALLogger.getInstance().log( DALLogger.LEVEL_SEVERE, "/DAL Server(getHostNameFromSocket):" + exp.getMessage() );
       }//catch
      return sHost;
    }

    /**
     * 
     * @param request
     * @param startTime
     */
    public static void printDALBench(IDALRequest request, long startTime ) {
        long elapsedTime = System.currentTimeMillis() - startTime;
        logger.log( DALLogger.LEVEL_WARNING, "DAL BENCH: {hostName= " + request.getSession().getClientHost() +
                                ", Session= " + request.getSession().getSessionID() + 
                                ", Caller= " + Constants.getDescription(request.getCaller()) + 
                                ", Command= " + Constants.getDescription(request.getCommand()) +
                                                           " } -> millis = " + elapsedTime ); 
    }

    /**
     * 
     * @return
     */
    public static boolean isServerAvailable() {
        boolean returnValue = true;
        Connection con = null;
        try {
            //Class.forName("com.wm.dal.jdbc.DALDriver");
            con = DriverManager.getConnection("jdbc:walmart:@" + ServerConf.getHostName() + ":"  + ServerConf.getPort()+ ":catalog","dal_user","dal_user");
            returnValue = con.isValid(5);
        } catch (Exception e) {
            e.printStackTrace();
            returnValue = false;
        }  finally {
            if (con != null) {
                try {
                    con.close();
                } catch (Exception exp) {
                    exp.printStackTrace();
                }
            }
        }
        return returnValue;
    }

    /**
     * 
     * @param waitTimeinSeconds
     */
    public static final void shutdownServer(final int waitTimeinSeconds) {
        AbstractDALServer.getInstance().shutdownNow();
        gracefullShutdown.set(true);
        
        new Thread(new Runnable() {
            public void run() {
                try {
                    if  ( waitTimeinSeconds > 0 ) {
                        Thread.sleep(waitTimeinSeconds * 1000);
                    } else  {
                        Thread.sleep(30 * 1000);
                    }
                } catch (Exception e) {;}
                
                logger.warning("System is shutting down...");
                System.exit(1);
            }
        }).start();
        
    }
        

    /**
     * 
     * @return
     */
    public static boolean isGracefulShutdown() {
        return gracefullShutdown.get();
    }

    /**
     * 
     * @param hostName
     * @return
     */
    public static String getHostName(String hostName) {
        return hostName != null ? hostName.trim().toLowerCase() : hostName;
        //return hostName != null ? hostName.trim().toLowerCase().replaceAll(ServerConf.WALMARTDOTCOM,"") : hostName;
    }
    
}

