package com.wm.dal.util;/*
 * Copyright (c) 2009 Walmart.COM. All rights reserved
 */

/**
 * Class ${CLASS}
 *
 * @author Amlan Chatterjee
 * @version $Id: DALException.java,v 1.2 2009/05/08 01:27:35 achatterjee Exp $
 * @since May 7, 2009
 */
public class DALException extends Exception {

    public DALException(String message) {
        super(message);
    }

    public DALException(String message, Throwable t) {
        super(message, t);
    }

    public String getMessage() {
        return super.getMessage();
    }

    public DALException(Throwable t) {
        super (t);
    }
}
