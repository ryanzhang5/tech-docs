/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.common;

import com.wm.dal.client.DALResponse;
import com.wm.dal.client.IDALRequest;
import com.wm.dal.client.IDALResponse;
import com.wm.dal.jdbc.utils.Constants;
import com.wm.dal.jdbc.utils.MethodAttribute;
import com.wm.dal.util.DALLogger;
import com.wm.dal.util.ServerUtil;
import com.wm.sql.DataAccess;
import com.arjuna.ats.jta.TransactionManager;

import com.wm.dal.util.ServerConf;
import com.wm.corelib.logging.ThreadGroupID;

import javax.transaction.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


/**
 * 
 * @author cshah
 * @version 1.0
 */
public class ConnectionDelegate {

    private Map<String,Connection> connectionMap = new HashMap<String,Connection>();
    private Map<Integer,ObjectMap<Statement,Connection>> statementMap = new HashMap<Integer,ObjectMap<Statement,Connection>>();
    private Map<Integer,ObjectMap<ResultSet,Statement>> resultSetMap = new HashMap<Integer,ObjectMap<ResultSet,Statement>>();

    private ICommand connHandler = new ConnectionCommand(this);
    private ICommand stmtHandler = new StatementCommand(this);
    private ICommand pstmtHandler = new PreparedStatementCommand(this);
    private ICommand cstmtHandler = new CallableStatementCommand(this);
    private ICommand rsHandler = new ResultSetCommand(this);

    static final DALLogger logger = DALLogger.getInstance();
    private ConnectionType connectionType;
    private Transaction transaction;

    /**
     * 
     */
    public ConnectionDelegate() {
    }

    /**
     * @param request
     * @return
     * @throws SQLException
     * @throws Exception
     */
    public IDALResponse execute(IDALRequest request) {
        String oldID = ThreadGroupID.get();
        ThreadGroupID.set((request.getSession() != null) ?request.getSession().getSessionID() :"");
        IDALResponse response = null;
        int caller = request.getCaller();
            try {
                switch (caller) {
                    case Constants.DATABASE_METADATA : {
                        response = connHandler.execute(request);
                        break; }
                    case Constants.CONNECTION : {
                        response = connHandler.execute(request);
                        break; }
                    case Constants.STATEMENT : {
                        response = stmtHandler.execute(request);
                        break; }
                    case Constants.PREPARED_STATEMENT : {
                        response = pstmtHandler.execute(request);
                        break; }
                    case Constants.CALLABLE_STATEMENT: {
                        response = cstmtHandler.execute(request);
                        break; }
                    case Constants.RESULTSET: {
                        response = rsHandler.execute(request);
                        break; }
                    default : {
                        UnsupportedOperationException uoe = new UnsupportedOperationException(Constants.UNSUPPORTED_EXCEPTION);
                        response = new DALResponse();
                        response.setException(uoe);
                    }
                }
            } catch (SQLException sqle) {
                response.setException(sqle);
                //sqle.printStackTrace();
            } catch (Exception e) {
                response.setException(e);
                //e.printStackTrace();
            }
            
        if (response != null) {
            response.setServerHost(ServerConf.getHostName());
        }

        ThreadGroupID.set(oldID); 
        return response;
    }

    /**
     * @throws SQLException
     */
    protected void closeAllConnections() throws SQLException {
        logger.fine("Closing ALL Connections");
        SQLException sqle = null;
        for (Iterator<Map.Entry<String, Connection>> it1 = connectionMap.entrySet().iterator(); it1.hasNext();) {
            Map.Entry<String, Connection> entry = it1.next();
            Connection conn = entry.getValue();
                try {
                    conn.close();
                } catch (SQLException se) {
                    sqle = se;
                } catch (Exception exp) {
                    sqle = new SQLException(exp);
                }
        }

        //clear the Map        
        connectionMap.clear();
        
        if (sqle != null)
            throw sqle;
    }

    /**
     * @throws SQLException
     */
    protected void closeAllStatements() throws SQLException {
        logger.fine("Closing ALL Statements");
        SQLException sqle = null;
        /*
        Iterator<Map.Entry<Integer, ObjectMap<Statement,Connection>>> iterator = statementMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Integer, ObjectMap<Statement,Connection>> entry = iterator.next();
            try {
                entry.getValue().getKey().close();
            } catch (SQLException se) {
                logger.log(DALLogger.LEVEL_WARNING, "Error", se);
                sqle = se;
            } catch (Exception exp) {
                logger.log(DALLogger.LEVEL_WARNING, "Error", exp);
                sqle = new SQLException(exp);
            }
        }
        */
        statementMap.clear();
        if (sqle != null)
            throw sqle;
    }

    /**
     * @throws SQLException
     */
    protected void closeAllResultSet() throws SQLException {
        logger.fine("Closing ALL Result Set");
        SQLException sqle = null;
        /*
        Iterator<Map.Entry<Integer, ObjectMap<ResultSet,Statement>>> iterator = resultSetMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<Integer, ObjectMap<ResultSet,Statement>> entry = iterator.next();
            try {
                entry.getValue().getKey().close();
            } catch (SQLException se) {
                logger.log(DALLogger.LEVEL_WARNING, "Error", se);
                sqle = se;
            } catch (Exception exp) {
                logger.log(DALLogger.LEVEL_WARNING, "Error", exp);
                sqle = new SQLException(exp);
            }
        }
        */
        resultSetMap.clear();
        if (sqle != null)
            throw sqle;
    }

    /**
     * 
     * @param shouldCommit
     * @throws SQLException
     */
    protected void commitORrollbackAllConnections(boolean shouldCommit) throws SQLException {
        if (transaction != null) {
            try {
                javax.transaction.TransactionManager txManager = TransactionManager.transactionManager();
                Transaction tx = setupThreadsTransaction(txManager);
                if (shouldCommit) {
                    logger.info("Committing the transaction");
                    txManager.commit();
                } else {
                    logger.info("Rolling back the transaction");
                    txManager.rollback();
                }
                revertThreadsTransaction(txManager, tx);
            } catch (Exception exp) {
                logger.log(logger.LEVEL_WARNING, "Error trying to commit/rollback the transaction", exp);
                throw new SQLException(exp);
            } finally {
                transaction = null;
            }
        }
        SQLException sqle = null;
        for (Map.Entry<String, Connection> entry : connectionMap.entrySet()) {
            String poolName = entry.getKey();
            if (DataAccess.getInstance().usesXA(poolName)) continue;

            logger.info("Committing/Rolling-back the connections from non-XA pool: " + poolName);
            Connection conn = entry.getValue();
                try {
                    if (shouldCommit) {
                        conn.commit();
                    } else {
                        conn.rollback();
                    }
                } catch (SQLException se) {
                    sqle = se;
                } catch (Exception exp) {
                    sqle = new SQLException(exp);
                }
        }//for
        if (sqle != null)
            throw sqle;
    }

    // returns the transaction associated with the calling thread - only if it's not the same as this.transaction 
    private Transaction setupThreadsTransaction(javax.transaction.TransactionManager txManager) throws SystemException, InvalidTransactionException {
        if (transaction == null) return null;

        boolean needsActivation = false;
        // check if the thread is already associated with a transaction
        Transaction tx = txManager.getTransaction();
        if (tx == null) {
            logger.info("The thread is not associated with any transaction");
            needsActivation = true;
        } else if (transaction.equals(tx)) {
            // only keep tx around - if it is not equal to transaction
            logger.info("The transaction: " + transaction + " associated with the connection-delegate is already associated with the thread");
            tx = null;
        } else {
            logger.warning("The thread is associated with one transaction: " + tx
                    + ", and the connection-delegate is associated with another: " + transaction);
            // suspend the transaction associated with the Thread
            tx = txManager.suspend();
            needsActivation = true;
        }
        logger.info("Transaction associated with this connection-delegate: " + transaction);
        if (needsActivation || transaction.getStatus() != Status.STATUS_ACTIVE) {
            logger.info("Resuming the transaction associated with this connection-delegate. Current Status: " + transaction.getStatus());
            txManager.resume(transaction);
        }
        return tx;
    }

    private void revertThreadsTransaction(javax.transaction.TransactionManager txManager, Transaction tx) throws InvalidTransactionException, SystemException {
        if (tx == null) return;

        logger.info("Resuming the transaction originally associated with this thread when coming into this method");
        txManager.resume(tx);
    }

    /**
     * @throws SQLException
     */
    protected void clearALLWarningForConnections() throws SQLException {
        SQLException sqle = null;
        for (Map.Entry<String, Connection> entry : connectionMap.entrySet()) {
            Connection conn = entry.getValue();
                try {
                    conn.clearWarnings();
                } catch (SQLException se) {
                    sqle = se;
                } catch (Exception exp) {
                    sqle = new SQLException(exp);
                }
            
        }
        if (sqle != null)
            throw sqle;
    }

    /**
     * @param request
     * @param response
     * @return
     * @throws SQLException
     */
    protected Connection getConnection(IDALRequest request, IDALResponse response) throws SQLException {
        String poolName = ConnectionTypeUtil.getPoolName(getConnectionType(request), request.getSession());
        response.setPoolName(poolName);
        return getConnectionInternal(poolName, request);
    }

    /**
     *
     * @param request
     * @return
     * @throws SQLException
     */
    protected Connection getDefaultConnection(IDALRequest request) throws SQLException {
        String poolName = getConnectionType(request).getDefaultPoolName();
        return getConnectionInternal(poolName, request);
    }

    protected ConnectionType getConnectionType(IDALRequest request) throws SQLException {
        if (connectionType == null) {
            DALSession session = request.getSession();
            String user     = (String)session.getConnecitonAttribute(MethodAttribute.USER).getAttribute();
            String password = (String)session.getConnecitonAttribute(MethodAttribute.PASSWORD).getAttribute();
            String alias    = (String)session.getConnecitonAttribute(MethodAttribute.ALIAS).getAttribute();
            connectionType  = ConnectionTypeManager.getInstance().getConnectionType(alias, user, password);
        }
        return connectionType;
    }

    private Connection getConnectionInternal(String poolName, IDALRequest request) throws SQLException {
        logger.info("Getting connection from pool for : " + poolName);
        Connection conn = null;
        try {
            if (connectionMap.containsKey(poolName)) {
                conn = connectionMap.get(poolName);
            } else {
                ensureTransaction(poolName);
                conn = DataAccess.getInstance().getConnection(poolName);
                setInitialProperties(request, conn);
                connectionMap.put(poolName, conn);
            }
            logger.fine("Connection-Map: " + connectionMap);
        } catch (SQLException sqle) {
            throw sqle;
        } catch (Exception exp) {
            //exp.printStackTrace();
            throw new SQLException(exp);
        }
        //added for logging
        //conn = LoggingConnection.getInstance(conn, Logger.getLogger("conn"), Level.FINER);
        return conn;
    }

    protected void ensureTransaction(String poolName) throws SystemException, NotSupportedException, InvalidTransactionException {
        // if this pool does not use XA, do not bother with the JTA transaction etc.
        if (!DataAccess.getInstance().usesXA(poolName)) return;

        logger.info("Ensuring that a transaction exists for the XA pool: " + poolName);

        boolean needsActivation = false;
        // check if the thread is already associated with a transaction
        javax.transaction.TransactionManager txManager = TransactionManager.transactionManager();
        Transaction tx = txManager.getTransaction();
        // check if the connection-delegate is associated with a transaction
        if (transaction == null) {
            // connection-delegate does not have a transaction
            if (tx != null) {
                if (tx.getStatus() == Status.STATUS_ACTIVE) {
                    logger.info("Associating the connection-delegate with the current thread's transaction: " + tx);
                    transaction = tx;
                } else {
                    logger.info("Suspending the 'non-active' transaction associated with the current thread: " + tx);
                    tx = txManager.suspend();
                }
            }
            if (transaction == null) {
                logger.info("Starting a new transaction and associating the connection-delegate with the same");
                txManager.begin();
                transaction = txManager.getTransaction();
            }
        } else if (tx == null) {
            logger.info("The thread is not associated with any transaction");
            needsActivation = true;
        } else if (transaction.equals(tx)) {
            logger.info("The transaction: " + transaction + " associated with the connection-delegate is already associated with the thread");
        } else {
            logger.warning("The thread is associated with one transaction: " + tx
                    + ", and the connection-delegate is associated with another: " + transaction);
            // suspend (and discard!!) the transaction associated with the Thread
            txManager.suspend();
            needsActivation = true;
        }
        logger.info("Transaction associated with this connection-delegate: " + transaction);
        if (needsActivation || transaction.getStatus() != Status.STATUS_ACTIVE) {
            logger.info("Resuming the transaction associated with this connection-delegate. Current Status: " + transaction.getStatus());
            txManager.resume(transaction);
        }
    }

    /**
     * 
     * @param request
     * @param conn
     * @throws SQLException
     */
    private void setInitialProperties(IDALRequest request, Connection conn) throws SQLException {
       DALSession session = request.getSession();
        try {
            if (conn == null) {
                logger.severe("Connection found null...returning back");
                return;
            }
            
            //TODO need better solution       
            if (session.getConnecitonAttribute(MethodAttribute.AUTO_COMMIT) != null) {
                MethodAttribute prop = session.getConnecitonAttribute(MethodAttribute.AUTO_COMMIT);
                conn.setAutoCommit( ((Boolean)prop.getAttribute()).booleanValue());
                logger.info("Setting auto commit property " + prop.getAttribute());
            }
    
            if (session.getConnecitonAttribute(MethodAttribute.SET_READONLY) != null) {
                MethodAttribute prop = session.getConnecitonAttribute(MethodAttribute.SET_READONLY);
                conn.setReadOnly( ((Boolean)prop.getAttribute()).booleanValue());
                logger.info("Setting read only property " + prop.getAttribute());
            }
    
            if (session.getConnecitonAttribute(MethodAttribute.SET_ISOLATION_LEVEL) != null) {
                MethodAttribute prop = session.getConnecitonAttribute(MethodAttribute.SET_ISOLATION_LEVEL);
                conn.setTransactionIsolation( ((Integer)prop.getAttribute()).intValue());
                logger.info("Setting tran level property " + prop.getAttribute());
            }
    
            if (session.getConnecitonAttribute(MethodAttribute.SET_HOLDABILITY) != null) {
                MethodAttribute prop = session.getConnecitonAttribute(MethodAttribute.SET_HOLDABILITY);
                conn.setHoldability( ((Integer)prop.getAttribute()).intValue());
                logger.info("Setting holdability property " + prop.getAttribute());
            }
        } catch (SQLException sqle) {
            throw sqle;
        } catch (Exception exp) {
            //exp.printStackTrace();
            throw new SQLException(exp);
        }

    }

    /**
     * 
     * @param request
     * @throws SQLException
     */
    protected void closeResultSet(IDALRequest request) throws SQLException {
        int ID = request.getID();
        if (resultSetMap.containsKey(ID) ) {
            logger.info("Closing ResultSet " + ID);
            resultSetMap.get(ID).getKey().close();
            resultSetMap.remove(ID);
        } else {
            logger.warning("Closing ResultSet NOT FOUND " + ID);
        }
    }

    /**
     * @param request
     * @throws SQLException
     */
    protected void closeStatement(IDALRequest request) throws SQLException {
        int ID = request.getID();
        if (statementMap.containsKey(ID) ) {
            logger.info("Closing Statement " + ID); 
            statementMap.get(ID).getKey().close();
            statementMap.remove(ID);
        } else {
            logger.warning("Closing Statement NOT FOUND " + ID);
        }
    }

    /**
     * 
     * @param stmt
     * @param rs
     * @throws SQLException
     */
    public void registerResultSet(Statement stmt, ResultSet rs) throws SQLException {
        if (rs != null) {
            resultSetMap.put(rs.hashCode(), new ObjectMap<ResultSet,Statement>(rs,stmt));        
        }
    }

    /**
     * 
     * @param conn
     * @param stmt
     * @throws SQLException
     */
    public void registerStmt(Connection conn, Statement stmt) throws SQLException {
        statementMap.put(stmt.hashCode(), new ObjectMap<Statement,Connection>(stmt,conn));
    }

    /**
     * 
     * @param ID
     * @return
     */
    public boolean containsStatement(int ID) {
        return statementMap.containsKey(ID);
    }
    
    /**
     * 
     * @return
     * @throws SQLException
     */
    public Statement getStatement(int ID) {
        return statementMap.get(ID).getKey();
    }

    /**
     * 
     * @return
     * @throws SQLException
     */
    public Map<String, Connection> getConnectionMap() throws SQLException {
        return connectionMap;
    }    


    /**
     * 
     * @param ID
     * @return
     */
    public boolean containsResultSet(int ID) {
        return resultSetMap.containsKey(ID);
    } 
 
    /**
     * 
     * @param ID
     * @return
     */
    public ResultSet getResultSet(int ID) {
        return resultSetMap.get(ID).getKey();
    }

    /**
     * 
     * @param ID
     * @return
     */
    public Statement getStatementForResultSet(int ID) {
        return resultSetMap.get(ID).getValue();
    }

    /**
     * 
     * @throws SQLException
     */
    public void closeAll() throws SQLException {
        forceClose(true);
    }

    /**
     * Equivalent to calling forceClose(false)
     */
    public void forceClose() {
        try {
            forceClose(false);
        } catch (SQLException e) {
            System.currentTimeMillis();// should never come here
        }
    }
        
    /**
     * Closes all resultsets, statements and connections. Optionally notifies the caller
     * in case of an exception.
     *
     * @param throwException - if true, the method will propagate exceptions encountered
     *      during the execution. If false, the method will just swallow all exceptions.
     * @throws SQLException - will re-throw the last encountered exception
     */
    public void forceClose(boolean throwException) throws SQLException {
        SQLException sqle = null;

        // first, take care of the JTA transaction
        if (transaction != null) {
            try {
                javax.transaction.TransactionManager txManager = TransactionManager.transactionManager();
                Transaction tx = setupThreadsTransaction(txManager);
                logger.info("Rolling back the transaction");
                txManager.rollback();
                revertThreadsTransaction(txManager, tx);
            } catch (Exception exp) {
                logger.log(logger.LEVEL_WARNING, "Error trying to rollback the transaction", exp);
                sqle = new SQLException(exp);
            } finally {
                transaction = null;
            }
        }
        long sTime = System.currentTimeMillis();
        // then make sure we close all the resultsets, statements and connections
        try {
            logger.info("Close - ALL Result Sets");
            this.closeAllResultSet();
        } catch (SQLException e) {
            sqle = e;
            //e.printStackTrace();
        } catch (Exception e) {
            sqle = new SQLException(e);
            //e.printStackTrace();
        } finally {
            logger.info("Close All Result Set -> millis = " + (System.currentTimeMillis()-sTime ));
        }

        try {
            sTime = System.currentTimeMillis();
            logger.info("Close - ALL Statements");
            this.closeAllStatements();
        } catch (SQLException e) {
            sqle = e;
            //e.printStackTrace();
        } catch (Exception e) {
            sqle = new SQLException(e);
            //e.printStackTrace();
        } finally {
            logger.info("Close All Statements -> millis = " + (System.currentTimeMillis()-sTime ));
        }
        
        
        try {
            sTime = System.currentTimeMillis();
            logger.info("Close - ALL Connections");
            this.closeAllConnections();
        } catch (SQLException e) {
            sqle = e;
            //e.printStackTrace();
        } catch (Exception e) {
            sqle = new SQLException(e);
            //e.printStackTrace();
        } finally {
            logger.info("Close All Connections -> millis = " + (System.currentTimeMillis()-sTime ));
        }


        if (throwException && sqle != null) {
            throw sqle;
        }
    }

    
/*****************************************************************************/
    /**
     * 
     * @author cshah
     * @version 1.0
     */
    class ObjectMap<K,V> {
        private K key;
        private V value;
       
        /**
         * 
         * @param key
         * @param value
         */
        public ObjectMap(K key, V value) {
            this.key = key;
            this.value = value;
        }

        /**
         * 
         * @return
         */
        public K getKey() {
            return key;
        }        
        
        /**
         * 
         * @return
         */
        public V getValue() {
            return value;
        }
    }    
/*****************************************************************************/    
}
