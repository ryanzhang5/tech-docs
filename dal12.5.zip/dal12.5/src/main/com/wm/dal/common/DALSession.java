/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.common;

import com.wm.dal.jdbc.args.DALArgs;
import com.wm.dal.jdbc.utils.Constants;
import com.wm.dal.jdbc.utils.MethodAttribute;
import com.wm.dal.util.ClientConf;
import com.wm.dal.util.DALLogger;

import com.wm.dal.util.ServerConf;

import com.wm.dal.util.ServerUtil;

import java.io.Serializable;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;


/**
 * 
 */
public class DALSession implements Serializable {
    private String sessionID;
    private String clientHost;
    private String serverHost;
    
    private boolean isStickyConnection = false;

    private Map<Integer, MethodAttribute> connectionAttributes = new HashMap<Integer, MethodAttribute>();
    private Map<Integer, MethodAttribute> statementAttributes = new HashMap<Integer, MethodAttribute>();
    private Map<Integer, MethodAttribute> resultSetAttributes = new HashMap<Integer, MethodAttribute>();
    
    private long startTime = System.currentTimeMillis();
    private static final DALLogger logger = DALLogger.getInstance();
    private AtomicInteger counter = new AtomicInteger(0);
    
    /**
     * Constructor with Session ID and Client ID
     * @param sessionID -- String
     * @param clientID -- String e.g. ndc-www1
     */
    public DALSession(String sessionID, String clientID) {
        this.sessionID = sessionID;
        this.clientHost = clientID;
        if (this.clientHost != null) {
            this.clientHost = ServerUtil.getHostName(clientHost);
        }
    }


    /**
     * Method return Session ID
     * @return -- Session ID
     */
    public String getSessionID() {
        return sessionID;
    }

    /**
     * Method return Client Host
     * @return -- Client Host e.g. ndc-www1
     */
    public String getClientHost() {
        return clientHost;
    }


    /**
     * Metdhod to invalidate the Session
     */
    public synchronized void invalidate() {
        invalidateResultSet();
        invalidateStatement();
        invalidateConnection();

        logger.warning("TOTAL DAL BENCH : " +
        "Requests=[" +  counter.get() +  "]" + 
        ",Server=[" + getServerHost() +  "]" + 
        ",Session=[" + getSessionID() +  "] " + 
        "invalidated -> millis = " + ( System.currentTimeMillis() - startTime) + " elapsed");
        this.sessionID = Constants.getSessionId();
        startTime = System.currentTimeMillis();  
        initializeCounter();
    }    

    /**
     * 
     */
    public void initializeCounter() {
        counter.set(0);
        startTime = System.currentTimeMillis();  
        String sID = ClientConf.getThreadSessionID();
        if (sID != null) {
          this.sessionID = sID;
        }
    }

    /**
     * 
     */
    public void incrementCounter() {
        counter.incrementAndGet();
    }
    /**
     * 
     */
    public void invalidateStatement() {
        statementAttributes.clear();
    }

    /**
     * 
     */
    public void invalidateResultSet() {
        resultSetAttributes.clear();
    }

    /**
     * 
     */
    public void invalidateConnection() {
        Map<Integer, MethodAttribute> newconnectionAttributes = new HashMap<Integer, MethodAttribute>();
        newconnectionAttributes.put(MethodAttribute.USER, connectionAttributes.get(MethodAttribute.USER));
        newconnectionAttributes.put(MethodAttribute.PASSWORD, connectionAttributes.get(MethodAttribute.PASSWORD));
        newconnectionAttributes.put(MethodAttribute.ALIAS, connectionAttributes.get(MethodAttribute.ALIAS));
        connectionAttributes.clear();
        connectionAttributes.putAll(newconnectionAttributes);
        isStickyConnection = false;
    }
    
    /**
     * 
     * @param ID
     * @param property
     */
    public void setConnectionAttribute(Integer ID, MethodAttribute property) {
        connectionAttributes.put(ID, property);
    }

    /**
     * 
     * @param ID
     * @param property
     */
    public void setStatementAttribute(Integer ID, MethodAttribute property) {
        statementAttributes.put(ID, property);
    }

    /**
     * 
     * @param ID
     * @param property
     */
    public void setResultSetAttribute(Integer ID, MethodAttribute property) {
        resultSetAttributes.put(ID, property);
    }

    /**
     * 
     * @param ID
     * @return
     */
    public MethodAttribute getStatementAttribute(Integer ID) {
        if (statementAttributes.containsKey(ID)) 
            return statementAttributes.get(ID);
            
      return null;  
    }

    /**
     * 
     * @param ID
     * @return
     */
    public MethodAttribute getConnecitonAttribute(Integer ID) {
        if (connectionAttributes.containsKey(ID)) 
            return connectionAttributes.get(ID);
            
      return null;  
    }    

    /**
     * 
     * @param ID
     * @return
     */
    public MethodAttribute getResultSetAttribute(Integer ID) {
        if (resultSetAttributes.containsKey(ID)) 
            return resultSetAttributes.get(ID);
            
      return null;  
    }    

    /**
     * 
     * @return
     */
    public String getSQL() {
        MethodAttribute usqlAttr = getStatementAttribute(MethodAttribute.UPDATED_SQL);
        Object updatedQuery = (usqlAttr != null) ? usqlAttr.getAttribute() : null;
        MethodAttribute osqlAttr = getStatementAttribute(MethodAttribute.SQL);
        Object originalQuery = (osqlAttr != null) ? osqlAttr.getAttribute(): null;
        return updatedQuery != null ? (String)updatedQuery : (String)originalQuery;
    }    

    /**
     * 
     * @return
     */
    public String getOriginalSQL() {
        Object originalQuery = getStatementAttribute(MethodAttribute.SQL).getAttribute();
        return (String)originalQuery;
    }    
   
    /**
     * 
     * @return
     */
    public List<DALArgs> getParameters() {
        MethodAttribute prop = getStatementAttribute(MethodAttribute.SQL_PARAMETERS);
        if (prop != null && prop.getAttribute() instanceof List) {
            return (List<DALArgs>)prop.getAttribute();
        }
        
        return null;
    }  
    
    /**
     * 
     * @param query
     */
    public void setSQL(String query) {
        if (query == null || query.trim().length() == 0) {
            logger.warning("Can not set null Query...");
            return;
        }
        
        MethodAttribute prop = new MethodAttribute(query);
        setStatementAttribute(MethodAttribute.UPDATED_SQL, prop);
    }    
    
    /**
     * 
     * @return
     */
    public String toString() {
        return  "Session ID : " +  sessionID + ", Client Host : " + clientHost + "\n" +
                printAttribute(connectionAttributes, "Connection") + " \n" + 
                printAttribute(statementAttributes, "Statement") + "\n" + 
                printAttribute(resultSetAttributes, "Result Set");
    }
   
   /**
     * 
     * @param map
     * @param type
     * @return
     */
    private String printAttribute(Map<Integer, MethodAttribute> map, String type) {
       StringBuffer sb = new StringBuffer();
       sb.append("Map : " + type + "\n");
       for (Iterator<Map.Entry<Integer, MethodAttribute>> it1 = map.entrySet().iterator(); it1.hasNext();) {
           Map.Entry<Integer, MethodAttribute> entry = it1.next();
            sb.append(entry.getKey()  +  " ==> " + entry.getValue() + "\n");
       }
       return sb.toString();
    }

    /**
     * 
     * @param serverHost
     */
    public void setServerHost(String serverHost) {
        this.serverHost = serverHost;
    }

    /**
     * 
     * @return
     */
    public String getServerHost() {
        return serverHost;
    }
}
