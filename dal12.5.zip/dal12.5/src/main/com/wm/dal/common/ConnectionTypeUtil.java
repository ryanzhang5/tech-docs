/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.common;

import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;

import com.wm.dal.router.IRouter;
import com.wm.dal.router.IRouterRequest;
import com.wm.dal.router.IRouterResponse;
import com.wm.dal.router.RouterRequest;
import com.wm.dal.router.RouterResponse;
import com.wm.dal.util.DALLogger;

/**
 * 
 */
public class ConnectionTypeUtil {
    static final DALLogger logger = DALLogger.getInstance();
    /**
     * 
     * @param type
     * @param session
     * @return
     * @throws SQLException
     */
    public static String getPoolName(ConnectionType type, DALSession session) throws SQLException {
        if (!type.isEnabled())
            throw new SQLException("Connection type is disabled.." + type.getName() + ":" + type.getUserName());

        IRouterRequest routerRequest = new RouterRequest(session);
        IRouterResponse routerResponse = new RouterResponse();
        List<? extends IRouter> routerList = type.getRouterList();

        if (routerList != null && routerList.size() > 0) {
            for (IRouter router : routerList) {
                if (router.isEnabled()) {
                    long stime = System.currentTimeMillis();
                    try {
                        router.route(routerRequest, routerResponse);
                    } catch (Exception e) {
                        logger.log(logger.LEVEL_WARNING, "Error using the router ["+router.getName()+"] to route the request: " + routerRequest, e);
                        throw new SQLException(e);
                    }
                    StringBuffer sb = new StringBuffer();
                    sb.append("ROUTER BENCH: Type=[" +  type.getName() + "],");
                    sb.append("Router=[" + router.getName() +  "]," );
                    sb.append("PoolName=[" );
                    if (routerResponse.getPoolName() != null ) {
                        sb.append(routerResponse.getPoolName());
                    } else {
                        sb.append(type.getDefaultPoolName());
                    }
                    sb.append("],");
                    sb.append("SQL=[" + session.getSQL() + "],");
                    sb.append("Session=[" + session.getSessionID() + "] ");
                    sb.append("-> millis = " + ( System.currentTimeMillis() - stime) + " elapsed");
                    logger.warning(sb.toString());
                    if (!routerResponse.getShouldChainThroughNextRouter())
                        break;
                }
            }//for
        }//if
        
        return (routerResponse.getPoolName() != null ? routerResponse.getPoolName()  : type.getDefaultPoolName());
    }
}
