/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.common;

import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
  
import com.wm.corelib.config.AppConfig;

/**
 * ConnectionTypeManager - manages the ConnectionType configuration
 *
 * @author mkishore
 * @version $Revision: 1.8 $
 * @since 4/2009
 */
public class ConnectionTypeManager {
    private static final Logger logger = Logger.getLogger(ConnectionTypeManager.class.getName());

    private static ConnectionTypeManager instance = newInstance();
    private static final String DEFAULT_CONFIG_FILE = "/dal-connection-types.xml";

    private static synchronized ConnectionTypeManager newInstance() {
        String configFile = AppConfig.getInstance().getProperty("CONF_DAL_CONN_TYPES_CONFIG_FILE", DEFAULT_CONFIG_FILE);
        ConnectionTypeManager ins = null;
        try {
            ins = new ConnectionTypeManager(configFile);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Could not initialize from the file: " + configFile, e);
        }
        if (ins == null && !DEFAULT_CONFIG_FILE.equals(configFile)) {
            try {
                ins = new ConnectionTypeManager(DEFAULT_CONFIG_FILE);
            } catch (Exception e) {
                logger.log(Level.SEVERE, "Could not initialize from the default config file: " + configFile, e);
            }
        }
        if (ins == null) {
            logger.log(Level.SEVERE, "The ConnectionTypeManager singleton instance could not be created");
        }
        return ins;
    }

    public static synchronized void setInstance(ConnectionTypeManager ins) {
        instance = ins;
    }

    private Map<String, ConnectionType> connectionTypeMap = new LinkedHashMap<String, ConnectionType>();

    /**
     * Loads the ConnectionTypes from a spring configuration file.
     *
     * @param configFile - classpath based path to the spring config file
     */
    public ConnectionTypeManager(String configFile) {
        try {
            logger.warning("Loading connection-types from classpath location: " + configFile);
            ApplicationContext applicationContext = new ClassPathXmlApplicationContext(configFile);
            List<ConnectionType> list = (List<ConnectionType>) applicationContext.getBean("connection-types");
            for (ConnectionType ct : list) {
                String name =  getKey(ct.getName() , ct.getUserName() , ct.getPassword()); 
                connectionTypeMap.put(name, ct);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Could not initialize the ConnectionTypeManager from the file: " + configFile, e);
        }
    }

    /**
     * Returns the singleton instance - initialized from the appropriate config file. If there is
     * a system property called "CONF_DAL_CONN_TYPES_CONFIG_FILE", the corresponding value is used as
     * the path to the config file - otherwise, the config is loaded from the default path at:
     * "/dal-connection-types.xml"
     *
     * @return the singleton instance
     */
    public static ConnectionTypeManager getInstance() {
        if (instance == null) {
            instance = newInstance(); // this is primarily intended for testing purposes
        }
        return instance;
    }

    /**
     * @param aliasName
     * @param user
     * @param password
     * @return
     */
    public ConnectionType getConnectionType(String aliasName, String user, String password) throws SQLException {
        if (connectionTypeMap.containsKey( getKey(aliasName, user,password)))
            return connectionTypeMap.get( getKey(aliasName, user,password));

        throw new SQLException("Invalid username/password for " + aliasName + ":" + user + ":" + password);
    }

    /**
     * 
     * @param aliasName
     * @param user
     * @param password
     * @return
     */
    private String getKey(String aliasName, String user, String password) {
        return aliasName + "_" + user + "_" + password;
    }
}
