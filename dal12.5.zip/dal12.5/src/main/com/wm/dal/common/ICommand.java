/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.common;

import com.wm.dal.client.IDALRequest;
import com.wm.dal.client.IDALResponse;

import java.sql.SQLException;

/**
 * 
 */
public interface ICommand {
    /**
     * 
     * @param request
     * @return
     * @throws SQLException
     */
    public IDALResponse execute(IDALRequest request) throws SQLException ;
}
