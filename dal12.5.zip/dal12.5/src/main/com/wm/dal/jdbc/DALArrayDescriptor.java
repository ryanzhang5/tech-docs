/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc;

import java.io.Serializable;

import java.sql.Connection;

/**
 * 
 * @author cshah
 * @version 1.0
 */
public class DALArrayDescriptor implements Serializable {

    private String descriptorName;
    private transient Connection connection;
    
    /**
     * 
     * @param descriptorName
     */
    private DALArrayDescriptor(String descriptorName, Connection connection) {
        this.descriptorName = descriptorName;
        this.connection = connection;
    }
    
    /**
     * 
     * @param descriptorName
     * @param connection
     * @return
     */
    public static DALArrayDescriptor createDescriptor(String descriptorName, Connection connection) {
        return new DALArrayDescriptor(descriptorName, connection);
    }

    /**
     * 
     * @return
     */
    public String getDescriptorName() {
        return descriptorName;
    }

    public Connection getConnection() {
        return connection;
    }
    
}
