/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc;

import java.io.Serializable;

import java.sql.SQLException;

/**
 * 
 * @author cshah
 * @version 1.0
 */
public class DALRow implements Serializable {
    private int   _colCount = 0;
    private Datum _data[] = null;

    /**
     * 
     * @param colCount
     */
    public DALRow( int colCount ) {
        init( colCount );
        _data = new Datum[colCount];
    }
      
    /**
     * 
     * @param colCount
     */
    private void init( int colCount ) {
        _colCount = colCount;
    }

    /**
     * 
     * @param colIndex
     * @return
     * @throws SQLException
     */
    public Datum getDatum( int colIndex ) throws SQLException {
        return _data[ toArrayIndex( colIndex ) ];
    }

    /**
     * 
     * @param colIndex
     * @param d
     * @throws SQLException
     */
    public void setDatum( int colIndex, Datum d ) throws SQLException {
        _data[ toArrayIndex( colIndex) ] = d;
    }
    
    /**
     * 
     * @param colIndex
     * @return
     * @throws SQLException
     */
    private int toArrayIndex( int colIndex ) throws SQLException {
        if ( colIndex < 1 || colIndex > _colCount ) throw new SQLException( "Invalid column index" );
            return colIndex - 1;
    }

}

