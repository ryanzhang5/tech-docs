/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 */

package com.wm.dal.jdbc;

import com.walmartlabs.pangaea.logging.client.type.TransactionLogger;
import com.wm.dal.client.DALNIOClient;
import com.wm.dal.client.DALNettyClient;
import com.wm.dal.client.DALOIONettyClient;
import com.wm.dal.client.IDALClient;
import com.wm.dal.client.IDALRequest;
import com.wm.dal.client.IDALResponse;
import com.wm.dal.common.ConnectionDelegate;
import com.wm.dal.common.DALSession;
import com.wm.dal.jdbc.utils.Constants;
import com.wm.dal.jdbc.utils.MethodAttribute;
import com.wm.dal.util.DALLogger;
import com.wm.dal.util.ServerConf;

import java.io.Serializable;

import java.net.InetAddress;

import java.sql.SQLException;


/**
 * @author cshah
 */
public class Processor {
    private boolean isServerEnabled = true;
    private ConnectionDelegate delegate = new ConnectionDelegate();
    private DALUrl url = null;
    private DALSession dalSession = null; 
    private static final DALLogger logger = DALLogger.getInstance();
    private IDALClient client;
    private int retryCount = 3;
    private String sGUID = null;
    
    /** 
     * 
     * @param pUrl
     */
    public Processor(DALUrl pUrl) {
        this.url = pUrl;
        isServerEnabled = ServerConf.isServerModeEnabled();
        validateSession();
            if (isServerEnabled) {
                do {
                    for (int i=1; i<=retryCount; i++) {
                        try {
                            newClient(ServerConf.getServerType());
                            break;
                        } catch (Exception exp) {
                            exp.printStackTrace();
                        }
                    }
                } while (client == null && url.failover());

                if (client == null) {
                    logger.severe("Could not connect to " + url.getRawUrl() + ", DAL is running in client mode");
                    isServerEnabled = false;
                }
            }
            
            
            
    }

    private void newClient(String serverType) throws Exception {
        if (serverType.equals("nio")) {
            client = new DALNIOClient(url.getHost(), url.getPort());
        } else if (serverType.equals("oionetty")) {
            client = new DALOIONettyClient(InetAddress.getByName(url.getHost()), url.getPort());
        } else {
            client = new DALNettyClient(InetAddress.getByName(url.getHost()), url.getPort());
        }
    }

    /**
     * 
     * @param conn
     * @param request
     * @return
     * @throws SQLException
     */
    public IDALResponse execute(DALConnection conn, IDALRequest request) throws SQLException {
        //request.setSession(dalSession);
        return executeInternal(request);
    }

    /**
     * 
     * @param metaData
     * @param request
     * @return
     * @throws SQLException
     */
    public IDALResponse execute(DALDatabaseMetaData metaData, IDALRequest request) throws SQLException {
        return executeInternal(request);
    }

    /**
     * 
     * @param stmt
     * @param request
     * @return
     * @throws SQLException
     */
    public IDALResponse execute(DALStatement stmt, 
                               IDALRequest request) throws SQLException {
        getSession().setStatementAttribute(MethodAttribute.SQL,new MethodAttribute(stmt.sql));
        //removed because of AVO problem
        //getSession().setStatementAttribute(MethodAttribute.SQL,new MethodAttribute(stmt.sql.toLowerCase()));
        getSession().setStatementAttribute(MethodAttribute.SQL_PARAMETERS,new MethodAttribute((Serializable)stmt.parameterMetaData.getArguments()));
        request.setID(stmt.ID);
        //request.setSession(dalSession);

        return executeInternal(request);
    }

    /**
     * 
     * @param resultSet
     * @param request
     * @return
     * @throws SQLException
     */
    public IDALResponse execute(DALResultSet resultSet, 
                               IDALRequest request) throws SQLException {
        request.setID(resultSet.cursor.getCurSorID());
        return executeInternal(request);
    }

    /**
     * 
     * @param request
     * @return
     * @throws SQLException
     */
    private IDALResponse executeInternal(IDALRequest request) throws SQLException {
        IDALResponse response = null;
        request.setSession(dalSession);
        long startTime = System.currentTimeMillis();
        String execution = "SERVER";
        logger.info("in execute internal " + request + ":" + execution);        

        switch (request.getCommand()) {
            case Constants.EXECUTE :
            case Constants.EXECUTE_QUERY :
            case Constants.EXECUTE_UPDATE :
            case Constants.EXECUTE_W_AUTOGENKEYS :
            case Constants.EXECUTE_UPDATE_W_AUTOGENKEYS :
            case Constants.EXECUTE_UPDATE_W_COLUMNINDEXES :
            case Constants.EXECUTE_UPDATE_W_COLUMNNAMES :
            case Constants.EXECUTE_W_COLUMNINDEXES :
            case Constants.EXECUTE_W_COLUMNNAMES :
            case Constants.EXECUTE_BATCH : {
                try {
                    String calTran = TransactionLogger.startTransaction(TransactionLogger.TRANSACTION_TYPE_DAL, null);
                    request.getSession().setStatementAttribute(MethodAttribute.TRANSACTION_ID, new MethodAttribute<String>(calTran));
                } catch (Exception exp) {
                    logger.warning("Exception occurred while starting CAL transaction " + exp.getMessage());
                  }
                    break;
            }
            default :        
        }
        
        try {
        if (isServerEnabled) {
            response = serverExecute(request);
        } else {
            execution = "CLIENT";
            response = clientExecute(request);
        }
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            throw sqle;
        } catch (Exception e) {
            e.printStackTrace();
            throw new SQLException(e);
        } finally {
            getSession().setServerHost(response != null ? response.getServerHost() : "");
            String poolName = (response != null) ? response.getPoolName() : null;
            long elapsedTime = System.currentTimeMillis() - startTime;
            int levelinfo = DALLogger.LEVEL_INFO;
            String sql = "";
            switch (request.getCommand()) {
                case Constants.EXECUTE :
                case Constants.EXECUTE_QUERY :
                case Constants.EXECUTE_UPDATE :
                case Constants.EXECUTE_W_AUTOGENKEYS :
                case Constants.EXECUTE_UPDATE_W_AUTOGENKEYS :
                case Constants.EXECUTE_UPDATE_W_COLUMNINDEXES :
                case Constants.EXECUTE_UPDATE_W_COLUMNNAMES :
                case Constants.EXECUTE_W_COLUMNINDEXES :
                case Constants.EXECUTE_W_COLUMNNAMES :
                case Constants.EXECUTE_BATCH : {
                    levelinfo = DALLogger.LEVEL_WARNING;
                    MethodAttribute meSQL = request.getSession().getStatementAttribute(MethodAttribute.SQL);
                    if (meSQL != null && meSQL.getAttribute() != null) {
                        sql = meSQL.getAttribute().toString();
                    }
                    try {
                      String str = "Group=" + poolName + ",Resource=" + sql;
                      TransactionLogger.endTransaction(str);
                      request.getSession().setStatementAttribute(MethodAttribute.TRANSACTION_ID, null);
                    } catch (Exception exp) {
                        logger.warning("Exception occurred while ending CAL transaction " + exp.getMessage());
                      }
                        break;
                }
                default :        
                        levelinfo = DALLogger.LEVEL_INFO;
                        break;
            }
            logger.log(levelinfo, "DAL " + execution + " BENCH: { " +
                                    //"  Client = " + request.getSession().getClientHost() +
                                    "  Server= " + request.getSession().getServerHost() +
                                    ", Session= " + request.getSession().getSessionID() + 
                                    ", Caller= " + Constants.getDescription(request.getCaller()) + 
                                    ", Command= " + Constants.getDescription(request.getCommand()) +
                                    ", Pool= " + poolName +
                                    ", Sql=[" + sql +  "]" +
                                    " } -> millis = " + elapsedTime ); 
        }
        
           if ( response.getException() != null && response.getException() instanceof SQLException ) {
                throw (SQLException)response.getException();
           }  else if ( response.getException() != null ) {
                Exception ee = response.getException();
                if (ee != null && ee.toString() != null ) {
                    throw new SQLException(ee.toString());
                } else {
                    throw new SQLException("Unknown exception");
                }
           }
           
           request.getSession().incrementCounter();
           return response;
    }
    
    /**
     * 
     * @param request
     * @return
     * @throws SQLException
     */
    private IDALResponse clientExecute(IDALRequest request) throws Exception {
        try {
            return delegate.execute(request);
        } catch (Exception exp) {
            exp.printStackTrace();
            throw new SQLException(exp);
        }
    }

    /**
     * 
     * @param request
     * @return
     * @throws SQLException
     */
    private IDALResponse serverExecute(IDALRequest request) throws Exception {
        return client.execute(request);
    }

    /**
     * 
     * @throws SQLException
     */
    private void validateSession() {
        if (dalSession == null ) {
            dalSession = new DALSession(Constants.getSessionId(), Constants.getClientID());
            logger.fine("Creating new DAL Session " + dalSession.toString());
        }

        dalSession.setConnectionAttribute(MethodAttribute.SERVER_MODE,new MethodAttribute(isServerEnabled));
    }

    /**
     * 
     */
    protected void releaseResources() {
        dalSession.invalidate();
        dalSession.setConnectionAttribute(MethodAttribute.SERVER_MODE,new MethodAttribute(isServerEnabled));
    }

    /**
     * 
     * @return
     */
    public DALSession getSession() {
        return dalSession;
    }

    /**
     * 
     */
    protected void close() {
        try {
            releaseResources();
            if (client != null)
            	client.close();
        } catch (Exception exp) {exp.printStackTrace();}
    }    

  /**
   * 
   */
  public void startTransaction() {
      if (sGUID == null) {
        try {
          sGUID = TransactionLogger.startTransaction(TransactionLogger.TRANSACTION_TYPE_DAL, null);
          getSession().setConnectionAttribute(MethodAttribute.TRANSACTION_ID, new MethodAttribute(sGUID) );
        } catch (Exception exp) {
            logger.warning("Exception occurred while starting CAL transaction " + exp.getMessage());
          }
        }
  }

  /**
   * 
   */
  public void endTransaction() {
      if (sGUID != null) {
      try {
        sGUID = null;
        getSession().setConnectionAttribute(MethodAttribute.TRANSACTION_ID, null );
        TransactionLogger.endTransaction();
        //CALTransaction.endTransaction("Group=" + "" + ",Resource=" + getSQL());
      } catch (Exception exp) {
        logger.warning("Exception occurred while ending CAL transaction " + exp.getMessage());
      }
      }
  }

    
}
