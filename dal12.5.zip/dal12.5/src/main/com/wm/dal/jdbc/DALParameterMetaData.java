/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc;

import com.wm.dal.jdbc.args.DALArgs;

import com.wm.dal.jdbc.utils.DALUtil;

import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author cshah
 * @version 1.0
 */
public class DALParameterMetaData implements java.sql.ParameterMetaData  {
    protected List<DALArgs> arguments = new ArrayList<DALArgs>();
        
    /**
     * Retrieves the number of parameters in the <code>PreparedStatement</code> 
     * object for which this <code>ParameterMetaData</code> object contains
     * information.
     *
     * @return the number of parameters
     * @exception SQLException if a database access error occurs
     * @since 1.4
     */
    public int getParameterCount() throws SQLException { 
        return arguments.size();
    }

    /**
     * Retrieves whether null values are allowed in the designated parameter.
     *
     * @param param the first parameter is 1, the second is 2, ...
     * @return the nullability status of the given parameter; one of 
     *        <code>ParameterMetaData.parameterNoNulls</code>, 
     *        <code>ParameterMetaData.parameterNullable</code>, or 
     *        <code>ParameterMetaData.parameterNullableUnknown</code>
     * @exception SQLException if a database access error occurs
     * @since 1.4
     */
    public int isNullable(int param) throws SQLException { 
        DALArgs arg = arguments.get(param-1);
        if (arg.isNull()) {
            return parameterNullable;
        } else {
            return parameterNullableUnknown;
        }
    }


    /**
     * Retrieves whether values for the designated parameter can be signed numbers.
     *
     * @param param the first parameter is 1, the second is 2, ...
     * @return <code>true</code> if so; <code>false</code> otherwise
     * @exception SQLException if a database access error occurs
     * @since 1.4
     */
    public boolean isSigned(int param) throws SQLException { throw new SQLException("Method not implemented"); }

    /**
     * Retrieves the designated parameter's number of decimal digits.
     *
     * @param param the first parameter is 1, the second is 2, ...
     * @return precision
     * @exception SQLException if a database access error occurs
     * @since 1.4
     */
    public int getPrecision(int param) throws SQLException { throw new SQLException("Method not implemented"); }

    /**
     * Retrieves the designated parameter's number of digits to right of the decimal point.
     *
     * @param param the first parameter is 1, the second is 2, ...
     * @return scale
     * @exception SQLException if a database access error occurs
     * @since 1.4
     */
    public int getScale(int param) throws SQLException { throw new SQLException("Method not implemented"); }        

    /**
     * Retrieves the designated parameter's SQL type.
     *
     * @param param the first parameter is 1, the second is 2, ...
     * @return SQL type from <code>java.sql.Types</code>
     * @exception SQLException if a database access error occurs
     * @since 1.4
     * @see java.sql.Types
     */
    public int getParameterType(int param) throws SQLException { 
        return arguments.get(param-1).getDataType();
    }

    /**
     * Retrieves the designated parameter's database-specific type name.
     *
     * @param param the first parameter is 1, the second is 2, ...
     * @return type the name used by the database. If the parameter type is
     * a user-defined type, then a fully-qualified type name is returned.
     * @exception SQLException if a database access error occurs
     * @since 1.4
     */
    public String getParameterTypeName(int param) throws SQLException { 
        return DALUtil.getTypeName(arguments.get(param-1).getDataType());
    }

 
    /**
     * Retrieves the fully-qualified name of the Java class whose instances 
     * should be passed to the method <code>PreparedStatement.setObject</code>.
     *
     * @param param the first parameter is 1, the second is 2, ...
     * @return the fully-qualified name of the class in the Java programming
     *         language that would be used by the method 
     *         <code>PreparedStatement.setObject</code> to set the value 
     *         in the specified parameter. This is the class name used 
     *         for custom mapping.
     * @exception SQLException if a database access error occurs
     * @since 1.4
     */
    public String getParameterClassName(int param) throws SQLException {
        return DALUtil.getTypeName(arguments.get(param-1).getDataType());
    }


    /**
     * Retrieves the designated parameter's mode.
     *
     * @param param the first parameter is 1, the second is 2, ...
     * @return mode of the parameter; one of 
     *        <code>ParameterMetaData.parameterModeIn</code>,
     *        <code>ParameterMetaData.parameterModeOut</code>, or
     *        <code>ParameterMetaData.parameterModeInOut</code>
     *        <code>ParameterMetaData.parameterModeUnknown</code>.
     * @exception SQLException if a database access error occurs
     * @since 1.4
     */
    public int getParameterMode(int param) throws SQLException { 
        DALArgs arg = arguments.get(param-1);
        if (arg.isOutParameter()) 
            return parameterModeOut;
        else
            return parameterModeIn;
    }

    protected void add(DALArgs arg) throws SQLException {
        //System.out.println(arg + ":" + arg.getPosition());
        if (arg.getPosition() <= 0 )
            throw new SQLException("Invalid index... " + arg.getPosition());
            
        arguments.add(arg);

    }
    
    protected void clear() {
        arguments.clear();
    }

    protected DALArgs get(int index) {
        DALArgs arg = null;
        for (DALArgs argOut : arguments) {
            if (argOut.getPosition() == index) {
                arg = argOut;
                break;
            }
        }
        return arg;
    }

    protected List<DALArgs> getArguments() {
        return arguments;
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        try {
        sb.append("Parameter Count : " + arguments.size() + " \n");
        for (DALArgs arg : arguments) {
            sb.append("Position : " + arg.getPosition() + ",Type : " + arg.getDataType() + ",Type Name : " + DALUtil.getTypeName(arg.getDataType()) + "\n" );
        }
        } catch (Exception exp) {
            exp.printStackTrace();
        }
        return sb.toString();
    }        

    /**
     * Returns an object that implements the given interface to allow access to
     * non-standard methods, or standard methods not exposed by the proxy.
     * 
     * If the receiver implements the interface then the result is the receiver 
     * or a proxy for the receiver. If the receiver is a wrapper
     * and the wrapped object implements the interface then the result is the
     * wrapped object or a proxy for the wrapped object. Otherwise return the
     * the result of calling <code>unwrap</code> recursively on the wrapped object 
     * or a proxy for that result. If the receiver is not a
     * wrapper and does not implement the interface, then an <code>SQLException</code> is thrown.
     *
     * @param iface A Class defining an interface that the result must implement.
     * @return an object that implements the interface. May be a proxy for the actual implementing object.
     * @throws java.sql.SQLException If no object found that implements the interface 
     * @since 1.6
     */
     public <T> T unwrap(java.lang.Class<T> iface) throws java.sql.SQLException {
         throw new SQLException("Method not implemented");
     }

    /**
     * Returns true if this either implements the interface argument or is directly or indirectly a wrapper
     * for an object that does. Returns false otherwise. If this implements the interface then return true,
     * else if this is a wrapper then return the result of recursively calling <code>isWrapperFor</code> on the wrapped
     * object. If this does not implement the interface and is not a wrapper, return false.
     * This method should be implemented as a low-cost operation compared to <code>unwrap</code> so that
     * callers can use this method to avoid expensive <code>unwrap</code> calls that may fail. If this method
     * returns true then calling <code>unwrap</code> with the same argument should succeed.
     *
     * @param iface a Class defining an interface.
     * @return true if this implements the interface or directly or indirectly wraps an object that does.
     * @throws java.sql.SQLException  if an error occurs while determining whether this is a wrapper
     * for an object with the given interface.
     * @since 1.6
     */
    public boolean isWrapperFor(java.lang.Class<?> iface) throws java.sql.SQLException {
        throw new SQLException("Method not implemented");
    }
        
}
