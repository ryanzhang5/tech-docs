/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc.utils;

import java.io.Serializable;

/**
 * @author cshah
 * @version 1.0
 */
public class MethodAttribute<T extends Serializable>  implements Serializable {
    //connection
    public static final int AUTO_COMMIT         = 1001;
    public static final int SET_HOLDABILITY     = 1002;
    public static final int SET_CATALOG         = 1003;
    public static final int SET_READONLY        = 1004;
    public static final int SET_ISOLATION_LEVEL = 1005;
    public static final int DATABASE_METADATA   = 1006;
    public static final int USER                = 1007;
    public static final int PASSWORD            = 1008;
    public static final int ALIAS               = 1009;
    public static final int CATALOG             = 1010;
    public static final int SCHEMA_PATTERN      = 1011;
    public static final int PROCEDURE_NAME_PATTERN = 1012;
    public static final int COLUMN_NAME_PATTERN = 1013;
    public static final int RS_TYPE             = 1014;
    public static final int SERVER_MODE         = 1015;
    public static final int TRANSACTION_ID      = 1016;

    //statement
    public static final int MAX_FIELD_SIZE      = 2001;
    public static final int MAX_ROW             = 2002;
    public static final int QUERY_TIMEOUT       = 2003;
    public static final int FETCH_DIRECTION     = 2004;
    public static final int FETCH_SIZE          = 2005;
    public static final int AUTO_GENERATED_KEYS = 2006;
    public static final int COLUMN_INDEXES      = 2007;
    public static final int COLUMN_NAMES        = 2008;
    public static final int RESULTSET_TYPE      = 2009;
    public static final int RESULTSET_CONCURRENCY = 2010;
    public static final int SQL                 = 2011;
    public static final int SQL_PARAMETERS      = 2012;
    public static final int CURSOR_NAME         = 2013;
    public static final int ESCAPE_PROCESSING   = 2014;
    public static final int BATCH               = 2015;
    public static final int CONSTRUCTOR         = 2016;
    public static final int CONSTRUCTOR_DEFAULT = 2017;
    public static final int CONST_W_RS_TYPE_CONCURRENCY = 2018;
    public static final int CONST_W_RS_TYPE_CONCURRENCY_HOLDABILITY = 2019;
    public static final int UPDATED_SQL         = 2020;
    public static final int CONST_W_AUTO_GEN_KEY = 2021
    ;
    //resultset
    public static final int RESULTSET_FETCHSIZE = 3001;
    
    private T attribute = null;
    
    /**
     * 
     * @param attribute
     */
    public MethodAttribute(T attribute) {
        this.attribute = attribute;
    }

    /**
     * 
     * @return
     */
    public T getAttribute() {
        return attribute;
    }

    public String toString() {
        if (attribute == null)
            return "";
        
        return "Attribute : " + attribute.toString();    
    }
}
