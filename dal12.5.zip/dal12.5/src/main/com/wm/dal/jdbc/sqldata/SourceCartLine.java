package com.wm.dal.jdbc.sqldata;

import java.io.Serializable;

import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

public class SourceCartLine implements java.sql.SQLData, Serializable {
    private long _id = 0;
    private String _lineID = null;
    private int _quantity = 0;

    // SQL type corresponding to this class
    private static final String SQL_TYPE = "CUSTOMER.T_SOURCE_CART_REC";

    // Default Constructor
    public SourceCartLine(){
    }

    // Overloaded constructor with all three fields
    public SourceCartLine(long id, String lineID, int quantity){
        _id = id;
        _lineID = lineID;
        _quantity = quantity;
    }

    // Getter for ID
    public long getID(){
        return _id;
    }

    // Getter for lineID
    public String getLineID(){
        return _lineID;
    }

    // Getter for quantity
    public int getQuantity(){
        return _quantity;
    }

    // Setter for ID
    public void setID(int id){
        _id = id;
    }

    // Setter for lineID
    public void setLineID(String lineID){
        _lineID = lineID;
    }

    // Setter for quantity
    public void setQuantity(int quantity){
        _quantity = quantity;
    }

    public String toString(){
        return ("ID = " + _id + "\t lineID = " + _lineID + "\tQuantity = " + _quantity);
    }

   //O fulfill contract of interface SQLData w/ these methods
    public String getSQLTypeName() throws SQLException {
        return SQL_TYPE;
    }

    public void readSQL(SQLInput stream, String typeName) throws SQLException {
        throw new RuntimeException("Not implemented because for now we don't need to read these.");
    }

    public void writeSQL(SQLOutput stream) throws SQLException {
        stream.writeString(String.valueOf(_id));
        stream.writeLong(Long.parseLong(_lineID));
        //stream.writeInt(Integer.parseInt(_lineID));
        stream.writeInt(_quantity);
    }
}

