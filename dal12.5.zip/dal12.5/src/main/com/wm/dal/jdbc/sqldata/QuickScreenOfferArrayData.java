package com.wm.dal.jdbc.sqldata;

import java.io.Serializable;

import java.math.BigDecimal;
import java.sql.*;

/**
 * Class for Offer Element Oracle ARRAY record.
 * <p/>
 * User: skumar
 * Date: Jan 21, 2008
 * Time: 11:41:21 AM
 */
public class QuickScreenOfferArrayData implements SQLData, Serializable {

    private OfferElementName offerElementName;
    private Object offerElementValue;

    /**
     * Oracle record type of the element in the array *
     */
    private static final String SQL_TYPE = "CUSTOMER.T_INSTANT_CREDIT_OFFER_REC";

    /**
     * Public constructor to be used by ARRAY *
     */
    public QuickScreenOfferArrayData() {

    }

    public QuickScreenOfferArrayData(
            OfferElementName offerElementName, Object offerElementValue) {
        this.offerElementName = offerElementName;
        this.offerElementValue = offerElementValue;
    }

    /**
     * Implementation of super calss method to return the type defined
     * in databse for this ARRAY object
     *
     * @return SQL Type defined in the database
     * @throws SQLException
     */
    public String getSQLTypeName() throws SQLException {
        return SQL_TYPE;
    }

    /**
     * Get offer element name for the array element
     *
     * @return return offer element name
     */
    public OfferElementName getOfferElementName() {
        return offerElementName;
    }

    /**
     * Get offer element value for this array element
     *
     * @return Date/String/long based on data type
     */
    public Object getOfferElementValue() {
        return offerElementValue;
    }

    /**
     * Method used to create object from the stream
     *
     * @param stream   SQLInput stream passed by the driver
     * @param typeName name of data type
     * @throws SQLException
     */
    public void readSQL(SQLInput stream, String typeName) throws SQLException {
        String elementName = stream.readString();
        this.offerElementName =
                OfferElementName.valueOf(elementName);

        stream.readString();//for the data type which we know
        if (this.offerElementName.getDataType() == String.class) {
            this.offerElementValue = stream.readString();
        } else if (this.offerElementName.getDataType() == Long.class) {
            stream.readString();//Dummy read
            this.offerElementValue = stream.readDouble();//Dummy read
            //stream.readDate();//Dummy read
        } else if (this.offerElementName.getDataType() == BigDecimal.class) {
            stream.readString();//Dummy read
            this.offerElementValue = stream.readBigDecimal();//Dummy read
            //stream.readDate();//Dummy read
        } else if (this.offerElementName.getDataType() == Date.class) {
            stream.readString();//Dummy read
            stream.readDouble();//Dummy read
            this.offerElementValue = stream.readDate();//Dummy read
        }

    }

    /* *
     * Write the data into the stream
     *
     * @param stream SQLOutput stream to write to
     * @throws SQLException
     */
    public void writeSQL(SQLOutput stream) throws SQLException {
    //public SerializableSQLData getSQLData() throws SQLException {
      //  DALWriteOnlySQLData stream = new DALWriteOnlySQLData(this.getSQLTypeName());
        if (this.offerElementName == null) {
            stream.writeString(null);
            stream.writeString(null);
            stream.writeString(null);
            stream.writeDouble(0.0d);
            stream.writeDate(null);
            return ;
        }
        stream.writeString(this.offerElementName.toString());
        stream.writeString(this.offerElementName.getDataTypeDBValue());
        if (this.offerElementName.getDataType() == String.class &&
                this.offerElementValue != null) {
            stream.writeString((String) this.offerElementValue);
        } else {
            stream.writeString(null);
        }
        if ((this.offerElementName.getDataType() == Long.class ||
                this.offerElementName.getDataType() == Double.class) &&
                this.offerElementValue != null) {
            if (this.offerElementName.getDataType() == Long.class) {
                stream.writeLong((Long) this.offerElementValue);
            } else {
                stream.writeDouble((Double) this.offerElementValue);
            }
        } else {
            if (this.offerElementName.getDataType() == BigDecimal.class &&
                    this.offerElementValue != null) {
                stream.writeBigDecimal((BigDecimal) this.offerElementValue);
            } else {
                stream.writeBigDecimal(null);
            }
        }

        if (this.offerElementName.getDataType() == Date.class &&
                this.offerElementValue != null) {
            stream.writeDate((Date) this.offerElementValue);
        } else {
            stream.writeDate(null);
        }
        return ;
    }

    public String toString() {
        return "Data Type : " + ( offerElementName != null ? offerElementName.getDataType() : null ) + ", Data Type DB Value : " 
                    + ( offerElementName != null ? offerElementName.getDataTypeDBValue() : null) + ", Value :" + offerElementValue;
    }    
}
