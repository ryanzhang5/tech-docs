package com.wm.dal.jdbc.beans;

import java.io.Serializable;

public class SecurityEnvPoolBean implements Serializable{

	public final static String SEPERATOR = ",";
	
	public SecurityEnvPoolBean() {
		
	}
	
	public SecurityEnvPoolBean(int envRouterId, String envName, String routerName, int ruleId) {
		
		this.envRouterId = envRouterId;
		this.envName = envName;
		this.routerName = routerName;
		this.ruleId = ruleId;
	}

	public int getEnvRouterId() {
		return envRouterId;
	}

	public void setEnvRouterId(int envRouterId) {
		this.envRouterId = envRouterId;
	}

	public String getEnvName() {
		return envName;
	}

	public void setEnvName(String envName) {
		this.envName = envName;
	}

	public String getRouterName() {
		return routerName;
	}

	public void setRouterName(String routerName) {
		this.routerName = routerName;
	}

	public int getRuleId() {
		return ruleId;
	}

	public void setRuleId(int ruleId) {
		this.ruleId = ruleId;
	}

	
	private int envRouterId;
	private String envName;
	private String routerName;
	private int ruleId;
}
