package com.wm.dal.jdbc.beans;

import com.wm.sql.DataAccess;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class DALSecurity {
    /*
        public static final String DATASOURCETYPE = "oracleDAL";

        private static ApplicationContext applicationContext = new ClassPathXmlApplicationContext(
                "/com/wm/dal/jdbc/beans/security-beans.xml");
        private DataSource dataSource = (DataSource) applicationContext
                .getBean(DATASOURCETYPE);
    */
    private Logger logger = Logger.getLogger(DALSecurity.class.getName());
    private static final String CONN_POOL = "dalpool_oms";
    public static final String ENVROUTERCONFTABNAME = "DAL_ENV_ROUTER_CONFIG";
    public static final String RULECONFTABNAME = "DAL_RULE_CONFIG";
    public static final String RULEFIELDCONFTABNAME = "DAL_RULE_FIELD_CONFIG";


    public boolean addDalEnvPoolConfig(SecurityEnvPoolBean bean) {

        return this.addDalEnvPoolConfig(bean.getEnvRouterId(), bean.getEnvName(), bean.getRouterName(), bean.getRuleId());
    }

    public boolean addDalEnvPoolConfig(int envRouterId, String envName, String routerName, int ruleId) {

        boolean success = false;
        Connection conn = null;
        PreparedStatement stmt = null;
        String sql = " insert into " + ENVROUTERCONFTABNAME + " (env_router_id,env_name,router_name,rule_id) " + " values(?,?,?,?) ";
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, envRouterId);
            stmt.setString(2, envName);
            stmt.setString(3, routerName);
            stmt.setInt(4, ruleId);
            stmt.executeUpdate();
            conn.commit();
            success = true;

        } catch (Exception ex) {
            try {
                conn.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            ex.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return success;

    }

    public boolean updateDalEnvPoolConfig(SecurityEnvPoolBean bean) {

        return this.updateDalEnvPoolConfig(bean.getEnvRouterId(), bean.getEnvName(), bean.getRouterName(), bean.getRuleId());
    }

    public boolean updateDalEnvPoolConfig(int envRouterId, String envName, String routerName, int ruleId) {

        boolean success = false;
        Connection conn = null;
        PreparedStatement stmt = null;
        String sql = " update " + ENVROUTERCONFTABNAME + " set env_name=?,router_name=?,rule_id=? " + " where env_router_id=?";
        try {
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, envName);
            stmt.setString(2, routerName);
            stmt.setInt(3, ruleId);
            stmt.setInt(4, envRouterId);
            stmt.executeUpdate();
            conn.commit();
            success = true;

        } catch (Exception ex) {
            try {
                conn.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            ex.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return success;
    }

    public boolean deleteDalEnvPoolConfig(SecurityEnvPoolBean bean) {

        return this.deleteDalEnvPoolConfig(bean.getEnvRouterId());

    }

    public boolean deleteDalEnvPoolConfig(int envRouterId) {

        boolean success = false;
        Connection conn = null;
        PreparedStatement stmt = null;
        String sql = " delete from " + ENVROUTERCONFTABNAME + " where env_router_id=?";
        try {
            //conn = dataSource.getConnection();
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, envRouterId);
            stmt.executeUpdate();
            conn.commit();
            success = true;

        } catch (Exception ex) {
            try {
                conn.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            ex.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return success;

    }

    public List searchAllDalEnvPoolConfig() {

        List result = new ArrayList();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = " select env_router_id,env_name,router_name,rule_id from " + ENVROUTERCONFTABNAME;
        try {
            //conn = dataSource.getConnection();
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()) {
                SecurityEnvPoolBean bean = new SecurityEnvPoolBean();
                bean.setEnvRouterId(rs.getInt(1));
                bean.setEnvName(rs.getString(2));
                bean.setRouterName(rs.getString(3));
                bean.setRuleId(rs.getInt(4));
                result.add(bean);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return result;
    }

    public SecurityEnvPoolBean searchDalEnvPoolConfig(SecurityEnvPoolBean bean) {

        return this.searchDalEnvPoolConfig(bean.getEnvRouterId());
    }

    public SecurityEnvPoolBean searchDalEnvPoolConfig(int envRouterId) {

        SecurityEnvPoolBean result = null;
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = " select env_router_id,env_name,router_name,rule_id from " + ENVROUTERCONFTABNAME + " where env_router_id=?";
        try {
            //conn = dataSource.getConnection();
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, envRouterId);
            rs = stmt.executeQuery();
            while (rs.next()) {
                SecurityEnvPoolBean bean = new SecurityEnvPoolBean();
                bean.setEnvRouterId(rs.getInt(1));
                bean.setEnvName(rs.getString(2));
                bean.setRouterName(rs.getString(3));
                bean.setRuleId(rs.getInt(4));
                result = bean;
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return result;
    }

    public boolean addDalRuleConfig(SecurityRuleBean bean) {

        return this.addDalRuleConfig(bean.getRuleId(), bean.getRuleFile(), bean.getModifiedDtm());
    }

    public boolean addDalRuleConfig(int ruleId, String ruleFile, Timestamp modifiedDtm) {

        boolean success = false;
        Connection conn = null;
        PreparedStatement stmt = null;
        String sql = " insert into " + RULECONFTABNAME + " (rule_id,rule_file,modified_dtm) " + " values(?,?,?) ";
        try {
            //conn = dataSource.getConnection();
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, ruleId);
            stmt.setString(2, ruleFile);
            stmt.setTimestamp(3, modifiedDtm);
            stmt.executeUpdate();
            conn.commit();
            success = true;

        } catch (Exception ex) {
            try {
                conn.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            ex.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return success;

    }

    public boolean updateDalRuleConfig(SecurityRuleBean bean) {

        return this.updateDalRuleConfig(bean.getRuleId(), bean.getRuleFile(), bean.getModifiedDtm());
    }

    public boolean updateDalRuleConfig(int ruleId, String ruleFile, Timestamp modifiedDtm) {

        boolean success = false;
        Connection conn = null;
        PreparedStatement stmt = null;
        String sql = " update " + RULECONFTABNAME + " set rule_file=?,modified_dtm=? " + " where rule_id=? ";
        try {
            //conn = dataSource.getConnection();
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, ruleFile);
            stmt.setTimestamp(2, modifiedDtm);
            stmt.setInt(3, ruleId);
            stmt.executeUpdate();
            conn.commit();
            success = true;

        } catch (Exception ex) {
            try {
                conn.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            ex.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return success;
    }

    public boolean deleteDalRuleConfig(SecurityRuleBean bean) {

        return this.deleteDalRuleConfig(bean.getRuleId());
    }

    public boolean deleteDalRuleConfig(int ruleId) {

        boolean success = false;
        Connection conn = null;
        PreparedStatement stmt = null;
        String sql = " delete from " + RULECONFTABNAME + " where rule_id=? ";
        try {
            //conn = dataSource.getConnection();
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, ruleId);
            stmt.executeUpdate();
            conn.commit();
            success = true;

        } catch (Exception ex) {
            try {
                conn.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            ex.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return success;

    }

    public List searchAllDalRuleConfig() {

        List result = new ArrayList();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = " select rule_id,rule_file from " + RULECONFTABNAME + " order by rule_id";
        try {
            //conn = dataSource.getConnection();
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()) {
                SecurityRuleBean bean = new SecurityRuleBean();
                bean.setRuleId(rs.getInt(1));
                bean.setRuleFile(rs.getString(2));
                result.add(bean);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return result;
    }

    public SecurityRuleBean searchDalRuleConfig(SecurityRuleBean bean) {

        return this.searchDalRuleConfig(bean.getRuleId());
    }

    public SecurityRuleBean searchDalRuleConfig(int ruleId) {

        SecurityRuleBean result = null;
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = " select rule_id,rule_file from " + RULECONFTABNAME + " where rule_id=?";
        try {
            //conn = dataSource.getConnection();
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, ruleId);
            rs = stmt.executeQuery();
            while (rs.next()) {
                SecurityRuleBean bean = new SecurityRuleBean();
                bean.setRuleId(rs.getInt(1));
                bean.setRuleFile(rs.getString(2));
                result = bean;
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return result;
    }

    public boolean addDalRuleFieldConfig(SecurityRuleFieldBean bean) {

        return this.addDalRuleFieldConfig(bean.getEnvRouterId(), bean.getFieldName(), bean.getFieldValue());
    }

    public boolean addDalRuleFieldConfig(int envRouterId, String fieldName, String fieldValue) {

        boolean success = false;
        Connection conn = null;
        PreparedStatement stmt = null;
        String sql = " insert into " + RULEFIELDCONFTABNAME + " (env_router_id,field_name,field_value) " + " values(?,?,?) ";
        try {
            //conn = dataSource.getConnection();
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, envRouterId);
            stmt.setString(2, fieldName);
            stmt.setString(3, fieldValue);
            stmt.executeUpdate();
            conn.commit();
            success = true;

        } catch (Exception ex) {
            try {
                conn.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            ex.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return success;

    }

    public boolean updateDalRuleFieldConfig(SecurityRuleFieldBean bean) {

        return this.updateDalRuleFieldConfig(bean.getEnvRouterId(), bean.getFieldName(), bean.getFieldValue());
    }

    public boolean updateDalRuleFieldConfig(int envRouterId, String fieldName, String fieldValue) {

        boolean success = false;
        Connection conn = null;
        PreparedStatement stmt = null;
        String sql = " update " + RULEFIELDCONFTABNAME + " set field_value=? " + " where env_router_id=? and field_name=?";
        try {
            //conn = dataSource.getConnection();
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, fieldValue);
            stmt.setInt(2, envRouterId);
            stmt.setString(3, fieldName);
            stmt.executeUpdate();
            conn.commit();
            success = true;

        } catch (Exception ex) {
            try {
                conn.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            ex.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return success;
    }

    public boolean deleteDalRuleFieldConfig(SecurityRuleFieldBean bean) {

        return this.deleteDalRuleFieldConfig(bean.getEnvRouterId(), bean.getFieldName());
    }

    public boolean deleteDalRuleFieldConfig(int envRouterId, String fieldName) {

        boolean success = false;
        Connection conn = null;
        PreparedStatement stmt = null;
        String sql = " delete from " + RULEFIELDCONFTABNAME + " where env_router_id=? and field_name=?";
        try {
            //conn = dataSource.getConnection();
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, envRouterId);
            stmt.setString(2, fieldName);
            stmt.executeUpdate();
            conn.commit();
            success = true;

        } catch (Exception ex) {
            try {
                conn.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            ex.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return success;
    }

    public List searchAllDalRuleFieldConfig() {

        List result = new ArrayList();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = " select env_router_id,field_name,field_value from " + RULEFIELDCONFTABNAME + " order by env_router_id,field_name";
        try {
            //conn = dataSource.getConnection();
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            while (rs.next()) {
                SecurityRuleFieldBean bean = new SecurityRuleFieldBean();
                bean.setEnvRouterId(rs.getInt(1));
                bean.setFieldName(rs.getString(2));
                bean.setFieldValue(rs.getString(3));
                result.add(bean);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return result;
    }

    public SecurityRuleFieldBean searchDalRuleFieldConfig(SecurityRuleFieldBean bean) {

        return this.searchDalRuleFieldConfig(bean.getEnvRouterId(), bean.getFieldName());
    }

    public SecurityRuleFieldBean searchDalRuleFieldConfig(int envRouterId, String fieldName) {

        SecurityRuleFieldBean result = null;
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = " select env_router_id,field_name,field_value from " + RULEFIELDCONFTABNAME + " where env_router_id=? and field_name=?";
        try {
            //conn = dataSource.getConnection();
            conn = getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, envRouterId);
            stmt.setString(2, fieldName);
            rs = stmt.executeQuery();
            while (rs.next()) {
                SecurityRuleFieldBean bean = new SecurityRuleFieldBean();
                bean.setEnvRouterId(rs.getInt(1));
                bean.setFieldName(rs.getString(2));
                bean.setFieldValue(rs.getString(3));
                result = bean;
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return result;
    }

    private Connection getConnection() {
        return DataAccess.getInstance().getConnection(CONN_POOL);
        //return dataSource.getConnection();
    }
//	private interface ISecurityRule {
//		
//		public static final String TABLENAME = "SECURITY.DAL_RULE_CONFIG";
//		public static final int idRuleId = 1;
//		public static final String nameRuleId = "rule_id";
//		public static final int idRuleFile = 2;
//		public static final String nameRuleFile = "rule_file";
//	}
//
//	private interface ISecurityEnvRouter {
//		
//		public static final String TABLENAME = "SECURITY.DAL_ENV_ROUTER_CONFIG";
//		public static final int idEnvRouterId = 1;
//		public static final String nameEnvRouterId = "env_router_id";
//		public static final int idEnvName = 2;
//		public static final String nameEnvName = "env_name";
//		public static final int idRouterName = 3;
//		public static final String nameRouterName = "router_name";
//		public static final int idRuleId = 4;
//		public static final String nameRuleId = "rule_id";
//		
//	}
//	
//	private interface ISecurityRuleField {
//		
//		public static final String TABLENAME = "SECURITY.DAL_RULE_FIELD_CONFIG";
//		public static final int idEnvRouterId = 1;
//		public static final String nameEnvRouterId = "env_router_id";
//		public static final int idFieldName = 2;
//		public static final String nameFieldName = "field_name";
//		public static final int idFieldValue = 3;
//		public static final String nameFieldValue = "field_value";
//	}

}
