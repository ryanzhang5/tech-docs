/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc.args;

import com.wm.dal.jdbc.DALBlob;
import com.wm.dal.jdbc.utils.DALUtil;

import java.sql.Blob;
import java.sql.SQLException;
import java.sql.Types;

/**
 * 
 * @author cshah
 * @version 1.0
 */
public class BlobArg extends DALArgs {
    private Blob value;

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    public BlobArg(int position, boolean isOut, boolean isNull, Blob value) throws SQLException {
        init(position, isOut, isNull, value);
    }

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    protected void init(int position, boolean isOut, boolean isNull, Blob value) throws SQLException {
        init(position, isOut, isNull, Types.BLOB);
        this.value = (Blob) DALUtil.convertToDALObject(value);
    }

    /**
     * @param obj
     * @return
     */
    public boolean equals(Object obj) {
        BlobArg arg = (BlobArg)obj;
        return arg.getValueObject().equals(this.getValueObject());
        //return super.equals(arg) && Arrays.equals(value, arg.value);
    }

    /**
     * @return
     */
    public Blob getValue() {
        return value;
    }

    /**
     * @param value
     * @throws SQLException
     */
    public void setValueObject(Object value) throws SQLException {
        if (value == null) {
            this.value = null;
            this.isNull(true);
        } else if (value instanceof Blob) {
            this.value = (Blob) DALUtil.convertToDALObject(value);
        } else if (value instanceof byte[]) {
            this.value = new DALBlob((byte[])value);
        }
    }

    /**
     * @return
     */
    public Object getValueObject() {
        return getValue();
    }

    /**
     * @return
     */
    public String toString() {
        return super.toString() + ", value = |" + value + "|";
    }

}
