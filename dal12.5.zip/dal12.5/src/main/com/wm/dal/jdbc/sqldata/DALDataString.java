package com.wm.dal.jdbc.sqldata;

import java.io.Serializable;

import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

public class DALDataString implements SQLData, Serializable {
     public static final String SQL_TYPE = "SYN_TYP_RL_PO_INFO";
     public static final String SQL_TAB_TYPE ="SYN_TAB_RL_PO_INFO";
  // members
    private String sqlTypeName;
    private String _datastring;


    // constructor that fills in data members
    public DALDataString(String datastring, String sqlType) {
      this._datastring = datastring;
      this.sqlTypeName = sqlType;
    }

    public String getDataString() {
      return _datastring;
    }

    public void setDataString(String _datastring) {
      this._datastring = _datastring;
    }

    // returns type name as set by readSQL (SQLData)
    public String getSQLTypeName() throws SQLException {
      return sqlTypeName;
    }

    // read data from sql stream (SQLData)
    public void readSQL(SQLInput stream, String typeName) throws SQLException {
      sqlTypeName = typeName;
      _datastring = stream.readString();
    }

    // write data to sql stream (SQLData)
    public void writeSQL(SQLOutput stream) throws SQLException {
      stream.writeString(_datastring);
    }
  }
