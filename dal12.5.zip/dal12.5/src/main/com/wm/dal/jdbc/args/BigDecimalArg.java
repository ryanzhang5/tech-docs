/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 */

package com.wm.dal.jdbc.args;

import java.math.BigDecimal;

import java.sql.SQLException;
import java.sql.Types;

/**
 * @author cshah
 */
public class BigDecimalArg extends DALArgs {
    private BigDecimal value;

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    public BigDecimalArg(int position, boolean isOut, boolean isNull, 
                         BigDecimal value) {
        init(position, isOut, isNull, value);
    }

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    protected void init(int position, boolean isOut, boolean isNull, 
                        BigDecimal value) {
        super.init(position, isOut, isNull, Types.NUMERIC);
        this.value = value;
    }

    /**
     * @param obj
     * @return
     */
    public boolean equals(Object obj) {
        BigDecimalArg arg = (BigDecimalArg)obj;
        return super.equals(arg) && value == arg.value;
    }

    /**
     * @return
     */
    public BigDecimal getValue() {
        return value;
    }

    /**
     * @return
     */
    public Object getValueObject() {
        return getValue();
    }

    /**
     * @param value
     * @throws SQLException
     */
    public void setValueObject(Object value) throws SQLException {
        if (value != null && value instanceof BigDecimal) {
            this.value = (BigDecimal) value;
        } else if (value != null && value instanceof Long) {
            this.value = new BigDecimal(((Long)value).longValue());
        } else if (value != null && value instanceof Double) {
            this.value = new BigDecimal(((Double)value).doubleValue());
        } else if (value != null && value instanceof Float) {
            this.value = new BigDecimal(((Float)value).floatValue());
        } else if (value != null && value instanceof Integer) {
            this.value = new BigDecimal(((Integer)value).intValue());
        } else if (value != null && value instanceof Short) {
            this.value = new BigDecimal(((Short)value).shortValue());
        }
    }

    /**
     * @return
     */
    public String toString() {
        return super.toString() + ", value = |" + value + "|";
    }

}
