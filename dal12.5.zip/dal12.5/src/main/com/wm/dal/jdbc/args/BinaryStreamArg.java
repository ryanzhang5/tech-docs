/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc.args;

import java.io.Serializable;

import java.sql.SQLException;
import java.sql.Types;

/**
 * @author cshah
 * @version 1.0
 */
public class BinaryStreamArg extends DALArgs implements Serializable{
    private byte[] value;
    private int length;

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     * @param length
     */
    public BinaryStreamArg(int position, boolean isOut, boolean isNull, 
                           byte[] value, int length) {
        init(position, isOut, isNull, value, length);
    }

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     * @param length
     */
    protected void init(int position, boolean isOut, boolean isNull, 
                        byte[] value, int length) {
        super.init(position, isOut, isNull, Types.LONGVARBINARY);
        this.value = value;
        this.length = length;
    }

    /**
     * @param obj
     * @return
     */
    public boolean equals(Object obj) {
        BinaryStreamArg arg = (BinaryStreamArg)obj;
        return super.equals(arg) && value == arg.value;
    }

    /**
     * @return
     */
    public byte[] getValue() {
        return value;
    }

    /**
     * @return
     */
    public Object getValueObject() {
        return getValue();
    }

    /**
     * @param value
     * @throws SQLException
     */
    public void setValueObject(Object value) throws SQLException {
        if (value != null && value instanceof byte[]) {
            this.value = ((byte[])value);
        } else if (value != null && value instanceof String) {
            this.value = ((String)value).getBytes();
        } else if (value != null && value instanceof char[]) {
            this.value = (new String((char[])value)).getBytes();
        }
    }

    /**
     * @return
     */
    public String toString() {
        return super.toString() + ", value = |" + value + "|";
    }

    /**
     * @return
     */
    public int getLength() {
        return this.length;
    }
}
