/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc.args;

import java.io.Serializable;

import java.sql.SQLException;
import java.sql.Types;

/**
 * 
 * @author cshah
 * @version 1.0
 */
public class CharStreamArg extends DALArgs implements Serializable {
    private char[] value;
    private int length;


    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     * @param length
     */
    public CharStreamArg(int position, boolean isOut, boolean isNull, 
                         char[] value, int length) {
        init(position, isOut, isNull, value, length);
    }

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     * @param length
     */
    protected void init(int position, boolean isOut, boolean isNull, 
                        char[] value, int length) {
        super.init(position, isOut, isNull, Types.LONGVARCHAR);
        this.value = value;
        this.length = length;
    }

    /**
     * @param obj
     * @return
     */
    public boolean equals(Object obj) {
        CharStreamArg arg = (CharStreamArg)obj;
        return super.equals(arg) && value == arg.value;
    }

    /**
     * @return
     */
    public char[] getValue() {
        return value;
    }

    /**
     * @return
     */
    public Object getValueObject() {
        return getValue();
    }

    /**
     * @param value
     * @throws SQLException
     */
    public void setValueObject(Object value) throws SQLException {
        if (value != null && value instanceof char[]) {
            this.value = ((char[])value);
        } else if (value != null && value instanceof String) {
            this.value = ((String)value).toCharArray();
        } else if (value != null ){
            this.value = ((String)value).toString().toCharArray();
        }
    }

    /**
     * @return
     */
    public String toString() {
        return super.toString() + ", value = |" + value + "|";
    }

    /**
     * @return
     */
    public int getLength() {
        return this.length;
    }        
}
