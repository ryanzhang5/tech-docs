package com.wm.dal.jdbc.utils;

import java.io.Serializable;

public class SecurityRuleFieldBean implements Serializable {

	public final static String SEPERATOR = "|";
	
	public int getRuleId() {
		return ruleId;
	}

	public void setRuleId(int ruleId) {
		this.ruleId = ruleId;
	}

	public String getFieldId() {
		return fieldId;
	}

	public void setFieldId(String fieldId) {
		this.fieldId = fieldId;
	}

	public String getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}

	public String packKey() {

		return ruleId + SEPERATOR + fieldId;
	}

	public void unpackKey(String key) {

		if (key != null && !"".equals(key)) {
			String[] keyStr = key.split(SEPERATOR);
			ruleId = Integer.valueOf(keyStr[0]);
			fieldId = keyStr[1];
		}
	}

	private int ruleId;
	private String fieldId;
	private String fieldValue;
}
