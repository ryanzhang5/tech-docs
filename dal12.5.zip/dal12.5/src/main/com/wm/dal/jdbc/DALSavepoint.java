/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc;

import java.sql.SQLException;

/**
 * 
 * @author cshah
 * @version 1.0
 */
public class DALSavepoint implements java.sql.Savepoint {

        /**
     * Retrieves the generated CALLER_ID for the savepoint that this 
     * <code>Savepoint</code> object represents.
     * @return the numeric CALLER_ID of this savepoint
     * @exception SQLException if this is a named savepoint
     * @since 1.4
     */
        public int getSavepointId() throws SQLException { throw new SQLException("Method not implemented"); }

        /**
         * Retrieves the name of the savepoint that this <code>Savepoint</code>
         * object represents.
         * @return the name of this savepoint
         * @exception SQLException if this is an un-named savepoint
         * @since 1.4
         */
        public String getSavepointName() throws SQLException { throw new SQLException("Method not implemented"); }
}
