/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc.args;

import java.io.Serializable;

import java.sql.*;

import java.util.Comparator;

/**
 * 
 * @author cshah
 * @version 1.0
 */
public abstract class DALArgs implements Serializable{
    private int position;
    private int type;
    private boolean isOut;
    private boolean isNull;
    private String paramName;
    private String typeName;
    
    /**
     * 
     */
    protected DALArgs() { }

    /**
     * @param position
     * @param isOutParam
     * @param isNull
     * @param type
     */
    protected DALArgs( int position, boolean isOutParam, boolean isNull, int type ) {
        init( position, isOutParam, isNull, type );
    }

    /**
     * @param position
     * @param isOutParam
     * @param isNull
     * @param type
     */
    protected void init( int position, boolean isOutParam, boolean isNull, int type ) {
        init( position, isOutParam, isNull, type,  null );
    }

    /**
     * 
     * @param position
     * @param isOutParam
     * @param isNull
     * @param type
     * @param typeName
     */
    protected void init( int position, boolean isOutParam, boolean isNull, int type, String typeName ) {
        this.position = position;
        this.type     = type;
        this.isOut    = isOutParam;
        this.isNull   = isNull;
        this.typeName = typeName;
    }

    /**
     * @param value
     * @throws SQLException
     */
    public abstract void setValueObject(Object value) throws SQLException;

    /**
     * @return
     * @throws SQLException
     */
    public abstract Object getValueObject() throws SQLException;

    /**
     * @return
     */
    public int getPosition() {
        return position;
    }

    /**
     * @return
     */
    public int getDataType() {
        return type;
    }

    /**
     * @return
     */
    public boolean isOutParameter() {
        return isOut;
    }

    /**
     * @return
     */
    public boolean isNull() {
        return isNull;
    }

    /**
     * @param v
     */
    public void isNull( boolean v ) {
        isNull = v;
    }

   /**
    * @return this db procedure argument as a string.
    */
    public String toString() {
    return   getClass().getName() + 
      ": position = " + getPosition() + " " +
      ", type = " + getDataType() + " " +
      ", isOut = " + isOutParameter() + " " +
      ", isNull = " + isNull() + " ";

    }

    /**
     * @param obj
     * @return
     */
    public boolean equals( Object obj ) {
        DALArgs arg = (DALArgs)obj;
        return getPosition() == arg.getPosition()
               &&
            getDataType() == arg.getDataType()
            &&
            isNull() == arg.isNull()
            &&
            isOutParameter() == arg.isOutParameter();
    }

  // Comparator to use when sorting DALArgs objects
  public static final Comparator ascendingPositionSort  =
    new Comparator () {
      /**
       * Compares the args and sorts them in
       * ascending order by their position.
       */
      public int compare( Object o1, Object o2 )
      {
        if ( o1 == null && o2 == null ) return 0;
        DALArgs arg1, arg2;
        arg1 = (DALArgs) o1;
        arg2 = (DALArgs) o2;
        // We consider null to always be earliest in the
        // sort order
        if ( arg1 == null ) return -1;
        if ( arg2 == null ) return  1;
        if ( arg1.getPosition() <  arg2.getPosition() ) return -1;
        if ( arg1.getPosition() == arg2.getPosition() ) return  0;
        if ( arg1.getPosition() >  arg2.getPosition() ) return  1;
        // Should never get here
        return 0;
      }
    };

    /**
     * 
     * @return
     */
    public String getTypeName() {
        return this.typeName;
    }
}

