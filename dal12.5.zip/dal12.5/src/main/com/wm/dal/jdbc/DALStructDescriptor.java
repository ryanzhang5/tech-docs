package com.wm.dal.jdbc;

import java.io.Serializable;

import java.sql.Connection;

/**
 * 
 * @author cshah
 * @version 1.0
 */
public class DALStructDescriptor implements Serializable {

    private String descriptorName;
    private transient Connection connection;

    /**
     * 
     * @param descriptorName
     */
    private DALStructDescriptor(String descriptorName, Connection connection) {
        this.descriptorName = descriptorName;
        this.connection = connection;
    }

    /**
     * 
     * @param descriptorName
     * @param connection
     * @return
     */
    public static DALStructDescriptor createDescriptor(String descriptorName, 
                                                       Connection connection) {
        return new DALStructDescriptor(descriptorName, connection);
    }

    /**
     * 
     * @return
     */
    public String getDescriptorName() {
        return descriptorName;
    }

    public Connection getConnection() {
        return connection;
    }
    
}
