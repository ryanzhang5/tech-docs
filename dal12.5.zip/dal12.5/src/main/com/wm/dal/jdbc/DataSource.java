/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc;


import java.io.PrintWriter;
import java.io.Serializable;

import java.sql.Driver;
import java.sql.SQLException;
import java.util.Properties;

import javax.naming.NamingException;
import javax.naming.Reference;
import javax.naming.Referenceable;
import javax.naming.StringRefAddr;

/**
 * An implementation of the JDBC 2.0 optional package <code>DataSource</code>
 * interface. It allows to set the URL, user name, and password to its
 * properties. It can be bound via JNDI so that the properties can be set by an
 * "application server" and a "ready-to-use" reference to
 * <code>DataSource</code> can be retrieved via JNDI.
 * 
 */
public class DataSource implements javax.sql.DataSource, Referenceable, Serializable {
//  private static final long serialVersionUID = 7103360001817804513L;
  
  /** DataSource properties */
  protected static final String URL_PROPERTY         = "url";
  protected static final String USER_PROPERTY        = "user";//Driver.USER_PROPERTY;
  protected static final String PASSWORD_PROPERTY    = "password";//Driver.PASSWORD_PROPERTY;
  protected static final String DRIVER_CLASSNAME     = "com.wm.dal.driver.DALDriver";
  protected static final String FACTORY_CLASSNAME    = "com.wm.dal.driver.DataSourceFactory";
  protected static final String DESCRIPTION_PROPERTY = "description";

  /** Wrapped driver for to get connections. */
  protected static Driver       driver               = null;
  static {
    try  {
      driver = (DALDriver) Class.forName(DRIVER_CLASSNAME).newInstance();
    } catch (Exception e) {
      throw new RuntimeException("Can't load " + DRIVER_CLASSNAME,e);
    }
  }

  /** DataSource properties */
  protected String              url                  = null;
  protected String              user                 = null;
  protected String              password             = null;
  protected PrintWriter         logWriter            = null;

  /**
   * Default constructor.
   */
  public DataSource() {
  }

  // ---------------------------------
  // --- DataSource methods
  // ---------------------------------
  /**
   * Gets connection. Retrieves a new connection using the user name and
   * password that have been already set.
   * 
   * @throws SQLException if an error occurs.
   * @return a new connection.
   */
  public java.sql.Connection getConnection() throws SQLException {
    return getConnection(user, password);
  }

  /**
   * Gets connection. Retrieves a new connection using the user name and
   * password specified.
   * 
   * @param user user name.
   * @param password password.
   * @return a new connection.
   * @throws SQLException if an error occurs.
   */
  public java.sql.Connection getConnection(String user, String password)
      throws SQLException {
    if (user == null) {
      user = "";
    }
    if (password == null)  {
      password = "";
    }
    Properties props = new Properties();
    props.put(USER_PROPERTY, user);
    props.put(PASSWORD_PROPERTY, password);

    return getConnection(props);
  }

  /**
   * Sets the log writer for this data source.
   * 
   * @param output print writer.
   * @throws SQLException in case of an error occurs.
   */
  public void setLogWriter(PrintWriter output) throws SQLException {
    logWriter = output;
  }

  /**
   * Gets the log writer.
   * 
   * @return log writer.
   */
  public java.io.PrintWriter getLogWriter() {
    return logWriter;
  }

  /**
   * Sets the timeout. Actually does nothing.
   * 
   * @param seconds timeout in seconds.
   * @throws SQLException in case of an error occurs.
   */
  public void setLoginTimeout(int seconds) throws SQLException {
  }

  /**
   * Gets the login timeout.
   * 
   * @return login timeout
   * @throws SQLException in case of an error occurs.
   */
  public int getLoginTimeout() throws SQLException {
    return 0;
  }

  // ---------------------------------
  // --- Referenceable methods
  // ---------------------------------
  /**
   * Gets a reference to this. The factory used for this class is the
   * {@link DataSourceFactory}class.
   * 
   * @return a reference to this.
   * @throws NamingException if <code>DataSourceFactory</code> not found.
   */
  public Reference getReference() throws NamingException {
    Reference ref = new Reference(getClass().getName(), FACTORY_CLASSNAME, null);
    ref.add(new StringRefAddr(DESCRIPTION_PROPERTY, getDescription()));
    ref.add(new StringRefAddr(USER_PROPERTY, getUser()));
    ref.add(new StringRefAddr(PASSWORD_PROPERTY, password));
    ref.add(new StringRefAddr(URL_PROPERTY, getUrl()));
    return ref;
  }

  // ---------------------------------
  // --- Properties methods
  // ---------------------------------

  /**
   * Return the description of this Datasource with the Driver version number.
   * 
   * @return Datasource description
   */
  public String getDescription() {
    return "Walmart.com " + driver.getMajorVersion() + "."
        + driver.getMinorVersion() + " Datasource";
  }

  /**
   * Sets url of the Walmart controller(s) to connect. The method is used by the
   * "application server" to set the URL (potentially according a deployment
   * descriptor). The url is stored in the {@link #URL_PROPERTY}property.
   * 
   * @param url URL to be used to connect Walmart controller(s)
   */
  public void setUrl(String url) {
    this.url = url;
  }

  /**
   * Sets URL of the Walmart controller(s) to connect. The method is used by the
   * "application server" to set the URL (potentially according a deployment
   * descriptor). The URL is stored in the "url" property.
   * 
   * @param url URL to be used to connect Walmart controller(s).
   */
  public void setURL(String url) {
    setUrl(url);
  }

  /**
   * Gets url of the Walmart controller(s) to connect. The URL is stored in the
   * {@link #URL_PROPERTY}property.
   * 
   * @return URL to be used to connect Walmart controller(s).
   */
  public String getUrl() {
    return url;
  }

  /**
   * Gets URL of the Walmart controller(s) to connect. The URL is stored in the
   * {@link #URL_PROPERTY}property.
   * 
   * @return URL to be used to connect Walmart controller(s).
   */
  public String getURL() {
    return getUrl();
  }

  /**
   * Sets user name to be used to connect the Walmart controller(s). The method
   * can be used by the "application server" to set the user name (potentially
   * according a deployment descriptor). The user name is stored in the
   * {@link #USER_PROPERTY}property.
   * 
   * @param userName user name to be used to connect Walmart controller(s).
   */
  public void setUser(String userName) {
    user = userName;
  }

  /**
   * Gets user name to be used to connect the Walmart controller(s). The user
   * name is stored in the {@link #USER_PROPERTY}property.
   * 
   * @return user name to be used to connect Walmart controller(s).
   */
  public String getUser() {
    return user;
  }

  /**
   * Sets password to be used to connect the Walmart controller(s). The method
   * can be used by the "application server" to set the password (potentially
   * according a deployment descriptor). The password is stored in the
   * {@link #PASSWORD_PROPERTY}property. Note that there is not a
   * <code>getPassword</code> method.
   * 
   * @param pwd password to be used to connect Walmart controller(s).
   */
  public void setPassword(String pwd) {
    password = pwd;
  }

  // ---------------------------------
  // --- Protected methods
  // ---------------------------------
  /**
   * Creates a connection using the specified properties.
   * 
   * @param props connection properties.
   * @throws SQLException if an error occurs.
   * @return a new connection.
   */
  protected java.sql.Connection getConnection(Properties props)
      throws SQLException {
    return driver.connect(url, props);
  }

    /**
     * Returns an object that implements the given interface to allow access to
     * non-standard methods, or standard methods not exposed by the proxy.
     * 
     * If the receiver implements the interface then the result is the receiver 
     * or a proxy for the receiver. If the receiver is a wrapper
     * and the wrapped object implements the interface then the result is the
     * wrapped object or a proxy for the wrapped object. Otherwise return the
     * the result of calling <code>unwrap</code> recursively on the wrapped object 
     * or a proxy for that result. If the receiver is not a
     * wrapper and does not implement the interface, then an <code>SQLException</code> is thrown.
     *
     * @param iface A Class defining an interface that the result must implement.
     * @return an object that implements the interface. May be a proxy for the actual implementing object.
     * @throws java.sql.SQLException If no object found that implements the interface 
     * @since 1.6
     */
     public <T> T unwrap(java.lang.Class<T> iface) throws java.sql.SQLException {
         throw new SQLException("Method not implemented");
     }

    /**
     * Returns true if this either implements the interface argument or is directly or indirectly a wrapper
     * for an object that does. Returns false otherwise. If this implements the interface then return true,
     * else if this is a wrapper then return the result of recursively calling <code>isWrapperFor</code> on the wrapped
     * object. If this does not implement the interface and is not a wrapper, return false.
     * This method should be implemented as a low-cost operation compared to <code>unwrap</code> so that
     * callers can use this method to avoid expensive <code>unwrap</code> calls that may fail. If this method
     * returns true then calling <code>unwrap</code> with the same argument should succeed.
     *
     * @param iface a Class defining an interface.
     * @return true if this implements the interface or directly or indirectly wraps an object that does.
     * @throws java.sql.SQLException  if an error occurs while determining whether this is a wrapper
     * for an object with the given interface.
     * @since 1.6
     */
    public boolean isWrapperFor(java.lang.Class<?> iface) throws java.sql.SQLException {
        throw new SQLException("Method not implemented");
    }

}
