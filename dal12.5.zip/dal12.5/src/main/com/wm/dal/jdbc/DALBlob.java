/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc;

import com.wm.dal.jdbc.utils.DALUtil;

import java.io.ByteArrayInputStream;

import java.io.InputStream;
import java.io.Serializable;

import java.sql.Blob;
import java.sql.SQLException;

/**
 * The representation (mapping) in
 * the Java<sup><font size=-2>TM</font></sup> programming
 * language of an SQL 
 * <code>BLOB</code> value.  An SQL <code>BLOB</code> is a built-in type 
 * that stores a Binary Large Object as a column value in a row of 
 * a database table. By default drivers implement <code>Blob</code> using
 * an SQL <code>locator(BLOB)</code>, which means that a
 * <code>Blob</code> object contains a logical pointer to the
 * SQL <code>BLOB</code> data rather than the data itself.
 * A <code>Blob</code> object is valid for the duration of the
 * transaction in which is was created.
 * 
 * <P>Methods in the interfaces {@link ResultSet}, 
 * {@link CallableStatement}, and {@link PreparedStatement}, such as
 * <code>getBlob</code> and <code>setBlob</code> allow a programmer to 
 * access an SQL <code>BLOB</code> value.
 * The <code>Blob</code> interface provides methods for getting the
 * length of an SQL <code>BLOB</code> (Binary Large Object) value,
 * for materializing a <code>BLOB</code> value on the client, and for
 * determining the position of a pattern of bytes within a 
 * <code>BLOB</code> value. In addition, this interface has methods for updating
 * a <code>BLOB</code> value.
 *
 * @since 1.2
 */

public class DALBlob implements java.sql.Blob, Serializable {
        volatile byte[] data;

    public DALBlob(final byte[] data) throws SQLException {

        if (data == null) {
            throw DALUtil.sqlException("Invalid Argument");
        }

        this.data = data;    // (byte[]) data.clone();
    }
        
        
    /**
     * Returns the underlying byte array
     *
     * @return the underlying byte array
     */
    public byte[] getData() {
        return data;
    }


      /**
       * Returns the number of bytes in the <code>BLOB</code> value
       * designated by this <code>Blob</code> object.
       * @return length of the <code>BLOB</code> in bytes
       * @exception SQLException if there is an error accessing the
       * length of the <code>BLOB</code>
       * @since 1.2
       */
      public long length() throws SQLException { 
        final byte[] ldata = data;
        return ldata.length;
    }

      /**
       * Retrieves all or part of the <code>BLOB</code>
       * value that this <code>Blob</code> object represents, as an array of
       * bytes.  This <code>byte</code> array contains up to <code>length</code> 
       * consecutive bytes starting at position <code>pos</code>.
       *
       * @param pos the ordinal position of the first byte in the 
       *        <code>BLOB</code> value to be extracted; the first byte is at
       *        position 1
       * @param length the number of consecutive bytes to be copied
       * @return a byte array containing up to <code>length</code> 
       *         consecutive bytes from the <code>BLOB</code> value designated
       *         by this <code>Blob</code> object, starting with the
       *         byte at position <code>pos</code>
       * @exception SQLException if there is an error accessing the
       *            <code>BLOB</code> value
       * @see #setBytes
       * @since 1.2
       */
      public byte[] getBytes(long pos, int length) throws SQLException { 
        final byte[] ldata = data;
        final int    dlen  = ldata.length;

        pos--;

        if (pos < 0 || pos > dlen) {
            throw DALUtil.sqlException("Invalid Argument pos: " + (pos + 1));
        }

        if (length < 0 || length > dlen - pos) {
            throw DALUtil.sqlException("Invalid Argument length: " + length);
        }

        if (pos == 0 && length == dlen) {
            return ldata;
        }

        final byte[] out = new byte[length];

        System.arraycopy(ldata, (int) pos, out, 0, length);

        return out;
    
    } 

      /**
       * Retrieves the <code>BLOB</code> value designated by this
       * <code>Blob</code> instance as a stream.
       *
       * @return a stream containing the <code>BLOB</code> data
       * @exception SQLException if there is an error accessing the
       *            <code>BLOB</code> value
       * @see #setBinaryStream
       * @since 1.2
       */
    public java.io.InputStream getBinaryStream () throws SQLException { 
        final byte[] ldata = data;
        return new ByteArrayInputStream(ldata);
    }

      /** 
       * Retrieves the byte position at which the specified byte array
       * <code>pattern</code> begins within the <code>BLOB</code>
       * value that this <code>Blob</code> object represents.  The
       * search for <code>pattern</code> begins at position
       * <code>start</code>.  
       *
       * @param pattern the byte array for which to search
       * @param start the position at which to begin searching; the
       *        first position is 1
       * @return the position at which the pattern appears, else -1
       * @exception SQLException if there is an error accessing the 
       * <code>BLOB</code>
       * @since 1.2
       */
    public long position(byte pattern[], long start) throws SQLException { 
        final byte[] ldata = data;
        final int    dlen  = ldata.length;

        if (start > dlen || pattern == null) {
            return -1;
        } else if (start < 1) {
            start = 0;
        } else {
            start--;
        }

        final int plen = pattern.length;

        if (plen == 0 || start > dlen - plen) {
            return -1;
        }

        final int  stop = dlen - plen;
        final byte b0   = pattern[0];

        outer_loop:
        for (int i = (int) start; i <= stop; i++) {
            if (ldata[i] != b0) {
                continue;
            }

            int     len     = plen;
            int     doffset = i;
            int     poffset = 0;
            boolean match   = true;

            while (len-- > 0) {
                if (ldata[doffset++] != pattern[poffset++]) {
                    continue outer_loop;
                }
            }

            return i + 1;
        }

        return -1;
    }

      /** 
       * Retrieves the byte position in the <code>BLOB</code> value
       * designated by this <code>Blob</code> object at which 
       * <code>pattern</code> begins.  The search begins at position
       * <code>start</code>.
       *
       * @param pattern the <code>Blob</code> object designating
       * the <code>BLOB</code> value for which to search
       * @param start the position in the <code>BLOB</code> value
       *        at which to begin searching; the first position is 1
       * @return the position at which the pattern begins, else -1
       * @exception SQLException if there is an error accessing the
       *            <code>BLOB</code> value
       * @since 1.2
       */
      public long position(Blob pattern, long start) throws SQLException { 
        final byte[] ldata = data;
        final int    dlen  = ldata.length;

        if (start > dlen || pattern == null) {
            return -1;
        } else if (start < 1) {
            start = 0;
        } else {
            start--;
        }

        final long plen = pattern.length();

        if (plen == 0 || start > ((long) dlen) - plen) {
            return -1;
        }

        // by now, we know plen <= Integer.MAX_VALUE
        final int iplen = (int) plen;
        byte[]    bap;

        if (pattern instanceof DALBlob) {
            bap = ((DALBlob) pattern).data;
        } else {
            bap = pattern.getBytes(1, iplen);
        }

        final int  stop = dlen - iplen;
        final byte b0   = bap[0];

        outer_loop:
        for (int i = (int) start; i <= stop; i++) {
            if (ldata[i] != b0) {
                continue;
            }

            int len     = iplen;
            int doffset = i;
            int poffset = 0;

            while (len-- > 0) {
                if (ldata[doffset++] != bap[poffset++]) {
                    continue outer_loop;
                }
            }

            return i + 1;
        }

        return -1;
    }

        // -------------------------- JDBC 3.0 -----------------------------------

        /**
         * Writes the given array of bytes to the <code>BLOB</code> value that
         * this <code>Blob</code> object represents, starting at position 
         * <code>pos</code>, and returns the number of bytes written.
         *
         * @param pos the position in the <code>BLOB</code> object at which
         *        to start writing
         * @param bytes the array of bytes to be written to the <code>BLOB</code>
         *        value that this <code>Blob</code> object represents
         * @return the number of bytes written
         * @exception SQLException if there is an error accessing the
         *            <code>BLOB</code> value
         * @see #getBytes
         * @since 1.4
         */
        public int setBytes(long pos, byte[] bytes) throws SQLException { throw new SQLException("Method not implemented"); }

        /**
         * Writes all or part of the given <code>byte</code> array to the
         * <code>BLOB</code> value that this <code>Blob</code> object represents
         * and returns the number of bytes written.
         * Writing starts at position <code>pos</code> in the <code>BLOB</code>
         * value; <code>len</code> bytes from the given byte array are written.
         *
         * @param pos the position in the <code>BLOB</code> object at which
         *        to start writing
         * @param bytes the array of bytes to be written to this <code>BLOB</code>
         *        object
         * @param offset the offset into the array <code>bytes</code> at which
         *        to start reading the bytes to be set
         * @param len the number of bytes to be written to the <code>BLOB</code>
         *        value from the array of bytes <code>bytes</code>
         * @return the number of bytes written
         * @exception SQLException if there is an error accessing the
         *            <code>BLOB</code> value
         * @see #getBytes
         * @since 1.4
         */
        public int setBytes(long pos, byte[] bytes, int offset, int len) throws SQLException { throw new SQLException("Method not implemented"); }

        /**
         * Retrieves a stream that can be used to write to the <code>BLOB</code> 
         * value that this <code>Blob</code> object represents.  The stream begins
         * at position <code>pos</code>.
         *
         * @param pos the position in the <code>BLOB</code> value at which
         *        to start writing
         * @return a <code>java.io.OutputStream</code> object to which data can 
         *         be written
         * @exception SQLException if there is an error accessing the
         *            <code>BLOB</code> value
         * @see #getBinaryStream
         * @since 1.4
         */
        public java.io.OutputStream setBinaryStream(long pos) throws SQLException { throw new SQLException("Method not implemented"); }

        /**
         * Truncates the <code>BLOB</code> value that this <code>Blob</code>
         * object represents to be <code>len</code> bytes in length.
         *
         * @param len the length, in bytes, to which the <code>BLOB</code> value
         *        that this <code>Blob</code> object represents should be truncated
         * @exception SQLException if there is an error accessing the
         *            <code>BLOB</code> value
         * @since 1.4
         */
        public void truncate(long len) throws SQLException { 
            final byte[] ldata = data;

            if (len < 0 || len > ldata.length) {
                throw DALUtil.sqlException("Invalid Argument"  + Long.toString(len));
            }

            if (len == ldata.length) {
                return;
            }

            byte[] newData = new byte[(int) len];
            System.arraycopy(ldata, 0, newData, 0, (int) len);
            data = newData;
        }

    /**
     * This method frees the <code>Blob</code> object and releases the resources that 
     * it holds. The object is invalid once the <code>free</code>
     * method is called.
     *<p>
     * After <code>free</code> has been called, any attempt to invoke a
     * method other than <code>free</code> will result in a <code>SQLException</code> 
     * being thrown.  If <code>free</code> is called multiple times, the subsequent
     * calls to <code>free</code> are treated as a no-op.
     *<p>
     * 
     * @throws SQLException if an error occurs releasing
     * the Blob's resources
     * @exception SQLFeatureNotSupportedException if the JDBC driver does not support
     * this method
     * @since 1.6
     */
    public void free() throws SQLException {
        data = null;
    }

    /**
     * Returns an <code>InputStream</code> object that contains a partial <code>Blob</code> value, 
     * starting  with the byte specified by pos, which is length bytes in length.
     *
     * @param pos the offset to the first byte of the partial value to be retrieved.
     *  The first byte in the <code>Blob</code> is at position 1
     * @param length the length in bytes of the partial value to be retrieved
     * @return <code>InputStream</code> through which the partial <code>Blob</code> value can be read.
     * @throws SQLException if pos is less than 1 or if pos is greater than the number of bytes
     * in the <code>Blob</code> or if pos + length is greater than the number of bytes 
     * in the <code>Blob</code>
     *
     * @exception SQLFeatureNotSupportedException if the JDBC driver does not support
     * this method
     * @since 1.6
     */
    public InputStream getBinaryStream(long pos, long length) throws SQLException {
        throw new SQLException("Method not implemented"); 
    }

}
