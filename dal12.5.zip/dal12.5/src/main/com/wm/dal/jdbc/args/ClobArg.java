/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc.args;

import com.wm.dal.jdbc.DALClob;
import com.wm.dal.jdbc.utils.DALUtil;

import java.sql.Clob;
import java.sql.SQLException;

/**
 * 
 * @author cshah
 * @version 1.0
 */
public class ClobArg extends DALArgs {
    private Clob value;

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    public ClobArg( int position, boolean isOut, boolean isNull, Clob value ) throws SQLException {
        init( position, isOut, isNull, value );
    }

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    protected void init( int position, boolean isOut, boolean isNull, Clob value ) throws SQLException {
        if (value == null)
            init( position, isOut, true, java.sql.Types.CLOB );
        else
            init( position, isOut, false, java.sql.Types.CLOB );
    
        this.value = (Clob) DALUtil.convertToDALObject(value);
    }

    /**
     * @param obj
     * @return
     */
    public boolean equals( Object obj ) {
        ClobArg arg = (ClobArg)obj;
        return super.equals( arg ) 
               &&
            value.equals( arg.value );
    }

   /**
     * @return
     */
    public Clob getValue() { return value; }

    /**
     * @return
     */
    public Object getValueObject() { return getValue(); }

    /**
     * @param value
     * @throws SQLException
     */
    public void setValueObject(Object value) throws SQLException {
        if (value == null) {
            this.value = null;
            this.isNull(true);
        } else if (value instanceof Clob) {
            this.value = (Clob) DALUtil.convertToDALObject(value);
        } else if (value instanceof String) {
            this.value = new DALClob((String)value);
        } else if (value instanceof char[]) {
            this.value = new DALClob((char[])value);            
        } else if (value instanceof byte[]) {
            this.value = new DALClob((byte[])value);                        
        }
    }

    /**
     * @return
     */
    public String toString() { 
        return super.toString() + ", value = |" + (value == null ? "null" : value.toString()) + "|"; 
      }
}
