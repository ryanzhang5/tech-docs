/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 */

package com.wm.dal.jdbc.sqldata;

import java.io.Serializable;

import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

/**
 * 
 * @author cshah
 */
public class DALLong implements SQLData, Serializable {
    private long longID;
    private String sqlTypeName;

    /**
     * 
     * @param itemId
     * @param sqlTypeName
     */
    public DALLong(long itemId, String sqlTypeName) {
        this.longID = itemId;
        this.sqlTypeName = sqlTypeName;
    }

    /**
     * 
     * @return
     * @throws SQLException
     */
    public String getSQLTypeName() throws SQLException {
        return sqlTypeName;
    }

    /**
     * 
     * @param sqlInput
     * @param string
     * @throws SQLException
     */
    public void readSQL(SQLInput sqlInput, String string) throws SQLException {
            longID = sqlInput.readLong();
    }

    /**
     * 
     * @param sqlOutput
     * @throws SQLException
     */
    public void writeSQL(SQLOutput sqlOutput) throws SQLException {
            sqlOutput.writeLong(longID);
    }

}
