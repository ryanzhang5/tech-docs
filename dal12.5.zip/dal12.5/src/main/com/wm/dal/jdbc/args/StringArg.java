/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc.args;

import java.sql.SQLException;


/**
 * @author cshah
 * @version 1.0
 */
public class StringArg extends DALArgs {
    private String value;

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    public StringArg( int position, boolean isOut, boolean isNull, String value ) {
        init( position, isOut, isNull, value );
    }

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    protected void init( int position, boolean isOut, boolean isNull, String value ) {
        super.init( position, isOut, isNull, java.sql.Types.VARCHAR );
        this.value = value;
    }

    /**
     * @param obj
     * @return
     */
    public boolean equals( Object obj ) {
        if (obj != null && obj instanceof StringArg) {
            StringArg arg = (StringArg)obj;
            return super.equals( arg )  && value.equals( arg.value );
        } 
        
        return false;
    }

    /**
     * @return
     */
    public String getValue() { return value; }

    /**
     * @return
     */
    public Object getValueObject() { return getValue(); }

    /**
     * @param value
     * @throws SQLException
     */
    public void setValueObject(Object value) throws SQLException {
        if (value != null && value instanceof String)
            this.value = (String)value;
    }

    /**
     * @return
     */
    public String toString() { return super.toString() + ", value = |" + value + "|"; }

}
