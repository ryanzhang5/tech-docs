/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.jdbc;

import oracle.jdbc.OracleConnection;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
  
import com.wm.corelib.config.AppConfig;

/**
 * DALFactory
 *
 * @author mkishore
 * @since 1.0
 */
public class DALFactory {
    private static final Logger logger = Logger.getLogger(DALFactory.class.getName());

    // defaults to being enabled - unless explicitly suppressed by setting this property
    private static final boolean DAL_ENABLED = Boolean.parseBoolean(AppConfig.getInstance().getProperty("dal.enabled", "true"));

    public static boolean isDALEnabled() {
        return DAL_ENABLED;
    }

    public static Array newArray(DALArrayDescriptor arrayDescriptor, int baseType, String baseTypeName, Object array) throws SQLException {
        Connection connection = arrayDescriptor.getConnection();
        if (connection != null && connection.isWrapperFor(OracleConnection.class)) {
            connection = connection.unwrap(OracleConnection.class);
            ArrayDescriptor oraDescriptor = ArrayDescriptor.createDescriptor(arrayDescriptor.getDescriptorName(), connection);
            return new ARRAY(oraDescriptor, connection, array);
        }
        return new DALArray(arrayDescriptor, baseType, baseTypeName, array);
    }

    public static Struct newStruct(DALStructDescriptor structDescriptor, String baseTypeName, Object attributes) throws SQLException {
        Connection connection = structDescriptor.getConnection();
        if (connection != null && connection.isWrapperFor(OracleConnection.class)) {
            connection = connection.unwrap(OracleConnection.class);
            StructDescriptor oraDescriptor = StructDescriptor.createDescriptor(structDescriptor.getDescriptorName(), connection);
            return new STRUCT(oraDescriptor, connection, (Object[]) attributes);
        }
        return new DALStruct(structDescriptor, baseTypeName, attributes);
    }

    public static Blob newBlob(Connection connection, byte[] data) throws SQLException {
        if (connection != null && connection.isWrapperFor(OracleConnection.class)) {
            connection = connection.unwrap(OracleConnection.class);
            oracle.sql.BLOB tempBlob = null;
            try {
                tempBlob = oracle.sql.BLOB.createTemporary(connection, true, oracle.sql.BLOB.DURATION_SESSION);
                tempBlob.open(oracle.sql.BLOB.MODE_READWRITE);
                java.io.OutputStream tempBlobWriter = tempBlob.setBinaryStream(1L);
                tempBlobWriter.write(data);
                tempBlobWriter.flush();
                tempBlobWriter.close();
                tempBlob.close();
                return tempBlob;
            } catch (Exception e) {
                logger.log(Level.WARNING, "Error creating an oracle BLOB", e);
                if (tempBlob != null) {
                    tempBlob.freeTemporary();
                }
                throw new SQLException(e);
            }
        }
        return new DALBlob(data);
    }

    public static Clob newClob(Connection connection, char[] data) throws SQLException {
        if (connection != null && connection.isWrapperFor(OracleConnection.class)) {
            connection = connection.unwrap(OracleConnection.class);
            oracle.sql.CLOB tempClob = null;
            try {
                tempClob = oracle.sql.CLOB.createTemporary(connection, true, oracle.sql.CLOB.DURATION_SESSION);
                tempClob.open(oracle.sql.CLOB.MODE_READWRITE);
                java.io.Writer tempClobWriter = tempClob.setCharacterStream(1L);
                tempClobWriter.write(data);
                tempClobWriter.flush();
                tempClobWriter.close();
                tempClob.close();
                return tempClob;
            } catch (Exception e) {
                logger.log(Level.WARNING, "Error creating an oracle CLOB", e);
                if (tempClob != null) {
                    tempClob.freeTemporary();
                }
                throw new SQLException(e);
            }
        }
        return new DALClob(data);
    }

}
