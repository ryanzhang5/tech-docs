package com.wm.dal.jdbc.sqldata;

import java.io.Serializable;

import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;
import java.sql.SQLData;

/**
 * Created by IntelliJ IDEA.
 * User: sramakrishnan
 * Date: Jan 14, 2008
 * Time: 1:21:10 PM
 * To change this template use File | Settings | File Templates.
 */
public class DALSCDetail implements SQLData, Serializable {

    //public static final String SQL_TYPE = "CUSTOMER.T_SC_SCAN_REC";
    //public static final String SQL_TAB_TYPE ="CUSTOMER.T_SC_SCAN_TAB";

    public static final String SQL_TYPE = "T_SC_SCAN_REC";
    public static final String SQL_TAB_TYPE ="T_SC_SCAN_TAB";

    private long poLineNo;
    private String startCardNo;
    private String endCardNo;
    private int quantity;
    private String sqlType;

    public DALSCDetail(){

    }

    // constructor that fills in data members
    public DALSCDetail(long poLineNo, String startCardNo, String endCardNo, int quantity, String sqlType) {
        this.poLineNo = poLineNo;
        this.startCardNo = startCardNo;
        this.endCardNo = endCardNo;
        this.quantity = quantity;
        this.sqlType = sqlType;
    }

    public long getPoLineNo() {
        return poLineNo;
    }

    public void setPoLineNo(long poLineNo) {
        this.poLineNo = poLineNo;
    }

    public String getStartCardNo() {
        return startCardNo;
    }

    public void setStartCardNo(String startCardNo) {
        this.startCardNo = startCardNo;
    }

    public String getEndCardNo() {
        return endCardNo;
    }

    public void setEndCardNo(String endCardNo) {
        this.endCardNo = endCardNo;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // returns type name as set by readSQL (SQLData)
    public String getSQLTypeName() throws SQLException {
        return sqlType;
    }

    // read data from sql stream (SQLData)
    public void readSQL(SQLInput stream, String typeName) throws SQLException {
        sqlType = typeName;
        poLineNo = stream.readLong();
        startCardNo = stream.readString();
        endCardNo = stream.readString();
        quantity = stream.readInt();        
    }

    // write data to sql stream (SQLData)
    public void writeSQL(SQLOutput stream) throws SQLException {
        stream.writeLong(poLineNo);
        stream.writeString(startCardNo);
        stream.writeString(endCardNo);
        stream.writeInt(quantity);
    }

    
}

