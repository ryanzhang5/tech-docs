/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc.args;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Types;

/**
 * @author cshah
 * @version 1.0
 */
public class TimestampArg extends DALArgs {
    private long value;

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    public TimestampArg(int position, boolean isOut, boolean isNull, 
                        long value) {
        init(position, isOut, isNull, value);
    }

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    protected void init(int position, boolean isOut, boolean isNull, 
                        long value) {
        super.init(position, isOut, isNull, Types.TIMESTAMP);
        this.value = value;
    }

    /**
     * @param obj
     * @return
     */
    public boolean equals(Object obj) {
        TimestampArg arg = (TimestampArg)obj;
        return super.equals(arg) && value == arg.value;
    }

    /**
     * @return
     */
    public long getValue() {
        return value;
    }

    /**
     * @return
     */
    public Object getValueObject() {
        return new Timestamp(getValue());
    }

    /**
     * @param value
     * @throws SQLException
     */
    public void setValueObject(Object value) throws SQLException {
        if (value != null && value instanceof Long) {
            this.value = ((Long)value).longValue();
        } else if (value != null && value instanceof Date) {
            this.value = ((Date)value).getTime();
        } else if (value != null && value instanceof Time) {
            this.value = ((Time)value).getTime();
        } else if (value != null && value instanceof Timestamp) {
            this.value = ((Timestamp)value).getTime();
        }
    }

    /**
     * @return
     */
    public String toString() {
        return super.toString() + ", value = |" + value + "|";
    }

}
