/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc.args;

import java.sql.SQLException;
import java.sql.Types;

/**
 * @author cshah
 * @version 1.0
 */
public class AsciiStreamArg extends DALArgs {
    private byte[] value;
    private int length;

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     * @param length
     */
    public AsciiStreamArg(int position, boolean isOut, boolean isNull, 
                          byte[] value, int length) {
        init(position, isOut, isNull, value, length);
    }

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     * @param length
     */
    protected void init(int position, boolean isOut, boolean isNull, 
                        byte[] value, int length) {
        super.init(position, isOut, isNull, Types.LONGVARCHAR);
        this.value = value;
        this.length = length;
    }

    /**
     * @param obj
     * @return
     */
    public boolean equals(Object obj) {
        AsciiStreamArg arg = (AsciiStreamArg)obj;
        return super.equals(arg) && value == arg.value;
    }

    /**
     * @return
     */
    public byte[] getValue() {
        return value;
    }

    /**
     * @return
     */
    public Object getValueObject() {
        return getValue();
    }

    /**
     * @param value
     * @throws SQLException
     */
    public void setValueObject(Object value) throws SQLException {
        if (value != null && value instanceof byte[])
            this.value = ((byte[])value);
    }

    /**
     * @return
     */
    public String toString() {
        return super.toString() + ", value = |" + value + "|";
    }

    /**
     * @return
     */
    public int getLength() {
        return this.length;
    }    
}
