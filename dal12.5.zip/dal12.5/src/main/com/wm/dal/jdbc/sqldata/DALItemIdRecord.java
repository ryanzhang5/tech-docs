package com.wm.dal.jdbc.sqldata;

import java.io.Serializable;

import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

public class DALItemIdRecord implements SQLData, Serializable {
    Long    itemId;

    // SQL type corresponding to this class
    private static final String SQL_TYPE = "CATALOG.T_ITEM_NUM_REC";

    public DALItemIdRecord() {}
    public DALItemIdRecord(Long itemId) { this.itemId = itemId; }

    public Long getItemId() { return itemId; }
    public void setItemId(Long itemId) { this.itemId = itemId; }

   //O fulfill contract of interface SQLData w/ these methods
    public String getSQLTypeName() throws SQLException {
        return SQL_TYPE;
    }

    public void readSQL(SQLInput stream, String typeName) throws SQLException {
        throw new RuntimeException("Not implemented because for now we don't need to read these.");
    }

    public void writeSQL(SQLOutput stream) throws SQLException {
        stream.writeLong(itemId);
    }
}


