package com.wm.dal.jdbc.sqldata;

import java.io.Serializable;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Offer Element names, this have a look up table in back end as well
 * Each element has a data type associated with it.
 * <p/>
 * User: skumar
 * Date: Feb 17, 2008
 * Time: 6:30:15 PM
 */
public class OfferElementName<T> implements Serializable {
    /**
     * Maps a string value to the enumeration object
     */
    private static Map<String, OfferElementName> enumMap = new HashMap<String, OfferElementName>();

    /**
     * Offer element names returned by GE when an offer is made.
     * Same fields names are used for Quick Screen and Application offer
     * <p/>
     * Note: MMC prefixed offer elements are for Discover card and the ones
     * without prefix is for Walmart card. There are some common ones which
     * are valid for both type of cards.
     */
    public static final OfferElementName<String> REFERENCE_NUMBER =
            new OfferElementName<String>("REFERENCE_NUMBER", String.class);
    public static final OfferElementName<Long> APPROVED_CREDIT_LINE =
            new OfferElementName<Long>("APPROVED_CREDIT_LINE", Long.class);
    public static final OfferElementName<String> MMC_CODE =
            new OfferElementName<String>("MMC_CODE", String.class);
    public static final OfferElementName<String> MMC_CODE_DESCRIPTION =
            new OfferElementName<String>("MMC_CODE_DESCRIPTION", String.class);
    public static final OfferElementName<String> DECISION_PRODUCT_CODE =
            new OfferElementName<String>("DECISION_PRODUCT_CODE", String.class);
    public static final OfferElementName<Long> TEMPORARY_CREDIT_LINE =
            new OfferElementName<Long>("TEMPORARY_CREDIT_LINE", Long.class);
    public static final OfferElementName<BigDecimal> MMC_APR =
            new OfferElementName<BigDecimal>("MMC_APR", BigDecimal.class);
    public static final OfferElementName<BigDecimal> MMC_DELIQUENCY_RATE =
            new OfferElementName<BigDecimal>("MMC_DELIQUENCY_RATE", BigDecimal.class);
    public static final OfferElementName<BigDecimal> MMC_RATES =
            new OfferElementName<BigDecimal>("MMC_RATES", BigDecimal.class);
    public static final OfferElementName<BigDecimal> MMC_CASH_RATE =
            new OfferElementName<BigDecimal>("MMC_CASH_RATE", BigDecimal.class);
    public static final OfferElementName<BigDecimal> MMC_DELIQUENCY_APR =
            new OfferElementName<BigDecimal>("MMC_DELIQUENCY_APR", BigDecimal.class);
    public static final OfferElementName<BigDecimal> MMC_CASH_APR =
            new OfferElementName<BigDecimal>("MMC_CASH_APR", BigDecimal.class);
    public static final OfferElementName<String> TIER_CODE =
            new OfferElementName<String>("TIER_CODE", String.class);
    public static final OfferElementName<String> TIER_CODE_DESCRIPTION =
            new OfferElementName<String>("TIER_CODE_DESCRIPTION", String.class);
    public static final OfferElementName<BigDecimal> APR =
            new OfferElementName<BigDecimal>("APR", BigDecimal.class);
    public static final OfferElementName<BigDecimal> INT_RATE =
            new OfferElementName<BigDecimal>("INT_RATE", BigDecimal.class);


    /**
     * Enum of data types for offer element
     */
    public static enum DataType {
        STRING("C"), NUMERIC("N"), DATE("D");
        private String dbValue;

        private DataType(String dbValue) {
            this.dbValue = dbValue;
        }

        public String getDBValue() {
            return this.dbValue;
        }
    }

    /**
     * Data type of the offer element
     */
    private Class<T> dataType = null;

    /**
     * Db value of the data type
     */
    private String dbValue;

    /**
     * The name of this enum constant, as declared in the enum declaration.
     * Most programmers should use the {@link #toString} method rather than
     * accessing this field.
     */
    private final String name;

    /**
     * Constructor
     *
     * @param name     Offer Element Name
     * @param dataType Class of the data type of the offer element value
     */
    private OfferElementName(String name, Class<T> dataType) {
        this.name = name;
        this.dataType = dataType;
        if (dataType == String.class) this.dbValue = "C";
        else if (dataType == Long.class) this.dbValue = "N";
        else if (dataType == Date.class) this.dbValue = "D";
        enumMap.put(name, this);
    }

    /**
     * Get Data Type of the offer element value
     *
     * @return dataType Class of the data type of the offer element value
     */
    public Class<T> getDataType() {
        return this.dataType;
    }

    /**
     * Db value of the Data type
     *
     * @return DB string representation of the offer element value data type
     */
    public String getDataTypeDBValue() {
        return this.dbValue;
    }

    /**
     * Returns the name of this enum constant, as contained in the
     * declaration.  This method may be overridden, though it typically
     * isn't necessary or desirable.  An enum type should override this
     * method when a more "programmer-friendly" string form exists.
     *
     * @return the name of this enum constant
     */
    public String toString() {
        return name;
    }

    /**
     * Returns true if the specified object is equal to this
     * enum constant.
     *
     * @param other the object to be compared for equality with this object.
     * @return true if the specified object is equal to this
     *         enum constant.
     */
    public final boolean equals(Object other) {
        return this == other;
    }

    /**
     * Returns a hash code for this enum constant.
     *
     * @return a hash code for this enum constant.
     */
    public final int hashCode() {
        return System.identityHashCode(this);
    }

    /**
     * Throws CloneNotSupportedException.  This guarantees that enums
     * are never cloned, which is necessary to preserve their "singleton"
     * status.
     *
     * @return (neverreturns)
     */
    protected final Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException();
    }

    /**
     * Returns the enum constant of the specified enum type with the
     * specified name.  The name must match exactly an identifier used
     * in constructor.  (Extraneous whitespace
     * characters are not permitted.)
     *
     * @param name the name of the constant to return
     * @return the enum constant of the specified enum type with the
     *         specified name
     * @throws IllegalArgumentException if the specified enum type has
     *                                  no constant with the specified name, or the specified
     *                                  class object does not represent an enum type
     * @throws NullPointerException     if <tt>enumType</tt> or <tt>name</tt>
     *                                  is null
     */
    public static OfferElementName valueOf(String name) {
        OfferElementName result = enumMap.get(name);
        if (result != null)
            return result;
        if (name == null)
            throw new IllegalArgumentException("Name is null");
        throw new IllegalArgumentException(
                "No enum const " + name);
    }

    /**
     * Returns an array of all defined constants of this type.
     *
     * @return Array of OfferElementName type objects.
     */
    public static OfferElementName[] values() {
        return enumMap.values().toArray(new OfferElementName[0]);
    }
}

