/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc.args;

import java.sql.Ref;
import java.sql.SQLException;
import java.sql.Types;

/**
 * @author cshah
 * @version 1.0
 */
public class RefArg extends DALArgs {
    private Ref value;

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    public RefArg(int position, boolean isOut, boolean isNull, Ref value) {
        init(position, isOut, isNull, value);
    }

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    protected void init(int position, boolean isOut, boolean isNull, 
                        Ref value) {
        super.init(position, isOut, isNull, Types.REF);
        this.value = value;
    }

    /**
     * @param obj
     * @return
     */
    public boolean equals(Object obj) {
        RefArg arg = (RefArg)obj;
        return super.equals(arg) && value == arg.value;
    }

    /**
     * @return
     */
    public Object getValue() {
        return value;
    }

    /**
     * @return
     */
    public Object getValueObject() {
        return getValue();
    }

    /**
     * @param value
     * @throws SQLException
     */
    public void setValueObject(Object value) throws SQLException {
        if (value != null && value instanceof Ref)
            this.value = (Ref)value;
    }

    /**
     * @return
     */
    public String toString() {
        return super.toString() + ", value = |" + value + "|";
    }

}
