/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc.args;

import com.wm.dal.jdbc.utils.DALUtil;

import java.sql.SQLException;
import java.sql.Types;

/**
 * @author cshah
 * @version 1.0
 */
public class ObjectArg extends DALArgs {
    // TODO: make this Externalizable - and do the following:
    // - convert SQLData to DALStruct
    // - convert Array to DALArray - this needs to be done in ArrayArg. DALUtil?
    // - convert Struct to DALStruct
    // - do this depth-first..
    
    private Object value;

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    public ObjectArg(int position, boolean isOut, boolean isNull, Object value) throws SQLException {
        init(position, isOut, isNull, value);
    }

    /**
     * @param position
     * @param isOut
     * @param isNull
     * @param value
     */
    protected void init(int position, boolean isOut, boolean isNull, Object value) throws SQLException {
        init(position, isOut, isNull, Types.JAVA_OBJECT);
        this.value = DALUtil.convertToDALObject(value);
    }

    /**
     * @param obj
     * @return
     */
    public boolean equals(Object obj) {
        ObjectArg arg = (ObjectArg)obj;
        return arg.getValueObject().equals(this.getValueObject());
    }

    /**
     * @return
     */
    public Object getValue() {
        return value;
    }

    /**
     * @param value
     * @throws SQLException
     */
    public void setValueObject(Object value) throws SQLException {
        if (value == null) {
            this.value = null;
            this.isNull(true);
        } else {
            this.value = DALUtil.convertToDALObject(value);
        }
    }

    /**
     * @return
     */
    public Object getValueObject() {
        return getValue();
    }

    /**
     * @return
     */
    public String toString() {
        return super.toString() + ", value = |" + value + "|";
    }

}
