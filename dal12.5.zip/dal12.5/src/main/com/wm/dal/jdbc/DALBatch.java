/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc;

import com.wm.dal.jdbc.args.DALArgs;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;


/**
 * 
 * @author cshah
 * @version 1.0
 */
public class DALBatch implements Serializable {
    private String sql;
    private List<DALArgs> argList;

    /**
     * 
     * @param sql
     * @param argList
     */
    public DALBatch(String sql, List<DALArgs> argList) {
        this.sql = sql;
        this.argList = new ArrayList<DALArgs>();
        this.argList.addAll(argList);
    }

    /**
     * 
     * @return
     */
    public String getSql() {
        return sql;
    }

    /**
     * 
     * @return
     */
    public List<DALArgs> getArgList() {
        return argList;
    }
}
