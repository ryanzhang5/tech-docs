/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.jdbc;

import com.wm.dal.jdbc.utils.Constants;
import com.wm.dal.common.ConnectionTypeManager;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverPropertyInfo;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;
import java.util.logging.Logger;
import java.util.logging.Level;

/**
 * 
 */
public class DALDriver implements Driver {
    private static final Logger logger = Logger.getLogger(DALDriver.class.getName());

    /** Driver major version. */
    public static final int MAJOR_VERSION = Constants.getMajorVersion();

    /** Driver minor version. */
    public static final int MINOR_VERSION = Constants.getMinorVersion();
    protected static ArrayList     driverPropertiesNames;
    protected static final String  HOST_PROPERTY  = "host";
    protected static final String  PORT_PROPERTY  = "port";
    protected static final String  ALIAS_PROPERTY  = "alias";
    protected static final String  USER_PROPERTY  = "user";
    protected static final String  PASSWORD_PROPERTY = "password";
    protected static final String  DRIVER_NAME = "Walmart.com Proprietary JDBC Driver";
    protected static final String  DRIVER_VERSION = "1.0b";
    
    static {
          try {
            java.sql.DriverManager.registerDriver(new DALDriver());
          } catch (SQLException e) {
                throw new RuntimeException("Unable to register DAL driver",e);
          }

        // Build the static list of driver properties
        driverPropertiesNames = new ArrayList();
        driverPropertiesNames.add(DALDriver.HOST_PROPERTY);
        driverPropertiesNames.add(DALDriver.PORT_PROPERTY);
        driverPropertiesNames.add(DALDriver.ALIAS_PROPERTY);
        driverPropertiesNames.add(DALDriver.USER_PROPERTY);
        driverPropertiesNames.add(DALDriver.PASSWORD_PROPERTY);

        try {
            // initialize the router - to ensure that the clients get a copy of the routing rules
            ConnectionTypeManager.getInstance();
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Error initializing the connection types", e);
        }

    }
    
    /**
     * Attempts to make a database connection to the given URL.
     * The driver should return "null" if it realizes it is the wrong kind
     * of driver to connect to the given URL.  This will be common, as when
     * the JDBC driver manager is asked to connect to a given URL it passes
     * the URL to each loaded driver in turn.
     *
     * <P>The driver should throw an <code>SQLException</code> if it is the right 
     * driver to connect to the given URL but has trouble connecting to
     * the database.
     *
     * <P>The <code>java.util.Properties</code> argument can be used to pass
     * arbitrary string tag/value pairs as connection arguments.
     * Normally at least "user" and "password" properties should be
     * included in the <code>Properties</code> object.
     *
     * @param url the URL of the database to which to connect
     * @param info a list of arbitrary string tag/value pairs as
     * connection arguments. Normally at least a "user" and
     * "password" property should be included.
     * @return a <code>Connection</code> object that represents a
     *         connection to the URL
     * @exception SQLException if a database access error occurs
     */
    public Connection connect(String url, java.util.Properties info) throws SQLException {

        if (url == null)
            throw new SQLException("URL can not be null...");

        if (!url.startsWith(Constants.URL_PREFIX))
            throw new SQLException("URL does not match...");

        Properties filteredProperties = filterProperties(info);
        
        String aliasName= Constants.getAliasName(url);
        filteredProperties.setProperty(ALIAS_PROPERTY, aliasName);
        
        DALUrl dalurl = new DALUrl(url, aliasName, filteredProperties.getProperty(USER_PROPERTY), filteredProperties.getProperty(PASSWORD_PROPERTY));
        return new DALConnection(dalurl);
            
    }

    /**
     * Retrieves whether the driver thinks that it can open a connection
     * to the given URL.  Typically drivers will return <code>true</code> if they
     * understand the subprotocol specified in the URL and <code>false</code> if
     * they do not.
     *
     * @param url the URL of the database
     * @return <code>true</code> if this driver understands the given URL;
     *         <code>false</code> otherwise  
     * @exception SQLException if a database access error occurs
     */
    public synchronized boolean acceptsURL(String url) throws SQLException {
        if (url == null || url.length() == 0)
            throw new SQLException("URL can not be null...");

        if (!url.startsWith(Constants.URL_PREFIX))
          return false;

        return true;
    }


    /**
     * Gets information about the possible properties for this driver.
     * <P>
     * The <code>getPropertyInfo</code> method is intended to allow a generic 
     * GUI tool to discover what properties it should prompt 
     * a human for in order to get 
     * enough information to connect to a database.  Note that depending on
     * the values the human has supplied so far, additional values may become
     * necessary, so it may be necessary to iterate though several calls
     * to the <code>getPropertyInfo</code> method.
     *
     * @param url the URL of the database to which to connect
     * @param info a proposed list of tag/value pairs that will be sent on
     *          connect open
     * @return an array of <code>DriverPropertyInfo</code> objects describing 
     *          possible properties.  This array may be an empty array if 
     *          no properties are required.
     * @exception SQLException if a database access error occurs
     */
    public DriverPropertyInfo[] getPropertyInfo(String url, java.util.Properties info)
                         throws SQLException {
        throw new SQLException("Method not implemented");
    }


    /**
     * Retrieves the driver's major version number. Initially this should be 1.
     *
     * @return this driver's major version number
     */
    public int getMajorVersion() {
        return MAJOR_VERSION;
    }

    /**
     * Gets the driver's minor version number. Initially this should be 0.
     * @return this driver's minor version number
     */
    public int getMinorVersion() {
        return MINOR_VERSION;
    }


    /**
     * Reports whether this driver is a genuine JDBC
     * Compliant<sup><font size=-2>TM</font></sup> driver.
     * A driver may only report <code>true</code> here if it passes the JDBC
     * compliance tests; otherwise it is required to return <code>false</code>.
     * <P>
     * JDBC compliance requires full support for the JDBC API and full support
     * for SQL 92 Entry Level.  It is expected that JDBC compliant drivers will
     * be available for all the major commercial databases.
     * <P>
     * This method is not intended to encourage the development of non-JDBC
     * compliant drivers, but is a recognition of the fact that some vendors
     * are interested in using the JDBC API and framework for lightweight
     * databases that do not support full database functionality, or for
     * special databases such as document information retrieval where a SQL
     * implementation may not be feasible.
     * @return <code>true</code> if this driver is JDBC Compliant; <code>false</code>
     *         otherwise
     */
    public boolean jdbcCompliant() {
        return false;
    }

    /**
     * 
     * @param props
     * @return
     */
    protected Properties filterProperties(Properties props) {
      Properties filtered = new Properties();

      if (props == null)
        return filtered;

      // extract only the keys we know
      Iterator iter = driverPropertiesNames.iterator();
      while (iter.hasNext()) {
        String name = (String) iter.next();
        String val = props.getProperty(name);
        if (val == null)
          continue;
        filtered.setProperty(name, val);
      }

      return filtered;
    }

}
