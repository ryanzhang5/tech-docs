package com.wm.dal.jdbc.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import com.wm.dal.jdbc.DALDriver;
import com.wm.sql.DataAccess;
  
import com.wm.corelib.config.AppConfig;

/**
 * Copyright 2009 walmart.com. All rights reserved
 */

/**
 * @author Martin Ma
 * @since 2009-4-16
 * @version 1.0 JDBC Datasource used to generate database connection object.
 */
public class JDBCDataSource implements DataSource {

	private String username;
	private String password;
	private String url;
	private String driverClassName;
	private String accessType;
	private String dsAlias;
	private String propFile;
	private String poolAlias;
	private PrintWriter logWriter;
	private int loginTimeout;

	/** DataSource properties */

	protected static final String USER_PROPERTY = "user";// Driver.USER_PROPERTY;
	protected static final String PASSWORD_PROPERTY = "password";// Driver.PASSWORD_PROPERTY;

	protected static final String ACCESS_TYPE_PURE = "pure";
	protected static final String ACCESS_TYPE_DATAACCESS = "data_access";
	protected static final String ACCESS_TYPE_DAL = "dal_access";
	protected static final String ACCESS_TYPE_JTA = "jta_access";

	public JDBCDataSource() {

	}

	public String getPoolAlias() {
		return poolAlias;
	}

	public void setPoolAlias(String poolAlias) {
		this.poolAlias = poolAlias;
	}

	public PrintWriter getLogWriter() throws SQLException {
		return logWriter;
	}

	public void setLogWriter(PrintWriter out) throws SQLException {
		this.logWriter = out;
	}

	public int getLoginTimeout() throws SQLException {
		return loginTimeout;
	}

	public void setLoginTimeout(int seconds) throws SQLException {
		this.loginTimeout = seconds;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getDriverClassName() {
		return driverClassName;
	}

	public void setDriverClassName(String driverClassName) {
		this.driverClassName = driverClassName;
	}

	public String getAccessType() {
		return accessType;
	}

	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}
	
	public String getDsAlias() {
		return dsAlias;
	}

	public void setDsAlias(String dsAlias) {
		this.dsAlias = dsAlias;
	}
	
	public String getPropFile() {
		return propFile;
	}

	public void setPropFile(String propFile) {
		this.propFile = propFile;
	}

	public Connection getConnection() throws SQLException {
		
		if (propFile == null || "".equals(propFile)) {
			propFile = "/dal.conf";
		}
		return getConnection(propFile);
	}
	
	
	public Connection getConnection(String propFile) throws SQLException {

		Connection con = null;
		if (ACCESS_TYPE_PURE.equals(accessType)) {
			try {
				con = this.getOriginalConnection();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
				throw new SQLException(e.getCause());
			}
		} else if (ACCESS_TYPE_DATAACCESS.equals(accessType)) {
			try {
				con = this.getDataAccessConnection(propFile);
			} catch (IOException e) {
				e.printStackTrace();
				throw new SQLException(e.getCause());
			}
		} else if (ACCESS_TYPE_DAL.equals(accessType)) {
			try {
				con = this.getDALConnection(propFile);
			} catch (InstantiationException e) {
				e.printStackTrace();
				throw new SQLException(e.getCause());
			} catch (IllegalAccessException e) {
				e.printStackTrace();
				throw new SQLException(e.getCause());
			} catch (IOException e) {
				e.printStackTrace();
				throw new SQLException(e.getCause());
			}
		} else if (ACCESS_TYPE_JTA.equals(accessType)) {
			try {
				con = getJTAConnection(propFile);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return con;
	}
	
	
	public Connection getConnection(String username, String password)
			throws SQLException {

		Connection con = null;
		this.username = username;
		this.password = password;
		con = this.getConnection();
		return con;
	}

	private Connection getDataAccessConnection(String propFile) throws SQLException,
			IOException {

		InputStream homeWareInput = JDBCDataSource.class
				.getResourceAsStream(propFile);
		Properties props = new Properties();
		props.load(homeWareInput);
		props.putAll(AppConfig.getInstance().getProperties());
		AppConfig.getInstance().setProperties(props);
		Connection con = DataAccess.getInstance().getConnection(poolAlias);
		// con.setAutoCommit(false);

		// return LoggingProxy.getProxy(con,
		// Connection.class,
		// CallableStatement.class,
		// PreparedStatement.class,
		// Statement.class,
		// ResultSet.class,
		// DatabaseMetaData.class,
		// ResultSetMetaData.class,
		// ParameterMetaData.class
		// );
		return con;
	}
	
	private Connection getOriginalConnection() throws SQLException,
			ClassNotFoundException {

		Connection con = null;
		Class.forName(driverClassName);
		con = DriverManager.getConnection(url, username, password);
		con.setAutoCommit(false);
		return con;
	}

	private Connection getDALConnection(String propFile) throws InstantiationException,
			IllegalAccessException, IOException, SQLException {
	
		InputStream homeWareInput = JDBCDataSource.class.getResourceAsStream(propFile);
		AppConfig.getInstance().getProperties().load(homeWareInput);

		Properties props = new Properties();
		props.put(USER_PROPERTY, username);
		props.put(PASSWORD_PROPERTY, password);
		return new DALDriver().connect(url, props);		
		
	}
	
	private Connection getJTAConnection(String propFile) throws IOException, SQLException {
		
		AppConfig.getInstance().getProperties().load(this.getClass().getResourceAsStream(propFile));
		Connection con = null;
		con = DataAccess.getInstance().getConnection(this.dsAlias);
		return con;
	}

	public java.lang.Object unwrap(java.lang.Class arg0)
			throws java.sql.SQLException {
		return null;
	}

	public boolean isWrapperFor(java.lang.Class arg0)
			throws java.sql.SQLException {
		return false;
	}
}


