package com.wm.dal.jdbc.beans;

import java.io.Serializable;

public class SecurityRuleFieldBean implements Serializable {

	public final static String SEPERATOR = ",";
	
	public SecurityRuleFieldBean() {
		
	}
	
	public SecurityRuleFieldBean(int envRouterId, String fieldName, String fieldValue) {
		
		this.envRouterId = envRouterId;
		this.fieldName = fieldName;
		this.fieldValue = fieldValue;
	}
	
	public int getEnvRouterId() {
		return envRouterId;
	}

	public void setEnvRouterId(int envRouterId) {
		this.envRouterId = envRouterId;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}

	public String packKey() {

		return envRouterId + SEPERATOR + fieldName;
	}

	public void unpackKey(String key) {

		if (key != null && !"".equals(key)) {
			String[] keyStr = key.split(SEPERATOR);
			envRouterId = Integer.valueOf(keyStr[0]);
			fieldName = keyStr[1];
		}
	}

	private int envRouterId;
	private String fieldName;
	private String fieldValue;
}
