package com.wm.dal.jmx;

import com.wm.corelib.jmxadmin.WmtMBeanImpl;
import com.wm.dal.util.ServerConf;

import javax.management.NotCompliantMBeanException;
  
import com.wm.corelib.config.AppConfig;

public class DALConfig extends WmtMBeanImpl implements DALConfigMBean {

    private String _theMessage = null;
    private int _logLevel;
    private int _maxThreads;

    public DALConfig() throws NotCompliantMBeanException {
        super(DALConfigMBean.class);
       _theMessage= "DALConfig implements DALConfigMBean";
    }

    public void setMessage (String theMessage) {
        this._theMessage = theMessage;
    }

    public String getMessage() {
        return _theMessage;
    }

    public void setLastInitialization(String s) {
	//to be implemented
    }

    public String getLastInitialization() {
	// to be implemented
	return null;
    }
    // LogLevel Attr
    public int getLogLevel() {
        _logLevel = ServerConf.getLogLevel();
        return _logLevel;
    }

    public void setLogLevel(int theLogLevel) {
        AppConfig.getInstance().setProperty(ServerConf.LOG_LEVEL, (new Integer(theLogLevel)).toString());
        ServerConf.setLogParameters(ServerConf.getLogLevel(),"DAL Log:");
        _logLevel = theLogLevel;
    }

    // MaxThreads Attr
    public int  getMaxThreads() {
        _maxThreads = ServerConf.getMaxIOWorkerThreadCount();
        return _maxThreads;
    }

    // Port Attr
    public int getPort() {
        return ServerConf.getPort();
    }

    // ConsolePort Attr
    public int getHttpPort() {
        return ServerConf.getHttpPort();
    }

    /////////////////////////
    // Operations
    /////////////////////////
    public void modifyLogLevel(int logLevel) {
       setLogLevel(logLevel);
    }

}
