package com.wm.dal.jmx;

import com.wm.corelib.annotation.Description;
import com.wm.corelib.annotation.PName;
import com.wm.corelib.jmxadmin.WmtMBean;

public interface DALConfigMBean extends WmtMBean {

    public int getLogLevel();
    public void setLogLevel(int theLogLevel) ;
    public int  getMaxThreads() ;
    public int getPort();
    public int getHttpPort();
    
    @Description("Log Level ")
    public void modifyLogLevel(@PName("Log Level") int theLogLevel);

}
