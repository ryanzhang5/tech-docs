/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 */

package com.wm.dal.server.nio;
  
import com.wm.corelib.config.AppConfig;

/**
 * 
 * @author cshah
 */
public class NIOConf {

    private static final String NIO_READ_SELECTOR   = "com.wm.nio.read.selector";
    private static final String NIO_WRITE_SELECTOR   = "com.wm.nio.write.selector";
    private static final String NIO_BUFFER_SIZE   = "com.wm.nio.buffer.size";
    private static final String NIO_TIMEOUT = "com.wm.nio.connection_timeout";
    public static final boolean ALLOCATE_DIRECT = false;

    /**
     * 
     * @return
     */
    public static final int getReadSelector() {
      int rv = 5;
      try {
        rv = Integer.parseInt( AppConfig.getInstance().getProperty( NIO_READ_SELECTOR ) );
      } catch ( Exception e ) {
        System.err.println( "Using default Read Selector: " + rv );
      }
      return rv;
    }

    /**
     * @return
     */
    public static final int getWriteSelector() {
      int rv = 10;
      try {
        rv = Integer.parseInt( AppConfig.getInstance().getProperty( NIO_WRITE_SELECTOR ) );
      } catch ( Exception e ) {
        System.err.println( "Using default Write Selector: " + rv );
      }
      return rv;
    }

    /**
     * @return
     */
    public static final int getBufferSize() {
      int rv = 8192 * 8;
      try {
        rv = Integer.parseInt( AppConfig.getInstance().getProperty( NIO_BUFFER_SIZE ) );
      } catch ( Exception e ) {
        System.err.println( "Using default Buffer Size : " + rv );
      }
      return rv;
    }

    /**
     * @return
     */
    public static final int getConnectionTimeout() {
      int rv = 30000; // default
      try {
        rv = Integer.parseInt( AppConfig.getInstance().getProperty( NIO_TIMEOUT  ) ) * 1000;
      } catch ( Exception ignore ) {;}
      return rv;
    }

}
