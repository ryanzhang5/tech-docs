/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 */

package com.wm.dal.server.nio;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author cshah
 */
public class DispatcherPool {

    private int loopCount = 0;
    private int totalDispatcher = 0;
    private final List<Dispatcher> dispatcherList = new ArrayList<Dispatcher>();
    private final Object gate = new Object();

    /**
     * Constructor
     * @param dispatcherCount -- int dispatcher count
     * @param threadName -- Thread Name
     */
    public DispatcherPool(int dispatcherCount, String threadName)  {
        if (dispatcherCount <= 0)
            dispatcherCount = 1;
    try {
        for (int i=0; i < dispatcherCount; i++) {
            Dispatcher dispatcher = new Dispatcher();
            dispatcherList.add(dispatcher);
            totalDispatcher = dispatcherList.size();
            Thread tt = new Thread(dispatcher);
            tt.setName(threadName + "-thread-" + i);
            tt.start();
        }
    } catch (Exception exp) {exp.printStackTrace();}
    }

    /**
     * Get next Dispatcher
     * @return -- Dispatcher
     */
    public Dispatcher nextDispatcher() {
        Dispatcher dd = null;
            synchronized (gate) {
                if (loopCount == totalDispatcher) {
                    loopCount = 0;
                }
                dd = dispatcherList.get(loopCount++);
            }
        return dd;
    }

}


