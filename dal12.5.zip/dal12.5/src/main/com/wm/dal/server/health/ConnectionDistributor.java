package com.wm.dal.server.health;


import com.bitmechanic.sql.GenericPool;

import com.wm.sql.DataAccess;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.TimerTask;
import java.util.logging.Logger;
  
import com.wm.corelib.config.AppConfig;

public class ConnectionDistributor extends TimerTask {
    private boolean isRunning  = false;
    protected static final Logger logger = Logger.getLogger(ConnectionDistributor.class.getName());
    private IActiveServers activeServers = null;//new HttpActiveServers();
    private static final String IS_ENABLED = "com.wm.dal.conn.lb.enabled";
    private static final String POOL_ALIAS = "com.wm.sql.dataaccess.aliases";
    private static final String ALGO_CLASS = "com.wm.dal.conn.lb.algorithm";

    public ConnectionDistributor() {
        try {
        Class clazz = Class.forName(AppConfig.getInstance().getProperty(ALGO_CLASS));
        Object obj = clazz.newInstance();
            if (obj instanceof IActiveServers)
                    activeServers = (IActiveServers)obj;
        } catch (Exception exp) {
                exp.printStackTrace();
        }
    }

    public void run() {
        String isEnabled = AppConfig.getInstance().getProperty(IS_ENABLED, "false");
        if (activeServers == null) {
                return;
        }
        
        if ("true".equals(isEnabled)) {
        if (isRunning) {
                logger.info("Connection re-loadbalancing algorithm is still in progress");
        } else {
            try {
            	isRunning = true;
                float totalPercentile = activeServers.getAndCheckServerCount();
                calculateMaxConnection(totalPercentile);
            } catch (Exception exp) {
                exp.printStackTrace();
            } finally {
            	isRunning = false;
            }
        }
        }//if
    }
    
    /**
     *
     * @param totalPercentile
     */
    private void calculateMaxConnection(float totalPercentile) {
        logger.warning("Connection LB Algorithm found Total Percentile :" + totalPercentile);

        if (totalPercentile == 0) {
            return;
        }

        Map<String,Integer> poolNameMap = getMaxSizeConfigurations();
        Iterator<Map.Entry<String, Integer>> iterator = poolNameMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, Integer> entry = iterator.next();
            String poolName = entry.getKey();
            try {
                    GenericPool[] genericPoolArray = DataAccess.getInstance().getGenericPool(poolName);
                    for (GenericPool genericPool : genericPoolArray ) {
                        if (genericPool != null && totalPercentile > 0) {
                            int newMaxConn = (int) (entry.getValue() * totalPercentile);
                            logger.warning("Setting new Max Connection for Connection Pool : " + poolName 
                            		+ " Old Max Value:" + genericPool.getMaxSize() + ", New Max Value:"
                            		+ newMaxConn);
                            if (newMaxConn > 0) {
                                genericPool.setMaxSize(newMaxConn);
                            }
                        }
                    }
            } catch (Exception exp) {
                exp.printStackTrace();
            }
        }
    }

    // we are fetching it everytime - to allow manual override, as appropriate.
    private Map<String,Integer> getMaxSizeConfigurations() {
        Map<String,Integer> poolNameMap = new HashMap<String,Integer>();

        String poolNames = AppConfig.getInstance().getProperty(POOL_ALIAS,"");
        StringTokenizer st = new StringTokenizer(poolNames, ",");
        while (st.hasMoreTokens()) {
            String poolName = st.nextToken();
            String smaxSize = AppConfig.getInstance().getProperty("com.wm.sql.dataaccess." +  poolName + ".maxconn");
            Integer maxSize = 0;
            try {
                maxSize = Integer.parseInt(smaxSize);
            } catch (Exception exp){
                exp.printStackTrace();
                }
            poolNameMap.put(poolName, maxSize);
        }

        return poolNameMap;
    }

}
