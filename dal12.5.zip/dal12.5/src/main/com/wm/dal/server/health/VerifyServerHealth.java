package com.wm.dal.server.health;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.Callable;
import java.util.logging.Logger;
  
import com.wm.corelib.config.AppConfig;

/**
 * Verify the remote dal server is alive or not.
 * @author mma
 * @version 1.0
 */
public class VerifyServerHealth implements Callable {
	
	private static final Logger logger = Logger.getLogger(VerifyServerHealth.class.getName());
	private static final String PORT = "dal.http.server.port";
	
    private String serverName;
    private String urlAddress;
    
    public VerifyServerHealth(String serverName) {
        this.serverName = serverName;
        String port = AppConfig.getInstance().getProperty(PORT);
        urlAddress = "http://" + serverName + ":" + port + "/verify.jsp";
    }
    
    public Boolean call() {
    	
    	Boolean result = new Boolean(false);
    	if (checkIsAlive() == true) {
    		result = new Boolean(true);
    	}
        return result;
    }
    
    /**
     * Check remote host is alive or not.
     * @param hostName Remote host name
     * @return true, is alive; false, is not alive
     */
    public boolean checkIsAlive() {
    	
    	boolean isAlive = false;
    	HttpURLConnection connection = null;
    	try {
			URL url = new URL(urlAddress);
			connection = (HttpURLConnection)url.openConnection();
			int statusCode = connection.getResponseCode();
			if (statusCode == HttpURLConnection.HTTP_OK) {
				//Status code is 200
				isAlive = true;
			}
		} catch (MalformedURLException ex) {
			logger.warning("DAL VERIFY SERVER HEALTH ERROR:[" + serverName +  "]; "+ ex.getMessage());
			//ex.printStackTrace();
		} catch (IOException ex) {
			logger.warning("DAL VERIFY SERVER HEALTH ERROR:[" + serverName +  "]; "+ ex.getMessage());
			//ex.printStackTrace();
		} catch (Exception ex) {
			logger.warning("DAL VERIFY SERVER HEALTH OTHER ERROR:[" + serverName +  "]; "+ ex.getMessage());
			//ex.printStackTrace();
		} finally {
			try {
				if (connection != null) {
					connection.disconnect();
				}
			} catch (Exception ex) {
				logger.warning("DAL VERIFY SERVER HEALTH OTHER ERROR: " + ex.getMessage());
			}
		}
    	return isAlive;
    	
    }
}
