/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 */

package com.wm.dal.server.nio;

import com.wm.dal.util.DALLogger;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;

/**
 * 
 * @author cshah
 */
final class ChannelIO {

    private SocketChannel socketChannel;
    private ByteBuffer requestBB;
    private static int requestBBSize = NIOConf.getBufferSize();
    private static final int MAX_ATTEMPTS = 5;
    private static final DALLogger  logger = DALLogger.getInstance();
    
    /**
     * Static Method
     * @param sc -- Socket Channel
     * @param blocking -- is Blocking
     * @return -- ChannelIO
     * @throws IOException -- Exception
     */
    static ChannelIO getInstance(SocketChannel sc, boolean blocking) throws IOException {
	ChannelIO cio = new ChannelIO(sc, blocking);
	cio.requestBB =  ( NIOConf.ALLOCATE_DIRECT ? ByteBuffer.allocateDirect(requestBBSize)  : ByteBuffer.allocate(requestBBSize)) ;
	return cio;
    }

    /**
     * Constructor
     * @param sc -- Socket Channel
     * @param blocking -- is Blocking true/false
     * @throws IOException -- Exception
     */
    protected ChannelIO(SocketChannel sc, boolean blocking) throws IOException {
    	try {
        this.socketChannel = sc;
        sc.configureBlocking(blocking);
        sc.socket().setTcpNoDelay( true );
	} catch (IOException ioexp) {
		//ioexp.printStackTrace();
		throw ioexp;
	} catch (Exception exp) {
		exp.printStackTrace();
	}
    }

    /**
     * Socket Channel
     * @return -- Socket Channel
     */
    protected SocketChannel getSocketChannel() {
	return socketChannel;
    }

    /**
     * Return a ByteBuffer with "remaining" space to work.  If you have to
     * reallocate the ByteBuffer, copy the existing info into the new buffer.
     * @param remaining
     */
    protected void resizeRequestBB(int remaining) {
	if (requestBB.remaining() < remaining) {
	    // Expand buffer for large request
	    ByteBuffer bb =  ( NIOConf.ALLOCATE_DIRECT ? ByteBuffer.allocateDirect(requestBB.capacity() * 2)  : ByteBuffer.allocate(requestBB.capacity() * 2) );
	    requestBB.flip();
	    bb.put(requestBB);
	    requestBB = bb;
	}
    }

    /**
     * Resize (if necessary) the inbound data buffer, and then read more
     * data into the read buffer.
     * @return -- Bytes read
     * @throws IOException -- Exception
     */
    int read() throws Exception {
    	int readSize = -1;
        //Allocate more space if less than 5% remains
        try {
	resizeRequestBB(requestBBSize/20);
	readSize = socketChannel.read(requestBB);
	} catch (IOException ioexp) {
		//ioexp.printStackTrace();
		throw ioexp;
	} catch (Exception exp) {
		//exp.printStackTrace();		
		throw exp;
	}
        return readSize;
    }

    /**
     * All data has been read, pass back the request in one buffer.
     * @return -- Bytebuffer
     */
    ByteBuffer getReadBuf() {
	return requestBB;
    }

    /**
     * Write the src buffer into the socket channel.
     * @param src -- Byte Buffer
     * @return -- Total Bytes written
     * @throws IOException -- Exception
     */
    int write(ByteBuffer src) throws Exception {
       logger.log(logger.LEVEL_INFO, "in write src buffer " + src.limit() );    
       int totalwrite = 0;
       int attempts = 0;
       Selector writeSelector = null;
       try {
       if (src == null)
        return totalwrite;

        while (src.hasRemaining()) {
              int len = socketChannel.write(src);
              attempts++;
              totalwrite += len;
                if (len == 0) {
                    if ( writeSelector == null || !writeSelector.isOpen()) {
                        writeSelector = Selector.open();
                        logger.log(logger.LEVEL_INFO, "New Write Selector Open " +  writeSelector);
                    }
                        SelectionKey key =socketChannel.register(writeSelector, SelectionKey.OP_WRITE);
                            if (writeSelector.select(NIOConf.getConnectionTimeout()) == 0) {
                                    if (attempts > MAX_ATTEMPTS) {
                                        writeSelector.close();
                                        throw new IOException("Client disconnected");
                                    }
                            } else {
                                attempts--;
                            }
                } else {
                    attempts = 0;
                }
        }//while
        } catch (IOException ioexp) {
                //ioexp.printStackTrace();
                throw ioexp;
        } catch (Exception exp) {
                //exp.printStackTrace();
                throw exp;
        } finally {
                if (writeSelector != null) {
                    writeSelector.close();
                    writeSelector = null;
                }
        } //finally
        return totalwrite;
    }

/*
    int write(ByteBuffer src) throws Exception {
       int totalwrite = 0;
       int attempts = 0;
       Selector writeSelector = null;
       try {
       if (src == null)
        return totalwrite;
        
        while (src.hasRemaining()) {
              int len = _socketChannel.write(src);
              attempts++;
              totalwrite += len;
                if (len == 0) {
                    if ( writeSelector == null || !writeSelector.isOpen()) {
                        writeSelector = SelectorFactory.getSelector();
                        if ( writeSelector == null){
                            // Continue using the main one.
                            continue;
                        }
                        //writeSelector = Selector.open();
                    }
                        SelectionKey key =_socketChannel.register(writeSelector, SelectionKey.OP_WRITE);
                            if (writeSelector.select(NIOConf.getConnectionTimeout()) == 0) {
                                    if (attempts > MAX_ATTEMPTS) {
                                        writeSelector.close();
                                        throw new IOException("Client disconnected");
                                    }
                            } else {
                                attempts--;
                            }
                } else {
                    attempts = 0;
                }
        }//while

	} catch (IOException ioexp) {
		ioexp.printStackTrace();
		throw ioexp;
	} catch (Exception exp) {
		exp.printStackTrace();		
		throw exp;
	} finally {
        if (writeSelector != null) {
            writeSelector.selectNow();
            SelectorFactory.returnSelector(writeSelector);        
            //writeSelector.close();
            //writeSelector = null;
        }
	} //finally
        return totalwrite;        
    }
*/
    /**
     * Perform a FileChannel.TransferTo on the socket channel. 
     * @param fc -- FileChannel
     * @param pos -- Position
     * @param len -- Length
     * @return -- Long
     * @throws IOException -- Exception
     */
    long transferTo(FileChannel fc, long pos, long len) throws IOException {
	return fc.transferTo(pos, len, socketChannel);
    }

    /*
     * Start any connection shutdown processing.
     * <P>
     * This isn't really necessary for the insecure variant, but needed
     * for the secure one where intermediate buffering must take place.
     * <P>
     * Return true if successful, and the data has been flushed.
     */
//    boolean shutdown() throws IOException {
//	return true;
//    }

    /**
     * Close the underlying connection. 
     * @throws IOException -- Exception
     */
    void close() throws IOException {
        try {
            if (socketChannel != null && socketChannel.socket() != null) {
                socketChannel.socket().shutdownInput();
                socketChannel.socket().shutdownOutput();
                socketChannel.close();
            }
        } catch (Exception exp) {;}
            try {
                if ( requestBB != null) {
                    requestBB.clear();
                    requestBB = null;
                }
                socketChannel = null;
            } catch (Exception exp){;}
    }

    /**
     * 
     */
    public void clearRead() {  
        if (requestBB != null) {
            requestBB.clear();
        }
    }
}


