/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 */

package com.wm.dal.server.http;

import com.wm.dal.util.DALLogger;

import com.wm.dal.util.ServerConf;

import org.mortbay.jetty.Connector;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.nio.SelectChannelConnector;
import org.mortbay.jetty.webapp.WebAppContext;
import org.mortbay.thread.QueuedThreadPool;



/**
 * 
 * @author cshah
 */
public class HttpServer {
    private int port = 1730;
    private String resourceBase = ".";
    private static final DALLogger logger = DALLogger.getInstance();

    /**
     * 
     * @param port
     * @param resourceBase
     */
    public HttpServer(int port, String resourceBase) {
        if (port > 0) {
            this.port = port;
        }
        this.resourceBase = resourceBase;
    }

    /**
     * 
     */
    public synchronized void startServer() {
        try {
        Server server = new Server();
            
        Connector connector=new SelectChannelConnector();
        connector.setHost(ServerConf.getHostName());
        connector.setPort(port);
        server.setConnectors(new Connector[]{connector});
        //server.setThreadPool(new QueuedThreadPool(10));
        WebAppContext webapp = new WebAppContext();
        webapp.setContextPath("/");
        //webapp.setContextPath(resourceBase);
        webapp.setWar(resourceBase);
        //webapp.setDefaultsDescriptor(resourceBase+"/web.xml");
            
        server.setHandler(webapp);
        server.start();
//        server.join();        
        logger.warning("DAL Http Server is running on port " + port);
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }    
}
