/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 */

package com.wm.dal.server.nio;

import com.wm.dal.client.DALResponse;
import com.wm.dal.client.IDALRequest;
import com.wm.dal.client.IDALResponse;
import com.wm.dal.common.ConnectionDelegate;
import com.wm.dal.server.ThreadPoolManager;
import com.wm.dal.util.DALLogger;

import com.wm.dal.util.ServerUtil;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import java.net.Socket;

import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;

import java.util.Date;


/**
 * 
 * @author cshah
 */
public final class RequestHandler implements Handler, Runnable {
    private ChannelIO channelIO;
    private boolean shouldCloseConnection = false;
    private ByteBuffer requestBuffer = null;
    private ByteBuffer responseBuffer = null;
    protected boolean inProcess = false;
    private boolean inConnectionAborted = false;
    private static final DALLogger  logger = DALLogger.getInstance();
    private long startTime = System.currentTimeMillis();
    private ConnectionDelegate delegate = new ConnectionDelegate();
    private static final DispatcherPool writeDispatcherPool = new DispatcherPool(NIOConf.getWriteSelector(), "Write Dispatcher");

    private String hostName = null;
    private IDALRequest request;
    
    /**
     * 
     * @param cio
     */
    RequestHandler(ChannelIO cio) {
	this.channelIO = cio;
        try {
            hostName = ServerUtil.getHostNameFromSocket(getSocket());
        } catch (Exception exp) {;}
    }

    /**
     * @return
     */
    public Socket getSocket() {
        if ( channelIO.getSocketChannel() != null)
            return channelIO.getSocketChannel().socket();
        return null;            
    }

    /**
     * @return
     */
    public String getRemoteHostName() {
        return hostName;
    }    

    /**
     * 
     * @param sk
     * @throws Exception
     */
    private void receive(SelectionKey sk) throws Exception {
        logger.log(DALLogger.LEVEL_INFO, "In Receive");
	try {
         int totalread = -1;
            try {
                totalread =channelIO.read();
            } catch (IOException exp) {
                sk.cancel();
                sk.attach(null);
                exp.printStackTrace();
                channelIO.close();
                shouldCloseConnection = true;
                return;
            } catch (Exception exp) {
                sk.cancel();
                sk.attach(null);
	        channelIO.close();
                exp.printStackTrace();
                shouldCloseConnection = true;
                return;
	    }
         
        if (totalread < 0 ) {
            shouldCloseConnection = true;
            return;
        }
        
        //totalread > 0  && 
        if (TransportUtil.isComplete(channelIO.getReadBuf())) {
            requestBuffer = channelIO.getReadBuf();
	    requestBuffer.flip();
	    process(sk);
	}
	} catch (IOException ioexp) {
	    shouldCloseConnection = true;
		//ioexp.printStackTrace();
		throw ioexp;
	} catch (Exception exp) {
	    shouldCloseConnection = true;
		//exp.printStackTrace();
                throw exp;
	}
    }

    /**
     * 
     * @param sk
     * @throws Exception
     */
    private void process(SelectionKey sk) throws Exception {
        Exception exception = null;
	try {
            sk.interestOps(sk.interestOps() & (~SelectionKey.OP_READ));
	    sk.attach(null);
            sk.cancel();
        } catch (Exception x) {
            x.printStackTrace();
            exception = new Exception(x.getMessage());
        }
        
        if (inConnectionAborted) {
            resetALL(sk);
            return;
        }
        
        //processing now     
        inProcess = true;
        startTime = System.currentTimeMillis() ;
            try  {
                //System.out.println("posotion " + getRequestBuffer().position() + ":" + getRequestBuffer().capacity() +":" + getRequestBuffer().limit()
                //    + ":" + getRequestBuffer().remaining());
                this.request = TransportUtil.readDALRequest(getRequestBuffer());
            } catch ( Exception ee ) {
               logger.warning("Exception From DAL..");    
               ServerUtil.printDALBench(request, startTime);
               ee.printStackTrace();
               exception = ee;
             } 
             
        if ( exception != null ) {
            ByteBuffer responseBB = null;
            try {
                ByteArrayOutputStream os = new ByteArrayOutputStream();
                ObjectOutputStream oos = new ObjectOutputStream(os);
            
                IDALResponse response = new DALResponse();
                response.setException(exception);
                oos.writeObject(response);
            
             responseBB= ByteBuffer.wrap(os.toByteArray());
             if (responseBB != null) {
                responseBB.flip();
             }
                try { 
                    os.close(); 
                } catch (Exception ee) { 
                    ee.printStackTrace();
                }

            } catch (Exception ignoreexp) {;
                //any other exception just ignore this and finally write data back to the client
                //or set the write flag
            } finally {
                setReply(responseBB);
            }
        } else { //if exception != null
                ThreadPoolManager.getInstance().getWMThreadPoolExecutor().execute(this);
        } //else
        
    }

    /**
     * 
     * @param sk
     * @throws Exception
     */
    public void handle(SelectionKey sk) throws Exception {
	try {
	    logger.log(DALLogger.LEVEL_INFO, "In Handle " + shouldCloseConnection);
	    if (shouldCloseConnection) {
	        resetALL(sk);
                return;
	    }        
            
            if (sk.isValid() && sk.interestOps() == SelectionKey.OP_READ ) {
                receive(sk);
            } else if (sk.isValid() && sk.interestOps() == SelectionKey.OP_WRITE ) {
	        send(sk);
	    }
	} catch (IOException x) {
	    logger.warning("Exception From DAL..");    
	    ServerUtil.printDALBench(request, startTime);
	    x.printStackTrace();
	    resetALL(sk);
	} catch (Exception ex) {
            logger.warning("Exception From DAL..");    
            ServerUtil.printDALBench(request, startTime);
            ex.printStackTrace();
            resetALL(sk);
        }
        
    }

    /**
     * 
     * @param sk
     * @throws Exception
     */
    private void send(SelectionKey sk) throws Exception {
        if (inConnectionAborted)
            return;
            
	try {
            logger.log(logger.LEVEL_INFO, "in send start:" + new Date());
            channelIO.write(responseBuffer);
            sk.interestOps(sk.interestOps() & (~SelectionKey.OP_WRITE));
            sk.attach(null);
            sk.cancel();

            //if (request.getCaller() == Constants.CONNECTION && request.getCommand() == Constants.CLOSE_CONNECTION) {
            //    _channelIO.close();
	    logger.log(logger.LEVEL_INFO, "in send end: " + new Date());
	} catch (Exception x) {
	    logger.warning("Exception From DAL..");    
	    //ServerUtil.printDALBench(request, startTime);
	    x.printStackTrace();
	    throw x;
	} finally {
            try {
                Acceptor.readDispatcherPool.nextDispatcher().register(
                    channelIO.getSocketChannel(), SelectionKey.OP_READ, this);
            } catch (Exception exp) {exp.printStackTrace();}
            ServerUtil.printDALBench(request, startTime);
            channelIO.clearRead();
            if (requestBuffer != null)
                requestBuffer.clear();
            if (responseBuffer != null)
                responseBuffer.clear();
        }
    }

    /**
     * 
     * @return
     */
    ByteBuffer getRequestBuffer() {
        return requestBuffer;
    }
    
    /**
     * 
     * @param resBB
     */
    public void setReply(ByteBuffer resBB) {
        if ( inConnectionAborted)
            return;
        responseBuffer = resBB;
        try {
            writeDispatcherPool.nextDispatcher().register(channelIO.getSocketChannel(), SelectionKey.OP_WRITE, this);
        } catch (Exception exp) {exp.printStackTrace();}
    }

    /**
     * 
     */
    protected void abortConnection() {
        try {
            ServerUtil.printDALBench(request, startTime);
            inConnectionAborted = true;
            channelIO.close();
        } catch (Exception exp) {exp.printStackTrace();}
    }
    
    /**
     * 
     * @param sk
     */
    private void resetALL(SelectionKey sk) {
        try {
            delegate.forceClose();
        } catch (Exception ignore) { ignore.printStackTrace();}

        try {
            try {
                ServerUtil.printDALBench(request, startTime);
            } catch (Exception ee) {;}
            sk.cancel();
            sk.attach(null);
            channelIO.close();
            if (requestBuffer != null)
                requestBuffer.clear();
            if (responseBuffer != null)
                responseBuffer.clear();
        } catch (Exception ignore) { ignore.printStackTrace();}
    }

    /**
     * 
     * @return
     */
    public IDALRequest getDALRequest() {
        return request;
    }

    /**
     * 
     */
    public void run() {
        try {
            IDALResponse response = delegate.execute(getDALRequest());
            setReply(TransportUtil.createResponseAsByteBuffer(response));
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }    

}
