/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 */

package com.wm.dal.server.nio;

import java.io.IOException;
import java.nio.channels.Selector;

import java.util.Stack;
import java.util.EmptyStackException;

/**
 * 
 * @author cshah
 */
public class SelectorFactory {
    public static long timeout = 50;
    private static final int ATTEMPTS = 5;
    public static int maxSelectors = NIOConf.getWriteSelector();
    private final static Stack<Selector> selectors = new Stack<Selector>();

    static {
        try{
            for (int i = 0; i < maxSelectors; i++) 
                selectors.add(Selector.open());
        } catch (IOException ex){
                ; // do nothing.
        }
    }

    /**
     * 
     * @return
     */
    public final static Selector getSelector() {
        synchronized(selectors) {
            Selector s = null;
                try {
                    if ( selectors.size() != 0 )
                        s = selectors.pop();
                } catch (EmptyStackException ex){;}
                           
                int attempts = 0;
                try{
                    while (s == null && attempts < ATTEMPTS) {
                        selectors.wait(timeout);
                        try {
                            if ( selectors.size() != 0 )
                                s = selectors.pop();
                        } catch (EmptyStackException ex){
                            break;
                        }
                        attempts++;
                    }
                } catch (InterruptedException ex){;}
            return s;
        }
    }

    /**
     * 
     * @param s
     */
    public final static void returnSelector(Selector s) {
        synchronized(selectors) {
            selectors.push(s);
                if (selectors.size() == 1)
                    selectors.notify();
        }
    }

}
