package com.wm.dal.server.health;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.logging.Logger;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import sun.misc.BASE64Encoder;

/**
 * <codeHTTPInvoker</code> is a helper class to make http call to the given url. 
 * @author hvijayakumar
 *
 */
public class HTTPInvoker implements Callable<String>{

	private static final Logger logger = Logger.getLogger(HTTPInvoker.class.getName());
	private String urlStr = null;
	private int connectTimeout = 5000; //default
	private int readTimeout = 5000; //default
	private String userName = null;
	private String password = null;
	
	/**
	 * Constructor with URL to be invoked
	 * @param url - URL String
	 */
	public HTTPInvoker (String url) {
		urlStr = url;
	}
	
	/**
	 * Constructor with URL and Timeout configuration
	 * @param url
	 * @param connectTimeout  connection Time out
	 * @param readTimeout Read time out
	 */
	public HTTPInvoker (String url, int connectTimeout, int readTimeout) {
		urlStr = url;
		this.connectTimeout = connectTimeout;
		this.readTimeout = readTimeout;
	}

	/**
	 * Constructor with URL and Timeout configuration
	 * @param url
	 * @param connectTimeout  connection Time out
	 * @param readTimeout Read time out
	 */
	public HTTPInvoker (String url, int connectTimeout, int readTimeout, String userName, String password) {
		urlStr = url;
		this.connectTimeout = connectTimeout;
		this.readTimeout = readTimeout;
		this.userName = userName;
		this.password = password;
	}
	
	@Override
	public String call() throws Exception {
		String resp = null;
	  HttpURLConnection httpurlconnection = null;

		try{
	        Random rand = new Random();
	        URL url = null;
	        // add random number to avoid cache issue
	        if(urlStr.contains("?")) {
	        	url = new URL((new StringBuilder()).append(urlStr).append("&randomId=").
	                        append(Math.abs(rand.nextInt())).toString());
	        } else {
	        	url = new URL((new StringBuilder()).append(urlStr).append("?randomId=").
                        append(Math.abs(rand.nextInt())).toString());
	        }

	        if(urlStr.contains("https") || urlStr.contains("HTTPS")) {
	        	disableSSLCertificateChecking();
	        	disableHostNameVerification();
		        httpurlconnection = (HttpsURLConnection)url.openConnection();
	        }else{
		        httpurlconnection = (HttpURLConnection)url.openConnection();
	        }
	        httpurlconnection.setRequestProperty("Cookie", "adminAccess_cookie");
	        httpurlconnection.setRequestProperty("Cache-Control", "no-cache");
	        httpurlconnection.setRequestProperty("Pragma", "no-cache");
	        httpurlconnection.setUseCaches(false);
	        httpurlconnection.setDefaultUseCaches(false);
	        httpurlconnection.setDoOutput(true);
	        httpurlconnection.setConnectTimeout(connectTimeout);
	        httpurlconnection.setReadTimeout(readTimeout);
	        if(userName != null && userName.trim().length()>0) {
	            BASE64Encoder enc = new sun.misc.BASE64Encoder();
	            String userpassword = userName + ":" + password;
	            String encodedAuthorization = enc.encode( userpassword.getBytes() );
	            httpurlconnection.setRequestProperty("Authorization", "Basic "+encodedAuthorization);
	        }
	        httpurlconnection.connect();     
	        int responseCode  = httpurlconnection.getResponseCode();
	        BufferedReader in = new BufferedReader(new InputStreamReader(httpurlconnection.getInputStream()));
          StringBuffer strBuff = new StringBuffer();
	        String str = null;
	        do  {
	            if((str = in.readLine()) == null)
	                break;
	            strBuff.append(str);
	        } while(true);
	        if(responseCode == 200) {
	        	resp = strBuff.toString();
	        }
	        in.close();
	        
		} catch (Exception e) {
			logger.warning("Exception occured in pinging netscaler " +e.toString());
    } finally {
      if (httpurlconnection != null) {
        try {
          httpurlconnection.disconnect();
        } catch (Exception e) {
            logger.warning("Exception occured in closing httpconnection " +e.toString());
        }
      }
    }
        
		return resp;
	}
	

	private void disableSSLCertificateChecking(){
		TrustManager[] trustAllCerts = new TrustManager[] {
             new X509TrustManager() {
                 public X509Certificate[] getAcceptedIssuers() {
                     return null;
                 }
                 public void checkClientTrusted(X509Certificate[] certs,
                                                String authType) {
                 }
                 public void checkServerTrusted(X509Certificate[] certs,
                                                String authType) {
                 }
                 public boolean isServerTrusted(java.security.cert.X509Certificate[] certs) {
                     return true;
                 }
          
                 public boolean isClientTrusted( java.security.cert.X509Certificate[] certs) {
                     return true;
                 }
             }
	    };
	 
		try {
	        SSLContext sc = SSLContext.getInstance("SSL");
	        sc.init(null, trustAllCerts, new java.security.SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
         }
         catch (KeyManagementException kme)
         {
             kme.printStackTrace();
         }
         catch (NoSuchAlgorithmException nsae)
         {
             nsae.printStackTrace();
         }
     }

	private void disableHostNameVerification(){
		 HostnameVerifier hv = new HostnameVerifier() {
				@Override
				public boolean verify(String urlHostName, SSLSession session) {
		            logger.fine("URL Host: " + urlHostName + " vs. " + session.getPeerHost());

					return true;
				}
    };
		    
		    HttpsURLConnection.setDefaultHostnameVerifier(hv);
	}
	


}
