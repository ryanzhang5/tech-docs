/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 */

package com.wm.dal.server.nio;

import java.io.IOException;

import java.nio.channels.Selector;
import java.nio.channels.SelectionKey;
import java.nio.channels.SelectableChannel;

import java.util.Iterator;

/**
 * 
 * @author cshah
 */
public class Dispatcher implements Runnable {
    private Selector selector;
    private final Object gate = new Object();
    private boolean isRunning = true;
    /**
     * Constructor
     * @throws IOException -- Exception
     */
    Dispatcher() throws IOException {
        selector = Selector.open();
    }

    /**
     * Run method
     */
    public void run() {
        while (isRunning) {
            try {
                dispatch();
            } catch (IOException x) {
                x.printStackTrace();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * Dispatch method, which iterate through selector and call handle method
     * @throws IOException -- Exception
     */
    private void dispatch() throws IOException {
    	try {
            selector.select();
            for (Iterator i = selector.selectedKeys().iterator(); i.hasNext(); ) {
                SelectionKey sk = (SelectionKey)i.next();
                //System.out.println("Key in dispatcher:" + sk + ":" + sk.interestOps());
                i.remove();
                Handler h = (Handler)sk.attachment();
                if (h != null)
                    h.handle(sk);
            }
	} catch (IOException ioexp) {
		ioexp.printStackTrace();
		throw ioexp;
	} catch (Exception exp) {
		exp.printStackTrace();
	}
        synchronized (gate) { System.currentTimeMillis();}

    }

    /**
     * Register method, which resister selectablechannel to the selector
     * @param ch -- SelectableChannel
     * @param ops -- Operation (Read/Write)
     * @param h -- Handler
     * @throws IOException -- Exception
     */
    public void register(SelectableChannel ch, int ops, Handler h) throws IOException {
	try {
        synchronized (gate) {
            selector.wakeup();
            ch.register(selector, ops, h);
        }
	} catch (IOException ioexp) {
		ioexp.printStackTrace();
		throw ioexp;
	} catch (Exception exp) {
		exp.printStackTrace();
	}
        
    }

/*
    public void close() {
        try {
        selector.selectNow();
        for (Iterator i = selector.selectedKeys().iterator(); i.hasNext(); ) {
            SelectionKey sk = (SelectionKey)i.next();
            //System.out.println("Key in dispatcher:" + sk + ":" + sk.interestOps());
            sk.cancel();
            sk.attach(null);
        }
        } catch (IOException ioexp) {
                ioexp.printStackTrace();
        } catch (Exception exp) {
                exp.printStackTrace();
        }
        synchronized (gate) { }
        isRunning = false;
    }
*/

}

