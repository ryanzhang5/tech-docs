package com.wm.dal.server.health;

public interface IActiveServers {
    public float getAndCheckServerCount() ;
}
