package com.wm.dal.server.health;


import com.wm.corelib.config.AppConfig;

import java.util.logging.Logger;


/**
 * <code>NSNitroApiWrapper</code> is the wrapper class which makes REST call to Netscaler to ping the status
 *  of the server bound to a given vip
 * @author hvijayakumar
 *
 */
public class NSNitroApiWrapper implements IActiveServers {
	private static final Logger logger = Logger.getLogger(NSNitroApiWrapper.class.getName());
  private static final String NS_URL = "dal.ns.url";
  private static final String NS_USER = "dal.ns.user";
  private static final String NS_PASSWORD = "dal.ns.password";
  private static final String NS_LBSERVER = "dal.ns.lbserver";
  private static final int CONN_TIMEOUT = 5000;
  private static final int READ_TIMEOUT = 10000;

  /**
   * 
   */
  public NSNitroApiWrapper() {
  }

  /**
   *
   * @param nsURL
   * @param lbServerName
   * @param userName
   * @param password
   * @return
   */
	private static float getNetScalerBindInformation(String nsURL, String lbServerName, String userName, String password ) {
		
		String url = "http://"+nsURL+"/nitro/v1/stat/lbvserver/"+lbServerName+"?format=xml&view=summary";
		HTTPInvoker invoker = new HTTPInvoker(url,CONN_TIMEOUT,READ_TIMEOUT,userName,password);
		float output = 0;
		try {
			String response = invoker.call();
				if(response != null) {
					output = parseNSQueryResponse(response);
				}
		} catch (Exception e) {
			logger.warning("Exception is pinging netscaler"+ e.getMessage());
		}
		return output;
		
	}

  /**
   *
   * @return
   */
  public float getAndCheckServerCount() {	
    return getNetScalerBindInformation(getURL(), getLBServer(), getUser(), getPassword());
  }
  
  /**
   *
   * @param responseMessage
   * @return
   */
	private static float parseNSQueryResponse(String responseMessage) {
		/* Below is the format of the Nitro API output. Inner Service element corresponds to ach server bound 
		 ....
		<service>
		<service>
		<name>v5.dal12</name>
		<throughput>0</throughput>
		<throughputrate>0</throughputrate>
		<avgsvrttfb>0</avgsvrttfb>
		<primaryipaddress>10.15.97.191</primaryipaddress>
		<primaryport>1729</primaryport>
		<servicetype>TCP</servicetype>
		<state>OUT OF SERVICE</state>
		<totalrequests>0</totalrequests>
		....
		</service>
		</service>
		..
		*/
		String SERVICE_START = "<service>";
		String SERVICE_END = "</service>";
		String NAME_START = "<name>";
		String NAME_END = "</name>";
		String IPADDRESS_START = "<primaryipaddress>";
		String IPADDRESS_END = "</primaryipaddress>";
		String PORT_START = "<primaryport>";
		String PORT_END = "</primaryport>";
		String STATE_START = "<state>";
		String STATE_END = "</state>";
		String TYPE_START = "<type>";
		String TYPE_END = "</type>";		
		int totalUPServers = 0;
    int totalDOWNServers = 0;
	  float totalPercentile = 0.0f;
	 		
    try {
		int startIndex = 0;
		int endIndex = -1;
		startIndex = responseMessage.indexOf(SERVICE_START)+SERVICE_START.length(); //This is outer service tag
		startIndex = responseMessage.indexOf(SERVICE_START,startIndex) ; //This is actual start of Service 
        while(startIndex != -1){
          startIndex = startIndex + + SERVICE_START.length(); //adding to go to end of <service> String
          endIndex = responseMessage.indexOf(SERVICE_END,startIndex); // This is to check 
          String serviceName = null;
          String ipAddress = null;
          String port = null;
          String state = null;
          String type = null;
          int nameStartIndex = responseMessage.indexOf(NAME_START,startIndex);
          if(nameStartIndex != -1 && nameStartIndex < endIndex) {
            nameStartIndex = nameStartIndex + NAME_START.length();
            int nameEndIndex = responseMessage.indexOf(NAME_END,nameStartIndex) ;
            if(nameEndIndex !=-1 && nameEndIndex>nameStartIndex) {
              serviceName = responseMessage.substring(nameStartIndex,nameEndIndex);
            }
          }
          int ipAddressStartIndex = responseMessage.indexOf(IPADDRESS_START,startIndex);
          if(ipAddressStartIndex != -1 && ipAddressStartIndex < endIndex) {
            ipAddressStartIndex = ipAddressStartIndex + IPADDRESS_START.length();
            int ipAddressEndIndex = responseMessage.indexOf(IPADDRESS_END,ipAddressStartIndex);
            if(ipAddressEndIndex !=-1 && ipAddressEndIndex>ipAddressStartIndex) {
              ipAddress = responseMessage.substring(ipAddressStartIndex,ipAddressEndIndex);
            }
          }
          int portStartIndex = responseMessage.indexOf(PORT_START,startIndex);
          if(portStartIndex != -1 && portStartIndex < endIndex) {
            portStartIndex = portStartIndex+PORT_START.length();
            int portEndIndex = responseMessage.indexOf(PORT_END,portStartIndex) ;
            if(portEndIndex !=-1 && portEndIndex>portStartIndex) {
              port = responseMessage.substring(portStartIndex,portEndIndex);
            }
          }
          int typeStartIndex = responseMessage.indexOf(TYPE_START,startIndex);
          if(typeStartIndex != -1 && typeStartIndex < endIndex) {
            typeStartIndex = typeStartIndex+TYPE_START.length();
            int typeEndIndex = responseMessage.indexOf(TYPE_END,typeStartIndex) ;
            if(typeEndIndex !=-1 && typeEndIndex>typeStartIndex) {
              type = responseMessage.substring(typeStartIndex,typeEndIndex);
            }
          }
          int stateStartIndex = responseMessage.indexOf(STATE_START,startIndex);
          if(stateStartIndex != -1 && stateStartIndex < endIndex) {
            stateStartIndex = stateStartIndex + STATE_START.length();
            int stateEndIndex = responseMessage.indexOf(STATE_END,stateStartIndex);
            if(stateEndIndex !=-1 && stateEndIndex>stateStartIndex) {
              state = responseMessage.substring(stateStartIndex,stateEndIndex);
                        if ("UP".equals(state)) {
                            totalUPServers++;    
                        } else if ("DOWN".equals(state)) {
                            totalDOWNServers++;    
                        }
            }
          }
          logger.info("Server Info : " + state + ":" + serviceName + ":" + ipAddress + ":" + port + ":" + type);    
    
          startIndex = responseMessage.indexOf(SERVICE_START,endIndex);
        } //while

    		logger.warning("Netscalar total UP servers:" + totalUPServers + ", total DOWN servers:" + totalDOWNServers);
        
        if (totalUPServers == 0) {
            return totalPercentile;
        }
        
        totalPercentile = (float) (totalUPServers + totalDOWNServers )/ totalUPServers;
    } catch (Exception exp) {
      logger.warning("Exception while parseNSQueryResponse : "+ exp.getMessage());
    }
        return totalPercentile;

	}

  /**
   *
   * @return
   */
  private String getURL() {
      return AppConfig.getInstance().getProperty(NS_URL,"");    
  }
  
  /**
   *
   * @return
   */
  private String getUser() {
      return AppConfig.getInstance().getProperty(NS_USER,"");    
  }

  /**
   *
   * @return
   */
  private String getPassword() {
      return AppConfig.getInstance().getProperty(NS_PASSWORD,"");    
  }

  /**
   *
   * @return
   */
  private String getLBServer() {
      return AppConfig.getInstance().getProperty(NS_LBSERVER,"");    
  }
	
}
