package com.wm.dal.server.health;


import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
  
import com.wm.corelib.config.AppConfig;

public class HttpActiveServers implements IActiveServers {
	
    private static final Logger logger = Logger.getLogger(HttpActiveServers.class.getName());
    private static final List<String> serverList = new ArrayList<String>();
    private static final String DAL_SERVER_LIST = "dal.serverList";
    private static final String SERVER_COUNT = "dal.serverCount";    
    
    /**
     * 
     */
    public HttpActiveServers() {
    	String srvrListStr = AppConfig.getInstance().getProperty(DAL_SERVER_LIST);
    	
//    	if (srvrContStr != null && !"".equals(srvrContStr.trim())) {
//    		try {
//    			serverCount = Integer.parseInt(srvrContStr);
//    		}catch (NumberFormatException ex) {
//    			logger.log(Level.WARNING, "HTTP ACTIVE SERVER ERROR MSG ", ex);
//    		}catch (Exception ex) {
//    			logger.log(Level.WARNING, "HTTP ACTIVE SERVER ERROR MSG ", ex);
//    		}
//    	}
    	
    	if (srvrListStr != null && !"".equals(srvrListStr.trim())) {
	    	try {
		    	if (! (srvrListStr.indexOf(";") < 0)) {
		    		StringTokenizer tokenizer = new StringTokenizer(srvrListStr,";");
		    		while (tokenizer.hasMoreTokens()) {
		    			String srvrElmt = tokenizer.nextToken();
		    			if (srvrElmt != null && !"".equals(srvrElmt)) {
		    				if (srvrElmt.indexOf("[") >= 0 && srvrElmt.indexOf("]") >= 0)
		    					serverList.addAll(getServerList(srvrElmt));
		    				else
		    					serverList.add(srvrElmt);
		    			}
		    		}
		    	}else {
		    		serverList.addAll(getServerList(srvrListStr));
		    	}
	    	}catch (NumberFormatException ex) {
				logger.log(Level.WARNING, "HTTP ACTIVE SERVER ERROR MSG ", ex);
			}catch (Exception ex) {
				logger.log(Level.WARNING, "HTTP ACTIVE SERVER ERROR MSG ", ex);
			}
    	}
    	
    }
    
    /**
     *
     * @return
     */
    public float getAndCheckServerCount(){
        int totalCount = 0;
        float totalPercentile = 0;
        if (serverList.size() == 0) {
                return 0;
            }
        List<FutureTask<Boolean>> ftList = new ArrayList<FutureTask<Boolean>>();
        ExecutorService es = Executors.newFixedThreadPool(serverList.size());
        
        try {
        for (String sName : serverList) {
                VerifyServerHealth serverHealth = new VerifyServerHealth (sName);
                FutureTask<Boolean> ft = new FutureTask<Boolean>(serverHealth);
                ftList.add(ft);
                es.execute(ft);
            }
                es.shutdownNow();
            
            for (FutureTask<Boolean> ft : ftList) {
                try {
                    Boolean object = ft.get(5000, TimeUnit.MILLISECONDS);
                    if (object != null && object.booleanValue()) {
                        totalCount++;
                    }
                    ft.cancel(true);                    
                } catch (Exception exp) {;}
                }
        } catch (Exception exp) {
                exp.printStackTrace();
            }
        
        int totalServers = getTotalServers();
        
        if ((totalCount > totalServers)  || (totalCount == 0) || (totalServers == 0) ) {
            return totalPercentile;
        }
        
        return (float) totalServers / totalCount;
    }
    
    /**
     *
     * @param serverListStr
     * @return
     */
    public List<String> getServerList(String serverListStr) {
		
    	List<String> srvrList = new ArrayList<String> ();
		/*
		 * Fo example: ndc-v[1-5]-dal[1-4].walmart.com
		 * seqVal[0] represents 1; seqVal[1] represents 5
		 * seqVal[2] represents 1; seqVal[3] represents 4
		 */
		int[] seqVal = new int[4];
		Pattern pattern = Pattern.compile("\\d+");
		Matcher matcher = pattern.matcher(serverListStr);
		int i = 0;
		while (matcher.find()) {
			String srvrElmt = matcher.group();
			if (srvrElmt != null && !"".equals(srvrElmt.trim())) {
				seqVal[i] = Integer.parseInt(srvrElmt);
			}
			i++;
		}
		for (int j=seqVal[2]; j <= seqVal[3]; j++) {
			for (int k=seqVal[0]; k<=seqVal[1]; k++) {
				String srvrName = serverListStr.trim().substring(0,3)+"-v" + k + "-dal" + j + ".walmart.com";
				srvrList.add(srvrName);
			}
		}
		return srvrList;
	}
    
    /**
     *
     * @return
     */
    private int getTotalServers() {
        String serverCount = AppConfig.getInstance().getProperty(SERVER_COUNT);
        int totalServers = 0;
        try {
            totalServers = Integer.valueOf(serverCount);
        } catch (Exception exp) {
            totalServers =0;
        }
        return totalServers;
    }
}
