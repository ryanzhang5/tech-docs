/*
 * Copyright 2009 Walmart.com. All rights reserved.
 */
package com.wm.dal.dao;

/**
 * Base class (recommended) for all data objects
 *
 * @author mkishore
 * @version $Revision: 1.2 $
 * @since 4/2009
 */
public class BaseDO implements IBaseDO {

}
