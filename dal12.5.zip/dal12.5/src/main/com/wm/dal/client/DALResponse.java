/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.client;

import java.io.Serializable;

/**
 * @author cshah
 * @version 1.0
 */
public class DALResponse implements IDALResponse,Serializable {
    private Exception exception = null;
    private ICallerResponse connectionResponse = new CallerResponse();
    private ICallerResponse statementResponse = new CallerResponse();
    private ICallerResponse resultSetResponse = new CallerResponse();
    private String serverHost = null;
    private String poolName = null;
    
    /**
     * 
     */
    public DALResponse() {
    }

    /**
     * @return
     */
    public Exception getException(){
        return exception;
    }

    /**
     * @param exp
     */
    public void setException(Exception exp){
        this.exception = exp;
    }

    /**
     * @return
     */
    public ICallerResponse getConnectionResponse() {
        return connectionResponse;
    }

    /**
     * @return
     */
    public ICallerResponse getStatementResponse() {
        return statementResponse;
    }

    /**
     * @return
     */
    public ICallerResponse getResultSetResponse() {
        return resultSetResponse;
    }

    /**
     * 
     * @param serverHost
     */
    public void setServerHost(String serverHost) {
        this.serverHost = serverHost;
    }

    /**
     * 
     * @return
     */
    public String getServerHost() {
        return serverHost;
    }

    /**
     * Set the name of the pool that ultimately served the request.
     *
     * @param poolName - name of a database connection pool
     */
    public void setPoolName(String poolName) {
        this.poolName = poolName;
    }

    /**
     * Return the name of the pool that ultimately served the request.
     *
     * @return the name of the pool that ultimately served the request
     */
    public String getPoolName() {
        return poolName;
    }
}
