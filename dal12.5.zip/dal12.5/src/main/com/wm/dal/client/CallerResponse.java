/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.client;

import java.io.Serializable;

import java.util.HashMap;
import java.util.Map;

/**
 * @author cshah
 * @version 1.0
 */
public class CallerResponse implements ICallerResponse, Serializable {
    private Map<String, Serializable> returnMap = new HashMap<String, Serializable>();
    private int ID  = 0;

    /**
     * 
     */
    public CallerResponse() {
    }


    /**
     * @param key
     * @param object
     */
    public void set(String key, Serializable object){
        if (key == null)
            return;
        returnMap.put(key,object);
    }

    /**
     * @param key
     * @return
     */
    public Serializable get(String key){
        return returnMap.get(key);
    }

    /**
     * @param key
     * @return
     */
    public boolean containsKey(String key) {
        return returnMap.containsKey(key);
    }

    /**
     * @return
     */
    public int getID() {
        return ID;
    }

    /**
     * @param cursorID
     */
    public void setID(int cursorID) {
        this.ID = cursorID;
    }

}
