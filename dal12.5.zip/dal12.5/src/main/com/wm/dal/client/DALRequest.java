/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.client;

import com.wm.dal.common.DALSession;

import java.io.Serializable;

/**
 * @author cshah
 * @version 1.0
 */
public class DALRequest implements Serializable, IDALRequest {
    private int ID = 0;
    private DALSession session;
    private int command = 0;
    private int caller = 0;


    /**
     * @param command
     * @param caller
     */
    public DALRequest(int command, int caller) {
        this.command = command;
        this.caller = caller;
    }

    /**
     * @return
     */
    public int getCommand() {
        return command;
    }

    /**
     * @param command
     */
    public void setCommand(int command) {
        this.command = command;
    }

    /**
     * @return
     */
    public int getCaller() {
        return caller;
    }

    /**
     * @param caller
     */
    public void setCaller(int caller) {
        this.caller = caller;
    }

    /**
     * @param session
     */
    public void setSession(DALSession session) {
        this.session = session;
    }

    /**
     * @return
     */
    public DALSession getSession() {
        return session;
    }

    /**
     * @param cursorID
     */
    public void setID(int cursorID) {
        this.ID = cursorID;
    }

    /**
     * @return
     */
    public int getID() {
        return ID;
    }    

    public String toString() {
        return "Command :" + this.command + ", Caller : " + this.caller + ", ID : " + this.ID + "\n" + session.toString();
    }
}
