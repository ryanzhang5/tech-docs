/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.client;

/**
 * 
 * @author cshah
 * @version 1.0
 */
public interface IDALClient {
   
    /**
     * 
     * @param request
     * @return
     * @throws Exception
     */
    public IDALResponse execute(IDALRequest request) throws Exception;
    
    /**
     * 
     * @throws Exception
     */
    public void close() throws Exception;
}
