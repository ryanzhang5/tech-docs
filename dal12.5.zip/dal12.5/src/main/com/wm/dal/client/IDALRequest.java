/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 * @version 1.0
 */

package com.wm.dal.client;

import com.wm.dal.common.DALSession;

import java.io.Serializable;

/**
 * @author cshah
 * @version 1.0
 */
public interface IDALRequest extends Serializable {
    /**
     * @return
     */
    public int getCommand(); // e.g. next, commit, rollback

    /**
     * @param command
     */
    public void setCommand(int command);

    /**
     * @return
     */
    public int getCaller(); // e.g connection, statement, resultset

    /**
     * @param caller
     */
    public void setCaller(int caller);

    /**
     * @param ID
     */
    public void setID(int ID);

    /**
     * @return
     */
    public int getID();

    /**
     * @param session
     */
    public void setSession(DALSession session) ;

    /**
     * @return
     */
    public DALSession getSession() ;

}
