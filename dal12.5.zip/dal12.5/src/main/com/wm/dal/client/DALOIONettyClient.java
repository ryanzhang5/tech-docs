/**
 * Copyright 2009 walmart.com. All rights reserved.
 */

/**
 * @auther cshah
 * @since 9.6
 */
package com.wm.dal.client;

import com.wm.dal.util.ClientConf;
import com.wm.dal.util.DALLogger;

import com.wm.dal.util.ServerConf;

import java.net.InetAddress;
import java.net.InetSocketAddress;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;

import org.jboss.netty.bootstrap.ClientBootstrap;
import org.jboss.netty.channel.ChannelFactory;
import org.jboss.netty.channel.ChannelFuture;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.channel.ChannelPipeline;
import org.jboss.netty.channel.ChannelPipelineCoverage;
import org.jboss.netty.channel.Channels;
import org.jboss.netty.channel.ExceptionEvent;
import org.jboss.netty.channel.MessageEvent;
import org.jboss.netty.channel.SimpleChannelHandler;
import org.jboss.netty.channel.socket.oio.OioClientSocketChannelFactory;
import org.jboss.netty.handler.codec.serialization.ObjectDecoder;
import org.jboss.netty.handler.codec.serialization.ObjectEncoder;

/**
 * 
 * @author cshah
 * @version 1.0
 */
@ChannelPipelineCoverage("one")
public class DALOIONettyClient extends SimpleChannelHandler implements IDALClient {

    private ChannelFuture future;
    private ChannelFactory factory;
    private final BlockingQueue<IDALResponse> responseQueue = 
        new LinkedBlockingQueue<IDALResponse>();
    private static final DALLogger logger = DALLogger.getInstance();
    private static final IDALResponse nullResp = new DALResponse();

    /**
     * 
     * @param addr
     * @param port
     * @throws Exception
     */
    public DALOIONettyClient(InetAddress addr, int port) throws Exception {

        nullResp.setException(new Exception("Null Response"));

        factory = new OioClientSocketChannelFactory(Executors.newFixedThreadPool(ClientConf.getNettyClientBossThreadPoolSize()) );

        ClientBootstrap bootstrap = new ClientBootstrap(factory);

        ChannelPipeline pipeline = bootstrap.getPipeline();
        pipeline.addLast("decoder", new ObjectDecoder());
        pipeline.addLast("encoder", new ObjectEncoder());
        pipeline.addLast("handler", this);

        bootstrap.setOption("connectTimeoutMillis", ClientConf.getConnectionTimeout());
        bootstrap.setOption("keepAlive", ClientConf.getKeepAlive());
        bootstrap.setOption("reuseAddress", ClientConf.getReuseAddress());
        bootstrap.setOption("soLinger", ClientConf.getSOLinger());
        bootstrap.setOption("tcpNoDelay", ClientConf.getTCPNoDely());

        future = bootstrap.connect(new InetSocketAddress(addr, port));
        future.awaitUninterruptibly();

        if (!future.isSuccess()) {
            try {
                future.cancel();
            } catch (Exception exp) {
                exp.printStackTrace();
            }

            if (!ServerConf.inServerVM()) {
                throw new Exception("DAL Server not available " + addr + ":" + port);
            }
            
        }

    }

    /**
     * 
     * @param request
     * @return
     * @throws Exception
     */
    public IDALResponse execute(IDALRequest request) throws Exception {
        return send(request);
    }

    /**
     * 
     * @throws Exception
     */
    public void close() throws Exception {
        responseQueue.offer(nullResp);
        try {
            future.getChannel().close();
        } catch (Exception exp) {
            ;
        }
        //try {
            //TODO
            //factory.releaseExternalResources();
        //} catch (Exception exp) {
        //    ;
        //}
    }

    /**
     * 
     * @param request
     * @return
     * @throws Exception
     */
    public IDALResponse send(IDALRequest request) throws Exception {
        logger.info("in send " + request);
        future.getChannel().write(request);
        logger.info("in take ");
        IDALResponse resp = responseQueue.take();
        if (resp != null)
            return resp;

        throw new Exception("Received Object does not match type...");
    }

    /**
     * 
     * @param ctx
     * @param e
     */
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, ExceptionEvent e) {
        Channels.close(e.getChannel());
        try {
            close();
        } catch (Exception exp) {
            ;
        }
    }

    /**
     * 
     * @param channelHandlerContext
     * @param me
     * @throws Exception
     */
    public void messageReceived(ChannelHandlerContext channelHandlerContext, 
                                MessageEvent me) throws Exception {
        Object message = me.getMessage();
        if (message instanceof IDALResponse) {
            responseQueue.offer((IDALResponse)message);
        } else {
            //just in case the received object does not match type
            responseQueue.offer(nullResp);
            logger.warning("Received message does not match type " + message);
        }
    }

}
