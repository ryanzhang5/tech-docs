package com.wm.weblib.jms;

/**
 * Base messaging class for non admin messages
 * 
 * All non-admin messages should extend this class
 */

public abstract class WMMessageCommon extends WMMessage {
	
	protected WMMessageCommon(WMMessageType msgType) {		
		super(msgType);
	}
	
	protected String getAdditionalParamsString() {
		return BLANK_STRING;
		
	}
}
