
package com.wm.weblib.jms;

import java.util.HashMap;
import java.util.Set;
import java.util.Map;
import java.util.List;
import java.lang.reflect.Method;
import javax.management.*;
import javax.management.monitor.*;

import oracle.jdbc.OracleTypes;
import com.wm.corelib.jmxadmin.WmtMBeanImpl;

public class JMSAdmin extends WmtMBeanImpl implements JMSAdminMBean, WMJMSConstants {

    private String listenerName;

    public JMSAdmin(String listenerName) throws NotCompliantMBeanException {
        super(JMSAdminMBean.class);
	this.listenerName = listenerName;
    }


    public String getLastMessageTimeStamp() {
	Map<String,WMJMSStartListener> jmsListeners = WMJMSListenerManager.getInstance().getListeners();

	WMJMSReceiveMessages aListener = 
	    WMJMSListenerManager.getInstance().getReceiver(listenerName);
	
	if (aListener == null) {
            return (new java.util.Date()).toString();
	}

	if (aListener.getLastMessageReceived() == null) {
	    return (new java.util.Date()).toString();
	} else {
	    java.util.Date recDate = aListener.getLastMessageReceived();
	    return recDate.toString();
	}
    }


    public int getMessageCount() {
        WMJMSReceiveMessages aListener = 
	    WMJMSListenerManager.getInstance().getReceiver(listenerName);

	if (aListener == null) {
	    return 0;
	} else {
	    int count = aListener.getMessageCount();
	    return count;
	}
    }


    public int getBatchMessageCount() {
        WMJMSReceiveMessages aListener = 
	    WMJMSListenerManager.getInstance().getReceiver(listenerName);

	if (aListener == null) {
	    return 0;
	} else {
	    int count = aListener.getBatchCount();
	    return count;
	}
    }


    public String getConfQueueName() {
        WMJMSReceiveMessages aListener = 
	    WMJMSListenerManager.getInstance().getReceiver(listenerName);

        if (aListener == null) {
	    return "";
	} else {
	    return aListener.getAQQName();
	}
    }


    public String getConfQueueSchema() {
        WMJMSReceiveMessages aListener = 
	    WMJMSListenerManager.getInstance().getReceiver(listenerName);
        if (aListener == null) {
	    return "";
	} else { 
	    return aListener.getAQSchema();
	}
    }


    public void stopListener() {
        cancelTimedTasks();
	    WMJMSListenerManager.getInstance().stop(listenerName);
    }


    public void startListener() {
        setupTimedTasks();
	    WMJMSListenerManager.getInstance().start(30000, listenerName);
    }


    public boolean getAlert() {
	try {
	    WMJMSReceiveMessages aListener =
		WMJMSListenerManager.getInstance().getReceiver(listenerName);
	    
	    List msgHandlers = aListener.getHandler();
	    
	    //need to use reflect to call that method
	    for (int i=0; i< msgHandlers.size(); i++) {
		Object aHandler = msgHandlers.get(i);
		Method[] methods = aHandler.getClass().getMethods();

		for (int j=0; j<methods.length; j++) {
		    if ("isQueueAlert".equals(methods[j].getName())) {
			Object aObject = methods[j].invoke(aHandler, (Object[])null);
			return ((Boolean)aObject).booleanValue();
		    }
		}
	    }
	} catch (Exception e) {
	    e.printStackTrace();
	}
	
	return false;
    }


    public String getLastPingReceived() {
	try {
	    WMJMSReceiveMessages aListener =
		WMJMSListenerManager.getInstance().getReceiver(listenerName);
	    
	    List msgHandlers = aListener.getHandler();
	    
	    for (int i=0; i< msgHandlers.size(); i++) {
		Object aHandler = msgHandlers.get(i);
		Method[] methods = aHandler.getClass().getMethods();
		
		for (int j=0; j<methods.length; j++) {
		    if ("getLastPingReceivedTimestamp".equals(methods[j].getName())) {
			return (methods[j].invoke(aHandler, new Object[0])).toString();
		    }
		}
	    }
	} catch (Exception e) {
	    //e.printStackTrace();
	}

	return "";
    }


    public String getLastPingSent() {
	try {
	    WMJMSReceiveMessages aListener =
		WMJMSListenerManager.getInstance().getReceiver(listenerName);
	    
	    List msgHandlers = aListener.getHandler();
	    for (int i=0; i< msgHandlers.size(); i++) {
		Object aHandler = msgHandlers.get(i);
		Method[] methods = aHandler.getClass().getMethods();
		
		for (int j=0; j<methods.length; j++) {
		    if ("getLastPingReceivedTimestamp".equals(methods[j].getName())) {
			return (methods[j].invoke(aHandler, new Object[0])).toString();
		    }
		}
	    }
	} catch (Exception e) {
	    //e.printStackTrace();
	}

        return "";
    }


    public String getAQName() {
        try {
            WMJMSReceiveMessages aListener =
                WMJMSListenerManager.getInstance().getReceiver(listenerName);

	    if (aListener != null) {
		return aListener.getAQQName();
	    }
        } catch (Exception e) {
            e.printStackTrace();
        }
	return "";
    }

    public String getAQSchema() {
        try {
            WMJMSReceiveMessages aListener =
                WMJMSListenerManager.getInstance().getReceiver(listenerName);

            if (aListener != null) {
                return aListener.getAQSchema();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
	return "";
    }

    public void sendMessage(String msg) {
	try {
	    WMJMSReceiveMessages aListener =
		WMJMSListenerManager.getInstance().getReceiver(listenerName);
	    
	    MessageFactory aFactory = aListener.getMessageFactory();
	    
	    List <WMMessage> msgs = aFactory.createMessage(msg);
	    for (int i=0; i< msgs.size(); i++) {
		SendJMSMessage.sendMessage(msgs.get(i));
	    }	    
	} catch (Exception e) {
	    e.printStackTrace();
	}
    }


    public String[] getHandlers() {
	return WMJMSListenerManager.getInstance().getHandlers(listenerName);
    }
	

    public String getQueueFactor() {
        try {
            WMJMSReceiveMessages aListener =
                WMJMSListenerManager.getInstance().getReceiver(listenerName);
	    
	    if (aListener != null) {
		String aqSchema = aListener.getAQSchema();
		String aqName = aListener.getAQQName();
		Map<String, String> map = JMSAdminUtil.getMsgTypeParameter(aqSchema.toUpperCase() +"." + aqName,
									   ITEM_AVAILABILITY);
		System.out.println("=============================== map " + map.toString());
		System.out.println("=============================== map " + MESSAGE_BATCH_SIZE);
		return map.get(MESSAGE_BATCH_SIZE);
	    }
        } catch (Exception e) {
            e.printStackTrace();
        }

	return "";
    }


    public String getQueueDelay() {
        try {
            WMJMSReceiveMessages aListener =
                WMJMSListenerManager.getInstance().getReceiver(listenerName);
	    
	    if (aListener != null) {
		String aqSchema = aListener.getAQSchema();
		String aqName = aListener.getAQQName();
		System.out.println(aqSchema);
		System.out.println(aqName);
		System.out.println(ITEM_AVAILABILITY);
		Map<String, String> map = JMSAdminUtil.getMsgTypeParameter(aqSchema.toUpperCase() + "." + aqName,
									   ITEM_AVAILABILITY);
		System.out.println("=============================== map " + map.toString());
		System.out.println("=============================== map " + MESSAGE_BATCH_DELAY);
		return map.get(MESSAGE_BATCH_DELAY);
	    }
        } catch (Exception e) {
            e.printStackTrace();
        }

	return "";
    }



    public void modifyQueueFactor(String value) {
	if (value == null) return;
	
        try {
            WMJMSReceiveMessages aListener =
                WMJMSListenerManager.getInstance().getReceiver(listenerName);
	    
            if (aListener != null) {
                String aqSchema = aListener.getAQSchema();
                String aqName = aListener.getAQQName();

		JMSAdminUtil.setQueueParameter(aqSchema.toUpperCase() +"." + aqName,
					       ITEM_AVAILABILITY,
					       MESSAGE_BATCH_SIZE,
					       value);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void modifyQueueDelay(String value) {
	if (value == null) return;

        try {
            WMJMSReceiveMessages aListener =
                WMJMSListenerManager.getInstance().getReceiver(listenerName);
	    
            if (aListener != null) {
                String aqSchema = aListener.getAQSchema();
                String aqName = aListener.getAQQName();

		JMSAdminUtil.setQueueParameter(aqSchema.toUpperCase()+"." + aqName,
					       ITEM_AVAILABILITY,
					       MESSAGE_BATCH_DELAY,
					       value);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
