package com.wm.weblib.jms;

import java.io.Serializable;
  
import com.wm.corelib.config.AppConfig;

/**
 * Class is used to send object message through JMS proxy server
 * needs atleast message type and object as Serializable 
 */
public class WMJMSObjectMessage implements Serializable {
    private String _msgType, _target, _origin;
    private Serializable _message;

    /**
     * Object to pass it as an object to FE server
     * @param msgType -- message type
     * @param object -- serizliable object
     */
    public WMJMSObjectMessage(String msgType, Serializable object) {
        _msgType = msgType;
        _message = object;
        _target = WMMessage.TARGET_ALL;
        _origin = AppConfig.getInstance().getProperty(WMJMSConstants.PROP_REAL_HOSTNAME);
    }

    /**
     * Object to pass it as an object to FE server
     * @param msgType -- message type
     * @param target -- target server
     * @param object -- serizliable object
     */
    public WMJMSObjectMessage(String msgType, String target,Serializable object) {
        _msgType = msgType;
        _target = target;
        _origin = AppConfig.getInstance().getProperty(WMJMSConstants.PROP_REAL_HOSTNAME);
        _message = object;
    }

    /**
     * Object to pass it as an object to FE server
     * @param msgType -- message type
     * @param target -- target server
     * @param origin -- origin server 
     * @param object -- serizliable object
     */
    public WMJMSObjectMessage(String msgType, String target, String origin, Serializable object) {
        _msgType = msgType;
        _target = target;
        _origin = origin;
        _message = object;
    }

    /**
     * Return serialized object, passed by other client
     * @return -- Serializable
     */
    public Serializable getObjectMessage() {
        return _message;
    }

    /**
     * Return Message type
     * @return -- String
     */
    public String getMsgType() {
        return _msgType;
    }

    /**
     * Return target server
     * @return -- String
     */
    public String getTarget() {
        return _target;
    }

    /**
     * Returns origin server
     * @return -- String
     */
    public String getOrigin() {
        return _origin;
    }
}
