package com.wm.weblib.jms;

/**
 * Messaging exception class 
 */
public class WMMessageException extends Exception {
	
	public WMMessageException(String msg) {
		super(msg);	
	}

}
