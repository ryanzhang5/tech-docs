
package com.wm.weblib.jms;

import com.wm.corelib.jmxadmin.WmtMBean;
import com.wm.corelib.annotation.Description;
import com.wm.corelib.annotation.PName;

public interface JMSAdminMBean extends WmtMBean {

    public String getLastMessageTimeStamp();
    public int getMessageCount();
    public int getBatchMessageCount();
    public String getConfQueueName();
    public String getConfQueueSchema();

    public boolean getAlert();
    public String getLastPingReceived();
    public String getLastPingSent();

    public String getAQName();
    public String getAQSchema();

    public String[] getHandlers();


    public void stopListener();
    public void startListener();

    public void sendMessage(String msg);

    public String getQueueFactor();
    public String getQueueDelay();

    public void modifyQueueFactor(String value);
    public void modifyQueueDelay(String value);

}
