
package com.wm.weblib.jms;

import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;



/** Utility class for parsing text message. It returns list of HashMap containing
 *  information in the message, such as message type, number of name, values pairs
 *  if any.
 */

public class WMMessageParser {

    /**
     * Parses text String containing name and value pairs and return hash map containing
     * the information.
     * @param msgType message type
     * @param textMessage Message to be parsed to create WMMessage
     * @param targetServerRegex target server regex
     * @return HashMap containing message information with key value pairs
     * @throws WMMessageException
     */
    private static final HashMap parseNV(String msgType, 
					 String textMessage,
					 String targetServerRegEx) 
	throws WMMessageException {

	HashMap<String, String> valueMap = new HashMap<String, String>(30); //to prevent rehashing
	valueMap.put(WMMessage.MSG_TYPE_KEY, msgType);

	int index0 = 0;

        if (textMessage != null) {
	    while (true) {
		int index1 = textMessage.indexOf(WMMessage.PARAM_DELIMETER, index0);
		
		if (index1 > 0) {
		    String nvPair = textMessage.substring(index0, index1);
		    int equalIndex = nvPair.indexOf(WMMessage.EQUALS);
		    
		    String name = nvPair.substring(0, equalIndex);
		    String value = nvPair.substring(equalIndex+1, nvPair.length());
		    valueMap.put(name, value);
		    
		    index0 = index1+1;
		    
		} else { //to the end
		    String nvPair = textMessage.substring(index0, textMessage.length());
		    
		    int equalIndex = nvPair.indexOf(WMMessage.EQUALS);
		    
		    String name = nvPair.substring(0, equalIndex);
		    String value = nvPair.substring(equalIndex+1, nvPair.length());
		    
		    valueMap.put(name, value);
		    break;
		}
	    }
	}
	    
	if (targetServerRegEx != null) {
	    valueMap.put(WMMessage.TARGET, targetServerRegEx);
	}
	
	return valueMap;
    }



    
    /**
     * Parses text String to create list of hashmap containing all message information.
     * @param textMessage Message to be parsed to create WMMessage
     * @param targetServerRegex target server regex
     * @return List of HashMap containing message information with key value pairs etc
     * @throws WMMessageException
     */
    public static final List<HashMap> parse(String textMessage, String targetServerRegEx)
	throws WMMessageException
    {
	ArrayList<String> msgBatch = new ArrayList<String>();
	ArrayList<HashMap> msgs = new ArrayList<HashMap>();
	
	String msgType = null;
	String msgBody = null;
	String msgTail = null;
    
	int msgTypeIndex = textMessage.indexOf(WMMessage.MSG_TYPE_DELIMETER);
        if (msgTypeIndex == -1) { //there is no delimeter, such as ping
	    msgs.add(parseNV(textMessage, null, targetServerRegEx));
            return msgs;
        }

	msgType = textMessage.substring(0, msgTypeIndex);

	int msgBodyIndex0 = textMessage.indexOf(WMMessage.BATCH_DELIMETER);

	// if clearcachebykey msg, then ignore batch "|"  since that msg might has "|" in the key itself instead of implicating batch separation
	boolean escape = msgType.equals(WMMessageType.MSG_TYPE_CLEAR_CACHE_BY_KEY.toString()) 
                      || msgType.equals(WMMessageType.MSG_TYPE_CLEAR_CACHE_BY_KEY_L1.toString());

	if (msgBodyIndex0 > 0 && !escape ) { //is batch, contains "|"
	
	    while(true) {
		int msgBodyIndex1 = textMessage.indexOf(WMMessage.BATCH_DELIMETER, msgBodyIndex0+1);
		
		if (msgBodyIndex1 > 0) {
		    msgBody = textMessage.substring(msgBodyIndex0+1, msgBodyIndex1).trim();
		    msgBatch.add(msgBody);

		    msgBodyIndex0 = msgBodyIndex1;
		} else {
		    break;
		}
	    }

	    msgTail = textMessage.substring(msgBodyIndex0+1, textMessage.length()).trim();

	    for (int i=0; i<msgBatch.size(); i++) {
		String newMsg = msgBatch.get(i) + msgTail;  //reconstruct each message
		HashMap aMsgMap = parseNV(msgType, newMsg, targetServerRegEx);
		msgs.add(aMsgMap);
	    }

	} else { // not batch
	    msgBody = textMessage.substring(msgTypeIndex+1, textMessage.length()).trim();
	    HashMap aMsgMap = parseNV(msgType, msgBody, targetServerRegEx);
	    msgs.add(aMsgMap);
	}

	return msgs;
    }

}
