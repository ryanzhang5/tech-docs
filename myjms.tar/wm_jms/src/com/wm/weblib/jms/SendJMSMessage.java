package com.wm.weblib.jms;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Driver;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.wm.sql.DataAccess;
  
import com.wm.corelib.config.AppConfig;


public class SendJMSMessage {
	
    public static final String TARGET_SERVER_ALL_REGEX = WMMessageAdmin.TARGET_ALL;
    public static final String TARGET_SERVER_WWW_REGEX =".*";
    public static final String TARGET_SERVER_AVOCADO_REGEX =".*";
    public static final String TARGET_SERVER_SWAP_REGEX =".*";
	
    public static final String MESSAGE_IS_COMMIT = "Y";
    public static final int MESSAGE_EXPIRE_TIME = 3600; //a hour
    public static final int MESSAGE_PRIORITY = 5;
    public static final String DBPOOL_ALIAS = AppConfig.getInstance()
            .getProperty("com.wm.jms.aq.poolname", "jdbcpool_inventory");

    /** Static class logger */
    private static Logger _logger = Logger.getLogger(SendJMSMessage.class.getName());
    private static final String _sendMessage = "{call wiq_aq_pkg.send_message(?, ?, ?, ?, ?)}";
    
    
    /**
     * Unified version of sending message based on the queue name
     * @param msg WMMessage
     */
    public static void sendMessage(WMMessage msg) {
	
	if (_logger.isLoggable(Level.FINE))
	    _logger.fine("Send Message [" + msg.getMessageAsString() + "]");
	
	Connection con = null;
	CallableStatement stmt = null;
	ResultSet rs = null;
	
	try {
	    con = getMessagingConnection (msg);
            stmt = con.prepareCall(_sendMessage);

	    stmt.setString(1, msg.getQueueSchema() + "." + msg.getQueueName() );
	    stmt.setString(2, msg.getMessageAsString());
	    stmt.setInt(3, MESSAGE_EXPIRE_TIME);
	    stmt.setString(4, MESSAGE_IS_COMMIT);
	    stmt.setInt(5, MESSAGE_PRIORITY);
	    stmt.execute();
	    con.commit();

	} catch (SQLException e) {
	    e.printStackTrace();
	    _logger.log(Level.SEVERE, 
			"Exception occured while sending admin message", e);
	    throw new com.wm.sql.XRuntimeSQL(e);
	} finally {
	    //connection is wrap of PooledConnection
	    //close will just return the connection to the pool
	    try {
		con.close();
	    } catch (Exception e) {
		e.printStackTrace();
	    }
	}		
    }

    private static Connection getMessagingConnection (WMMessage msg) throws SQLException{
    	Connection con = null;
        String dalPoolName = SendJMSMessage.DBPOOL_ALIAS.replaceAll("jdbc", "dal");
        String jdbcPoolName = SendJMSMessage.DBPOOL_ALIAS;
	
    	if(msg.getMessageType().equals(WMMessageType.MSG_TYPE_UNLOCK_DB_POOL) ){
    		
    		String diverClass = null;
    		String url = null;
    		String user = null;
    		String passwd = null;
    		
    		diverClass = AppConfig.getInstance().getProperty("com.wm.sql.dataaccess."+dalPoolName+".class");
    		url        = AppConfig.getInstance().getProperty("com.wm.sql.dataaccess."+dalPoolName+".url");
    		user       = AppConfig.getInstance().getProperty("com.wm.sql.dataaccess."+dalPoolName+".user");
    		passwd     = AppConfig.getInstance().getProperty("com.wm.sql.dataaccess."+dalPoolName+".passwd");

    		if(diverClass==null || diverClass.trim().equals("")){
        		diverClass = AppConfig.getInstance().getProperty("com.wm.sql.dataaccess."+jdbcPoolName+".class");
        		url        = AppConfig.getInstance().getProperty("com.wm.sql.dataaccess."+jdbcPoolName+".url");
        		user       = AppConfig.getInstance().getProperty("com.wm.sql.dataaccess."+jdbcPoolName+".user");
        		passwd     = AppConfig.getInstance().getProperty("com.wm.sql.dataaccess."+jdbcPoolName+".passwd");   			
    		}
    		
    		if(diverClass==null || diverClass.trim().equals("")){
    			throw new SQLException("Can not find configuration for pool: "+ jdbcPoolName);
    		}
    		
    		Driver driver = null;
    		Properties driverProperties = new Properties();
                driverProperties.put("user", user);
                driverProperties.put("password", passwd);
            
            try {
            	driver = (Driver) Class.forName(diverClass).newInstance();
            	con = driver.connect(url, driverProperties);
            }catch (SQLException sqle) {
                throw sqle;
            }catch (Exception e) {
                throw new SQLException(e);
            }

    	}else{
    		
    	    String diverClass = AppConfig.getInstance().getProperty("com.wm.sql.dataaccess."+jdbcPoolName+".class");
    	    if(diverClass!=null && !diverClass.trim().equals("")){
    		con = DataAccess.getInstance().getConnection(jdbcPoolName);
    	    }else{
    		con = DataAccess.getInstance().getConnection(dalPoolName);
    	    }
    	}
    	return con;
    }    

}
