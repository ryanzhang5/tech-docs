package com.wm.weblib.jms;

import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;
import java.util.logging.Logger;
  
import com.wm.corelib.config.AppConfig;

/**
 * Implement a concrete subclass of this when you want to create
 * a handler for a specific type of WMMessage.
 */
abstract public class WMMessageHandler implements WMJMSConstants {

	/** Static class logger */
	private static Logger _logger = Logger.getLogger(WMMessageHandler.class.getName());
	
    /**
     * Return this static final status object from handleMessage
     * when you don't care about the message you were passed.  This
     * will avoid unnecessary noop status message object creation.
     */
    protected final static WMMessageHandlerStatus _defaultStatus = new WMMessageHandlerStatus();

    /**
     * This will be used as return value in case of successful message processing.
     */
    protected final static WMMessageHandlerStatus _successStatus = new WMMessageHandlerStatus(WMMessageHandlerStatus.CODE_SUCCESS);

    /**
     * Implementations of this method should check to see if
     * the message is of concern to the handler.  If it isn't of
     * concern, this method should be a noop.  If it is of
     * concern, the this method should handle it in some way.
     *
     * This method returns a WMMessageHandlerStatus object which
     * describes the status of handling event.
     */
    public abstract WMMessageHandlerStatus handleMessage(WMMessage m);
    
    protected abstract boolean canHandle(WMMessage m);
    
	/**
	 * Checks to see if the message is source is trusted or not.
	 * Defaults to true
	 *
	 * @param message WMMEssage to be handled
	 * @return true if message is from trusted souce else false
	 * @see WMAdminMessageHandler#isTrusted(WMMessage)
	 * @see WMJMSListener#_processMessage(WMMessage)
	 */
	protected boolean isTrusted(final WMMessage message) {
		return true;		
	}
	
	/**
	 * Checks to see if the message is targetted to this server
	 * if no parameter is sent, assumes targettted 
	 * 
	 * @param message WMMessage to be tested
	 * @return true if targetted else false
	 * @see WMAdminMessageHandler#isTargetted(WMMessage)
	 * @see WMJMSListener#_processMessage(WMMessage)
	 */
	protected boolean isTargetted(final WMMessage message) {
				
		String target = message.getTarget();		
		boolean targetted = true;
		if (target != null) {
			targetted = AppConfig.getInstance().getProperty(PROP_REAL_HOSTNAME).matches(target);		
		}
		_logger.fine("Target Server Regex : " + target + " allowed : " + targetted);
		return targetted;
	}	



    /**
     * For testing only. Reads messages from standard input,
     * calls handleMessage for each one and prints results to output stream
     */
    

}
