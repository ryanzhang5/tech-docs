/*
 * Created on Aug 7, 2005
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package com.wm.weblib.jms;

import java.util.Date;
import java.util.Vector;
import java.util.logging.Logger;

import javax.jms.Session;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;

import oracle.jms.AQjmsFactory;
import oracle.jms.AQjmsSession;
  
import com.wm.corelib.config.AppConfig;

public class WMJMSOracleStartListener extends WMJMSStartListener {
    /** Static class logger */
    private static Logger _logger = Logger.getLogger(WMJMSOracleStartListener.class.getName());

    private static final String DBPOOL_ALIAS = AppConfig.getInstance()
            .getProperty("com.wm.jms.aq.poolname", "jdbcpool_inventory");

    /** AQ message queue name */
    private String aq_queue_name;

    /** AQ schema */
    private String aq_schema;

    //
    // Member variables
    //
    private TopicConnectionFactory _tcf = null;
    private TopicConnection _tc = null;
    private TopicSession _session = null;
    private TopicSubscriber _subscriber = null;
    private Topic _topic = null;
    private String _subscriberName = null;
    private String _name;

    public WMJMSOracleStartListener(String name, String aq_schema, String aq_queue_name){
        this._name = name;
        this.aq_queue_name = aq_queue_name;
        this.aq_schema = aq_schema;
    }

    public String getAQQName(){
		return aq_queue_name;
	}
    public String getAQSchema(){
		return aq_schema;
	}
    public String getListenerName(){
        return _name;
    }
    public TopicSession getSession(){
        return _session;
    }
    public TopicSubscriber getSubscriber(){
        return _subscriber;
    }
    public TopicConnection getConnection(){
        return _tc;
    }

    public void JMSStart() {
        try {
            /* create connection and session */
            _logger.info("Starting JMS connection for " + _name);
            _tcf = AQjmsFactory.getTopicConnectionFactory(
                    AppConfig.getInstance().getProperty("com.wm.sql.dataaccess."+DBPOOL_ALIAS+".url"),
                    new java.util.Properties());
            _logger.info("TopicConnectionFactory created for " + _name);
            _tc = _tcf.createTopicConnection(
                    AppConfig.getInstance().getProperty("com.wm.sql.dataaccess."+DBPOOL_ALIAS+".user"),
                    AppConfig.getInstance().getProperty("com.wm.sql.dataaccess."+DBPOOL_ALIAS+".passwd"));
            _logger.info("TopicConnection created for " + _name);

            _session = _tc.createTopicSession(true, Session.CLIENT_ACKNOWLEDGE);
            _logger.info("TopicSession created for " + _name);

            _topic = ((AQjmsSession) _session).getTopic(aq_schema, aq_queue_name);
            _logger.info("Topic created for " + _name);

            /* create a subscriber */
            _subscriberName = JMSAdminUtil.getSubscriberName();
            _subscriber = _session.createDurableSubscriber(_topic,
                                                           _subscriberName,
                                                           null, false);
            _logger.info("Subscriber '" + _subscriberName + "' created for " + _name);

            _tc.start();
            _logger.info("Started connection for " + _name );
            _logger.info("Waiting for the messages for " + _name+ " , " + _tc);
        } catch (Exception e) {
            _logger.warning("Error starting JMS" + e);
        }
    }

    public void JMSStop() {
        _logger.info("Stopping JMS for " + _name);

        try {
            if (_subscriber != null) {
                _subscriber.close();
            }
        } catch (Exception ignore) {
            ignore.printStackTrace();
        }

        _logger.info("Subscriber closed for " + _name );

        try {
            if (_tc != null) {
                _tc.stop();
            }
        } catch (Exception ignore) {
            ignore.printStackTrace();
        }

        _logger.info("Connection stopped " + _name);

        try {
            if (_session != null) {
            	((AQjmsSession)_session).unsubscribe(_topic, JMSAdminUtil.getSubscriberName());
            	_logger.info("unsubscribe for " + JMSAdminUtil.getSubscriberName());

                _session.close();
            }
        } catch (Exception ignore) {
            ignore.printStackTrace();
        }

        _logger.info("session closed for " + _name);

        try {
            if (_tc != null) {
                _tc.close();
            }
        } catch (Exception ignore) {
            ignore.printStackTrace();
        }

        _logger.info("TopicConnection closed for " + _name+ " , " + _tc);
        _logger.info("Done " + _name);
        _tc = null;
        _subscriber = null;
        _session = null;
    }
    /**
     * Checks if listener connected.
     */
    public boolean isConnected() {
        return _tc != null;
    }
    /**
     * Return status information for the object.
     */
    public synchronized String toString() {
        String ls = AppConfig.getInstance().getProperty("line.separator");
        StringBuffer s = new StringBuffer(getClass().getName() + " { ");
        s.append(ls);

        if (!isConnected()) {
            s.append("  Listener is not connected.");
            s.append(ls);
        } else {
            s.append("  subscriber name: ");
            s.append(_subscriberName);
            s.append(ls);
            s.append("  queue name: ");
            s.append(aq_schema + "." + aq_queue_name);
            //s.append(ls);
            //s.append("  lastMessageReceived: ");
            //s.append(_lastMessageReceived);
            //s.append(ls);
            //s.append("  messages received: ");
            //s.append(_messageCount);
            s.append(ls);
        }

        /*s.append("  registered handlers: { ");

        for (int i = 0; i < _handlers.size(); i++) {
            if (i != 0) {
                s.append(",");
            }

            s.append(_handlers.elementAt(i).getClass().getName());
        }

        s.append(" }");
        s.append(ls);
        s.append("}");*/

        return s.toString();
    }
}
