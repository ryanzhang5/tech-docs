

package com.wm.weblib.jms;

public interface WMJMSConstants {

    public static final String PROP_REAL_HOSTNAME = "com.wm.hostname.real";
    public static final String PROP_APP_DOMAIN_CODE = "com.wm.ApplicationDomainCode";
    public static final String PROP_AUTHORIZED_PUBLISHERS = "com.wm.jms.AuthorizedPublishers";

    public static final String ITEM_AVAILABILITY = "ITEM_AVAILABILITY";
    public static final String MESSAGE_BATCH_SIZE = "MESSAGE_BATCH_SIZE";
    public static final String MESSAGE_BATCH_DELAY = "MESSAGE_BATCH_DELAY";

}
