
package com.wm.weblib.jms;

import com.wm.weblib.jms.common.WMMessageDBPoolClear;
import com.wm.weblib.jms.common.WMMessageDBPoolUnlock;
import com.wm.weblib.jms.common.WMMessageDBPoolUrlKeys;

import java.util.HashMap;
import java.util.List;

import javax.jms.ObjectMessage;

/** abstract class with abstract methods so sub classes
 *  will provide actual implementation for WM JMS message
 *  creation.
 */

public abstract class MessageFactory {

    protected String _qName;
    protected String _qSchema;

    /** parses JMS text message and generates list of WMMessages.
     *  @param message JMS text message
     *  @return list of WMMessages
     *  @throws WMMessageException 
     */
    public abstract List<WMMessage> parseJMSTextMessage(javax.jms.TextMessage message) 
	throws WMMessageException;

    /** parses JMS object message and generates list of WMMessages.
     *  @param message JMS Object message
     *  @return list of WMMessages
     *  @throws WMMessageException 
     */
    public abstract List<WMMessage> parseJMSObjectMessage(WMJMSObjectMessage message) 
        throws WMMessageException;


    /** parses message string and generates list of WMMessages. 
     *  @param message string
     *  @return list of WMMessages
     *  @throws WMMessageException
     */
    public abstract List<WMMessage> createMessage(String message)
        throws WMMessageException;

    /**
     * creates and returns a new instance of given message object.
     * subclasses can adopt a parent_first/child_first implementation - as needed.
     * @param valueMap map containing message information after parsing.
     * @return - a new WMMessageType (if this is a known type), or null
     */
    protected WMMessage newInstance(HashMap<String, String> valueMap)
            throws WMMessageException {
        // Note: have named this as newInstance instead of get/createMessage() to avoid
        // breaking existing subclasses that might have those methods declared as private.

        String msgType = valueMap.get(WMMessage.MSG_TYPE_KEY);

        if (_qName == null || _qName.trim().length() == 0 ||
                _qSchema == null || _qSchema.trim().length() == 0) {
            throw new WMMessageException("JMS queue name is null");
        }

        WMMessage msg = null;
        if (msgType.equals(WMMessageType.MSG_TYPE_CLEAR_DB_POOL.toString())) {
            msg = new WMMessageDBPoolClear(valueMap);
        } else if (msgType.equals(WMMessageType.MSG_TYPE_UNLOCK_DB_POOL.toString())) {
            msg = new WMMessageDBPoolUnlock(valueMap);
        } else if (msgType.equals(WMMessageType.MSG_TYPE_SET_CONNECTION_POOL_INFO.toString())) {
        	msg = new com.wm.weblib.jms.common.WMMessageSetConnectionPoolInfo(valueMap);
        } else if (msgType.equals(WMMessageType.MSG_TYPE_DBPOOL_CONNECTION_RECYCLE.toString())) {
        	msg = new com.wm.weblib.jms.common.WMMessageDBPoolConnectionRecycle(valueMap);
        } else if (msgType.equals(WMMessageType.MSG_TYPE_DBPOOL_URL_KEYS.toString())) {
        	msg = new WMMessageDBPoolUrlKeys(valueMap);
        }

        if (msg != null) {
            msg.setQueueInfo(_qName, _qSchema);
        }
        
        return msg;
    }


    /** Factory class will maintain the queue name/schema and put it
     *  in the message it generates. SendJMSMessage will use the
     *  name to send the meesage.
     *  @param qName JMS queue name
     *  @param qSchema JMS queue schema
     *  @throws WMMessageException    
     */
    public void setQueueInfo(String qName, String qSchema) 
        throws WMMessageException {
        if (qName != null && qName.trim().length() > 0 &&
            qSchema != null && qSchema.trim().length() > 0) {
            _qName = qName;
            _qSchema = qSchema;
        } else {
            throw new WMMessageException("JMS queue name is null");
        }
    }


    public String getQueueName() {
	    return _qName;
    }

    public String getQueueSchema() {
	    return _qSchema;
    }

    //public abstract WMMessage createMessage(HashMap valueMap) throws WMMessageException;
    //public abstract List<WMMessage> createMessage(String textMessage) throws WMMessageException;

}
