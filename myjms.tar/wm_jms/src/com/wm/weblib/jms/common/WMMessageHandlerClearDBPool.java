package com.wm.weblib.jms.common;


import com.bitmechanic.sql.GenericPool;
import com.wm.sql.DataAccess;
import com.wm.weblib.jms.WMMessage;
import com.wm.weblib.jms.WMMessageHandlerStatus;
import com.wm.weblib.jms.WMMessageType;

import java.util.Date;
import java.util.StringTokenizer;
import java.util.List;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Admin Message Handler, locks / unlocks DB Pools.
 * Primarily used for database updates
 */
public class WMMessageHandlerClearDBPool extends WMAdminMessageHandler {
    private static final Logger logger = Logger.getLogger(WMMessageHandlerClearDBPool.class.getName());

    // TODO: keep this?
    public static final String[] DEFAULT_POOLS = {
            "jdbcpool_search",
            "jdbcpool_cc",
            "jdbcpool_catalog",
            "jdbcpool_oms",
            "jdbcpool_inventory",
            "dalpool_catalog",
            "dalpool_catalog_ssl",
            "dalpool_catalog_l2",
            "dalpool_catalog_avo",
            "dalpool_oms",
            "dalpool_oms_node1",
            "dalpool_oms_node2",
            "dalpool_oms_node3",                                    
            "dalpool_oms_ssl",
            "dalpool_oms_l2",
            "dalpool_oms_avo",
            "dalpool_inventory",
    };

    private static final String[] SEARCH_POOL = {
            "jdbcpool_search",
    };

    /**
     * returns true if this message can be handled
     *
     * @param message WMMessage
     */
    protected boolean canHandle(WMMessage message) {
        WMMessageType msgType = message.getMessageType();
        return msgType.equals(WMMessageType.MSG_TYPE_CLEAR_DB_POOL)
        || msgType.equals(WMMessageType.MSG_TYPE_UNLOCK_DB_POOL)
        || msgType.equals(WMMessageType.MSG_TYPE_DBPOOL_CONNECTION_RECYCLE);
    }

    /**
     * Handles messages "clear_db_pool" and "unlock_db_pool"
     * <p/>
     * optionally message can have pooltype.
     * If pooltype is search, clear_db_pool and unlock_db_pool
     * operations work only on search pools and will not send lock message to L2 Servers
     * <p/>
     * <p/>
     * <p/>
     * clear_db_pool locks the pool and removes all connections and starts a timer to
     * unlock the pool after pre-defined time.
     * <p/>
     * unlock_db_pool releases lock on the pool
     * <p/>
     * Both messages send appropriate messages to Global Cache
     *
     * @param m message to be handled
     * @return WMMessageHandlerStatus
     *         - success message after successful processing of the message.
     *         - a default status if the message is not processed, and
     *         - an error code and stack trace if an exception occurred.
     */
    public WMMessageHandlerStatus handleMessage(WMMessage m) {

        try {

            if (!canHandle(m)) return _defaultStatus;

            WMMessageType mt = m.getMessageType();
            if (mt.equals(WMMessageType.MSG_TYPE_CLEAR_DB_POOL)) {
                WMMessageDBPoolClear msg = (WMMessageDBPoolClear) m;
                logger.warning("Processing CLEAR_DB_POOL msg ...");

                // Lock down the pool and restrict further access to the pool.
                /*
                   [2/6/02] Currently, daily data pushes are applied to both
                   catalog and search servers.  Here's how it's done:
                    1.  Script sends JMS message "clear_db_pool" to lock and clear
                        both the catalog and search db pool before any rename is
                        performed.
                    2.  Script waits for a success message.  Then it renames the
                        catalog table(s) followed by search table(s).
                    3.  Script sends JMS message "unlock_db_pool" to unlock the
                        pools.
                 */

                lockPools(getPoolNames(msg));
                logger.warning("Pools locked/Cleared All Db-connections...");

                _successStatus.setMessage(this.getClass().getName() + ": successfully processed message " + m);
            } else if (mt.equals(WMMessageType.MSG_TYPE_UNLOCK_DB_POOL)) {
                WMMessageDBPoolUnlock msg = (WMMessageDBPoolUnlock) m;
                logger.warning("Processing UNLOCK_DB_POOL msg ...");

                unlockPools(getPoolNames(msg));
                logger.warning("Pools now UNLOCKED ...");

                _successStatus.setMessage(this.getClass().getName() + ": successfully processed message " + m);
            }else if (mt.equals(WMMessageType.MSG_TYPE_DBPOOL_CONNECTION_RECYCLE)) {
                WMMessageDBPoolConnectionRecycle msg = (WMMessageDBPoolConnectionRecycle) m;
                logger.warning("Processing dbpool_connection_recycle msg ...");

                recyclePools(getPoolNames(msg));
                logger.warning("Pools now recycled ...");

                _successStatus.setMessage(this.getClass().getName() + ": successfully processed message " + m);
            }

        } catch (Exception e) {
            logger.log(Level.WARNING, "DEFAULT ERROR MSG", e);

            return new WMMessageHandlerStatus(WMMessageHandlerStatus.CODE_FAILURE, e.toString());
        }

        return _successStatus;
    }

    private String[] getPoolNames(WMMessageDBPool msg) {
        return (msg.isSearchPoolsOnly())
                ? SEARCH_POOL
                : ((msg.getPoolType() != null)
                        ? split(msg.getPoolType(), WMMessage.APP_SAFE_DELIMITER)
                        : DEFAULT_POOLS
                );
    }

    private String[] split(String str, String delim) {
        List<String> list = new ArrayList<String>();
        StringTokenizer tokenizer = new StringTokenizer(str, delim);
        while (tokenizer.hasMoreTokens()) {
            String token = tokenizer.nextToken();
            if (token != null && token.trim().length() != 0) {
                list.add(token.trim());
            }
        }
        return list.toArray(new String[list.size()]);
    }


    private void recyclePools(String[] poolNames) {
        for (String poolName : poolNames) {
            logger.warning("Recycling pool: " + poolName);
            try {
                GenericPool[] pool = DataAccess.getInstance().getConnectionPool(poolName.trim());
                if (pool == null) continue;
                for (GenericPool aPool : pool) {
                    try {
                        aPool.removeAll();
                    } catch (Exception e) {
                        logger.log(Level.WARNING, "Unexpected error while recycling pool", e);
                    }
                }
            } catch (Exception e) {
                logger.log(Level.WARNING, "Unexpected error while recycling pools", e);
            }
        }
    }

    private void lockPools(String[] poolNames) {
        for (String poolName : poolNames) {
            logger.warning("Locking pool: " + poolName);
            try {
                GenericPool[] pool = DataAccess.getInstance().getConnectionPool(poolName.trim());
                if (pool == null) continue;
                for (GenericPool aPool : pool) {
                    try {
                        aPool.setLocked(true);
                        aPool.removeAll();
                    } catch (Exception e) {
                        logger.log(Level.WARNING, "Unexpected error while locking pool", e);
                    }
                }
            } catch (Exception e) {
                logger.log(Level.WARNING, "Unexpected error while locking pools", e);
            }
        }
    }

    private void unlockPools(String[] poolNames) {
        for (String poolName : poolNames) {
            logger.warning("Unlocking pool: " + poolName);
            try {
                GenericPool[] pool = DataAccess.getInstance().getConnectionPool(poolName.trim());
                if (pool == null) continue;
                for (GenericPool aPool : pool) {
                    try {
                        aPool.setLocked(false);
                    } catch (Exception e) {
                        logger.log(Level.WARNING, "Unexpected error while unlocking pools", e);
                    }
                }
            } catch (Exception e) {
                logger.log(Level.WARNING, "Unexpected error while unlocking pools", e);
            }
        }
    }


    protected void test() throws java.io.IOException {
        java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(System.in));
        logger.info("Enter messages to test.");
        logger.info("<format> := <lock/unlock> <poolNames> <target-servers-regex>");
        logger.info("<poolNames> := <poolName>_<poolName>");
        logger.info("==================================================");

        while (true) {
            try {
                StringTokenizer st = new StringTokenizer(r.readLine(), " ");
                if (st.countTokens() < 3) {
                    logger.info("Incorrect number of parameters. expected: 3, actual: " + st.countTokens());
                    continue;
                }
                String type = st.nextToken();
                String poolNames = st.nextToken();
                String target = st.nextToken();

                if (!"lock".equalsIgnoreCase(type) && !"unlock".equalsIgnoreCase(type)) {
                    logger.info("Incorrect operation type. expected: lock/unlock, actual: " + type);
                    continue;
                }

                //List <WMMessage>wms = WMMessage.parse(textMessage);
                //List<WMMessage> wms = (new WMMessageAdminFactory()).createMessage(textMessage);
                WMMessage wm = null;
                if ("lock".equalsIgnoreCase(type)) {
                    wm = new WMMessageDBPoolClear(target, poolNames);
                } else {
                    wm = new WMMessageDBPoolUnlock(target, poolNames);
                }
                wm.setTimestamp(new Date());
                logger.info("Processing message: " + wm);
                WMMessageHandlerStatus status = this.handleMessage(wm);
                logger.info("result: " + status);

            } catch (Exception exception) {
                logger.log(Level.WARNING, "Error processing the input message", exception);
            }

        }
    }


    public static void main(String[] args) throws java.io.IOException {
        (new WMMessageHandlerClearDBPool()).test();
    }
}