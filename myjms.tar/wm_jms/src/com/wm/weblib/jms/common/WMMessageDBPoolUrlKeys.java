package com.wm.weblib.jms.common;

import com.wm.weblib.jms.WMMessageAdmin;
import com.wm.weblib.jms.WMMessageException;
import com.wm.weblib.jms.WMMessageType;

import java.util.HashMap;
import java.util.Map;
import java.io.Serializable;

public class WMMessageDBPoolUrlKeys extends WMMessageAdmin {

	public WMMessageDBPoolUrlKeys(HashMap valueMap) throws WMMessageException {
		super(WMMessageType.MSG_TYPE_DBPOOL_URL_KEYS, valueMap);
	}

    public Map<String,String> getUrlKeys() {
        return (Map<String,String>) getObjectMessage();
    }

    @Override
    public void setObjectMessage(Serializable objmsg) {
        if (objmsg == null || objmsg instanceof Map) {
            super.setObjectMessage(objmsg);
        } else {
            throw new IllegalArgumentException("This class expects a Map<String,String> argument, found: " + objmsg.getClass());
        }
    }
}