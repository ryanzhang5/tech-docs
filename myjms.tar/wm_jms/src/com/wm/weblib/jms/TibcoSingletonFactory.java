package com.wm.weblib.jms;


import com.tibco.tibjms.TibjmsTopicConnectionFactory;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.logging.Logger;

import javax.jms.TopicConnectionFactory;


public class TibcoSingletonFactory {
    private static TibcoSingletonFactory instance;
    private static final ConcurrentMap<String, TopicConnectionFactory> connectionFactoryMap = new ConcurrentHashMap<String,TopicConnectionFactory>();
    private static final Logger logger = Logger.getLogger(TibcoSingletonFactory.class.getName());

    /**
     * Private Constructor
     * @throws Exception -- Exception
     */
    private TibcoSingletonFactory() throws Exception {
    }

    /**
     * Singleton class
     * @return -- Instance ActiveMQSingleTonFactory
     */
    public static synchronized TibcoSingletonFactory getInstance() throws Exception {
        if (instance == null) {
            instance = new TibcoSingletonFactory();
        }

        return instance;
    }    

     /**
     * Return TopicConnectionFactory for Active MQ
     * @param user - User
     * @param password - Password
     * @param url - URL
     * @return - TopicConnectionFactory
     * @throws Exception - Exception
     */
    public synchronized TopicConnectionFactory getTopicConnectionFactory(String user, String password, String url) throws Exception {
        if (!connectionFactoryMap.containsKey(url)) {
            if (url == null || url.trim().length() == 0) 
                throw new Exception("TIBCO URL can not be null");
    
            if (user == null || user.trim().length() == 0) {
                logger.warning("User name is null, using default user name");
                user = "admin";
            }
            
            if (password == null || password.trim().length() == 0) {
                logger.warning("Password is null, using default password");
                password = "";
            }
            
            TopicConnectionFactory _tcf =  new TibjmsTopicConnectionFactory(url);
            connectionFactoryMap.put(url, _tcf); 
        }
        return connectionFactoryMap.get(url);
    }    
}
