package com.wm.weblib.jms;

import java.io.Serializable;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import java.util.List;
import java.util.ArrayList;
  
import com.wm.corelib.config.AppConfig;


/**
 * Base WMMessage class for server messaging
 * Encapsulates message data 
 * Interface to parse text message may be removed. 
 */
public abstract class WMMessage implements WMJMSConstants {	
    
    /** Constants used in sub classes */
    public static final String MSG_TYPE_KEY = "msgType";
    public static final String MSG_TYPE_DELIMETER = ":";
    public static final String BATCH_DELIMETER = "|";
    public static final String PARAM_DELIMETER = ",";
    public static final String EQUALS = "=";
    public static final String BLANK_STRING = "";
    // the following is not used by framework itself, 
    // its reserved for use by apps to create simple delimited messages
    public static final String APP_SAFE_DELIMITER = "~";
    
    public static final String ORIGIN = "origin";
    public static final String TARGET = "target";
    public static final String TARGET_ALL = ".*";	
    
    

    /** Target Queue Name
     */
    protected String _qName;


    /** Target Queue Schema
     */
    protected String _qSchema;

    /**
     * Target server regex
     */
    protected String _target;
    
    /** 
     * key value map for the message maintained privately, all extending
     * classes should use appropriate setters and getters.
     */
    private HashMap<String, String> _valueMap = new HashMap<String, String>();
    
    private Serializable _objectMessage = null;
    /**
     * The type of message this thing is.
     */
    private WMMessageType _messageType;
    
    /**
     * The type of message this thing is.
     */
    protected String _originServer;
    
    /**
     * Describes when the message was issued.
     */
    private Date _timestamp;

       
    /**
     * Protected contructor
     * @param msgType
     */
    protected WMMessage(WMMessageType msgType) {
	_messageType = msgType;				    
    }
    
    /**
     * @return WMMessageType message type
     */
    public WMMessageType getMessageType() {
	return _messageType;
    }
    
    /**
     * Returns a timestamp for when the message was initially sent.
     */
    public Date getTimestamp() {
	return _timestamp;
    }
    
    public void setTimestamp(Date timeStamp) {
	_timestamp = timeStamp;
    }

       /**
     * Returns a originserver for when the message was initially sent.
     */
    public String getOriginServer() {
	return _originServer;
    }
    
    public void setOriginServer(String originServer) {
    _originServer = originServer;
    }    
    
    /**
     * returns additional message string
     * used by specialized super classes
     * @return String
     * @see WMMessageAdmin
     */
    protected abstract String getAdditionalParamsString();
    
    /**
     * Returns WMMessage in String format.
     * returned value can be parsed back to create identical message
     * @return String WMMessage in string format
     * @see #getAdditionalParamsString()
     */
    public String getMessageAsString() {
	
	StringBuffer buf = new StringBuffer(100);		
	buf.append(getMessageType()).append(MSG_TYPE_DELIMETER);
	buf.append(TARGET).append(EQUALS).append(getTarget()).append(PARAM_DELIMETER);

	String origin = AppConfig.getInstance().getProperty(PROP_REAL_HOSTNAME);
	buf.append(ORIGIN).append(EQUALS).append(origin);
	
	// Any additional params super class may supply
	buf.append(getAdditionalParamsString());
	
	Iterator itr = _valueMap.keySet().iterator();
	while (itr.hasNext()) {
	    String str = (String)itr.next();
	    buf.append(getParamString(str, getValue(str)));
	}


	return buf.toString();
    } // getMessageAsString
    

    protected String getParamString(String key, String value) {
	if (value == null)
	    value = BLANK_STRING;
	return PARAM_DELIMETER + key + EQUALS + value;		
    }
    
    /**
     * Get string representation of the WMMessage
     */
    public String toString() {	
	return getMessageAsString();
    }
    
    
	
    /** 
     * Convenience method to set value
     * Try to convert given value to String 
     */
    protected void setValue(String name, Object value){
	_valueMap.put(name, (String)value);
    }
    
    /** Convenience method to set String value */
    protected void setValue(String name, String value){
	_valueMap.put(name, value);
    }
    
    /**
     * sets value, ensures given value is integer
     * @param key Key
     * @param value value convertible to int
     * @throws WMMessageException
     */
    protected void setIntValue(String key, Object value)
	throws WMMessageException
    {	
	try {
	    String val = value.toString();
	    Integer.parseInt(val);
	    setValue(key, val);
	} catch (NumberFormatException e) {
	    throw new WMMessageException(key + " error : " + e.getMessage());
	}
    }
    
    /**
     * sets value, ensures given value is convertible to long
     * @param key Key
     * @param value convertible to long
     * @throws WMMessageException
     */
    protected void setLongValue(String key, Object value)
	throws WMMessageException
    {	
	try {	
	    String val = value.toString();
	    Long.parseLong(val);
	    setValue(key, val);
	} catch (NumberFormatException e) {
	    throw new WMMessageException(key + " error : " + e.getMessage());
	}
    }
    
    /**
     * returns stored value as string 
     * @param name key name
     * @return value, null if not stored
     */
    protected String getValue(String name){
	return (String)_valueMap.get(name);
    }
    
    /**
     * returns target regular expression
     * @return target regular expression, if nothing is set TARGET_ALL 
     */
    public String getTarget() {
	if (_target == null )
	    return TARGET_ALL;
	return _target;
    }
    

    public String getQueueName() {
	return _qName;
    }


    public String getQueueSchema() {
	return _qSchema;
    }


    public void setQueueInfo(String qName, String qSchema) {
	_qName = qName;
	_qSchema = qSchema;
    }

    
    public Serializable getObjectMessage() {
        return _objectMessage;
    }

    public void setObjectMessage(Serializable objmsg) {
        _objectMessage = objmsg;
    }
    
    /**
     * For testing only.
     */
    /*
    public static void main(String[] args) {
	for (int i = 0; i<args.length; i++) {		
	    try {			
		String msg = args[i];
		System.out.println(msg);
		System.out.println("");

		List<WMMessage> ms = WMMessage.parse(msg);
		for (int j=0; j<ms.size(); j++) {
		    WMMessage m = ms.get(j);
		    System.out.println(m.toString() + " :: " + m.getClass().getName());			
		}
	    } catch (WMMessageException exception ) {
		exception.printStackTrace();
	    }
	}
    }
    */
}
